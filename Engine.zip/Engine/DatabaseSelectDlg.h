#ifndef _ENGINE_DATABASESELECTDLG_H_
#define _ENGINE_DATABASESELECTDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_UI_LAYOUTMANAGER_H_
#	include "Ui\LayoutManager.h"
#endif	// _UI_LAYOUTMANAGER_H_
#ifndef 	_UI_LISTCTRLSORT_H_
#	include "Ui\ListCtrlSort.h"
#endif	// _UI_LISTCTRLSORT_H_
#ifndef 	_ENGINE_QUERIES_H_
#	include "Engine\Queries.h"
#endif	// _ENGINE_QUERIES_H_
#ifndef 	_ENGINE_DATABASES_H_
#	include "Engine\Databases.h"
#endif	// _ENGINE_DATABASES_H_
#ifndef 	_DATA_COLLECTIONSELECTDLG_H_
#	include "Data\CollectionSelectDlg.h"
#endif	// _DATA_COLLECTIONSELECTDLG_H_
#include "resource.h"
//}}Uses

//{{Predefines
class CIuDatabaseList;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDatabaseSelectDlg, CDialog }}
#define CIuDatabaseSelectDlg_super CDialog

class CIuDatabaseSelectDlg : public CIuDatabaseSelectDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDatabaseSelectDlg(CWnd* pParent = NULL);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool SelectDlg(CIuID& id, CIuDatabases* pDatabases, CIuQueries* pQueries, int iFlags = 0, LPCTSTR pcszApplication = 0, CWnd* pParent = 0);
	static bool SelectDlg(CIuDatabaseList& DatabaseList, int iFlags = 0, LPCTSTR pcszApplication = 0, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CreateColumns();
	void CreateRows();
	void CreateRows(CIuCollection* pCollection);
	CIuCollectable* GetCollectable(CIuID ID);
	void OnChange(CIuID ID);
	void OnSpecialAccess();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The collection(s) being selected from
	CIuDatabases* m_pDatabases;
	CIuQueries* m_pQueries;
	// The default selections (if any)
	CIuIDArray m_aidDefaults;
	// Dialog auto-sizer item
	CIuLayoutManager m_LayoutManager;
	// Name of application which must be matched for databases
	CString m_sApplication;
	// Flags
	int m_iFlags;
	// Multi-select?
	bool m_fMultiSelect;
	// Sort helper
	CIuListCtrlSort m_Sort;
	// Parent window to use for child dialogs.
	// NOTE: Sometimes this dialog pops up children but never displays itself.
	CWnd* m_pParent;
//}}Data


public:
	//{{AFX_DATA(CIuDatabaseSelectDlg)
	enum { IDD = IDD_ENGINE_DATABASE_SELECT };
	CButton	m_btnStates;
	CButton	m_btnValidate;
	CButton	m_btnAll;
	CListCtrl	m_Grid;
	CString	m_sDescription;
	BOOL	m_fAll;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuDatabaseSelectDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuDatabaseSelectDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnColumnclickGrid(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedGrid(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkGrid(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRefresh();
	afx_msg void OnSearch();
	afx_msg void OnAll();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnValidate();
	afx_msg void OnStates();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_DATABASESELECTDLG_H_
