#ifndef _ENGINE_GEORAWEXCHANGE_H_
#define _ENGINE_GEORAWEXCHANGE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENT_H_
#	include "Engine\GeoRawElement.h"
#endif	// _ENGINE_GEORAWELEMENT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawExchange)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawExchange, CIuGeoRawElement }}
#define CIuGeoRawExchange_super CIuGeoRawElement

class CIuGeoRawExchange : public CIuGeoRawExchange_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawExchange)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawExchange();
	virtual ~CIuGeoRawExchange();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetTitle() const;
	CIuGeoRawElementAccumulator& GetZips() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
	void SetTitle(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetZips_() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sTitle;
	mutable CIuGeoRawElementAccumulator m_Zips;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuGeoRawExchange::GetTitle() const
{
	return m_sTitle;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawExchange::GetZips() const
{
	return m_Zips;
}

#endif // _ENGINE_GEORAWEXCHANGE_H_
