#ifndef _ENGINE_REGEX_H_
#define _ENGINE_REGEX_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRegEx)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegEx, CIuObjectNamed }}
//	This class exists primarily as a help class for dealing with expressions.
//	All classes that deal with "expressions" use this class as a helper. UI's
//		also use this class to properly format expressions.
//	This class ensure that constructing and parsing of expressions is handled
//		in a consistent manner.
// An associated class, CIuRegExList, deals with lists of expressions.
//	For example, this class deals makes sure that special characters are
//		properly delimited: "Omaha, NE" -> "Omaha\, NE"
//	The name of an expression object is used by the expression list object to
//		hold the index name associated with the expression. 
//		The name may be blank.
//	This class has several purposes:
//		1) Properly format an expression typed-in by the user... adding 
//			backslashes, quotes, etc. so that the string is properly handled
//			by the engine.
//		2) Analyze an expression in an attempt to determine its type.
//		3) Parse an expression and make the components available for internal
//			processing by the engine.
//	The class works by parsing the expression in a tokenized representation.
//	
//	Currently, the following expression types/components are recognized:
//		Simple String
//			A simple string. May contain special characters using the backslash
//				\char					Used to insert special characters.
//										'\,' matches a comma character
//			Examples:
//				'abc'
//				'abc\''
//		Wild-Carded String
//			A wild-carded string. Similar to a simple string, but may have a 
//			terminating '*' to indicate a wildcarded match. A '*' may be 
//			embedded using a backslash.
//			Examples:
//					'abc'
//					'abc*'
//					'\*abc*'
//					'\*abc\*'
//		Key
//			Index keys are often simple or wildcarded strings. However, they
//			can also contain more than one component (in a multi-keyed index).
//			Internally, we generally use a null as the separator. However, 
//			this is not easily passed around. So it is, instead, converted to a 
//			printable ascii character. 
//			A character like \n or \t might seem like a reasonable choice, but this
//			character is not easily entered or represented in most UI's. We also need
//			to make sure that the select character does not appear in any data fields.
//			Finally, the character must be lower than any other character so that the
//			keys sort correctly. 
//			Anyway... taking all this into consideration dictates that the only possible
//			choice is a control character (like '\n' or '\t') even though it is difficult
//			to represent in a UI.
//			Tab is the choice because linefeed causes goofy looking textual queries.
//			A tab can be represented as \t or as an actual tab character. In debug mode,
//			we also accept the caret, '^', and convert it to a tab.
//			Examples:
//					'abc\tdef\tghi'
//		List
//			A list of strings, wild card strings, regular expressions, ranges 
//			or keys may be created by separated the components with a comma
//			Examples:
//					'abc,def*'
//		Range
//			A ranged list of strings, wild card strings, regular expressions or keys
//			may be created by separating the sub-ranges with a tilde.
//				~						Anywhere but the start of a sub-expression, denotes a range.
//										'A~C' matches anything >= A and <= B.
//										NOTE: Ranges are undefined when used with wildcards. They may
//										work for simple expressions, but nothing is guaranteed.
//				- (leading)			At the start of an sub-expression, functions as a 'NOT'.
//										'-A~B' matches anything but 'A' to 'B'
//			Examples:
//					'abc~def'
//					'-abc~def'
//		Expressions
//			A rudimentary regular expression evaluator is built in.
//			The following special characters are recognized:
//				- (leading)			At the start of an sub-expression, functions as a 'NOT'. 
//										'-A' matches anything but 'A'
//				%						At the start of an sub-expression, denotes a phonetic match.
//				!						At the start of an sub-expression, denotes a "within" search.
//										This would be the same as starting the expression with a star.
//										'!OHN' would match any string containing 'OHN'
//										This is the same as '*OHN*'.
//				*						Matches zero or more characters
//				?						Matches exactly one character
//			Examples:
//				'-407,-870,3??'
//		Global
//			The start of an expression may contain a grouping of options
//				enclosed in curly brackets.
//			This specifies one or more options which apply to each and 
//				every sub expression.
//			For example 
//				'{!}' specifies that each clause should be a "within" search.
//				'{*}' implies that all strings need only be a partial match. 
//						so '{*}A,B' is the same as 'A*,B*'
//				'{%}' implies that all sub-expressions should be matched phonetically. 
//				'{-}' implies that all sub-expressions should be negated.
//				Multiple options are allowed, as in '{-!}'
//			Examples:
//				{*}
//				{-!}
//	
//	NOTE: This grammar was derived originally from PhoneDisc. It would be more
//			consistent to use '~' for negation and '-' for ranges... but that was
//			not the PhoneDisc way. I try to make the grammar as flexible as 
//			possible anyway.

// Flags for specifying which components are ALLOWED.
const int regExString				= 0x00000000;	// Redundant option... chars are alway allowed
const int regExWildcard				= 0x00000001;	// Allow a trailing '*'
const int regExSeparator			= 0x00000002;	// Allow a \t (tab character) to separate compontents
const int regExList					= 0x00000004;	// Allow comma separated lists of values
const int regExRange					= 0x00000008;	// Allow ranges
const int regExRegEx					= 0x00000010;	// Allow expression */?/!/%
const int regExGlobal				= 0x00000020;	// Allow global options {*/-/%/!}
const int regExIgnoreWhitespace	= 0x00000040;	// Ignore leading/trailing whitespace on expression
const int regExCaseSensitive		= 0x00000080;	// Perform case insensitive compares

const int regExAddWildcard			= 0x00000100;	// Used by CreateExpression() to append
																// a single wildcard
// Combined flags

// A simple expression which ignores leading and trailing whitespace
const int regExSimple				= regExString|regExIgnoreWhitespace;
// Simple expression with a wildcard
const int regExSimpleWildcard		= regExString|regExIgnoreWhitespace|regExWildcard;
// Index key only
const int regExKey					= regExString|regExSeparator|regExWildcard;
const int regExKeyRange				= regExString|regExSeparator|regExWildcard|regExRange;
const int regExKeyRangeList		= regExString|regExSeparator|regExWildcard|regExList|regExRange;
// Full expression
const int regExFull					= regExString|regExWildcard|regExList|regExRange|regExRegEx|regExGlobal|regExIgnoreWhitespace;

// NOTE: The high 12-bits are used internally!
const int regExAll					= 0x00000FFF;

// Flags indicating a global option or a master option
// has been set. These can also be passed to CreateExpression()
//	to create the options on the fly.
//	These are considered to be "internal" flags even though
//	they are used externally in create expression.
// These are set when a global option has been set
// via the expression. For example: '{!-}'.
const int regExHasGlobalWildcard	= 0x00001000;	// {*}
const int regExHasGlobalNot		= 0x00002000;	// {-}
const int regExHasGlobalPhonetic	= 0x00004000;	// {%}
const int regExHasGlobalWithin	= 0x00008000;	// {!}


// Options for sub expression
// These indicate whether a term in an expression contained
// certain special options.
const int regExHasTermNot			= 0x00010000;	// Expression has a leading -
const int regExHasTermPhonetic	= 0x00020000;	// ... % (implies no range!)
const int regExHasTermWithin		= 0x00040000;	// ... ! (implies no range!)
const int regExHasTermWildcard	= 0x00080000;	// A trailing '*'
const int regExHasTermRange		= 0x00100000;	// Expression was a range
const int regExHasTermList			= 0x00200000;	// Expression was a list
const int regExHasTermSeparator	= 0x00400000;	// A \t (tab character) to separate compontents
const int regExHasTermRegEx		= 0x00800000;	// Expression */? (but not a wildcard)

// These indicate whether a specified option
// was actually parsed!
const int regExHasParsedNot		= 0x01000000;	
const int regExHasParsedPhonetic	= 0x02000000;	
const int regExHasParsedWithin	= 0x04000000;	

// Flags indicating the state of the expression
const int regExHasAllNegated		= 0x80000000;	// All terms were negated (used by comparator)

const int regExHasMask				= 0xFFFFF000;

#define CIuRegEx_super CIuObjectNamed
class IU_CLASS_EXPORT CIuRegEx : public CIuRegEx_super
{
//{{Declare
	DECLARE_SERIAL(CIuRegEx)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegEx();
	CIuRegEx(const CIuRegEx&);
	CIuRegEx(LPCTSTR pcszExpression, int iFlags = regExSimple);
	virtual ~CIuRegEx();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetExpression() const;
	int GetFlags() const;
	int GetMasterFlags() const;
	static int GetMasterFlags(LPCTSTR pcsz);
	int GetTerm(int iTerm, CString& sLo, CString& sHi) const;
	int GetTerms() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static CString CleanName(LPCTSTR pcsz);
	static CString Convert(LPCTSTR pcszName, LPCTSTR pcszExpression, int iFlags = regExSimple);
	static CString ConvertExpression(LPCTSTR pcszExpression, int iFlags = regExSimple);
	static CString ConvertName(LPCTSTR pcszName);
	static CString CreateExpression(int iFlags, LPCTSTR pcszExpression);
	static CString CreateExpressionF(int iFlags, LPCTSTR pcszExpression, ...);
	CString CreateLikeClause(LPCTSTR pcszName = 0, LPCTSTR pcszExpression = 0) const;
	virtual void Copy(const CIuObject& object);
	void SetExpression(LPCTSTR pcszExpression, int iFlags = regExSimple);
	void SetName(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuRegEx& operator=(const CIuRegEx&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	CString BuildExpression();
	static CString BuildGlobals(int iFlags);
	static CString CleanExpression(LPCTSTR pcsz, int& iTermFlags, int& iGlobalFlags);
	void CommonConstruct();
	static LPCTSTR ParseExpression(LPCTSTR pcsz, CString& sLo, CString& sHi, int& iTermFlags, int& iGlobalFlags);
	void ParseExpressions(LPCTSTR pcsz);
	static LPCTSTR ParseGlobal(LPCTSTR pcsz, int& iFlags);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Formatted string representation of the expression
	CString m_sExpression;
	// Flags controlling the expression
	int m_iFlags;
	// Parse sub-expressions
	// The strings representing:
	//	Leading options (not/phonetic/within/range)
	CIntArray m_aiFlags;
	// Values for hi/lo or lo=expression
	CStringArray m_asLo;
	CStringArray m_asHi;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuRegEx::GetExpression() const
{
	// The expression which is returned is not quoted.
	// However, it may have been reformatted from the input.
	return m_sExpression;
}

inline int CIuRegEx::GetFlags() const
{
	return m_iFlags;
}

#endif // _ENGINE_REGEX_H_
