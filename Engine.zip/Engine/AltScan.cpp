#include "StdAfx.h"
//{{Include
#include "AltScan.h"
#include "Alt.h"
#include "CdromSpecConst.h"
#include "AltSpec.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Error\Error.h"
#include "Common\Clean.h"
#include "FieldDefConst.h"
#include "..\Version.h"
#include "RecordIterator.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltScan, CIuAltScan_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltScan)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTSCAN, CIuAltScan, CIuAltScan_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltScan, IDS_ENGINE_PPG_ALTSCAN, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAltScan, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAltScan, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ALTSCAN, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAltScan, IDS_ENGINE_PROP_OUTPUT, GetOutput_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuAltScan, IDS_ENGINE_PROP_OUTPUT, IDS_ENGINE_PPG_ALTSCAN, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAltScan::CIuAltScan() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltScan::~CIuAltScan()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuAltScan::Build(CIuOutput& Output, CIuFlags Flags)
{
	m_Input.SetInputFilename(GetFilename());
	m_Input.SetOutputFilename(GetFilename());

	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
	{
		GetOutput().Delete(&Output);
		m_Input.Delete(&Output);
	}

	if (!Output.Fire())
		return false;

	if (!Flags.Test(cdromsBuildAlt))
		return true;

	if (!m_Input.Build(Output, Flags))
		return false;

	// Save output state
	CIuOutputStateInstance instance(Output);

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetFilename());
	if (!Iterator.Open(Output))
		return false;

	// Process the records in the file
	Output.OutputF("Scanning alternates %s\n", LPCTSTR(GetName()));
	Output.SetMessageF("Alternates scan");
	CIuRecordPtr pRecord;
	CIuAltInstance Instance;
	CStringArray as;
	for (int iRecord = 0; Iterator.MoveNext(Output, pRecord); ++iRecord)
	{
		LPCTSTR pcszAlt = pRecord->GetField(inputAltAlt);
		LPCTSTR pcszSeeAlso = pRecord->GetField(inputAltSeeAlso);

		StringAsStringArray(pcszSeeAlso, as, '\n');

		Instance.Clear();
		Instance.SetKey(pcszAlt);
		Instance.SetValues(as);

		if (Instance.GetKey().IsEmpty() || Instance.GetKey().CompareNoCase(_T(",")) == 0)
		{
			Output.WarnF("Alternate record %d in %s has blank key\n", iRecord, LPCTSTR(GetName()));
			continue;
		}
		if (Instance.GetValueCount() == 0)
		{
			// This happens quite often, especially in the alt-phone file. Simply ignore the record.
			// Output.WarnF("WARNING: Alternate record %d in %s has no values\n", iRecord, LPCTSTR(GetName()));
			continue;
		}
		GetOutput().Append(Instance);
	}

	// Done
	Output.SetMessageF("Closing");
	Output.Fire();
	Iterator.Close(Output);

	Output.SetMessage("Writing raw alternates");
	Output.Fire();
	GetOutput().Write();

	// Having completed the scan and written the output, we now clear the
	// output. Otherwise, the output will be a huge drag on memory resources.
	Output.SetMessage("Clearing raw alternates");
	Output.Fire();
	GetOutput().Empty();

	// Result
	Output.OutputF("Processed %ld alternates in %s\n", iRecord, LPCTSTR(GetName()));

	// Display elapsed time
	instance.Pop(true);

	return Output.Fire();
}

void CIuAltScan::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("AltScan");
	m_sFilename = "Filename";
	if (m_pOutput.IsNull())
	{
		m_pOutput.Create();
	}
	SetVersion(IU_VERSION);
	//}}Initialize
}

CString CIuAltScan::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CIuObject* CIuAltScan::GetOutput_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pOutput.Ptr()));
}
		
void CIuAltScan::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAltScan::SetSpec(int iAltNo)
{
	CIuAltSpec Spec;
	Spec.FromNo(0, iAltNo);

	SetName(Spec.GetName());
	SetID(Spec.GetID());
	SetFilename(Spec.GetFilename());
	GetOutput().SetSpec(iAltNo);
}
