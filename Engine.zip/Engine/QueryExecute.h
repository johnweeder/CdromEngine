#ifndef _ENGINE_QUERYEXECUTE_H_
#define _ENGINE_QUERYEXECUTE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_SELECT_H_
#	include "Engine\Select.h"
#endif	// _ENGINE_SELECT_H_
#ifndef 	_ENGINE_REGEXLIST_H_
#	include "Engine\RegExList.h"
#endif	// _ENGINE_REGEXLIST_H_
#ifndef 	_SOURCECONVERT_H_
#	include "SourceConvert.h"
#endif	// _SOURCECONVERT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuQueryExecute)
IU_DEFINE_OBJECT_PTR(CIuSource)
IU_DEFINE_OBJECT_PTR(CIuSetList)
IU_DEFINE_OBJECT_PTR(CIuCounts)
class CIuSourceProvider;
class CIuEngine;
class CIuQuery;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Expected query type
enum CIuQueryMode
{
	queryModeNone,

	queryModeRecordSet,
	queryModeCount,
	queryModeRequest,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuQueryExecute, CIuObject }}
//	This is a helper class used by the query object to actually run a query.
// This class is relatively complicated and it was separated from the query
// class primarily for maintainability.
#define CIuQueryExecute_super CIuObject

class CIuQueryExecute : public CIuQueryExecute_super
{
//{{Declare
	DECLARE_SERIAL(CIuQueryExecute)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuQueryExecute();
	CIuQueryExecute(CIuQuery& Query);
	virtual ~CIuQueryExecute();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetExpression() const;
	CIuQuery& GetQuery() const;
	CString GetResult() const;
	bool HasQuery() const;
	bool IsSuccessful() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Run();
	CIuCountsPtr SetCount(LPCTSTR);
	void SetQuery(CIuQuery& pQuery);
	void SetRecordSet(LPCTSTR);
	void SetRequest(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	bool CreateFilter();
	bool CreateSetList();
	bool CreateSources();
	void CreateSourceSetList();
	bool Distinct();
	bool ExpandSetList();
	bool First();
	bool Execute();
	CIuEngine& GetEngine() const;
	CIuOutput& GetOutput() const;
	CIuSourceProvider& GetSourceProvider() const;
	bool IsDirectMode() const;
	bool IsScanNeeded() const;
	void Reset();
	bool RunCount();
	bool RunDirect();
	bool RunOutput();
	bool RunRecordSet();
	bool RunRequest();
	bool Scan();
	void SetExpression(LPCTSTR);
	bool Setup();
	bool Sort();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Query mode
	int m_iMode;
	// The owning query
	CIuQuery* m_pQuery;
	CString m_sExpression;
	// If a string result is returned, it is here
	CString m_sResult;
	// The counts object for the current count request
	CIuCountsPtr m_pCounts;
	// The select statement
	CIuSelect m_Select;
	// Flags/options used to create sources
	int m_iFlags;
	CIuOptions m_Options;
	// The queries names for this run
	CStringArray m_asQueries;
	// And, the indexes/keys which apply to each database
	CIuRegExList m_Criteria;
	// Geo constrained (near) search
	CIuLatLongDistance m_Distance;
	CIuLatLongCoordinate m_Center;
	int m_iNear;
	// The WHERE/FILTER clause
	CString m_sFilter;
	// Sort info
	bool m_fSort;
	CStringArray m_asSort;
	int m_iSortLimit;
	// The raw sources are a collection of pointers to 
	// the lowest level source objects.
	CArray<CIuSourcePtr, CIuSource*> m_aSources;
	// The set list
	CIuSetListPtr m_pSetList;
	// The output is the source attached to the recordeet
	// It may be the same as an input source or it may be different
	CIuSourcePtr m_pSource;
	// A converter object
	CIuSourceConvert m_Convert;
	// Successful completion flag
	// A setting of false usually indicates the operation was 
	// either aborted or is in progress
	bool m_fSuccess;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuQueryExecute::GetExpression() const
{
	return m_sExpression;
}

inline CIuQuery& CIuQueryExecute::GetQuery() const
{
	ASSERT(HasQuery());
	return *m_pQuery;
}

inline CString CIuQueryExecute::GetResult() const
{
	return m_sResult;
}

inline bool CIuQueryExecute::HasQuery() const
{
	return m_pQuery != 0;
}

inline bool CIuQueryExecute::IsSuccessful() const
{
	return m_fSuccess;
}

#endif // _ENGINE_QUERYEXECUTE_H_
