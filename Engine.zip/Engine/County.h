#ifndef _ENGINE_COUNTY_H_
#define _ENGINE_COUNTY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENT_H_
#	include "Engine\GeoElement.h"
#endif	// _ENGINE_GEOELEMENT_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCounty, CIuGeoElement }}
#define CIuCounty_super CIuGeoElement
#pragma pack(1)
class CIuCounty : public CIuCounty_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCountyCode() const;
	LPCTSTR GetCountyCodeAsString() const;
	LPCTSTR GetCountyName() const;
	int GetStateNo() const;
	void GetZipList(CIuGeoList&) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoCounty;

	// The full 5 digit state code
		int m_iCountyCode;
	// Fixed Data:
	// Variable Data:
		// List of associated ZIP's	
	// Strings:
		//	0) County code as string
		//	1) County name
//}}Data

};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuCounty::GetCountyCode() const
{
	return m_iCountyCode;
}

inline LPCTSTR CIuCounty::GetCountyCodeAsString() const
{
	return GetName();
}

inline LPCTSTR CIuCounty::GetCountyName() const
{
	return GetString(1);
}

inline int CIuCounty::GetStateNo() const
{
	return m_iCountyCode / 1000;
}

#endif // _ENGINE_COUNTY_H_
