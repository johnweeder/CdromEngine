#ifndef _ENGINE_FIELDDEFSPEC_H_
#define _ENGINE_FIELDDEFSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ENGINEAPP_H_
#	include "Engine\EngineApp.h"
#endif	// _ENGINE_ENGINEAPP_H_
#ifndef 	_INTEROP_FLAGS_H_
#	include "Interop\Flags.h"
#endif	// _INTEROP_FLAGS_H_
#ifndef 	_COMMON_OPTIONS_H_
#	include "Common\Options.h"
#endif	// _COMMON_OPTIONS_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldDefSpec)
class CIuFieldDef;
class CIuExpression;
class CIuRecordDef;
class CIuResolveSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldDefSpec, CIuObjectNamed }}
#define CIuFieldDefSpec_super CIuObjectNamed

class CIuFieldDefSpec : public CIuFieldDefSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuFieldDefSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldDefSpec();
	CIuFieldDefSpec(LPCTSTR pcsz, bool fAssumeIsSpec = false);
	CIuFieldDefSpec(const CIuFieldDefSpec&);
	CIuFieldDefSpec(const CIuFieldDef&);
	virtual ~CIuFieldDefSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool AreDefaults() const;
	int GetBoughtLevel() const;
	int GetCaseConvert() const;
	static int GetCount();
	CString GetDescription() const;
	CString GetExpression() const;
	CIuExpression* GetExpressionPtr() const;
	int GetFieldNo() const;
	CIuFlags GetFlags() const;
	CString GetFlagsAsString() const;
	int GetLength() const;
	CString GetLiteral() const;
	CString GetLongName() const;
	static void GetNames(CStringArray& as);
	int GetOffset() const;
	CString GetOptions() const;
	CString GetShortName() const;
	virtual CString GetSpecification() const;
	bool HasExpressionPtr() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	CIuExpression* DetachExpressionPtr();
	virtual bool FromExpression(LPCTSTR pcszName, LPCTSTR pcszParms = 0, LPCTSTR pcszExpr = 0);
	virtual void FromFieldDef(const CIuFieldDef& FieldDef);
	virtual bool FromIndex(int iSpec, LPCTSTR pcszParms = 0, LPCTSTR pcszExpr = 0);
	virtual bool FromName(LPCTSTR pcszName);
	virtual bool FromNo(int iSpec, LPCTSTR pcszParms = 0, LPCTSTR pcszExpr = 0);
	static void Parse(LPCTSTR pcsz, bool fAssumeIsSpec, CString& sName, CString& sParms, CString& sExpr, bool& fRelative);
	virtual void Parse(LPCTSTR pcsz, bool fAssumeIsSpec = false);
	virtual int Resolve(CIuResolveSpec& Spec);
	virtual void Set(LPCTSTR pcsz, bool fAssumeIsSpec = false);
	void SetBoughtLevel(int);
	void SetCaseConvert(int iCaseConvert);
	void SetDefaults(bool = true);
	void SetDescription(LPCTSTR);
	void SetExpression(LPCTSTR);
	void SetFlags(CIuFlags);
	void SetFlagsAsString(LPCTSTR);
	void SetLength(int);
	void SetLongName(LPCTSTR);
	void SetName(LPCTSTR pcsz);
	void SetOffset(int);
	void SetOptions(LPCTSTR);
	void SetShortName(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldDefSpec& operator=(const CIuFieldDefSpec&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	void SetFieldNo(int);
	void SetLiteral(LPCTSTR);
protected:
	virtual void ParseParms(LPCTSTR pcsz, bool fAppend = false);
private:
	void CommonConstruct();
	void ResolveField(CIuResolveSpec& Spec);
	void SetExpressionPtr(CIuExpression* pExpression);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	// Options includes an parts of the parameters which were not 
	// recognized elsewhere.
	// These are different than the global options passed in during 
	// resolution.
	CString m_sOptions;

private:
	// These components represent an assembled textual field specification 
	// of the form:
	//		"name(parms):expression"
	CString m_sExpression;
	// These values are parsed out of the "parms" area.
	CString m_sLongName;
	CString m_sShortName;
	CString m_sDescription;
	int m_iLength;
	int m_iBoughtLevel;
	int m_iOffset;
	CIuFlags m_flagsFlags;
	int m_iCaseConvert;
	// This is a special option. When it is parsed out, it tells the 
	// resolver to prefer information in the raw record's field def
	// over information in this field specification.
	// In other words, this field specification just provides "defaults".
	bool m_fDefaults;

	// This information is strictly used during the process
	// of resolving a field specification. Basically, a field will
	// resolve to 1) an actual field, 2) an expression or 
	//	3) a constant literal.
	int m_iFieldNo;
	CIuExpression* m_pExpression;
	CString m_sLiteral;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuFieldDefSpec::AreDefaults() const
{
	return m_fDefaults;
}

inline int CIuFieldDefSpec::GetBoughtLevel() const
{
	return m_iBoughtLevel;
}

inline int CIuFieldDefSpec::GetCaseConvert() const
{
	return m_iCaseConvert;
}

inline CString CIuFieldDefSpec::GetDescription() const
{
	return m_sDescription;
}

inline CString CIuFieldDefSpec::GetExpression() const
{
	return m_sExpression;
}

inline CIuExpression* CIuFieldDefSpec::GetExpressionPtr() const
{
	return m_pExpression;
}

inline int CIuFieldDefSpec::GetFieldNo() const
{
	return m_iFieldNo;
}

inline int CIuFieldDefSpec::GetLength() const
{
	return m_iLength;
}

inline CString CIuFieldDefSpec::GetLiteral() const
{
	return m_sLiteral;
}

inline CString CIuFieldDefSpec::GetLongName() const
{
	return m_sLongName;
}

inline int CIuFieldDefSpec::GetOffset() const
{
	return m_iOffset;
}

inline CString CIuFieldDefSpec::GetOptions() const
{
	return m_sOptions;
}

inline CString CIuFieldDefSpec::GetShortName() const
{
	return m_sShortName;
}

inline bool CIuFieldDefSpec::HasExpressionPtr() const
{
	return m_pExpression != 0;
}

#endif // _ENGINE_FIELDDEFSPEC_H_
