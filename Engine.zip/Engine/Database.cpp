#include "stdafx.h"
#include "Engine.h"
#include "Meters.h"
#include "resource.h"
#include "Data\resource.h"
#include "CdromSpec.h"
#include "Database.h"
#include "Databases.h"
#include "Version.h"
#include "Data\Archive.h"
#include "Meter.h"						 
#include "Indexes.h"
#include "Error\Error.h"
#include "Common\SysInfo.h"
#include "CdromSpecConst.h"
#include "UserInterfaceSpec.h"
#include "UserInterface.h"
#include "UserInterfaces.h"
#include "MeterSpec.h"
#include "Cdrom.h"
#include "Splash.h"
#include "SplashSpec.h"
#include "Splashes.h"
#include "MeterEnableDlg.h"
#include "MeterWarningDlg.h"
#include "VersionDlg.h"
#include "Ui\FillStatesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuDatabase, CIuDatabase_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuDatabase)

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_DATABASE, CIuDatabase, CIuDatabase_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuDatabase, IDS_ENGINE_PROP_METERMONIKER, GetMeterMoniker, SetMeterMoniker, 0)

	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuDatabase, IDS_ENGINE_PROP_INDEXES, GetIndexes_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuDatabase, IDS_ENGINE_PROP_INDEXES, 0)

	IU_ATTRIBUTE_PAGE(CIuDatabase, IDS_ENGINE_PPG_DATABASE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_COPYRIGHT, GetCopyright, SetCopyright, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_COPYRIGHT, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_RELEASE, GetRelease, SetRelease, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_RELEASE, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_DT(CIuDatabase, IDS_ENGINE_PROP_CREATED, GetCreated, SetCreated, 0)
	IU_ATTRIBUTE_EDITOR_DT(CIuDatabase, IDS_ENGINE_PROP_CREATED, IDS_ENGINE_PPG_DATABASE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_USERINTERFACE, GetUserInterface, SetUserInterface, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_USERINTERFACE, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_APPLICATION, GetApplication, SetApplication, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_APPLICATION, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuDatabase, IDS_ENGINE_PROP_METERMONIKER, IDS_ENGINE_PPG_DATABASE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_FILENAME, GetFilename, SetStringNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuDatabase, IDS_ENGINE_PROP_FORMAT, GetFormat, SetFormat, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuDatabase, IDS_ENGINE_PROP_FORMAT, IDS_ENGINE_PPG_DATABASE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuDatabase, IDS_ENGINE_PROP_SPLASH, GetSplash, SetSplash, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuDatabase, IDS_ENGINE_PROP_SPLASH, IDS_ENGINE_PPG_DATABASE, 0)
	IU_ATTRIBUTE_PROPERTY_VERSION(CIuDatabase, IDS_ENGINE_PROP_VERSIONCURRENT, GetVersionCurrent, SetVersionCurrent, 0)
	IU_ATTRIBUTE_EDITOR_VERSION(CIuDatabase, IDS_ENGINE_PROP_VERSIONCURRENT, IDS_ENGINE_PPG_DATABASE, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuDatabase, IDS_ENGINE_PROP_GROUPNO, GetGroupNo, SetGroupNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuDatabase, IDS_ENGINE_PROP_GROUPNO, IDS_ENGINE_PPG_DATABASE, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuDatabase, IDS_ENGINE_PROP_GROUPCOUNT, GetGroupCount, SetGroupCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuDatabase, IDS_ENGINE_PROP_GROUPCOUNT, IDS_ENGINE_PPG_DATABASE, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuDatabase, IDS_ENGINE_PROP_STATES, GetStates, SetStates, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuDatabase, IDS_ENGINE_PROP_STATES, IDS_ENGINE_PPG_DATABASE, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

// If max is greater than the application, then this database won't even appear.
// Generally, this is a bad thing, we want the database to appear and then display
// an error message when the user attempts to access it.
const	CIuVersionNumber versionDatabaseMax(2000,1,6,2200);
// Database objects with less than this are also ignored. This gives us a way to
//	 sunset an old database
const	CIuVersionNumber versionDatabaseMin(1999,0,1,100);
// This is the "current" database version. If it is greater than the application, then
// the user will see the database but will receive an error message when accessing it
// and the application should deny the access (or else it will probably blow up).
const	CIuVersionNumber versionDatabaseCurrent(2000,1,6,2200);
//}}Implement

CIuDatabase::CIuDatabase()
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuDatabase::CIuDatabase(const CIuDatabase& rDatabase)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rDatabase;
}
																			  
CIuDatabase::~CIuDatabase()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuDatabase::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackDatabaseObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

bool CIuDatabase::CheckAccessCode(CWnd* pParent)
{
	// Check if cd-only database has been enabled for non-cd use
	CString sOptions = GetOptions();
	CIuOptions Options = sOptions;
	if (Options.Find(_T("accesscode")) < 0)
		return true;

	// If no meter, error out
	if (!HasMeter())
	{
		TRACE("WARNING: Can not set access code database without attaching a meter.\n");
		ASSERT(false);
		return true;
	}

	// Check if meter corrupt
	if (!CheckCorrupt(pParent))
		return false;

	// Check if already enabled.
	CIuMeter& Meter = GetMeter();
	if (Meter.GetValue(meterAccessCodeEnable, 0) != 0)
		return true;

	if (!CIuMeterEnableDlg::DoDialog(Meter, meterEnableAccessCode_SingleUser, pParent, true))
		return false;

	return true;
}

bool CIuDatabase::CheckAcknowledge(CWnd* pParent)
{
	if (!HasMeter())
		return true;
		
	// Check if meter corrupt
	if (!CheckCorrupt(pParent))
		return false;

	// Check if needs to display notification dialog.
	CIuMeter& Meter = GetMeter();
	if (!Meter.CheckAcknowledge(pParent))
		return false;
	return true;
}

bool CIuDatabase::CheckCdOnly(CWnd* pParent)
{
	// Check if cd-only database has been enabled for non-cd use
	CString sOptions = GetOptions();
	CIuOptions Options = sOptions;
	if (Options.Find(_T("cdonly")) < 0)
		return true;

	// If on a cd, allow it
	if (IsCdrom())
		return true;

	// If no meter, error out
	if (!HasMeter())
	{
		TRACE("WARNING: Can not set cd-only database without attaching a meter.\n");
		ASSERT(false);
		return true;
	}

	// Check if meter corrupt
	if (!CheckCorrupt(pParent))
		return false;

	// Check if already enabled.
	CIuMeter& Meter = GetMeter();
	if (Meter.GetValue(meterNetworkEnable, 0) != 0)
		return true;

	if (!CIuMeterEnableDlg::DoDialog(Meter, meterEnableNetworkAccess_SingleUser, pParent, true))
		return false;

	return true;
}

bool CIuDatabase::CheckCorrupt(CWnd* pParent)
{
	if (!HasMeter())
		return true;

	CIuMeter& Meter = GetMeter();
	if (!Meter.IsCorrupt())
		return true;

	if (!CIuMeterEnableDlg::DoDialog(Meter, meterEnableCorrupt, pParent, true))
		return false;

	return true;
}

bool CIuDatabase::CheckExpired(CWnd* pParent)
{
	if (!HasMeter())
		return true;
		
	// Check if meter corrupt
	if (!CheckCorrupt(pParent))
		return false;

	// Check if already enabled.
	CIuMeter& Meter = GetMeter();
	while (Meter.IsExpired())
	{
		if (!CIuMeterEnableDlg::DoDialog(Meter, meterEnableExpired, pParent, true))
			return false;
	}

	if (Meter.IsExpired())
		return false;
	return true;
}

bool CIuDatabase::CheckVersion(CIuVersionNumber version, bool fShowDlg, CWnd* pParent)
{
	if (GetVersionCurrent() > GetVersionCurrentStatic())
	{
		// OK, this database is not supported in this engine.
		if (fShowDlg)
			CIuVersionDlg::DoDialogDatabase(GetVersionCurrent(), GetVersionCurrentStatic(), CIuVersionNumber(), pParent);
		return false;
	}

	return GetDatabases().GetEngine().CheckVersion(GetFormat(), version, fShowDlg, pParent);
}

bool CIuDatabase::CheckWarning(CWnd* pParent)
{
	if (!HasMeter())
		return true;

	// Check if meter corrupt
	if (!CheckCorrupt(pParent))
		return false;

	// Check if already enabled.
	CIuMeter& Meter = GetMeter();
	
	if (!Meter.IsWarning())
		return true;

	if (!Meter.ShouldNotify())
		return true;

	CIuMeterWarningDlg::DoDialog(Meter, pParent);
	Meter.SetLastNotifyDate();
	return true;
}

void CIuDatabase::Clear()
{
	CIuDatabase_super::Clear();
	CIuDatabase::CommonConstruct();
}

void CIuDatabase::CommonConstruct()
{
	//{{Initialize
	if (!m_pIndexes)
	{
		m_pIndexes.Create();
		m_pIndexes->SetDatabase(this);
	}
	m_sCopyright = IU_COPYRIGHT_STRING IU_COMPANY_STRING;
	m_monikerMeterMoniker.Clear();
	m_sRelease = "";
	// Default to "PowerFinder" for backwards compatibility.
	m_sUserInterface = szFormatPf_2000;
	m_sApplication = "";
	m_sOptions = "";
	m_sFilename = "";
	m_sFormat = szFormatPf_2000;
	m_pObjectRepository = 0;
	m_monikerSplash.Clear();
	m_dtCreated = COleDateTime::GetCurrentTime();
	SetVersion(versionDatabaseMax);
	m_iGroupNo = 0;
	m_iGroupCount = 1;
	m_verVersionCurrent = CIuVersionNumber();
	m_asStates.RemoveAll();
	//}}Initialize
}

void CIuDatabase::Copy(const CIuObject& object)
{
	CIuDatabase_super::Copy(object);

	const CIuDatabase* pDatabase = dynamic_cast<const CIuDatabase*>(&object);
	if (pDatabase == 0 || pDatabase == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuDatabase)));
	
	*m_pIndexes = *pDatabase->m_pIndexes;
	m_monikerMeterMoniker = pDatabase->m_monikerMeterMoniker;
	m_sCopyright = pDatabase->m_sCopyright;
	m_sRelease = pDatabase->m_sRelease;
	m_sUserInterface = pDatabase->m_sUserInterface;
	m_sApplication = pDatabase->m_sApplication;
	m_sOptions = pDatabase->m_sOptions;
	m_sFilename = pDatabase->m_sFilename;
	m_monikerSplash = pDatabase->m_monikerSplash;
	m_dtCreated = pDatabase->m_dtCreated;
	m_sFormat = pDatabase->m_sFormat;
	m_iGroupCount = pDatabase->m_iGroupCount;
	m_iGroupNo = pDatabase->m_iGroupNo;
	m_verVersionCurrent = pDatabase->m_verVersionCurrent;
	m_asStates.Copy(pDatabase->m_asStates);
}

CIuDatabases& CIuDatabase::GetDatabases() const
{
	CIuDatabases* pParent = dynamic_cast<CIuDatabases*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

inline int CIuDatabase::GetGroupCount() const
{
	return max(1, m_iGroupCount);
}

inline int CIuDatabase::GetGroupNo() const
{
	return max(0, min(m_iGroupNo, GetGroupCount() - 1));
}

CIuIndexes& CIuDatabase::GetIndexes() const
{
	return m_pIndexes.Ref();
}

CIuObject* CIuDatabase::GetIndexes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pIndexes.Ptr()));
}

CIuMeter& CIuDatabase::GetMeter() const
{
	ASSERT(HasMeter());
	int iIndex = GetDatabases().GetEngine().GetMeters().Find(GetMeterMoniker());
	ASSERT(iIndex >= 0);
	return GetDatabases().GetEngine().GetMeters().Get(iIndex);
}

CIuSplashPtr CIuDatabase::GetSplashPtr() const
{
	if (!HasCollection() || !GetDatabases().HasEngine())
		return CIuSplashPtr();
	int iIndex = GetDatabases().GetEngine().GetSplashes().Find(GetSplash());
	if (iIndex < 0)
		return CIuSplashPtr();

	CIuSplashPtr pSplash = &GetDatabases().GetEngine().GetSplashes().Get(iIndex);
	return pSplash;
}

void CIuDatabase::GetStates(CStringArray& as) const
{
	as.Copy(m_asStates);
}

CString CIuDatabase::GetUserInterface() const
{
	return m_sUserInterface.IsEmpty() ? CString(szFormatPf_2000): m_sUserInterface;
}

CIuUserInterfacePtr CIuDatabase::GetUserInterfacePtr() const
{
	if (!HasCollection() || !GetDatabases().HasEngine())
		return CIuUserInterfacePtr();
	int iIndex = GetDatabases().GetEngine().GetUserInterfaces().Find(GetUserInterface());
	if (iIndex < 0)
		return CIuUserInterfacePtr();

	CIuUserInterfacePtr pUserInterface = &GetDatabases().GetEngine().GetUserInterfaces().Get(iIndex);
	return pUserInterface;
}

CIuVersionNumber CIuDatabase::GetVersionCurrentStatic()
{
	return versionDatabaseCurrent;
}

CIuVersionNumber CIuDatabase::GetVersionMax() const
{
	return versionDatabaseMax;
}

CIuVersionNumber CIuDatabase::GetVersionMaxStatic()
{
	return versionDatabaseMax;
}

CIuVersionNumber CIuDatabase::GetVersionMin() const
{
	return versionDatabaseMin;
}

CIuVersionNumber CIuDatabase::GetVersionMinStatic()
{
	return versionDatabaseMin;
}

bool CIuDatabase::HasMeter() const
{
	return GetDatabases().GetEngine().GetMeters().Find(GetMeterMoniker()) >= 0;
}

bool CIuDatabase::IsCdrom() const
{
	if (GetFilename().IsEmpty())
		return false;
	CIuSysInfo si;
	int nDiskType;
	CString sFileSysType;
	if (!si.GetDriveTypeInfo(GetFilename(), sFileSysType, nDiskType))
		return false;
	return nDiskType == DRIVE_CDROM;
}

CIuDatabase& CIuDatabase::operator=(const CIuDatabase& rDatabase)
{
	Copy(rDatabase);
	return *this;
}

void CIuDatabase::SetApplication(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sApplication = pcsz;
}

void CIuDatabase::SetCopyright(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCopyright = pcsz;
}

void CIuDatabase::SetCreated(const COleDateTime& dt)
{
	m_dtCreated = dt;
}

void CIuDatabase::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuDatabase::SetFormat(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFormat = pcsz;
}

void CIuDatabase::SetGroupCount(int iGroupCount)
{
	m_iGroupCount = iGroupCount;
}

void CIuDatabase::SetGroupNo(int iGroupNo)
{
	m_iGroupNo = iGroupNo;
}

void CIuDatabase::SetMeterMoniker(const CIuMoniker& moniker)
{
	m_monikerMeterMoniker = moniker;
}

void CIuDatabase::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuDatabase::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuDatabase::SetRelease(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sRelease = pcsz;
}

void CIuDatabase::SetSplash(const CIuMoniker& moniker)
{
	m_monikerSplash = moniker;
}

void CIuDatabase::SetStates(const CStringArray& as)
{
	m_asStates.Copy(as);
}

void CIuDatabase::SetUserInterface(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sUserInterface = pcsz;
}

void CIuDatabase::SetSpec(CIuCdromSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());

	SetTitle(Spec.GetTitle());
	SetDescription(Spec.GetDescription());
	SetVersion(versionDatabaseMax);
	SetVersionCurrent(versionDatabaseCurrent);
	SetRelease(Spec.GetRelease());
	if (Spec.HasUserInterface())
		SetUserInterface(Spec.GetUserInterface().GetName());
	if (Spec.HasSplash())
		SetSplash(Spec.GetSplash().GetMoniker());
	SetApplication(Spec.GetApplication());
	SetOptions(Spec.GetOptions());
	SetFormat(Spec.GetFormat());
	SetFilename(Spec.GetFilename());
	SetGroupNo(Spec.GetGroupNo());
	SetGroupCount(Spec.GetGroupCount());
	CStringArray asStates;
	Spec.GetStates(asStates);
	SetStates(asStates);
	if (Spec.GetMeterCount() >= 1)
	{
		CIuMeterSpec& MeterSpec = Spec.GetMeter(0);
		SetMeterMoniker(MeterSpec.GetMoniker());
	}
}

void CIuDatabase::SetVersionCurrent(CIuVersionNumber ver)
{
	m_verVersionCurrent = ver;
}

void CIuDatabase::ShowStates(CWnd* pParent)
{
	CStringArray asStates;
	GetStates(asStates);
	if (asStates.GetSize() <= 0)
		return ;

	CIuFillStatesDlg::Edit(asStates, pParent);
}
