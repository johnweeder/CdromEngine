#include "stdafx.h"
#include "engine.h"
#include "MeterEnableDlg.h"
#include "MeterDiagnosticDlg.h"
#include "Meter.h"
#include "Meters.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDM_METER_ADMIN			0x0110
#define IDM_METER_DIAGNOSTIC	0x0210


//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterEnableDlg, CIuMeterEnableDlg_super)
	//{{AFX_MSG_MAP(CIuMeterEnableDlg)
	ON_BN_CLICKED(IDC_ENGINE_ENABLE, OnEnable)
	ON_EN_CHANGE(IDC_ENGINE_RESPONSECODE, OnChange)
	ON_WM_SYSCOMMAND()
	ON_BN_CLICKED(IDC_ENGINE_WEBSITE, OnWebsite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterEnableDlg::CIuMeterEnableDlg(CWnd* pParent /*=NULL*/) : CIuMeterEnableDlg_super(CIuMeterEnableDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterEnableDlg)
	m_sUserCode = _T("");
	m_sResponse = _T("");
	m_sStatus = _T("This product does not support operation from a hard disk or network.");
	//}}AFX_DATA_INIT
	m_fCorrupt = false;
	m_pMeter = 0;
	m_fUpdated = false;
	m_iMaxAttempts = 10;
	m_fAutoEnable = true;
	m_iMode = meterEnableUnknown;
}

void CIuMeterEnableDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterEnableDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterEnableDlg)
	DDX_Control(pDX, IDC_ENGINE_WEBSITE, m_btnWebSite);
	DDX_Control(pDX, IDC_ENGINE_PHONE, m_editPhone);
	DDX_Control(pDX, IDC_ENGINE_USERCODE, m_editUserCode);
	DDX_Control(pDX, IDC_ENGINE_RESPONSECODE, m_editResponse);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_ENGINE_ENABLE, m_btnEnable);
	DDX_Text(pDX, IDC_ENGINE_USERCODE, m_sUserCode);
	DDX_Text(pDX, IDC_ENGINE_RESPONSECODE, m_sResponse);
	DDX_Text(pDX, IDC_ENGINE_STATUS, m_sStatus);
	//}}AFX_DATA_MAP
}

bool CIuMeterEnableDlg::DoDialog(CIuMeter& Meter, int iMode, CWnd* pParent, bool fAutoEnable)
{
	CIuMeterEnableDlg Dlg(pParent);
	Dlg.m_pMeter = &Meter;
	Dlg.m_fAutoEnable = fAutoEnable;
	ASSERT(
		iMode == meterEnableNetworkAccess_SingleUser || 
		iMode == meterEnableNetworkAccess_MultiUser || 
		iMode == meterEnableAccessCode_SingleUser || 
		iMode == meterEnableAccessCode_MultiUser || 
		iMode == meterEnableExpired || 
		iMode == meterEnableCorrupt);
	Dlg.m_iMode = iMode;
	if (Dlg.DoModal() != IDOK)
		return false;
	return Dlg.m_fUpdated;
}

void CIuMeterEnableDlg::OnChange()
{
	if (m_fUpdated) 
	{
		if (m_iMode == meterEnableNetworkAccess_MultiUser || m_iMode == meterEnableNetworkAccess_SingleUser)
		{
			m_sStatus = _T("This product now supports operation from a network or hard disk.");
		}
		else if (m_iMode == meterEnableAccessCode_MultiUser || m_iMode == meterEnableAccessCode_SingleUser)
		{
			m_sStatus = _T("This product is now enabled.");
		}
		else if (m_iMode == meterEnableExpired)
		{
			m_sStatus = _T("This product has expired, but a 30-day grace period has been granted.");
		}
		else if (m_iMode == meterEnableCorrupt)
		{
			m_sStatus = _T("The application has been reset.");
		}
		else
		{
			ASSERT(false);
		}
		UpdateData(false);
		m_btnEnable.EnableWindow(true);
		m_editResponse.EnableWindow(false);
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnCancel.EnableWindow(false);
		return ;		
	}

	UpdateData(true);
	m_editResponse.EnableWindow(true);
	m_btnEnable.EnableWindow(CIuQueryResponseSession::IsValid(m_sResponse));
}

void CIuMeterEnableDlg::OnEnable() 
{
	if (m_fUpdated)
	{
		OnOK();
		return ;
	}

	UpdateData();
	if (!CIuQueryResponseSession::IsValid(m_sResponse))
		return ;

	bool fValid = m_Session.Verify(m_sResponse, m_sUserCode);
	if (!fValid)
	{
		--m_iMaxAttempts;
	}
	else if (m_fCorrupt)
	{
		if (m_pMeter->IsCorrupt())
		{
			m_pMeter->Reset();
			m_sResponse.Empty();
			UpdateData(false);
			OnChange();

			if (!m_pMeter->IsCorrupt())
				AfxMessageBox(IDS_ENGINE_METER_RESET, MB_OK|MB_ICONEXCLAMATION);
			else
				AfxMessageBox(IDS_ENGINE_METER_RESET_FAILED, MB_OK|MB_ICONEXCLAMATION);
		}
		SetUserCode();
		if (m_iMode == meterEnableCorrupt)
		{
			m_fUpdated = true;
			OnOK();
		}
	}
	else
	{
		m_fUpdated = true;
		if (m_fAutoEnable)
		{
			if (m_iMode == meterEnableNetworkAccess_MultiUser || m_iMode == meterEnableNetworkAccess_SingleUser)
			{
				m_pMeter->SetValue(meterNetworkEnable, 1);
				m_btnEnable.SetWindowText(_T("&Close"));
				m_btnCancel.ShowWindow(SW_HIDE);
			}
			else if (m_iMode == meterEnableAccessCode_MultiUser || m_iMode == meterEnableAccessCode_SingleUser)
			{
				m_pMeter->SetValue(meterAccessCodeEnable, 1);
				m_btnEnable.SetWindowText(_T("&Close"));
				m_btnCancel.ShowWindow(SW_HIDE);
			}
			else if (m_iMode == meterEnableExpired)
			{
				// Add thirty days
				m_pMeter->SetExpireDate(30);
				m_btnEnable.SetWindowText(_T("&OK"));
				m_btnCancel.ShowWindow(SW_HIDE);
			}
			UpdateData(false);
			OnChange();
		}
		else
			OnOK();
	}
}

BOOL CIuMeterEnableDlg::OnInitDialog() 
{
	ASSERT(
		m_iMode == meterEnableNetworkAccess_SingleUser || 
		m_iMode == meterEnableNetworkAccess_MultiUser || 
		m_iMode == meterEnableAccessCode_SingleUser || 
		m_iMode == meterEnableAccessCode_MultiUser || 
		m_iMode == meterEnableCorrupt ||
		m_iMode == meterEnableExpired);

	CIuMeterEnableDlg_super::OnInitDialog();

	CMenu* pSysMenu = GetSystemMenu(false);

	// IDM_METER_ADMIN must be in the system command range.
	ASSERT((IDM_METER_ADMIN & 0xFFF0) == IDM_METER_ADMIN);
	ASSERT(IDM_METER_ADMIN < 0xF000);

	if (pSysMenu != NULL)
	{
		int iRights = m_pMeter->GetMeters().GetEngine().GetUserRights();
		if ((iRights & engineRightsMeterAdmin) != 0)
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_METER_ADMIN, _T("Administrator..."));
		}
	}

	ASSERT((IDM_METER_DIAGNOSTIC & 0xFFF0) == IDM_METER_DIAGNOSTIC);
	ASSERT(IDM_METER_DIAGNOSTIC < 0xF000);

	if (pSysMenu != NULL)
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_METER_DIAGNOSTIC, _T("Diagnostics..."));
	}

	CenterWindow();

	ASSERT(m_pMeter);
	CString sKey = m_pMeter->GetKey();
	m_Session.SetKey(sKey);
	SetUserCode();

	CFont* pFont = m_editUserCode.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);
	m_editResponse.SetFont(&m_fontLarge);
	m_editUserCode.SetFont(&m_fontLarge);

	// NOTE: This can be one or more phones
	const int cxEachStop = 130;
	m_editPhone.SetTabStops(cxEachStop);
	CString sPhone = m_pMeter->GetPhone();
	if (!sPhone.IsEmpty() && sPhone.GetAt(0) == '(')
	{
		CString sPhoneEx = _T("Phone: ") + sPhone;
		m_editPhone.SetWindowText(sPhoneEx);
	}
	else
		m_editPhone.SetWindowText(sPhone);

	m_btnWebSite.ShowWindow(m_pMeter->GetWebSite().IsEmpty() ? SW_HIDE: SW_SHOW);

	UpdateData(false);

	OnChange();

	return true;
}

void CIuMeterEnableDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_METER_ADMIN)
	{
		UpdateData();
		if (m_pMeter->GetMeters().AdministratorDlg(this, m_pMeter->GetID(), m_sUserCode, &m_sResponse))
			m_editResponse.SetWindowText(m_sResponse);
		SetUserCode();
	}
	else if ((nID & 0xFFF0) == IDM_METER_DIAGNOSTIC)
	{
		UpdateData();
		CString sLocation;
		switch (m_iMode)
		{
			case meterEnableNetworkAccess_SingleUser:
				sLocation = _T("Enable Single Network");
				break;
			case meterEnableNetworkAccess_MultiUser:
				sLocation = _T("Enable Multi Netword");
				break;
			case meterEnableAccessCode_SingleUser:
				sLocation = _T("Singe User Access");
				break;
			case meterEnableAccessCode_MultiUser:
				sLocation = _T("Multi User Access");
				break;
			case meterEnableExpired:
				sLocation = _T("Product Expired");
				break;
			case meterEnableCorrupt:
				sLocation = _T("Application Corrupt");
				break;
			default:
				sLocation = _T("Meter Enable Invalid");
				break;
		}
		if (m_fCorrupt)
			sLocation = _T("Meter Enable - Special"); // Don't say "corrupt", we don't want to clue in the hackers
		CIuMeterDiagnosticDlg::DoDialog(*m_pMeter, m_sUserCode, sLocation, this);
		SetUserCode();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CIuMeterEnableDlg::OnWebsite() 
{
 	ShellExecute(NULL, _T("open"), m_pMeter->GetWebSite(), NULL, NULL, SW_SHOWNORMAL);
}

void CIuMeterEnableDlg::SetUserCode()
{
	if (m_iMode == meterEnableNetworkAccess_SingleUser || m_iMode == meterEnableNetworkAccess_MultiUser)
	{
		SetWindowText("Enable Network Access...");
		m_sStatus = _T("This product does not support operation from a hard disk or network.");
		if (m_iMode == meterEnableNetworkAccess_SingleUser)
			m_sUserCode = m_Session.GetQuery(meterMagicNetworkEnable_SingleUser, true);
		else
			m_sUserCode = m_Session.GetQuery(meterMagicNetworkEnable_MultiUser, true);
	}
	else if (m_iMode == meterEnableAccessCode_SingleUser || m_iMode == meterEnableAccessCode_MultiUser)
	{
		SetWindowText("Enable Access...");
		m_sStatus = _T("This product must be enabled before it can be used.");
		if (m_iMode == meterEnableAccessCode_SingleUser)
			m_sUserCode = m_Session.GetQuery(meterMagicAccessCodeEnable_SingleUser, true);
		else
			m_sUserCode = m_Session.GetQuery(meterMagicAccessCodeEnable_MultiUser, true);
	}
	else if (m_iMode == meterEnableExpired)
	{
		SetWindowText("Product Expired...");
		m_sStatus = _T("This product has expired.\nPlease contact your representative for a new version.");

		m_sUserCode = m_Session.GetQuery(meterMagicExpireOverRide, true);
	}
	else if (m_iMode == meterEnableCorrupt)
	{
		SetWindowText("Product Corrupt...");
		m_sStatus = _T("The application has determined that it is in a corrupt state.\nPlease contact your representative for assistance.");

		m_sUserCode = m_Session.GetQuery(meterMagicMeterCorrupt, true);
	}

	// If meter is corrupt, generate a special code...
	m_fCorrupt = m_pMeter->IsCorrupt();
	if (m_fCorrupt)
	{
		m_sUserCode = m_Session.GetQuery(meterMagicMeterCorrupt, true);
	}

	UpdateData(FALSE);
}
