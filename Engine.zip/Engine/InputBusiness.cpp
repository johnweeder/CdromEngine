#include "StdAfx.h"
//{{Include
#include "InputBusiness.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Common\String.h"
#include "Data\DataFilename.h"
#include "Error\Error.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputBusiness, CIuInputBusiness_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputBusiness)

// Read size for cache.
#ifdef _DEBUG
const int iMaxCacheSize = 128 * 1024;
#else
const int iMaxCacheSize = 8 * 1024 * 1024;
#endif

// These are the field offsets for the various records
// They are in the order they appear within the file.
enum BusinessMaster
{
	masterBusinessName,				// 30
	masterLastName,					// 14
	masterFirstName,					// 11
	masterGender,						// 1
	masterTitle,						// 3
	masterTitleCode,					// 1
	masterAddress,						// 30
	masterCity,							// 16
	masterState,						// 2
	masterZipCode,						// 5
	masterZipFour,						// 4
	masterCountyCode,					// 3
	masterPopulationCode,			// 1
	masterAreaCode,					// 3
	masterPhoneNumber,				// 7
	masterFaxAreaCode,				// 3
	masterFaxPhoneNumber,			// 7
	masterAbiNumber,					// 9
	masterParent,						// 9
	masterSubsidiary,					// 9
	masterSiteNumber,					// 9
	masterPreferredFlag,				// 1
	masterAcronymFlag,				// 1
	masterEmployeeSizeCode,			// 1
	masterOutputVolumeCode,			// 1
	masterNumberEmployees,			// 5
	masterOutputVolume,				// 9
	masterBusinessStatusCode,		// 1
	masterIdentificationCode,		// 1
	masterCreditRatingCode,			// 1
	masterCompanyHoldingStatus,	// 1
	masterGovernmentFlag,			// 1
	masterMfgFlag,						// 1
	masterTrueNewAdd,					// 1
	masterSmaliBusinessFlag,		// 1
	masterBigBusinessFlag,			// 1
	masterGrowingBusinessFlag,		// 1
	masterCottageCode,				// 1
	masterYearCode,					// 1
	masterOfficeSizeCode,			// 1
	masterNewAddDate,					// 4
	masterYearFirstAppeared,		// 2
	masterDeliveryPointBarCode,	// 3
	masterCarrierRouteCode,			// 4
	masterTollFreeAreaCode,			// 3
	masterTollFreePhoneNumber,		// 7
	masterWebAddress,					// 40
	masterMsaCode,						// 4

	masterLongitude,					// 9
	masterLatitude,					// 9
	masterMatchType,					// 1
	masterAddChangeFlag,				// 1
	masterProductionDate,			// 8

	//----- Number of Fields -----
	masterMax
}; //  274

enum BusinessParsedAddress
{
	parsedStreetPreDirectional,	// 2
	parsedStreetName,					// 28
	parsedStreetSuffix,				// 5
	parsedStreetPostDirectional,	// 2
	parsedHouseNumber,				// 15
	parsedApartmentSuite,			// 20
	parsedAddress,						// 30

	//----- Number of Fields -----
	parsedMax
}; // 106

enum BusinessMailing
{
	mailingAddress,					// 30
	mailingCity,						// 16
	mailingState,						// 2
	mailingZipCode,					// 5
	mailingZipFour,					// 4
	mailingDeliveryPointBarCode,	// 3
	mailingCarrierRouteCode,		// 4

	//----- Number of Fields -----
	mailingMax
}; // 68

enum BusinessCorporate
{
	corporateEmployeeSizeCode,		// 1
	corporateOutputVolumeCode,		// 9
	corporateCorporateEmployees,	// 6
	corporateOutputVolume,			// 9
	corporateStockExchangeCode,	// 1
	corporateStockTickerSymbol,	// 6

	//----- Number of Fields -----
	corporateMax
}; // 36

enum BusinessSic
{
	sicProfessionalSicFlag,			// 1
	sicSicCode,							// 6
	sicYellowPageCode,				// 5
	sicPrimarySicDesiginator,		// 1
	sicFranchiseCodes,				// 1-6
	sicAdSizeCode,						// 2
	sicYearFirstAppeared,			// 2
	sicIndustrySpecificFirstByte,	// 1
	sicDateInDatabase,				// 4
	sicBankAssetCode,					// 1

	//----- Number of Fields -----
	sicMax
}; // 33


enum BusinessExecutive
{
	executiveLastName,				// 14
	executiveFirstName,				// 11
	executiveTitle,					// 3
	executiveTitleCode,				// 1
	executiveGender,					// 1

	//----- Number of Fields -----
	executiveMax
}; // 35
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTBUSINESS, CIuInputBusiness, CIuInputBusiness_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputBusiness, IDS_ENGINE_PPG_INPUTBUSINESS, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl sort_sic(const void *elem1, const void *elem2)
{
	CIuBuffer** ppBuffer1 = (CIuBuffer**)elem1;
	LPCTSTR apcszSic1[sicMax];
	int iFields1 = CIuInputBusiness::Delimit(**ppBuffer1, apcszSic1, sicMax);
	ASSERT(iFields1 == sicMax);

	CIuBuffer** ppBuffer2 = (CIuBuffer**)elem2;
	LPCTSTR apcszSic2[sicMax];
	int iFields2 = CIuInputBusiness::Delimit(**ppBuffer2, apcszSic2, sicMax);
	ASSERT(iFields2 == sicMax);

	// The primary SIC is always first (lower)
	LPCTSTR pcszPrimarySic1 = apcszSic1[sicPrimarySicDesiginator];
	LPCTSTR pcszPrimarySic2 = apcszSic2[sicPrimarySicDesiginator];
	if (*pcszPrimarySic1 != '\0' && *pcszPrimarySic2 == '\0')
		return -1;
	if (*pcszPrimarySic1 == '\0' && *pcszPrimarySic2 != '\0')
		return 1;

	// Lower years go first
	int iResult = _tcsicmp(apcszSic1[sicYearFirstAppeared], apcszSic2[sicYearFirstAppeared]);
	if (iResult != 0)
		return iResult;

	// Else by increasing SIC (note: duplicate SIC's not allowed!)
	// Except that 8888 SIC codes go to the very end
	LPCTSTR pcszSic1 = apcszSic1[sicSicCode];
	LPCTSTR pcszSic2 = apcszSic2[sicSicCode];

	bool f1Is8888 = _tcsncmp(pcszSic1, "8888", 4) == 0;
	bool f2Is8888 = _tcsncmp(pcszSic2, "8888", 4) == 0;
	if (f1Is8888 && !f2Is8888)
		return 1;
	else if (!f1Is8888 && f2Is8888)
		return -1;

	iResult = _tcsicmp(pcszSic1, pcszSic2);
	ASSERT(iResult != 0);
	return iResult;
}

CIuInputBusiness::CIuInputBusiness() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputBusiness::~CIuInputBusiness()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputBusiness::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputBusiness"));
	m_iNextRecord = 0;
	m_Length = 0;
	m_iCacheNext = 0;
	m_iCacheData = 0;
	//}}Initialize
}

bool CIuInputBusiness::CreateRecord()
{
	ClearFields();

	// Delimit the various detail records
	LPCTSTR apcszMaster[masterMax];
	int iMaster = Delimit(m_Master, apcszMaster, masterMax);
	if (iMaster != masterMax) 
	{
		// This happens when an invalid record appears (usually at the end of a file)
		GetOutput().OutputF("*** WARNING: Invalid input record found in business input file %s\n", LPCTSTR(GetInputFilename()));
		GetOutput().Fire();
		return false;
	}
	ASSERT(iMaster == masterMax);

	LPCTSTR apcszParsed[parsedMax];
	int iParsed = Delimit(m_Parsed, apcszParsed, parsedMax);
	if (iParsed != 0 && iParsed != parsedMax)
		Error(IU_E_INPUT_FAILURE, _T("Invalid parsed address detail on business record."));

	ASSERT(iParsed == 0 || iParsed == parsedMax);

	// Output the various fixed information fields
	LPCTSTR pcszName = apcszMaster[masterBusinessName];
	// Don't allow business names that end with a comma. It can screw up the
	// alternate record logic in PF which uses that format for see-also records.
	int iName = _tcslen(pcszName);
	if (iName && pcszName[iName-1] == ',')
	{
		CString sName(pcszName, iName-1);
		SetField(inputFieldName, sName);
	}
	else
		SetField(inputFieldName, pcszName);
	SetField(inputFieldGender, apcszMaster[masterGender]);

	MakeNameInitials(inputFieldContact, apcszMaster[masterLastName], apcszMaster[masterFirstName], 0, 0, 0, 0);

	MakeAddress(apcszParsed[parsedHouseNumber], apcszParsed[parsedStreetPreDirectional], apcszParsed[parsedStreetName], apcszParsed[parsedStreetSuffix], apcszParsed[parsedStreetPostDirectional], apcszParsed[parsedApartmentSuite], 0, 0);

	MakeState(apcszMaster[masterState]);
	SetField(inputFieldCity, apcszMaster[masterCity]);
	MakeZip(apcszMaster[masterZipCode], apcszMaster[masterZipFour], 0);

	MakePhone(inputFieldAcPhone, apcszMaster[masterAreaCode], apcszMaster[masterPhoneNumber]);
	MakePhone(inputFieldFaxAcPhone, apcszMaster[masterFaxAreaCode], apcszMaster[masterFaxPhoneNumber]);
	MakePhone(inputFieldTollFreeAcPhone, apcszMaster[masterTollFreeAreaCode], apcszMaster[masterTollFreePhoneNumber]);

	SetField(inputFieldLongitude, apcszMaster[masterLongitude]);
	SetField(inputFieldLatitude, apcszMaster[masterLatitude]);
	SetField(inputFieldMatchLevel, apcszMaster[masterMatchType]);
	SetField(inputFieldPubDate, apcszMaster[masterProductionDate]);
	SetField(inputFieldMsaCode, apcszMaster[masterMsaCode]);
	SetField(inputFieldCountyCode, apcszMaster[masterCountyCode]);
	SetField(inputFieldEmployeeSizeCode, apcszMaster[masterEmployeeSizeCode]);
	SetField(inputFieldSalesVolumeCode, apcszMaster[masterOutputVolumeCode]);

	m_sSicCode = "";
	m_sFranchiseCode = "";
	m_sAdSizeCode = "";
	m_sFirstYear = "";
	const int iMaxSics = 16;
	for (int iSic = 0; iSic < iMaxSics; ++iSic)
	{
		if (iSic < m_iSics)
		{
			CIuBuffer* pBuffer = m_aSic.GetAt(iSic);
			ASSERT(pBuffer);

			LPCTSTR apcszSic[sicMax];
			int iThisSic = Delimit(*pBuffer, apcszSic, sicMax);
			if (iThisSic != sicMax)
				Error(IU_E_INPUT_FAILURE, _T("Invalid sic detail on business record."));

			ASSERT(iThisSic == sicMax);

			LPCTSTR pcszSicCode = apcszSic[sicSicCode];
			if (*pcszSicCode == '\0')
				continue;
			if (!m_sSicCode.IsEmpty())
			{
				m_sSicCode			+= "\n";
				m_sFranchiseCode	+= "\n";
				m_sAdSizeCode		+= "\n";
				m_sFirstYear		+= "\n";
			}
			m_sSicCode			+= pcszSicCode;
			m_sFranchiseCode	+= apcszSic[sicFranchiseCodes];
			m_sAdSizeCode		+= apcszSic[sicAdSizeCode];
			m_sFirstYear		+= apcszSic[sicYearFirstAppeared];
		}
	}

	SetField(inputFieldSicCode, m_sSicCode);
	SetField(inputFieldFranchiseCode, m_sFranchiseCode);
	SetField(inputFieldAdSizeCode, m_sAdSizeCode);
	SetField(inputFieldFirstYear, m_sFirstYear);

	SetField(inputFieldBusResFlag, "B");

	return Output();
}

int CIuInputBusiness::Delimit(CIuBuffer& Buffer, LPCTSTR* apcsz, int iPtrs)
{
	ASSERT(iPtrs >= 0);
	ASSERT(apcsz);

	// Always make sure we end with a null
	const BYTE bNull = '\0';
	int iSize = Buffer.GetSize();
	if (iSize > 0 && Buffer[iSize - 1] != '\0')
	{
		Buffer.Append(&bNull, sizeof(bNull));
		iSize = Buffer.GetSize();
	}

	// Replace tabs with nulls and set up pointers to fields
	BYTE* pb = Buffer;
	for (int i = 0, j = 0; j < iSize; )
	{
		LPCTSTR pcsz = LPCTSTR(pb + j);

		for (; pb[j] != '\t' && pb[j] != '\0' && j < iSize; ++j)
			/* null */ ;

		if (j < iSize && pb[j] == '\t')
			pb[j] = '\0';

		if (j < iSize && pb[j] == '\0')
			++j;

		if (i < iPtrs)
		{
			apcsz[i] = _tcsskipws(pcsz);
			++i;
		}
		else
		{
			TRACE("WARNING: Extra fields in business input record.\n");
		}
	}

	// Mark any remaining fields as blank
	for (int iRemainder = i; iRemainder < iPtrs; ++iRemainder)
		apcsz[iRemainder] = _T("");
	
	return i;
}

void CIuInputBusiness::Free()
{
	// Delete all the SIC detail pointers
	int iSize = m_aSic.GetSize();
	for (int i = 0; i < iSize; ++i)
		delete m_aSic[i];

	m_aSic.RemoveAll();
}

CIuFilename CIuInputBusiness::GetFullInputFilename() const
{
	CIuFilename Filename = IuDataFilenameSearch(GetInputFilename(), ".dat");
	return Filename;
}

void CIuInputBusiness::OnClose()
{
	m_File.Close();

	Free();

	m_Cache.Destroy();
	m_Master.Destroy();
	m_Parsed.Destroy();
	m_Sic.Destroy();
	m_Count.Destroy();
	m_Skip.Destroy();
	m_aSic.RemoveAll();

	CIuInputBusiness_super::OnClose();
}

int CIuInputBusiness::OnGetRange()
{
	return -1;
}

bool CIuInputBusiness::OnMoveFirst()
{
	m_iNextRecord = 0;
	m_iCacheNext = 0;
	m_Cache.Empty();
	m_iCacheData = 0;
	return true;
}

bool CIuInputBusiness::OnMoveNext()
{
	if (!ReadRecord())
		return false;

	if (!CreateRecord())
		return false;

	++m_iNextRecord;
	return true;
}

bool CIuInputBusiness::OnOpen(CIuOpenSpec& OpenSpec)
{
	GetOutput().SetMessageF("Input from business data file '%s'", LPCTSTR(GetInputFilename()));

	// Get full filename
	CString sFile = GetFullInputFilename();

	// Open the file
	m_File.SetCacheSize(iMaxCacheSize);
	m_File.Open(sFile);

	// Get the file length
	m_Length = m_File.GetLength();

	// Set current record
	m_iNextRecord = 0;

	// Position to start 
	m_iCacheNext = 0;
	m_iCacheData = 0;
	m_Cache.Empty();

	return CIuInputBusiness_super::OnOpen(OpenSpec);
}

bool CIuInputBusiness::ReadCache()
{
	// Get size to read
	ASSERT(m_iCacheNext <= m_Length);
	CIuFilePosition Remaining = m_Length - m_iCacheNext;

	int iReadSize = (int)min(CIuFilePosition(iMaxCacheSize), Remaining);
	if (iReadSize <= 0)
		return false;

	// Do the read
	m_Cache.SetSize(iReadSize);

	m_File.Read(m_iCacheNext, m_Cache.GetPtr(), iReadSize);

	m_iCacheNext += iReadSize;
	m_iCacheData = 0;

	return true;
}

int CIuInputBusiness::ReadCount()
{
	if (!ReadLine(m_Count))
		return 0;

	return StringAsInt(LPCTSTR(m_Count.GetPtr()));
}

bool CIuInputBusiness::ReadLine(CIuBuffer& Buffer)
{
	// Start with an empty Buffer
	Buffer.Empty();

	// Keep processing until we get an entire line
	for (;;)
	{
		// Read a new Buffer if needed
		if (m_iCacheData >= m_Cache.GetSize())
		{
			if (!ReadCache())
				break;
		}

		// Try to find an end of line in the cache
		int iCacheSize = m_Cache.GetSize();
		BYTE* pb = m_Cache.GetPtr();
		bool fEol = false;
		for (int i = m_iCacheData; i < iCacheSize; ++i)
		{
			if (pb[i] == '\n')
			{
				++i;
				fEol = true;
				break;
			}
			if (!_istascii(pb[i]) || (!_istprint(pb[i]) && pb[i] != '\t'))
				pb[i] = ' ';
		}

		// Append to output
		int iAppend = i - m_iCacheData;
		if (fEol)
			--iAppend;
		if (iAppend > 0)
			Buffer.Append(pb + m_iCacheData, iAppend);
		m_iCacheData = i;
		if (fEol)
		{
			// Always valid... even if empty line
			// Make sure we get a null terminator....
			Buffer.Append((BYTE)0);
			return true;
		}
	}

	// No eol found, return true if record is not empty
	bool fValid = Buffer.GetSize() != 0;
	// Make sure we get a null terminator....
	Buffer.Append((BYTE)0);
	return fValid;
}

bool CIuInputBusiness::ReadRecord()
{
	m_iSics = 0;

	// Read the master record detail
	if (!ReadLine(m_Master))
	{
		// This would be a valid end of file condition
		return false;
	}

	// Read the parsed address data and keep the first record
	int iParsed = ReadCount();
	if (iParsed > 0)
	{
		if (!ReadLine(m_Parsed))
			Error(IU_E_INPUT_FAILURE, _T("Expected parsed address detail on business record (1)."));
		if (!ReadSkip(iParsed - 1))
			Error(IU_E_INPUT_FAILURE, _T("Expected parsed address detail on business record (2)."));
	}
	else
		m_Parsed.Empty();

	// Skip the mailing detail section
	ReadSkip();

	// Skip the corporate detail and keep the first record
	ReadSkip();

	// Read the SIC section
	if (!ReadSic())
		Error(IU_E_INPUT_FAILURE, _T("Expected sic detail on business record (1)."));

	// Skip the executive section
	ReadSkip();

	return true;
}

bool CIuInputBusiness::ReadSic()
{
	// Process _all_ of the SIC's
	// Later, we will decide which one to keep
	int iSics = ReadCount();
	m_iSics = 0;
	for (int iSic = 0; iSic < iSics; ++iSic)
	{
		// Read and delimit it
		if (!ReadLine(m_Sic))
			break;

		LPCTSTR apcszSic[sicMax];
		int iThisSics = Delimit(m_Sic, apcszSic, sicMax);
		ASSERT(iThisSics == sicMax);

		// Check if a record with an identical SIC is already in the list
		// If so, keep the record which:
		//		a) is a primary sic
		//		b) has been in the database the longest
		//		c) has the largest ad size
		bool fDisRegard = false;
		for (int iIndex = 0; iIndex < m_iSics; ++iIndex)
		{
			LPCTSTR apcszSic0[sicMax];
			CIuBuffer* pBuffer = m_aSic.GetAt(iIndex);
			int iSic0 = Delimit(*pBuffer, apcszSic0, sicMax);
			ASSERT(iSic0 == sicMax);

			if (_tcsicmp(apcszSic[sicSicCode], apcszSic0[sicSicCode]) != 0)
				continue;

			LPCTSTR pcszPrimarySic = apcszSic0[sicPrimarySicDesiginator];
			if (*pcszPrimarySic != '\0')
			{
				fDisRegard = true;
				break;
			}
			if (_tcsicmp(apcszSic[sicYearFirstAppeared], apcszSic0[sicYearFirstAppeared]) > 0)
			{
				fDisRegard = true;
				break;
			}
			if (_tcsicmp(apcszSic[sicAdSizeCode], apcszSic0[sicAdSizeCode]) > 0)
			{
				fDisRegard = true;
				break;
			}
			break;
		}

		if (fDisRegard)
			continue;

		// Add a new Buffer if needed
		ASSERT(iIndex >= 0 && iIndex <= m_iSics);
		if (iIndex >= m_aSic.GetSize())
			m_aSic.Add(new CIuBuffer);

		// Store SIC detail in Buffer
		ASSERT(iIndex >= 0 && iIndex < m_aSic.GetSize());
		*m_aSic.GetAt(iIndex) = m_Sic;

		// If new record, increment count
		ASSERT(iIndex <= m_iSics);
		if (iIndex == m_iSics)
			++m_iSics;
	}

	// Sort the SIC's. This will place the primary SIC at the top of the list.
	if (m_iSics > 1)
		qsort(m_aSic.GetData(), m_iSics, sizeof(CIuBuffer*), sort_sic);

	return true;
}

bool CIuInputBusiness::ReadSkip()
{
	// Skip an entire section
	int iSkip = ReadCount();
	return ReadSkip(iSkip);
}

bool CIuInputBusiness::ReadSkip(int iSkip)
{
	if (iSkip <= 0)
		return true;

	for (int i = 0; i < iSkip; ++i)
		if (!ReadLine(m_Skip))
			Error(IU_E_INPUT_FAILURE, _T("Expected detail record count on business record."));

	return true;
}

void CIuInputBusiness::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputBusiness_super::SetSpec(Spec);
}
