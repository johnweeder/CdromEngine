#ifndef _ENGINE_GEORAW_H_
#define _ENGINE_GEORAW_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENTCOLLECTION_H_
#	include "Engine\GeoRawElementCollection.h"
#endif	// _ENGINE_GEORAWELEMENTCOLLECTION_H_
#ifndef 	_ENGINE_GEORAWELEMENTMAP_H_
#	include "Engine\GeoRawElementMap.h"
#endif	// _ENGINE_GEORAWELEMENTMAP_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_GEOZIPCENTROID_H_
#	include "Engine\GeoZipCentroid.h"
#endif	// _ENGINE_GEOZIPCENTROID_H_
#ifndef 	_ENGINE_GEORAWINSTANCE_H_
#	include "Engine\GeoRawInstance.h"
#endif	// _ENGINE_GEORAWINSTANCE_H_
#ifndef 	_ENGINE_GEORAWMAP_H_
#	include "Engine\GeoRawMap.h"
#endif	// _ENGINE_GEORAWMAP_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRaw)
IU_DEFINE_OBJECT_PTR(CIuGeoRawElementCollection)
IU_DEFINE_OBJECT_PTR(CIuGeoRawMap)
class CIuGeoSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRaw, CIuObjectNamed }}
#define CIuGeoRaw_super CIuObjectNamed

class CIuGeoRaw : public CIuGeoRaw_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRaw)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRaw();
	virtual ~CIuGeoRaw();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoRawElementCollection& GetAreaCode() const;
	CIuGeoRawElementMap& GetAreaCodeMap() const;
	CIuGeoRawElementCollection& GetCity() const;
	CIuGeoRawElementMap& GetCityMap() const;
	CIuGeoRawElementCollection& GetCounty() const;
	CIuGeoRawElementMap& GetCountyMap() const;
	CIuGeoRawElementCollection& GetExchange() const;
	CIuGeoRawElementMap& GetExchangeMap() const;
	CString GetFilename() const;
	CIuFilename GetFullFilename() const;
	CIuGeoRawElementCollection& GetMsa() const;
	CIuGeoRawElementMap& GetMsaMap() const;
	CString GetOutput() const;
	CIuGeoRawElementCollection& GetState() const;
	CIuGeoRawElementMap& GetStateMap() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	CIuGeoRawElementCollection& GetZip() const;
	CIuGeoRawElementMap& GetZipMap() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(CIuGeoRawInstance& instance, CIuOutput& Output);
	virtual void Clear();
	void CreateMaps();
	void Delete(CIuOutput* pOutput = 0);
	void Empty();
	void Process(const CIuRecord& Record, CIuOutput& Output);
	void Read();
	void ReadZipCentroid(CIuOutput& Output);
	void Resolve(CIuResolveSpec& Spec);
	void SetFilename(LPCTSTR);
	void SetSpec(CIuGeoSpec& Spec);
	void Write() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionRead(const CIuPropertyCollection& collection, CIuOutput&);
	CIuObject* GetAreaCode_() const;
	CIuObject* GetCity_() const;
	CIuObject* GetCounty_() const;
	CIuObject* GetExchange_() const;
	CIuObject* GetMap_() const;
	CIuObject* GetMsa_() const;
	CIuObject* GetState_() const;
	CIuObject* GetZip_() const;
private:
	void CommonConstruct();
	void InitHashTables();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The name of the raw data file
	CString m_sFilename;
	// Record def, field mapping and current record instance
	mutable CIuGeoRawMap m_Map;
	CIuGeoRawInstance m_Instance;
	// The collections containing the raw geography information
	mutable CIuGeoRawElementCollection m_Zip;
	mutable CIuGeoRawElementCollection m_AreaCode;
	mutable CIuGeoRawElementCollection m_City;
	mutable CIuGeoRawElementCollection m_County;
	mutable CIuGeoRawElementCollection m_Exchange;
	mutable CIuGeoRawElementCollection m_Msa;
	mutable CIuGeoRawElementCollection m_State;
	// An object used to provide a performance efficient mapping
	// of a collection at compressions time
	mutable CIuGeoRawElementMap m_ZipMap;
	mutable CIuGeoRawElementMap m_AreaCodeMap;
	mutable CIuGeoRawElementMap m_CityMap;
	mutable CIuGeoRawElementMap m_ExchangeMap;
	mutable CIuGeoRawElementMap m_MsaMap;
	mutable CIuGeoRawElementMap m_CountyMap;
	mutable CIuGeoRawElementMap m_StateMap;
	// Information from the zip5 centroid file
	CMap<int, int, CIuGeoZipCentroid, const CIuGeoZipCentroid&> m_mapCentroid;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetAreaCode() const
{
	return m_AreaCode;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetAreaCodeMap() const
{
	return m_AreaCodeMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetCity() const
{
	return m_City;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetCityMap() const
{
	return m_CityMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetCounty() const
{
	return m_County;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetCountyMap() const
{
	return m_CountyMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetExchange() const
{
	return m_Exchange;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetExchangeMap() const
{
	return m_ExchangeMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetMsa() const
{
	return m_Msa;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetMsaMap() const
{
	return m_MsaMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetState() const
{
	return m_State;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetStateMap() const
{
	return m_StateMap;
}

inline CIuGeoRawElementCollection& CIuGeoRaw::GetZip() const
{
	return m_Zip;
}

inline CIuGeoRawElementMap& CIuGeoRaw::GetZipMap() const
{
	return m_ZipMap;
}

#endif // _ENGINE_GEORAW_H_
