#include "StdAfx.h"
//{{Include
#include "OpenSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuOpenSpec::CIuOpenSpec() 
{
	CommonConstruct();
}

CIuOpenSpec::CIuOpenSpec(CIuOutput* pOutput, CIuObjectRepository* pObjectRepository, const CIuOptions* pOptions)
{
	CommonConstruct();
	m_pOutput = pOutput;
	m_pObjectRepository = pObjectRepository;
	m_pOptions = pOptions;
}

CIuOpenSpec::CIuOpenSpec(const CIuOpenSpec& rOpenSpec)
{
	CommonConstruct();
	*this = rOpenSpec;
}

CIuOpenSpec::~CIuOpenSpec()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuOpenSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pOutput = 0;
	m_pObjectRepository = 0;
	m_pOptions = 0;
	//}}Initialize
}

CIuOpenSpec& CIuOpenSpec::operator=(const CIuOpenSpec& rOpenSpec)
{
	m_pOutput = rOpenSpec.m_pOutput;
	m_pObjectRepository = rOpenSpec.m_pObjectRepository;
	m_pOptions = rOpenSpec.m_pOptions;
	return *this;
}
