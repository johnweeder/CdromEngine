#ifndef _ENGINE_REGEXCOMPARE_H_
#define _ENGINE_REGEXCOMPARE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
#ifndef 	_ENGINE_REGEX_H_
#	include "Engine\RegEx.h"
#endif	// _ENGINE_REGEX_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegExCompare }}
// Low overhead comparator object
//	Note on evaluation:
//		1 ) Terms (separated by comma's) are evaluated left to right.
//		2 ) If a non-negated term is matched, the expression immediately returns true.
//		3 ) If a negated term is matched, the expression immediately returns false.
//		4 ) No term was matched, so...
//		4a) If all terms were negated, then the expression is true.
//		4b) If one or more terms were non-negated, then the expression is false.
// Comparison is _not_ case sensitive.
// The result returned depends on the pattern. If the pattern contained a single
// term (not phonetic or negated), then the result will be relative (GT/EQ/LT). 
// Phonetic and complex regEx matches are only defined in the yes/no sense of matching.
// The result is not well defined for phonetic operations and regular expressions.
const int regExGT				= 2;
const int regExExact			= 0;
const int regExLT				= -2;

// If the expression contained multiple terms, or if the terms contained
// complicated regEx terms, the you will get a simple yes/no match.
// The 'regExPartial' indicates a match made based on a terminating wildcard.
//		AB* is a partial match to ABC
//		ABC* is an exact match to ABC
// NOTE: regExYes and regExExact have the same value and implie the same
//			thing.
// It can be assumed that regExYes || regExPartial implies a match.
const int regExYes			= 0;
const int regExPartial		= -1;
const int regExNo				= 1;

// This should not happen. It indicates a failure
// in the matching logic.
const int regExFailed		= 99;

inline bool REGEX_GT(int iResult)
{
	return iResult == regExGT;	
}
inline bool REGEX_GE(int iResult)
{
	return iResult == regExGT || iResult == regExExact || iResult == regExPartial;
}
inline bool REGEX_EQ(int iResult)
{
	return iResult == regExExact || iResult == regExPartial;
}
inline bool REGEX_LE(int iResult)
{
	return iResult == regExLT || iResult == regExExact || iResult == regExPartial;
}
inline bool REGEX_LT(int iResult)
{
	return iResult == regExLT;
}

class IU_CLASS_EXPORT CIuRegExCompare 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegExCompare();
	CIuRegExCompare(const CIuRegEx& RegEx);
	CIuRegExCompare(const CIuRegEx& RegEx, int iTerm);
	~CIuRegExCompare();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	int Compare(LPCTSTR) const;
	void Create(const CIuRegEx& RegEx);
	void Create(const CIuRegEx& RegEx, int iTerm);
	void Dump() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void Append(BYTE b);
	void Append(LPCTSTR pcsz, int iFlags);
	void Append(const CIuRegEx& RegEx, int iTerm);
	int CompareTerm(const BYTE* pbValue, const BYTE* pbPattern) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Parsed version of pattern. Each byte in the buffer represents a token
	// to be matched.
	CIuBuffer m_Tokens;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_REGEXCOMPARE_H_
