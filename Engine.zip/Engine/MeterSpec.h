#ifndef _ENGINE_METERSPEC_H_
#define _ENGINE_METERSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_GUID_H_
#	include "Interop\Guid.h"
#endif	// _INTEROP_GUID_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuMeterSpec)
class CIuCdromSpec;
struct CIuMeterSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterSpec, CIuObjectNamed }}
#define CIuMeterSpec_super CIuObjectNamed

class CIuMeterSpec : public CIuMeterSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuMeterSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterSpec();
	virtual ~CIuMeterSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool AllowUpdate() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	int GetExpireDays() const;
	CString GetFilename() const;
	int GetFlags() const;
	virtual CIuGuid GetGuid1() const;
	virtual CIuGuid GetGuid2() const;
	int GetInitialCount() const;
	int GetInitialCountUpgrade() const;
	int GetInitialRev() const;
	CString GetKey() const;
	int GetMaxOutput() const;
	int GetMeterNo() const;
	CString GetPhone() const;
	CIuMoniker GetPrevious() const;
	COleDateTime GetReleaseDate() const;
	CString GetSpecialAccess() const;
	CString GetTitle() const;
	int GetUpgradeCount() const;
	int GetUpgradeLevel() const;
	int GetWarningDays() const;
	CString GetWarningText() const;
	CString GetWebSite() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iMeterSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszMeter);
	void FromNo(CIuCdromSpec* pCdrom, int iMeterNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuMeterSpecDft* pMeterSpec);
	void SetAllowUpdate(bool);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetExpireDays(int);
	void SetFilename(LPCTSTR);
	void SetFlags(int iFlags);
	void SetGuid1(const CIuGuid& guid);
	void SetGuid2(const CIuGuid& guid);
	void SetInitialCount(int);
	void SetInitialCountUpgrade(int iInitialCountUpgrade);
	void SetInitialRev(int iRev);
	void SetKey(LPCTSTR);
	void SetMaxOutput(int);
	void SetMeterNo(int);
	void SetPhone(LPCTSTR);
	void SetPrevious(const CIuMoniker&);
	void SetReleaseDate(const COleDateTime&);
	void SetSpecialAccess(LPCTSTR);
	void SetTitle(LPCTSTR);
	void SetUpgradeCount(int iUpgradeCount);
	void SetUpgradeLevel(int iUpgradeLevel);
	void SetWarningDays(int);
	void SetWarningText(LPCTSTR);
	void SetWebSite(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	CIuGuid m_guidGuid1;
	CIuGuid m_guidGuid2;
	bool m_fAllowUpdate;
	int m_iInitialCount;
	int m_iExpireDays;
	int m_iMaxOutput;
	CString m_sPhone;
	CString m_sWebSite;
	CString m_sKey;
	int m_iMeterNo;
	CString m_sTitle;
	int m_iWarningDays;
	CString m_sFilename;
	COleDateTime m_dtReleaseDate;
	CString m_sWarningText;
	int m_iFlags;
	int m_iInitialRev;
	CString m_sSpecialAccess;
	int m_iUpgradeLevel;
	int m_iUpgradeCount;
	CIuMoniker m_monikerPrevious;
	int m_iInitialCountUpgrade;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuMeterSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline int CIuMeterSpec::GetExpireDays() const
{
	return m_iExpireDays;
}

inline CString CIuMeterSpec::GetFilename() const
{
	return m_sFilename;
}

inline int CIuMeterSpec::GetFlags() const
{
	return m_iFlags;
}

inline CIuGuid CIuMeterSpec::GetGuid1() const
{
	return m_guidGuid1;
}

inline CIuGuid CIuMeterSpec::GetGuid2() const
{
	return m_guidGuid2;
}

inline int CIuMeterSpec::GetInitialCount() const
{
	return m_iInitialCount;
}

inline int CIuMeterSpec::GetInitialCountUpgrade() const
{
	return m_iInitialCountUpgrade;
}

inline int CIuMeterSpec::GetInitialRev() const
{
	return m_iInitialRev;
}

inline CString CIuMeterSpec::GetKey() const
{
	return m_sKey;
}

inline int CIuMeterSpec::GetMaxOutput() const
{
	return m_iMaxOutput;
}

inline int CIuMeterSpec::GetMeterNo() const
{
	return m_iMeterNo;
}

inline CString CIuMeterSpec::GetPhone() const
{
	return m_sPhone;
}

inline CIuMoniker CIuMeterSpec::GetPrevious() const
{
	return m_monikerPrevious;
}

inline COleDateTime CIuMeterSpec::GetReleaseDate() const
{
	return m_dtReleaseDate;
}

inline CString CIuMeterSpec::GetSpecialAccess() const
{
	return m_sSpecialAccess;
}

inline CString CIuMeterSpec::GetTitle() const
{
	return m_sTitle;
}

inline int CIuMeterSpec::GetUpgradeCount() const
{
	return m_iUpgradeCount;
}

inline int CIuMeterSpec::GetUpgradeLevel() const
{
	return m_iUpgradeLevel;
}

inline int CIuMeterSpec::GetWarningDays() const
{
	return m_iWarningDays;
}

inline CString CIuMeterSpec::GetWarningText() const
{
	return m_sWarningText;
}

inline CString CIuMeterSpec::GetWebSite() const
{
	return m_sWebSite;
}

inline bool CIuMeterSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

inline bool CIuMeterSpec::AllowUpdate() const
{
	return m_fAllowUpdate;
}

#endif // _ENGINE_METERSPEC_H_
