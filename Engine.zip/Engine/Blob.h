#ifndef _ENGINE_BLOB_H_
#define _ENGINE_BLOB_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBlob)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
// Blob Types
enum CIuBlobNo
{
	blobNone = 0,

	blob88mdLicense_2001,
	blob104mLicense_2001,
	blobBmlLicense_2000,
	blobOamLicense_V1,
	blobPbLicense_2001,
	blobPbmLicense_V1,
	blobPfLicense_2001,
	blobPgLicense_2000,
	blobPuLicense_2001,
	blobRbocLicense_2000,
	blobSampleLicense,
	blobSluLicense_2000,
	blobYpuLicense_2001,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBlob, CIuCollectable }}
#define CIuBlob_super CIuCollectable

class IU_CLASS_EXPORT CIuBlob : public CIuBlob_super
{
//{{Declare
	DECLARE_SERIAL(CIuBlob)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBlob();
	virtual ~CIuBlob();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBlobNo() const;
	CString GetFilename() const;
	CString GetFullFilename() const;
	CIuObjectRepository& GetObjectRepository() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void SetBlobNo(int);
	void SetFilename(LPCTSTR);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuBlobSpec& Spec);
	bool ViewAsText(LPCTSTR pcszTitle = 0, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sFilename;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	int m_iBlobNo;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBlob::GetBlobNo() const
{
	return m_iBlobNo;
}
inline CIuObjectRepository& CIuBlob::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline bool CIuBlob::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_BLOB_H_
