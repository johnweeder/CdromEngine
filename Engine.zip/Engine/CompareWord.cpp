#include "StdAfx.h"
//{{Include
#include "CompareWord.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuCompareWord::CIuCompareWord() 
{
	CommonConstruct();
}

CIuCompareWord::CIuCompareWord(const CIuCompareWord& rCompareWord)
{
	CommonConstruct();
	*this = rCompareWord;
}

CIuCompareWord::~CIuCompareWord()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCompareWord::Compare(LPCTSTR pcszValue) const
{
	ASSERT(AfxIsValidString(pcszValue));
	if (m_iWords == 0)
		return true;

	// Set all the flags to false
	memset(m_afMatched, 0, m_iWords * sizeof(m_afMatched[0]));

	while (*pcszValue)
	{
		// Pick the next word out of the value
		pcszValue = _tcsskipws(pcszValue);
		if (*pcszValue == '\0')
			break;

		LPCTSTR pcszWord = pcszValue;
		while (*pcszValue && !_istspace(*pcszValue))
			++pcszValue;

		int iWord = pcszValue - pcszWord;

		// Match it against the pattern
		for (int i = 0; i < m_iWords; ++i)
		{
			// If this part of the pattern already matched, then try next
			if (m_afMatched[i])
				continue;
			// If word is smaller than pattern, try next
			if (iWord < m_aiLength[i])
				continue;
			// Compare
			int iResult = memicmp(m_apcsz[i], pcszWord, m_aiLength[i]);
			if (iResult != 0)
				continue;
			// If partial match, make sure we are wildcarded
			if (iWord != m_aiLength[i] && !m_afWildcarded[i])
				continue;
			// Good match to component
			m_afMatched[i] = true;
			break;
		}
	}

	// Check that we matched all components
	for (int i = 0; i < m_iWords; ++i)
		if (!m_afMatched[i])
			return false;

	return true;
}

void CIuCompareWord::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sExpression = "";
	m_iWords = 0;
	m_Buffer.Empty();
	//}}Initialize
}

CIuCompareWord& CIuCompareWord::operator=(const CIuCompareWord& rCompareWord)
{
	if (this == &rCompareWord)
		return *this;
	SetExpression(rCompareWord.m_sExpression);
	return *this;
}

void CIuCompareWord::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;

	// Similar to LIKE comparator. Initial {xxxx} options can be specified.
	// {*} wildcards all words.
	bool fAlwaysWildcarded = false;
	if (*pcsz == '{')
	{
		++pcsz;
		for (;*pcsz && *pcsz != '}'; ++pcsz)
		{
			switch (*pcsz)
			{
				case '*':
					fAlwaysWildcarded = true;
					break;
			}
		}
		if (*pcsz == '}')
			++pcsz;
	}

	m_iWords = 0;
	m_Buffer.Empty();

	while (*pcsz && m_iWords < MaxCompareWords)
	{
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == '\0')
			break;

		CString sWord;
		for (; *pcsz && !_istspace(*pcsz); ++pcsz)
			sWord += *pcsz;

		int iLength = sWord.GetLength();
		bool fWildcard = iLength > 0 && sWord[iLength - 1] == '*';
		if (fWildcard)
			sWord = sWord.Left(iLength - 1);

		m_Buffer.AppendString(sWord);
		m_afWildcarded[m_iWords] = fWildcard || fAlwaysWildcarded;
		++m_iWords;
	}

	for (int iWord = 0; iWord < m_iWords; ++iWord)
	{
		m_apcsz[iWord] = m_Buffer.GetString(iWord);
		ASSERT(AfxIsValidString(m_apcsz[iWord]));
		m_aiLength[iWord] = _tcslen(m_apcsz[iWord]);
	}
}


