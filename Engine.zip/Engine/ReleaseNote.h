#ifndef _ENGINE_RELEASENOTE_H_
#define _ENGINE_RELEASENOTE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReleaseNote)
class CIuReleaseNotes;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Release Note Types
enum CIuReleaseNoteNo
{
	releaseNoteAll= -1,

	releaseNoteNone = 0,

	releaseNoteFirst,
		releaseNote104m_2001 = releaseNoteFirst,
		releaseNote88md_2001,
		releaseNoteAc_V1,
		releaseNoteBml_2000,
		releaseNoteConsole,
		releaseNoteCi_V1,
		releaseNoteMeterAdmin,
		releaseNoteNetAdmin,
		releaseNoteOam_V1,
		releaseNotePb_2001,
		releaseNotePbm_V1,
		releaseNotePf_2001,
		releaseNotePg_2000,
		releaseNotePowerCheck,
		releaseNotePu_2001,
		releaseNoteRboc_2000,
		releaseNoteRp_2001,
		releaseNoteSample,
		releaseNoteSlu_2000,
		releaseNoteYpu_2001,
	releaseNoteLast,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReleaseNote, CIuCollectable }}
#define CIuReleaseNote_super CIuCollectable

class IU_CLASS_EXPORT CIuReleaseNote : public CIuReleaseNote_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuReleaseNote)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReleaseNote();           // protected constructor used by dynamic creation
	virtual ~CIuReleaseNote();
	CIuReleaseNote(const CIuReleaseNote&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetNotes() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuVersionNumber GetReleaseCurrent() const;
	CIuVersionNumber GetReleaseMin() const;
	CIuReleaseNotes& GetReleaseNotes() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool HasReleaseNotes() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	bool CheckVersion(CIuVersionNumber version, bool fShowDlg = true, CWnd* pParent = 0);
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void SetNotes(LPCTSTR pcsz);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetReleaseCurrent(CIuVersionNumber);
	void SetReleaseMin(CIuVersionNumber);
	void SetSpec(CIuReleaseNoteSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuReleaseNote& operator=(const CIuReleaseNote&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionCheckVersion(const CIuPropertyCollection& collection, CIuOutput&);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sNotes;
	CIuObjectRepository* m_pObjectRepository;
	CIuVersionNumber m_verReleaseMin;
	CIuVersionNumber m_verReleaseCurrent;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuReleaseNote::GetNotes() const
{
	return m_sNotes;
}

inline CIuObjectRepository& CIuReleaseNote::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuVersionNumber CIuReleaseNote::GetReleaseCurrent() const
{
	return m_verReleaseCurrent;
}

inline CIuVersionNumber CIuReleaseNote::GetReleaseMin() const
{
	return m_verReleaseMin;
}

inline bool CIuReleaseNote::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuReleaseNote::HasReleaseNotes() const
{
	return HasCollection();
}

#endif // _ENGINE_RELEASENOTE_H_
