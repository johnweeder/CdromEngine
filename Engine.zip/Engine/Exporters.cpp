#include "stdafx.h" 
//{{Include
#include "engine.h"
#include "Exporters.h"
#include "resource.h"
#include "Exporter.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExporters, CIuExporters_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExporters)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTERS, CIuExporters, CIuExporters_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuExporters, IDS_ENGINE_PPG_EXPORTERS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuExporters, IDS_ENGINE_PPG_EXPORTERS, 10, editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuExporters::CIuExporters()
{
#ifdef _DEBUG
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
#endif
	CommonConstruct();
}

CIuExporters::~CIuExporters()
{
#ifdef _DEBUG
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
#endif
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExporters::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

CIuEngine& CIuExporters::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

void CIuExporters::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuExporterPtr pExporter = dynamic_cast<CIuExporter*>(pCollectable.Ptr());
	GetEngine().QueryObject(collectionExporters, Descriptor, *pExporter);
}

CIuCollectablePtr CIuExporters::OnNew(CWnd*) const
{
	CIuExporterPtr pExporter;
	pExporter.Create();
	return CIuObjectPtr(pExporter);
}

void CIuExporters::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}
