#ifndef _ENGINE_ADDRESSSTREETNAMES_H_
#define _ENGINE_ADDRESSSTREETNAMES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ELEMENTCOLLECTION_H_
#	include "Engine\ElementCollection.h"
#endif	// _ENGINE_ELEMENTCOLLECTION_H_
#ifndef 	_COMMON_STRINGBUFFER_H_
#	include "Common\StringBuffer.h"
#endif	// _COMMON_STRINGBUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddressStreetNames)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// A helper class used to perform preprocessing on the streets
#pragma pack(1)
struct CIuAddressStreetName
{
public:
	LPCTSTR m_pcszStreetName;
	LPCTSTR m_pcszSuffix;
	LPCTSTR m_pcszPreDir;
	LPCTSTR m_pcszPostDir;
	int m_iCount;
};
#pragma pack()

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddressStreetNames, CIuElementCollection }}
#define CIuAddressStreetNames_super CIuElementCollection

class CIuAddressStreetNames : public CIuAddressStreetNames_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddressStreetNames)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddressStreetNames();
	virtual ~CIuAddressStreetNames();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddressStreetName* GetSorted(int iWhich) const;
	int GetSortedCount() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	CIuElement* Add(LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir);
	void Empty();
	void Sort();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Temporary string used during add
	// Kept here so it doesn't keep re-allocating
	CString m_sAdd;
	// Array for sorted elements
	// We keep the data array fixed in memory cause it is larger
	CArray<CIuAddressStreetName, CIuAddressStreetName> m_ArrayData;
	// We work with the sort array of pointers which is 1/5 the size
	CArray<CIuAddressStreetName*, CIuAddressStreetName*> m_pArraySorted;
	// A heap for the strings we are sorting
	CIuStringHeap m_HeapData;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_ADDRESSSTREETNAMES_H_
