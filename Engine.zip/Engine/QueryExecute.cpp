#include "StdAfx.h"
//{{Include
#include "QueryExecute.h"
#include "Engine.h"
#include "Query.h"
#include "SourceProvider.h"
#include "SourceBuffer.h"
#include "SourceSetList.h"
#include "SetList.h"
#include "SetLists.h"
#include "Expression.h"
#include "Common\Options.h"
#include "Common\String.h"
#include "Common\BigBuffer.h"
#include "Error\Error.h"
#include "resource.h"
#include "Counts.h"
#include "Databases.h"
#include "Meters.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

// Enable this to dump extended trace information
#if 0
#define QUERYTRACE	TRACE
#else
inline void AFX_CDECL QueryTrace(LPCTSTR, ...) { }
#define QUERYTRACE	1 ? (void)0 : ::QueryTrace
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuQueryExecute, CIuQueryExecute_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuQueryExecute)
//}}Implement

static int __cdecl SortByKey(const void *elem1, const void *elem2)
{
	const BYTE* pb1 = *(const BYTE**)elem1;
	pb1 += sizeof(UINT64);
	int cb1 = *(const int*)pb1;
	pb1 += sizeof(int);

	const BYTE* pb2 = *(const BYTE**)elem2;
	pb2 += sizeof(UINT64);
	int cb2 = *(const int*)pb2;
	pb2 += sizeof(int);

	int cb = min(cb1, cb2);
	if (cb > 0)
	{
		int iResult = memicmp(pb1, pb2, cb);
		if (iResult != 0)
			return iResult;
	}
	if (cb1 > cb2)
		return 1;
	else if (cb1 < cb2)
		return -1;
	return 0;
}

CIuQueryExecute::CIuQueryExecute() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuQueryExecute::CIuQueryExecute(CIuQuery& Query)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	SetQuery(Query);
}

CIuQueryExecute::~CIuQueryExecute()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuQueryExecute::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pQuery = 0;
	m_fSuccess = false;
	m_sExpression = "";
	m_iMode = queryModeNone;
	m_sResult = "Result";
	//}}Initialize
}

bool CIuQueryExecute::CreateFilter()
{
	if (!GetOutput().Fire(IU_EVENT_OPERATION_CONTINUE))
		return false;

	// First, find all those criteria which are not supported via an index
	CStringArray asFilter;
	for (int iSource = 0; iSource < m_aSources.GetSize(); ++iSource)
	{
		CIuSourcePtr pSource = m_aSources[iSource];
		ASSERT(pSource.NotNull());
		pSource->GetSetListFilter(m_Criteria, asFilter);
	}

	// Dedup the critiera
	CIuSortedStringArray asCriteria;
	asCriteria.SetNoCase();
	asCriteria.SetDedup();
	for (int i = 0; i < asFilter.GetSize(); ++i)
	{
		CString sFilter = asFilter[i];
		asCriteria.Add(sFilter);
	}

	// Now, go back and extend the FILTER
	for (int iCriteria = 0; iCriteria < asCriteria.GetSize(); ++iCriteria)
	{
		CString sCriteria = asCriteria[iCriteria];
		if (!m_sFilter.IsEmpty())
			m_sFilter += _T(" AND ");
		m_sFilter += _T("(");
		m_sFilter += sCriteria;
		m_sFilter += _T(")");
	}

	return true;
}

bool CIuQueryExecute::CreateSetList()
{
	// First, get the raw set list items
	CIuSetLists SetListsOr(combineOr);
	for (int iSource = 0; iSource < m_aSources.GetSize(); ++iSource)
	{
		CIuSourcePtr pSource = m_aSources[iSource];
		ASSERT(pSource.NotNull());
		CIuSetListPtr pSetList = pSource->GetSetList(m_Criteria, &GetOutput(), sourceModeDefault);
		SetListsOr.Add(pSetList);
	}
	m_pSetList = SetListsOr.Combine(&GetOutput());

	// Next, check for any tagging
	int iTagged = m_Select.GetTagged();
	if (iTagged != taggedAny)
	{
		CIuSetLists SetListsOr(combineOr);
		for (int iSource = 0; iSource < m_asQueries.GetSize(); ++iSource)
		{
			CIuSourcePtr pSource = m_aSources[iSource];
			ASSERT(pSource.NotNull());
			CIuSetListPtr pSetList = pSource->GetSetListTagged();
			SetListsOr.Add(pSetList);
		}

		CIuSetListPtr pSetList = SetListsOr.Combine(&GetOutput());

		CIuSetLists SetListsAnd(combineAnd);
		SetListsAnd.Add(m_pSetList);
		SetListsAnd.Add(pSetList);

		m_pSetList = SetListsAnd.Combine(&GetOutput());
	}

	return true;
}

bool CIuQueryExecute::CreateSources()
{
	int iQueries = m_asQueries.GetSize();
	ASSERT(iQueries > 0);
	for (int iQuery = 0; iQuery < iQueries; ++iQuery)
	{
		if (!GetOutput().Fire(IU_EVENT_OPERATION_CONTINUE))
			return false;
		CString sQuery = m_asQueries[iQuery];
		CIuSourceDescriptorPtr pSourceDescriptor = GetSourceProvider().GetSourceDescriptor(sQuery);
		if (pSourceDescriptor.IsNull())
			Error(IU_E_QUERY_FAILED, Format(_T("Could not find query.\n%s"), sQuery));

		CIuSourcePtr pSource = GetSourceProvider().GetSource(*pSourceDescriptor);
		if (pSource.IsNull())
			Error(IU_E_QUERY_FAILED, _T("Could not create data source from source descriptor."));
		
		m_aSources.Add(pSource);

		// If we have a single source, we will use it to set the various
		// pointers in the query object.
		// Otherwise, we just leave the default.
		if (iQuery == 0 && iQueries == 1)
		{
			CString sDatabase = pSourceDescriptor->GetDatabase();
			CIuDatabases& Databases = GetEngine().GetDatabases();
			int iDatabase = Databases.Find(sDatabase);
			if (iDatabase >= 0)
			{
				CIuDatabasePtr pDatabase = &Databases.Get(iDatabase);
				GetQuery().m_pDatabase = pDatabase;
				if (pDatabase.NotNull())
				{
					GetQuery().m_pMeter = &pDatabase->GetMeter();
					GetQuery().m_pUserInterface = pDatabase->GetUserInterfacePtr();
				}
			}
			else
			{
				CIuMoniker Moniker = pSourceDescriptor->GetMeter();
				CIuMeters& Meters = GetEngine().GetMeters();
				int iMeter = Meters.Find(Moniker);
				if (iMeter >= 0)
				{
					CIuMeterPtr pMeter = &Meters.Get(iMeter);
					GetQuery().m_pMeter = pMeter;
				}
			}
		}
	}

	return true;
}

void CIuQueryExecute::CreateSourceSetList()
{
	if (m_pSetList.IsNull())
	{
		CIuSourceBufferPtr pSourceBuffer;
		pSourceBuffer.Create();
		m_pSource = pSourceBuffer;
		return ;
	}

	ASSERT(m_pSetList.NotNull());
	CIuSourceSetListPtr pSourceSetList;
	pSourceSetList.Create();
	pSourceSetList->SetEngine(GetEngine());
	ASSERT(m_aSources.GetSize() > 0);
	pSourceSetList->SetSetList(m_pSetList);
	m_pSource = pSourceSetList;
}

bool CIuQueryExecute::Distinct()
{
#pragma __TODO("CIuQueryExecute::Distinct")
#if 0
	if (!m_fSort)
		return true;

	ASSERT(m_asSort.GetSize() != 0);
	m_Convert.SetKeys(m_asSort);

	ASSERT(m_pSetList.NotNull());
	ASSERT(m_pSource.NotNull());

	// Make a copy of the current set list
	CIuSetListPtr pSetList;
	pSetList.Create();

	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		*pSetList = *m_pSetList;
	}

	// Get the number of records we are processing
	int iCount = pSetList->GetCount();

	// Set up the progress info
	CIuOutputStateInstance instance(GetOutput());
	QUERYTRACE("QUERY: Sort started, %ld records\n", iCount);

	// Some sort variables
	CArray<int,int> aiRecords;
	aiRecords.SetSize(iCount);
	CIuBigBuffer Buffer;
	Buffer.SetGrowBy(128 * 1024);

	// Build the sort keys
	GetOutput().SetRange(iCount);
	GetOutput().SetPosition(0);

	CIuRecordPtr pRecord;
	int iNoise = min(10000, max(1000, iCount / 100));
	for (int i = 0; i < iCount; ++i)
	{
		if ((i % iNoise) == 0)
		{
			GetOutput().SetPosition(i);
			if (!GetOutput().Fire(IU_EVENT_OPERATION_PROGRESS))
			{
				return false;
			}
		}
		UINT64 uiSrcRecNo = pSetList->GetSrcRecNo(i);
		int iOffset = m_Convert.CreateSortKey(Buffer, uiSrcRecNo);
		aiRecords.SetAt(i, iOffset);
	}

	const BYTE* pb = Buffer.GetPtr();
	for (i = 0; i < iCount; ++i)
	{
		int iOffset = aiRecords.GetAt(i);
		aiRecords.SetAt(i, int(pb + iOffset));
	}

	qsort(aiRecords.GetData(), aiRecords.GetSize(), sizeof(int), SortByKey);

	pSetList->Empty();
	pSetList->SetSorted(false);
	for (i = 0; i < iCount; ++i)
	{
		UINT64 uiSrcRecNo = *(const UINT64*)aiRecords.GetAt(i);
		VERIFY(pSetList->Add(GET_SRCNO(uiSrcRecNo), GET_RECNO(uiSrcRecNo)));
	}

	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		*m_pSetList = *pSetList;
	}

	instance.Pop(true);
#endif

	return true;
}

bool CIuQueryExecute::Execute()
{
	if (!Setup())
		return false;

	if (m_iMode == queryModeRecordSet)
	{
		if (!RunRecordSet())
			return false;
	}
	else if (m_iMode == queryModeCount)
	{
		if (!RunCount())
			return false;
	}
	else if (m_iMode == queryModeRequest)
	{
		if (!RunRequest())
			return false;
	}
	else
	{
		QUERYTRACE("QUERYEXECUTE: Invalid query.\n");
		return false;
	}
	return true;
}
bool CIuQueryExecute::ExpandSetList()
{
	ASSERT(m_pSetList.NotNull());
	if (m_pSetList.IsNull())
		return true;

	// The setlist is sorted for efficiency
	if (!m_pSetList->IsSorted())
		m_pSetList->Sort();

	// The set list will contain one or more sources
	// Each of the sources will be expanded individually.
	m_pSetList = m_Convert.ExpandSetList(m_pSetList, &GetOutput());
	return m_pSetList.NotNull();
}

bool CIuQueryExecute::First() 
{
	int iCount, iOffset;
	if (!m_Select.GetFirst(iCount, iOffset))
		return true;

	if (iOffset == 0)
	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		m_pSetList->Truncate(iCount);
	}
	else
	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		CIuSetListPtr pSetListSubSet = m_pSetList->SubSet(iCount, iOffset);
		*m_pSetList = *pSetListSubSet;
	}
	return true;
}
		
CIuEngine& CIuQueryExecute::GetEngine() const
{
	return GetQuery().GetEngine();
}

CIuOutput& CIuQueryExecute::GetOutput() const
{
	ASSERT(HasQuery());
	return GetQuery().GetOutput();
}

CIuSourceProvider& CIuQueryExecute::GetSourceProvider() const
{
	return GetEngine().GetSourceProvider();
}

bool CIuQueryExecute::IsDirectMode() const
{
	// This is a check queries which can be processed in "direct mode".
	// We will automatically go into "direct" mode if a number of criteria are met.

	// Only one source for direct mode
	if (m_aSources.GetSize() != 1)
		return false;

	// No "filter" clause (we can't scan)
	if (!m_sFilter.IsEmpty())
		return false;

	// No sorting in direct mode
	if (m_fSort)
		return false;

	// No direct mode for expanded setlists (primarily an export function)
	if (m_Select.GetExpand())
		return false;

	if (m_Select.GetTagged() != taggedAny)
		return false;

	int iCount, iOffset;
	if (m_Select.GetFirst(iCount, iOffset))
		return false;

	if (m_iNear != 0)
		return false;

	return true;
}

bool CIuQueryExecute::IsScanNeeded() const
{
	if (!m_sFilter.IsEmpty())
		return true;
	if (m_iNear != 0)
		return true;

	return false;
}

void CIuQueryExecute::Reset()
{
	// Clear various data elemets
	m_iFlags = 0;
	m_Options.Clear();
	m_asQueries.RemoveAll();
	m_Criteria.Clear();
	m_aSources.RemoveAll();
	m_sFilter = "";
	m_pSource.Release();
	m_pSetList.Release();
	m_fSuccess = false;
	m_sResult = "";
	m_pCounts.Release();
}

bool CIuQueryExecute::Run()
{
	QUERYTRACE("QUERYEXECUTE: Executing:\n\t%s\n", LPCTSTR(m_sExpression));
	bool fResult = Execute();
	if (!fResult)
	{
		QUERYTRACE("QUERYEXECUTE: Query failed or was aborted.\n");
		// Set started flag so calling thread can continue.
		GetQuery().SetStarted();
		return false;	
	}
	QUERYTRACE("QUERYEXECUTE: complete.\n");
	return true;
}

bool CIuQueryExecute::RunCount()
{
	ASSERT(m_pCounts.NotNull());

	CString sCount;
	if (!m_Select.GetCount(sCount))
		return false;

	{
		CSingleLock lock(&m_pCounts->m_mutex, true);
		m_pCounts->Empty();
		m_pCounts->SetExpression(sCount);
	}

	m_asQueries.RemoveAll();
	m_asQueries.Add(GetQuery().GetID().AsString());

	if (!CreateSources())
		return false;
	if (!CreateSetList())
		return false;

	GetQuery().SetStarted();

	// Get the number of records we are processing
	int iCount = m_pSetList->GetCount();

	int iSeeAlso = m_Select.GetSeeAlso();

	// Set up the progress info
	CIuOutputStateInstance instance(GetOutput());
	QUERYTRACE("QUERY: Count started, %ld records\n", iCount);
#ifdef _DEBUG
	time_t timeStart = time(0);
#endif

	m_Convert.SetOptions(m_Options);
	m_Convert.SetFilter(sCount);

	// Run the record scanner
	GetOutput().SetRange(iCount);
	GetOutput().SetPosition(0);

	CIuRecordPtr pRecord;
	int iNoise = min(10000, max(1000, iCount / 100));
	int iMatched = 0;
	int iTotal = 0;
	for (int i = 0; i < iCount; ++i)
	{
		if ((i % iNoise) == 0)
		{
			{
				CSingleLock lock(&m_pCounts->m_mutex, true);
				m_pCounts->SetMatched(iMatched);
				m_pCounts->SetRemaining(iCount - i);
				m_pCounts->SetTotal(iTotal);
			}
			GetOutput().SetPosition(i);
			GetOutput().SetData(m_pCounts.Ptr());

			if (!GetOutput().Fire(IU_EVENT_ENGINE_COUNT))
				return false;
		}

		UINT64 uiSrcRecNo = m_pSetList->GetSrcRecNo(i);
		bool fResult = m_Convert.EvaluateBool(uiSrcRecNo, pRecord, sourceModeDefault);

		if (iSeeAlso != seeAlsoAny)
		{
			bool fIsAlt = pRecord->IsAlternate();
			if (iSeeAlso == seeAlsoYes)
			{
				if (!fIsAlt)
					continue;
			}
			else
			{
				ASSERT(iSeeAlso == seeAlsoNo);
				if (fIsAlt)
					continue;
			}
		}
			

		++iTotal;
		if (fResult)
			++iMatched;
		ASSERT(uiSrcRecNo == MAKE_SRCRECNO(pRecord->GetSourceNo(), pRecord->GetRecordNo()));

	}

	{
		CSingleLock lock(&m_pCounts->m_mutex, true);
		m_pCounts->SetMatched(iMatched);
		m_pCounts->SetRemaining(iCount - i);
		m_pCounts->SetTotal(iTotal);
	}
	GetOutput().SetPosition(iCount);
	GetOutput().SetData(m_pCounts.Ptr());

	if (!GetOutput().Fire(IU_EVENT_ENGINE_COUNT_COMPLETE))
		return false;

#ifdef _DEBUG
	time_t timeNow = time(0);
	int iElapsed = timeNow - timeStart;
	int iRecordsPerSecond = iCount;
	if (iElapsed > 0)
		iRecordsPerSecond /= iElapsed;
	QUERYTRACE("QUERY: Count completed, matched %d of %d records in %d seconds (%d records/second)\n", iMatched, iCount, iElapsed, iRecordsPerSecond);
#endif

	instance.Pop(true);
	return true;
}

bool CIuQueryExecute::RunDirect()
{
	QUERYTRACE("QUERY: Direct mode\n");

	// We must have exactly one source
	ASSERT(m_aSources.GetSize() == 1);

	// If no key is specified, just have the query use raw
	// source directly.
	if (m_Criteria.GetCount() == 0)
	{
		m_pSource = m_aSources[0];
	}
	// Otherwise, create a set list to hold some
	// subset of the raw source
	else
	{
		CIuSourcePtr pSource = m_aSources[0];
		ASSERT(pSource.NotNull());

		m_pSetList = pSource->GetSetList(m_Criteria, &GetOutput(), sourceModeDefault);
		CreateSourceSetList();
	}
	ASSERT(m_pSource.NotNull());
	return RunOutput();
}

bool CIuQueryExecute::RunOutput()
{
	ASSERT(m_pSource.NotNull());

	// Store source
	GetQuery().GetRecordSet().SetSource(m_pSource);

	// Set up information specific to the record set
	CStringArray asFields;
	if (m_Select.GetFields(asFields))
		GetQuery().GetRecordSet().m_Convert.SetFields(asFields);
	int iCaseConvert = m_Select.GetCase();
	GetQuery().GetRecordSet().m_Convert.SetCaseConvert(iCaseConvert);

	// Mark as started
	GetQuery().SetStarted();

	return true;
}

bool CIuQueryExecute::RunRecordSet()
{
	if (!CreateSources())
		return false;
	if (!CreateFilter())
		return false;
	if (IsDirectMode())
	{
		if (!RunDirect())
			return false;
		m_fSuccess = true;
		return true;
	}

	ASSERT(m_asQueries.GetSize() == m_aSources.GetSize());
	if (!CreateSetList())
		return false;

	if (m_Select.GetExpand())
	{
		if (!ExpandSetList())
			return false;
	}

	if (IsScanNeeded())
	{
		if (!Scan())
			return false;
	}
	else
	{
		CreateSourceSetList();
		if (!RunOutput())
			return false;
	}
	if (!Sort())
		return false;
	if (!First())
		return false;
	m_fSuccess = true;
	return true;
}

bool CIuQueryExecute::RunRequest()
{
	m_sResult = _T("");

	// Check for a valid request
	CString sRequest = UnQuote(m_Select.GetRequest());
	if (sRequest.IsEmpty())
		Error(IU_E_REQUEST_FAILED, _T("Empty request specified."));

	// Make sure at least one parm is passed
	CIuOptions Options(sRequest, ',');
	if (Options.GetCount() < 1)
		Error(IU_E_REQUEST_FAILED, _T("No request specified."));

	// Some requests may be handled locally, if so, deal with them
	CStringArray as;
	Options.Get(as);

	// Request(s)
	// Some requests may be handled locally
	CString sType = as[0];
	if (sType.CompareNoCase("XXX") == 0)
	{
		return true;
	}

	// Get the queries and from the queries, find a source
	m_Select.GetQuery(m_asQueries);
	CIuSourcePtr pSource;
	if (m_asQueries.GetSize() == 0)
	{
		// If no explicit queries, use the current
		CIuRecordSet& RecordSet = GetQuery().GetRecordSet();
		if (RecordSet.HasSource())
			pSource = &RecordSet.GetSource();
	}
	else
	{
		CString sQuery = m_asQueries[0];
		CIuSourceDescriptorPtr pSourceDescriptor = GetSourceProvider().GetSourceDescriptor(sQuery);
		if (pSourceDescriptor.IsNull())
			Error(IU_E_QUERY_FAILED, Format(_T("Could not find query.\n%s"), sQuery));
		pSource = GetSourceProvider().GetSource(*pSourceDescriptor);
		if (pSource.IsNull())
			Error(IU_E_QUERY_FAILED, _T("Could not create data source from source descriptor."));
	}

	// With the source, attempt to process the request.
	if (pSource.IsNull() || !pSource->Request(m_sResult, as))
	{
		m_sResult = _T("Unrecognized or unhandled request.\n'");
		m_sResult += m_Select.GetRequest();
		m_sResult += _T("'\n");
		Error(IU_E_REQUEST_FAILED, LPCTSTR(m_sResult));
	}

	return true;
}

bool CIuQueryExecute::Scan()
{
	// Save current set list
	ASSERT(m_pSource.IsNull());
	ASSERT(m_pSetList.NotNull());
	CIuSetListPtr pSetList = m_pSetList;

	// Create a new, empty set list for our source
	m_pSetList.Create();

	// Create a source list with the empty set list
	CreateSourceSetList();

	// Mark query as started
	if (!RunOutput())
		return false;

	// Get the number of records we are processing
	int iCount = pSetList->GetCount();
	if (m_fSort && m_iSortLimit > 0)
		iCount = min(iCount, m_iSortLimit);

	// Set up the progress info
	CIuOutputStateInstance instance(GetOutput());
	QUERYTRACE("QUERY: Scan started, %ld records\n", iCount);
#ifdef _DEBUG
	time_t timeStart = time(0);
#endif

	m_Convert.SetOptions(m_Options);

	int iSeeAlso = m_Select.GetSeeAlso();

	bool fFilter = false;
	if (!m_sFilter.IsEmpty())
	{
		fFilter = true;
		m_Convert.SetFilter(m_sFilter);
	}

	// Run the record scanner
	GetOutput().SetRange(iCount);
	GetOutput().SetPosition(0);

	CIuRecordPtr pRecord;
	int iNoise = min(10000, max(1000, iCount / 100));
	int iOutput = 0;
	for (int i = 0; i < iCount; ++i)
	{
		if ((i % iNoise) == 0)
		{
			GetOutput().SetPosition(i);
			if (!GetOutput().Fire(IU_EVENT_OPERATION_PROGRESS))
			{
				return false;
			}
		}

		UINT64 uiSrcRecNo = pSetList->GetSrcRecNo(i);
		if (fFilter)
		{
			if (!m_Convert.EvaluateBool(uiSrcRecNo, pRecord, sourceModeDefault))
				continue;
		}
		else
		{
			if (m_Convert.Get(uiSrcRecNo, pRecord, sourceModeDefault) == 0)
				return false;
		}

		ASSERT(uiSrcRecNo == MAKE_SRCRECNO(pRecord->GetSourceNo(), pRecord->GetRecordNo()));

		if ((m_iNear & (nearDistance|nearCoordinate)) == (nearDistance|nearCoordinate))
		{
			if (pRecord->IsNoMail())
				continue;

			CIuLatLongCoordinate Coord;
			pRecord->GetLatLong(Coord);
			if (!Coord.IsValid() || Coord.IsZero())
				continue;

			CIuLatLongDistance Distance = Coord - m_Center;
			if (Distance > m_Distance)
				continue;
		}

		if (iSeeAlso != seeAlsoAny)
		{
			bool fIsAlt = pRecord->IsAlternate();
			if (iSeeAlso == seeAlsoYes)
			{
				if (!fIsAlt)
					continue;
			}
			else
			{
				ASSERT(iSeeAlso == seeAlsoNo);
				if (fIsAlt)
					continue;
			}
		}

		{
			CSingleLock lock(&m_pSource->m_mutex, true);
			m_pSetList->Add(*pRecord);
			++iOutput;
		}
	}

#ifdef _DEBUG
	time_t timeNow = time(0);
	int iElapsed = timeNow - timeStart;
	int iRecordsPerSecond = iCount;
	if (iElapsed > 0)
		iRecordsPerSecond /= iElapsed;
	QUERYTRACE("QUERY: Scan completed, %ld matches from %ld records in %ld seconds (%ld records/second)\n", iOutput, iCount, iElapsed, iRecordsPerSecond);
#endif

	instance.Pop(true);
	return true;
}

CIuCountsPtr CIuQueryExecute::SetCount(LPCTSTR pcsz)
{
	Reset();
	ASSERT(AfxIsValidString(pcsz));
	SetExpression(pcsz);
	m_iMode = queryModeCount;

	// First step is to create a counts object
	m_pCounts.Create();

	return m_pCounts;
}

void CIuQueryExecute::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_iMode = queryModeNone;
	m_sExpression = pcsz;
}

void CIuQueryExecute::SetQuery(CIuQuery& Query)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pQuery = &Query;
	m_Select.SetEngine(GetEngine());
}

void CIuQueryExecute::SetRecordSet(LPCTSTR pcsz)
{
	Reset();
	ASSERT(AfxIsValidString(pcsz));
	SetExpression(pcsz);
	m_iMode = queryModeRecordSet;
}

void CIuQueryExecute::SetRequest(LPCTSTR pcsz)
{
	Reset();
	ASSERT(AfxIsValidString(pcsz));
	SetExpression(pcsz);
	m_iMode = queryModeRequest;
}

bool CIuQueryExecute::Setup()
{
	m_Convert.SetEngine(GetEngine());
	m_Select.SetExpression(m_sExpression);

	// Set up the master options and flags
	m_Select.GetMasterOptions(m_Options);
	GetQuery().SetOptions(m_Options);

	// Get the flags to use
	m_iFlags = 0;
	if (m_Select.IsDebug())
		m_iFlags |= sourceFlagDebug;

	// Get query source names
	m_Select.GetQuery(m_asQueries);
	if (m_asQueries.GetSize() == 0)
	{
		CString sDefault = GetSourceProvider().GetDefaultSource(GetQuery().GetName());
		if (!sDefault.IsEmpty())
			m_asQueries.Add(sDefault);
	}
	if (m_asQueries.GetSize() == 0)
		Error(IU_E_QUERY_FAILED, _T("Request failed. No data source specified and no default is available."));

	// Get the index critiera
	m_Select.GetCriteria(m_Criteria);

	m_fSort = m_Select.GetSort(m_asSort);
	if (m_fSort)
		m_Select.GetSortLimit(m_iSortLimit);
	else
		m_iSortLimit = -1;

	// Currently, you must specify both distance and coordinate
	m_iNear = m_Select.GetNear(m_Center, m_Distance);
	ASSERT(m_iNear == 0 || (m_iNear & (nearDistance|nearCoordinate)) == (nearDistance|nearCoordinate));
	if (m_iNear != 0)
	{
		if (!m_Center.IsValid() || m_Center.IsZero())
			m_iNear = 0;
	}

	// Retrieve the "WHERE" or "FILTER" clause.
	// This clause may be modified if no all of the sources can process the 
	// criteria passed to them
	CString sFilter = m_Select.GetFilter();
	if (!sFilter.IsEmpty())
	{
		// Enclose in quote. We may later add to this expression
		// if we need to scan for criteria which do not have an index
		// or which have an expression which does not lend itself to being
		// evaluated by an index.
		m_sFilter += _T("(");
		m_sFilter += sFilter;
		m_sFilter += _T(")");
	}

	return true;
}

bool CIuQueryExecute::Sort()
{
	if (!m_fSort)
		return true;

	ASSERT(m_asSort.GetSize() != 0);
	m_Convert.SetKeys(m_asSort);

	ASSERT(m_pSetList.NotNull());
	ASSERT(m_pSource.NotNull());

	// Make a copy of the current set list
	CIuSetListPtr pSetList;
	pSetList.Create();

	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		*pSetList = *m_pSetList;
	}

	// Get the number of records we are processing
	int iCount = pSetList->GetCount();

	// Set up the progress info
	CIuOutputStateInstance instance(GetOutput());
	QUERYTRACE("QUERY: Sort started, %ld records\n", iCount);

	// Some sort variables
	CArray<int,int> aiRecords;
	aiRecords.SetSize(iCount);
	CIuBigBuffer Buffer;
	Buffer.SetGrowBy(128 * 1024);

	// Build the sort keys
	GetOutput().SetRange(iCount);
	GetOutput().SetPosition(0);

	CIuRecordPtr pRecord;
	int iNoise = min(10000, max(1000, iCount / 100));
	for (int i = 0; i < iCount; ++i)
	{
		if ((i % iNoise) == 0)
		{
			GetOutput().SetPosition(i);
			if (!GetOutput().Fire(IU_EVENT_OPERATION_PROGRESS))
			{
				return false;
			}
		}
		UINT64 uiSrcRecNo = pSetList->GetSrcRecNo(i);
		int iOffset = m_Convert.CreateSortKey(Buffer, uiSrcRecNo);
		aiRecords.SetAt(i, iOffset);
	}

	const BYTE* pb = Buffer.GetPtr();
	for (i = 0; i < iCount; ++i)
	{
		int iOffset = aiRecords.GetAt(i);
		aiRecords.SetAt(i, int(pb + iOffset));
	}

	qsort(aiRecords.GetData(), aiRecords.GetSize(), sizeof(int), SortByKey);

	pSetList->Empty();
	pSetList->SetSorted(false);
	for (i = 0; i < iCount; ++i)
	{
		UINT64 uiSrcRecNo = *(const UINT64*)aiRecords.GetAt(i);
		VERIFY(pSetList->Add(GET_SRCNO(uiSrcRecNo), GET_RECNO(uiSrcRecNo)));
	}

	{
		CSingleLock lock(&m_pSource->m_mutex, true);
		*m_pSetList = *pSetList;
	}

	instance.Pop(true);

	return true;
}
