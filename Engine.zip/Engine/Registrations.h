#ifndef _ENGINE_REGISTRATIONS_H_
#define _ENGINE_REGISTRATIONS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_REGISTRATION_H_
#	include "engine\Registration.h"
#endif	// _ENGINE_REGISTRATION_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRegistrations)
class CIuEngine;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegistrations, CIuCollection }}
#define CIuRegistrations_super CIuCollection

class IU_CLASS_EXPORT CIuRegistrations : public CIuRegistrations_super
{
//{{Declare
	DECLARE_SERIAL(CIuRegistrations)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegistrations();
	virtual ~CIuRegistrations();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuRegistration& Get(const CIuMoniker& moniker) const;
	CIuRegistration& Get(LPCTSTR s) const;
	CIuRegistration& Get(int iIndex) const;
	CIuRegistration& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetEngine(CIuEngine& Engine);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuRegistration& CIuRegistrations::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuRegistration*>(&CIuCollection::Get(moniker));
}

inline CIuRegistration& CIuRegistrations::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuRegistration*>(&CIuCollection::Get(s));
}

inline CIuRegistration& CIuRegistrations::Get(int iIndex) const
{
	return *dynamic_cast<CIuRegistration*>(&CIuCollection::Get(iIndex));
}

inline CIuRegistration& CIuRegistrations::Get(CIuID id) const
{
	return *dynamic_cast<CIuRegistration*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuRegistrations::GetEngine() const
{
	ASSERT(HasEngine());
	return *m_pEngine;
}

inline bool CIuRegistrations::HasEngine() const
{
	return m_pEngine != 0;
}

#endif // _ENGINE_REGISTRATIONS_H_
