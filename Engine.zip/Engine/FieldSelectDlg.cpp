#include "stdafx.h"
#include "FieldSelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIuFieldDlg dialog


CIuFieldDlg::CIuFieldDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIuFieldDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuFieldDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CIuFieldDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuFieldDlg)
	DDX_Control(pDX, IDC_ENGINE_UP, m_Up);
	DDX_Control(pDX, IDC_ENGINE_SELECTALL, m_SelectAll);
	DDX_Control(pDX, IDC_ENGINE_SELECT, m_Select);
	DDX_Control(pDX, IDC_ENGINE_DOWN, m_Down);
	DDX_Control(pDX, IDC_ENGINE_DELETEALL, m_DeleteAll);
	DDX_Control(pDX, IDC_ENGINE_DELETE, m_Delete);
	DDX_Control(pDX, IDC_ENGINE_DEFAULT, m_Default);
	DDX_Control(pDX, IDC_ENGINE_SELECTED, m_ListBoxSelected);
	DDX_Control(pDX, IDC_ENGINE_ALL, m_ListBoxUniversal);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIuFieldDlg, CDialog)
	//{{AFX_MSG_MAP(CIuFieldDlg)
	ON_BN_CLICKED(IDC_ENGINE_SELECT, OnSelect)
	ON_BN_CLICKED(IDC_ENGINE_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_ENGINE_UP, OnUp)
	ON_BN_CLICKED(IDC_ENGINE_DOWN, OnDown)
	ON_BN_CLICKED(IDC_ENGINE_SELECTALL, OnSelectall)
	ON_BN_CLICKED(IDC_ENGINE_DELETEALL, OnDeleteAll)
	ON_BN_CLICKED(IDC_ENGINE_DEFAULT, OnDefault)
	ON_LBN_SELCHANGE(IDC_ENGINE_SELECTED, OnSelchangeSelected)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuFieldDlg message handlers

void CIuFieldDlg::OnDefault()
{
	int iSize = m_ListBoxSelected.GetCount();
	if (iSize > 0)
		DeleteAll();

	PopulateDefaultListBox();
}

void CIuFieldDlg::OnDelete() 
{

	int iSelected = m_ListBoxSelected.GetCurSel();
	if (iSelected == LB_ERR)
		return;

	int iData = m_ListBoxSelected.GetItemData(iSelected);
	CString sSelectedStr;
	m_ListBoxSelected.GetText(iSelected, sSelectedStr);	

	int iIndex = FindIndex(iData);
	int iInserted = m_ListBoxUniversal.InsertString(iIndex, sSelectedStr);
	m_ListBoxUniversal.SetItemData(iInserted, iData);
	m_ListBoxSelected.DeleteString(iSelected);	
	m_ListBoxUniversal.SetCurSel(iInserted);

	if (iSelected >= m_ListBoxSelected.GetCount())
		m_ListBoxSelected.SetCurSel(iSelected - 1);
	else
		m_ListBoxSelected.SetCurSel(iSelected);

	DisableButtons();
}

void CIuFieldDlg::OnDeleteAll() 
{
	CWaitCursor wait;
	DeleteAll();
	DisableButtons();
}

void CIuFieldDlg::OnDown() 
{
	int iSelected = m_ListBoxSelected.GetCurSel();
	if (iSelected == LB_ERR)
		return;

	if (iSelected < m_ListBoxSelected.GetCount() - 1)
	{
		int iData = m_ListBoxSelected.GetItemData(iSelected);
		CString sSelected;
		m_ListBoxSelected.GetText(iSelected, sSelected);
		m_ListBoxSelected.SetItemData(m_ListBoxSelected.InsertString(iSelected + 2, sSelected), iData);
		m_ListBoxSelected.DeleteString(iSelected);
		m_ListBoxSelected.SetCurSel(iSelected + 1);
	}

	DisableButtons();

}

BOOL CIuFieldDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CWaitCursor wait;

	int iSize = m_asUniversal.GetSize();
	ASSERT(iSize > 0);
	if (iSize <= 0)
		EndDialog(-1);

	if (m_asDefault.GetSize() <= 0)
		DisableDlgItem(&m_Default);

	PopulateUniversalListBox();		// Populate Universal ListBox

	if (m_asSelected.GetSize() > 0)
		PopulateSelectedListBox();	//Populate Selection ListBox with existing
	else							//	selected Choices
		PopulateDefaultListBox();	//Populate Selection ListBox with Defaults

	DisableButtons();

	return true;  // return true unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return false
}

void CIuFieldDlg::OnOK() 
{
	CString sSelected = _T("");
	for (int i=0; i<m_ListBoxSelected.GetCount(); i++)
	{
		m_ListBoxSelected.GetText(i, sSelected);
		m_asExportFields.Add(sSelected);
	}
	
	CDialog::OnOK();
}

void CIuFieldDlg::OnSelchangeSelected() 
{
	DisableButtons();	
}

void CIuFieldDlg::OnSelect() 
{

	int iSelected = m_ListBoxUniversal.GetCurSel();
	if (iSelected == LB_ERR)
		return;
	int iData = m_ListBoxUniversal.GetItemData(iSelected);
	CString sSelectedStr;
	m_ListBoxUniversal.GetText(iSelected, sSelectedStr);

	int iAddedIndex = m_ListBoxSelected.AddString(sSelectedStr);
	m_ListBoxSelected.SetItemData(iAddedIndex, iData);

	m_ListBoxUniversal.DeleteString(iSelected);	
	m_ListBoxSelected.SetCurSel(iAddedIndex);

	if (iSelected >= m_ListBoxUniversal.GetCount())
		m_ListBoxUniversal.SetCurSel(iSelected - 1);
	else
		m_ListBoxUniversal.SetCurSel(iSelected);

	DisableButtons();
}

void CIuFieldDlg::OnSelectall() 
{
	CWaitCursor wait;
	for (int i=0; i < m_ListBoxUniversal.GetCount(); i++)
	{
		CString sTemp = _T("");
		int iData;
		m_ListBoxUniversal.GetText(i, sTemp);
		iData = m_ListBoxUniversal.GetItemData(i);
		int iAddedIndex = m_ListBoxSelected.AddString(sTemp);
		m_ListBoxSelected.SetItemData(iAddedIndex, iData);
	}

	m_ListBoxUniversal.ResetContent();

	DisableButtons();
}

void CIuFieldDlg::OnUp() 
{
	int iSelected = m_ListBoxSelected.GetCurSel();
	if (iSelected == LB_ERR)
		return;

	if (iSelected > 0)
	{
		int iData = m_ListBoxSelected.GetItemData(iSelected);
		CString sSelected;
		m_ListBoxSelected.GetText(iSelected, sSelected);
		m_ListBoxSelected.SetItemData(m_ListBoxSelected.InsertString(iSelected - 1, sSelected), iData);
		m_ListBoxSelected.DeleteString(iSelected + 1);
		m_ListBoxSelected.SetCurSel(iSelected - 1);
	}

	DisableButtons();

}
// }} CIuFieldDlg message handlers 
/////////////////////////////////////////////////////////////////////////////

void CIuFieldDlg::DeleteAll()
{
	//Moves everything from the Selection ListBox to Universal ListBox
	for (int i=0; i < m_ListBoxSelected.GetCount(); i++)
	{
		CString sTemp = _T("");
		int iData;
		m_ListBoxSelected.GetText(i, sTemp);
		iData = m_ListBoxSelected.GetItemData(i);

		int iIndex = FindIndex(iData);
		int iInserted = m_ListBoxUniversal.InsertString(iIndex, sTemp);
		m_ListBoxUniversal.SetItemData(iInserted, iData);
	}

	m_ListBoxSelected.ResetContent();
}

void CIuFieldDlg::DisableButtons()
{
	if (m_ListBoxSelected.GetCurSel() == LB_ERR)
	{
		DisableDlgItem(&m_Up);
		DisableDlgItem(&m_Down);
	}
	else
	{
		if (m_ListBoxSelected.GetCurSel() == m_ListBoxSelected.GetCount() - 1)
			DisableDlgItem(&m_Down);
		else
			m_Down.EnableWindow(true);

		if (m_ListBoxSelected.GetCurSel() == 0)
			DisableDlgItem(&m_Up);
		else
			m_Up.EnableWindow(true);
	}

	if (m_ListBoxSelected.GetCount() <= 0)
	{
		DisableDlgItem(&m_Delete);
		DisableDlgItem(&m_DeleteAll);
	}
	else
	{
		m_Delete.EnableWindow(true);
		m_DeleteAll.EnableWindow(true);
	}

	if (m_ListBoxUniversal.GetCount() <= 0)
	{
		DisableDlgItem(&m_Select);
		DisableDlgItem(&m_SelectAll);
	}
	else
	{
		m_Select.EnableWindow(true);
		m_SelectAll.EnableWindow(true);
	}
	
}

int CIuFieldDlg::FindIndex(int iData)
{
	CWaitCursor wait;

	UINT iLow = 0;
	UINT iHigh = m_ListBoxUniversal.GetCount();

	while (iLow < iHigh)
	{
		UINT iMid = (iLow + iHigh)/2;
		if (static_cast<int>(m_ListBoxUniversal.GetItemData(iMid)) < iData)
			iLow = iMid + 1;
		else
			iHigh = iMid;
	}

	return iLow;
}

void CIuFieldDlg::GetExportFields(CStringArray &asExFlds) const
{
	asExFlds.Copy(m_asExportFields);
}

void CIuFieldDlg::DisableDlgItem(CWnd *pItem)
{
	ASSERT(pItem != NULL);

	CWnd* pWndFocus = GetFocus();
#ifdef _DEBUG
	pWndFocus->AssertValid();
#endif

	if (pWndFocus->GetDlgCtrlID() == pItem->GetDlgCtrlID())
		GetNextDlgTabItem(pItem, false)->SetFocus();

	pItem->EnableWindow(false);
}

void CIuFieldDlg::PopulateDefaultListBox()
{
	if (m_asDefault.GetSize() <= 0)
	{
		DisableDlgItem(&m_Default);
		return;
	}
	for (int i=0; i<m_asDefault.GetSize(); i++)
	{
		int iFound = m_ListBoxUniversal.FindStringExact(-1, m_asDefault.GetAt(i));

		if (iFound != LB_ERR)
		{
			m_ListBoxSelected.SetItemData(m_ListBoxSelected.AddString(m_asDefault.GetAt(i)), m_ListBoxUniversal.GetItemData(iFound));
			m_ListBoxUniversal.DeleteString(iFound);
		}
	}

	m_ListBoxSelected.SetCurSel(0);
}

void CIuFieldDlg::PopulateSelectedListBox()
{
	for (int i=0; i<m_asSelected.GetSize(); i++)
	{
		int iFound = m_ListBoxUniversal.FindStringExact(-1, m_asSelected.GetAt(i));

		if (iFound != LB_ERR)
		{
			m_ListBoxSelected.SetItemData(m_ListBoxSelected.AddString(m_asSelected.GetAt(i)), m_ListBoxUniversal.GetItemData(iFound));
			m_ListBoxUniversal.DeleteString(iFound);
		}
	}

	m_ListBoxSelected.SetCurSel(0);
}

void CIuFieldDlg::PopulateUniversalListBox()
{
	int iData = 0;
	for (int i=0; i<m_asUniversal.GetSize(); i++)
	{
		CString sData = m_asUniversal.GetAt(i);
		if (m_ListBoxUniversal.FindStringExact(-1, sData) == LB_ERR)
		{
			m_ListBoxUniversal.SetItemData(m_ListBoxUniversal.AddString(sData), iData);
			iData += 1;
		}
	}

	m_ListBoxUniversal.SetCurSel(0);
}

void CIuFieldDlg::SetDefaultArray(const CStringArray &asDefault)
{
	if (m_asDefault.GetSize() > 0)
		m_asDefault.RemoveAll();

	m_asDefault.Copy(asDefault);
}

void CIuFieldDlg::SetSelectedArray(const CStringArray &asSelected)
{
	if (m_asSelected.GetSize() > 0)
		m_asSelected.RemoveAll();

	m_asSelected.Copy(asSelected);
}

void CIuFieldDlg::SetUniversalArray(const CStringArray &asUniversal)
{
	if (m_asUniversal.GetSize() > 0)
		m_asUniversal.RemoveAll();

	m_asUniversal.Copy(asUniversal);
}