#ifndef _ENGINE_COUNTSIMPLEDLG_H_ 
#define _ENGINE_COUNTSIMPLEDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "Engine\resource.h"
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuQuery)
IU_DEFINE_OBJECT_PTR(CIuCounts)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCountSimpleDlg, CDialog }}
#define CIuCountSimpleDlg_super CDialog

class IU_CLASS_EXPORT CIuCountSimpleDlg : public CIuCountSimpleDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuCountSimpleDlg(CWnd* pParent = NULL);   // standard constructor
	~CIuCountSimpleDlg();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuProgressBroadcast& GetBroadcast() const;
	int GetHandle() const;
	bool HasBroadcast() const;
	bool ShouldAbort() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static CIuCountsPtr DoDialog(CIuQuery& Query, LPCTSTR pcszExpression, CWnd* pParent, LPCTSTR pcszLabel1, LPCTSTR pcszLabel2);
	void SetAbort(bool);
	void SetBroadcast(CIuProgressBroadcast* pBroadcast);
	void SetHandle(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Query object running the count
	CIuQueryPtr m_pQuery;
	// Count expression
	CString m_sExpression;
	// Counts object
	CIuCountsPtr m_pCounts;
	// Is running?
	bool m_fRunning;
	// Can close
	bool m_fCanClose;
	// Abort flag
	bool m_fAbort;
	// Operation handle
	int m_iHandle;
	// Back pointer to broadcast object.
	// If not null, this window will subscribe and unsubscribe automatically
	CIuProgressBroadcast* m_pBroadcast;
//}}Data

private:
	//{{AFX_DATA(CIuCountSimpleDlg)
	enum { IDD = IDD_ENGINE_COUNT_SIMPLE };
	CStatic	m_editRemaining;
	CStatic	m_stLabelRemaining;
	CButton	m_btnStop;
	CString	m_sLabel1;
	CString	m_sLabel2;
	CString	m_sTotal;
	CString	m_sRemaining;
	CString	m_sCount2;
	CString	m_sCount1;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuCountSimpleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuCountSimpleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnStop();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	void OnOK();
	void OnCancel();

	LRESULT OnEvent(WPARAM, LPARAM lpParam);
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuProgressBroadcast& CIuCountSimpleDlg::GetBroadcast() const
{
	ASSERT(HasBroadcast());
	return *m_pBroadcast;
}

inline int CIuCountSimpleDlg::GetHandle() const
{
	return m_iHandle;
}

inline bool CIuCountSimpleDlg::HasBroadcast() const
{
	return m_pBroadcast != 0;
}

inline bool CIuCountSimpleDlg::ShouldAbort() const
{
	return m_fAbort;
}

#endif // _ENGINE_COUNTSIMPLEDLG_H_
