#ifndef _ENGINE_FIELDSELECTDLG_H_
#define _ENGINE_FIELDSELECTDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// CIuFieldDlg dialog

#define CIuFieldDlg_super CDialog

class CIuFieldDlg : public CIuFieldDlg_super
{
/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	void GetExportFields(CStringArray& asExFlds) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetDefaultArray(const CStringArray &asDefault);
	void SetSelectedArray(const CStringArray& asSelected);
	void SetUniversalArray(const CStringArray& asUniversal);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CIuFieldDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelect();
	afx_msg void OnDelete();
	afx_msg void OnUp();
	afx_msg void OnDown();
	afx_msg void OnSelectall();
	afx_msg void OnDeleteAll();
	afx_msg void OnDefault();
	virtual void OnOK();
	afx_msg void OnSelchangeSelected();
	//}}AFX_MSG

// Dialog Data
	//{{AFX_DATA(CIuFieldDlg)
	enum { IDD = IDD_ENGINE_FIELD_SELECT };
	CButton	m_Up;
	CButton	m_SelectAll;
	CButton	m_Select;
	CButton	m_Down;
	CButton	m_DeleteAll;
	CButton	m_Delete;
	CButton	m_Default;
	CListBox	m_ListBoxSelected;
	CListBox	m_ListBoxUniversal;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIuFieldDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	DECLARE_MESSAGE_MAP()

private:
	void DeleteAll();
	void DisableButtons();
	void DisableDlgItem(CWnd* pItem);
	int FindIndex(int iData);
	void PopulateDefaultListBox();
	void PopulateSelectedListBox();
	void PopulateUniversalListBox();

	CStringArray m_asDefault;
	CStringArray m_asExportFields;
	CStringArray m_asSelected;
	CStringArray m_asUniversal;
//}}Implementation
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_FIELDSELECTDLG_H_
