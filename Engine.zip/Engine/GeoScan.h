#ifndef _ENGINE_GEOSCAN_H_
#define _ENGINE_GEOSCAN_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDITERATOR_H_
#	include "Engine\RecordIterator.h"
#endif	// _ENGINE_RECORDITERATOR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoScan)
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
IU_DEFINE_OBJECT_PTR(CIuGeoRaw)
class CIuGeoSpec;
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoScan, CIuRecordIterator }}
#define CIuGeoScan_super CIuRecordIterator
class CIuGeoScan : public CIuGeoScan_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoScan)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoScan();
	virtual ~CIuGeoScan();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetAreaCodeFilename() const;
	CString GetCensusFilename() const;
	CString GetCountyFilename() const;
	CString GetExchangeFilename() const;
	CString GetMsaFilename() const;
	CIuGeoRaw& GetRaw() const;
	bool ShouldAppend() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Delete(CIuOutput* pOutput = 0);
	void SetAppend(bool);
	void SetAreaCodeFilename(LPCTSTR);
	void SetCensusFilename(LPCTSTR);
	void SetCountyFilename(LPCTSTR);
	void SetExchangeFilename(LPCTSTR);
	void SetMsaFilename(LPCTSTR);
	void SetSpec(CIuGeoSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void OnClose(CIuOutput&);
	bool OnOpen(CIuOpenSpec& OpenSpec);
	bool OnProcess(const CIuRecord& Record, CIuOutput&);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetRaw_() const;
private:
	void CommonConstruct();
	void UpdateAreaCode(CIuOutput& Output);
	void UpdateCensus(CIuOutput& Output);
	void UpdateCounty(CIuOutput& Output);
	void UpdateExchange(CIuOutput& Output);
	void UpdateMsa(CIuOutput& Output);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The output object
	CIuGeoRawPtr m_pRaw;
	// Secondary files used to update the geo information
	CString m_sMsaFilename;
	CString m_sCountyFilename;
	CString m_sCensusFilename;
	CString m_sAreaCodeFilename;
	CString m_sExchangeFilename;
	// Append to existing object?
	bool m_fAppend;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuGeoScan::GetAreaCodeFilename() const
{
	return m_sAreaCodeFilename;
}

inline CString CIuGeoScan::GetCensusFilename() const
{
	return m_sCensusFilename;
}

inline CString CIuGeoScan::GetCountyFilename() const
{
	return m_sCountyFilename;
}

inline CString CIuGeoScan::GetExchangeFilename() const
{
	return m_sExchangeFilename;
}

inline CString CIuGeoScan::GetMsaFilename() const
{
	return m_sMsaFilename;
}

inline CIuGeoRaw& CIuGeoScan::GetRaw() const
{
	return m_pRaw.Ref();
}

inline bool CIuGeoScan::ShouldAppend() const
{
	return m_fAppend;
}

#endif // _ENGINE_GEOSCAN_H_
