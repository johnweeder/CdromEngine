#include "stdafx.h" 
//{{Include
#include "Exporter.h"
#include "Exporters.h"
#include "Engine.h"
#include "resource.h"
#include "Error\Error.h"
#include "XChgFixedFile.h"
#include "XChgDelimitedFile.h"
#include "XChgDBaseFile.h"
#include "IDs.h"
#include "OpenSpec.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
const	CIuVersionNumber versionExporterMax(2000,1,5,304);
const	CIuVersionNumber versionExporterMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTER, CIuExporter, CIuExporter_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExporter, IDS_ENGINE_PROP_DESCRIPTION, GetDescription, SetDescription, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExporter, IDS_ENGINE_PROP_EXTENSION, GetExtension, SetExtension, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExporter, IDS_ENGINE_PROP_MAXFIELDS, GetMaxFields, SetMaxFields, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExporter, IDS_ENGINE_PROP_MAXRECORDS, GetMaxRecords, SetMaxRecords, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExporter, IDS_ENGINE_PROP_FIELDNAMELENGTH, GetFieldNameLength, SetFieldNameLength, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuExporter, IDS_ENGINE_PROP_FIELDNAMESUNIQUE, GetFieldNamesUnique, SetFieldNamesUnique, 0)

	IU_ATTRIBUTE_PAGE(CIuExporter, IDS_ENGINE_PPG_EXPORTER, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExporter, IDS_ENGINE_PROP_DESCRIPTION, IDS_ENGINE_PPG_EXPORTER, 5, editorMultiLine)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExporter, IDS_ENGINE_PROP_EXTENSION, IDS_ENGINE_PPG_EXPORTER, 1, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExporter, IDS_ENGINE_PROP_MAXFIELDS, IDS_ENGINE_PPG_EXPORTER, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExporter, IDS_ENGINE_PROP_MAXRECORDS, IDS_ENGINE_PPG_EXPORTER, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExporter, IDS_ENGINE_PROP_FIELDNAMELENGTH, IDS_ENGINE_PPG_EXPORTER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuExporter, IDS_ENGINE_PROP_FIELDNAMESUNIQUE, IDS_ENGINE_PPG_EXPORTER, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuExporter

IMPLEMENT_SERIAL(CIuExporter, CIuExporter_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExporter)

CIuExporter::CIuExporter()
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuExporter::~CIuExporter()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExporter::Clear()
{
	CIuExporter_super::Clear();
	CIuExporter::CommonConstruct();
}

void CIuExporter::CommonConstruct()
{
	//{{Initialize
	m_sExtension = _T(".txt");
	m_fFieldNamesUnique = false;
	m_iFieldNameLength = -1;
	m_iMaxRecords = -1;
	m_iMaxFields = -1;
	SetVersion(versionExporterMax);
	//}}Initialize
}

CIuXChgFilePtr CIuExporter::CreateXChgFile(CIuOpenSpec& OpenSpec) const
{
	// Instantiate your own specific export instance here....
	// If you change the begin/end/sep/term values, may need to
	// change values in ..\ExportDefSpec.cpp.
	CIuXChgDelimitedFilePtr pDelimitedFile;
	if (GetID() == idExporterCsv)
	{
		CIuXChgDelimitedFilePtr pFile;
		pFile.Create();
		pDelimitedFile = pFile;
		ASSERT(pFile.NotNull());
		pFile->SetBegin(_T("\""));
		pFile->SetEnd(_T("\""));
		pFile->SetSeparator(_T(","));
		pFile->SetTerminator(_T("\r\n"));
		pDelimitedFile = pFile;
	}
	else if (GetID() == idExporterTab)
	{
		CIuXChgDelimitedFilePtr pFile;
		pFile.Create();
		ASSERT(pFile.NotNull());
		pFile->SetBegin(_T(""));
		pFile->SetEnd(_T(""));
		pFile->SetSeparator(_T("\t"));
		pFile->SetTerminator(_T("\r\n"));
		pDelimitedFile = pFile;
	}
	else if (GetID() == idExporterFix)
	{
		CIuXChgFixedFilePtr pFile;
		pFile.Create();
		ASSERT(pFile.NotNull());
		return pFile;
	}
	else if (GetID() == idExporterDbf)
	{
		CIuXChgDBaseFilePtr pFile;
		pFile.Create();
		ASSERT(pFile.NotNull());
		return pFile;
	}
	else if (GetID() == idExporterTxt)
	{
		CIuXChgDelimitedFilePtr pFile;
		pFile.Create();
		ASSERT(pFile.NotNull());
		// Output each field on its own line, and put a blank line after each record.
		pFile->SetBegin(_T(""));
		pFile->SetEnd(_T(""));
		pFile->SetSeparator(_T("\r\n"));
		pFile->SetTerminator(_T("\r\n"));
		// But, do not output empty fields (don't want blank lines in a record).
		pFile->SetSkipEmptyFields(true);
		pDelimitedFile = pFile;
	}
	else 
	{
		// Didn't recognize the id
		ASSERT(false);
		return CIuXChgFilePtr();
	}

	if (OpenSpec.m_pOptions)
	{
		int iWhich = 0;
		// Begin
		iWhich = OpenSpec.m_pOptions->Find("NoXChgBegin");
		if (iWhich >= 0)
			pDelimitedFile->SetBegin(_T(""));
		else
		{
			iWhich = OpenSpec.m_pOptions->Find("XChgBegin");
			if (iWhich >= 0)
			{
				CString sValue = OpenSpec.m_pOptions->GetValue(iWhich);
				pDelimitedFile->SetBegin(sValue);
			}
		}
		// End
		iWhich = OpenSpec.m_pOptions->Find("NoXChgEnd");
		if (iWhich >= 0)
			pDelimitedFile->SetEnd(_T(""));
		else
		{
			iWhich = OpenSpec.m_pOptions->Find("XChgEnd");
			if (iWhich >= 0)
			{
				CString sValue = OpenSpec.m_pOptions->GetValue(iWhich);
				pDelimitedFile->SetEnd(sValue);
			}
		}
		// Separator
		iWhich = OpenSpec.m_pOptions->Find("NoXChgSeparator");
		if (iWhich >= 0)
			pDelimitedFile->SetSeparator(_T(""));
		else
		{
			iWhich = OpenSpec.m_pOptions->Find("XChgSeparator");
			if (iWhich >= 0)
			{
				CString sValue = OpenSpec.m_pOptions->GetValue(iWhich);
				pDelimitedFile->SetSeparator(sValue);
			}
		}
		// Terminator
		iWhich = OpenSpec.m_pOptions->Find("NoXChgTerminator");
		if (iWhich >= 0)
			pDelimitedFile->SetTerminator(_T(""));
		else
		{
			iWhich = OpenSpec.m_pOptions->Find("XChgTerminator");
			if (iWhich >= 0)
			{
				CString sValue = OpenSpec.m_pOptions->GetValue(iWhich);
				pDelimitedFile->SetTerminator(sValue);
			}
		}
	}
	return pDelimitedFile;
}

LPCTSTR CIuExporter::GetExporterName(const CIuID& id)
{
	if (id == idExporterCsv)
		return _T("Comma Delimited");
	else if (id == idExporterTab)
		return _T("Tab Delimited");
	else if (id == idExporterFix)
		return _T("Fixed Length");
	else if (id == idExporterDbf)
		return _T("dBase III");
	else if (id == idExporterTxt)
		return _T("Text");
	ASSERT(false);
	return _T("#Unknown#");
}

CIuExporters& CIuExporter::GetExporters() const
{
	CIuExporters* pParent = dynamic_cast<CIuExporters*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuVersionNumber CIuExporter::GetVersionMax() const
{
	return versionExporterMax;
}

CIuVersionNumber CIuExporter::GetVersionMaxStatic()
{
	return versionExporterMax;
}

CIuVersionNumber CIuExporter::GetVersionMin() const
{
	return versionExporterMin;
}

CIuVersionNumber CIuExporter::GetVersionMinStatic()
{
	return versionExporterMin;
}

void CIuExporter::SetExtension(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExtension = pcsz;
}

void CIuExporter::SetFieldNameLength(int iFieldNameLength)
{
	m_iFieldNameLength = iFieldNameLength;
}

void CIuExporter::SetFieldNamesUnique(bool f)
{
	m_fFieldNamesUnique = f;
}

void CIuExporter::SetMaxFields(int iMaxFields)
{
	m_iMaxFields = iMaxFields;
}

void CIuExporter::SetMaxRecords(int iMaxRecords)
{
	m_iMaxRecords = iMaxRecords;
}

bool CIuExporter::SetSpec(CIuID id)
{
	// Static function to create specific, known exports
	// Initialize the CIuExporter object
	if (id == idExporterCsv)
	{
		SetDescription(_T("Comma Delimited Description"));
		SetExtension(_T("CSV"));
		SetFieldNameLength(-1);  // No Limit
		SetFieldNamesUnique(false);   // Do not require unique field names
		SetMaxFields(-1);  // No limit
		SetMaxRecords(-1); // No limit
	}
	else if (id == idExporterTab)
	{
		SetDescription(_T("Tab Delimited Description"));
		SetExtension(_T("TXT"));
		SetFieldNameLength(-1);  // do not limit field name lengths
		SetFieldNamesUnique(false);   // unique field names are NOT required
		SetMaxFields(-1);  // no limit
		SetMaxRecords(-1); // no limit
	}
	else if (id == idExporterFix)
	{
		SetDescription(_T("Fixed Length Description"));
		SetExtension(_T("TXT"));
		SetFieldNameLength(0);  // Limit field names to width of field
		SetFieldNamesUnique(false);   // Do not require unique field names
		SetMaxFields(-1);  // No limit
		SetMaxRecords(-1); // No limit
	}
	else if (id == idExporterDbf)
	{
		SetDescription(_T("dBase III Description"));
		SetExtension(_T("DBF"));
		SetFieldNameLength(10);  // Limit field names to ten characters
		SetFieldNamesUnique(true);   // unique field names are required
		SetMaxFields(127);  // max of 127 fields are supported
		SetMaxRecords(-1); // No limit
	}
	else if (id == idExporterTxt)
	{
		SetDescription(_T("Text Description"));
		SetExtension(_T("TXT"));
		SetFieldNameLength(-1);  // No Limit
		SetFieldNamesUnique(false);   // Do not require unique field names
		SetMaxFields(-1);  // No limit
		SetMaxRecords(-1); // No limit
	}
	else
	{
		// This is allowed... perhaps somebody else is providing this exporter
		return false;
	}
	SetID(id);
	SetName(GetExporterName(id));
	return true;
}

