#ifndef _ENGINE_EXPRESSIONBUILDERDLG_H_
#define _ENGINE_EXPRESSIONBUILDERDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
#ifndef 	_UI_LAYOUTMANAGER_H_
#	include "Ui\LayoutManager.h"
#endif	// _UI_LAYOUTMANAGER_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionBuilderDlg, CDialog }}
#define CIuExpressionBuilderDlg_super CDialog

class CIuExpressionBuilderDlg : public CIuExpressionBuilderDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionBuilderDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool Edit(CString& sExpression, CStringArray& asFields, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void OnDblclk(CListBox& lb);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Dialog auto-sizer item
	CIuLayoutManager m_LayoutManager;
	// The list of fields
	CStringArray m_asFields;
//}}Data

public:
	//{{AFX_DATA(CIuExpressionBuilderDlg)
	enum { IDD = IDD_ENGINE_EXPRESIONBUILDER };
	CListBox	m_ibOperators;
	CListBox	m_ibFunctions;
	CListBox	m_ibFields;
	CEdit	m_editExpression;
	CString	m_sExpression;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuExpressionBuilderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuExpressionBuilderDlg)
	afx_msg void OnDblclkFields();
	afx_msg void OnDblclkFunctions();
	afx_msg void OnDblclkOperators();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_EXPRESSIONBUILDERDLG_H_
