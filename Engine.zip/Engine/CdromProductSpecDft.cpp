#include "StdAfx.h"
//{{Include
#include "CdromProductSpecDft.h"
#include "CdromSpecConst.h"
#include "Blob.h"
#include "ReportDef.h"
#include "ExportDef.h"
#include "Registration.h"
#include "ReleaseNote.h"
#include "Splash.h"
//}}Include

#ifdef _DEBUG
#  define new DEBUG_NEW
#  undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
const TCHAR szStatesUsa[] = 
	"AK\nAL\nAR\nAZ\nCA\nCO\nCT\nDC\nDE\nFL\nGA\nHI\nIA\nID\nIL\nIN\nKS\n"
	"KY\nLA\nMA\nMD\nME\nMI\nMN\nMO\nMS\nMT\nNC\nND\nNE\nNH\nNJ\nNM\nNV\n"
	"NY\nOH\nOK\nOR\nPA\nRI\nSC\nSD\nTN\nTX\nUT\nVA\nVT\nWA\nWI\nWV\nWY";
const TCHAR szNoStates[] = _T("");
const TCHAR szTestStates[] = _T("NE");

/////////////////////////////////////////////////////////////////////////////
// Some constant strings

#define ATTR_END							0

#define ATTR_APP_CDUSA					"AppExe" "\0" "CDUSA.EXE"
#define ATTR_APP_AC						"AppExe" "\0" "AddressCorrector.exe"
#define ATTR_APP_PD						"AppExe" "\0" "PhoneDisc.exe"
#define ATTR_APP_CI						"AppExe" "\0" "CallerID.exe"
#define ATTR_APP_CONSOLE				"AppExe" "\0" "Console.exe"
#define ATTR_APP_METERADMIN			"AppExe" "\0" "MeterAdmin.exe"
#define ATTR_APP_NETADMIN				"AppExe" "\0" "NetAdmin.exe"
#define ATTR_APP_OAM						"AppExe" "\0" "OAM.exe"
#define ATTR_APP_POWERCHECK			"AppExe" "\0" "PowerCheck.exe"
#define ATTR_APP_RP						"AppExe" "\0" "ResumePlus.exe"
#define ATTR_APP_SLU						"AppExe" "\0" "SalesLeadsUSA.exe"
#define ATTR_APP_SAMPLE					"AppExe" "\0" "SampleInternal.exe"

#define ATTR_NET_INSTALL				"AllowNetInstall" "\0" "1"

#define ATTR_COPY_NOTHING				"CopyFiles" "\0" ""

#define ATTR_FOLDER_CDUSA				"FolderName" "\0" "CDUSA"
#define ATTR_FOLDER_PD					"FolderName" "\0" "PhoneDisc"
#define ATTR_FOLDER_AC					"FolderName" "\0" "Address Corrector"
#define ATTR_FOLDER_CI					"FolderName" "\0" "CallerID"
#define ATTR_FOLDER_OAM					"FolderName" "\0" "OAM"
#define ATTR_FOLDER_INFOUSA			"FolderName" "\0" "infoUSA"
#define ATTR_FOLDER_RP					"FolderName" "\0" "ResumePlus"
#define ATTR_FOLDER_SLU					"FolderName" "\0" "SalesLeads USA"

#define ATTR_ICON_104M_2001R1	      "IconName" "\0" "104 Million Businesses & Households - 2001 1st Edition"
#define ATTR_ICON_88MD_2001R1	      "IconName" "\0" "88 Million Households Deluxe - 2001 1st Edition"
#define ATTR_ICON_CDUSA				   "IconName" "\0" "CD-USA"
#define ATTR_ICON_AC_V1					"IconName" "\0" "Address Corrector - Version 1"
#define ATTR_ICON_BML_2000				"IconName" "\0" "Business Mailings Lists - 2000 Edition"
#define ATTR_ICON_CI_V1					"IconName" "\0" "CallerID - Version 1"
#define ATTR_ICON_CONSOLE				"IconName" "\0" "infoUSA Console"
#define ATTR_ICON_METERADMIN			"IconName" "\0" "infoUSA Meter Administrator"
#define ATTR_ICON_NETADMIN				"IconName" "\0" "infoUSA Network Administrator"
#define ATTR_ICON_OAM_V1				"IconName" "\0" "Open Access Method - Version 1"
#define ATTR_ICON_PF_2000R2			"IconName" "\0" "PowerFinder - 2000 2nd Edition"
#define ATTR_ICON_PG_2000R1			"IconName" "\0" "PowerFinder Government - 2000 1st Edition"
#define ATTR_ICON_PG_2000R2			"IconName" "\0" "PowerFinder Government - 2000 2nd Edition"
#define ATTR_ICON_RBOC_2000			"IconName" "\0" "infoUSA - 2000 Edition"
#define ATTR_ICON_POWERCHECK			"IconName" "\0" "Power Check"
#define ATTR_ICON_RP_V1					"IconName" "\0" "ResumePlus - Version 1"
#define ATTR_ICON_SLU_2000				"IconName" "\0" "SalesLeads USA - 2000 Edition"
#define ATTR_ICON_SAMPLE				"IconName" "\0" "Sample"
#define ATTR_ICON_PB_2001R1			"IconName" "\0" "Power Business - 2001 1st Edition"
#define ATTR_ICON_PF_2001R1			"IconName" "\0" "PowerFinder - 2001 1st Edition"
#define ATTR_ICON_PU_2001R1			"IconName" "\0" "PowerFinder USA1 - 2001 1st Edition"

#define ATTR_REDIST_MFC \
												"ReqSysFileVersions" \
												"\0" \
												"mfc42.dll,6.0.8665.0," \
												"msvcrt.dll,6.1.8637.0," \
												"msvcirt.dll,6.1.8637.0," \
												"comctl32.dll,4.72.3611.1900"

/////////////////////////////////////////////////////////////////////////////
// Some blob collections
static int aiBlobsNone[]            =  { blobNone };
static int aiBlobs104m_2001[]       =  { blob104mLicense_2001,    blobNone };
static int aiBlobs88md_2001[]       =  { blob88mdLicense_2001,    blobNone };
static int aiBlobsBml_2000[]        =  { blobBmlLicense_2000,     blobNone };
static int aiBlobsOam_V1[]          =  { blobOamLicense_V1,       blobNone };
static int aiBlobsPb_2001[]         =  { blobPbLicense_2001,      blobNone };
static int aiBlobsPf_2001[]         =  { blobPfLicense_2001,      blobNone };
static int aiBlobsPg_2000[]         =  { blobPgLicense_2000,      blobNone };
static int aiBlobsPu_2001[]         =  { blobPuLicense_2001,      blobNone };
static int aiBlobsRboc_2000[]       =  { blobRbocLicense_2000,    blobNone };
static int aiBlobsSample[]          =  { blobSampleLicense,       blobNone };
static int aiBlobsSlu_2000[]        =  { blobSluLicense_2000,     blobNone };
static int aiBlobsYpu_2001[]        =  { blobYpuLicense_2001,     blobNone };

/////////////////////////////////////////////////////////////////////////////
// Some export def collections
static int aiExportDefsNone[] =  
{ 
   exportDefNone 
};

static int aiExportDefsAll[] =
{
   exportDefSingleLine,
	exportDefAct,
	exportDefWordproMailMerge,
	exportDefAutomapStreets,
	exportDefDbaseIiIii,
	exportDefDesktopManager,
	exportDefGoldmine,
	exportDefLotusOrganizer21,
	exportDefMaximizer,
	exportDefMaplinx,
	exportDefMicrosoftWordMailMerge,
	exportDefMicrosoftOutlook,
	exportDefMymaillist,
	exportDefWordPerfectMailMerge,
	exportDefExcel,
	exportDefLotus123,
	exportDefWinfaxPro70,
	exportDefMailingLabel,
	exportDefMailingLabelWPhone,
	exportDefTabDelimited,
	exportDefCommaDelimitedWHeaders,
	exportDefCommaDelimited,
	exportDefCommaDelWLatLongDist,
	exportDefStreets2000Interoperability,
	exportDefPowerStreets,
	exportDefBusinessMapping,
	exportDefPalmPilot1,
	reportDefNone 
};

static int aiExportDefsPbm_V1[] =
{
   exportDefELetter,
		reportDefNone
};

static int aiExportDefsSlu[] =
{
   exportDefSingleLine,
	exportDefWordproMailMerge,
	exportDefAutomapStreets,
	exportDefDbaseIiIii,
	exportDefDesktopManager,
	exportDefGoldmine,
	exportDefLotusOrganizer21,
	exportDefMaximizer,
	exportDefMaplinx,
	exportDefMicrosoftWordMailMerge,
	exportDefMicrosoftOutlook,
	exportDefMymaillist,
	exportDefWordPerfectMailMerge,
	exportDefExcel,
	exportDefLotus123,
	exportDefWinfaxPro70,
	exportDefMailingLabel,
	exportDefMailingLabelWPhone,
	exportDefTabDelimited,
	exportDefCommaDelimitedWHeaders,
	exportDefCommaDelimited,
	exportDefStreets2000Interoperability,
	exportDefPowerStreets,
	exportDefBusinessMapping,
	exportDefPalmPilot1,
	reportDefNone 
};

/////////////////////////////////////////////////////////////////////////////
// Some report collections
static int aiReportDefsNone[] =  
{ 
   reportDefNone 
};

/////////////////////////////////////////////////////////////////////////////
// Product specification

static const CIuCdromProductSpecDft Product104mTest_2001 =
{
   _T("104 Million Businesses & Households Test"),cdromProduct104mTest_2001,
	szDescriptionGenerate,
	szProductGroup104m_Test_2001,
	cdromFormat104m_2001,
	_T("sample"),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mUsa_2001 =
{
   _T("104 Million Businesses & Households USA"),cdromProduct104mUsa_2001,
	szDescriptionGenerate,
	szProductGroup104m_Usa_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packDefaultSplitSize,
	szStatesUsa,
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mCentral_2001 =
{
   _T("104 Million Businesses & Households Central"),cdromProduct104mCentral_2001,
	szDescriptionGenerate,
	szProductGroup104m_Regional_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("AR\nIA\nKS\nLA\nMN\nMO\nMS\nND\nNE\nOK\nSD\nTX"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mGreatLakes_2001 =
{
   _T("104 Million Businesses & Households GreatLakes"),cdromProduct104mGreatLakes_2001,
	szDescriptionGenerate,
	szProductGroup104m_Regional_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("DC\nIL\nIN\nKY\nMD\nMI\nOH\nWI\nWV"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mSouthEast_2001 =
{
   _T("104 Million Businesses & Households SouthEast"),cdromProduct104mSouthEast_2001,
	szDescriptionGenerate,
	szProductGroup104m_Regional_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("AL\nFL\nGA\nNC\nSC\nTN\nVA"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mNorthEast_2001 =
{
   _T("104 Million Businesses & Households NorthEast"),cdromProduct104mNorthEast_2001,
	szDescriptionGenerate,
	szProductGroup104m_Regional_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("CT\nDE\nMA\nME\nNH\nNJ\nNY\nPA\nRI\nVT"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product104mWestern_2001 =
{
   _T("104 Million Businesses & Households Western"),cdromProduct104mWestern_2001,
	szDescriptionGenerate,
	szProductGroup104m_Regional_2001,
	cdromFormat104m_2001,
	_T(""),
	registration104m_2001,
	releaseNote104m_2001,
	splash104m_2001,
	aiBlobs104m_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("AK\nAZ\nCA\nCO\nHI\nID\nMT\nNM\nNV\nOR\nUT\nWA\nWY"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_104M_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdTest_2001 =
{
   _T("88 Million Households Deluxe Test"),cdromProduct88mdTest_2001,
	szDescriptionGenerate,
	szProductGroup88md_Test_2001,
	cdromFormat88md_2001,
	_T("sample"),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdUsa_2001 =
{
   _T("88 Million Households Deluxe USA"),cdromProduct88mdUsa_2001,
	szDescriptionGenerate,
	szProductGroup88md_Usa_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packDefaultSplitSize,
	szStatesUsa,
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdMidWest_2001 =
{
   _T("88 Million Households Deluxe MidWest"),cdromProduct88mdMidWest_2001,
	szDescriptionGenerate,
	szProductGroup88md_Regional_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("IL\nIN\nKY\nMI\nOH\nTN\nWI\nWV"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdSouthEast_2001 =
{
   _T("88 Million Households Deluxe SouthEast"),cdromProduct88mdSouthEast_2001,
	szDescriptionGenerate,
	szProductGroup88md_Regional_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("FL\nGA\nMD\nMS\nNC\nSC\nVA"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdCentral_2001 =
{
   _T("88 Million Households Deluxe Central"),cdromProduct88mdCentral_2001,
	szDescriptionGenerate,
	szProductGroup88md_Regional_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("AL\nAR\nIA\nKS\nLA\nMN\nMO\nNE\nOK\nSD\nTX"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdNorthEast_2001 =
{
   _T("88 Million Households Deluxe NorthEast"),cdromProduct88mdNorthEast_2001,
	szDescriptionGenerate,
	szProductGroup88md_Regional_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("CT\nDC\nDE\nMA\nME\nNH\nNJ\nNY\nPA\nRI\nVT"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft Product88mdWestern_2001 =
{
   _T("88 Million Households Deluxe Western"),cdromProduct88mdWestern_2001,
	szDescriptionGenerate,
	szProductGroup88md_Regional_2001,
	cdromFormat88md_2001,
	_T(""),
	registration88md_2001,
	releaseNote88md_2001,
	splash88md_2001,
	aiBlobs88md_2001,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	_T("AK\nAZ\nCA\nCO\nHI\nID\nMT\nND\nNM\nNV\nOR\nUT\nWA\nWY"),
   {
      ATTR_APP_CDUSA,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CDUSA,
		ATTR_ICON_88MD_2001R1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcUi_V1 =
{
   _T("Address Corrector UI"),cdromProductAcUi_V1,
	szDescriptionGenerate,
	szProductGroupAc_Ui_V1,
	cdromFormatAc_V1,
	_T("sample"),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	szNoStates,
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcTest_V1 =
{
   _T("Address Corrector Test"),cdromProductAcTest_V1,
	szDescriptionGenerate,
	szProductGroupAc_Test_V1,
	cdromFormatAc_V1,
	_T("sample"),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcUsa_V1 =
{
   _T("Address Corrector USA"),cdromProductAcUsa_V1,
	szDescriptionGenerate,
	szProductGroupAc_Usa_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packDefaultSplitSize,
	szStatesUsa,
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcMidWest_V1 =
{
   _T("Address Corrector MidWest"),cdromProductAcMidWest_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("IL\nIN\nMI\nOH\nWI"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcSouthEast_V1 =
{
   _T("Address Corrector SouthEast"),cdromProductAcSouthEast_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("AL\nAR\nFL\nKY\nLA\nMO\nMS\nTN"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcMidAtlantic_V1 =
{
   _T("Address Corrector MidAtlantic"),cdromProductAcMidAtlantic_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("DC\nDE\nGA\nMD\nNC\nPA\nSC\nVA\nWV"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcCentral_V1 =
{
   _T("Address Corrector Central"),cdromProductAcCentral_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("CO\nIA\nKS\nMN\nND\nNE\nNM\nOK\nSD\nTX"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcNorthEast_V1 =
{
   _T("Address Corrector NorthEast"),cdromProductAcNorthEast_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("CT\nMA\nME\nNH\nNJ\nNY\nRI\nVT"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductAcWestern_V1 =
{
   _T("Address Corrector Western"),cdromProductAcWestern_V1,
	szDescriptionGenerate,
	szProductGroupAc_Regional_V1,
	cdromFormatAc_V1,
	_T(""),
	registrationAc_V1,
	releaseNoteAc_V1,
	splashAc_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	_T("AK\nAZ\nCA\nHI\nID\nMT\nNV\nOR\nUT\nWA\nWY"),
   {
      ATTR_APP_AC,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_AC,
		ATTR_ICON_AC_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductBml1Test_2000 =
{
   _T("Business Mailing Lists Disk 1 Test"),cdromProductBml1Test_2000,
	szDescriptionGenerate,
	szProductGroupBml1_Test_2000,
	cdromFormatBml1_2000,
	_T(""),
	registrationBml_2000,
	releaseNoteBml_2000,
	splashBml1_2000,
	aiBlobsBml_2000,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_PD,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_PD,
		ATTR_ICON_BML_2000,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductBml1Usa_2000 =
{
   _T("Business Mailing Lists Disk 1 USA"),  cdromProductBml1Usa_2000,
	szDescriptionGenerate,
	szProductGroupBml1_Usa_2000,
	cdromFormatBml1_2000,
	_T(""),
	registrationBml_2000,
	releaseNoteBml_2000,
	splashBml1_2000,
	aiBlobsBml_2000,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szStatesUsa,
   {
      ATTR_APP_PD,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_PD,
		ATTR_ICON_BML_2000,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductBml2Test_2000 =
{
   _T("Business Mailing Lists Disk 2 Test"),cdromProductBml2Test_2000,
	szDescriptionGenerate,
	szProductGroupBml2_Test_2000,
	cdromFormatBml2_2000,
	_T(""),
	registrationBml_2000,
	releaseNoteBml_2000,
	splashBml2_2000,
	aiBlobsBml_2000,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_PD,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_PD,
		ATTR_ICON_BML_2000,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductBml2Usa_2000 =
{
   _T("Business Mailing Lists Disk 2 USA"),cdromProductBml2Usa_2000,
	szDescriptionGenerate,
	szProductGroupBml2_Usa_2000,
	cdromFormatBml2_2000,
	_T(""),
	registrationBml_2000,
	releaseNoteBml_2000,
	splashBml2_2000,
	aiBlobsBml_2000,
	aiExportDefsAll,
	aiReportDefsNone,
	packNoSplit,
	szStatesUsa,
   {
      ATTR_APP_PD,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_PD,
		ATTR_ICON_BML_2000,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiUi_V1 =
{
   _T("CallerID UI"),cdromProductCiUi_V1,
	szDescriptionGenerate,
	szProductGroupCi_Ui_V1,
	cdromFormatCi_V1,
	_T("sample"),
	registrationCi_V1,
	releaseNoteCi_V1,
	splashCi_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	szNoStates,
   {
      ATTR_APP_CI,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CI,
		ATTR_ICON_CI_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiTest_V1 =
{
   _T("CallerID Test"),cdromProductCiTest_V1,
	szDescriptionGenerate,
	szProductGroupCi_Test_V1,
	cdromFormatCi_V1,
	_T("sample"),
	registrationCi_V1,
	releaseNoteCi_V1,
	splashCi_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packNoSplit,
	szTestStates,
   {
      ATTR_APP_CI,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CI,
		ATTR_ICON_CI_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiUsa_V1 =
{
   _T("CallerID USA"),cdromProductCiUsa_V1,
	szDescriptionGenerate,
	szProductGroupCi_Usa_V1,
	cdromFormatCi_V1,
	_T(""),
	registrationCi_V1,
	releaseNoteCi_V1,
	splashCi_V1,
	aiBlobsNone,
	aiExportDefsNone,
	aiReportDefsNone,
	packDefaultSplitSize,
	szStatesUsa,
   {
      ATTR_APP_CI,
		ATTR_NET_INSTALL,
		ATTR_FOLDER_CI,
		ATTR_ICON_CI_V1,
		ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiWest_V1 =
{
   _T("CallerID West"),cdromProductCiWest_V1,
	szDescriptionGenerate,
	szProductGroupCi_Regional_V1,
	cdromFormatCi_V1,
	_T(""),
	registrationCi_V1,
	releaseNoteCi_V1,
	splashCi_V1,
	aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packDefaultSplitSize,
   _T("AK\nAZ\nCA\nCO\nHI\nID\nKS\nMN\nMT\nND\nNE\nNM\nNV\nOK\nOR\nSD\nTX\nUT\nWA\nWY"),
   {
      ATTR_APP_CI,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CI,
      ATTR_ICON_CI_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiMidWest_V1 =
{
   _T("CallerID MidWest"),cdromProductCiMidWest_V1,
   szDescriptionGenerate,
   szProductGroupCi_Regional_V1,
   cdromFormatCi_V1,
   _T(""),
   registrationCi_V1,
   releaseNoteCi_V1,
   splashCi_V1,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packDefaultSplitSize,
   _T("AL\nAR\nCT\nIA\nIL\nIN\nKY\nLA\nMI\nMO\nMS\nOH\nPA\nTN\nWI"),
   {
      ATTR_APP_CI,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CI,
      ATTR_ICON_CI_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductCiEast_V1 =
{
   _T("CallerID East"),cdromProductCiEast_V1,
   szDescriptionGenerate,
   szProductGroupCi_Regional_V1,
   cdromFormatCi_V1,
   _T(""),
   registrationCi_V1,
   releaseNoteCi_V1,
   splashCi_V1,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packDefaultSplitSize,
   _T("DC\nDE\nFL\nGA\nMA\nMD\nME\nNC\nNH\nNJ\nNY\nRI\nSC\nVA\nVT\nWV"),
   {
      ATTR_APP_CI,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CI,
      ATTR_ICON_CI_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductConsole =
{
   szFormatConsole,cdromProductConsole,
   _T("infoUSA Console"),
   szProductGroupConsole,
   cdromFormatConsole,
   _T(""),
   registrationNone,
   releaseNoteConsole,
   splashNone,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szNoStates,
   {
      ATTR_APP_CONSOLE,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_INFOUSA,
      ATTR_ICON_CONSOLE,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductMeterAdmin =
{
   szFormatMeterAdmin,cdromProductMeterAdmin,
   _T("Meter administration utility database."),
   szProductGroupNetAdmin,
   cdromFormatMeterAdmin,
   _T(""),
   registrationNone,
   releaseNoteMeterAdmin,
   splashNone,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szNoStates,
   {
      ATTR_APP_METERADMIN,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_INFOUSA,
      ATTR_ICON_METERADMIN,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductNetAdmin =
{
   szFormatNetAdmin,cdromProductNetAdmin,
   _T("Meter administration utility database."),
   szProductGroupNetAdmin,
   cdromFormatNetAdmin,
   _T(""),
   registrationNone,
   releaseNoteNetAdmin,
   splashNone,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szNoStates,
   {
      ATTR_APP_NETADMIN,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_INFOUSA,
      ATTR_ICON_NETADMIN,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductOamTest_V1 =
{
   _T("OamTest"),cdromProductOamTest_V1,
   szDescriptionGenerate,
   szProductGroupOam_Test_V1,
   cdromFormatOam_V1,
   _T(""),
   registrationNone,
   releaseNoteOam_V1,
   splashOam_V1,
   aiBlobsOam_V1,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_OAM,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_OAM,
      ATTR_ICON_OAM_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductOamUsa_V1 =
{
   _T("OamUsa"),cdromProductOamUsa_V1,
   szDescriptionGenerate,
   szProductGroupOam_Usa_V1,
   cdromFormatOam_V1,
   _T(""),
   registrationNone,
   releaseNoteOam_V1,
   splashOam_V1,
   aiBlobsOam_V1,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_OAM,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_OAM,
      ATTR_ICON_OAM_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPbTest_2001 =
{
   _T("Power Business Test 2001"),cdromProductPbTest_2001,
   szDescriptionGenerate,
   szProductGroupPb_Test_2001,
   cdromFormatPb_2001,
   _T("sample"),
   registrationPb_2001,
   releaseNotePb_2001,
   splashPb_2001,
   aiBlobsPb_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PB_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPbUsa_2001 =
{
   _T("Power Business USA 2001"),cdromProductPbUsa_2001,
   szDescriptionGenerate,
   szProductGroupPb_Usa_2001,
   cdromFormatPb_2001,
   _T(""),
   registrationPb_2001,
   releaseNotePb_2001,
   splashPb_2001,
   aiBlobsPb_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packDefaultSplitSize,
   szStatesUsa,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PB_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPbmTest_V1 =
{
   _T("Personalized Business Mailings Test"),cdromProductPbmTest_V1,
   szDescriptionGenerate,
   szProductGroupPbm_Test_V1,
   cdromFormatPbm_V1,
   _T("sample"),
   registrationPbm_V1,
   releaseNotePbm_V1,
   splashPbm_V1,
   aiBlobsNone,
   aiExportDefsPbm_V1,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_CDUSA,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CDUSA,
      ATTR_ICON_CDUSA,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPbmUsa_V1 =
{
   _T("Personalized Business Mailings USA"),cdromProductPbmUsa_V1,
   szDescriptionGenerate,
   szProductGroupPbm_Usa_V1,
   cdromFormatPbm_V1,
   _T(""),
   registrationPbm_V1,
   releaseNotePbm_V1,
   splashPbm_V1,
   aiBlobsNone,
   aiExportDefsPbm_V1,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_CDUSA,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CDUSA,
      ATTR_ICON_CDUSA,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfTest_2001 =
{
   _T("PowerFinder Test 2001"),cdromProductPfTest_2001,
   szDescriptionGenerate,
   szProductGroupPf_Test_2001,
   cdromFormatPf_2001,
   _T("sample"),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfEast_2001 =
{
   _T("PowerFinder East 2001"),cdromProductPfEast_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("CT\nDE\nMA\nMD\nME\nNC\nNJ\nRI\nVA\nVT"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfMidAtlantic_2001 =
{
   _T("PowerFinder MidAtlantic 2001"),cdromProductPfMidAtlantic_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("DC\nNH\nNY\nOH\nPA\nWV"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfMidWest_2001 =
{
   _T("PowerFinder MidWest 2001"),cdromProductPfMidWest_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AR\nIL\nIN\nKY\nMI\nTN"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfMountain_2001 =
{
   _T("PowerFinder Mountain 2001"),cdromProductPfMountain_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AZ\nCO\nID\nMT\nNM\nNV\nTX\nUT\nWY"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfNorthCentral_2001 =
{
   _T("PowerFinder NorthCentral 2001"),cdromProductPfNorthCentral_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("IA\nKS\nMN\nMO\nND\nNE\nOK\nSD\nWI"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfPacific_2001 =
{
   _T("PowerFinder Pacific 2001"),cdromProductPfPacific_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AK\nCA\nHI\nOR\nWA"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPfSouthern_2001 =
{
   _T("PowerFinder Southern 2001"),cdromProductPfSouthern_2001,
   szDescriptionGenerate,
   szProductGroupPf_Regional_2001,
   cdromFormatPf_2001,
   _T(""),
   registrationPf_2001,
   releaseNotePf_2001,
   splashPf_2001,
   aiBlobsPf_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AL\nFL\nGA\nLA\nMS\nSC"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PF_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgUsa_2000 =
{
   _T("PowerFinder Government USA"),cdromProductPgUsa_2000,
   szDescriptionGenerate,
   szProductGroupPg_Usa_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgMidWest_2000 =
{
   _T("PowerFinder Government MidWest"),cdromProductPgMidWest_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("IL\nIN\nMI\nOH\nWI"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgSouthEast_2000 =
{
   _T("PowerFinder Government SouthEast"),cdromProductPgSouthEast_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AL\nAR\nFL\nKY\nLA\nMO\nMS\nTN"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgMidAtlantic_2000 =
{
   _T("PowerFinder Government MidAtlantic"),cdromProductPgMidAtlantic_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("DC\nDE\nGA\nMD\nNC\nPA\nSC\nVA\nWV"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgCentral_2000 =
{
   _T("PowerFinder Government Central"),cdromProductPgCentral_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("CO\nIA\nKS\nMN\nND\nNE\nNM\nOK\nSD\nTX"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgNorthEast_2000 =
{
   _T("PowerFinder Government NorthEast"),cdromProductPgNorthEast_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("CT\nMA\nME\nNH\nNJ\nNY\nRI\nVT"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgTest_2000 =
{
   _T("PowerFinder Government Test"),cdromProductPgTest_2000,
   szDescriptionGenerate,
   szProductGroupPg_Test_2000,
   cdromFormatPg_2000,
   _T("sample"),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPgWestern_2000 =
{
   _T("PowerFinder Government Western"),cdromProductPgWestern_2000,
   szDescriptionGenerate,
   szProductGroupPg_Regional_2000,
   cdromFormatPg_2000,
   _T(""),
   registrationNone,
   releaseNotePg_2000,
   splashPg_2000,
   aiBlobsPg_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("AK\nAZ\nCA\nHI\nID\nMT\nNV\nOR\nUT\nWA\nWY"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PG_2000R2,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPowerCheck_2000 =
{
   szFormatPowerCheck,cdromProductPowerCheck,
   _T("Power Check Utility Database."),
   szProductGroupPowerCheck,
   cdromFormatPowerCheck,
   _T(""),
   registrationNone,
   releaseNotePowerCheck,
   splashNone,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szNoStates,
   {
      ATTR_APP_POWERCHECK,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_INFOUSA,
      ATTR_ICON_POWERCHECK,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPuTest_2001 =
{
   _T("PowerFinder USA1 Test 2001"),cdromProductPuTest_2001,
   szDescriptionGenerate,
   szProductGroupPu_Test_2001,
   cdromFormatPu_2001,
   _T("sample"),
   registrationPu_2001,
   releaseNotePu_2001,
   splashPu_2001,
   aiBlobsPu_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PU_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductPuUsa_2001 =
{
   _T("PowerFinder USA1 USA 2001"),cdromProductPuUsa_2001,
   szDescriptionGenerate,
   szProductGroupPu_Usa_2001,
   cdromFormatPu_2001,
   _T(""),
   registrationPu_2001,
   releaseNotePu_2001,
   splashPu_2001,
   aiBlobsPu_2001,
   aiExportDefsAll,
   aiReportDefsNone,
   packDefaultSplitSize,
   szStatesUsa,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_PU_2001R1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocTest_2000 =
{
   _T("Rboc Test"),cdromProductRbocTest_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Test_2000,
   cdromFormatRboc_2000,
   _T("sample"),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocGreatLakes_2000 =
{
   _T("Rboc GreatLakes"),cdromProductRbocGreatLakes_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("MI\nWI\nIL\nOH\nIN"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocSeAtlantic1_2000 =
{
   _T("Rboc SE Atlantic1"),cdromProductRbocSeAtlantic1_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("NC\nSC\nKY\nTN"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocSeAtlantic2_2000 =
{
   _T("Rboc SE Atlantic2"),cdromProductRbocSeAtlantic2_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("MS\nAL\nGA\nLA\nFL\n"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocNeAtlantic1_2000 =
{
   _T("Rboc NE Atlantic 1"),cdromProductRbocNeAtlantic1_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("NY\nME\nRI\nVT\nMA\nCT\nNH"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocNeAtlantic2_2000 =
{
   _T("Rboc NE Atlantic 2"),cdromProductRbocNeAtlantic2_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("NJ\nPA\nVA\nWV\nDC\nMD\nDE"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocPacific_2000 =
{
   _T("Rboc Pacific"),cdromProductRbocPacific_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("CA\nHI\nNV\nAK"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocSouthWest_2000 =
{
   _T("Rboc SouthWest"),cdromProductRbocSouthWest_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("KS\nMO\nOK\nAR\nTX"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRbocMidWest_2000 =
{
   _T("Rboc MidWest"),cdromProductRbocMidWest_2000,
   szDescriptionGenerate,
   szProductGroupRboc_Regional_2000,
   cdromFormatRboc_2000,
   _T(""),
   registrationNone,
   releaseNoteRboc_2000,
   splashRboc_2000,
   aiBlobsRboc_2000,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   _T("WA\nOR\nID\nMT\nUT\nWY\nND\nNM\nSD\nNE\nAZ\nCO\nIA\nMN"),
   {
      ATTR_APP_PD,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_RBOC_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductReleaseNotes =
{
   _T("ReleaseNotes"),cdromProductReleaseNotes,
   _T("Release Notes."),
   szProductGroupReleaseNotes,
   cdromFormatReleaseNotes,
   _T(""),
   registrationNone,
   releaseNoteAll,
   splashNone,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szNoStates,
   {
      0
   }
};

static const CIuCdromProductSpecDft ProductRpTest_2001 =
{
   _T("ResumePlus Test"),cdromProductRpTest_2001,
   szDescriptionGenerate,
   szProductGroupRp_Test_2001,
   cdromFormatRp_2001,
   _T("sample"),
   registrationRp_2001,
   releaseNoteRp_2001,
   splashRp_2001,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_RP,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_RP,
      ATTR_ICON_RP_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductRpUsa_2001 =
{
   _T("ResumePlus USA"),cdromProductRpUsa_2001,
   szDescriptionGenerate,
   szProductGroupRp_Usa_2001,
   cdromFormatRp_2001,
   _T(""),
   registrationRp_2001,
   releaseNoteRp_2001,
   splashRp_2001,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_RP,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_RP,
      ATTR_ICON_RP_V1,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductSluTest_2000 =
{
   _T("SalesLeadsUSA Test"),cdromProductSluTest_2000,
   szDescriptionGenerate,
   szProductGroupSlu_Test_2000,
   cdromFormatSlu_2000,
   _T("sample"),
   registrationSlu_2000,
   releaseNoteSlu_2000,
   splashSlu_2000,
   aiBlobsSlu_2000,
   aiExportDefsSlu,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_SLU,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_SLU,
      ATTR_ICON_SLU_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductSluUsa_2000 =
{
   _T("SalesLeadsUSA USA"),cdromProductSluUsa_2000,
   szDescriptionGenerate,
   szProductGroupSlu_Usa_2000,
   cdromFormatSlu_2000,
   _T(""),
   registrationSlu_2000,
   releaseNoteSlu_2000,
   splashSlu_2000,
   aiBlobsSlu_2000,
   aiExportDefsSlu,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_SLU,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_SLU,
      ATTR_ICON_SLU_2000,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductSample =
{
   _T("Sample"),cdromProductSample,
   szDescriptionGenerate,
   szProductGroupSample,
   cdromFormatSample,
   _T(""),
   registrationSample,
   releaseNoteSample,
   splashSample,
   aiBlobsSample,
   aiExportDefsAll,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_SAMPLE,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_PD,
      ATTR_ICON_SAMPLE,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductYpuTest_2001 =
{
   _T("YellowPagesUSA Test"),cdromProductYpuTest_2001,
   szDescriptionGenerate,
   szProductGroupYpu_Test_2001,
   cdromFormatYpu_2001,
   _T("sample"),
   registrationYpu_2001,
   releaseNoteYpu_2001,
   splashYpu_2001,
   aiBlobsYpu_2001,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szTestStates,
   {
      ATTR_APP_CDUSA,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CDUSA,
      ATTR_ICON_CDUSA,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft ProductYpuUsa_2001 =
{
   _T("YellowPagesUSA USA"),cdromProductYpuUsa_2001,
   szDescriptionGenerate,
   szProductGroupYpu_Usa_2001,
   cdromFormatYpu_2001,
   _T(""),
   registrationYpu_2001,
   releaseNoteYpu_2001,
   splashYpu_2001,
   aiBlobsNone,
   aiExportDefsNone,
   aiReportDefsNone,
   packNoSplit,
   szStatesUsa,
   {
      ATTR_APP_CDUSA,
      ATTR_NET_INSTALL,
      ATTR_FOLDER_CDUSA,
      ATTR_ICON_CDUSA,
      ATTR_COPY_NOTHING,
		ATTR_REDIST_MFC,
		ATTR_END
   }
};

static const CIuCdromProductSpecDft* apProduct[] = 
{
   &Product104mTest_2001,
   &Product104mUsa_2001,
   &Product104mCentral_2001,
   &Product104mGreatLakes_2001,
   &Product104mSouthEast_2001,
   &Product104mNorthEast_2001,
   &Product104mWestern_2001,
   &Product88mdTest_2001,
   &Product88mdUsa_2001,
   &Product88mdMidWest_2001,
   &Product88mdSouthEast_2001,
   &Product88mdCentral_2001,
   &Product88mdNorthEast_2001,
   &Product88mdWestern_2001,
   &ProductAcUi_V1,
   &ProductAcTest_V1,
   &ProductAcUsa_V1,
   &ProductAcMidWest_V1,
   &ProductAcSouthEast_V1,
   &ProductAcMidAtlantic_V1,
   &ProductAcCentral_V1,
   &ProductAcNorthEast_V1,
   &ProductAcWestern_V1,
   &ProductBml1Test_2000,
   &ProductBml1Usa_2000,
   &ProductBml2Test_2000,
   &ProductBml2Usa_2000,
   &ProductCiTest_V1,
   &ProductCiUi_V1,
   &ProductCiUsa_V1,
   &ProductCiWest_V1,
   &ProductCiMidWest_V1,
   &ProductCiEast_V1,
   &ProductConsole,
   &ProductMeterAdmin,
   &ProductNetAdmin,
   &ProductPbTest_2001,
   &ProductPbUsa_2001,
   &ProductOamTest_V1,
   &ProductOamUsa_V1,
   &ProductPbmTest_V1,
   &ProductPbmUsa_V1,
   &ProductPfTest_2001,
   &ProductPfEast_2001,
   &ProductPfMidAtlantic_2001,
   &ProductPfMidWest_2001,
   &ProductPfMountain_2001,
   &ProductPfNorthCentral_2001,
   &ProductPfPacific_2001,
   &ProductPfSouthern_2001,
   &ProductPgUsa_2000,
   &ProductPgMidWest_2000,
   &ProductPgSouthEast_2000,
   &ProductPgMidAtlantic_2000,
   &ProductPgCentral_2000,
   &ProductPgNorthEast_2000,
   &ProductPgTest_2000,
   &ProductPgWestern_2000,
   &ProductPowerCheck_2000,
   &ProductPuTest_2001,
   &ProductPuUsa_2001,
   &ProductRbocTest_2000,
   &ProductRbocGreatLakes_2000,
   &ProductRbocSeAtlantic1_2000,
   &ProductRbocSeAtlantic2_2000,
   &ProductRbocNeAtlantic1_2000,
   &ProductRbocNeAtlantic2_2000,
   &ProductRbocPacific_2000,
   &ProductRbocSouthWest_2000,
   &ProductRbocMidWest_2000,
   &ProductReleaseNotes,
   &ProductRpTest_2001,
   &ProductRpUsa_2001,
   &ProductSluTest_2000,
   &ProductSluUsa_2000,
   &ProductSample,
   &ProductYpuTest_2001,
   &ProductYpuUsa_2001,
};

/////////////////////////////////////////////////////////////////////////////
// CIuCdromProductSpecDft

int CIuCdromProductSpecDft::Find(LPCTSTR pcszProduct)
{
   ASSERT(AfxIsValidString(pcszProduct));
   for (int i = 0; i < GetCount(); ++i)
   {
      if (_tcsicmp(Get(i)->m_pcszProduct,pcszProduct) == 0)
         return i;
   }
   return -1;
}

int CIuCdromProductSpecDft::Find(int iProduct)
{
   for (int i = 0; i < GetCount(); ++i)
   {
      if (Get(i)->m_iProduct == iProduct)
         return i;
   }
   return -1;
}

const CIuCdromProductSpecDft* CIuCdromProductSpecDft::Get(int iWhich)
{
   ASSERT(iWhich >= 0 && iWhich < GetCount());
   return apProduct[iWhich];
}

int CIuCdromProductSpecDft::GetCount()
{
   return sizeof(apProduct) / sizeof(apProduct[0]);
}


