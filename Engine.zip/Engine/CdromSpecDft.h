#ifndef _ENGINE_CDROMSPECDFT_H_
#define _ENGINE_CDROMSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_ID_H_
#	include "Interop\Id.h"
#endif	// _INTEROP_ID_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

// NOTES:
// This file contains the raw data used to create a cd-rom specification.
//	A large number of components can go into creating a full specification. 
// Normally, the specification is passed as part of the "SetSpec()" call
// used to set up the build.
// The CD-ROM specifications have two components:
//		* Product information which stays the same from release to release. 
//		* Release information which can change for each product release.

/////////////////////////////////////////////////////////////////////////////
// The master record used to create a full cd-rom specification
// Note: a master specification does not have a name. It is identified
// by the composite of its individual component names.
struct CIuCdromSpecDft
{
public:
	static int Find(LPCTSTR pcszName);
	static int Find(int iProductNo, LPCTSTR pcszRelease);
	static const CIuCdromSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The full name of this release. This is a short, internal indentifier
	// CD-ROM's don't have a numeric identifier... not really needed
	LPCTSTR m_pcszCdrom;
	// These are ID's which are specific to this release
	// If null, a new id is generated, however, be careful because
	// we usually _require_ consistent ID's on CD's of the same product.
	const CIuID* m_pidCdrom;
	// This is the title for the release (i.e "PowerFinder Western - 2000 1st Edition")
	// This is used as the title of the CD-ROM
	LPCTSTR m_pcszTitle;
	// The product name (i.e "PowerFinder Western")
	int m_iProductNo;
	// A string describing the release (i.e. "2000 1st Edition")
	LPCTSTR m_pcszRelease;
	// The filename prefix. All files related to this release use this prefix.
	LPCTSTR m_pcszFilename;
	// Group No/Count
	int m_iGroupNo;
	int m_iGroupCount;
	//	Primary meter
	int m_iMeterNo;
	// A list of secondary meter objects carried (usually previous releases)
	//	Can be null
	int* m_piOtherMeterNo;
};


/////////////////////////////////////////////////////////////////////////////
//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMSPECDFT_H_
