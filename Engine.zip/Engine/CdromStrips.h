#ifndef _ENGINE_CDROMSTRIPS_H_
#define _ENGINE_CDROMSTRIPS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSTRIP_H_
#	include "Engine\CdromStrip.h"
#endif	// _ENGINE_CDROMSTRIP_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdromStrips)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromStrips, CIuCollection }}
#define CIuCdromStrips_super CIuCollection

class CIuCdromStrips : public CIuCdromStrips_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromStrips)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromStrips();
	virtual ~CIuCdromStrips();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromStrip& Get(const CIuMoniker& moniker) const;
	CIuCdromStrip& Get(LPCTSTR s) const;
	CIuCdromStrip& Get(int iIndex) const;
	CIuCdromStrip& Get(CIuID id) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags);
	void Delete(CIuOutput* pOutput);
	void CreateStrip(CIuCdromStripSpec& StripSpec);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromStrip& CIuCdromStrips::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuCdromStrip*>(&CIuCollection::Get(moniker));
}

inline CIuCdromStrip& CIuCdromStrips::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuCdromStrip*>(&CIuCollection::Get(s));
}

inline CIuCdromStrip& CIuCdromStrips::Get(int iIndex) const
{
	return *dynamic_cast<CIuCdromStrip*>(&CIuCollection::Get(iIndex));
}

inline CIuCdromStrip& CIuCdromStrips::Get(CIuID id) const
{
	return *dynamic_cast<CIuCdromStrip*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_CDROMSTRIPS_H_
