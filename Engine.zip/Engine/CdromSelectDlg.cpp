#include "stdafx.h"
#include "CdromSelectDlg.h"
#include "CdromSpec.h"
#include "CdromSpecDft.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CIuCdromSelectDlg::CIuCdromSelectDlg(CWnd* pParent /*=NULL*/) : CIuCdromSelectDlg_super(CIuCdromSelectDlg::IDD, pParent) 
{
	//{{Initialize
	m_iSpec = -1;
	m_iMaxRecords = -1;
	//}}Initialize

	//{{AFX_DATA_INIT(CIuCdromSelectDlg)
	//}}AFX_DATA_INIT
#ifdef _DEBUG
	m_MaxRecordNo = 1; // First 1K records
#else
	m_MaxRecordNo = 0; // All records
#endif
}

void CIuCdromSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuCdromSelectDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuCdromSelectDlg)
	DDX_Control(pDX, IDC_ENGINE_EDIT, m_btnEdit);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDC_ENGINE_TREE, m_Tree);
	DDX_Radio(pDX, IDC_ENGINE_ALL, m_MaxRecordNo);
	//}}AFX_DATA_MAP
}

const UINT wmCheckUpdate = RegisterWindowMessage("CIuCdromSelectDlgEvent");

BEGIN_MESSAGE_MAP(CIuCdromSelectDlg, CIuCdromSelectDlg_super)
	//{{AFX_MSG_MAP(CIuCdromSelectDlg)
	ON_BN_CLICKED(IDC_ENGINE_EDIT, OnEdit)
	ON_NOTIFY(TVN_SELCHANGED, IDC_ENGINE_TREE, OnSelchangedTree)
	ON_NOTIFY(NM_DBLCLK, IDC_ENGINE_TREE, OnDblclkTree)
	ON_NOTIFY(NM_CLICK, IDC_ENGINE_TREE, OnClickTree)
	ON_NOTIFY(TVN_KEYDOWN, IDC_ENGINE_TREE, OnKeydownTree)
	//}}AFX_MSG_MAP
	// This registers the handler for engine listener events
	ON_REGISTERED_MESSAGE(wmCheckUpdate, OnCheckUpdate)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCdromSelectDlg::CreateApplications()
{
	m_Entries.RemoveAll();
	m_Tree.DeleteAllItems();

	// Add the application names to the tree
	CStringArray asApplications;
	CIuCdromSpec::GetApplications(asApplications);
	for (int iApplication = 0; iApplication < asApplications.GetSize(); ++iApplication)
	{
		LPCTSTR pcszApplication = asApplications[iApplication];

		HTREEITEM hApplication = m_Tree.InsertItem(pcszApplication, TVI_ROOT);
		VERIFY(m_Tree.SetItemData(hApplication, DWORD(m_Entries.GetSize())));

		CIuCdromSelectEntry Entry(hApplication, pcszApplication);
		m_Entries.Add(Entry);

		CreateReleases(asApplications[iApplication], hApplication);
	}
}

void CIuCdromSelectDlg::CreateProductGroups(LPCTSTR pcszApplication, LPCTSTR pcszRelease, HTREEITEM hRelease)
{
	ASSERT(AfxIsValidString(pcszApplication));

	CStringArray asProductGroups;
	CIuCdromSpec::GetProductGroups(pcszApplication, pcszRelease, asProductGroups);

	// Add the ProductGroup names to the tree
	for (int iProductGroup = 0; iProductGroup < asProductGroups.GetSize(); ++iProductGroup)
	{
		LPCTSTR pcszProductGroup = asProductGroups[iProductGroup];

		HTREEITEM hProductGroup = m_Tree.InsertItem(pcszProductGroup, hRelease);
		VERIFY(m_Tree.SetItemData(hProductGroup, DWORD(m_Entries.GetSize())));

		CIuCdromSelectEntry Entry(hProductGroup, pcszApplication, pcszRelease, pcszProductGroup);
		m_Entries.Add(Entry);

		CreateProducts(pcszApplication, pcszRelease, pcszProductGroup, hProductGroup);
	}
}

void CIuCdromSelectDlg::CreateProducts(LPCTSTR pcszApplication, LPCTSTR pcszRelease, LPCTSTR pcszProductGroup, HTREEITEM hProductGroup)
{
	ASSERT(AfxIsValidString(pcszApplication));
	ASSERT(AfxIsValidString(pcszRelease));

	CStringArray asProducts;
	CIuCdromSpec::GetProducts(pcszApplication, pcszRelease, pcszProductGroup, asProducts);

	// Add the Cdrom names to the tree
	for (int iProduct = 0; iProduct < asProducts.GetSize(); ++iProduct)
	{
		LPCTSTR pcszProduct = asProducts[iProduct];

		int iSpec = CIuCdromSpec::FindProductRelease(pcszProduct, pcszRelease);
		ASSERT(iSpec >= 0);

		HTREEITEM hProduct = m_Tree.InsertItem(pcszProduct, hProductGroup);
		VERIFY(m_Tree.SetItemData(hProduct, DWORD(m_Entries.GetSize())));

		if (iSpec == m_iSpec)
		{
			m_Tree.EnsureVisible(hProduct);
			m_Tree.SelectItem(hProduct);
		}

		CIuCdromSelectEntry Entry(hProduct, pcszApplication, pcszRelease, pcszProductGroup, pcszProduct, iSpec);
		m_Entries.Add(Entry);
	}
}

void CIuCdromSelectDlg::CreateReleases(LPCTSTR pcszApplication, HTREEITEM hApplication)
{
	ASSERT(AfxIsValidString(pcszApplication));

	CStringArray asReleases;
	CIuCdromSpec::GetReleases(pcszApplication, asReleases);

	// Add the Release names to the tree
	for (int iRelease = 0; iRelease < asReleases.GetSize(); ++iRelease)
	{
		LPCTSTR pcszRelease = asReleases[iRelease];

		HTREEITEM hRelease = m_Tree.InsertItem(pcszRelease, hApplication);
		VERIFY(m_Tree.SetItemData(hRelease, DWORD(m_Entries.GetSize())));

		CIuCdromSelectEntry Entry(hRelease, pcszApplication, pcszRelease);
		m_Entries.Add(Entry);

		CreateProductGroups(pcszApplication, pcszRelease, hRelease);
	}
}

void CIuCdromSelectDlg::GetEntries(CIuCdromSelectEntryArray& Entries) const
{
	Entries.Copy(m_Entries);
	
}

LRESULT CIuCdromSelectDlg::OnCheckUpdate(WPARAM, LPARAM)
{
	Update();
	return LRESULT(0);
}

void CIuCdromSelectDlg::OnClickTree(NMHDR*, LRESULT* pResult)
{
	PostMessage(wmCheckUpdate);
	*pResult = 0;
}

void CIuCdromSelectDlg::OnDblclkTree(NMHDR*, LRESULT* pResult) 
{
	*pResult = 0;
	OnEdit();
}

void CIuCdromSelectDlg::OnEdit() 
{
	HTREEITEM hCurSel = m_Tree.GetNextItem(TVI_ROOT, TVGN_CARET);
	if (hCurSel == 0)
		return ;

	int iEntry = m_Tree.GetItemData(hCurSel);
	if (iEntry < 0)
		return ;

	CIuCdromSelectEntry Entry = m_Entries.GetAt(iEntry);
	if (Entry.GetSpecNo() < 0)
		return ;

	CIuCdromSpec Spec;
	Spec.FromIndex(Entry.GetSpecNo());
	Spec.Edit(0, this);
}

BOOL CIuCdromSelectDlg::OnInitDialog() 
{
	CIuCdromSelectDlg_super::OnInitDialog();

	m_btnOK.EnableWindow(false);
	m_btnEdit.EnableWindow(false);

	m_LayoutManager.Attach(this);

	m_LayoutManager.AddChild(IDC_ENGINE_TREE);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_TREE,			OX_LMS_TOP,    OX_LMT_SAME,		iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_TREE,			OX_LMS_BOTTOM, OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_TREE,			OX_LMS_RIGHT,  OX_LMT_OPPOSITE, -iWindowMargin, IDC_ENGINE_MAX_RECORDS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_TREE,			OX_LMS_LEFT,   OX_LMT_SAME,		iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_TOP,		OX_LMT_SAME,		iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_TOP,		OX_LMT_OPPOSITE,	iWindowMargin, IDOK);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_EDIT,			OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_EDIT,			OX_LMS_TOP,		OX_LMT_OPPOSITE,	2 * iWindowMargin, IDCANCEL);

	m_LayoutManager.SetConstraint(IDC_ENGINE_MAX_RECORDS,	OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_MAX_RECORDS,	OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_ALL,			OX_LMS_LEFT,	OX_LMT_SAME,		2 * iWindowMargin, IDC_ENGINE_MAX_RECORDS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_ALL,			OX_LMS_TOP,		OX_LMT_SAME,		3 * iWindowMargin, IDC_ENGINE_MAX_RECORDS);

	m_LayoutManager.SetConstraint(IDC_ENGINE_1K,				OX_LMS_LEFT,	OX_LMT_SAME,		0,					IDC_ENGINE_ALL);
	m_LayoutManager.SetConstraint(IDC_ENGINE_1K,				OX_LMS_TOP,		OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_ALL);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_10K,			OX_LMS_LEFT,	OX_LMT_SAME,		0,					IDC_ENGINE_1K);
	m_LayoutManager.SetConstraint(IDC_ENGINE_10K,			OX_LMS_TOP,		OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_1K);

	m_LayoutManager.SetConstraint(IDC_ENGINE_100K,			OX_LMS_LEFT,	OX_LMT_SAME,		0,					IDC_ENGINE_10K);
	m_LayoutManager.SetConstraint(IDC_ENGINE_100K,			OX_LMS_TOP,		OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_10K);

	// Set the minimum size of the window
	m_LayoutManager.SetMinMax(IDC_ENGINE_TREE, CSize(200,50));
	
	// Draw the layout with the new constraints
	// This is necessary when constraints are implemented and the window must be refreshed
	m_LayoutManager.RedrawLayout();

	CreateApplications();

	CenterWindow();

	return true; 
}

void CIuCdromSelectDlg::OnOK() 
{
	UpdateData();
	Update();

	HTREEITEM hCurSel = m_Tree.GetNextItem(TVI_ROOT, TVGN_CARET);

	if (hCurSel == 0)
		SetSpec(-1);
	else
	{
		int iEntry = m_Tree.GetItemData(hCurSel);
		if (iEntry >= 0)
		{
			CIuCdromSelectEntry Entry = m_Entries.GetAt(iEntry);
			if (Entry.GetSpecNo() >= 0)
				SetSpec(Entry.GetSpecNo());
		}
	}

	switch (m_MaxRecordNo)
	{
		case 0:
			m_iMaxRecords = -1;
			break;
		case 1:
			m_iMaxRecords = 1000;
			break;
		case 2:
			m_iMaxRecords = 10000;
			break;
		case 3:
			m_iMaxRecords = 100000;
			break;
	}
	CIuCdromSelectDlg_super::OnOK();
}

void CIuCdromSelectDlg::OnKeydownTree(NMHDR*, LRESULT* pResult)
{
	PostMessage(wmCheckUpdate);
	*pResult = 0;
}

void CIuCdromSelectDlg::OnSelchangedTree(NMHDR*, LRESULT* pResult) 
{
	PostMessage(wmCheckUpdate);
	*pResult = 0;
}


void CIuCdromSelectDlg::SetMaxRecords(int iMaxRecords)
{
	switch (iMaxRecords)
	{
		default:
		case -1:
			m_MaxRecordNo = 0;
			m_iMaxRecords = -1;
			break;
		case 1000:
			m_MaxRecordNo = 1;
			m_iMaxRecords = iMaxRecords;
			break;
		case 10000:
			m_MaxRecordNo = 2;
			m_iMaxRecords = iMaxRecords;
			break;
		case 100000:
			m_MaxRecordNo = 3;
			m_iMaxRecords = iMaxRecords;
			break;
	}
}

void CIuCdromSelectDlg::SetSpec(int iSpec)
{
	m_iSpec = iSpec;
}

void CIuCdromSelectDlg::SetSpec(LPCTSTR pcszCurrent)
{
	m_iSpec = CIuCdromSpecDft::Find(pcszCurrent);
}

void CIuCdromSelectDlg::Update()
{
	bool fCheck = false;
	for (int iEntry = 0; iEntry < m_Entries.GetSize(); ++iEntry)
	{
		CIuCdromSelectEntry& Entry = m_Entries.ElementAt(iEntry);
	
		bool fOldCheck = Entry.IsChecked() != 0;
		bool fNewCheck = m_Tree.GetCheck(Entry.GetItem()) != 0;
		if (fNewCheck && Entry.GetSpecNo() >= 0)
			fCheck = true;
		if (fOldCheck != fNewCheck)
		{
			Entry.SetChecked(fNewCheck);
			m_Tree.Expand(Entry.GetItem(), TVE_EXPAND);

			for (int iChildEntry = iEntry + 1; iChildEntry < m_Entries.GetSize(); ++iChildEntry)
			{
				CIuCdromSelectEntry& ChildEntry = m_Entries.ElementAt(iChildEntry);

				// Never recurse into an entry from a product
				if (!Entry.GetProduct().IsEmpty())
					break;

				// Application must always match
				if (Entry.GetApplication().CompareNoCase(ChildEntry.GetApplication()) != 0)
					break;

				// If I have a release, the child must match it
				if (!Entry.GetRelease().IsEmpty())
				{
					if (Entry.GetRelease().CompareNoCase(ChildEntry.GetRelease()) != 0)
						break;

					// If I have a group, the child must match it
					if (!Entry.GetGroup().IsEmpty())
					{
						if (Entry.GetGroup().CompareNoCase(ChildEntry.GetGroup()) != 0)
							break;
					}
				}

				ChildEntry.SetChecked(fNewCheck);
				m_Tree.SetCheck(ChildEntry.GetItem(), fNewCheck);
				m_Tree.Expand(ChildEntry.GetItem(), TVE_EXPAND);

				if (fNewCheck && ChildEntry.GetSpecNo() >= 0)
					fCheck = true;

				iEntry = iChildEntry + 1;
			}
		}
	}

	int iSpecNo = -1;
	HTREEITEM hCurSel = m_Tree.GetNextItem(TVI_ROOT, TVGN_CARET);
	if (hCurSel != 0)
	{
		int iEntry = m_Tree.GetItemData(hCurSel);
		if (iEntry >= 0)
		{
			CIuCdromSelectEntry Entry = m_Entries.GetAt(iEntry);
			if (Entry.GetSpecNo() >= 0)
				iSpecNo = Entry.GetSpecNo();
		}
	}

	m_btnOK.EnableWindow(iSpecNo >= 0 || fCheck);
	m_btnEdit.EnableWindow(iSpecNo >= 0);
}
