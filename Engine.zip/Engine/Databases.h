#ifndef _ENGINE_DATABASES_H_
#define _ENGINE_DATABASES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_DATABASE_H_
#	include "Engine\Database.h"
#endif	// _ENGINE_DATABASE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuDatabases)
class CIuEngine;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDatabases, CIuDatabases_super }}

#define CIuDatabases_super CIuCollection

class IU_CLASS_EXPORT CIuDatabases : public CIuDatabases_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuDatabases)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDatabases();
	virtual ~CIuDatabases();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuDatabase& Get(LPCTSTR s) const;
	CIuDatabase& Get(int iIndex) const;
	CIuDatabase& Get(CIuID id) const;
	CIuDatabasePtr GetCurrent() const;
	CIuEngine& GetEngine() const;
	bool HasCurrent() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool SelectDlg(CIuID& id, int iFlags = 0, CWnd* pParent = 0);
	bool SelectDlgEx(CIuID& id, int iFlags = 0, LPCTSTR pcszApplication = 0, CWnd* pParent = 0);
	void SetCurrent(CIuDatabase* pDatabase);
	void SetEngine(CIuEngine& Engine);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	void OnRemove(int iIndex);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionSelectDlg(const CIuPropertyCollection& collection, CIuOutput&);
protected:
	void CommonConstruct();
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
	CIuDatabasePtr m_pDatabaseCurrent;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuDatabase& CIuDatabases::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuDatabase*>(&CIuCollection::Get(s));
}

inline CIuDatabase& CIuDatabases::Get(int iIndex) const
{
	return *dynamic_cast<CIuDatabase*>(&CIuCollection::Get(iIndex));
}

inline CIuDatabase& CIuDatabases::Get(CIuID id) const
{
	return *dynamic_cast<CIuDatabase*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuDatabases::GetEngine() const
{
	ASSERT(HasEngine());
	return *m_pEngine;
}

inline bool CIuDatabases::HasCurrent() const
{
	return m_pDatabaseCurrent.NotNull();
}

inline bool CIuDatabases::HasEngine() const
{
	return m_pEngine != 0;
}

#endif 

