#ifndef _ENGINE_BTREEPOINTERS_H_
#define _ENGINE_BTREEPOINTERS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_COMMON_BITBUFFER_H_
#	include "Common\BitBuffer.h"
#endif	// _COMMON_BITBUFFER_H_
#ifndef 	_COMMON_NYBBLEINT_H_
#	include "Common\NybbleInt.h"
#endif	// _COMMON_NYBBLEINT_H_
#ifndef 	_COMMON_NYBBLESTRING_H_
#	include "Common\NybbleString.h"
#endif	// _COMMON_NYBBLESTRING_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreePointers)
IU_DEFINE_OBJECT_PTR(CIuBTree)
class CIuCdrom;
class CIuSetList;
class CIuSetLists;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreePointers, CIuObject }}
#define CIuBTreePointers_super CIuObject

class CIuBTreePointers : public CIuBTreePointers_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreePointers)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreePointers();
	virtual ~CIuBTreePointers();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	DWORD Get(int iPointer);
	int GetBitsPerPointer() const;
	int GetBlocks() const;
	int GetBlockSize() const;
	CIuBTree& GetBTree() const;
	CIuObjectRepository& GetObjectRepository() const;
	int GetPointers() const;
	CIuVersionNumber GetVersion() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool IsOpen() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool AddSetList(CIuSetLists& SetList, CIuOutput* pOutput, CIuID& ID, UINT32 uiLo, UINT32 uiCount, UINT32 uiMin = 0, UINT32 uiMax = UINT32(-1));
	void Append(const CDWordArray& adw);
	void Append(DWORD dwPointerNo);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close();
	void Create(CIuOutput& Output);
	void Delete(CIuOutput* pOutput);
	void Open(bool fDebug);
	bool SanityCheck(CIuOutput& Output);
	void SetBitsPerPointer(int iBits);
	void SetBlocks(int i);
	void SetBTree(CIuBTreePtr BTree);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetPointers(int iPointers);
	void SetSpec(CIuBTreeSpec& Spec);
	void SetVersion(CIuVersionNumber);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	CString GetFilename() const;
	CString GetFullFilename() const;
	void ReadBlock(int iBlock);
	void WriteBlock();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBTree* m_pBTree;
	// Some member variables (these allocate memory... they are class members for performance).
	// These variables should only be used locally to a function.
		CIuNybbleString m_ns;
		CIuNybbleInt m_ni;
	// File pointers used during creation
	CIuPrefixFilePtr m_pFile;
	CIuFileVirtualPtr m_pVFile;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;

	int m_iBlock;
	int m_iBlocks;
	bool m_fAppending;
	int m_iPointers;
	int m_iBitsPerPointer;
	CIuBitBuffer m_block;
	CIuVersionNumber m_verVersion;

	// Some non-persistent data
	int m_iPointersPerBlock;

//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBTreePointers::GetBitsPerPointer() const
{
	return m_iBitsPerPointer;
}

inline int CIuBTreePointers::GetBlocks() const
{
	return m_iBlocks;
}

inline CIuBTree& CIuBTreePointers::GetBTree() const
{
	return *m_pBTree;
}

inline CIuObjectRepository& CIuBTreePointers::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline int CIuBTreePointers::GetPointers() const
{
	return m_iPointers;
}

inline CIuVersionNumber CIuBTreePointers::GetVersion() const
{
	return m_verVersion;
}

inline bool CIuBTreePointers::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_BTREEPOINTERS_H_
