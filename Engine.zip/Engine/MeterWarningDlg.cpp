#include "stdafx.h"
#include "MeterWarningDlg.h"
#include "Meter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterWarningDlg, CIuMeterWarningDlg_super)
	//{{AFX_MSG_MAP(CIuMeterWarningDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterWarningDlg::CIuMeterWarningDlg(CWnd* pParent /*=NULL*/) : CIuMeterWarningDlg_super(CIuMeterWarningDlg::IDD, pParent)
{
	//{{Initialize
	m_pMeter = 0;
	m_fNoWarningBitmap = false;
	//}}Initialize

	//{{AFX_DATA_INIT(CIuMeterWarningDlg)
	//}}AFX_DATA_INIT
}

void CIuMeterWarningDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterWarningDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterWarningDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuMeterWarningDlg::DoDialog(CIuMeter& Meter, CWnd* pParent)
{
	CIuMeterWarningDlg Dlg(pParent);
	Dlg.SetMeter(&Meter);
	Dlg.DoModal();
}

BOOL CIuMeterWarningDlg::OnInitDialog() 
{
	CIuMeterWarningDlg_super::OnInitDialog();
	ASSERT(m_pMeter);

	SetWindowText(m_pMeter->GetTitle());

	m_fNoWarningBitmap = (m_pMeter->GetFlags() & meterFlagNotifyNoWarning) != 0;

	COleDateTime dtExpires = m_pMeter->GetExpireDate();
	CString sExpires;
	if (dtExpires.GetStatus() == COleDateTime::valid)
		sExpires = dtExpires.Format("%B %d, %Y");

	CString sWarningText = m_pMeter->GetWarningText();
	static const TCHAR szTab[] = _T("     ");
	if (sWarningText.IsEmpty())
	{
		if (!sExpires.IsEmpty())
		{
			// This is the default message for PG.
			// They want it very simple!
			// Also... no "WARNING" bitmap for the default display...
			m_fNoWarningBitmap = true;
			m_sWarning += "&<&s12This product contains old data.\n\n";
			m_sWarning += "&<&s12It will expire on:\n&^";
			m_sWarning += szTab;
			m_sWarning += sExpires;
			m_sWarning += _T("\n");
		}
		else
		{
			// This is a more advanced message for non-expiring products
			m_sWarning += "&^&s11Please &udo not&n use this product.\n";
			m_sWarning += "You will not find current information\n";
			m_sWarning += "on this product, it is obsolete!\n";
			m_sWarning += "The information in our database\n";
			m_sWarning += "changes over &b40%&n each year.\n";
		}
	}
	else
	{
		m_sWarning += sWarningText;
		m_sWarning += _T("\n");
		m_sWarning += _T("\n");
		// Append expire date if any.
		if (!sExpires.IsEmpty())
		{
			m_sWarning += "&^&s11This product will expire on:\n&^";
			m_sWarning += szTab;
			m_sWarning += sExpires;
			m_sWarning += _T("\n");
		}
	}

	CString sPhone = m_pMeter->GetPhone();
	if (!sPhone.IsEmpty())
	{
		if (sPhone.GetAt(0) == '(')
		{
			m_sPhone += _T("&n&s14&<");
			m_sPhone += _T("To get the most current product available\n");
			m_sPhone += _T("Call: &b");
			m_sPhone += sPhone;
		}
		else
		{
			// Do some replacing, then append the phone
			m_sPhone += _T("&n&s12&<");
			sPhone.Replace(_T("\r\n"), _T("\n"));
			sPhone.Replace(_T("\n"), _T("\n&<"));
			sPhone.Replace(_T("\t"), "&>");
			m_sPhone += sPhone;
		}
	}

	// Load the warning bitmap if in use
	// Start with a default size
	const int iMargin = 7;
	CSize csWarning = m_Text.GetTextSize(m_sWarning);
	CSize csPhone = m_Text.GetTextSize(m_sPhone);
	// Add iMargin to allow for tab between phone number and label.
	csPhone.cx += iMargin;
	if (!m_fNoWarningBitmap)
	{
		VERIFY(m_WarningBitmp.LoadBitmap(IDB_ENGINE_WARNING));
		m_rectWarningBitmap.left = iMargin;
		m_rectWarningBitmap.right = m_rectWarningBitmap.left + m_WarningBitmp.GetWidth();
		m_rectWarningBitmap.top = iMargin;
		m_rectWarningBitmap.bottom = m_rectWarningBitmap.top + m_WarningBitmp.GetHeight();

		m_rectWarning.left = m_rectWarningBitmap.right + iMargin;
		m_rectWarning.right = m_rectWarning.left + csWarning.cx;
		m_rectWarning.top = iMargin;
		m_rectWarning.bottom = m_rectWarning.top + csWarning.cy;

		m_rectPhone.left = iMargin;
		m_rectPhone.right = m_rectPhone.left + csPhone.cx;
		m_rectPhone.top = max(m_rectWarningBitmap.bottom, m_rectWarning.bottom) + 2 * iMargin;
		m_rectPhone.bottom = m_rectPhone.top + csPhone.cy;
	}
	else
	{
		m_rectWarningBitmap = CRect(0,0,0,0);
		
		m_rectWarning.left = iMargin;
		m_rectWarning.right = m_rectWarning.left + csWarning.cx;
		m_rectWarning.top = iMargin;
		m_rectWarning.bottom = m_rectWarning.top + csWarning.cy;

		m_rectPhone.left = iMargin;
		m_rectPhone.right = m_rectPhone.left + csPhone.cx;
		m_rectPhone.top = m_rectWarning.bottom + 2 * iMargin;
		m_rectPhone.bottom = m_rectPhone.top + csPhone.cy;
	}

	CRect rectOK;
	m_btnOK.GetWindowRect(rectOK);

	CSize cs(600,400);
	cs.cy = m_rectPhone.bottom + iMargin + rectOK.Height() + iMargin;
	cs.cx = max(m_rectWarning.right, m_rectPhone.right) + iMargin;

	int x = cs.cx - rectOK.Width() - iMargin;
	int y = cs.cy - rectOK.Height() - iMargin;
	m_btnOK.SetWindowPos(NULL, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER);

	// Position window
	CRect rectWindow;
	GetWindowRect(rectWindow);
	CRect rectClient;
	GetClientRect(rectClient);

	SetWindowPos(NULL, 0, 0, 
		cs.cx + rectWindow.Width() - rectClient.Width(), 
		cs.cy + rectWindow.Height() - rectClient.Height(),
		SWP_NOMOVE|SWP_NOZORDER);

	CenterWindow();

	return true;
}

void CIuMeterWarningDlg::OnPaint() 
{
	CPaintDC dc(this);

	if (!m_fNoWarningBitmap)
		m_WarningBitmp.Draw(dc, m_rectWarningBitmap.left, m_rectWarningBitmap.top, -1, -1, bitmapTransparent);
	m_Text.Draw(dc, m_rectWarning, m_sWarning);
	m_Text.Draw(dc, m_rectPhone, m_sPhone);
}

void CIuMeterWarningDlg::SetMeter(CIuMeter* pMeter)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pMeter != 0);
	m_pMeter = pMeter;
}

