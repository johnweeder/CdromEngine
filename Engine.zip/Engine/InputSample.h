#ifndef _ENGINE_INPUTSAMPLE_H_
#define _ENGINE_INPUTSAMPLE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTDELIMITED_H_
#	include "Engine\InputDelimited.h"
#endif	// _ENGINE_INPUTDELIMITED_H_
#ifndef 	_ENGINE_ADDRESSCODEC_H_
#	include "Engine\AddressCodec.h"
#endif	// _ENGINE_ADDRESSCODEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputSample)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputSample, CIuInputDelimited }}
#define CIuInputSample_super CIuInputDelimited

class CIuInputSample : public CIuInputSample_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputSample)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputSample();
	virtual ~CIuInputSample();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool IsIncludeBusiness() const;
	bool IsIncludeResidential() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetIncludeBusiness(bool);
	void SetIncludeResidential(bool);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	bool OnProcess();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fIncludeBusiness;
	bool m_fIncludeResidential;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuInputSample::IsIncludeBusiness() const
{
	return m_fIncludeBusiness;
}

inline bool CIuInputSample::IsIncludeResidential() const
{
	return m_fIncludeResidential;
}

#endif // _ENGINE_INPUTSAMPLE_H_
