#include "StdAfx.h"
//{{Include
#include "CompareContains.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuCompareContains::CIuCompareContains() 
{
	CommonConstruct();
}

CIuCompareContains::CIuCompareContains(const CIuCompareContains& rCompareContains)
{
	CommonConstruct();
	*this = rCompareContains;
}

CIuCompareContains::~CIuCompareContains()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCompareContains::Compare(LPCTSTR pcszValue) const
{
	ASSERT(AfxIsValidString(pcszValue));
	// We must do a case insensitive strstr
	bool fContains = false;
	int iValue = _tcslen(pcszValue);
	LPCTSTR pcszPattern = m_sExpression;
	int iPattern = m_sExpression.GetLength();
	if (iPattern <= 0)
		fContains = true;
	else
	{
		while (iValue >= iPattern)
		{
			for (int i = 0; i < iPattern; ++i)
			{
				if (_totupper(pcszValue[i]) != _totupper(pcszPattern[i]))
					break;
			}

			if (i >= iPattern)
			{
				fContains = true;
				break;
			}

			--iValue;
			++pcszValue;
		}
	}
	return fContains;
}

void CIuCompareContains::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sExpression = "";
	//}}Initialize
}

CIuCompareContains& CIuCompareContains::operator=(const CIuCompareContains& rCompareContains)
{
	if (this == &rCompareContains)
		return *this;
	m_sExpression = rCompareContains.m_sExpression;
	return *this;
}

void CIuCompareContains::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
}
