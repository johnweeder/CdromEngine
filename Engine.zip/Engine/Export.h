#ifndef _ENGINE_EXPORT_H_
#define _ENGINE_EXPORT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_QUERY_H_
#	include "Engine\Query.h"
#endif	// _ENGINE_QUERY_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExport)
IU_DEFINE_OBJECT_PTR(CIuExportInstance)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExport, CIuObjectNamed }}
#define CIuExport_super CIuObjectNamed

class IU_CLASS_EXPORT CIuExport : public CIuExport_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuExport)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExport();           
	virtual ~CIuExport();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuEngine& GetEngine() const;
	CString GetExportDef() const;
	CString GetExpression() const;
	CString GetFilename() const;
	CIuExportInstance& GetInstance() const;
	int GetHandle() const;
	int GetMaxRecords() const;
	CString GetOptions() const;
	CIuOutput& GetOutput() const;
	CIuQuery& GetQuery() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasEngine() const;
	bool HasQuery() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	void CommonConstruct();
	int Export();
	bool ExportDlg(LPCTSTR pcszName = 0, CWnd* pParent = 0); 
	void Load();
	void Save();
	void SetEngine(CIuEngine& Engine);
	void SetExportDef(LPCTSTR pcsz);
	void SetExpression(LPCTSTR pcsz);
	void SetFilename(LPCTSTR pcsz);
	void SetMaxRecords(int);
	void SetOptions(LPCTSTR pcsz);
	void SetQuery(CIuQuery* pQuery, bool fAutoRemove = false);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnLoad(LPCTSTR pcszName = 0, CIuOutput* pOutput = 0);
	virtual void OnSave(LPCTSTR pcszName = 0, CIuOutput* pOutput = 0);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionExport(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionExportDlg(const CIuPropertyCollection& Collection, CIuOutput& Output);
	void GetExportDefAllowed(CStringArray& as) const;
private:
	void GetSettingName(CString& sName) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
private:
	CIuEngine* m_pEngine;
	CString m_sFilename;
	CString m_sExpression;
	CString m_sExportDef;
	CIuExportInstancePtr m_pInstance;
	CString m_sOptions;
	CIuQueryPtr m_pQuery;
	// If this flag is set, a query is automatically removed from the
	// the queries collection when this object is destroyed.
	bool m_fAutoRemove;
	mutable CIuOutputPtr m_pOutput;
	int m_iMaxRecords;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuExport::GetExportDef() const
{
	return m_sExportDef;
}

inline CString CIuExport::GetExpression() const
{
	return m_sExpression;
}

inline CIuExportInstance& CIuExport::GetInstance() const
{
	return m_pInstance.Ref();
}

inline int CIuExport::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline CString CIuExport::GetOptions() const
{
	return m_sOptions;
}

inline CIuQuery& CIuExport::GetQuery() const
{
	return m_pQuery.Ref();
}

inline bool CIuExport::HasEngine() const
{
	return m_pEngine!=0;
}

inline bool CIuExport::HasQuery() const
{
	return m_pQuery.NotNull();
}

#endif // _ENGINE_EXPORT_H_
