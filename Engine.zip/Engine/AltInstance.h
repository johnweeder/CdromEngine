#ifndef _ENGINE_ALTINSTANCE_H_
#define _ENGINE_ALTINSTANCE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltInstance)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltInstance, CIuObject }}
#define CIuAltInstance_super CIuObject

class CIuAltInstance : public CIuAltInstance_super
{
//{{Declare
	DECLARE_SERIAL(CIuAltInstance)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltInstance();
	virtual ~CIuAltInstance();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddValue(LPCTSTR);
	CString GetKey() const;
	CString GetValue(int) const;
	int GetValueCount() const;
	void GetValues(CStringArray& as) const;
	CString GetValuesAsString() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	bool Matches(LPCTSTR pcszPattern) const;
	void RemoveAllValues();
	void SetKey(LPCTSTR);
	void SetValues(const CStringArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sKey;
	CStringArray m_asValues;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuAltInstance::GetKey() const
{
	return m_sKey;
}

inline CString CIuAltInstance::GetValue(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetValueCount());
	return m_asValues[iWhich];
}

inline int CIuAltInstance::GetValueCount() const
{
	return m_asValues.GetSize();
}

#endif // _ENGINE_ALTINSTANCE_H_
