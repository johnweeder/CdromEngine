#include "StdAfx.h"
//{{Include
#include "ElementCollection.h"
#include "resource.h"
#include "Element.h"
#include "Miscellaneous.h"
#include "Interop\Conversions.h"
#include "Error\Error.h"
#include "Interop\Integer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuElementCollection, CIuElementCollection_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuElementCollection)
const	CIuVersionNumber versionElementCollectionMax(2000,1,5,304);
const	CIuVersionNumber versionElementCollectionMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ELEMENTCOLLECTION, CIuElementCollection, CIuElementCollection_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuElementCollection, IDS_ENGINE_PPG_ELEMENTCOLLECTION, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuElementCollection, IDS_ENGINE_PROP_HASHSIZE, GetHashSize, SetHashSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuElementCollection, IDS_ENGINE_PROP_HASHSIZE, IDS_ENGINE_PPG_ELEMENTCOLLECTION, 1, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuElementCollection, IDS_ENGINE_PROP_COUNT, GetCount, SetCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuElementCollection, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_ELEMENTCOLLECTION, 0, INT_MAX, editorReadOnly)

	IU_ATTRIBUTE_PAGE(CIuElementCollection, IDS_ENGINE_PPG_ELEMENTCOLLECTION2, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuElementCollection, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuElementCollection, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_ELEMENTCOLLECTION2, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl sort_elements_by_count_decreasing(const void *elem1, const void *elem2)
{
	const CIuElement** ppElement1 = (const CIuElement**)elem1;
	const CIuElement** ppElement2 = (const CIuElement**)elem2;
	return int((*ppElement2)->GetCount() - (*ppElement1)->GetCount());
}

static int __cdecl sort_elements_by_name(const void *elem1, const void *elem2)
{
	const CIuElement** ppElement1 = (const CIuElement**)elem1;
	const CIuElement** ppElement2 = (const CIuElement**)elem2;
	return _tcscmp((*ppElement1)->GetName(), (*ppElement2)->GetName());
}

CIuElementCollection::CIuElementCollection() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuElementCollection::~CIuElementCollection()
{
	Empty();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuElement* CIuElementCollection::Add(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));

	if (m_ElementMap.GetSize() == 0)
		AllocateMap(GetHashSize());

	UINT uiHash = CIuElement::HashKey(pcszName) % m_ElementMap.GetSize();

	CIuElement* pElement = m_ElementMap.GetAt(uiHash);
	if (pElement)
	{
		int iResult = _tcscmp(pcszName, pElement->GetName());
		if (iResult < 0)
		{
			// This element belongs first in the bucket... make it so
			pElement = Create(pcszName);
			ASSERT(pElement);
			++m_iCount;
			pElement->SetNext(m_ElementMap.GetAt(uiHash));
			m_ElementMap.SetAt(uiHash, pElement);
			return pElement;
		}

		// Inserted into this bucket in sorted order
		for (;;)
		{
			// Matches this element in the bucket
			if (iResult == 0)
			{
				pElement->Another();
				return pElement;
			}
			// There is no next element
			if (pElement->GetNext() == 0)
			{
				// Add new element to end of bucket
				CIuElement* pNew = Create(pcszName);
				pElement->SetNext(pNew);
				++m_iCount;
				return pNew;
			}

			// Compare to next element in chain
			iResult = _tcscmp(pcszName, pElement->GetNext()->GetName());

			// Should be insert before next element?
			if (iResult < 0)
			{
				CIuElement* pNew = Create(pcszName);
				pNew->SetNext(pElement->GetNext());
				pElement->SetNext(pNew);
				++m_iCount;
				return pNew;
			}
			pElement = pElement->GetNext();
		}
	}
	else
	{
		// First element in this bucket
		pElement = Create(pcszName);
		ASSERT(pElement);
		m_ElementMap.SetAt(uiHash, pElement);
		++m_iCount;
		return pElement;
	}
}

CIuElement* CIuElementCollection::AddBlank(int iCount)
{
	CIuElement* pElement = Add("");
	ASSERT(pElement);
	pElement->SetCount(iCount);
	return pElement;
}

void CIuElementCollection::AllocateMap(int iHashSize)
{
	// First free any existing map
	Empty();

	// Then, allocate a new map
	ASSERT(iHashSize > 0);
	m_ElementMap.SetSize(iHashSize);
	int iSize = m_ElementMap.GetSize();
	for (int i = 0; i < iSize; ++i)
		m_ElementMap.SetAt(i, 0);
}

void CIuElementCollection::Clear()
{
	CIuElementCollection_super::Clear();
	CIuElementCollection::CommonConstruct();
	Empty();
}

void CIuElementCollection::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("ElementCollection");
	// Hash table size is critical to reasonable performance. 
	// Streets and last names have around 2M unique values nation wide.
	// The rule of thumb is to make the hash table twice as large as
	// the maximum number of elements...
	// However, we don't have unlimited memory, so we'll settle for around
	// 2M (about 8M of memory used).
	m_iHashSize = 2 * 1024 * 1024 - 1;
	m_iCount = 0;
	SetVersion(versionElementCollectionMax);
	//}}Initialize
}

bool CIuElementCollection::Compress(CIuBuffer& Buffer, int& iCount, CIuOutput& Output)
{
	// Press names into a buffer in decreasing count order
	// The strings are simply packed with a null terminator after each string
	SortByCountDecreasing();

	ASSERT(GetSortedCount() == GetCount());
	if (iCount < 0)
		iCount = GetSortedCount();
	if (iCount > GetSortedCount())
		iCount = GetSortedCount();

	int iStart = Buffer.GetSize();
	for (int i = 0; i < iCount; ++i)
	{
		CIuElement* pElement = GetSorted(i);
		ASSERT(pElement);
		LPCTSTR pcszName = pElement->GetName();
		Buffer.Append((const BYTE*)pcszName, _tcslen(pcszName) + 1);
	}
	int iEnd = Buffer.GetSize();
	// Output description, set range, etc
	Output.OutputF("Compressed %d elements in %d bytes\n", iCount, iEnd - iStart);
	return Output.Fire();
}

CIuElement* CIuElementCollection::Create(LPCTSTR pcszName)
{
	CIuElement* pElement = new CIuElement;
	ASSERT(pElement);
	pElement->SetCollection(this);
	if (pcszName)
		pElement->Create(pcszName);
	return pElement;
}

int CIuElementCollection::DeCompress(const BYTE* pb, int cb, CArray<LPCTSTR, LPCTSTR>& aStrings, int iStrings)
{
	const BYTE* pbStart = pb;

	ASSERT(iStrings >= 0);
	ASSERT(iStrings >= 0);
	aStrings.SetSize(iStrings);

	for (int i = 0; i < iStrings && cb > 0; ++i)
	{
		aStrings.SetAt(i, LPCTSTR(pb));

		for (;*pb != 0 && cb > 0; ++pb, --cb)
			/* null */ ;
		if (*pb == 0 && cb > 0)
		{
			++pb;
			--cb;
		}
	}

	if (i != iStrings)
		Error(IU_E_ELEMENT_INVALID, _T("Expected additional elements decompressing address information"));

	// Returns number of bytes consumed
	return pb - pbStart;
}

void CIuElementCollection::Dump(CIuOutput& Output)
{
	const int iMax = 50000;
	int iCount = m_ElementArray.GetSize();
	int iTotal = 0;
	for (int i = 0; i < iCount; ++i)
	{
		CIuElement* pElement = m_ElementArray.GetAt(i);
		ASSERT(pElement);
		iTotal += pElement->GetCount();
	}

	Output.OutputF("ElementCollection with %d elements with %d instances\n", iCount, iTotal);
	int iSummation = 0;
	for (i = 0; i < min(iCount, iMax); ++i)
	{
		CIuElement* pElement = m_ElementArray.GetAt(i);
		ASSERT(pElement);
		iSummation += pElement->GetCount();
		__int64 iPercentage = (__int64(pElement->GetCount()) * 1000) / __int64(iTotal);
		__int64 iPercentageSummation = (__int64(iSummation) * 1000) / __int64(iTotal);
		Output.OutputF("\t%10d\t%10d\t%2d.%1d %%\t%10d\t%2d.%1d %%\t%s\n",
			i,
			pElement->GetCount(),
			int(iPercentage / 10), int(iPercentage % 10),
			iSummation,
			int(iPercentageSummation / 10), int(iPercentageSummation % 10),
			LPCTSTR(pElement->GetName()));
	}
}

void CIuElementCollection::Empty()
{
	int iSize = m_ElementMap.GetSize();
	for (int i = 0; i < iSize; ++i)
		delete m_ElementMap[i];
	m_ElementMap.RemoveAll();
	m_ElementArray.RemoveAll();
	m_iCount = 0;
	m_Heap.Empty();
}

int CIuElementCollection::FindSorted(LPCTSTR pcszName) const
{
	for (int i = 0; i < GetSortedCount(); ++i)
	{
		CIuElement* pElement = GetSorted(i);
		ASSERT(pElement);
		if (_tcsicmp(pcszName, pElement->GetName()) == 0)
			return i;
	}
	return -1;
}

CString CIuElementCollection::GetGridElement(int iRow, int iCol) const
{
	// Make sure row is valid
	ASSERT(GetCount() == GetSortedCount());
	if (iRow < 0 || iRow >= GetSortedCount())
		return CString();

	// Get the element in this row
	CIuElement* pElement = m_ElementArray.GetAt(iRow);
	if (pElement == 0)
		return CString();

	// Display the count in column 0
	if (iCol == 0)
	{
		CString sCount;
		return IntAsString(sCount, pElement->GetCount());
	}
	--iCol;

	// Find the buffer containing the value we are looking for
	CString s = pElement->GetName();
	return s;
}

bool CIuElementCollection::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			SortByCountDecreasing();

			static TCHAR szName[] = _T("CIuElementCollectionGrid");
			rq.SetName(szName);
			rq.Load();
			rq.SetSize(CSize(2, GetSortedCount()));

			rq.SetColumn(0, "Count",	100, gridWidthOptional);
			rq.SetColumn(1, "Name",		100, gridWidthOptional);

			return true;
		}
		case gridRqTerminate:
			rq.Save();
			return true;
		case gridRqDblClickRow:
		case gridRqDblClickCell:
			return false;
		case gridRqGet:
		{
			CString s = CIuElementCollection::GetGridElement(rq.GetRow(), rq.GetColumn());
			rq.SetValue(s);
			return true;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

CIuElement* CIuElementCollection::GetSorted(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetSortedCount());
	ASSERT(m_ElementArray.GetAt(iWhich));
	return m_ElementArray.GetAt(iWhich);
}

int CIuElementCollection::GetSortedCount() const
{
	return m_ElementArray.GetSize();
}

CIuVersionNumber CIuElementCollection::GetVersionMax() const
{
	return versionElementCollectionMax;
}

CIuVersionNumber CIuElementCollection::GetVersionMaxStatic()
{
	return versionElementCollectionMax;
}

CIuVersionNumber CIuElementCollection::GetVersionMin() const
{
	return versionElementCollectionMin;
}

CIuVersionNumber CIuElementCollection::GetVersionMinStatic()
{
	return versionElementCollectionMin;
}

void CIuElementCollection::Serialize(CArchive& ar)
{
	// We use MFC serialization for performance reasons...
	// NOTE: We are only saving the ElementCollection information via MFC serialization
	const DWORD dwCurrentVersion = 0x00000001;
	if (ar.IsStoring())
	{
		ar << dwCurrentVersion;

		DWORD dwHashSize = m_ElementMap.GetSize();
		ASSERT(dwHashSize != 0);
		ar << dwHashSize;

		DWORD dwCount = m_iCount;
		ar << dwCount;

		for (int iHash = 0; iHash < m_ElementMap.GetSize(); ++iHash)
		{
			CIuElement* pElement = m_ElementMap.GetAt(iHash);
			while (pElement)
			{
				ASSERT(dwCount != 0);
				--dwCount;
				pElement->Serialize(ar);
				pElement = pElement->GetNext();

			}
		}
		ASSERT(dwCount == 0);
	}
	else
	{
		Empty();

		DWORD dwVersion;
		ar >> dwVersion;
		ASSERT(dwVersion == dwCurrentVersion);

		DWORD dwHashSize;
		ar >> dwHashSize;
		ASSERT(dwHashSize > 0);
		AllocateMap(int(dwHashSize));

		DWORD dwCount;
		ar >> dwCount;

		CIuElement* pPrevElement = 0;
		UINT uiPrevHash = 0;

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			CIuElement* pElement = Create();
			ASSERT(pElement);
			pElement->Serialize(ar);

			UINT uiHash = pElement->HashKey() % dwHashSize;

			if (m_ElementMap.GetAt(uiHash) == 0)
			{
				++m_iCount;
				m_ElementMap.SetAt(uiHash, pElement);
				pPrevElement = pElement;
				uiPrevHash = uiHash;
			}
			else if (pPrevElement != 0 && uiPrevHash == uiHash)
			{
				++m_iCount;
				pPrevElement->SetNext(pElement);
				ASSERT(_tcscmp(pPrevElement->GetName(), pElement->GetName()) <= 0);
				pPrevElement = pElement;
			}
			else
			{
				// This should not happen.... elements should insert into correct order
				ASSERT(false);
			}
		}
		ASSERT(dwCount == DWORD(m_iCount));
	}
	CIuElementCollection_super::Serialize(ar);
}

void CIuElementCollection::SetCount(int iCount)
{
	m_iCount = iCount;
}

void CIuElementCollection::SetHashSize(int iHashSize)
{
	m_iHashSize = iHashSize;
}

void CIuElementCollection::Sort()
{
	m_ElementArray.SetSize(GetCount());
	int iArray = 0;
	int iHashSize = m_ElementMap.GetSize();
	for (int iHash = 0; iHash < iHashSize; ++iHash)
	{
		CIuElement* pElement = m_ElementMap.GetAt(iHash);
		while (pElement)
		{
			m_ElementArray.SetAt(iArray, pElement);
			++iArray;
			pElement = pElement->GetNext();
			ASSERT(iArray <= GetCount());
		}
	}
	ASSERT(iArray <= GetCount());
	m_ElementArray.SetSize(iArray);
}

void CIuElementCollection::SortByCountDecreasing()
{
	Sort();
	if (m_ElementArray.GetSize() > 0)
		qsort(m_ElementArray.GetData(), m_ElementArray.GetSize(), sizeof(CIuElement*), sort_elements_by_count_decreasing);
}

void CIuElementCollection::SortByName()
{
	Sort();
	if (m_ElementArray.GetSize() > 0)
		qsort(m_ElementArray.GetData(), m_ElementArray.GetSize(), sizeof(CIuElement*), sort_elements_by_name);
}

