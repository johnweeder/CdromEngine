#include "StdAfx.h"
//{{Include
#include "FieldNth.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuFieldNth::CIuFieldNth() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	//{{Initialize
	m_iFields = 0;
	//}}Initialize
}

CIuFieldNth::~CIuFieldNth()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuFieldNth::SetField(const CIuRecord& Record, int iField)
{
	int iSize;
	const char* pcsz = Record.GetField(iField, iSize);
	ASSERT(pcsz[iSize - 1] == '\0');

	SetSize(iSize);
	SetBuffer((const BYTE*)pcsz, iSize);

	BYTE* pb = GetPtr();

	// Do _not_ resize the array. We don't want it reallocating a lot...
	//	Just let it grow if needed.
	m_iFields = 1;
	m_aiOffset.SetAtGrow(0, 0);
	for (int i = 0; i < iSize; ++i)
	{
		if (pb[i] == '\n')
		{
			pb[i] = '\0';
			m_aiOffset.SetAtGrow(m_iFields, i + 1);
			++m_iFields;
		}
	}
	// Add the final as a means to quickly calc field size by offset
	m_aiOffset.SetAtGrow(m_iFields, GetSize());
}
