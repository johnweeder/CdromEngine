#ifndef _ENGINE_ENGINEAPP_H_
#define _ENGINE_ENGINEAPP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

#ifndef 	_DATA_DATA_H_
#	include "Data\Data.h"
#endif	// _DATA_DATA_H_

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

#ifndef IU_ENGINE
#	ifdef _DEBUG
#		pragma comment(lib, "iuEngineD")
#	else
#		pragma comment(lib, "iuEngineR")
#	endif
#endif

//{{MasterHeader
struct IU_CLASS_EXPORT CIuRecord;
class IU_CLASS_EXPORT CIuRecordPtr;
//}}MasterHeader

class CIuVersionInfo;

IU_API_EXPORT void IuEngineInfo(CIuVersionInfo& VersionInfo);
IU_API_EXPORT void IuEngineInit();

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

#endif // _ENGINE_ENGINEAPP_H_
