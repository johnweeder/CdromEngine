#ifndef _ENGINE_KEYRANGE_H_
#define _ENGINE_KEYRANGE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuKeyRange)
class CIuKey;
class CIuKeyDef;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuKeyRange, CIuObject }}
#define CIuKeyRange_super CIuObject
class CIuKeyRange : public CIuKeyRange_super
{
//{{Declare
	DECLARE_SERIAL(CIuKeyRange)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuKeyRange(LPCTSTR pcsz = 0);
	CIuKeyRange(const CIuKeyRange&);
	virtual ~CIuKeyRange();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString Get() const;
	void Get(int iWhich, CIuKey& KeyLo, CIuKey& KeyHi, const CIuKeyDef& KeyDef) const;
	int GetCount() const;
	bool IsSimpleKey(int iWhich, CString* pValue = 0) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void AddKey(LPCTSTR pcszLo = 0, LPCTSTR pcszHi = 0);
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void CopyKey(int iWhich, const CIuKeyRange& Range);
	void RemoveKey(int iWhich);
	void Set(LPCTSTR pcsz);
	void SetKey(int iWhich, LPCTSTR pcszLo = 0, LPCTSTR pcszHi = 0);
	void Sort(const CIuKeyDef& KeyDef);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuKeyRange& operator=(const CIuKeyRange&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CStringArray m_asLo;
	CIntArray m_aiTypeLo;
	CStringArray m_asHi;
	CIntArray m_aiTypeHi;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_KEYRANGE_H_
