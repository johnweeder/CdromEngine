#include "StdAfx.h"
//{{Include
#include "InputRecordFile.h"
#include "resource.h"
#include "CdromSpec.h"
#include "RecordFile.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputRecordFile, CIuInputRecordFile_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputRecordFile)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTRECORDFILE, CIuInputRecordFile, CIuInputRecordFile_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputRecordFile, IDS_ENGINE_PPG_INPUTRECORDFILE, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputRecordFile::CIuInputRecordFile() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputRecordFile::~CIuInputRecordFile()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputRecordFile::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputRecordFile"));
	if (m_pRecordFile.IsNull())
		m_pRecordFile.Create();
	//}}Initialize
}

CIuFilename CIuInputRecordFile::GetFullOutputFilename() const
{
	return GetRecordFile().GetFullFilename();
}

void CIuInputRecordFile::OnClose()
{
	GetRecordFile().Close();
	CIuInputRecordFile_super::OnClose();
}

bool CIuInputRecordFile::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputRecordFile_super::OnOpen(OpenSpec))
		return false;
	GetRecordFile().SetFilename(GetOutputFilename());
	if (ShouldAppend())
	{
		// We have to be careful in append mode to make sure that
		//	 the appending record def matches the original record def.
		// The record defs must match or bad things will happen!
		GetRecordFile().SetAppend(ShouldAppend());
		GetRecordFile().Open(OpenSpec);
	}
	else
	{
		// Copy the record definition to the output
		CIuRecordDefPtr pRecordDef = GetRecordDef();
		GetRecordFile().GetRecordDef() = *pRecordDef;
		GetRecordFile().Create(OpenSpec);
	}
	return true;
}

bool CIuInputRecordFile::OnOutput()
{
	GetRecord(m_pRecord);
	GetRecordFile().Append(*m_pRecord);
	return CIuInputRecordFile_super::OnOutput();
}

void CIuInputRecordFile::SetOutputFilename(LPCTSTR pcsz)
{
	CIuInputRecordFile_super::SetOutputFilename(pcsz);
	GetRecordFile().SetFilename(pcsz);
}

void CIuInputRecordFile::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputRecordFile_super::SetSpec(Spec);
}

