#include "StdAfx.h"
//{{Include
#include "InputZipCentroid.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputZipCentroid, CIuInputZipCentroid_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputZipCentroid)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTZIPCENTROID, CIuInputZipCentroid, CIuInputZipCentroid_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputZipCentroid, IDS_ENGINE_PPG_INPUTZIPCENTROID, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputZipCentroid::CIuInputZipCentroid() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputZipCentroid::~CIuInputZipCentroid()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputZipCentroid::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input ZipCentroid"));
	SetInputFilename("ZipCentroid");
	SetOutputFilename("ZipCentroid");
	SetFormat(inputZipCentroid);
	//}}Initialize
}

bool CIuInputZipCentroid::OnProcess()
{
	LPCTSTR pcszZip			= GetInput(0);
	ASSERT(_tcslen(pcszZip) == 5);
	LPCTSTR pcszLatitude		= GetInput(1);
	LPCTSTR pcszLongitude	= GetInput(2);
	SetField(inputFieldZIP, pcszZip);
	SetField(inputFieldLatitude, pcszLatitude);
	SetField(inputFieldLongitude,	pcszLongitude);
	return Output();
}
