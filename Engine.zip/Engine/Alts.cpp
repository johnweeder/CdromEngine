#include "StdAfx.h"
//{{Include
#include "Alts.h"
#include "resource.h"
#include "Alt.h"
#include "CdromSpec.h"
#include "AltSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAlts, CIuAlts_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAlts)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTS, CIuAlts, CIuAlts_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAlts, IDS_ENGINE_PPG_ALTS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuAlts, IDS_ENGINE_PPG_ALTS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAlts::CIuAlts() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAlts::~CIuAlts()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuAlts::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int iAlt = 0; iAlt < GetCount(); ++iAlt)
		if (!Get(iAlt).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuAlts::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuAlts::Create(CIuAltSpec& AltSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuAlt& Alt = Get(iIndex);
	Alt.SetSpec(AltSpec);
}

CIuCollectablePtr CIuAlts::OnNew(CWnd*) const
{
	CIuAltPtr pAlt;
	pAlt.Create();
	return pAlt;
}

void CIuAlts::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iAlt = 0; iAlt <  Spec.GetAltCount(); ++iAlt)
		Create(Spec.GetAlt(iAlt));  	
}
