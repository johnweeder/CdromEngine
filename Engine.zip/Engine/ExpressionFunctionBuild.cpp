#include "StdAfx.h"
//{{Include
#include "ExpressionFunctionBuild.h"
#include "Interop\Conversions.h"
#include "Common\ThousandSeparated.h"
#include "Common\String.h"
#include "LatLongCoordinate.h"
#include "LatLongDistance.h"
#include "States.h"
#include "Solicit.h"
#include "resource.h"
#include "ParseName.h"
#include "StatesRaw.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement

// NOTE: Function names _ending_ with an underscore are considered to be "internal"
//			and should not be exposed to external customers.
//			The second part of the function name is a list of parameters

static const CIuExpressionFunctionDef adefs[] =
{
	// Functions
	// NOTE: This array should match the enum in ExpressionElement.h
	{ 
		exprBuildAcPhone,
		"BuildAcPhone_\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::BuildAcPhone), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::BuildAcPhoneMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprBuildPriNo,
		"BuildPriNo_\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::BuildPriNo), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::BuildPriNoMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprBuildSecNo,
		"BuildSecNo_\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::BuildSecNo), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::BuildSecNoMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprBuildStreet,
		"BuildStreet_\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::BuildStreet), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::BuildStreetMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprCompareFunction,
		"Compare\0expr, expr",                     
		0, 0, PFNFUNCTIONINT(CIuExpressionFunctionBuild::Compare), 
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::NumericMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprCompareNoCase,
		"CompareNoCase\0expr, expr",               
		0, 0, PFNFUNCTIONINT(CIuExpressionFunctionBuild::CompareNoCase),
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::NumericMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprCRLF,
		"CRLF\0count=1",                        
		PFNFUNCTION(CIuExpressionFunctionBuild::CRLF), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::CRLFMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprDefVal,
		"DefVal\0expr,def[,test1,test2,..]",                      
		PFNFUNCTION(CIuExpressionFunctionBuild::DefVal), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::DefVaiMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprExtractNamePart,
		"ExtractNamePart\0expr,'L|F|M|G|P|T'",					
		PFNFUNCTION(CIuExpressionFunctionBuild::ExtractNamePart), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::ExtractNamePartMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprFirstName,
		"FirstName\0",                   
		PFNFUNCTION(CIuExpressionFunctionBuild::FirstName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::FirstNameMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprFlipName,
		"FlipName\0",                    
		PFNFUNCTION(CIuExpressionFunctionBuild::FlipName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::FlipNameMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprHyphenatePhone,
		"HyphenatePhone\0expr",              
		PFNFUNCTION(CIuExpressionFunctionBuild::HyphenatePhone), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::HyphenatePhoneMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprHyphenateZIP,
		"HyphenateZIP\0expr",                
		PFNFUNCTION(CIuExpressionFunctionBuild::HyphenateZIP), 0, 0,
      PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::HyphenateZIPMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprIff,
		"Iff\0TestExpr,TrueExpr,FalseExpr",
		PFNFUNCTION(CIuExpressionFunctionBuild::Iff), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::IffMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprLastName,
		"LastName\0expr",                    
		PFNFUNCTION(CIuExpressionFunctionBuild::LastName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::LastNameMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprLatLongDistance,
		"LatLongDistance\0CenterLat,CenterLong,units,directional",
		PFNFUNCTION(CIuExpressionFunctionBuild::LatLongDistance), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::LatLongDistanceMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprLeft,
		"Left\0expr, length",								
		PFNFUNCTION(CIuExpressionFunctionBuild::Left), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::LeftMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprLen,
		"Len\0expr",
		0, 0, PFNFUNCTIONINT(CIuExpressionFunctionBuild::Len),
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::NumericMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprLookup,
		"Lookup\0#,expr0,expr1,expr2,...",
		PFNFUNCTION(CIuExpressionFunctionBuild::Lookup), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::LookupMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeAddress,
		"MakeAddress\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeAddress), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeAddressMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeCityState,
		"MakeCityState\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeCityState), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeCityStateMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeLastLine,
		"MakeLastLine\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeLastLine), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeLastLineMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeLower,
		"MakeLower\0expr",                   
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeLower), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeLowerMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeName,
		"MakeName\0",							
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeNameMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeNameInitials,
		"MakeNameInitials\0",							
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeNameInitials), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeNameInitialsMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakePhone,
		"MakePhone\0",							
		PFNFUNCTION(CIuExpressionFunctionBuild::MakePhone), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakePhoneMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeStreet,
		"MakeStreet\0",						
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeStreet), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeStreetMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeUpper,
		"MakeUpper\0expr",                  
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeUpper), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeUpperMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMakeZip,
		"MakeZip\0",							
		PFNFUNCTION(CIuExpressionFunctionBuild::MakeZIP), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MakeZIPMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprMid,
		"Mid\0expr,start,len",                         
		PFNFUNCTION(CIuExpressionFunctionBuild::Mid), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::MidMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprNewline,
		"Newline\0count=1",                     
		PFNFUNCTION(CIuExpressionFunctionBuild::Newline), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::NewlineMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprPaste,
		"Paste\0expr1,sep1,expr2,sep2,...,exprN",
		PFNFUNCTION(CIuExpressionFunctionBuild::Paste), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::VarArgConcatenationMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprPasteSpace,
		"PasteSpace\0expr,expr,...",                  
		PFNFUNCTION(CIuExpressionFunctionBuild::PasteSpace), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::PasteSpaceMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprRepeat,
		"Repeat\0expr, count=1",
		PFNFUNCTION(CIuExpressionFunctionBuild::Repeat), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::RepeatMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprRight,
		"Right\0expr,count",								
		PFNFUNCTION(CIuExpressionFunctionBuild::Right), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::RightMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprSortZIP9First,
		"SortZIP9First_\0ZIP",
		PFNFUNCTION(CIuExpressionFunctionBuild::SortZIP9First), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::SortZIP9FirstMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprSpace,
		"Space\0count=1",                       
		PFNFUNCTION(CIuExpressionFunctionBuild::Space), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::SpaceMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprStateAbbr2Code,
		"StateAbbr2Code\0",                    
		PFNFUNCTION(CIuExpressionFunctionBuild::StateAbbr2Code), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::StateAbbr2CodeMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprStateCode2Abbr,
		"StateCode2Abbr\0",                    
		PFNFUNCTION(CIuExpressionFunctionBuild::StateCode2Abbr), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::StateCode2AbbrMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprSurround,
		"Surround\0exprLeft,e1,e2..,eN,exprRight",                    
		PFNFUNCTION(CIuExpressionFunctionBuild::Surround), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::VarArgConcatenationMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprTab,
		"Tab\0count=1",                         
		PFNFUNCTION(CIuExpressionFunctionBuild::Tab), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::TabMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprTAPIPhone,
		"TAPIPhone\0ACPhone",
		PFNFUNCTION(CIuExpressionFunctionBuild::TAPIPhone), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::TAPIPhoneMaxLength),
		CIuExpressionFunctionBuild::Create
	},{ 
		exprThousands,
		"Thousands\0expr",                         
		PFNFUNCTION(CIuExpressionFunctionBuild::Thousands), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::ThousandsMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprTrim,
		"Trim\0expr",
		PFNFUNCTION(CIuExpressionFunctionBuild::Trim), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::TrimMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprTrimLeft,
		"TrimLeft\0expr",
		PFNFUNCTION(CIuExpressionFunctionBuild::TrimLeft), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::TrimMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprTrimRight,
		"TrimRight\0expr",
		PFNFUNCTION(CIuExpressionFunctionBuild::TrimRight), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionBuild::TrimMaxLength), 
		CIuExpressionFunctionBuild::Create
	},{ 
		exprUnknown, 0
	}
};
//}}Implement


CIuExpressionFunctionBuild::CIuExpressionFunctionBuild(CIuExpressionType Type) : CIuExpressionFunction(Type)
{
}

CIuExpressionFunctionBuild::CIuExpressionFunctionBuild(const CIuExpressionFunctionBuild& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionFunctionBuild::~CIuExpressionFunctionBuild()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

LPCTSTR CIuExpressionFunctionBuild::BuildAddress(int iType, const CIuRecord* pRecord) const
{
	// This is an internal function used by the build process to clean up
	// an address and split it into it's 3 major pieces: prino street secno
	// Parms:
	//	iType:	0=Get primary number
	//				1=Get street
	//				2=Get secondary number
	//		0:		PriNo
	//		1:		PreDir
	//		2:		Street
	//		3:		Suffix
	//		4:		PostDir
	//		5:		SecNo
	//		6:		Highrise flag (R=rural route, P= po box)
	//		7		Non-solicitation flag 
	//
	if (iType < 0 || iType > 2)
	{	
		
		return m_sBuffer;
	}

	LPCTSTR pcszPriNo = _tcsskipws(EvaluateChild(0, pRecord));
	LPCTSTR pcszPreDir = _tcsskipws(EvaluateChild(1, pRecord));
	LPCTSTR pcszStreet = _tcsskipws(EvaluateChild(2, pRecord));
	LPCTSTR pcszSuffix = _tcsskipws(EvaluateChild(3, pRecord));
	LPCTSTR pcszPostDir = _tcsskipws(EvaluateChild(4, pRecord));
	LPCTSTR pcszSecNo = _tcsskipws(EvaluateChild(5, pRecord));
	LPCTSTR pcszHighrise = _tcsskipws(EvaluateChild(6, pRecord));
	LPCTSTR pcszNoSolicit = _tcsskipws(EvaluateChild(7, pRecord));
	if (*pcszNoSolicit != '\0' && !SolicitCanMail(pcszNoSolicit[0]))
		return _T("");

	// Buffer will contain full street name
	m_sBuffer = pcszPreDir;
	PasteString(m_sBuffer, pcszStreet);
	PasteString(m_sBuffer, pcszSuffix);
	PasteString(m_sBuffer, pcszPostDir);

	if (*pcszPreDir == '\0' && *pcszHighrise != '\0')
	{
		if (pcszHighrise[0] == 'P')
			m_sBuffer = _T("PO BOX");
		else if (pcszHighrise[0] == 'R')
		{
			// OK, our data is screwed up six ways to Sunday. 
			// Business and residential have different for and different crap...
			// Handle a special case here
			LPCTSTR pcszRR = m_sBuffer;
			bool fKeeper = false;
			if (*pcszPriNo == '\0' && *pcszRR == 'R')
			{
				++pcszRR;
				if (*pcszRR == 'R')
				{
					++pcszRR;
					if (*pcszRR == ' ')
					{
						++pcszRR;
						while (_istdigit(*pcszRR))
							++pcszRR;
						if (*pcszRR == '\0')
							fKeeper = true;
					}
				}
			}
			if (!fKeeper)
				m_sBuffer = _T("RR");
		}
	}

	// Make primary # the RR# or HC#
	if (m_sBuffer.CompareNoCase(_T("RR")) == 0 || m_sBuffer.CompareNoCase(_T("HC")) == 0)
	{
		if (*pcszPriNo != '\0')
		{
			m_sBuffer += _T(" ");
			m_sBuffer += pcszPriNo;
			pcszPriNo = "";
		}
	}

	bool fRR = false;
	if (m_sBuffer.GetLength() >= 2 && (_memicmp(LPCTSTR(m_sBuffer), _T("RR"), 2) == 0 || _memicmp(LPCTSTR(m_sBuffer), _T("HC"), 2) == 0))
	{
		fRR = true;

		// Watch for no space between RR/HC and route #
		if (m_sBuffer.GetLength() >= 3 && _istdigit(m_sBuffer[2]))
			m_sBuffer.Insert(2, ' ');

		// Watch for goofy RR/HC where there are a bunch of spaces and then the secondary number
		// i.e. "RR 1             60", the box number is usually also present in the secondary#.
		if (m_sBuffer.GetLength() > 2)
		{
			LPCTSTR pcszBuffer = m_sBuffer;
			LPCTSTR pcsz = pcszBuffer + 2;
			if (_istspace(*pcsz))
				++pcsz;
			while (_istdigit(*pcsz))
				++pcsz;
			if (_istspace(pcsz[0]) && _istspace(pcsz[1]))
			{
				int iLength = pcsz - pcszBuffer;
				m_sBuffer = m_sBuffer.Left(iLength);
			}
		}
		
		// Remove the word "BOX" from the end of an HC or RR.
		LPCTSTR pcszBuffer = m_sBuffer;
		int iBuffer = m_sBuffer.GetLength();
		if (iBuffer > 6 && _memicmp(pcszBuffer + iBuffer - 4, _T(" BOX"), 4) == 0)
		{
			m_sBuffer = m_sBuffer.Left(iBuffer - 4);
			m_sBuffer.TrimRight();
		}
	}


	bool fPoBox = m_sBuffer.CompareNoCase(_T("PO BOX")) == 0;
	if (fRR || fPoBox)
	{
		if (*pcszPriNo != '\0')
		{
			if (*pcszSecNo == '\0')
				pcszSecNo = pcszPriNo;

			pcszPriNo = "";
		}
	}

	switch (iType)
	{
		case 0:
			return pcszPriNo;
		case 1:
			return m_sBuffer; // Street
		case 2:
			return pcszSecNo;
	}

	return _T("");
}

LPCTSTR CIuExpressionFunctionBuild::BuildAcPhone(const CIuRecord * pRecord) const
{
	// This is an internal function used by the build process to clean up
	// a phone. All zeroes are converted
	// Parms:
	//		0:		AreaCode
	//		1:		Phone
	//		2:		Non-solicitation flag 
	//
	LPCTSTR pcszNoSolicit = _tcsskipws(EvaluateChild(2, pRecord));
	if (*pcszNoSolicit != '\0' && !SolicitCanPhone(pcszNoSolicit[0]))
		return _T("");

	m_sBuffer = "";
	m_sBuffer += EvaluateChild(0, pRecord);
	m_sBuffer += EvaluateChild(1, pRecord);

	// NOTE: The following types of phones are suppressed:
	//	000-000-0000
	//	000-???-????
	//	???-000-????
	__int64 iPhone = StringAsInt64(m_sBuffer);
	__int64 iAreaCode = (iPhone / 10000000);
	__int64 iPrefix   = (iPhone % 10000000) / 10000;
	if (iPhone == 0 || iAreaCode == 0 || iPrefix == 0)
		return _T("");

	TCHAR sz[20];
	Int64AsStringEx(sz, sizeof(sz), iPhone, 10, 10, 10, true);
	m_sBuffer = sz;
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::BuildAcPhoneMaxLength() const
{
	return 10;
}

LPCTSTR CIuExpressionFunctionBuild::BuildPriNo(const CIuRecord * pRecord) const
{
	return BuildAddress(0, pRecord);
}

int CIuExpressionFunctionBuild::BuildPriNoMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::BuildSecNo(const CIuRecord * pRecord) const
{
	return BuildAddress(2, pRecord);
}

int CIuExpressionFunctionBuild::BuildSecNoMaxLength() const
{
	return GetChildMaxLength(5);
}

LPCTSTR CIuExpressionFunctionBuild::BuildStreet(const CIuRecord * pRecord) const
{
	return BuildAddress(1, pRecord);
}

int CIuExpressionFunctionBuild::BuildStreetMaxLength() const
{
	return GetChildMaxLength(1, 4) + 3;
}


int CIuExpressionFunctionBuild::Compare(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz0 = EvaluateChild(0, pRecord);
	LPCTSTR pcsz1 = EvaluateChild(1, pRecord);
	return _tcscmp(pcsz0, pcsz1);
}

int CIuExpressionFunctionBuild::CompareNoCase(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz0 = EvaluateChild(0, pRecord);
	LPCTSTR pcsz1 = EvaluateChild(1, pRecord);
	return _tcsicmp(pcsz0, pcsz1);
}

CIuExpressionElement* CIuExpressionFunctionBuild::Clone() const
{
	CIuExpressionFunctionBuild* pElement = new CIuExpressionFunctionBuild(*this);
	ASSERT(pElement);
	return pElement;
} 

CIuExpressionFunction* CIuExpressionFunctionBuild::Create()
{
	return new CIuExpressionFunctionBuild;
}

LPCTSTR CIuExpressionFunctionBuild::CRLF(const CIuRecord * pRecord) const
{
	m_sBuffer = _T("\r\n");
	if (GetChildCount() == 1)
		ReplicateString(m_sBuffer, EvaluateChildInt(0, pRecord));
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::CRLFMaxLength() const
{
	if (GetChildCount() != 1)
		return 2;
	int iMaxLen = CIuExpressionFunction::GetMaxLength();
	if (!IsChildConst(0))
	{
		TRACE("Warning: Constant expression expected to CRLF(): limiting to %d\n", iMaxLen);
	}
	else
	{
		iMaxLen = 2 * EvaluateChildInt(0, NULL);
		if (iMaxLen < 0)
			iMaxLen = 0;
	}
	return iMaxLen;
}

// DefVal(a, b) is a if a is non-empty, else b.
// DefVal saves times versus IFF(a, a, b), since the expression for
// the first argument need only be evaluated once.
//
// DefVal(a,b,c,d,...) is a if a does not take on any of the values c,d,e...,
// else b.
LPCTSTR CIuExpressionFunctionBuild::DefVal(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int nChildren = GetChildCount();
	if (nChildren < 3)
	{
		if (m_sBuffer.IsEmpty())
			m_sBuffer = EvaluateChild(1, pRecord);
	}
	else
	{
		for (int iChild = 2; iChild < nChildren; ++iChild)
		{
			LPCTSTR pcszChild = EvaluateChild(iChild, pRecord);
			if (m_sBuffer.CompareNoCase(pcszChild) == 0)
			{
				// match made
				m_sBuffer = EvaluateChild(1, pRecord);
				break;  
			}
		}
	}
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::DefVaiMaxLength() const
{
	return GetChildMaxLength(0, 1);
}

LPCTSTR CIuExpressionFunctionBuild::ExtractNamePart(const CIuRecord* pRecord) const
{
	// ExtractNamePart([Name], "x") where x indicates the part desired:
	// The [Name] value should be in LastName, FirstName, .. order.
#pragma __TODO("JerryL: ExtractNamePart(): Make smarter. / dont use CString")
	m_sBuffer = EvaluateChild(0, pRecord);
	CString sPart = EvaluateChild(1, pRecord);
	if (!m_sBuffer.IsEmpty() && !sPart.IsEmpty())
	{
		m_sBuffer.TrimRight();
		m_sBuffer.TrimLeft();
		int iComma = m_sBuffer.Find(',');
		if (iComma == -1)
		{
			m_sBuffer = "";
		}
		else
		{
			// Assume space-separated values to the right of the comma
			enum { nMaxParts = 6 };
			CStringArray asParts;
			asParts.SetSize(nMaxParts);
			asParts.ElementAt(0) = m_sBuffer.Left(iComma);
			m_sBuffer.Delete(0, iComma);
			for (int iPart = 1; iPart < nMaxParts && !m_sBuffer.IsEmpty(); ++iPart)
			{
				m_sBuffer.TrimLeft();
				int iSpace = m_sBuffer.Find(' ');
				if (iSpace == -1)
				{
					sPart = m_sBuffer;
					m_sBuffer = "";
				}
				else
				{
					asParts.ElementAt(iPart) = m_sBuffer.Left(iSpace);
					m_sBuffer.Delete(0, iSpace);
				}
			}
			// Convert letter in sPart to iPart, the index into asParts.
			switch (sPart.GetAt(0))
			{
			case 'L': case 'l': // Last Name
				iPart = 0;
				break;
			case 'F': case 'f': // First Name
				iPart = 1;
				break;
			case 'M': case 'm': // Middle name
				iPart = 2;
				break;
			case 'G': case 'g': // Generational
				iPart = 3;
				break;
			case 'P': case 'p': // Professional Suffix
				iPart = 4;
				break;
			case 'T': case 't': // title
				iPart = 5;
				break;
			default:
				iPart = -1;
				ASSERT(false);
				break;
			}
			if (iPart < 0 || iPart >= asParts.GetSize())
				m_sBuffer = "";
			else
			{
				m_sBuffer = asParts.GetAt(iPart);
				m_sBuffer.TrimRight();
				m_sBuffer.TrimLeft();
			}
		}
	}
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::ExtractNamePartMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::FirstName(const CIuRecord* pRecord) const
{
	// FirstName([Name])
	// Compare to LastName([Name]), FlipName([Name])
	// Returns the first name portion

	// Start with value of first child.
	m_sBuffer = EvaluateChild(0, pRecord);
	// if no comma, or multiple commas, return the empty string 
	// See LastName()
	int iComma = m_sBuffer.Find(_T(','));
	if (iComma == -1)
	{
		// No comma, return empty string
		m_sBuffer = "";
		return m_sBuffer;
	}
	int iComma2 = m_sBuffer.Find(_T(','), iComma + 1);
	if (iComma2 != -1)
	{
		// more than one comma, return empty string
		m_sBuffer = "";
		return m_sBuffer;
	}
	// Exactly one comma found
	// Return the text to the right of that string
	m_sBuffer = m_sBuffer.Mid(iComma+1);  // rhs of comma
	m_sBuffer.TrimRight();
	m_sBuffer.TrimLeft();
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::FirstNameMaxLength() const
{
	return GetChildMaxLength(0);  // Getting a first name may only decrease the original length.
}

LPCTSTR CIuExpressionFunctionBuild::FlipName(const CIuRecord* pRecord) const
{
	// FlipName([Name])
	// if there is a comma in the name field, return string with first name first.
	//     Last, First M  -> First M Last
	// if there isn't a comma in the name field, return it as is.
	//     Last -> Last
#pragma __TODO("Remove reliance on CString")
	// Start with value of first child.
	m_sBuffer = EvaluateChild(0, pRecord);
	// No change if no comma, or multiple commas...
	int iComma = m_sBuffer.Find(_T(','));
	if (iComma == -1)
		return m_sBuffer;  // no comma, leave as is.
	int iComma2 = m_sBuffer.Find(_T(','), iComma + 1);
	if (iComma2 != -1)
		return m_sBuffer; // more than one comma, leave as is.
	// Exactly one comma found 
	// Last, First -> First Last
	CString sFirst = m_sBuffer.Mid(iComma+1);  // rhs of comma
	sFirst.TrimRight();
	sFirst.TrimLeft();
	CString sLast = m_sBuffer.Left(iComma);   // lhs of comma
	sLast.TrimRight();
	sLast.TrimLeft();
	m_sBuffer = sFirst;
	if (!sFirst.IsEmpty() && !sLast.IsEmpty())
		m_sBuffer += _T(' ');
	m_sBuffer += sLast;
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::FlipNameMaxLength() const
{
	return GetChildMaxLength(0);  // Flipping a name may only decrease the original length.
}

const CIuExpressionFunctionDef* CIuExpressionFunctionBuild::GetFunctionDefs()
{
	return adefs;
}

LPCTSTR CIuExpressionFunctionBuild::HyphenatePhone(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iLen = m_sBuffer.GetLength();
	if (iLen == 7)
	{
		m_sBuffer.Insert(3, '-');
	}
	else if (iLen == 6)
	{
		// This would be areacode-exchange
		m_sBuffer.Insert(3, '-');
	}
	else if (iLen == 10)
	{
		m_sBuffer.Insert(6,'-');
		m_sBuffer.Insert(3,'-');
	}
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::HyphenatePhoneMaxLength() const
{
	int iMaxLen = GetChildMaxLength(0);
	if (iMaxLen == 7)
		++iMaxLen;
	else if (iMaxLen == 10)
		iMaxLen += 2;
	return iMaxLen;
}

LPCTSTR CIuExpressionFunctionBuild::HyphenateZIP(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iLen = m_sBuffer.GetLength();
	if (iLen == 9 || iLen == 11)
		m_sBuffer.Insert(5,'-');
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::HyphenateZIPMaxLength() const
{
	int iMaxLen = GetChildMaxLength(0);
	if (iMaxLen == 9 || iMaxLen == 11)
		++iMaxLen;
	return iMaxLen;
}

// Iff(a, b, c) corresponds to the ternary operator : (a ? b : c)
// If the first expression is non-zero, b is returned.
// If the first expression is zero (or the empty string), c is returned.
LPCTSTR CIuExpressionFunctionBuild::Iff(const CIuRecord* pRecord) const
{
	bool f = EvaluateChildBool(0, pRecord);
	m_sBuffer = EvaluateChild((f ? 1 : 2), pRecord);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::IffMaxLength() const
{
	// Return the longer of the two subexpressions.
	return GetChildMaxLength(1, 2);
}

bool CIuExpressionFunctionBuild::IsConst() const
{
	// Conditional functions (iff and lookup) and special functions
	switch (GetType())
	{
		case exprLatLongDistance:
			return false;
		case exprIff:
			if (IsChildConst(0))
			{
				bool f = EvaluateChildBool(0, 0);
				return IsChildConst(f ? 1: 2);
			}
			break;
		case exprLookup:
			if (IsChildConst(0))
			{
				int iWhich = EvaluateChildInt(0, 0);
				return IsChildConst(iWhich + 1);
			}
			break;
	}
	return CIuExpressionFunctionBuild_super::IsConst();
}


LPCTSTR CIuExpressionFunctionBuild::LatLongDistance(const CIuRecord* pRecord) const
{
	// We could do some special optimizations but this is a low performance function.
	ASSERT(pRecord);
	CIuLatLongCoordinate Coord2;
	pRecord->GetLatLong(Coord2);

	CIuLatLongCoordinate Coord1(EvaluateChild(0, pRecord), EvaluateChild(1, pRecord));
#pragma __TODO("Remove reliance on CString")
	CString Direction;
	CIuLatLongDistance Distance = CIuLatLongCoordinate::GetDistance(Coord1, Coord2, &Direction);
	if (!Distance.IsValid())
	{
		m_sBuffer = "";
		return m_sBuffer;
	}

	CIuLatLongDistance::CIuLatLongDistanceUnits Units;
	LPCTSTR pcszUnits = EvaluateChild(2, pRecord);
	if (_tcsicmp(pcszUnits, "f") == 0 || _tcsicmp(pcszUnits, "feet") == 0)
		Units = CIuLatLongDistance::LatLongUnitsFeet;
	else
		Units = CIuLatLongDistance::LatLongUnitsMiles;

	m_sBuffer = Distance.AsString(Units, true);

	if (EvaluateChildBool(3, pRecord))
	{
		// Append directionals
		m_sBuffer += _T(" ");
		m_sBuffer += Direction;
	}

	return m_sBuffer;
}

int CIuExpressionFunctionBuild::LatLongDistanceMaxLength() const
{
	// Must be large enough to handle the distance, the unit designator (currently miles) and the directional
	// which is currently 2 characters plus a space.
	// 20 should be sufficient
	return 20;
}


LPCTSTR CIuExpressionFunctionBuild::LastName(const CIuRecord* pRecord) const
{
	// LastName([Name])
	// if there is one comma in the name, return string to the left of the comma.
	//     Last, First M  -> Last
	// if there isn't a single comma in the name field, return it as is.
	// This would be the case if the name was from a business record.
	//     Last -> Last

	// Start with value of first child.
	m_sBuffer = EvaluateChild(0, pRecord);
	// No change if no comma, or multiple commas...
	int iComma = m_sBuffer.Find(_T(','));
	if (iComma == -1)
		return m_sBuffer;  // no comma, leave as is.
	int iComma2 = m_sBuffer.Find(_T(','), iComma + 1);
	if (iComma2 != -1)
		return m_sBuffer; // more than one comma, leave as is.
	// Exactly one comma found
	m_sBuffer = m_sBuffer.Left(iComma);   // lhs of comma
	m_sBuffer.TrimRight();
	m_sBuffer.TrimLeft();
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::LastNameMaxLength() const
{
	return GetChildMaxLength(0);  // May only decrease the original length.
}

LPCTSTR CIuExpressionFunctionBuild::Left(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iLeft = EvaluateChildInt(1, pRecord);
	m_sBuffer = m_sBuffer.Left(iLeft);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::LeftMaxLength() const
{
	// If length is const, return it
	if (IsChildConst(1))
		return max(0, EvaluateChildInt(1, 0));

	// Will never return smaller than the input... but may the
	// actual length may or may not be known (it doesn't have to be a constant...).
	return GetChildMaxLength(0);
}

int CIuExpressionFunctionBuild::Len(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	return _tcslen(pcsz);
}

// Lookup(x, a, b, c, ...) returns a if x == 0, b if x == 1, c if x == 2, and so on.
LPCTSTR CIuExpressionFunctionBuild::Lookup(const CIuRecord * pRecord) const
{
	int iIndex = EvaluateChildInt(0, pRecord) + 1;
	m_sBuffer = EvaluateChild(iIndex, pRecord);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::LookupMaxLength() const
{
	return GetChildMaxLength(1, GetChildCount()-1);
}

// MakeAddress(PrimaryNumber, StreetAddress, SecondaryNumber)
LPCTSTR CIuExpressionFunctionBuild::MakeAddress(const CIuRecord* pRecord) const
{
	if (pRecord && pRecord->IsNoMail())
	{
		return szNonSolicitUpper;
	}

	// House + Street + UnitDir (#) + Apt
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.TrimLeft();
	m_sBuffer.TrimRight();

	if (!m_sBuffer.IsEmpty())
		m_sBuffer += " ";
	m_sBuffer += EvaluateChild(1, pRecord);
	m_sBuffer.TrimRight();

	bool fRR = m_sBuffer.GetLength() >= 3 &&
		(_memicmp(LPCTSTR(m_sBuffer), _T("RR "), 3) == 0 ||
		_memicmp(LPCTSTR(m_sBuffer), _T("HC "), 3) == 0 ||
		m_sBuffer.CompareNoCase("RR") == 0 ||
		m_sBuffer.CompareNoCase("HC") == 0);

	bool fPob = m_sBuffer.CompareNoCase("PO BOX") == 0;

	LPCTSTR pcszSecNo = _tcsskipws(EvaluateChild(2, pRecord));

	if (!m_sBuffer.IsEmpty() && *pcszSecNo != '\0')
	{
		if (fRR)
			m_sBuffer += " BOX ";
		else if (fPob)
			m_sBuffer += " ";
		// Watch for deformed secondary numbers that already start
		// with a # sign
		else if (pcszSecNo[0] == '#')
			m_sBuffer += " ";
		else
			m_sBuffer += " #";
		m_sBuffer += pcszSecNo;
	}
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeAddressMaxLength() const
{
#pragma __TODO("Handle special case like RR/POB")
	return max(int(_tcslen(szNonSolicitMixed)), GetChildMaxLength(0, 2) + 3);
}

LPCTSTR CIuExpressionFunctionBuild::MakeCityState(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	if (!m_sBuffer.IsEmpty())
		m_sBuffer += ", ";
	m_sBuffer += EvaluateChild(1, pRecord);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeCityStateMaxLength() const
{
	return GetChildMaxLength(0, 2) + 2;
}

LPCTSTR CIuExpressionFunctionBuild::MakeLastLine(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	if (!m_sBuffer.IsEmpty())
		m_sBuffer += ", ";
	m_sBuffer += EvaluateChild(1, pRecord);
	if (!m_sBuffer.IsEmpty())
		m_sBuffer += " ";
	m_sBuffer += EvaluateChild(2, pRecord);
	m_sBuffer.TrimRight();
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeLastLineMaxLength() const
{
	return GetChildMaxLength(0, 2) + 1 + 2;
}

LPCTSTR CIuExpressionFunctionBuild::MakeLower(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.MakeLower();
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::MakeLowerMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::MakeName(const CIuRecord* pRecord) const
{
	LPCTSTR pcszLast	= _tcsskipws(EvaluateChild(0, pRecord));
	LPCTSTR pcszFirst = _tcsskipws(EvaluateChild(1, pRecord));
	LPCTSTR pcszMI = _tcsskipws(EvaluateChild(2, pRecord));
	LPCTSTR pcszGen = _tcsskipws(EvaluateChild(3, pRecord));
	LPCTSTR pcszProSuffix = _tcsskipws(EvaluateChild(4, pRecord));
	LPCTSTR pcszTitle	= _tcsskipws(EvaluateChild(5, pRecord));
	::MakeName(m_sBuffer, makeNameLastFirst, pcszLast, pcszFirst, pcszMI, pcszGen, pcszProSuffix, pcszTitle);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeNameMaxLength() const
{
	return GetChildMaxLength(0, 4) + 5;
}

LPCTSTR CIuExpressionFunctionBuild::MakeNameInitials(const CIuRecord* pRecord) const
{
	LPCTSTR pcszLast	= _tcsskipws(EvaluateChild(0, pRecord));
	LPCTSTR pcszFirst = _tcsskipws(EvaluateChild(1, pRecord));
	LPCTSTR pcszMI = _tcsskipws(EvaluateChild(2, pRecord));
	LPCTSTR pcszGen = _tcsskipws(EvaluateChild(3, pRecord));
	LPCTSTR pcszProSuffix = _tcsskipws(EvaluateChild(4, pRecord));
	LPCTSTR pcszTitle	= _tcsskipws(EvaluateChild(5, pRecord));
	::MakeName(m_sBuffer, makeNameLastFirst, pcszLast, pcszFirst, pcszMI, pcszGen, pcszProSuffix, pcszTitle, makeNameInitialsOnly);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeNameInitialsMaxLength() const
{
	return GetChildMaxLength(0, 4) + 5;
}

LPCTSTR CIuExpressionFunctionBuild::MakePhone(const CIuRecord* pRecord) const
{
	if (pRecord && pRecord->IsNoPhone())
	{
		m_sBuffer = _T("0000000000");
		return m_sBuffer;
	}
	// area + prefix + phone
	// Make sure we have plenty of leading zeros
	m_sBuffer = _T("0000000000");
	LPCTSTR pcszAc	= _tcsskipws(EvaluateChild(0, pRecord));
	m_sBuffer += pcszAc;
	if (GetChildCount() > 1)
	{
		LPCTSTR pcszPrefix = _tcsskipws(EvaluateChild(1, pRecord));
		m_sBuffer += pcszPrefix;
		if (GetChildCount() > 2)
		{
			LPCTSTR pcszSuffix = _tcsskipws(EvaluateChild(2, pRecord));
			m_sBuffer += pcszSuffix;
		}
	}
	if (m_sBuffer.GetLength() > 10)
		m_sBuffer = m_sBuffer.Right(10);
	// If what remains is all zeros, then blank it out.
	// We do NOT want 10 zeros, they consume too much space during build.
	if (m_sBuffer.Compare(_T("0000000000")) == 0)
		m_sBuffer = "";
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakePhoneMaxLength() const
{
	return 10;
}

LPCTSTR CIuExpressionFunctionBuild::MakeStreet(const CIuRecord* pRecord) const
{
	// PreDir + Street + Suffix + PostDir 
	m_sBuffer = _tcsskipws(EvaluateChild(0, pRecord));
	m_sBuffer.TrimRight();

	LPCTSTR pcszStreetName = _tcsskipws(EvaluateChild(1, pRecord));
	m_sBuffer += " ";
	m_sBuffer += pcszStreetName;
	m_sBuffer.TrimRight();

	LPCTSTR pcszSuffix = _tcsskipws(EvaluateChild(2, pRecord));
	m_sBuffer += " ";
	m_sBuffer += pcszSuffix;
	m_sBuffer.TrimRight();

	LPCTSTR pcszPostDir = _tcsskipws(EvaluateChild(3, pRecord));
	m_sBuffer += " ";
	m_sBuffer += pcszPostDir;
	m_sBuffer.TrimRight();
	m_sBuffer.TrimLeft();
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeStreetMaxLength() const
{
	// PreDir+" "+Street+" "+Suffix+" "+PostDir
	return GetChildMaxLength(0, 3) + 3;
}

LPCTSTR CIuExpressionFunctionBuild::MakeUpper(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.MakeUpper();
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::MakeUpperMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::MakeZIP(const CIuRecord* pRecord) const
{
	LPCTSTR pcszZip5	= _tcsskipws(EvaluateChild(0, pRecord));
	int iZip5 = _tcslen(pcszZip5);
	LPCTSTR pcszAddon = _tcsskipws(EvaluateChild(1, pRecord));
	int iAddon = _tcslen(pcszAddon);
	LPCTSTR pcszDpbc  = _tcsskipws(EvaluateChild(2, pRecord));
	int iDpbc = _tcslen(pcszDpbc);

	TCHAR szZip[5+4+3+1];
	memset(szZip, '0', 12);
	szZip[12] = '\0';

	memcpy(szZip,		pcszZip5,	min(5, iZip5));
	memcpy(szZip + 5, pcszAddon,	min(4, iAddon));
	memcpy(szZip + 9, pcszDpbc,	min(3, iDpbc));

	if (memcmp(szZip + 9, "000",	3) == 0)
	{
		szZip[9] = '\0';
		if (memcmp(szZip + 5, "0000",	4) == 0)
		{
			szZip[5] = '\0';
			if (memcmp(szZip, "00000",	5) == 0)
				szZip[0] = '\0';
		}
	}
	m_sBuffer = szZip;
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MakeZIPMaxLength() const
{
	// ZIP+4+DPBC=12 
	return 12;
}

// Mid(s, iMid, iLength)
// iMid is zero-based position to start the extraction within the string.
// iLength is the # of characters to extract starting at position iMid.
//
// returns s[iMid..iMid + iLength - 1]
//
LPCTSTR CIuExpressionFunctionBuild::Mid(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iMid = EvaluateChildInt(1, pRecord);
	int iLength = EvaluateChildInt(2, pRecord);
	if (iMid >= 0 && iLength >= 0 && iMid + iLength <= m_sBuffer.GetLength())
		m_sBuffer = m_sBuffer.Mid(iMid, iLength);
	else
		m_sBuffer = _T("");
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::MidMaxLength() const
{
	// If length is const, return it
	if (IsChildConst(2))
		return max(0, EvaluateChildInt(2, 0));

	// Will never return smaller than the input... but may the
	// actual length may or may not be known (it doesn't have to be a constant...).
	return GetChildMaxLength(2);
}

LPCTSTR CIuExpressionFunctionBuild::Newline(const CIuRecord * pRecord) const
{
	m_sBuffer = _T('\n');
	if (GetChildCount() == 1)
		ReplicateString(m_sBuffer, EvaluateChildInt(0, pRecord));
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::NewlineMaxLength() const
{
	if (GetChildCount() != 1)
		return 1;
	int iMaxLen = CIuExpressionFunction::GetMaxLength();
	if (!IsChildConst(0))
	{
		TRACE("Warning: Constant expression expected to Newline(): limiting to %d\n", iMaxLen);
	}
	else
	{
		iMaxLen = EvaluateChildInt(0, NULL);
		if (iMaxLen < 0)
			iMaxLen = 0;
	}
	return iMaxLen;
}

CIuExpressionFunctionBuild& CIuExpressionFunctionBuild::operator=(const CIuExpressionFunctionBuild& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionFunctionBuild_super::operator=(rExpressionElement);
	return *this;
}

CIuExpressionElement* CIuExpressionFunctionBuild::Optimize()
{
	// This virtual function is special in that the object being
	// called may delete itself! Be careful when doing this. If you 
	// delete yourself, do it as the last thing before exitting.

	// Conditional functions (iff and lookup)
	switch (GetType())
	{
		case exprIff:
			if (IsChildConst(0))
			{
				// Replace Iff(true, e1, e2) with e1
				// Replace Iff(false, e1, e2) with e2
				bool f = EvaluateChildBool(0, 0);
				CIuExpressionElement * pChild = DetachChild(f ? 1 : 2);
				ASSERT(pChild);
				delete this;
				return pChild;
			}
			break;
		case exprLookup:
			if (IsChildConst(0))
			{
				// Replace Lookup(0, e1, e2, e3...) by e1
				// Replace Lookup(1, e1, e2, ...) by e2
				// and so on.
				int iWhich = EvaluateChildInt(0, 0);
				CIuExpressionElement * pChild = DetachChild(iWhich + 1);
				ASSERT(pChild);
				delete this;
				return pChild;
			}
			break;
	}
	return CIuExpressionFunctionBuild_super::Optimize();
}


// Paste() is a special form of the concatenation of a variable number
// of strings.  Its intent is to handle insertion of separators between
// data values, where the data values are possible empty. 
//
// Example: Paste(City, ",_", State), where:
// City= State=  Paste=
// ""    ""      ""
// ""    "S"     "S"
// "C"   "S"     "C,_S"
// "C"   ""      "C"
//
// Example: Paste(City, ",_", State, "__", ZIP), where
// City=  State=  ZIP= Paste=
// ""		 ""      ""   ""
// ""     ""      "Z"  "Z"
// ""     "S"     "Z"  "S__Z"
// ""     "S"     ""   "S"
// "C"    "S"     ""   "C,_S"
// "C"    "S"     "Z"  "C,_S__Z"
// "C"    ""      "Z"  "C,_Z"
// "C"    ""      ""   "C"
LPCTSTR CIuExpressionFunctionBuild::Paste(const CIuRecord* pRecord) const
{
	// Find iFirst, the first even-indexed child with a non-empty value.
	m_sBuffer = _T("");
	int nChildren = GetChildCount();
	for (int iFirst = 0; iFirst < nChildren; iFirst += 2)
	{
		m_sBuffer = EvaluateChild(iFirst, pRecord);
		if (!m_sBuffer.IsEmpty())
			break;
	}
	// Find iNext, the next even-indexed child with a non-empty value.
	// If such a value is found, concatenate the value at iFirst+1
	// (the separator) before concatenating the next value.
	for (int iNext = iFirst + 2; iNext < nChildren; iNext += 2)
	{
		LPCTSTR pcszNext = EvaluateChild(iNext, pRecord);
		if (*pcszNext != '\0')
		{
			m_sBuffer += EvaluateChild(iFirst + 1, pRecord);
			m_sBuffer += pcszNext;
			iFirst = iNext;
		}
	}
	return m_sBuffer;
}

// PasteSpace() combines all the input fields into one string --- separating them
//	with spaces.
LPCTSTR CIuExpressionFunctionBuild::PasteSpace(const CIuRecord* pRecord) const
{
	m_sBuffer = _T("");  
	int nChildren = GetChildCount();
	for (int i = 0; i < nChildren; ++i)
	{
		LPCTSTR pcszCurrent = EvaluateChild(i, pRecord);
		if (*pcszCurrent == '\0')
			continue;
		if (!m_sBuffer.IsEmpty())
		{
			int iLength = m_sBuffer.GetLength();
			if (m_sBuffer.GetAt(iLength - 1) != ' ')
				m_sBuffer += ' ';
		}
		m_sBuffer += pcszCurrent;
	}
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::PasteSpaceMaxLength() const
{
	return GetChildMaxLength(0, GetChildCount()-1) + max(0, (GetChildCount() - 1));
}

// Repeat(string, number=1)
// returns string repeated number of times
LPCTSTR CIuExpressionFunctionBuild::Repeat(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	if (GetChildCount() >= 2)
		ReplicateString(m_sBuffer, EvaluateChildInt(1, pRecord));
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::RepeatMaxLength() const
{
	int iMaxLen = GetChildMaxLength(0);
	if (IsChildConst(1))
	{
		int nRepeat = EvaluateChildInt(1, NULL);
		if (nRepeat < 0)
			iMaxLen = 0;
		else
		{
			iMaxLen *= nRepeat;
			if (iMaxLen < 0)
			{
				TRACE("Warning: overflow computing maximum length of Repeat(expr, %d)\n", nRepeat);
				iMaxLen = CIuExpressionFunction::GetMaxLength();
			}
		}
	}
	else
	{
		// Use the default value for a field width, since
		// cannot evaluate the second parameter (# of repetitions)
		TRACE("Warning: Constant expression expected for second argument to Repeat()\n");
		iMaxLen = CIuExpressionFunction::GetMaxLength();
	}
	return iMaxLen;
}

LPCTSTR CIuExpressionFunctionBuild::Right(const CIuRecord* pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iRight = EvaluateChildInt(1, pRecord);
	m_sBuffer = m_sBuffer.Right(iRight);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::RightMaxLength() const
{
	// If length is const, return it
	if (IsChildConst(1))
		return max(0, EvaluateChildInt(1, 0));

	// Will never return smaller than the input... but may the
	// actual length may or may not be known (it doesn't have to be a constant...).
	return GetChildMaxLength(0);
}

// An internal function to sort ZIP+4 before ZIP (to be used in a ORDERBY clause)
// Make a five-digit ZIP greater than a 9-digit ZIP by turning the first digit
// into a letter.  E.g.: "12345" -> "A2345"
LPCTSTR CIuExpressionFunctionBuild::SortZIP9First(const CIuRecord * pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	int iLen = m_sBuffer.GetLength();
	if (iLen == 0)
		m_sBuffer = _T('A');
	else if (iLen < 9)  // a very weak definition of 5-digit ZIP
		m_sBuffer.SetAt(0, TCHAR(m_sBuffer.GetAt(0) - '0' + 'A'));
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::SortZIP9FirstMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::Space(const CIuRecord * pRecord) const
{
	m_sBuffer = _T(' ');
	if (GetChildCount() == 1)
		ReplicateString(m_sBuffer, EvaluateChildInt(0, pRecord));
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::SpaceMaxLength() const
{
	if (GetChildCount() != 1)
		return 1;
	int iMaxLen = CIuExpressionFunction::GetMaxLength();
	if (!IsChildConst(0))
	{
		TRACE("Warning: Constant expression expected to Space(): limiting to %d\n", iMaxLen);
	}
	else
	{
		iMaxLen = EvaluateChildInt(0, NULL);
		if (iMaxLen < 0)
			iMaxLen = 0;
	}
	return iMaxLen;
}

LPCTSTR CIuExpressionFunctionBuild::StateAbbr2Code(const CIuRecord * pRecord) const
{
	int nChildren = GetChildCount();
	if (nChildren < 1)
		m_sBuffer = _T("");
	else
		m_sBuffer = CIuStatesRaw::Abbr2Code(EvaluateChild(0, pRecord));
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::StateAbbr2CodeMaxLength() const
{
	return 2;
}

LPCTSTR CIuExpressionFunctionBuild::StateCode2Abbr(const CIuRecord * pRecord) const
{
	int nChildren = GetChildCount();
	if (nChildren < 1)
		m_sBuffer = _T("");
	else
		m_sBuffer = CIuStatesRaw::Code2Abbr(EvaluateChild(0, pRecord));
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::StateCode2AbbrMaxLength() const
{
	return 2;
}

// Surround() is a special form of the concatenation of a variable number
// of strings.  Its intent is to wrap a non-empty inner string by two 
// outer strings.  If the inner string is empty, an empty string results.
//
// Surround(L, a, R) is L + a + R if a is non-empty, else a (the empty string)
// Surround(L, a0, a1, ..., aN, R) is Surround(L, a0+a1+...+aN, R)
// Surround(L, a) is L + a if a is not empty.
// Surround(L) is empty (by definition)
LPCTSTR CIuExpressionFunctionBuild::Surround(const CIuRecord * pRecord) const
{
	m_sBuffer = _T("");
	int nChildren = GetChildCount();
	if (nChildren == 2)
	{
		LPCTSTR pcszInner = EvaluateChild(1, pRecord);
		if (*pcszInner != '\0')
		{
			m_sBuffer = EvaluateChild(0, pRecord);
			m_sBuffer += pcszInner;
		}
	}
	else if (nChildren > 2)
	{
		m_sBuffer = EvaluateChild(0, pRecord);

		bool fEmpty = true;
		for (int iChild = 1; iChild < nChildren - 1; ++iChild)
		{
			LPCTSTR pcszInner = EvaluateChild(iChild, pRecord);
			if (*pcszInner == '\0')
				continue;
			fEmpty = false;
			m_sBuffer += pcszInner;
		}

		if (fEmpty)
			m_sBuffer = _T("");
		else
			m_sBuffer += EvaluateChild(nChildren - 1, pRecord);
	}
	return m_sBuffer;
}

LPCTSTR CIuExpressionFunctionBuild::Tab(const CIuRecord * pRecord) const
{
	m_sBuffer = _T('\t');
	if (GetChildCount() == 1)
		ReplicateString(m_sBuffer, EvaluateChildInt(0, pRecord));
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::TabMaxLength() const
{
	if (GetChildCount() != 1)
		return 1;
	int iMaxLen = CIuExpressionFunction::GetMaxLength();
	if (!IsChildConst(0))
	{
		TRACE("Warning: Constant expression expected to Tab(): limiting to %d\n", iMaxLen);
	}
	else
	{
		iMaxLen = EvaluateChildInt(0, NULL);
		if (iMaxLen < 0)
			iMaxLen = 0;
	}
	return iMaxLen;
}

LPCTSTR CIuExpressionFunctionBuild::TAPIPhone(const CIuRecord* pRecord) const
{
	// Convert a phone number of the form 
	//    9999999999
	// to its TAPI canonical format in the USA
	//    +1 (999) 99999999
	//
	// Intended call: TAPIPhone([ACPhone]) or TAPIPhone([ACPhoneFax])
	// where the value of [ACPhone] or [ACPhoneFax] is a nine-digit string.
	//
	// Needed to populate ACT phone numbers.
	m_sBuffer = EvaluateChild(0, pRecord);
	if (!m_sBuffer.IsEmpty())
	{
		if (m_sBuffer.GetLength() != 10)
			m_sBuffer.Delete(0, m_sBuffer.GetLength());  // make string empty
		else 
		{
			// Insert substrings from right to left
			// Transforms "ABCDEFGHJ..." into "+1 (ABC) DEFGHIJ..."
			m_sBuffer.Insert(0, _T("+1 ("));  // prepend country code for US and Canada
			m_sBuffer.Insert(4+3, _T(") "));  // insert right paren on other side of AC
		}
	}
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::TAPIPhoneMaxLength() const
{
	// 1234567890123456
	// +1 (abc) defghij
	return 16;
}

LPCTSTR CIuExpressionFunctionBuild::Thousands(const CIuRecord * pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.TrimRight();
	m_sBuffer.TrimLeft();
	StringThousandSeparated(m_sBuffer, m_sBuffer, ',', 3);
	return m_sBuffer;
}

int CIuExpressionFunctionBuild::ThousandsMaxLength() const
{
	int iMaxLen = 0;
	int iChildMaxLen = GetChildMaxLength(0);
	if (iChildMaxLen > 0)
		iMaxLen = iChildMaxLen + (iChildMaxLen - 1) / 3;
	return iMaxLen;
}

LPCTSTR CIuExpressionFunctionBuild::Trim(const CIuRecord * pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.TrimRight();
	m_sBuffer.TrimLeft();
	return m_sBuffer;
}
LPCTSTR CIuExpressionFunctionBuild::TrimLeft(const CIuRecord * pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.TrimLeft();
	return m_sBuffer;
}
int CIuExpressionFunctionBuild::TrimMaxLength() const
{
	return GetChildMaxLength(0);
}

LPCTSTR CIuExpressionFunctionBuild::TrimRight(const CIuRecord * pRecord) const
{
	m_sBuffer = EvaluateChild(0, pRecord);
	m_sBuffer.TrimRight();
	return m_sBuffer;
}

// Initially used for Paste() and Surround().
int CIuExpressionFunctionBuild::VarArgConcatenationMaxLength() const
{
	// Allow for spaces between individual components
	return GetChildMaxLength(0, GetChildCount()-1) + GetChildCount() - 1;
}
