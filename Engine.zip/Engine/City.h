#ifndef _ENGINE_CITY_H_
#define _ENGINE_CITY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENT_H_
#	include "Engine\GeoElement.h"
#endif	// _ENGINE_GEOELEMENT_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCity, CIuGeoElement }}
#define CIuCity_super CIuGeoElement

#pragma pack(1)
class CIuCity : public CIuCity_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	LPCTSTR GetCity() const;
	int GetMsaNo() const;
	LPCTSTR GetState() const;
	LPCTSTR GetStateCity() const;;
	void GetZipList(CIuGeoList&) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoCity;

	// Fixed Data:
		int m_iMsaNo;
	// Variable Data:
		// List of associated ZIP's	
	// Strings:
		//	0) State abbreviation/City
		//	1) City name
		//	2) State abbreviation
//}}Data

};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline LPCTSTR CIuCity::GetCity() const
{
	return GetString(1);
}

inline int CIuCity::GetMsaNo() const
{
	return m_iMsaNo;
}

inline LPCTSTR CIuCity::GetState() const
{
	return GetString(2);
}

inline LPCTSTR CIuCity::GetStateCity() const
{
	return GetName();
}

#endif // _ENGINE_CITY_H_
