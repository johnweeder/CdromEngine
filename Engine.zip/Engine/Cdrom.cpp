#include "StdAfx.h"
//{{Include
#include "Cdrom.h"
#include "Cdroms.h"
#include "SourceDescriptorSpec.h"
#include "CdromSpec.h"
#include "CdromInput.h"
#include "CdromSelectDlg.h"
#include "SourceDescriptors.h" 
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Error\Error.h"
#include "Engine.h"
#include "..\Version.h"
#include "RecordDef.h"
#include "BTrees.h"
#include "Tokens.h"
#include "Address.h"
#include "Alts.h"
#include "ExportDefs.h"
#include "ReportDefs.h"
#include "Database.h"
#include "Meters.h"
#include "ReleaseNotes.h"
#include "Registration.h"
#include "UserInterface.h"
#include "Indexes.h"
#include "Blobs.h"
#include "Splash.h"
#include "Miscellaneous.h"
#include "Registration.h"
#include "Common\SortedStringArray.h"
#include "Data\DataFilename.h"
#include "MeterSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdrom, CIuCdrom_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdrom)
const CIuVersionNumber versionCdrom(1999,0,9,2900);
const	CIuVersionNumber versionCdromMax(2000,1,5,304);
const	CIuVersionNumber versionCdromMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROM, CIuCdrom, CIuCdrom_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_ALTS, GetAlts_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_ALTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_BTREES, GetBTrees_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_BTREES, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_TOKENS, GetTokens_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_TOKENS, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_DATABASE, GetDatabase_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_DATABASE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_EXPORTDEFS, GetExportDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_EXPORTDEFS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_REPORTDEFS, GetReportDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_REPORTDEFS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_METERS, GetMeters_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_METERS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_RELEASENOTES, GetReleaseNotes_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_RELEASENOTES, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_SPLASH, GetSplash_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_SPLASH, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_BLOBS, GetBlobs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_BLOBS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_SOURCES, GetSources_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdrom, IDS_ENGINE_PROP_SOURCES, editorUsePropName)

	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_PACK, GetPack_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_PAGE(CIuCdrom, IDS_ENGINE_PPG_CDROM, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdrom, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuCdrom, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_CDROM, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCdrom, IDS_ENGINE_PROP_SPLITSIZE, GetSplitSize, SetSplitSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCdrom, IDS_ENGINE_PROP_SPLITSIZE, IDS_ENGINE_PPG_CDROM, 0, INT_MAX, 0)

	IU_ATTRIBUTE_PAGE(CIuCdrom, IDS_ENGINE_PPG_CDROM_OBJECTS, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_INPUT, GetInput_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_INPUT, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_SIC, GetSic_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_SIC, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_ADDRESS, GetAddress_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_ADDRESS, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_GEO, GetGeo_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_GEO, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_USERINTERFACE, GetUserInterface_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_USERINTERFACE, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_REGISTRATION, GetRegistration_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_REGISTRATION, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdrom, IDS_ENGINE_PROP_REPOSITORY, GetObjectRepository_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdrom, IDS_ENGINE_PROP_REPOSITORY, IDS_ENGINE_PPG_CDROM_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_ACTION(CIuCdrom, IDS_ENGINE_ACTION_VIEWPACK, ActionViewPack, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdrom, IDS_ENGINE_ACTION_VIEWPACK, IDS_ENGINE_PPG_CDROM_OBJECTS, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdrom::CIuCdrom() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdrom::~CIuCdrom()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuCdrom::ActionViewPack(const CIuPropertyCollection&, CIuOutput&)
{
	IU_TRY_ERROR
	{
		GetPack().Open(GetFilename(), true, true, packDefaultBlockSize);
		GetPack().Edit();
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
	}
	GetPack().Close();
	return CString("Success");
}


bool CIuCdrom::Build(CIuOutput& Output, CIuFlags Flags)
{
	CString sStarted;
	sStarted.Format(_T("Build Started, Flags=%08lX"), DWORD(Flags));
	Log(sStarted);

	// Build the object list
	// Notify everyone of the repository object
	UpdateObjectRepository(Output);

	if (Flags.Test(cdromsBuildDeleteCdrom))
		Delete(&Output);

	if (Flags.Test(cdromsBuildDeleteStart))
	{
		if (!GetInput().Build(*this, Output, cdromsBuildDeleteStart))
			return false;
		
		if (!BuildChildren(Output, cdromsBuildDeleteStart))
			return false;

		SaveDelete(GetFilename(), &Output);
	}

	if (Flags.Test(cdromsBuildInput))
	{
		if (!GetInput().Build(*this, Output, Flags & cdromsBuildInput))
			return false;
	}

	if (Flags.Test(cdromsBuildCompress))
	{
		// Clear out the database index list and
		// data source list. Each data component
		// will rebuild this lists as need
		if (HasDatabase())
			GetDatabase().GetIndexes().RemoveAll();			
		GetSources().RemoveAll();

		// Build the object list
		UpdateObjectRepository(Output);

		// Compress
		if (!BuildChildren(Output, Flags & cdromsBuildCompress))
			return false;
	}

	if (Flags.Test(cdromsBuildPack))
	{
		UpdateObjectRepository(Output);

#pragma __TODO("Set up any information needed specifically by the Pack file")
		GetPack().Open(GetFilename(), false, true, packDefaultBlockSize);

		// Write the GetObjectRepository() to the Pack
		// This is always write and it is written first so that it
		// is near to the middle of the cdrom.
		// Don't update the repository for an update. It must be correct.
		// This means that update won't work if new objects are added or
		// old objects are deleted.
		// Also, note that an update may move objects to the end of the file
		// if they could not be updated in their current location.
		if (!Flags.Test(cdromsBuildUpdate))
		{
			CString sType = IuClassFactoryGetType(IDS_DATA_OBJECT_OBJECTREPOSITORY);
			CString sRepositoryName;
			sRepositoryName.Format("/%s/%s", LPCTSTR(sType), GetObjectRepository().GetID().AsString());
			int iBytes = GetPack().Pack(sRepositoryName, GetObjectRepository());
			Output.OutputF(_T("Packed CD-ROM master repository\n\t%s\n\t%s\n\t%d bytes\n"),
				LPCTSTR(sRepositoryName),
				LPCTSTR(GetPack().GetFullFilename()),
				iBytes);
		}

		// The order of packing is important. We want to get object definitions
		// early in the pack file. We want to get the data near the end of the file.
		bool fResult = true;
		if (fResult && Flags.Test(cdromsBuildPackDatabaseObjects) && !Flags.Test(cdromsBuildUpdate))
			if (!BuildChildren(Output, Flags & cdromsBuildPackDatabaseObjects))
				fResult = false;
		if (fResult && Flags.Test(cdromsBuildPackAuxiliaryObjects))
			if (!BuildChildren(Output, Flags & cdromsBuildPackAuxiliaryObjects))
				fResult = false;
		if (fResult && Flags.Test(cdromsBuildPackAuxiliaryFiles))
			if (!BuildChildren(Output, Flags & cdromsBuildPackAuxiliaryFiles))
				fResult = false;
		if (fResult && Flags.Test(cdromsBuildPackDatabaseFiles) && !Flags.Test(cdromsBuildUpdate))
			if (!BuildChildren(Output, Flags & cdromsBuildPackDatabaseFiles))
				fResult = false;

		// Close the Pack
		GetPack().Close();

		if (!fResult)
			return false;
	}

	if (Flags.Test(cdromsBuildDeleteEnd))
	{
		if (!GetInput().Build(*this, Output, cdromsBuildDeleteEnd))
			return false;
		
		if (!BuildChildren(Output, cdromsBuildDeleteEnd))
			return false;

		SaveDelete(GetFilename(), &Output);
	}

	// Split after the temporary files have been cleaned up
	if (Flags.Test(cdromsBuildSplit) && GetSplitSize() > 0)
	{
		CStringArray asFilenamesDst;
		CIuPack::Split(GetFilename(), asFilenamesDst, GetSplitSize(), &Output);
	}

	// Build the .ID file
	if (Flags.Test(cdromsBuildID))
	{
		if (!BuildID(Output))
			return false;
	}

	
	Log(_T("Build Completed"));

	return Output.Fire();
}

bool CIuCdrom::BuildChildren(CIuOutput& Output, CIuFlags Flags)
{
	// Order is important here...
	if (GetInput().HasData())
	{
		if (!GetAlts().Build(*this, Output, Flags))
			return false;
		if (HasAddress())
			if (!GetAddress().Build(*this, Output, Flags))
				return false;
		if (HasGeo())
			if (!GetGeo().Build(*this, Output, Flags))
				return false;
		if (HasSic())
			if (!GetSic().Build(*this, Output, Flags))
				return false;
		if (!GetTokens().Build(*this, Output, Flags))
			return false;
	}
	if (HasSplash())
		if (!GetSplash().Build(*this, Output, Flags))
			return false;
	if (!GetBlobs().Build(*this, Output, Flags))
		return false;
	if (GetInput().HasData())
		if (!GetBTrees().Build(*this, Output, Flags))
			return false;
	if (!GetReleaseNotes().Build(*this, Output, Flags))
		return false;
	if (!GetExportDefs().Build(*this, Output, Flags))
		return false;
	if (!GetMeters().Build(*this, Output, Flags))
		return false;
	if (HasUserInterface())
		if (!GetUserInterface().Build(*this, Output, Flags))
			return false;
	if (HasRegistration())
		if (!GetRegistration().Build(*this, Output, Flags))
			return false;
	if (!GetReportDefs().Build(*this, Output, Flags))
		return false;
	if (GetInput().HasData() && HasDatabase())
	{
		if (!GetDatabase().Build(*this, Output, Flags))
			return false;
		if (!GetSources().Build(*this, Output, Flags))
			return false;
	}
	return Output.Fire();
}

bool CIuCdrom::BuildID(CIuOutput& Output)
{
	CIuFilename Filename = IuDataFilenameSearch(GetFilename(), extDataProductID).GetFullFilename();

	m_Product.SaveProfile(Filename, productFlagProduct);

	Output.OutputF("Saved product ID file as '%s'\n", LPCTSTR(Filename));
	return Output.Fire();
}

void CIuCdrom::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sFilename = "cdrom";
	SetName("CDROM");
	if (m_pBTrees.IsNull())
	{
		m_pBTrees.Create();
	}
	if (m_pTokens.IsNull())
	{
		m_pTokens.Create();
	}
	if (m_pAlts.IsNull())
	{
		m_pAlts.Create();
	}
	if (m_pObjectRepository.IsNull())
	{
		m_pObjectRepository.Create();
	}
	if (m_pExportDefs.IsNull())
	{
		m_pExportDefs.Create();
	}
	if (m_pMeters.IsNull())
	{
		m_pMeters.Create();
	}
	if (m_pReportDefs.IsNull())
	{
		m_pReportDefs.Create();
	}
	if (m_pReleaseNotes.IsNull())
	{
		m_pReleaseNotes.Create();
	}
	if (m_pBlobs.IsNull())
	{
		m_pBlobs.Create();
	}
	m_pEngine = 0;
	SetVersion(versionCdrom);
	m_iSplitSize = -1; // Don't split...
	if (m_pInput.IsNull())
	{
		m_pInput.Create();
	}
	if (m_pPack.IsNull())
	{
		m_pPack.Create();
	}
	if (m_pSources.IsNull())
	{
		m_pSources.Create();
	}
	SetVersion(versionCdromMax);
	//}}Initialize
}

void CIuCdrom::CreateIndex(const CIuSourceDescriptorSpec& Spec)
{
	// Add a source
	int iIndex = GetSources().Add();
	ASSERT(iIndex >= 0);
	CIuSourceDescriptor& Source = GetSources().Get(iIndex);
	Source.SetSpec(Spec);

	// If a database is present, update the meta data
	if (!HasDatabase())
		return ;

	// A database/index is really a stripped down representation of a source
	// The indexes represent the meta data describing which tables
	//		are available in a database.
	// The database is the meta data describing the entire physical CD-ROM.
	// The actual source descriptors can be rebuilt at run time. This
	//		allows us to easily add in additional functionality... even 
	//		though the meta data may be out of date.
	// However, the cost of creating source descriptors at runtime 
	//		is that we have to load each of the base provider 
	//		(btree/sic/token/geo) objects.
	// Therefore, we also pack in the source descriptor objects themselves.
	//		And rebuild them only when necessary.
	// Each index has the id (moniker) of its source and the name of the index

	// If empty (default index), then don't make an entry
	if (Spec.GetIndex().IsEmpty())
		return ;
	iIndex = GetDatabase().GetIndexes().Add();
	ASSERT(iIndex >= 0);
	CIuIndex& Index = GetDatabase().GetIndexes().Get(iIndex);
	Index.SetID(Spec.GetID());
	ASSERT(!Spec.GetIndex().IsEmpty());
	Index.SetName(Spec.GetIndex());
	Index.GetRecordDef() = Spec.GetRecordDef();
}

void CIuCdrom::CreateIndexes(CIuSourceDescriptorSpecArray& Specs)
{
	for (int i = 0; i < Specs.GetSize(); ++i)
	{
		CIuSourceDescriptorSpec& Spec = Specs.ElementAt(i);
		CreateIndex(Spec);
	}
}

void CIuCdrom::Delete(CIuOutput* pOutput)
{
	CIuFilename Filename = IuDataFilenameSearch(GetFilename(), extDataPack);
	CdromDelete(Filename, pOutput);
}

CIuObject* CIuCdrom::GetAddress_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAddress.Ptr()));
}

CIuObject* CIuCdrom::GetAlts_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAlts.Ptr()));
}

CIuObject* CIuCdrom::GetBlobs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pBlobs.Ptr()));
}

CIuObject* CIuCdrom::GetBTrees_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pBTrees.Ptr()));
}

CIuObject* CIuCdrom::GetDatabase_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pDatabase.Ptr()));
}

CIuObject* CIuCdrom::GetExportDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pExportDefs.Ptr()));
}

CIuObject* CIuCdrom::GetGeo_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pGeo.Ptr()));
}

CIuObject* CIuCdrom::GetInput_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInput.Ptr()));
}

CIuObject* CIuCdrom::GetMeters_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pMeters.Ptr()));
}

CIuObject* CIuCdrom::GetObjectRepository_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pObjectRepository.Ptr()));
}

CIuObject* CIuCdrom::GetPack_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pPack.Ptr()));
}

CIuObject* CIuCdrom::GetRegistration_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRegistration.Ptr()));
}

CIuObject* CIuCdrom::GetReleaseNotes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pReleaseNotes.Ptr()));
}

CIuObject* CIuCdrom::GetReportDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pReportDefs.Ptr()));
}

CIuObject* CIuCdrom::GetSic_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSic.Ptr()));
}

CIuObject* CIuCdrom::GetSources_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSources.Ptr()));
}

CIuObject* CIuCdrom::GetSplash_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSplash.Ptr()));
}

CIuObject* CIuCdrom::GetTokens_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pTokens.Ptr()));
}

CIuObject* CIuCdrom::GetUserInterface_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pUserInterface.Ptr()));
}

CIuVersionNumber CIuCdrom::GetVersionMax() const
{
	return versionCdromMax;
}

CIuVersionNumber CIuCdrom::GetVersionMaxStatic()
{
	return versionCdromMax;
}

CIuVersionNumber CIuCdrom::GetVersionMin() const
{
	return versionCdromMin;
}

CIuVersionNumber CIuCdrom::GetVersionMinStatic()
{
	return versionCdromMin;
}

void CIuCdrom::Log(LPCTSTR pcszTitle, LPCTSTR pcszText) const
{
	FILE* file = 0;
	IU_TRY_ERROR
	{
		// Write an event to the log file.
		CIuFilename Filename = GetFilename();
		Filename.ReplaceExt(_T(".log"));
		file = fopen(Filename, "a+t");
		if (file == 0)
			return ;

		// NOTE: Try to maintain data column formatting
		// using both a fixed number of characters and tabs
		// between columns. In this way, it can be easily viewed
		// with a text editor... or copy/pasted into Excel.
		CString sOutput;
		sOutput += "*\n";
		sOutput += "**\n";
		sOutput += "*** ";
		ASSERT(AfxIsValidString(pcszTitle));
		sOutput += pcszTitle;
		sOutput += "\n";

		sOutput += "*** ";
		sOutput += GetName();
		sOutput += "\n";

		COleDateTime dt = COleDateTime::GetCurrentTime();
		sOutput += "*** ";
		sOutput += dt.Format();
		sOutput += _T("\n");
		sOutput += "**\n";
		sOutput += "*\n";
		fputs(sOutput, file);

		if (pcszText)
		{
			ASSERT(AfxIsValidString(pcszText));
			fputs(pcszText, file);
		}

		fputs(_T("\n"), file);
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
	}
	if (file)
		fclose(file);
	file = 0;
}

bool CIuCdrom::SelectDlg(CWnd* pParent)
{
	CIuCdromSelectDlg dlg(pParent);
	dlg.SetSpec(GetName());
	if (dlg.DoModal() != IDOK)
		return false;
	int iSpec = dlg.GetSpec();
	if (iSpec < 0)
		return false;
	CIuCdromSpec Spec;
	Spec.FromIndex(iSpec);
	Spec.SetMaxRecords(dlg.GetMaxRecords());
	SetSpec(Spec);
	return true;
}

void CIuCdrom::SetEngine(CIuEngine& Engine)
{
	m_pEngine = &Engine;
}

void CIuCdrom::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCdrom::SetOwner(CIuObject* pOwner)
{
	// Virtual function called by the scripting engine to designate the owner 
	// of this object (normally an engine)
	if (pOwner)
		if (pOwner->IsKindOf(RUNTIME_CLASS(CIuEngine)))
			SetEngine(*dynamic_cast<CIuEngine*>(pOwner));
}

void CIuCdrom::SetSpec(CIuCdromSpec& Spec)
{
	SetName(Spec.GetName());
	SetID(Spec.GetID());

	ASSERT(!Spec.GetFilename().IsEmpty());
	SetFilename(Spec.GetFilename());
	SetSplitSize(Spec.GetSplitSize());

	CString sCopyright = IU_COPYRIGHT_STRING;
	CString sName = Spec.GetTitle();
	CString sData = sName;
	sData += _T("\r\n");
	sData += Spec.GetDescription();
	GetPack().SetData(sData);
	GetPack().SetName(sName);
	GetPack().SetCopyright(sCopyright);
	GetPack().SetFilename(Spec.GetFilename());

	GetObjectRepository().SetID(Spec.GetID());

	// Order is important...
	GetInput().SetSpec(Spec);

	GetAlts().SetSpec(Spec);
	if (Spec.HasGeo())
	{
		m_pGeo.Create();
		GetGeo().SetSpec(Spec.GetGeo());
	}
	else
		m_pGeo.Release();
	if (Spec.HasSic())
	{
		m_pSic.Create();
		GetSic().SetSpec(Spec.GetSic());
	}
	else
		m_pSic.Release();
	if (Spec.HasAddress())
	{
		m_pAddress.Create();
		GetAddress().SetSpec(Spec.GetAddress());
	}
	else
		m_pAddress.Release();

	GetTokens().SetSpec(Spec);
	GetBlobs().SetSpec(Spec);
	if (Spec.HasSplash())
	{
		m_pSplash.Create();
		GetSplash().SetSpec(Spec.GetSplash());
	}
	else
		m_pSplash.Release();

	GetBTrees().SetSpec(Spec);

	GetExportDefs().SetSpec(Spec);
	GetMeters().SetSpec(Spec);
	GetReportDefs().SetSpec(Spec);
	GetReleaseNotes().SetSpec(Spec);

	if (Spec.HasRegistration())
	{
		m_pRegistration.Create();
		GetRegistration().SetSpec(Spec.GetRegistration());
	}
	else
		m_pRegistration.Release();

	if (Spec.HasUserInterface())
	{
		m_pUserInterface.Create();
		GetUserInterface().SetSpec(Spec.GetUserInterface());
	}
	else
		m_pRegistration.Release();

	if (Spec.HasDatabase())
	{
		m_pDatabase.Create();
		GetDatabase().SetSpec(Spec);
	}
	else
		m_pDatabase.Release();

	// Clear current
	m_Product.Clear();

	// Set defaults
	m_Product.SetSetupFile(_T("Setup.Exe"));

	// Load any attributes from the spec
	POSITION pos = Spec.GetAttributeFirst();
	while (pos)
	{
		CString sName;
		CString sValue;
		Spec.GetAttributeNext(pos, sName, sValue);
		m_Product.SetAttribute(sName, sValue);
	}

	// Set the programmatic attributes
	if (Spec.GetMeterCount() >= 1)
	{
		CIuMeterSpec& MeterSpec = Spec.GetMeter(0);
		m_Product.SetMeter(MeterSpec.GetMoniker().GetName());
	}

	m_Product.SetName(Spec.GetTitle());
	m_Product.SetRelease(Spec.GetRelease());

	CString sCopyFiles = m_Product.GetCopyFiles();
	if (!sCopyFiles.IsEmpty())
		sCopyFiles += _T(",");
	sCopyFiles += Spec.GetFilename();
	sCopyFiles += IuDataFilenameExt(extDataPack);
	m_Product.SetCopyFiles(sCopyFiles);

#ifdef _DEBUG
//	m_Product.Dump();
#endif
}

void CIuCdrom::SetSplitSize(int iSplitSize)
{
	m_iSplitSize = iSplitSize;
}

void CIuCdrom::UpdateObjectRepository(CIuOutput& Output)
{
	// Notify everyone of the repository object
	CIuCdrom::BuildChildren(Output, cdromsBuildSetRepository);

	// Remove all current entries
	ASSERT(m_pObjectRepository.NotNull());
	GetObjectRepository().RemoveAll();

	// Make a build request for each object to 
	// simply update the object repository
	CIuCdrom::BuildChildren(Output, cdromsBuildUpdateRepository);
}
	



