#ifndef _ENGINE_EXPRESSIONFIELD_H_
#define _ENGINE_EXPRESSIONFIELD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionField, CIuExpressionElement }} 
#define CIuExpressionField_super CIuExpressionElement

class CIuExpressionField : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionField(LPCTSTR pcsz = 0);
	CIuExpressionField(const CIuExpressionField& rExpressionElement);
	virtual ~CIuExpressionField();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetBoughtLevel() const;
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual LPCTSTR Evaluate(const CIuRecord*) const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
	virtual void Resolve(CIuResolveSpec& Spec);
	void SetField(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionField& operator=(const CIuExpressionField& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The field name when it is actually resolved
	CString m_sField;
	int m_iMaxLength;
	int m_iBoughtLevel;
	int m_iFieldFlags;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONFIELD_H_
