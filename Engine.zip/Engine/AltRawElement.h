#ifndef _ENGINE_ALTRAWELEMENT_H_
#define _ENGINE_ALTRAWELEMENT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_SORTEDSTRINGARRAY_H_
#	include "Common\SortedStringArray.h"
#endif	// _COMMON_SORTEDSTRINGARRAY_H_
#ifndef 	_ENGINE_ALTINSTANCE_H_
#	include "Engine\AltInstance.h"
#endif	// _ENGINE_ALTINSTANCE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltRawElement)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltRawElement, CIuObject }}
#define CIuAltRawElement_super CIuObject

class CIuAltRawElement : public CIuAltRawElement_super
{
//{{Declare
	DECLARE_SERIAL(CIuAltRawElement)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltRawElement();
	CIuAltRawElement(CIuAltInstance& Instance);
	virtual ~CIuAltRawElement();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddValue(LPCTSTR);
	void Append(CIuAltInstance& Instance);
	CString GetKey() const;
	CIuAltRawElement* GetNext() const;
	CString GetValue(int) const;
	int GetValueCount() const;
	void GetValues(CStringArray& as) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void RemoveAllValues();
	void Serialize(CArchive& ar);
	void SetKey(LPCTSTR);
	void SetNext(CIuAltRawElement* pNext);
	void SetValues(const CStringArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuAltRawElement* m_pNext;
	CString m_sKey;
	CIuSortedStringArray m_asValues;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuAltRawElement::GetKey() const
{
	return m_sKey;
}

inline CIuAltRawElement* CIuAltRawElement::GetNext() const
{
	return m_pNext;
}

inline CString CIuAltRawElement::GetValue(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetValueCount());
	return m_asValues.GetAt(iWhich);
}

inline int CIuAltRawElement::GetValueCount() const
{
	return m_asValues.GetSize();
}

#endif // _ENGINE_ALTRAWELEMENT_H_
