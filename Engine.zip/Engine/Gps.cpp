#include "stdafx.h" 
//{{Include
#include "engine.h"
#include "Gps.h"
#include "resource.h"
#include "Error\Error.h"
#include "LatLongDistance.h"
#include "LatLongCoordinate.h"
#include "Common\MessagePump.h"
#include "Interop\Conversions.h"
#include "Nmea.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuGps, CIuGps_super)
IU_IMPLEMENT_OBJECT_PTR(CIuGps)
static const TCHAR szDefaultConfig[] = _T("port=com1;baud=4800;parity=none;bits=8");
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GPS, CIuGps, CIuGps_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGps, IDS_ENGINE_PROP_LATITUDE, GetLatitude, SetLatitude, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGps, IDS_ENGINE_PROP_LONGITUDE, GetLongitude, SetLongitude, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGps, IDS_ENGINE_PROP_STATUS, GetStatus, SetStatus, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGps, IDS_ENGINE_PROP_ALTITUDE, GetAltitude, SetAltitude, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGps, IDS_ENGINE_PROP_UTCTIME, GetUtcTime, SetUtcTime, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGps, IDS_ENGINE_PROP_SATELLITES, GetSatellites, SetSatellites, 0)

	IU_ATTRIBUTE_ACTION(CIuGps, IDS_ENGINE_ACTION_CONNECT, ActionConnect, 0)
	IU_ATTRIBUTE_ACTION(CIuGps, IDS_ENGINE_ACTION_REFRESH, ActionRefresh, 0)

	IU_ATTRIBUTE_PAGE(CIuGps, IDS_ENGINE_PPG_GPS, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGps, IDS_ENGINE_PROP_LONGITUDE, IDS_ENGINE_PPG_GPS, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGps, IDS_ENGINE_PROP_LATITUDE, IDS_ENGINE_PPG_GPS, 1, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuGps, IDS_ENGINE_ACTION_CONNECT, IDS_ENGINE_PPG_GPS, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuGps, IDS_ENGINE_ACTION_REFRESH, IDS_ENGINE_PPG_GPS, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGps, IDS_ENGINE_PROP_STATUS, IDS_ENGINE_PPG_GPS, 1, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGps, IDS_ENGINE_PROP_ALTITUDE, IDS_ENGINE_PPG_GPS, 0, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGps, IDS_ENGINE_PROP_SATELLITES, IDS_ENGINE_PPG_GPS, 0, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGps, IDS_ENGINE_PROP_UTCTIME, IDS_ENGINE_PPG_GPS, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

#pragma __TODO("Add timer to UTC time to count seconds when not receiving")

CIuGps::CIuGps()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);

	m_pEngine = 0;
	CommonConstruct();
}

CIuGps::~CIuGps()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}


/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGps::Abort() 
{
	m_fAbort = true;
}

CString CIuGps::ActionConnect(const CIuPropertyCollection& Collection, CIuOutput&)
{
	CString sConnect = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_CONNECT), 0);
	Connect(sConnect);

	CString sResult = "Successfully connected to GPS receiver.\n";
	return sResult;
}

CString CIuGps::ActionRefresh(const CIuPropertyCollection&, CIuOutput&)
{
	Refresh();
	return CString(_T("GPS position refreshed.\n"));
}

void CIuGps::Clear()
{
	CIuGps_super::Clear();
	CIuGps::CommonConstruct();
}

void CIuGps::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	static const TCHAR szNotAvailable[] = _T("Not Available");
	m_sLatitude = szNotAvailable;
	m_sLongitude = szNotAvailable;
	m_sStatus = _T("GPS receiver data not present.");
	m_iAltitude = 0;
	m_sUtcTime = "00:00:00";
	m_iSatellites = 0;
	m_sConnect = szDefaultConfig;
	m_fAbort = false;
	SetVersion(IU_VERSION);
	//}}Initialize
}

bool CIuGps::Connect(LPCTSTR pcszConnect)
{
	if (!DisConnect())
		return false;

	// We could recurse if a query is in progress
	IU_PREVENT_RECURSION(m_recurse) false;

	// Start with the defaults
	m_sConnect = szDefaultConfig;
	// Add on any special options
	m_sConnect += ';';
	m_sConnect += pcszConnect;

	IU_TRY_ERROR
	{
		// Set up and then open the com port
		CIuCommConfig config(m_sConnect);
		m_com.Open(config);
		m_com.SetTimeouts(5000, 5000);
		m_com.PurgeRx();
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
		return false;
	}
	return true;
}

bool CIuGps::DisConnect() 
{
	IU_PREVENT_RECURSION(m_recurse) false;

	m_com.Close();
	return true;
}

CIuEngine& CIuGps::GetEngine() const
{
	ASSERT(m_pEngine!=0);
	return *m_pEngine;
}

CString CIuGps::GetLatitude() const
{
	return m_sLatitude;
}

CString CIuGps::GetLongitude() const
{
	return m_sLongitude;
}

CString CIuGps::GetStatus() const
{
	return m_sStatus;
}

CString CIuGps::Proximity(LPCTSTR Latitude, LPCTSTR Longitude)
{
	CIuLatLongCoordinate Coord1(LPCTSTR(GetLatitude()), LPCTSTR(GetLongitude()));
	ASSERT(AfxIsValidString(Latitude));
	ASSERT(AfxIsValidString(Longitude));
	CIuLatLongCoordinate Coord2(Latitude, Longitude);

	if (!Coord1.IsValid() || !Coord2.IsValid() || Coord1.IsZero() || Coord2.IsZero())
		return CString(_T("Not Available"));

	CString sDirection;
	CIuLatLongDistance Distance = CIuLatLongCoordinate::GetDistance(Coord1, Coord2, &sDirection);

	CString sProximity = Distance.AsString(CIuLatLongDistance::LatLongUnitsMiles, true);
	sProximity += _T(" ");
	sProximity += sDirection;
	return sProximity;
}

bool CIuGps::Refresh()
{
	IU_PREVENT_RECURSION(m_recurse) false;

	m_fAbort = false;

	IU_TRY_ERROR
	{
		CIuNmea nmea;
		UINT uiStatus = IDS_ENGINE_GPS_NO_DATA;

		// Send some initialization strings designed to cause the correct data to be sent asap
		// Generic request for gps info
		static const TCHAR szRequest1[] = "$PMOTG,RMC,0000*1D\r\n";
		m_com.Write(szRequest1);
		// ...Delorme Tripmate
		// Claude did this... not sure why....
		static const TCHAR szRequest2[] = "$IIGPQ,ASTRAL*73\r\n";
		m_com.Write(szRequest2);
		static const TCHAR szRequest3[] = "$PRWIILOG,RMC,A,,,\r\n";
		m_com.Write(szRequest3);
		static const TCHAR szRequest4[] = "$PRWIILOG,GGA,A,,,\r\n";
		m_com.Write(szRequest4);

		int iUnknowns = 0;
		int iAstrals = 0;
		for (int iTry = 0; iTry < 3; )
		{
			// Wait about 1 seconds for a message.
			time_t timeStart = time(0);
			while (m_com.IsRxQueueEmpty() && time(0) - timeStart < 1 && !m_fAbort)
				PumpMessages();
AnotherLine:
			if (m_fAbort)
			{
				uiStatus = IDS_ENGINE_GPS_ABORTED;
				break;
			}

			CString sLine;
			m_com.Read(sLine);

			if (sLine.IsEmpty())
			{
				++iTry;
				uiStatus = iUnknowns > 0 || iAstrals > 0 ? IDS_ENGINE_GPS_WAITING: IDS_ENGINE_GPS_NO_DATA;
				continue;
			}

			if (sLine.CompareNoCase(_T("ASTRAL")) == 0)
			{
				++iAstrals;
				if (iAstrals > 100)
				{
					uiStatus = IDS_ENGINE_GPS_WAITING;
					break;
				}
				// Go and immediately try another line.
				// Don't wait or the buffer seems to fill with "ASTRAL"'s
				goto AnotherLine;
			}

			++iTry;

			TCHAR chStatus = nmea.Parse(sLine);
			// Echo sentences back to receiver.
			// The Delorme receiver likes this....
//			if (chStatus != 0 && chStatus != 'N')
//			{
//				m_com.Write(sLine);
//			}
			if (chStatus == 'A' || chStatus == '1' || chStatus == '2')
			{
				uiStatus = IDS_ENGINE_GPS_OK;
				break;
			}			
			else if (chStatus == 'V' || chStatus == '0')
			{
				uiStatus = IDS_ENGINE_GPS_NOT_VALID;
				break;
			}
			else if (chStatus == 'N')
			{
				uiStatus = IDS_ENGINE_GPS_NOT_NMEA;
				break;
			}
			else if (chStatus == 0)
			{
				uiStatus = IDS_ENGINE_GPS_NO_DATA;
				break;
			}
			else if (chStatus == 'U')
			{
				// Unknown sentence, try again
				++iUnknowns;
				continue;
			}
		}

		if (nmea.m_iatitude.IsValid() && !nmea.m_iatitude.IsZero())
			SetLatitude(nmea.m_iatitude.AsString()) ;
		if (nmea.m_iongitude.IsValid() && !nmea.m_iongitude.IsZero())
			SetLongitude(nmea.m_iongitude.AsString());
		if (!nmea.m_sUtcTime.IsEmpty())
			SetUtcTime(nmea.m_sUtcTime);
		if (nmea.m_iAltitude >= 0)
			SetAltitude(nmea.m_iAltitude);
		CString sStatus = S(uiStatus);
		if (nmea.m_iSatellites > 0)
		{
			sStatus += _T(" ");
			CString sSatellites;
			sStatus += IntAsString(sSatellites, nmea.m_iSatellites);
			sStatus += _T(" SV's.");
			SetSatellites(nmea.m_iSatellites);
		}
		SetStatus(sStatus);
	}
	IU_CATCH_ERROR(e)
	{
		IU_TRY_ERROR
		{
			// Flush in case of full buffer error
			m_com.PurgeRx();
		}
		IU_CATCH_ERROR(e2)
		{
			m_com.PurgeRx();
			e2->Delete();
		}
		CString s;
		s = S(IDS_ENGINE_GPS_ERROR);
		s += '\n';
		s += e->GetDescription();
		SetStatus(s);
		e->Delete();
		return false;
	}
	return true;
}

void CIuGps::SetAltitude(int iAltitude)
{
	m_iAltitude = iAltitude;
}

void CIuGps::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuGps::SetLatitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLatitude = pcsz;
}

void CIuGps::SetLongitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongitude = pcsz;
}

void CIuGps::SetSatellites(int iSatellites)
{
	m_iSatellites = iSatellites;
}

void CIuGps::SetStatus(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sStatus = pcsz;
}

void CIuGps::SetUtcTime(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sUtcTime = pcsz;
}
