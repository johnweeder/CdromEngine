#include "stdafx.h"
#include "engine.h"
#include "DialDlg.h"
#include "Tapi.h"
#include "Error\Error.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuDialDlg, CIuDialDlg_super)
	//{{AFX_MSG_MAP(CIuDialDlg)
	ON_BN_CLICKED(IDC_ENGINE_SAVE, OnSave)
	ON_BN_CLICKED(IDC_ENGINE_HELPDIAL, OnHelpDial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

const UINT iPorts[] = 
{
	IDS_ENGINE_PORT1, 
	IDS_ENGINE_PORT2, 
	IDS_ENGINE_PORT3, 
	IDS_ENGINE_PORT4, 
	IDS_ENGINE_PORT5, 
	0
};

const UINT iCOM[] =
{
	IDS_ENGINE_DIALER, 
	IDS_ENGINE_SOUNDCARD, 
	IDS_ENGINE_COM1, 
	IDS_ENGINE_COM2, 
	IDS_ENGINE_COM3, 
	IDS_ENGINE_COM4,
	0
};

//}}Implement

CIuDialDlg::CIuDialDlg(CIuTapi* pTapi, CWnd* pParent /*=NULL*/) : CIuDialDlg_super(CIuDialDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuDialDlg)
	m_sLocalAreaCode = _T("");
	m_sLDPrefix = _T("");
	m_sLDSufix = _T("");
	m_sLocalPrefix = _T("");
	//}}AFX_DATA_INIT
	ASSERT(pTapi);
	m_pTapi = pTapi;
}

/////////////////////////////////////////////////////////////////////////////
// CIuDialDlg message handlers

void CIuDialDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuDialDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuDialDlg)
	DDX_Control(pDX, IDC_ENGINE_HELPDIAL, m_btnHelp);
	DDX_Control(pDX, IDC_ENGINE_PORT, m_cbPort);
	DDX_Control(pDX, IDC_ENGINE_DIAL1, m_Dial1);
	DDX_Control(pDX, IDC_ENGINE_DIAL2, m_Dial2);
	DDX_Control(pDX, IDC_ENGINE_DIAL3, m_Dial3);
	DDX_Control(pDX, IDC_ENGINE_DIAL4, m_Dial4);
	DDX_Text(pDX, IDC_ENGINE_AREA, m_sLocalAreaCode);
	DDX_Text(pDX, IDC_ENGINE_PREFIX, m_sLDPrefix);
	DDX_Text(pDX, IDC_ENGINE_SUFFIX, m_sLDSufix);
	DDX_Text(pDX, IDC_ENGINE_LOCAL, m_sLocalPrefix);
	//}}AFX_DATA_MAP
}

void CIuDialDlg::OnHelpDial() 
{
	CString sHelpFile = GetTapi().GetHelpFile();
	if (sHelpFile.IsEmpty())
		return;
	DWORD dwCommand = HELP_CONTENTS;
	if (GetTapi().GetHelpContext() != 0)
		dwCommand = HELP_CONTEXT;
	::WinHelp(m_hWnd, sHelpFile, dwCommand, GetTapi().GetHelpContext());
}

BOOL CIuDialDlg::OnInitDialog() 
{
	CIuDialDlg_super::OnInitDialog();

	m_btnHelp.ShowWindow(GetTapi().GetHelpFile().IsEmpty() ? SW_HIDE: SW_SHOW);

	CString sPhone = GetTapi().GetPhone();
	if (sPhone.GetLength() != 10) 
		return false;

	CString m_sAC = sPhone.Left(3);
	CString m_sP3 = sPhone.Mid(3,3);
	CString m_sP4 = sPhone.Right(4);

	CString sFormat;
	sFormat.Format("1-%s-%s-%s", LPCTSTR(m_sAC), LPCTSTR(m_sP3), LPCTSTR(m_sP4));
	m_Dial1.SetWindowText(sFormat);
	sFormat.Format("%s-%s", LPCTSTR(m_sP3), LPCTSTR(m_sP4));
	m_Dial2.SetWindowText(sFormat);
	sFormat.Format("%s-%s-%s", LPCTSTR(m_sAC), LPCTSTR(m_sP3), LPCTSTR(m_sP4));
	m_Dial3.SetWindowText(sFormat);
	sFormat.Format("1-%s-%s", LPCTSTR(m_sP3), LPCTSTR(m_sP4));
	m_Dial4.SetWindowText(sFormat);

	int iOutPort = 0;
	for (int i = 0; iPorts[i]; ++i)
	{
		int iIndex = m_cbPort.AddString(S(iPorts[i]));
		m_cbPort.SetItemData(iIndex, iCOM[i]);
		if (S(iCOM[i]) == GetTapi().GetDialer())
			iOutPort = i;
	}

	// select correct output source
	m_cbPort.SetCurSel(iOutPort);

	// Current settings
	m_sLocalAreaCode = GetTapi().GetLocalAreaCode();
	m_sLDPrefix = GetTapi().GetLDPrefix();
	m_sLDSufix = GetTapi().GetLDSuffix();
	m_sLocalPrefix = GetTapi().GetLocalPrefix();

	// Select correct radio btn
	if (m_sAC == m_sLocalAreaCode)
		m_Dial2.SetCheck(1);
	else 
		m_Dial1.SetCheck(1);

	UpdateData(false);
	CenterWindow();
	return true;  
}

void CIuDialDlg::OnOK() 
{
	OnSave();
	CIuDialDlg_super::OnOK();
}

void CIuDialDlg::OnSave()
{
	UpdateData(true);

	// Various edit fields
	GetTapi().SetLocalAreaCode(m_sLocalAreaCode);
	GetTapi().SetLDPrefix(m_sLDPrefix);	
	GetTapi().SetLocalPrefix(m_sLocalPrefix);
	GetTapi().SetLDSuffix(m_sLDSufix);

	// Save the format
	if (m_Dial1.GetCheck() != 0)
		GetTapi().SetFormat(tapiDialLdAc);
	else if (m_Dial2.GetCheck() != 0)
		GetTapi().SetFormat(tapiDialLocal);
	else if (m_Dial3.GetCheck() != 0)
		GetTapi().SetFormat(tapiDialAc);
	else
		GetTapi().SetFormat(tapiDialLd);

	// Save the port
	int iCur = m_cbPort.GetCurSel();
	int nId = (int)m_cbPort.GetItemData(iCur);
	GetTapi().SetDialer(S(nId));

	// Write it
	GetTapi().Flush();
}
