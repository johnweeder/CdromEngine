#ifndef _ENGINE_CASECONVERSION_H_
#define _ENGINE_CASECONVERSION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Case conversion
enum CIuCaseConversionMode
{
	caseNoConvert = 0,

	caseMixed,
	caseLower,
	caseUpper,
};

IU_API_EXPORT CString CaseConvert(LPCTSTR pcsz, CIuCaseConversionMode mode = caseMixed, int iFlags = 0);
IU_API_EXPORT void CaseConvertInPlace(LPTSTR pszBuffer, int nBuffer, CIuCaseConversionMode mode = caseMixed, int iFlags = 0);
IU_API_EXPORT void CaseConvertInPlace(CString& rs, CIuCaseConversionMode mode = caseMixed, int iFlags = 0);

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CASECONVERSION_H_
