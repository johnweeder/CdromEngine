#include "StdAfx.h"
//{{Include
#include "OamBroker.h"
#include "..\Data\XmlDocument.h"
#include "Error\Error.h"
#include "Oam\OamConst.h"
#include "SourceProvider.h"
#include "Source.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuOamBroker, CIuOamBroker_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuOamBroker)
//}}Implement

CIuOamBroker::CIuOamBroker() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuOamBroker::~CIuOamBroker()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuOamBroker::Connect(LPCTSTR /* pcszConnect */)
{
#pragma __TODO("CIuOamBroker::Connect")
	return true;
}

void CIuOamBroker::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fRecurse = false;
	//}}Initialize
}

void CIuOamBroker::DisConnect()
{
//	CMap<CIuID, const CIuID&, CIuEnginePtr, CIuEnginePtr> m_Workspaces;
//	bool m_fRecurse;
//	CIuEnginePtr
#pragma __TODO("Clean up here....")	
#pragma __TODO("CIuOamBroker::DisConnect()")	
}

bool CIuOamBroker::Transact(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	if (m_fRecurse)
	{
		TRACE("WARNING: Recursive call to CIuOamBroker::Transact()\n");
		ASSERT(false);		
		return false;
	}
	m_fRecurse = true;
	bool fResult = false;
	IU_TRY_ERROR
	{
		// Create the response document
		pResponse.Create();

		if (pRequest.IsNull())
		{
			fResult = true;
			XmlError(pResponse, OamErrorInvalidRequest);
		}
		else
		{
			if (CIuXmlDocument::Is(pRequest, szOamConnect))
				fResult = XmlConnect(pRequest, pResponse);
			else if (CIuXmlDocument::Is(pRequest, szOamDisconnect))
				fResult = XmlDisconnect(pRequest, pResponse);
			else if (CIuXmlDocument::Is(pRequest, szOamGetQueryNames))
				fResult = XmlGetQueryNames(pRequest, pResponse);
			else if (CIuXmlDocument::Is(pRequest, szOamGetQueryDef))
				fResult = XmlGetQueryDef(pRequest, pResponse);
			else
			{
				fResult = true;
				TRACE("OAM: Unrecognized request: %s\n", LPCTSTR(pRequest->GetName()));
				CString sDescription = _T("Unrecognized request:\n") + CString(pRequest->GetName());
				XmlError(pResponse, OamErrorUnrecognizedRequest, sDescription);
			}
		}
		if (!fResult)
		{
			fResult = true;
			XmlError(pResponse, OamErrorServerFailure);
		}
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
		fResult = false;
	}

	// Add a timestamp to the response
	pResponse->TimeStamp();

	// Release the current engine pointer
	m_pCurrent.Release();

	// Exit
	TRACE("OAM: %s\n", fResult ? _T("Success"): _T("Failure"));
	m_fRecurse = false;
	return fResult;
}

bool CIuOamBroker::XmlConnect(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	CString sUser = pRequest->GetChildValue(szOamUser);
	CString sPassword = pRequest->GetChildValue(szOamPassword);
	
	CIuEnginePtr pEngine;
	pEngine.Create();
	if (!pEngine->Connect())
		return XmlError(pResponse, 2000, _T("Database initialization failed."));

	CIuID ID = CIuID::Create();
	CString sWorkspaceID = ID.AsString();

	m_Workspaces.SetAt(sWorkspaceID, pEngine);

	pResponse->SetName(szOamConnected);
	pResponse->Add(szOamWorkspaceID, sWorkspaceID);

	return true;
}

bool CIuOamBroker::XmlDisconnect(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	if (!XmlWorkspace(pRequest, pResponse))
		return true;

	m_Workspaces.RemoveKey(m_sWorkspaceID);
	m_pCurrent.Release();

	return XmlSuccess(pResponse);
}

bool CIuOamBroker::XmlError(CIuXmlDocumentPtr& pResponse, int iErrorCode, LPCTSTR pcszDescription)
{
	if (pcszDescription == 0)
	{
		switch (iErrorCode)
		{
			case OamErrorInvalidRequest:
				pcszDescription = _T("Invalid request.");
				break;
			case OamErrorUnknown:
				pcszDescription = _T("Unknown error.");
				break;
			case OamErrorUnrecognizedRequest:
				pcszDescription = _T("Unrecognized request.");
				break;
			case OamErrorNotSupported:
				pcszDescription = _T("Unsupported request.");
				break;
			case OamErrorServerFailure:
				pcszDescription = _T("Server failure.");
				break;
			default:
				pcszDescription = _T("Unspecified error.");
				break;
		}
	}

	pResponse->SetName(szOamError);
	CString sErrorCode;
	sErrorCode.Format(_T("%d"), sErrorCode);
	pResponse->Add(szOamErrorCode, sErrorCode);
	pResponse->Add(szOamDescription, pcszDescription);
	return true;
}

bool CIuOamBroker::XmlGetQueryDef(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	if (!XmlWorkspace(pRequest, pResponse))
		return true;

	CString sQuery = pRequest->GetChildValue(szOamQuery);

	CIuSourceProvider& SourceProvider = m_pCurrent->GetSourceProvider();
	CIuSourceDescriptors& SourceDescriptors = SourceProvider.GetDescriptors();
	int iIndex = SourceDescriptors.Find(sQuery);
	if (iIndex < 0)
		return XmlError(pResponse, 2000, _T("Query not found."));

	CIuSourceDescriptor& SourceDescriptor = SourceDescriptors.Get(iIndex);

	pResponse->SetName(szOamQueryDef);
	pResponse->Add(szOamName, SourceDescriptor.GetName());
	CStringArray asFields;
	SourceDescriptor.GetFields(asFields);
	if (asFields.GetSize() != 0)
	{
		CIuXmlNode& Fields = pResponse->Add(szOamFields);
		for (int iField = 0; iField < asFields.GetSize(); ++iField)
		{
			CIuXmlNode& Field = Fields.Add(szOamField);

			CString sField = asFields[iField];

			Field.Add(szOamName, sField);
		}
	}

#pragma __TODO("Description")
#pragma __TODO("Criterion")

	return true;
}

bool CIuOamBroker::XmlGetQueryNames(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	if (!XmlWorkspace(pRequest, pResponse))
		return true;

	pResponse->SetName(szOamQueryNames);

	CIuSourceProvider& SourceProvider = m_pCurrent->GetSourceProvider();
	SourceProvider.Refresh();

	CIuSourceDescriptors& SourceDescriptors = SourceProvider.GetDescriptors();

	for (int i = 0; i < SourceDescriptors.GetCount(); ++i)
	{
		CIuSourceDescriptor& SourceDescriptor = SourceDescriptors.Get(i);

		pResponse->Add(szOamName, SourceDescriptor.GetName());
	}

	return true;
}

bool CIuOamBroker::XmlSuccess(CIuXmlDocumentPtr& pResponse)
{
	pResponse->SetName(szOamSuccess);
	if (!m_sWorkspaceID.IsEmpty())
		pResponse->AddAttribute(szOamWorkspaceID, m_sWorkspaceID);

	return true;
}

bool CIuOamBroker::XmlWorkspace(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse)
{
	// Retrieve the workspace id from the current request and set up any member variables.
	// Return an appropriate response if invalid workspace.
	m_sWorkspaceID = pRequest->GetChildValue(szOamWorkspaceID);
	if (!m_Workspaces.Lookup(m_sWorkspaceID, m_pCurrent))
	{
		XmlError(pResponse, 2000, _T("Workspace ID not recognized."));
		return false;
	}

	ASSERT(m_pCurrent.NotNull());
	return true;
}
