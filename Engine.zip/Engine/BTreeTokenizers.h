#ifndef _ENGINE_BTREETOKENIZERS_H_
#define _ENGINE_BTREETOKENIZERS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_BTREETOKENIZER_H_
#	include "Engine\BTreeTokenizer.h"
#endif	// _ENGINE_BTREETOKENIZER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeTokenizers)
class CIuBTreeCodec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeTokenizers, CIuCollection }}
#define CIuBTreeTokenizers_super CIuCollection

class CIuBTreeTokenizers : public CIuBTreeTokenizers_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeTokenizers)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeTokenizers();
	virtual ~CIuBTreeTokenizers();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuBTreeTokenizer& Get(const CIuMoniker& moniker) const;
	CIuBTreeTokenizer& Get(LPCTSTR s) const;
	CIuBTreeTokenizer& Get(int iIndex) const;
	CIuBTreeTokenizer& Get(CIuID id) const;
	CIuBTreeCodec& GetCodec() const;
	bool HasCodec() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Close(bool fForce = false);
	void MakeRecordDef(CIuRecordDef& RecordDef);
	void Open();
	void Resolve(CIuResolveSpec& Spec);
	void SetCodec(CIuBTreeCodec* pCodec);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuBTreeSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void CreateBTreeTokenizer(CIuBTreeTokenizerSpec& BTreeTokenizerSpec);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBTreeCodec* m_pCodec;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuBTreeTokenizer& CIuBTreeTokenizers::Get(const CIuMoniker& moniker) const
{
	ASSERT(dynamic_cast<CIuBTreeTokenizer*>(&CIuBTreeTokenizers_super::Get(moniker)));
	return *(CIuBTreeTokenizer*)(&CIuBTreeTokenizers_super::Get(moniker));
}

inline CIuBTreeTokenizer& CIuBTreeTokenizers::Get(LPCTSTR s) const
{
	ASSERT(dynamic_cast<CIuBTreeTokenizer*>(&CIuBTreeTokenizers_super::Get(s)));
	return *(CIuBTreeTokenizer*)(&CIuBTreeTokenizers_super::Get(s));
}

inline CIuBTreeTokenizer& CIuBTreeTokenizers::Get(int iIndex) const
{
	ASSERT(dynamic_cast<CIuBTreeTokenizer*>(&CIuBTreeTokenizers_super::Get(iIndex)));
	return *(CIuBTreeTokenizer*)(&CIuBTreeTokenizers_super::Get(iIndex));
}

inline CIuBTreeTokenizer& CIuBTreeTokenizers::Get(CIuID id) const
{
	ASSERT(dynamic_cast<CIuBTreeTokenizer*>(&CIuBTreeTokenizers_super::Get(id)));
	return *(CIuBTreeTokenizer*)(&CIuBTreeTokenizers_super::Get(id));
}

inline CIuBTreeCodec& CIuBTreeTokenizers::GetCodec() const
{
	ASSERT(m_pCodec!=0);
	return *m_pCodec;
}

inline bool CIuBTreeTokenizers::HasCodec() const
{
	return m_pCodec!=0;
}

#endif // _ENGINE_BTREETOKENIZERS_H_
