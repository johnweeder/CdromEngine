#ifndef _ENGINE_INDEXES_H_
#define _ENGINE_INDEXES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INDEX_H_
#	include "Engine\Index.h"
#endif	// _ENGINE_INDEX_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuIndexes)
class CIuDatabase;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuIndexes, CIuIndexes_super }}

#define CIuIndexes_super CIuCollection

class IU_CLASS_EXPORT CIuIndexes : public CIuIndexes_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuIndexes)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuIndexes();           
	virtual ~CIuIndexes();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuIndex& Get(LPCTSTR s) const;
	CIuIndex& Get(int iIndex) const;
	CIuIndex& Get(CIuID id) const;
	CIuDatabase& GetDatabase() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void SetDatabase(CIuDatabase* pDatabase);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides 

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuDatabase* m_pDatabase;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuIndex& CIuIndexes::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuIndex*>(&CIuCollection::Get(s));
}

inline CIuIndex& CIuIndexes::Get(int iIndex) const
{
	return *dynamic_cast<CIuIndex*>(&CIuCollection::Get(iIndex));
}

inline CIuIndex& CIuIndexes::Get(CIuID id) const
{
	return *dynamic_cast<CIuIndex*>(&CIuCollection::Get(id));
}

#endif 
