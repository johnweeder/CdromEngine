#include "StdAfx.h"
//{{Include
#include "Counts.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCounts, CIuCounts_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCounts)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_COUNTS, CIuCounts, CIuCounts_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuCounts, IDS_ENGINE_PPG_COUNTS, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCounts, IDS_ENGINE_PROP_TOTAL, GetTotal, SetTotal, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCounts, IDS_ENGINE_PROP_TOTAL, IDS_ENGINE_PPG_COUNTS, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCounts, IDS_ENGINE_PROP_MATCHED, GetMatched, SetMatched, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCounts, IDS_ENGINE_PROP_MATCHED, IDS_ENGINE_PPG_COUNTS, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCounts, IDS_ENGINE_PROP_REMAINING, GetRemaining, SetRemaining, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCounts, IDS_ENGINE_PROP_REMAINING, IDS_ENGINE_PPG_COUNTS, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCounts, IDS_ENGINE_PROP_EXPRESSION, GetExpression, SetExpression, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCounts, IDS_ENGINE_PROP_EXPRESSION, IDS_ENGINE_PPG_COUNTS, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCounts::CIuCounts() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCounts::~CIuCounts()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCounts::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iTotal = 0;
	m_iMatched = 0;
	m_iRemaining = 0;
	m_sExpression = "";
	//}}Initialize
}

void CIuCounts::Empty()
{
}

void CIuCounts::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
}

void CIuCounts::SetMatched(int iMatched)
{
	m_iMatched = iMatched;
}

void CIuCounts::SetRemaining(int iRemaining)
{
	m_iRemaining = iRemaining;
}

void CIuCounts::SetTotal(int iTotal)
{
	m_iTotal = iTotal;
}
