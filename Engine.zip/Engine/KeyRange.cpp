#include "StdAfx.h"
//{{Include
#include "KeyRange.h"
#include "Key.h"
#include "KeyDef.h"
#include "resource.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuKeyRange, CIuKeyRange_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuKeyRange)
//}}Implement

CIuKeyRange::CIuKeyRange(LPCTSTR pcsz) 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	if (pcsz)
		Set(pcsz);
}

CIuKeyRange::CIuKeyRange(const CIuKeyRange& rKeyRange)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rKeyRange;
}

CIuKeyRange::~CIuKeyRange()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuKeyRange::AddKey(LPCTSTR pcszLo, LPCTSTR pcszHi)
{
	if (pcszLo == 0 && pcszHi == 0)
	{
		m_asLo.Add("");
		m_aiTypeLo.Add(keyLoVal);
		m_asHi.Add("");
		m_aiTypeHi.Add(keyHiVal);
	}
	else if (pcszHi == 0)
	{
		m_asLo.Add(pcszLo);
		m_aiTypeLo.Add(keyValue);
		m_asHi.Add("");
		m_aiTypeHi.Add(keyInvalid);
	}
	else
	{
		m_asLo.Add(pcszLo);
		m_aiTypeLo.Add(keyValue);
		m_asHi.Add(pcszHi);
		m_aiTypeHi.Add(keyValue);
	}
}

void CIuKeyRange::Clear()
{
	CIuKeyRange_super::Clear();
	m_asLo.RemoveAll();
	m_aiTypeLo.RemoveAll();
	m_asHi.RemoveAll();
	m_aiTypeHi.RemoveAll();
}

void CIuKeyRange::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

void CIuKeyRange::Copy(const CIuObject& object)
{
	CIuKeyRange_super::Copy(object);

	const CIuKeyRange* pKeyRange = dynamic_cast<const CIuKeyRange*>(&object);
	if (pKeyRange == 0 || pKeyRange == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuKeyRange)));
	
	m_asLo.Copy(pKeyRange->m_asLo);
	m_aiTypeLo.Copy(pKeyRange->m_aiTypeLo);
	m_asHi.Copy(pKeyRange->m_asHi);
	m_aiTypeHi.Copy(pKeyRange->m_aiTypeHi);
}

void CIuKeyRange::CopyKey(int iWhich, const CIuKeyRange& Range)
{
	ASSERT(iWhich >= 0 && iWhich < Range.GetCount());
	if (iWhich < 0 || iWhich >= Range.GetCount())
		return ;

	m_asLo.Add(Range.m_asLo[iWhich]);
	m_aiTypeLo.Add(Range.m_aiTypeLo[iWhich]);
	m_asHi.Add(Range.m_asHi[iWhich]);
	m_aiTypeHi.Add(Range.m_aiTypeHi[iWhich]);
}

CString CIuKeyRange::Get() const
{
	CString sKeys;
	int iCount = GetCount();
	for (int iRange = 0; iRange < iCount; ++iRange)
	{
		if (iRange != 0)
			sKeys += _T(",");
		if (m_aiTypeLo[iRange] == keyValue)
		{
			sKeys += _T("\'");
			sKeys += m_asLo[iRange];
			sKeys += _T("\'");
		}
		if (m_aiTypeHi[iRange] == keyValue)
		{
			sKeys += _T("-\'");
			sKeys += m_asHi[iRange];
			sKeys += _T("\'");
		}
	}
	return sKeys;
}

void CIuKeyRange::Get(int iWhich, CIuKey& KeyLo, CIuKey& KeyHi, const CIuKeyDef& KeyDef) const
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	if (m_aiTypeLo[iWhich] == keyLoVal)
		KeyLo.SetLoVal();
	else
		KeyLo.Set(m_asLo[iWhich], KeyDef);
	if (m_aiTypeHi[iWhich] == keyHiVal)
		KeyHi.SetHiVal();
	else if (m_aiTypeHi[iWhich] == keyInvalid)
		KeyHi.Clear();
	else
		KeyHi.Set(m_asHi[iWhich], KeyDef);
}

int CIuKeyRange::GetCount() const
{
	ASSERT(m_asLo.GetSize() == m_asHi.GetSize());
	ASSERT(m_asLo.GetSize() == m_aiTypeLo.GetSize());
	ASSERT(m_asHi.GetSize() == m_aiTypeHi.GetSize());
	return m_asLo.GetSize();
}

bool CIuKeyRange::IsSimpleKey(int iWhich, CString* pValue) const
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	if (iWhich < 0 || iWhich >= GetCount())
		return false;
	if (m_aiTypeLo[iWhich] != keyValue)
		return false;
	if (m_aiTypeHi[iWhich] != keyInvalid)
		return false;
	if (pValue)
		*pValue = m_asLo[iWhich];
	return true;
}

CIuKeyRange& CIuKeyRange::operator=(const CIuKeyRange& rKeyRange)
{
	Copy(rKeyRange);
	return *this;
}

void CIuKeyRange::RemoveKey(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	if (iWhich < 0 || iWhich >= GetCount())
		return ;

	m_asLo.RemoveAt(iWhich);
	m_aiTypeLo.RemoveAt(iWhich);
	m_asHi.RemoveAt(iWhich);
	m_aiTypeHi.RemoveAt(iWhich);
}

void CIuKeyRange::Set(LPCTSTR pcsz)
{
	Clear();

	// NOTE: A blank range becomes a low range of "loval" and no hi range.
	// A null pointer causes there to be zero ranges.

	while (pcsz != 0 && (*pcsz != 0 || GetCount() == 0))
	{
		ASSERT(pcsz);

		// Parse out the low key
		CString sKeyLo;
		int iLoType = keyInvalid;
		CString sKeyHi;
		int iHiType = keyInvalid;

		while (*pcsz)
		{
			if (IsQuote(*pcsz))
			{
				CString sQuoted;
				pcsz = ExtractQuote(pcsz, sQuoted);
				CString sUnQuoted = UnQuote(sQuoted);
				sKeyLo += sUnQuoted;
			}
			else if (pcsz[0] == '\\' && pcsz[1] != '\0')
			{
				if (pcsz[1] == 't' || pcsz[1] == 'T')
					sKeyLo += '\t';
				else
					sKeyLo += pcsz[1];
				pcsz += 2;
			}
			else if (pcsz[0] == '-' || pcsz[0] == '~')
			{
				break;
			}
			else if (pcsz[0] == ',' || pcsz[0] == ';')
			{
				++pcsz;
				break;
			}
			else
			{
				sKeyLo += *pcsz;
				++pcsz;
			}
		}
		if (sKeyLo.IsEmpty())
		{
			// If nothing is specified, default to loval-hival
			iLoType = keyLoVal;
			iHiType = keyHiVal;
		}
		else
			iLoType = keyValue;
		if (pcsz[0] == '-' || pcsz[0] == '~')
		{
			++pcsz;
			while (*pcsz)
			{
				if (IsQuote(*pcsz))
				{
					CString sQuoted;
					pcsz = ExtractQuote(pcsz, sQuoted);
					CString sUnQuoted = UnQuote(sQuoted);
					sKeyHi += sUnQuoted;
				}
				else if (pcsz[0] == '\\' && pcsz[1] != '\0')
				{
					sKeyHi += pcsz[1];
					pcsz += 2;
				}
				else if (pcsz[0] == '-' || pcsz[0] == '~' || pcsz[0] == ',' || pcsz[0] == ';')
				{
					++pcsz;
					break;
				}
				else
				{
					sKeyHi += *pcsz;
					++pcsz;
				}
			}
			iHiType = sKeyHi.IsEmpty() ? keyHiVal: keyValue;
		}
		m_asLo.Add(sKeyLo);
		m_aiTypeLo.Add(iLoType);
		m_asHi.Add(sKeyHi);
		m_aiTypeHi.Add(iHiType);
	}

	if (m_asLo.GetSize() == 0)
	{
		// Create fake range to cover entire database
		m_asLo.Add(_T(""));
		m_aiTypeLo.Add(keyLoVal);
		m_asHi.Add(_T(""));
		m_aiTypeHi.Add(keyHiVal);
	}
}

void CIuKeyRange::SetKey(int iWhich, LPCTSTR pcszLo, LPCTSTR pcszHi)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	if (iWhich < 0 || iWhich >= GetCount())
		return ;

	if (pcszLo == 0 && pcszHi == 0)
	{
		m_asLo.SetAt(iWhich, "");
		m_aiTypeLo.SetAt(iWhich, keyLoVal);
		m_asHi.SetAt(iWhich, "");
		m_aiTypeHi.SetAt(iWhich, keyHiVal);
	}
	else if (pcszHi == 0)
	{
		m_asLo.SetAt(iWhich, pcszLo);
		m_aiTypeLo.SetAt(iWhich, keyValue);
		m_asHi.SetAt(iWhich, "");
		m_aiTypeHi.SetAt(iWhich, keyInvalid);
	}
	else
	{
		m_asLo.SetAt(iWhich, pcszLo);
		m_aiTypeLo.SetAt(iWhich, keyValue);
		m_asHi.SetAt(iWhich, pcszHi);
		m_aiTypeHi.SetAt(iWhich, keyValue);
	}
}

void CIuKeyRange::Sort(const CIuKeyDef& KeyDef) 
{
	// Sort the keys so that records are pulled in a roughly ascending order.
	// Note that we don't deal with ranges or overlaps or overlaps of ranges.
	if (GetCount() <= 1)
		return ;

	// Do a simple scanning sort based on the lo key. 
	CIuKeyRange Range = *this;

	Clear();

	CIuKey KeyLo1, KeyLo2;
	CIuKey KeyHi;
	while (Range.GetCount() > 0)
	{
		int iSelected = 0;
		Range.Get(iSelected, KeyLo1, KeyHi, KeyDef);

		for (int i = 1; i < Range.GetCount(); ++i)
		{
			Range.Get(i, KeyLo2, KeyHi, KeyDef);
			if (KeyLo2.Compare(KeyLo1) < 0)
			{
				KeyLo1 = KeyLo2;
				iSelected = i;
			}
		}
		CopyKey(iSelected, Range);
		Range.RemoveKey(iSelected);
	}
}
