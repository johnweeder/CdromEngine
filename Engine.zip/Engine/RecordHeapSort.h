#ifndef _ENGINE_RECORDHEAPSORT_H_
#define _ENGINE_RECORDHEAPSORT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_HEAPSORT_H_
#	include "Common\HeapSort.h"
#endif	// _COMMON_HEAPSORT_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

#define CIuRecordHeapSort_super CIuHeapSort
class CIuRecordHeapSort : public CIuRecordHeapSort_super
{
	// NOTE: This heap sort contains an array of 4 byte offsets into
	// a record heap. The record heap contains all of the record (which are
	//	variable length).
public:
	CIuRecordHeapSort();
	~CIuRecordHeapSort();

	bool Insert(const CIuRecord& Record);
	CIuRecord* Peek();
	CIuRecordPtr Remove();
	void SetSize(int iMaxElements);
	void SetSortFlags(int iFlags);
	void Store(CIuRecord& Record);

protected:
	int OnCompare(const BYTE* pb1, const BYTE* pb2) const;
	BYTE* OnConstruct();
	void OnCopy(BYTE* pbDst, const BYTE* pbSrc);
	void OnDestruct(BYTE* pArray);
	void OnExchange(BYTE* pb1, BYTE* pb2);

private:
	int m_iSortFlags;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_RECORDHEAPSORT_H_
