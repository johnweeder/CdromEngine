#ifndef _ENGINE_BTREECODEC_H_
#define _ENGINE_BTREECODEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
#ifndef 	_ENGINE_KEYDEF_H_
#	include "Engine\KeyDef.h"
#endif	// _ENGINE_KEYDEF_H_
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
#ifndef 	_COMMON_NYBBLEINT_H_
#	include "Common\NybbleInt.h"
#endif	// _COMMON_NYBBLEINT_H_
#ifndef 	_COMMON_NYBBLESTRING_H_
#	include "Common\NybbleString.h"
#endif	// _COMMON_NYBBLESTRING_H_
#ifndef 	_ENGINE_GEOMAP_H_
#	include "Engine\GeoMap.h"
#endif	// _ENGINE_GEOMAP_H_
#ifndef 	_ENGINE_GEO_H_
#	include "Engine\Geo.h"
#endif	// _ENGINE_GEO_H_
#ifndef 	_ENGINE_RECORDFILE_H_
#	include "Engine\RecordFile.h"
#endif	// _ENGINE_RECORDFILE_H_
#ifndef 	_COMMON_BITBUFFER_H_
#	include "Common\BitBuffer.h"
#endif	// _COMMON_BITBUFFER_H_
#ifndef 	_ENGINE_BTREETOKENIZERS_H_
#	include "Engine\BTreeTokenizers.h"
#endif	// _ENGINE_BTREETOKENIZERS_H_
#ifndef 	_COMMON_STRINGBUFFER_H_
#	include "Common\StringBuffer.h"
#endif	// _COMMON_STRINGBUFFER_H_
#ifndef 	_ENGINE_ALT_H_
#	include "Engine\Alt.h"
#endif	// _ENGINE_ALT_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
#ifndef 	_ENGINE_SIC_H_
#	include "Engine\Sic.h"
#endif	// _ENGINE_SIC_H_
#ifndef 	_ENGINE_ADDRESS_H_
#	include "Engine\Address.h"
#endif	// _ENGINE_ADDRESS_H_
#ifndef 	_ENGINE_ADDRESSCODEC_H_
#	include "Engine\AddressCodec.h"
#endif	// _ENGINE_ADDRESSCODEC_H_
#ifndef 	_ENGINE_FIELDNTH_H_
#	include "Engine\FieldNth.h"
#endif	// _ENGINE_FIELDNTH_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeCodec)
class CIuBTree;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

// Token appears only if specified by a bit flag
const int tokenOptional		= 0x00000001;
// Token value 0 implies that token value is stored inline
const int tokenExceptional	= 0x00000002;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeCodec, CIuObject }}
#define CIuBTreeCodec_super CIuObject

class CIuBTreeCodec : public CIuBTreeCodec_super
{
// Notes on compressed records:
//		All record data is aligned on nybble boundaries.
//		Records are grouped in fixed size blocks.
//		With in the block, records are delta compressed.
//		Compressed strings are represented using the "nybble string" codec.
//		Compressed (variable length) integers are represented using the nybble int codec.
//		Record pointers (indexes) are maintained in a separate bit packed file.
//		Packed bits are padded to the nearest 4 bit (nybble) boundary
//	
//		A record is layed out using a nybble delta buffer. 
//		Each record will either be an alternate record or a "full" record.
//		An alternate record simply consists of nybble encoded strings representing the
//		alternate key and value.
//		Each full record starts with one or more null terminated strings representing the
//		key. Following this are the fixed bits, then the variable bits. The bits are
//		padded to a nybble boundary. Finally the variable length nybbles are appended
//		in REVERSE order. Think of this as the variables bits and the variable nybbles
//		"growing" towards each other like two stacks.
	
//{{Declare
	DECLARE_SERIAL(CIuBTreeCodec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeCodec();
	virtual ~CIuBTreeCodec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddressCodec& GetAddressCodec() const;
	CIuMoniker GetAddressMoniker() const;
	CString GetAdSizeCode() const;
	CIuMoniker GetAltMoniker() const;
	CString GetBusResFlag() const;
	CString GetEmployeeSizeCode() const;
	CString GetFirstYear() const;
	CString GetFranchiseCode() const;
	CString GetGender() const;
	int GetGeoBits() const;
	CIuGeoMap& GetGeoMap() const;
	CIuBTree& GetBTree() const;
	int GetBitsPerPointer(int iAdditional) const;
	int GetEstimatedRecordCount() const;
	int GetFixedBits() const;
	CIuGeoPtr GetGeo();
	CIuMoniker GetGeoMoniker() const;
	const CIuKey& GetKey() const;
	CIuKeyDef& GetKeyDef() const;
	int GetKeyFields() const;
	void GetKeyFlags(CIntArray& al) const;
	CIuFieldMap& GetKeyMap() const;
	const CIuKey& GetKeyNext() const;
	int GetLatLongPrecision() const;
	int GetMinimumRecordSize() const;
	void GetMiscellaneousFlags(CIntArray& al) const;
	CString GetNoSolicit() const;
	CIuObjectRepository& GetObjectRepository() const;
	void GetOptionalFlags(CIntArray& al) const;
	int GetPhoneCount() const;
	CDWordArray& GetPointers() const;
	const CIuNybbleBuffer& GetRecord() const;
	CIuFieldMap& GetMiscellaneousMap() const;
	CString GetSalesVolumeCode() const;
	int GetSicBits() const;
	CString GetSicCode() const;
	int GetSicCount() const;
	CIuMoniker GetSicMoniker() const;
	void GetTokenBits(CIntArray& al) const;
	int GetTokenBitsCount() const;
	void GetTokenFlags(CIntArray& al) const;
	CIuVersionNumber GetVersion() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasGeo() const;
	CIuFieldMap& GetPhoneMap() const;
	CIuBTreeTokenizers& GetTokenizers() const;
	CIuFieldMap& GetOptionalMap() const;
	CIuRecordFile& GetInput() const;
	bool HasAddress() const;
	bool HasAdSizeCode() const;
	bool HasBusResFlag() const;
	bool HasEmployeeSizeCode() const;
	bool HasFirstYear() const;
	bool HasFranchiseCode() const;
	bool HasKeyOnly() const;
	bool HasObjectRepository() const;
	bool HasSalesVolumeCode() const;
	bool HasSicCode() const;
	bool IsAlt() const;
	bool IsAltCity() const;
	bool IsAltPhone() const;
	bool IsBusOnly() const;
	bool IsResOnly() const;
	bool NoCityStateCorrection() const;
	bool NoCountyCorrection() const;
	bool NoLatLongCorrection() const;
	bool NoMsaCorrection() const;
	bool NoSolicitMail() const;
	bool NoSolicitPhone() const;
	bool NoZipAddOn() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Close();
	bool Compress(CIuOutput& Output);
	void Create(CIuOutput& Output);
	void DeCompress(CIuNybbleBuffer& buffer, CIuRecordSpec& Spec, bool fKeyOnly);
	CIuRecordDefPtr MakeRecordDef();
	void Open(bool fDebug);
	void SetAddressMoniker(const CIuMoniker&);
	void SetAdSizeCode(LPCTSTR);
	void SetAltCity(bool);
	void SetAltMoniker(const CIuMoniker&);
	void SetAltPhone(bool);
	void SetBTree(CIuBTree* pBTree);
	void SetBusOnly(bool);
	void SetBusResFlag(LPCTSTR);
	void SetEmployeeSizeCode(LPCTSTR);
	void SetFirstYear(LPCTSTR);
	void SetFixedBits(int);
	void SetFranchiseCode(LPCTSTR);
	void SetGender(LPCTSTR);
	void SetGeoBits(int);
	void SetGeoMoniker(const CIuMoniker&);
	void SetHasAddress(bool);
	void SetHasGeo(bool);
	void SetKeyFlags(const CIntArray&);
	void SetKeyOnly(bool = true);
	void SetLatLongPrecision(int);
	void SetMinimumRecordSize(int);
	void SetMiscellaneousFlags(const CIntArray&);
	void SetNoCityStateCorrection(bool);
	void SetNoCountyCorrection(bool);
	void SetNoLatLongCorrection(bool);
	void SetNoMsaCorrection(bool);
	void SetNoSolicit(LPCTSTR);
	void SetNoSolicitMail(bool);
	void SetNoSolicitPhone(bool);
	void SetNoZipAddOn(bool);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetOptionalFlags(const CIntArray&);
	void SetPhoneCount(int);
	void SetResOnly(bool);
	void SetSalesVolumeCode(LPCTSTR);
	void SetSicBits(int);
	void SetSicCode(LPCTSTR);
	void SetSicCount(int);
	void SetSicMoniker(const CIuMoniker&);
	void SetSpec(CIuBTreeSpec& Spec);
	void SetTokenBits(const CIntArray&);
	void SetTokenFlags(const CIntArray&);
	void SetVersion(CIuVersionNumber);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnEditBegin();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	void CommonConstruct();
	CIuObject* GetAddressCodec_() const;
	CIuObject* GetGeoMap_() const;
	CIuObject* GetInput_() const;
	CIuObject* GetKeyDef_() const;
	CIuObject* GetKeyMap_() const;
	CIuObject* GetMiscellaneousMap_() const;
	CIuObject* GetOptionalMap_() const;
	CIuObject* GetPhoneMap_() const;
	CIuObject* GetTokenizers_() const;
private:
	void CompressAddress();
	bool CompressAlt(bool fRemainder);
	void CompressBus();
	bool CompressBusResFlag();
	void CompressGeo();
	void CompressKey();
	void CompressMiscellaneous();
	void CompressNoSolicit();
	void CompressOptional();
	void CompressPhone();
	void CompressRes();
	void CompressSpecial();
	void CompressTokens();
	void CreateAddress();
	void CreateBus();
	void CreateBusResFlag();
	void CreateGeo();
	void CreateKey();
	void CreateMiscellaneous();
	void CreateNoSolicit();
	void CreateOptional();
	void CreatePhone();
	void CreateRes();
	void CreateSpecial();
	void CreateTokens();
	void DeCompressAddress(CIuNybbleBuffer& buffer);
	void DeCompressBus(CIuNybbleBuffer& buffer);
	void DeCompressBusResFlag(CIuNybbleBuffer& buffer);
	void DeCompressGeo(CIuNybbleBuffer& buffer);
	void DeCompressKey(CIuNybbleBuffer& buffer);
	void DeCompressMiscellaneous(CIuNybbleBuffer& buffer);
	void DeCompressNoSolicit(CIuNybbleBuffer& buffer);
	void DeCompressOptional(CIuNybbleBuffer& buffer);
	void DeCompressPhone(CIuNybbleBuffer& buffer);
	void DeCompressRes(CIuNybbleBuffer& buffer);
	void DeCompressSpecial(CIuNybbleBuffer& buffer);
	void DeCompressTokens(CIuNybbleBuffer& buffer);
	void MakeRecordDefAddress(CIuRecordDef& RecordDef);
	void MakeRecordDefBus(CIuRecordDef& RecordDef);
	void MakeRecordDefBusResFlag(CIuRecordDef& RecordDef);
	void MakeRecordDefGeo(CIuRecordDef& RecordDef);
	void MakeRecordDefKey(CIuRecordDef& RecordDef);
	void MakeRecordDefMiscellaneous(CIuRecordDef& RecordDef);
	void MakeRecordDefNoSolicit(CIuRecordDef& RecordDef);
	void MakeRecordDefOptional(CIuRecordDef& RecordDef);
	void MakeRecordDefPhone(CIuRecordDef& RecordDef);
	void MakeRecordDefRes(CIuRecordDef& RecordDef);
	void MakeRecordDefSpecial(CIuRecordDef& RecordDef);
	void MakeRecordDefTokens(CIuRecordDef& RecordDef);
	void NextAlt();
	void OpenAddress();
	void OpenAlt();
	void OpenGeo();
	void OpenSic();
	void Resolve();
	void ResolveAddress(CIuResolveSpec& Spec);
	void ResolveBus(CIuResolveSpec& Spec);
	void ResolveBusResFlag(CIuResolveSpec& Spec);
	void ResolveGeo(CIuResolveSpec& Spec);
	void ResolveKey(CIuResolveSpec& Spec);
	void ResolveMiscellaneous(CIuResolveSpec& Spec);
	void ResolveNoSolicit(CIuResolveSpec& Spec);
	void ResolveOptional(CIuResolveSpec& Spec);
	void ResolvePhone(CIuResolveSpec& Spec);
	void ResolveRes(CIuResolveSpec& Spec);
	void ResolveSpecial(CIuResolveSpec& Spec);
	void ResolveTokens(CIuResolveSpec& Spec);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Instance data
		// Back pointer to owner
		CIuBTree* m_pBTree;
		CIuOutput* m_pOutput;
		// Data related to the persistent storage location
		CIuObjectRepository* m_pObjectRepository;

	// Codec
		// Nybbles for the current record
		CIuNybbleBuffer m_record;
		// The codec version number
		CIuVersionNumber m_verVersion;

	// Compression
		// Raw record file object (compressor only)
		CIuRecordFilePtr m_pInput;
		// Raw record (compressor only)
		CIuRecordPtr m_pRawRecord;
		// A list of pointers for the current record (compressor only)
		CDWordArray m_adwPointers;
		// Field map & raw record for "mapped" fields (compressor only)
		// NOTE: For performance, we try to minimize the number of field mappings
		//			performed. Most of the maps are actually appended to this map.
		CIuRecordPtr m_pRecord;
		CIuFieldMap m_Map;
		// Variables nybbles (everything after the fixed bits... stored in reverse)
		// This buffer is only used during compression.
		// During decompression, the nybbles stay in there record buffer
		CIuNybbleBuffer m_nybblesVariable;
		// Variable bits (Stored after the fixed bits... but stored in normal order)
		CIuBitBuffer m_bitsVariable;
		// Are the input records exhausted?
		bool m_fRecordsExhausted;
		// Minimum bits in compressor output record
		int m_iMinimumRecordSize;

	// Decompression
		// A series of null terminated strings representing the output fields (decompressor only)
		// These variables limit the re-entrancy of the decompressor
		CIuStringBuffer m_Output;
		//	Temporary decompressor buffer
		CIuBuffer m_Temp;
		// Next nybble to consume
		int m_iNextNybble;
		// Next bit to consume from fixed bit buffer
		int m_iNextFixedBit;
		// Next variable bit to consume
		int m_iNextVariableBit;
		// Next variable nybble to consume
		int m_iNextVariableNybble;

	// Index builds...
		// Key for the next record (if any)
		// Used for building multi-pointer indexes
		CIuKey m_keyNext;
		// Next Raw record (if any)
		CIuRecordPtr m_pRecordNext;
		// Record containing the evaluated key fields (compressor only)
		CIuRecordPtr m_pRecordNextKey; 
		// Has the next record already been read?
		bool m_fNextRecord;

	// Key
		// Is only a key stored for this codec?
		bool m_fKeyOnly;
		// Definition of key
		CIuKeyDef m_KeyDef;
		// Key for the current record
		CIuKey m_key;
		// Flags for fields
		// Stored here for performance reasons
		CIntArray m_aiKeyFlags;
		// Field mapping for key fields (compressor only)
		CIuFieldMap m_KeyMap;
		// Offset/count in master record map (compressor only)
		int m_iKeyFirst;
		int m_iKeyCount;

	// Alternate records (inserted in compressor)
		// NOTE: These specification on control whether alternate
		// records are inserted. They do _not_ control the try 
		// harder logic
		// Has alternate table attached? (internal flag)
		bool m_fHasAlt;
		// Special flags controlling insertion
		bool m_fAltPhone;
		bool m_fAltCity;
		// Are alternate records inserted? (compressor only)
		CIuMoniker m_monikerAltMoniker;
		// Alternate records file (compressor only)
		CIuAltPtr m_pAlt;
		// Current alt record to be inserted
		int m_iAlt;
		CString m_sAlt;
		// Next alternate "value" to use
		int m_iAltValue;
		int m_iAltValues;
		// Indicates last record was an alternate...
		bool m_fPrevAlt;
		// Pointers from the previous record. The other stuff will be rebuilt.
		CDWordArray m_adwPrevPointers;

	// Fixed Bits
		// Number of bits in the fixed bit buffer
		int m_iFixedBits;
		// The bits for the current record
		// NOTE: Only used for compression. During decompression, all bits are
		// stored in the variable length buffer
		CIuBitBuffer m_bitsFixed;

	// Geography
		// Does the codec use a geo
		bool m_fHasGeo;
		// Moniker for the geo being used
		CIuMoniker m_monikerGeoMoniker;
		// Number of bits to store geography token
		int m_iGeoBits;
		// Pointer to the geo being used
		CIuGeoPtr m_pGeo;
		// Current geo information
		CIuGeoCodec m_GeoCodec;
		// Mapping of geo releated fields (compressor only)
		CIuGeoMap m_GeoMap;
		// This can be used to save space by reducing the precision
		// of lat/int deltas. This value is the number of bits stripped
		// from the end of each delta (lat & int).  Since the default
		// precision is about 3 feet, each bit removed doubles the error.
		int m_iLatLongPrecision;
		// If this flag is set, no ZIP+4 is stored. Only the ZIP5
		bool m_fNoZipAddOn;
		// Should the various geo components be corrected from the geography 
		// default to the value specified in the record.
		bool m_fNoCityStateCorrection;
		bool m_fNoMsaCorrection;
		bool m_fNoCountyCorrection;
		bool m_fNoLatLongCorrection;

	// Address
		bool m_fHasAddress;
		// Moniker of address file
		CIuMoniker m_monikerAddressMoniker;
		// The address file
		CIuAddressPtr m_pAddress;
		// The address codec (compressor only)
		CIuAddressCodecPtr m_pAddressCodec;

	// No Solicit
		// No solicit field (compressor only)
		CString m_sNoSolicit;
		// Store no mail solicit flag?
		bool m_fNoSolicitMail;
		// Store no phone solicit flag?
		bool m_fNoSolicitPhone;
		// Indicate whether current records is no mail/phone solicit? (decompressor only)
		bool m_fNoSolicitMailCurrent;
		bool m_fNoSolicitPhoneCurrent;
		// Offset/count in master record map (compressor only)
		int m_iNoSolicitFirst;

	// Business/Residential
		// Residences only?
		bool m_fResOnly;
		// Businesses only?
		bool m_fBusOnly;
		// Name of the bus/res flag field
		CString m_sBusResFlag;
		// Field offset for bus/res flag
		int m_iBusResFlag;
		// Indicate whether current record is residence/business? (decompressor only)
		bool m_fResCurrent;

	// Business
		CString m_sEmployeeSizeCode;
		int m_iEmployeeSizeCode;
		CString m_sSalesVolumeCode;
		int m_iSalesVolumeCode;

		CIuMoniker m_monikerSicMoniker;
		CIuSicPtr m_pSic;
		CString m_sSicCode;
		CString m_sFranchiseCode;
		CString m_sAdSizeCode;
		CString m_sFirstYear;
		int m_iSicCode;
		int m_iFranchiseCode;
		int m_iAdSizeCode;
		int m_iFirstYear;
		int m_iSicCount;
		int m_iSicBits;
		int m_iCurrentYear;

		CIuFieldNth m_Sics;
		CIuFieldNth m_Franchises;
		CIuFieldNth m_AdSizeCodes;
		CIuFieldNth m_FirstYears;

	// Residential

	// Tokens
		// Number of bits used by each token
		CIntArray m_aiTokenBits;
		// If the token flags (optional/exceptional)?
		CIntArray m_aiTokenFlags;
		// A list of tokenizers
		CIuBTreeTokenizers m_Tokenizers;

	// Special
		CString m_sGender;
		int m_iGender;

	// Miscellaneous fields
		// Flags for fields
		// Stored here for performance reasons
		CIntArray m_aiMiscellaneousFlags;
		// Record containing the evaluated fields (compressor only)
		// Field mapping for miscellaneous fields (compressor only)
		CIuFieldMap m_MiscellaneousMap;
		// Offset/count in master record map (compressor only)
		int m_iMiscellaneousFirst;
		int m_iMiscellaneousCount;

	// Optional fields
	//		Zero or more fields. Empty fields are not stored.
	//		Bits in the "packed bits" area indicate whether a field is present or not.
	//		
		// Flags for fields
		// Stored here for performance reasons
		CIntArray m_aiOptionalFlags;
		// Field mapping for optional fields (compressor only)
		CIuFieldMap m_OptionalMap;
		// Offset/count in master record map (compressor only)
		int m_iOptionalFirst;
		int m_iOptionalCount;

	// Phones
		// Number of phones being stored (persistent)
		int m_iPhoneCount;
		// Mapping of phone number fields (compressor only)
		CIuFieldMap m_PhoneMap;
		// Offset/count in master record map (compressor only)
		int m_iPhoneNoFirst;
		int m_iPhoneNoCount;
	// For performance, we keep a local pointer to the stats object
		CIuBTreeStatistics* m_pStats;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddressCodec& CIuBTreeCodec::GetAddressCodec() const
{
	return m_pAddressCodec.Ref();
}

inline CIuMoniker CIuBTreeCodec::GetAddressMoniker() const
{
	return m_monikerAddressMoniker;
}

inline CString CIuBTreeCodec::GetAdSizeCode() const
{
	return m_sAdSizeCode;
}

inline CIuMoniker CIuBTreeCodec::GetAltMoniker() const
{
	return m_monikerAltMoniker;
}

inline CIuBTree& CIuBTreeCodec::GetBTree() const
{
	ASSERT(m_pBTree!=0);
	return *m_pBTree;
}

inline CString CIuBTreeCodec::GetBusResFlag() const
{
	return m_sBusResFlag;
}

inline CString CIuBTreeCodec::GetEmployeeSizeCode() const
{
	return m_sEmployeeSizeCode;
}

inline CString CIuBTreeCodec::GetFirstYear() const
{
	return m_sFirstYear;
}

inline int CIuBTreeCodec::GetFixedBits() const
{
	return m_iFixedBits;
}

inline CString CIuBTreeCodec::GetFranchiseCode() const
{
	return m_sFranchiseCode;
}

inline CString CIuBTreeCodec::GetGender() const
{
	return m_sGender;
}

inline int CIuBTreeCodec::GetGeoBits() const
{
	return m_iGeoBits;
}

inline CIuGeoMap& CIuBTreeCodec::GetGeoMap() const
{
	return *const_cast<CIuGeoMap*>(&m_GeoMap);
}

inline CIuMoniker CIuBTreeCodec::GetGeoMoniker() const
{
	return m_monikerGeoMoniker;
}

inline CIuRecordFile& CIuBTreeCodec::GetInput() const
{
	return m_pInput.Ref();
}

inline const CIuKey& CIuBTreeCodec::GetKey() const
{
	return m_key;
}

inline CIuKeyDef& CIuBTreeCodec::GetKeyDef() const
{
	return *const_cast<CIuKeyDef*>(&m_KeyDef);
}

inline int CIuBTreeCodec::GetKeyFields() const
{
	return m_aiKeyFlags.GetSize();
}

inline CIuFieldMap& CIuBTreeCodec::GetKeyMap() const
{
	return *const_cast<CIuFieldMap*>(&m_KeyMap);
}

inline const CIuKey& CIuBTreeCodec::GetKeyNext() const
{
	return m_keyNext;
}

inline int CIuBTreeCodec::GetLatLongPrecision() const
{
	return m_iLatLongPrecision;
}

inline int CIuBTreeCodec::GetMinimumRecordSize() const
{
	return m_iMinimumRecordSize;
}

inline CIuFieldMap& CIuBTreeCodec::GetMiscellaneousMap() const
{
	return *const_cast<CIuFieldMap*>(&m_MiscellaneousMap);
}

inline CString CIuBTreeCodec::GetNoSolicit() const
{
	return m_sNoSolicit;
}

inline CIuObjectRepository& CIuBTreeCodec::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuFieldMap& CIuBTreeCodec::GetOptionalMap() const
{
	return *const_cast<CIuFieldMap*>(&m_OptionalMap);
}

inline int CIuBTreeCodec::GetPhoneCount() const
{
	return m_iPhoneCount;
}

inline CIuFieldMap& CIuBTreeCodec::GetPhoneMap() const
{
	return *const_cast<CIuFieldMap*>(&m_PhoneMap);
}

inline CDWordArray& CIuBTreeCodec::GetPointers() const																			
{																																			  
	return *const_cast<CDWordArray*>(&m_adwPointers);
}

inline const CIuNybbleBuffer& CIuBTreeCodec::GetRecord() const
{
	return m_record;
}

inline CString CIuBTreeCodec::GetSalesVolumeCode() const
{
	return m_sSalesVolumeCode;
}

inline int CIuBTreeCodec::GetSicBits() const
{
	return m_iSicBits;
}

inline CString CIuBTreeCodec::GetSicCode() const
{
	return m_sSicCode;
}

inline int CIuBTreeCodec::GetSicCount() const
{
	return m_iSicCount;
}

inline CIuMoniker CIuBTreeCodec::GetSicMoniker() const
{
	return m_monikerSicMoniker;
}

inline int CIuBTreeCodec::GetTokenBitsCount() const
{
	return m_aiTokenBits.GetSize();
}

inline CIuBTreeTokenizers& CIuBTreeCodec::GetTokenizers() const
{
	return *const_cast<CIuBTreeTokenizers*>(&m_Tokenizers);
}

inline CIuVersionNumber CIuBTreeCodec::GetVersion() const
{
	return m_verVersion;
}

inline bool CIuBTreeCodec::HasAddress() const
{
	return m_fHasAddress;
}

inline bool CIuBTreeCodec::HasAdSizeCode() const
{
	return !m_sAdSizeCode.IsEmpty();
}

inline bool CIuBTreeCodec::HasBusResFlag() const
{
	return !m_sBusResFlag.IsEmpty();
}

inline bool CIuBTreeCodec::HasEmployeeSizeCode() const
{
	return !m_sEmployeeSizeCode.IsEmpty();
}

inline bool CIuBTreeCodec::HasFirstYear() const
{
	return !m_sFirstYear.IsEmpty();
}

inline bool CIuBTreeCodec::HasFranchiseCode() const
{
	return !m_sFranchiseCode.IsEmpty();
}

inline bool CIuBTreeCodec::HasGeo() const
{
	return m_fHasGeo;
}

inline bool CIuBTreeCodec::HasKeyOnly() const
{
	return m_fKeyOnly;
}

inline bool CIuBTreeCodec::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuBTreeCodec::HasSalesVolumeCode() const
{
	return !m_sSalesVolumeCode.IsEmpty();
}

inline bool CIuBTreeCodec::HasSicCode() const
{
	return !m_sSicCode.IsEmpty();
}
	
inline bool CIuBTreeCodec::IsAlt() const
{
	return m_fPrevAlt;
}

inline bool CIuBTreeCodec::IsAltCity() const
{
	return m_fAltCity;
}

inline bool CIuBTreeCodec::IsAltPhone() const
{
	return m_fAltPhone;
}

inline bool CIuBTreeCodec::IsBusOnly() const
{
	return m_fBusOnly;
}

inline bool CIuBTreeCodec::IsResOnly() const
{
	return m_fResOnly;
}

inline bool CIuBTreeCodec::NoCityStateCorrection() const
{
	return m_fNoCityStateCorrection;
}

inline bool CIuBTreeCodec::NoCountyCorrection() const
{
	return m_fNoCountyCorrection;
}

inline bool CIuBTreeCodec::NoLatLongCorrection() const
{
	return m_fNoLatLongCorrection;
}

inline bool CIuBTreeCodec::NoMsaCorrection() const
{
	return m_fNoMsaCorrection;
}

inline bool CIuBTreeCodec::NoSolicitMail() const
{
	return m_fNoSolicitMail;
}

inline bool CIuBTreeCodec::NoSolicitPhone() const
{
	return m_fNoSolicitPhone;
}

inline bool CIuBTreeCodec::NoZipAddOn() const
{
	return m_fNoZipAddOn;
}

#endif // _ENGINE_BTREECODEC_H_
