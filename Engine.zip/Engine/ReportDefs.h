#ifndef _ENGINE_ReportDefS_H_
#define _ENGINE_ReportDefS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
#ifndef 	_ENGINE_REPORTDEF_H_
#	include "Engine\ReportDef.h"
#endif	// _ENGINE_REPORTDEF_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReportDefs)
class CIuEngine;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReportDefs, CIuCollection }}
#define CIuReportDefs_super CIuCollection

class IU_CLASS_EXPORT CIuReportDefs : public CIuReportDefs_super
{
//{{Declare
	DECLARE_SERIAL(CIuReportDefs)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReportDefs();           
	virtual ~CIuReportDefs();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuReportDef& Get(const CIuMoniker& moniker) const;
	CIuReportDef& Get(LPCTSTR s) const;
	CIuReportDef& Get(int iIndex) const;
	CIuReportDef& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Create(CIuReportDefSpec& ReportDefSpec);
	void SetEngine(CIuEngine& Engine);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuReportDef& CIuReportDefs::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuReportDef*>(&CIuCollection::Get(moniker));
}

inline CIuReportDef& CIuReportDefs::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuReportDef*>(&CIuCollection::Get(s));
}

inline CIuReportDef& CIuReportDefs::Get(int iIndex) const
{
	return *dynamic_cast<CIuReportDef*>(&CIuCollection::Get(iIndex));
}

inline CIuReportDef& CIuReportDefs::Get(CIuID id) const
{
	return *dynamic_cast<CIuReportDef*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuReportDefs::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

inline bool CIuReportDefs::HasEngine() const
{
	return m_pEngine!=0;
}

#endif 
