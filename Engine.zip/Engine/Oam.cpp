#include "StdAfx.h"
//{{Include
#include "Oam.h"
#include "OamBroker.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

extern "C" CIuXmlBroker* infoUSAXmlBroker(const TCHAR* pcszName)
{
	if (_tcsisempty(pcszName) || _tcsicmp(pcszName, _T("oam")) == 0)
	{
		// Create an OAM Broker
		CIuOamBrokerPtr pBroker;
		pBroker.Create();
		ASSERT(pBroker.NotNull());
		// NOTE: We are returning a pointer which has an additional reference count
		// We don't return a CIuBrokerPtr because the exern "C" convention won't
		// handle it.
		pBroker.AddRef();
		return pBroker.Ptr();
	}
	return 0;
}

