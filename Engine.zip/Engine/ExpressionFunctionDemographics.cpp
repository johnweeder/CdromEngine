#include "StdAfx.h"
//{{Include
#include "ExpressionFunctionDemographics.h"
#include "DemographicsBusiness.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement

// NOTE: Function names _ending_ with an underscore are considered to be "internal"
//			and should not be exposed to external customers.
//			The second part of the function name is a list of parameters

static const CIuExpressionFunctionDef adefs[] =
{
	// Functions
	// NOTE: This array should match the enum in ExpressionElement.h
	{ 
		exprAdSizeName,
		"AdSizeName\0",                   
		PFNFUNCTION(CIuExpressionFunctionDemographics::AdSizeName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionDemographics::AdSizeNameMaxLength), 
		CIuExpressionFunctionDemographics::Create
	},{ 
		exprEmployeeSizeName,
		"EmployeeSizeName\0",                   
		PFNFUNCTION(CIuExpressionFunctionDemographics::EmployeeSizeName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionDemographics::EmployeeSizeNameMaxLength), 
		CIuExpressionFunctionDemographics::Create
	},{ 
		exprSalesVolumeName,
		"SalesVolumeName\0",                   
		PFNFUNCTION(CIuExpressionFunctionDemographics::SalesVolumeName), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionDemographics::SalesVolumeNameMaxLength), 
		CIuExpressionFunctionDemographics::Create
	},{ 
		exprUnknown, 0
	}
};
//}}Implement


CIuExpressionFunctionDemographics::CIuExpressionFunctionDemographics(CIuExpressionType Type) : CIuExpressionFunction(Type)
{
}

CIuExpressionFunctionDemographics::CIuExpressionFunctionDemographics(const CIuExpressionFunctionDemographics& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionFunctionDemographics::~CIuExpressionFunctionDemographics()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

LPCTSTR CIuExpressionFunctionDemographics::AdSizeName(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	return ::AdSizeName(::AdSizeFromCode(*pcsz));
}

int CIuExpressionFunctionDemographics::AdSizeNameMaxLength() const
{
	return ::AdSizeNameMaxLength();
}

CIuExpressionElement* CIuExpressionFunctionDemographics::Clone() const
{
	CIuExpressionFunctionDemographics* pElement = new CIuExpressionFunctionDemographics(*this);
	ASSERT(pElement);
	return pElement;
} 

CIuExpressionFunction* CIuExpressionFunctionDemographics::Create()
{
	return new CIuExpressionFunctionDemographics;
}

LPCTSTR CIuExpressionFunctionDemographics::EmployeeSizeName(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	return ::EmployeeSizeName(::EmployeeSizeFromCode(*pcsz));
}

int CIuExpressionFunctionDemographics::EmployeeSizeNameMaxLength() const
{
	return ::EmployeeSizeNameMaxLength();
}

const CIuExpressionFunctionDef* CIuExpressionFunctionDemographics::GetFunctionDefs()
{
	return adefs;
}

bool CIuExpressionFunctionDemographics::IsConst() const
{
	return CIuExpressionFunctionDemographics_super::IsConst();
}

CIuExpressionFunctionDemographics& CIuExpressionFunctionDemographics::operator=(const CIuExpressionFunctionDemographics& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionFunctionDemographics_super::operator=(rExpressionElement);
	return *this;
}

CIuExpressionElement* CIuExpressionFunctionDemographics::Optimize()
{
	// This virtual function is special in that the object being
	// called may delete itself! Be careful when doing this. If you 
	// delete yourself, do it as the last thing before exitting.
	return CIuExpressionFunctionDemographics_super::Optimize();
}

LPCTSTR CIuExpressionFunctionDemographics::SalesVolumeName(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	return ::SalesVolumeName(::SalesVolumeFromCode(*pcsz));
}

int CIuExpressionFunctionDemographics::SalesVolumeNameMaxLength() const
{
	return ::SalesVolumeNameMaxLength();
}

