#ifndef _ENGINE_RECORDSPEC_H_
#define _ENGINE_RECORDSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
#ifndef 	_COMMON_STATICBUFFER_H_
#	include "Common\StaticBuffer.h"
#endif	// _COMMON_STATICBUFFER_H_
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordSpec }}
//	This is a low level class which is used exclusively to construct a record
//	from. 

class IU_CLASS_EXPORT CIuRecordSpec 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordSpec();
	virtual ~CIuRecordSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	const BYTE* GetField(int iField) const;
	int GetFields() const;
	int GetFieldSize(int iField) const;
	CIuKey& GetKey();
	const BYTE* GetKeyPtr() const;
	int GetKeySize() const;
	bool IsAlternate() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Add(const BYTE* pb, int cb);
	void Add(LPCTSTR pcsz);
	void AddBlank();
	BYTE* AddStore(const BYTE* pb, int cb);
	BYTE* AddStore(LPCTSTR pcsz);
	void Clear();
	void Map(const CIuRecord& Record, const CIuFieldMap& FieldMap);
	void Set(const CIuRecord& Record);
	void Set(const CStringArray& as);
	void Set(const BYTE* pb, int cb);
	void Set(LPCTSTR pcsz, int cb);
	void Set(const CIuBuffer& Buffer);
	void SetAlt();
	void SetBoughtLevel(int iBoughtLevel);
	void SetBus();
	void SetExpandCount(DWORD dwExpandCount);
	void SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount);
	void SetExtra(WORD wExtra, int cbKey = 0);
	void SetFieldSize(int iField, int iSize);
	void SetFlags(WORD wFlags);
	void SetKey();
	void SetKey(int iKey);
	void SetKey(const BYTE* pbKey, int cbKey);
	void SetLatLong(DWORD dwLatitude, DWORD dwLongitude);
	void SetNoMail();
	void SetNoPhone();
	void SetRecordFields(int iRecordFields);
	void SetRecordNo(DWORD dwRecordNo);
	void SetRes();
	void SetSourceNo(DWORD dwSourceNo);
	void SetTagged();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// NOTE: Generally, you should avoid using these fields directly except
	//			when you are in dire need of performance (which is most of the 
	//			time when you are working at the record level).

	// Ultimately, the fields are created from these two members.
	// If m_apb[n] <= 0xffff, then the pointer references our internal buffer.
	//	Otherwise, m_apb[n] must be a pointer to a buffer which persists until
	//		after the record is created.
	// Don't just keep a pointer into the buffer. The internal buffer starts at 
	//		relatively a small size. If it is reallocated, it become necessary to 
	//		retart the entire mapping process because the pointers into the previous
	//		buffer will be incorrect.

	// The number of actual fields 
	int m_iFields;
	// Only the first 'N' fields necessarily be used in the actual record.
	// Sometimes, the other fields are tacked on to the end because we needed
	// scratch space to calculate the key or other things.
	int m_iRecordFields;
	//	Field size (m_acb[n]) does _not_ include the null and
	//		the field is not necessarily null terminated
	// A field may be blank if the size and pointer are null. 
	//	A blank field can be stored more efficiently in a raw record
	//		because we don't actually allocate space for it.
	// Maybe at a future date this could be dynamic....
	const BYTE* m_apb[recordMaxFields];
	int m_acb[recordMaxFields];
	// A buffer for accumulating data
	//	We use a rather large static buffer to eliminate allocations
	CIuStaticBuffer4096 m_Buffer;
	// Extra flags... just allocates space in case thing grows
	WORD m_wExtra;
	// Extra space for key to grow
	int m_cbKeyExtra;
	// Actual flags
	WORD m_wFlags;
	// DWORD values
	DWORD m_dwRecordNo;			
	DWORD m_dwSourceNo;			
	DWORD m_dwLatitude;			
	DWORD m_dwLongitude;
	DWORD m_dwExpandNo;			
	DWORD m_dwExpandCount;
	// Key (in various formats)
	CIuKey m_Key;
	int m_iKeyFields;
	const BYTE* m_pbKey;
	int m_cbKey;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline void CIuRecordSpec::Add(LPCTSTR pcsz)
{
	Add((const BYTE*)pcsz, _tcslen(pcsz));
}

inline void CIuRecordSpec::AddBlank()
{
	ASSERT(m_iFields < recordMaxFields);
	m_apb[m_iFields] = 0;
	m_acb[m_iFields] = 0;
	++m_iFields;
}

inline BYTE* CIuRecordSpec::AddStore(LPCTSTR pcsz)
{
	return AddStore((const BYTE*)pcsz, _tcslen(pcsz));
}

inline const BYTE* CIuRecordSpec::GetField(int iField) const
{
	ASSERT(iField >= 0 && iField < m_iFields);
	const BYTE* pb = m_apb[iField];
	if (int(pb) > 0xffff)
		return pb;
	if (pb == 0)
		return (const BYTE*)"";
	return m_Buffer.GetPtr(int(pb));
}

inline int CIuRecordSpec::GetFields() const
{
	return m_iFields;
}

inline int CIuRecordSpec::GetFieldSize(int iField) const
{
	ASSERT(iField >= 0 && iField < m_iFields);
	return m_acb[iField];
}

inline CIuKey& CIuRecordSpec::GetKey()
{
	return m_Key;
}

inline const BYTE* CIuRecordSpec::GetKeyPtr() const
{
	return int(m_pbKey) > 0xffff ? m_pbKey: m_Buffer.GetPtr(int(m_pbKey));
}

inline int CIuRecordSpec::GetKeySize() const
{
	return m_cbKey;
}

inline bool CIuRecordSpec::IsAlternate() const
{
	return (m_wFlags & recordAlternate) != 0;
}

inline void CIuRecordSpec::Set(LPCTSTR pcsz, int cb)
{
	CIuRecordSpec::Set((const BYTE*)pcsz, cb);
}

inline void CIuRecordSpec::Set(const CIuBuffer& Buffer)
{
	Set(Buffer.GetPtr(), Buffer.GetSize());
}

#endif // _ENGINE_RECORDSPEC_H_
