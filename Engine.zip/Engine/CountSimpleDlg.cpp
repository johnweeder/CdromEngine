#include "stdafx.h"
//{{Include
#include "CountSimpleDlg.h"
#include "Ui\ProgressBroadcast.h"
#include "Ui\ProgressEvent.h"
#include "Globals\Events.h"
#include "Interop\Conversions.h"
#include "Query.h"
#include "Counts.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuCountSimpleDlg, CDialog)
	//{{AFX_MSG_MAP(CIuCountSimpleDlg)
		ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_ENGINE_STOP, OnStop)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(wmProgressEvent, OnEvent)
END_MESSAGE_MAP()
const int idTimer = 769;
//}}Implement

CIuCountSimpleDlg::CIuCountSimpleDlg(CWnd* pParent /*=NULL*/) : CIuCountSimpleDlg_super(CIuCountSimpleDlg::IDD, pParent)
{
	//{{Initialize
	m_fAbort = false;
	m_iHandle = -1;
	m_pBroadcast = 0;
	m_fRunning = false;
	m_fCanClose = false;
	//}}Initialize

	//{{AFX_DATA_INIT(CIuCountSimpleDlg)
	m_sLabel1 = _T("");
	m_sLabel2 = _T("");
	m_sTotal = _T("0");
	m_sRemaining = _T("0");
	m_sCount2 = _T("0");
	m_sCount1 = _T("0");
	//}}AFX_DATA_INIT
}

CIuCountSimpleDlg::~CIuCountSimpleDlg()
{
}

void CIuCountSimpleDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuCountSimpleDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuCountSimpleDlg)
	DDX_Text(pDX, IDC_ENGINE_LABEL1, m_sLabel1);
	DDX_Text(pDX, IDC_ENGINE_LABEL2, m_sLabel2);
	DDX_Text(pDX, IDC_ENGINE_TOTAL_TOTAL, m_sTotal);
	DDX_Text(pDX, IDC_ENGINE_REMAINING, m_sRemaining);
	DDX_Text(pDX, IDC_ENGINE_COUNT2, m_sCount2);
	DDX_Text(pDX, IDC_ENGINE_COUNT1, m_sCount1);
	DDX_Control(pDX, IDC_ENGINE_REMAINING, m_editRemaining);
	DDX_Control(pDX, IDC_ENGINE_LABEL_REMAINING, m_stLabelRemaining);
	DDX_Control(pDX, IDC_ENGINE_STOP, m_btnStop);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuCountsPtr CIuCountSimpleDlg::DoDialog(CIuQuery& Query, LPCTSTR pcszExpression, CWnd* pParent, LPCTSTR pcszLabel1, LPCTSTR pcszLabel2)
{
	CIuCountSimpleDlg dlg(pParent);

	dlg.m_pBroadcast = &Query.GetEngine().GetBroadcast();
	dlg.m_pQuery = &Query;
	dlg.m_sExpression = pcszExpression;
	if (pcszLabel1)
		dlg.m_sLabel1 = pcszLabel1;
	if (pcszLabel2)
		dlg.m_sLabel2 = pcszLabel2;
	if (dlg.DoModal() != IDOK)
		return CIuCountsPtr();
	return dlg.m_pCounts;
}

void CIuCountSimpleDlg::OnCancel()
{
	OnStop();
}

void CIuCountSimpleDlg::OnOK()
{
	OnStop(); 
}

void CIuCountSimpleDlg::OnClose() 
{
	CIuCountSimpleDlg_super::OnClose();
}

LRESULT CIuCountSimpleDlg::OnEvent(WPARAM, LPARAM lpParam)
{
	CIuProgressEvent* pEvent = (CIuProgressEvent*)lpParam;
	if (pEvent == 0)
		return 0;

	if (GetHandle() != -1 && pEvent->GetHandle() != -1 && GetHandle() != pEvent->GetHandle())
		return 0;
	
	// If this is not an event we are interested in, just return.
	// If handle is -1, we show all events...
	switch (pEvent->GetEvent())
	{
		case IU_EVENT_ENGINE_COUNT_COMPLETE:
			m_editRemaining.ShowWindow(SW_HIDE);
			m_stLabelRemaining.ShowWindow(SW_HIDE);
			m_btnStop.SetWindowText(_T("&Close"));
			m_fCanClose = true;
		case IU_EVENT_ENGINE_COUNT:
		{
			CIuCountsPtr pCounts = (CIuCounts*)pEvent->GetData();
			ASSERT(pCounts.NotNull());
			IntAsString(m_sRemaining, pCounts->GetRemaining());
			IntAsString(m_sCount1, pCounts->GetMatched());
			ASSERT(pCounts->GetMatched() <= pCounts->GetTotal());
			IntAsString(m_sCount2, pCounts->GetTotal() - pCounts->GetMatched());
			IntAsString(m_sTotal, pCounts->GetTotal());
			UpdateData(FALSE);
			break;
		}
		case IU_EVENT_OPERATION_ABORT:
			// Abort event, set our abort flag as if the user had pressed the key
			SetAbort(true);
		case IU_EVENT_OPERATION_COMPLETE:
			m_editRemaining.ShowWindow(SW_HIDE);
			m_stLabelRemaining.ShowWindow(SW_HIDE);
			m_btnStop.SetWindowText(_T("&Close"));
			m_fCanClose = true;
			break;
	}

	UpdateData(false);

	// Return not-zero to abort or zero to continue.
	return LRESULT(ShouldAbort() ? 1: 0);
}

BOOL CIuCountSimpleDlg::OnInitDialog() 
{
	CIuCountSimpleDlg_super::OnInitDialog();
	
	m_btnStop.SetWindowText(_T("&Cancel"));

	UpdateData(false);

	CenterWindow();

	if (m_pBroadcast)
		m_pBroadcast->Subscribe(this, wmProgressEvent);

	SetTimer(idTimer, 100, 0);

	return true;  
}

void CIuCountSimpleDlg::OnStop() 
{
	if (m_fCanClose)
	{
		if (m_fAbort)		
			CIuCountSimpleDlg_super::OnCancel();
		else
			CIuCountSimpleDlg_super::OnOK();
	}
	else
	{
		SetAbort(true);
		m_fCanClose = true;
		m_btnStop.SetWindowText(_T("&Close"));
	}
}

void CIuCountSimpleDlg::OnTimer(UINT nIDEvent) 
{
	if (!m_fRunning && idTimer == nIDEvent)
	{
		m_fRunning = true;
		KillTimer(idTimer);
		m_pCounts = m_pQuery->Count(m_sExpression);
		ASSERT(m_pCounts.NotNull());
	}
	CDialog::OnTimer(nIDEvent);
}

void CIuCountSimpleDlg::PostNcDestroy() 
{

	// John I moved the unsubscribe from here since the CIuCountSimpleDlg->m_hWnd is null
	// once U get here, so U can not unsubscribe.
	CIuCountSimpleDlg_super::PostNcDestroy();
}

void CIuCountSimpleDlg::SetAbort(bool f)
{
	m_fAbort = f;
}

void CIuCountSimpleDlg::SetBroadcast(CIuProgressBroadcast* pBroadcast)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pBroadcast != 0);
	m_pBroadcast = pBroadcast;
}

void CIuCountSimpleDlg::SetHandle(int iHandle)
{
	m_iHandle = iHandle;
}



void CIuCountSimpleDlg::OnDestroy() 
{
	if (m_pBroadcast)
	{
		m_pBroadcast->UnSubscribe(this);
		m_pBroadcast = 0;
	}
	CDialog::OnDestroy();
}
