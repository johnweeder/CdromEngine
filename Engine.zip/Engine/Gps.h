#ifndef _ENGINE_GPS_H_ 
#define _ENGINE_GPS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_GLOBALS_RECURSION_H_
#	include "Globals\Recursion.h"
#endif	// _GLOBALS_RECURSION_H_
#ifndef 	_COMMON_COMMFILE_H_
#	include "Common\CommFile.h"
#endif	// _COMMON_COMMFILE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGps)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGps, CCmdTarget }}
#define CIuGps_super CIuObject

class IU_CLASS_EXPORT CIuGps : public CIuGps_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_DYNCREATE(CIuGps)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGps();
	virtual ~CIuGps();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAltitude() const;
	CIuEngine& GetEngine() const;
	CString GetLatitude() const;
	CString GetLongitude() const;
	int GetSatellites() const;
	CString GetStatus() const;
	CString GetUtcTime() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Abort() ;
	virtual void Clear();
	void CommonConstruct();
	bool Connect(LPCTSTR ConnectString) ;
	bool DisConnect() ;
	CString Proximity(LPCTSTR Latitude, LPCTSTR Longitude);
	bool Refresh();
	void SetAltitude(int);
	void SetEngine(CIuEngine& Engine);
	void SetLatitude(LPCTSTR);
	void SetLongitude(LPCTSTR);
	void SetSatellites(int);
	void SetStatus(LPCTSTR);
	void SetUtcTime(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionConnect(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionRefresh(const CIuPropertyCollection& Collection, CIuOutput& Output);
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuRecurseInstance m_recurse;
	CIuEngine* m_pEngine;
	CString m_sLatitude;
	CString m_sLongitude;
	CString m_sStatus;
	int m_iAltitude;
	CString m_sUtcTime;
	int m_iSatellites;
	bool m_fAbort;
	CString m_sConnect;
	CIuCommFile m_com;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuGps::GetAltitude() const
{
	return m_iAltitude;
}

inline int CIuGps::GetSatellites() const
{
	return m_iSatellites;
}

inline CString CIuGps::GetUtcTime() const
{
	return m_sUtcTime;
}

#endif // _ENGINE_GPS_H_
