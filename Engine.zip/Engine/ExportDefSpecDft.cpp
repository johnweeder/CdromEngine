#include "StdAfx.h"
//{{Include
#include "ExportDefSpecDft.h"
#include "ExportDef.h"
#include "IDs.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ExportDef specifications

// Exporter Names
static const TCHAR szExporterNameCSV[]		= "Comma Delimited";
static const TCHAR szExporterNameTAB[]		= "Tab Delimited";
static const TCHAR szExporterNameDBF[]		= "dBase III";
static const TCHAR szExporterNameTXT[]		= "Text";
static const TCHAR szExporterNameFIX[]		= "Fixed Length";

// Default Export Specifications

// Options:
// HasHeader[=NO]    if option is present, output a header record of field names
// HeaderNames=Short|Long; if HasHeader, use these names in the header
//             default is Long (int field names)
// NoSelect[=NO]    Prevent format from showing up in export dialog
//// Overrides of the default export begin/end etc.
// Must either specify NoXChg... or XChg...=String
// If both are found, you'll get an empty string for that XChg value.
//
// NoXChgTerminator or XChgTerminator=String
// NoXChgSeparator or XChgSeparator=String
// NoXChgBegin or XChgBegin=String
// NoXChgEnd or XChgEnd=String
//
// The table below is only a convenience.
// See CIuExporter::CreateXChgFile for actual default xchg file values.
//
// Format begin   end     separator terminator
// CSV    dquote  dquote  comma     crlf
// TAB    <empty> <empty> tab       crlf
// TXT    <empty>	<empty> crlf      crlf   // each field on its own line
// 

static const CIuExportDefSpecDft exportDefSingleLineDft =
{
	"SingleLine", exportDefSingleLine,
	&idExportDefSingleLine,
	_T("Single Line"),
	_T(""),
	"TXT",
	"",
	szExporterNameTXT,
	exportDefTypeFixed,
	0,
	{
		"Field(longname='Field',shortname='Field'): PasteSpace("
			"Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name])),"
			"MakeAddress([PriNo],[Street],[SecNo]),"
			"MakeLastLine([City],[StateAbbr],HyphenateZIP(Left([ZIP],9))),"
			"HyphenatePhone([ACPhone]))",
		0	
	}
};

static const CIuExportDefSpecDft exportDefActDft =
{
	"Act", exportDefAct,
	&idExportDefAct,
	_T("ACT!"),
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,
	exportDefTypeFixed,
	0,
	{
		"Business(longname='Business',shortname='BUSINESS'):Iff([SICCode],[Name],'')",
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],'',Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name])))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefWordproMailMergeDft =
{
	"WordproMailMerge", exportDefWordproMailMerge,
	&idExportDefWordproMailMerge,
	_T("WordPro Mail Merge (AmiPro)"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefAutomapStreetsDft =
{
	"AutomapStreets", exportDefAutomapStreets,
	&idExportDefAutomapStreets,
	_T("AutoMap Streets (Microsoft)"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"StreetAdr(longname='StreetAdr',shortname='STREETADR'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Latitude(longname='Latitude',shortname='LATITUDE'):[Latitude]",
		"Longitude(longname='Longitude',shortname='LONGITUDE'):[Longitude]",
		"Url(longname='Url',shortname='URL'):[WebSite]",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"SicCode(longname='SicCode',shortname='SICCODE'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft exportDefDbaseIiIiiDft =
{
	"DbaseIiIii", exportDefDbaseIiIii,
	&idExportDefDbaseIiIii,
	_T("DBase II,III"),
	_T(""),
	"DBF",
	"",
	szExporterNameDBF,
	exportDefTypeFixed,
	151,
	{
		"LastName(Offset=0,Length=30,longname='LastName',shortname='LASTNAME'):Iff([SICCode],[Name],'')",
		"FirstName(Offset=30,Length=30,longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"Address(Offset=60,Length=30,longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(Offset=90,Length=30,longname='City',shortname='CITY'):[City]",
		"State(Offset=120,Length=2,longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(Offset=122,Length=10,longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(Offset=132,Length=12,longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Sic(Offset=144,Length=6,longname='Sic',shortname='SIC'):[SICCode]",
		"Busres(Offset=150,Length=1,longname='Busres',shortname='BUSRES'):Iff([SICCode],'B','R')",
		0	
	}
};

static const CIuExportDefSpecDft exportDefDesktopManagerDft =
{
	"DesktopManager", exportDefDesktopManager,
	&idExportDefDesktopManager,
	_T("Desktop Manager"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"Business(longname='Business',shortname='BUSINESS'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"AreaCode(longname='AreaCode',shortname='AREACODE'):Left([ACPhone],3)",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone(Mid([ACPhone],3,7))",
		0	
	}
};

static const CIuExportDefSpecDft exportDefGoldmineDft =
{
	"Goldmine", exportDefGoldmine,
	&idExportDefGoldmine,
	_T("GoldMine"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Business(longname='Business',shortname='BUSINESS'):Iff([SICCode],[Name],'')",
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],'',Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name])))",
		"StreetAddress(longname='StreetAddress',shortname='STREETADDR'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefLotusOrganizer21Dft =
{
	"LotusOrganizer21", exportDefLotusOrganizer21,
	&idExportDefLotusOrganizer21,
	_T("Lotus Organizer 2.1"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Filler(longname='Filler',shortname='Filler'):'0'",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"Business(longname='Business',shortname='BUSINESS'):Iff([SICCode],[Name],'')",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMaximizerDft =
{
	"Maximizer", exportDefMaximizer,
	&idExportDefMaximizer,
	_T("Maximizer"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMaplinxDft =
{
	"Maplinx", exportDefMaplinx,
	&idExportDefMaplinx,
	_T("MapLinx (.csv Import)"),
	_T(""),
	"CSV",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMicrosoftWordMailMergeDft =
{
	"MicrosoftWordMailMerge", exportDefMicrosoftWordMailMerge,
	&idExportDefMicrosoftWordMailMerge,
	_T("Microsoft Word Mail Merge"),
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"Address2(longname='Address2',shortname='ADDRESS2'):MakeLastLine([City],[StateAbbr],HyphenateZIP(Left([ZIP],9)))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMicrosoftOutlookDft =
{
	"MicrosoftOutlook", exportDefMicrosoftOutlook,
	&idExportDefMicrosoftOutlook,
	_T("Microsoft OutLook"),
	_T(""),
	"CSV",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"BusinessStreet(longname='BusinessStreet',shortname='BUSINESSST'):Iff([SICCode],MakeAddress([PriNo],[Street],[SecNo]),'')",
		"BusinessCity(longname='BusinessCity',shortname='BUSINESSCI'):Iff([SICCode],[City],'')",
		"BusinessState(longname='BusinessState',shortname='BUSINESSST'):Iff([SICCode],[StateAbbr],'')",
		"BusinessPostalCode(longname='BusinessPostalCode',shortname='BUSINESSPO'):Iff([SICCode],HyphenateZIP(Left([ZIP],9)),'')",
		"HomeStreet(longname='HomeStreet',shortname='HOMESTREET'):Iff([SICCode],'',MakeAddress([PriNo],[Street],[SecNo]))",
		"HomeCity(longname='HomeCity',shortname='HOMECITY'):Iff([SICCode],'',[City])",
		"HomeState(longname='HomeState',shortname='HOMESTATE'):Iff([SICCode],'',[StateAbbr])",
		"HomePostalCode(longname='HomePostalCode',shortname='HOMEPOSTAL'):Iff([SICCode],'',HyphenateZIP(Left([ZIP],9)))",
		"BusinessPhone(longname='BusinessPhone',shortname='BUSINESSPH'):Iff([SICCode],HyphenatePhone([ACPhone]),'')",
		"HomePhone(longname='HomePhone',shortname='HOMEPHONE'):Iff([SICCode],'',HyphenatePhone([ACPhone]))",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMymaillistDft =
{
	"Mymaillist", exportDefMymaillist,
	&idExportDefMymaillist,
	_T("MyMailList"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefWordPerfectMailMergeDft =
{
	"WordPerfectMailMerge", exportDefWordPerfectMailMerge,
	&idExportDefWordPerfectMailMerge,
	_T("Word Perfect Mail Merge"),
	_T(""),
	"DAT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefExcelDft =
{
	"Excel", exportDefExcel,
	&idExportDefExcel,
	_T("Excel"),
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Busres(longname='Busres',shortname='BUSRES'):Iff([SICCode],'B','R')",
		"SicCode(longname='SicCode',shortname='SICCODE'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft exportDefLotus123Dft =
{
	"Lotus123", exportDefLotus123,
	&idExportDefLotus123,
	_T("Lotus 123"),
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefWinfaxPro70Dft =
{
	"WinfaxPro70", exportDefWinfaxPro70,
	&idExportDefWinfaxPro70,
	_T("WinFax Pro 7.0"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Business(longname='Business',shortname='BUSINESS'):Iff([SICCode],[Name],'')",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"AreaCode(longname='AreaCode',shortname='AREACODE'):Left([ACPhone],3)",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone(Mid([ACPhone],3,7))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		"PlaceHolder(longname='PlaceHolder',shortname='PlaceHolder'):''",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMailingLabelDft =
{
	"MailingLabel", exportDefMailingLabel,
	&idExportDefMailingLabel,
	_T("Mailing Label"),
	_T(""),
	"TXT",
	"XChgTerminator='\r\n\r\n'",	// want a blank line between records
	szExporterNameTXT,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"Address2(longname='Address2',shortname='ADDRESS2'):MakeLastLine([City],[StateAbbr],HyphenateZIP(Left([ZIP],9)))",
		0	
	}
};

static const CIuExportDefSpecDft exportDefMailingLabelWPhoneDft =
{
	"MailingLabelWPhone", exportDefMailingLabelWPhone,
	&idExportDefMailingLabelWPhone,
	_T("Mailing Label w/Phone"),
	_T(""),
	"TXT",
	"XChgTerminator='\r\n\r\n'",	// want a blank line between records
	szExporterNameTXT,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"Address2(longname='Address2',shortname='ADDRESS2'):MakeLastLine([City],[StateAbbr],HyphenateZIP(Left([ZIP],9)))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};


static const CIuExportDefSpecDft exportDefTabDelimitedDft =
{
	"TabDelimited", exportDefTabDelimited,
	&idExportDefTabDelimited,
	_T("Tab Delimited"),
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Busres(longname='Busres',shortname='BUSRES'):Iff([SICCode],'B','R')",
		"SicCode(longname='SicCode',shortname='SICCODE'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft exportDefCommaDelimitedWHeadersDft =
{
	"CommaDelimitedWHeaders", exportDefCommaDelimitedWHeaders,
	&idExportDefCommaDelimitedWHeaders,
	_T("Comma Delimited w/headers"),
	_T(""),
	"CSV",
	"HasHeader,HeaderNames=Long",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Sic(longname='Sic',shortname='SIC'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft exportDefCommaDelimitedDft =
{
	"CommaDelimited", exportDefCommaDelimited,
	&idExportDefCommaDelimited,
	_T("Comma Delimited"),
	_T(""),
	"CSV",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Busres(longname='Busres',shortname='BUSRES'):Iff([SICCode],'B','R')",
		"SicCode(longname='SicCode',shortname='SICCODE'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft exportDefCommaDelWLatLongDistDft =
{
	"CommaDelWLatLongDist", exportDefCommaDelWLatLongDist,
	&idExportDefCommaDelWLatLongDist,
	_T("Comma Del w/Lat,Long & Dist"),
	_T(""),
	"CSV",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Name(longname='Name',shortname='NAME'):Iff([SICCode],[Name],Iff([FlipNames],FlipName([Name]),[Name]))",
		"Address1(longname='Address1',shortname='ADDRESS1'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"Zip(longname='Zip',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Busres(longname='Busres',shortname='BUSRES'):Iff([SICCode],'B','R')",
		"SicCode(longname='SicCode',shortname='SICCODE'):[SICCode]",
		"Latitude(longname='Latitude',shortname='LATITUDE'):[Latitude]",
		"Longitude(longname='Longitude',shortname='LONGITUDE'):[Longitude]",
		"Distance(longname='Distance',shortname='DISTANCE'):LatLongDistance([GeoCenterLatitude],[GeoCenterLongitude],'',0)",  // distance of record from current geo center in miles, without directionals.
		0	
	}
};

static const CIuExportDefSpecDft exportDefStreets2000InteroperabilityDft =
{
	"Streets2000Interoperability", exportDefStreets2000Interoperability,
	&idExportDefStreets2000Interoperability,
	_T("Streets 2000 Interoperability"),
	_T(""),
	"TXT",
	_T("Encryption=FlipBits, NoSelect, NoMeter"),
	// Executes HKEY_LOCAL_MACHINE\\Software\\InfoUSA\\Mapping\\AppPath
	// 
	szExporterNameFIX,
	exportDefTypeFixed,
	131,
	{
		"Label(Length=30,Offset=0,longname='Label',shortname='Label'):[Name]",
		"Latitude(Length=10,Offset=30,longname='Latitude',shortname='LATITUDE'):[Latitude]",
		"Longitude(Length=10,Offset=40,longname='Longitude',shortname='LONGITUDE'):[Longitude]",
		"Address(Length=30,Offset=50,longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(Length=30,Offset=80,longname='City',shortname='CITY'):[City]",
		"State(Length=2,Offset=110,longname='State',shortname='ST'):[StateAbbr]",
		"ZIP(Length=5,Offset=112,longname='ZIP',shortname='ZIP'):Iff(Len([ZIP])>=5,Left([ZIP],5),'')",
		"ZIP4(Length=4,Offset=117,longname='ZIP4',shortname='ZIP4'):Iff(Len([ZIP])>=9,Mid([ZIP],5,4),'')",
		"AC(Length=3,Offset=121,longname='Area Code',shortname='AC'):Iff(Len([ACPhone])==10,Left([ACPhone],3),'')",
		"Ph3(Length=3,Offset=124,longname='Phone Prefix',shortname='PH3'):Iff(Len([ACPhone])==10,Mid([ACPhone],3,3),'')",
		"Ph4(Length=4,Offset=127,longname='Phone Suffix',shortname='PH4'):Iff(Len([ACPhone])==10,Mid([ACPhone],6,4),'')",
		0	
	}
};

static const CIuExportDefSpecDft exportDefPowerStreetsDft =
{
	"PowerStreets", exportDefPowerStreets,
	&idExportDefPowerStreets,
	_T("Power Streets"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Latitude(longname='Latitude',shortname='LATITUDE'):[Latitude]",
		"Longitude(longname='Longitude',shortname='LONGITUDE'):[Longitude]",
		"Name(longname='Name',shortname='NAME'):[Name]",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='ST'):[StateAbbr]",
		"ZIP(longname='ZIP',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

// same as ExportPowerStreets
static const CIuExportDefSpecDft exportDefBusinessMappingDft =
{
	"BusinessMapping", exportDefBusinessMapping,
	&idExportDefBusinessMapping,
	_T("Business Mapping"),
	_T(""),
	"TXT",
	"",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"Latitude(longname='Latitude',shortname='LATITUDE'):[Latitude]",
		"Longitude(longname='Longitude',shortname='LONGITUDE'):[Longitude]",
		"Name(longname='Name',shortname='NAME'):[Name]",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='ST'):[StateAbbr]",
		"ZIP(longname='ZIP',shortname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefPalmPilot1Dft = // Initial Version
{
	"PalmPilot1", exportDefPalmPilot1,
	&idExportDefPalmPilot1,
#pragma __TODO("Jerry Loos: Future release: options to support 'Filename comes from registry', 'Select iff some registry entry is present'.")
	// NoSelect=!RegistryValueExists("HKEY_LOCAL_MACHINE\\Software\\infoUSA\\Palm Export")
	// Filename=GetRegistryString("HKEY_LOCAL_MACHINE\\Software\\infoUSA\\ExportPath")
	"Palm Pilot",
	_T(""),
	"TXT",
	"",
	szExporterNameTAB,  // tab delimited
	exportDefTypeFixed,
	0,
	{
		"LastName(Longname='LastName'):Iff([SICCode]=='',LastName([Name]),'')",
		"FirstName(Longname='FirstName'):Iff([SICCode]=='',FirstName([Name]),'')",
		"Company(Longname='Company'):Iff([SICCode]!='',[Name],'')",
		"Address(Longname='Address'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(Longname='City'):[City]",
		"State(Longname='State'):[StateAbbr]",
		"ZIP(Longname='ZIP'):HyphenateZIP(Left([ZIP],9))",
		"Phone(Longname='Phone'):HyphenatePhone([ACPhone])",
		"Fax(Longname='Fax'):HyphenatePhone([FaxACPhone])",
		0	
	}
};

static const CIuExportDefSpecDft exportDefELetterDft =
{
	"ELetter", exportDefELetter,
	&idExportDefELetter,
	_T("ELetter"),
	_T(""),
	"CSV",
	"HasHeader,HeaderNames=Long",
	szExporterNameCSV,
	exportDefTypeFixed,
	0,
	{
		"FirstName(longname='FirstName',shortname='FIRSTNAME'):Iff([SICCode],'',FirstName([Name]))",
		"LastName(longname='LastName',shortname='LASTNAME'):Iff([SICCode],'',LastName([Name]))",
		"Company(longname='Company',shortname='COMPANY'):Iff([SICCode],[Name],'')",
		"Address(longname='Address',shortname='ADDRESS'):MakeAddress([PriNo],[Street],[SecNo])",
		"City(longname='City',shortname='CITY'):[City]",
		"State(longname='State',shortname='STATE'):[StateAbbr]",
		"ZipCode(longname='ZipCode',shortname='ZIPCODE'):HyphenateZIP(Left([ZIP],9))",
		"Phone(longname='Phone',shortname='PHONE'):HyphenatePhone([ACPhone])",
		"Sic(longname='Sic',shortname='SIC'):[SICCode]",
		0	
	}
};

static const CIuExportDefSpecDft* apExportDef[] =
{
	&exportDefSingleLineDft,
	&exportDefActDft,
	&exportDefWordproMailMergeDft,
	&exportDefAutomapStreetsDft,
	&exportDefDbaseIiIiiDft,
	&exportDefDesktopManagerDft,
	&exportDefGoldmineDft,
	&exportDefLotusOrganizer21Dft,
	&exportDefMaximizerDft,
	&exportDefMaplinxDft,
	&exportDefMicrosoftWordMailMergeDft,
	&exportDefMicrosoftOutlookDft,
	&exportDefMymaillistDft,
	&exportDefWordPerfectMailMergeDft,
	&exportDefExcelDft,
	&exportDefLotus123Dft,
	&exportDefWinfaxPro70Dft,
	&exportDefMailingLabelDft,
	&exportDefMailingLabelWPhoneDft,
	&exportDefTabDelimitedDft,
	&exportDefCommaDelimitedWHeadersDft,
	&exportDefCommaDelimitedDft,
	&exportDefCommaDelWLatLongDistDft,
	&exportDefStreets2000InteroperabilityDft,
	&exportDefPowerStreetsDft,
	&exportDefBusinessMappingDft,
	&exportDefPalmPilot1Dft,
	&exportDefELetterDft,
};

/////////////////////////////////////////////////////////////////////////////
// CIuExportDefSpecDft

int CIuExportDefSpecDft::Find(LPCTSTR pcszExportDef)
{
	ASSERT(AfxIsValidString(pcszExportDef));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszExportDef, pcszExportDef) == 0)
			return i;
	}
	return -1;
}

int CIuExportDefSpecDft::Find(int iExportDef)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iExportDef == iExportDef)
			return i;
	}
	return -1;
}

const CIuExportDefSpecDft* CIuExportDefSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return apExportDef[iWhich];
}

int CIuExportDefSpecDft::GetCount()
{
	return sizeof(apExportDef) / sizeof(apExportDef[0]);
}
