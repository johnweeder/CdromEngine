#include "StdAfx.h"
//{{Include
#include "AddressStreetNames.h"
#include "Element.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddressStreetNames, CIuAddressStreetNames_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddressStreetNames)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESSSTREETNAMES, CIuAddressStreetNames, CIuAddressStreetNames_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddressStreetNames, IDS_ENGINE_PPG_ADDRESSSTREETNAMES, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl CompareSuffix(LPCTSTR pcszSuffix1, LPCTSTR pcszSuffix2)
{
	// Special case for suffix sort. The ST suffix is considered < all others
	// so that it sorts to the top. This yields a minor compression improvement
	bool fStreet1 = _tcsicmp(pcszSuffix1, "ST") == 0;
	bool fStreet2 = _tcsicmp(pcszSuffix2, "ST") == 0;
	if (fStreet1 && !fStreet2)
		return -1;
	else if (!fStreet1 && fStreet2)
		return 1;
	else if (!fStreet1 && !fStreet2)
	{
		int iResult = _tcsicmp(pcszSuffix1, pcszSuffix2);
		if (iResult != 0)
			return iResult;
	}
	return 0;
}

static int __cdecl SortStreetSuffixCount(const void *elem1, const void *elem2)
{
	const CIuAddressStreetName* pElement1 = *(const CIuAddressStreetName**)elem1;
	const CIuAddressStreetName* pElement2 = *(const CIuAddressStreetName**)elem2;
	int iResult = _tcsicmp(pElement1->m_pcszStreetName, pElement2->m_pcszStreetName);
	if (iResult != 0)
		return iResult;
	iResult = CompareSuffix(pElement1->m_pcszSuffix, pElement2->m_pcszSuffix);
	if (iResult != 0)
		return iResult;
	return pElement2->m_iCount - pElement1->m_iCount;
}

static int __cdecl SortStreetCount(const void *elem1, const void *elem2)
{
	const CIuAddressStreetName* pElement1 = *(const CIuAddressStreetName**)elem1;
	const CIuAddressStreetName* pElement2 = *(const CIuAddressStreetName**)elem2;
	int iResult = _tcsicmp(pElement1->m_pcszStreetName, pElement2->m_pcszStreetName);
	if (iResult != 0)
		return iResult;
	// Streets with duplicate suffixes not allowed
	ASSERT(_tcsicmp(pElement1->m_pcszSuffix, pElement2->m_pcszSuffix) != 0);
	return pElement2->m_iCount - pElement1->m_iCount;
}

static int __cdecl SortCount(const void *elem1, const void *elem2)
{
	const CIuAddressStreetName* pElement1 = *(const CIuAddressStreetName**)elem1;
	const CIuAddressStreetName* pElement2 = *(const CIuAddressStreetName**)elem2;
	return pElement2->m_iCount - pElement1->m_iCount;
}

CIuAddressStreetNames::CIuAddressStreetNames() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddressStreetNames::~CIuAddressStreetNames()
{
	Empty();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuElement* CIuAddressStreetNames::Add(LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir)
{
	m_sAdd = pcszStreetName;
	m_sAdd += _T("\t");
	m_sAdd += pcszSuffix;
	m_sAdd += _T("\t");
	m_sAdd += pcszPreDir;
	m_sAdd += _T("\t");
	m_sAdd += pcszPostDir;
	return CIuAddressStreetNames_super::Add(m_sAdd);
}

void CIuAddressStreetNames::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

void CIuAddressStreetNames::Empty()
{
	CIuAddressStreetNames_super::Empty();
	m_ArrayData.RemoveAll();
	m_pArraySorted.RemoveAll();
	m_HeapData.Empty();
}

CIuAddressStreetName* CIuAddressStreetNames::GetSorted(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetSortedCount());
	return m_pArraySorted.GetAt(iWhich);
}

int CIuAddressStreetNames::GetSortedCount() const
{
	return m_pArraySorted.GetSize();
}

void CIuAddressStreetNames::Sort()
{
	// Empty current
	m_pArraySorted.RemoveAll();
	m_ArrayData.RemoveAll();
	m_HeapData.Empty();
	if (GetCount() == 0)
		return ;

	// Build sortable array
	m_ArrayData.SetSize(GetCount());
	int iArray = 0;
	int iHashSize = m_ElementMap.GetSize();
	for (int iHash = 0; iHash < iHashSize; ++iHash)
	{
		CIuElement* pElement = m_ElementMap.GetAt(iHash);
		while (pElement)
		{
			CIuAddressStreetName Street;

			LPCTSTR pcszStreet = pElement->GetName();

			const int iMaxStreet = 1024;
			int iStreet = _tcslen(pcszStreet) + 1;
			TCHAR szStreet[iMaxStreet];
			if (iStreet <= iMaxStreet)
				_tcscpy(szStreet, pcszStreet);
			else
			{
				ASSERT(iStreet <= iMaxStreet);
				memcpy(szStreet, pcszStreet, sizeof(szStreet));
				szStreet[sizeof(szStreet) - 1] = '\0';
			}

			Street.m_iCount = pElement->GetCount();

			char* psz = szStreet;
			ASSERT(psz);
			LPCTSTR pcszStreetName = psz;
			while (*psz != '\t' && *psz != '\0')
				++psz;
			*psz++ = '\0';
			Street.m_pcszStreetName = m_HeapData.Add(pcszStreetName);

			LPCTSTR pcszSuffix = psz;
			while (*psz != '\t' && *psz != '\0')
				++psz;
			*psz++ = '\0';
			Street.m_pcszSuffix = m_HeapData.Add(pcszSuffix);

			LPCTSTR pcszPreDir = psz;
			while (*psz != '\t' && *psz != '\0')
				++psz;
			*psz++ = '\0';
			Street.m_pcszPreDir = m_HeapData.Add(pcszPreDir);

			Street.m_pcszPostDir = m_HeapData.Add(psz);

			m_ArrayData.SetAt(iArray, Street);

			++iArray;
			pElement = pElement->GetNext();
			ASSERT(iArray <= GetCount());
		}
	}
	ASSERT(iArray == GetCount());

	// Build pointer array
	m_pArraySorted.SetSize(GetCount());
	for (int i = 0; i < m_ArrayData.GetSize(); ++i)
	{
		CIuAddressStreetName* pStreet = &m_ArrayData.ElementAt(i);
		m_pArraySorted.SetAt(i, pStreet);
	}

	// Sort
	qsort(m_pArraySorted.GetData(), m_pArraySorted.GetSize(), sizeof(CIuAddressStreetName*), SortStreetSuffixCount);

	// Combine all common streets/suffixes
	for (i = 0; i < m_pArraySorted.GetSize(); )
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		++i;
		int iRemove = 0;
		for (int j = i; j < m_pArraySorted.GetSize(); ++j)
		{
			CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(j);
			
			int iResult = _tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName);
			ASSERT(iResult <= 0);
			if (iResult != 0)
				break;
			ASSERT(CompareSuffix(pStreet1->m_pcszSuffix, pStreet2->m_pcszSuffix) <= 0);
			iResult = _tcsicmp(pStreet1->m_pcszSuffix, pStreet2->m_pcszSuffix);
			if (iResult != 0)
				break;

			pStreet1->m_iCount += pStreet2->m_iCount;
			++iRemove;
		}
		if (iRemove > 0)
		{
#ifdef _DEBUG
			{
				for (int k = i; k < i + iRemove; ++k)
				{
					CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(k);
					ASSERT(_tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName) == 0);
					ASSERT(_tcsicmp(pStreet1->m_pcszSuffix, pStreet2->m_pcszSuffix) == 0);
				}
			}
#endif
			m_pArraySorted.RemoveAt(i, iRemove);
#ifdef _DEBUG
			{
				if (i < m_pArraySorted.GetSize())
				{
					CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(i);
					ASSERT(_tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName) != 0 || _tcsicmp(pStreet1->m_pcszSuffix, pStreet2->m_pcszSuffix) != 0);
				}
			}
#endif
			
		}
	}

#ifdef _DEBUG
	for (i = 0; i < m_pArraySorted.GetSize() - 1; ++i)
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(i + 1);
		ASSERT(_tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName) != 0 || _tcsicmp(pStreet1->m_pcszSuffix, pStreet2->m_pcszSuffix) != 0);
	}
#endif

	// Sort again
	qsort(m_pArraySorted.GetData(), m_pArraySorted.GetSize(), sizeof(CIuAddressStreetName*), SortStreetCount);

	// Combine all common streets except those which have more than a threshhold count
#ifdef _DEBUG
	const int iThreshHoldSeparate = 25;
#else
	const int iThreshHoldSeparate = 500;
#endif
	for (i = 0; i < m_pArraySorted.GetSize(); )
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		++i;
		int iRemoveAt = i;
		int iRemove = 0;
		for (int j = i; j < m_pArraySorted.GetSize(); )
		{
			CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(j);
			
			int iResult = _tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName);
			if (iResult != 0)
				break;

			if (pStreet2->m_iCount >= iThreshHoldSeparate)
			{
				if (iRemove > 0)
				{
#ifdef _DEBUG
					{
						for (int k = iRemoveAt; k < iRemoveAt + iRemove; ++k)
						{
							CIuAddressStreetName* pStreet = m_pArraySorted.ElementAt(k);
							ASSERT(pStreet->m_iCount < iThreshHoldSeparate);
						}
					}
#endif
					m_pArraySorted.RemoveAt(iRemoveAt, iRemove);
				}
				++i;
				j = i;
				iRemoveAt = i;
				iRemove = 0;
				continue;
			}

			pStreet1->m_iCount += pStreet2->m_iCount;
			++iRemove;
			++j;
		}
		if (iRemove > 0)
		{
#ifdef _DEBUG
			{
				for (int k = iRemoveAt; k < iRemoveAt + iRemove; ++k)
				{
					CIuAddressStreetName* pStreet = m_pArraySorted.ElementAt(k);
					ASSERT(pStreet->m_iCount < iThreshHoldSeparate);
				}
			}
#endif
			m_pArraySorted.RemoveAt(iRemoveAt, iRemove);		
		}
	}

#ifdef _DEBUG
	for (i = 0; i < m_pArraySorted.GetSize() - 1; ++i)
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(i + 1);
		if (_tcsicmp(pStreet1->m_pcszStreetName, pStreet2->m_pcszStreetName) != 0)
			continue;
		ASSERT(pStreet2->m_iCount >= iThreshHoldSeparate);
	}
#endif

	// Remove all having less than the minimum occurances
	// Start from end of array
	const int iThreshHoldRemove = 5;
	for (i = m_pArraySorted.GetSize() - 1; i >= 0; --i)
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		if (pStreet1->m_iCount < iThreshHoldRemove)
		{
			int iCount = 1;
			while (i > 0)
			{
				CIuAddressStreetName* pStreet2 = m_pArraySorted.ElementAt(i - 1);
				if (pStreet2->m_iCount < iThreshHoldRemove)
				{
					--i;
					++iCount;
				}
				else
					break;
			}
#ifdef _DEBUG
		{
			for (int j = i; j < i + iCount; ++j)
			{
				CIuAddressStreetName* pStreet = m_pArraySorted.ElementAt(j);
				ASSERT(pStreet->m_iCount < iThreshHoldRemove);
			}
		}
#endif
			m_pArraySorted.RemoveAt(i, iCount);
		}
	}

#ifdef _DEBUG
	for (i = 0; i < m_pArraySorted.GetSize() - 1; ++i)
	{
		CIuAddressStreetName* pStreet1 = m_pArraySorted.ElementAt(i);
		ASSERT(pStreet1->m_iCount >= iThreshHoldRemove);
	}
#endif

	// Sort one last time by count
	qsort(m_pArraySorted.GetData(), m_pArraySorted.GetSize(), sizeof(CIuAddressStreetName*), SortCount);
}
