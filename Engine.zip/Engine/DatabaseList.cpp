#include "stdafx.h"
//{{Include
#include "engine.h"
#include "DatabaseList.h"
#include "Databases.h"
#include "Queries.h"
#include "Query.h"
#include "Index.h"
#include "Indexes.h"
#include "RecordDef.h"
#include "DatabaseSelectDlg.h"
#include "resource.h"
#include "resource.h"
#include "Data\Output.h"
#include "Common\SortedStringArray.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IU_IMPLEMENT_OBJECT_PTR(CIuDatabaseList)
IMPLEMENT_DYNCREATE(CIuDatabaseList, CIuDatabaseList_super)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_DATABASELIST, CIuDatabaseList, CIuDatabaseList_super)
//{{AttributeMap
	IU_ATTRIBUTE_ACTION(CIuDatabaseList, IDS_ENGINE_ACTION_SELECTDLG, ActionSelectDlg, 0)

	IU_ATTRIBUTE_PAGE(CIuDatabaseList, IDS_ENGINE_PPG_DATABASELIST, 50, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER_ARRAY(CIuDatabaseList, IDS_ENGINE_PROP_DATABASES, GetDatabases, SetDatabases, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER_ARRAY(CIuDatabaseList, IDS_ENGINE_PROP_DATABASES, IDS_ENGINE_PPG_DATABASELIST, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_EDITOR_ALLOWED_VALUES(CIuDatabaseList, IDS_ENGINE_PROP_DATABASES, GetDatabasesAllowed, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuDatabaseList, IDS_ENGINE_PROP_SEARCHALL, SearchAll, SetSearchAll, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuDatabaseList, IDS_ENGINE_PROP_SEARCHALL, IDS_ENGINE_PPG_DATABASELIST, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuDatabaseList, IDS_ENGINE_PROP_SHOWQUERIES, ShowQueries, SetShowQueries, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuDatabaseList, IDS_ENGINE_PROP_SHOWQUERIES, IDS_ENGINE_PPG_DATABASELIST, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()
//}}Implement

CIuDatabaseList::CIuDatabaseList()
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuDatabaseList::~CIuDatabaseList()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuDatabaseList::ActionSelectDlg(const CIuPropertyCollection&, CIuOutput& Output)
{
	if (!SelectDlg(0, Output.GetParentWnd()))
		return CString("Cancelled");
	return CString("Success");
}

int CIuDatabaseList::Add(LPCTSTR Name, int Before) 
{
	return AddDatabase(Name, Before);
}

int CIuDatabaseList::AddDatabase(const CIuMoniker& moniker, int iBefore) 
{
	int iCount = GetDatabaseCount();
	if (iBefore < 0 || iBefore >= iCount)
		return m_amonikerDatabases.Add(moniker);

	m_amonikerDatabases.InsertAt(iBefore, moniker);
	return iBefore;
}

void CIuDatabaseList::Clear()
{
	CIuDatabaseList_super::Clear();
	CIuDatabaseList::CommonConstruct();
}

void CIuDatabaseList::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("DatabaseList");
	m_fSearchAll = false;
	m_fShowQueries = false;
	m_amonikerDatabases.RemoveAll();
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuDatabaseList::GetDatabasesAllowed(CStringArray& as) const
{
	if (HasEngine())
	{
		as.RemoveAll();

		CStringArray asDatabases;
		GetEngine().GetDatabases().GetCollectionNames(asDatabases);
		as.Append(asDatabases);

		if (ShowQueries())
		{
			CStringArray asQueries;
			GetEngine().GetQueries().GetCollectionNames(asQueries);
			as.Append(asQueries);
		}
	}
}

CIuID CIuDatabaseList::GetDatabaseID(int iIndex) const
{
	return GetDatabase(iIndex).GetID();
}

CString CIuDatabaseList::GetDatabaseName(int iIndex) const
{
	return GetDatabase(iIndex).GetName();
}

CIuDatabasePtr CIuDatabaseList::GetDatabasePtr(int iWhich) const
{
	CIuMoniker Moniker = GetDatabase(iWhich);
	int iIndex = GetEngine().GetDatabases().Find(Moniker);
	if (iIndex < 0)
		return CIuDatabasePtr();
	return CIuDatabasePtr(&GetEngine().GetDatabases().Get(iIndex));
}

void CIuDatabaseList::GetDatabases(CIuMonikerArray& amoniker) const
{
	amoniker.Copy(m_amonikerDatabases);
}

void CIuDatabaseList::GetFields(CStringArray& as) const
{
	CIuSortedStringArray ssa;
	ssa.SetNoCase(true);
	ssa.SetDedup(true);

	int iDatabases = GetDatabaseCount();
	for (int iDatabase = 0; iDatabase < iDatabases; ++iDatabase)
	{
		if (IsQuery(iDatabase))
		{
			CIuQueryPtr pQuery = GetQueryPtr(iDatabase);
			CStringArray asFields;
			pQuery->GetRecordSet().GetRecordDef()->GetFieldDefs().GetCollectionNames(asFields);
			ssa.Add(asFields);
		}
		else
		{
			CIuDatabasePtr pDatabase = GetDatabasePtr(iDatabase);
			int iIndexes = pDatabase->GetIndexes().GetCount();
			for (int iIndex = 0; iIndex < iIndexes; ++iIndex)
			{
				CIuIndex& Index = pDatabase->GetIndexes().Get(iIndex);

				CStringArray asFields;
				Index.GetRecordDef().GetFieldDefs().GetCollectionNames(asFields);
				ssa.Add(asFields);
			}
		}
	}

	as.Copy(ssa);
}

void CIuDatabaseList::GetIndexes(CStringArray& as) const
{
	CIuSortedStringArray ssa;
	ssa.SetNoCase(true);
	ssa.SetDedup(true);

	int iDatabases = GetDatabaseCount();
	for (int iDatabase = 0; iDatabase < iDatabases; ++iDatabase)
	{
		if (IsQuery(iDatabase))
			continue;

		CIuDatabasePtr pDatabase = GetDatabasePtr(iDatabase);
		int iIndexes = pDatabase->GetIndexes().GetCount();
		for (int iIndex = 0; iIndex < iIndexes; ++iIndex)
		{
			CIuMoniker Moniker = pDatabase->GetIndexes().Get(iIndex).GetMoniker();
			ssa.Add(Moniker.AsString());
		}
	}

	as.Copy(ssa);
}

CIuQueryPtr CIuDatabaseList::GetQueryPtr(int iWhich) const
{
	CIuMoniker Moniker = GetDatabase(iWhich);
	int iIndex = GetEngine().GetQueries().Find(Moniker);
	if (iIndex < 0)
		return CIuQueryPtr();
	return CIuQueryPtr(&GetEngine().GetQueries().Get(iIndex));
}

bool CIuDatabaseList::IsEmpty() const
{
	return GetDatabaseCount() == 0;
}

bool CIuDatabaseList::IsQuery(int iWhich) const
{
	CIuMoniker Moniker = GetDatabase(iWhich);
	int iIndex = GetEngine().GetQueries().Find(Moniker);
	return iIndex >= 0;
}

void CIuDatabaseList::Remove(int iIndex)
{
	ASSERT(iIndex >= 0 && iIndex < GetDatabaseCount());
	RemoveDatabase(iIndex);
}

void CIuDatabaseList::RemoveAll()
{																				   
	RemoveAllDatabases();
}

void CIuDatabaseList::RemoveAllDatabases()
{
	m_amonikerDatabases.RemoveAll();
}

void CIuDatabaseList::RemoveDatabase(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetDatabaseCount());
	m_amonikerDatabases.RemoveAt(iWhich);
}

bool CIuDatabaseList::SelectDlg(int iFlags, CWnd* pParent)
{
	return CIuDatabaseSelectDlg::SelectDlg(*this, iFlags, 0, pParent);
}

bool CIuDatabaseList::SelectDlg(int iFlags, LPCTSTR pcszApplication, CWnd* pParent)
{
	return CIuDatabaseSelectDlg::SelectDlg(*this, iFlags, pcszApplication, pParent);
}

void CIuDatabaseList::SetDatabase(int iWhich, const CIuMoniker& moniker)
{
	ASSERT(iWhich >= 0);
	m_amonikerDatabases.SetAtGrow(iWhich, moniker);
}

void CIuDatabaseList::SetDatabases(const CIuMonikerArray& amoniker)
{
	m_amonikerDatabases.Copy(amoniker);
}

void CIuDatabaseList::SetSearchAll(bool f)
{
	m_fSearchAll = f;
}

void CIuDatabaseList::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuDatabaseList::SetShowQueries(bool f)
{
	m_fShowQueries = f;
}

