#ifndef _ENGINE_CDROMINPUT_H_
#define _ENGINE_CDROMINPUT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdromInput)
IU_DEFINE_OBJECT_PTR(CIuInputResidential)
IU_DEFINE_OBJECT_PTR(CIuInputBusiness)
IU_DEFINE_OBJECT_PTR(CIuInputSample)
IU_DEFINE_OBJECT_PTR(CIuGeoScan)
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
IU_DEFINE_OBJECT_PTR(CIuRecordSort)
IU_DEFINE_OBJECT_PTR(CIuTokenScans)
IU_DEFINE_OBJECT_PTR(CIuSicScan)
IU_DEFINE_OBJECT_PTR(CIuAddressScan)
IU_DEFINE_OBJECT_PTR(CIuCdromStrips)
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromInput, CIuObjectNamed }}
#define CIuCdromInput_super CIuObjectNamed

class CIuCdromInput : public CIuCdromInput_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromInput)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromInput();
	virtual ~CIuCdromInput();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddressScan& GetAddressScan() const;
	CString GetFilename() const;
	CIuGeoScan& GetGeoScan() const;
	CIuCdromStrips& GetIndexes() const;
	CIuInputBusiness& GetInputBusiness() const;
	CIuInputResidential& GetInputResidential() const;
	CIuInputSample& GetInputSample() const;
	CIuRecordFile& GetRecords() const;
	CIuSicScan& GetSicScan() const;
	CIuRecordSort& GetSort() const;
	CString GetState(int) const;
	int GetStateCount() const;
	void GetStates(CStringArray& as) const;
	CIuTokenScans& GetTokenScans() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasAddress() const;
	bool HasData() const;
	bool HasGeo() const;
	bool HasSic() const;
	bool IncludeBusiness() const;
	bool IncludeResidential() const;
	bool IncludeSample() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Delete(CIuOutput* pOutput = 0);
	void RemoveAllStates();
	void SetFilename(LPCTSTR);
	void SetHasAddress(bool);
	void SetHasGeo(bool);
	void SetHasSic(bool);
	void SetIncludeBusiness(bool = true);
	void SetIncludeResidential(bool = true);
	void SetIncludeSample(bool = true);
	void SetSpec(CIuCdromSpec& Spec);
	void SetStates(const CStringArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetAddressScan_() const;
	CIuObject* GetGeoScan_() const;
	CIuObject* GetIndexes_() const;
	CIuObject* GetInputBusiness_() const;
	CIuObject* GetInputResidential_() const;
	CIuObject* GetInputSample_() const;
	CIuObject* GetRecords_() const;
	CIuObject* GetSicScan_() const;
	CIuObject* GetSort_() const;
	CIuObject* GetTokenScans_() const;
private:
	bool BuildInput(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fIncludeBusiness;
	bool m_fIncludeResidential;
	bool m_fIncludeSample;
	CIuInputResidentialPtr m_pInputResidential;
	CIuInputBusinessPtr m_pInputBusiness;
	CIuInputSamplePtr m_pInputSample;
	CIuGeoScanPtr m_pGeoScan;
	CIuRecordFilePtr m_pRecords;
	CIuRecordSortPtr m_pSort;
	CIuTokenScansPtr m_pTokenScans;
	CIuSicScanPtr m_pSicScan;
	CIuAddressScanPtr m_pAddressScan;
	CIuCdromStripsPtr m_pIndexes;
	CStringArray m_asStates;
	bool m_fHasGeo;
	bool m_fHasSic;
	bool m_fHasAddress;
	CString m_sFilename;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddressScan& CIuCdromInput::GetAddressScan() const
{
	return m_pAddressScan.Ref();
}

inline CString CIuCdromInput::GetFilename() const
{
	return m_sFilename;
}

inline CIuGeoScan& CIuCdromInput::GetGeoScan() const
{
	return m_pGeoScan.Ref();
}

inline CIuCdromStrips& CIuCdromInput::GetIndexes() const
{
	return m_pIndexes.Ref();
}

inline CIuInputBusiness& CIuCdromInput::GetInputBusiness() const
{
	return m_pInputBusiness.Ref();
}

inline CIuInputResidential& CIuCdromInput::GetInputResidential() const
{
	return m_pInputResidential.Ref();
}

inline CIuInputSample& CIuCdromInput::GetInputSample() const
{
	return m_pInputSample.Ref();
}

inline CIuRecordFile& CIuCdromInput::GetRecords() const
{
	return m_pRecords.Ref();
}

inline CIuSicScan& CIuCdromInput::GetSicScan() const
{
	return m_pSicScan.Ref();
}

inline CIuRecordSort& CIuCdromInput::GetSort() const
{
	return m_pSort.Ref();
}

inline CString CIuCdromInput::GetState(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetStateCount());
	return m_asStates[iWhich];
}

inline int CIuCdromInput::GetStateCount() const
{
	return m_asStates.GetSize();
}

inline CIuTokenScans& CIuCdromInput::GetTokenScans() const
{
	return m_pTokenScans.Ref();
}

inline bool CIuCdromInput::HasAddress() const
{
	return m_fHasAddress;
}

inline bool CIuCdromInput::HasData() const
{
	return IncludeBusiness() || IncludeResidential() || IncludeSample();
}

inline bool CIuCdromInput::HasGeo() const
{
	return m_fHasGeo;
}

inline bool CIuCdromInput::HasSic() const
{
	return m_fHasSic;
}

inline bool CIuCdromInput::IncludeBusiness() const
{
	return m_fIncludeBusiness;
}

inline bool CIuCdromInput::IncludeResidential() const
{
	return m_fIncludeResidential;
}

inline bool CIuCdromInput::IncludeSample() const
{
	return m_fIncludeSample;
}

#endif // _ENGINE_CDROMINPUT_H_
