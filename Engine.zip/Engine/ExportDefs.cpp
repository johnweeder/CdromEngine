#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "resource.h"
#include "ExportDefs.h"
#include "CdromSpec.h"
#include "Exporter.h"
#include "Exporters.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportDefs, CIuExportDefs_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportDefs)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTDEFS, CIuExportDefs, CIuExportDefs_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuExportDefs, IDS_ENGINE_PPG_EXPORTDEFS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuExportDefs, IDS_ENGINE_PPG_EXPORTDEFS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuExportDefs::CIuExportDefs()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportDefs::~CIuExportDefs()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuExportDefs::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int i = 0; i < GetCount(); ++i)
		if (!Get(i).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuExportDefs::CommonConstruct()
{
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuExportDefs::Create(CIuExportDefSpec& ExportDefSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuExportDef& ExportDef = Get(iIndex);
	ExportDef.SetSpec(ExportDefSpec);
}

CIuEngine& CIuExportDefs::GetEngine() const
{
	return *m_pEngine;
}

void CIuExportDefs::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuExportDefPtr pExportDef = dynamic_cast<CIuExportDef*>(pCollectable.Ptr());
	GetEngine().QueryObject(collectionExportDefs, Descriptor, *pExportDef);
}

CIuCollectablePtr CIuExportDefs::OnNew(CWnd*) const
{
	CIuExportDefPtr pExportDef;
	pExportDef.Create();
	return pExportDef;
}

void CIuExportDefs::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the engine
	m_pEngine = &Engine;
}

void CIuExportDefs::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iExportDef = 0; iExportDef < Spec.GetExportDefCount(); ++iExportDef)
		Create(Spec.GetExportDef(iExportDef));  	
}
