#include "StdAfx.h"
//{{Include
#include "ExpressionBinary.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionBinary::CIuExpressionBinary(CIuExpressionType Type) : CIuExpressionElement(Type)
{
	SetFormat(exprFormatInt);
}

CIuExpressionBinary::CIuExpressionBinary(const CIuExpressionBinary& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionBinary::~CIuExpressionBinary()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionBinary::Clone() const
{
	CIuExpressionBinary* pElement = new CIuExpressionBinary(*this);
	ASSERT(pElement);
	return pElement;
} 

bool CIuExpressionBinary::EvaluateBool(const CIuRecord* pRecord) const
{
	return EvaluateInt(pRecord) != 0;
}

int CIuExpressionBinary::EvaluateInt(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() >= 2);
	ASSERT(
		GetType() == exprDivide ||
		GetType() == exprMultiply ||
		GetType() == exprMinus ||
		GetType() == exprPlus
		);

	int iAccumulator = EvaluateChildInt(0, pRecord);
	for (int iChild = 1; iChild < GetChildCount(); ++iChild)
	{
		int iNext = EvaluateChildInt(iChild, pRecord);
		switch (GetType())
		{
			case exprDivide:
				if (iNext != 0)
					iAccumulator /= iNext;
				else
					iAccumulator = 0;
				break;
			case exprMultiply:
				iAccumulator *= iNext;
				break;
			case exprMinus:
				iAccumulator -= iNext;
				break;
			case exprPlus:
				iAccumulator += iNext;
				break;
			default:
				ASSERT(false);
		}
	}
	return iAccumulator;
}

int CIuExpressionBinary::GetMaxLength() const
{
	return NumericMaxLength();
}

LPCTSTR CIuExpressionBinary::GetTypeName() const
{
	switch (GetType())
	{
		case exprBinary:
			return "#Binary Operator#";
		case exprDivide:
			return "/";
		case exprMultiply:
			return "*";
		case exprMinus:
			return "-";
		case exprPlus:
			return "+";
	}
	return CIuExpressionBinary_super::GetTypeName();
}

bool CIuExpressionBinary::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprBinary || CIuExpressionBinary_super::IsKindOf(Type);
}

CIuExpressionBinary& CIuExpressionBinary::operator=(const CIuExpressionBinary& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionBinary_super::operator=(rExpressionElement);
	return *this;
}
