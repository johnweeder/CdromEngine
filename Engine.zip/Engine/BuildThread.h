#ifndef _ENGINE_BUILDTHREAD_H_
#define _ENGINE_BUILDTHREAD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_EVENTTHREAD_H_
#	include "Data\EventThread.h"
#endif	// _DATA_EVENTTHREAD_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBuildThread, CIuEventThread }}
#define CIuBuildThread_super CIuEventThread

class CIuBuildThread : public CIuBuildThread_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuBuildThread)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static CIuBuildThread* Start(bool fPaused = false);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnEvent();
//}}Overrides
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BUILDTHREAD_H_