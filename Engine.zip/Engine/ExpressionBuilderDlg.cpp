#include "stdafx.h"
#include "ExpressionBuilderDlg.h"
#include "Ui\ListBox.h"
#include "ExpressionFunction.h"
#include "ExpressionElement.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuExpressionBuilderDlg, CDialog)
	//{{AFX_MSG_MAP(CIuExpressionBuilderDlg)
	ON_LBN_DBLCLK(IDC_ENGINE_FIELDS, OnDblclkFields)
	ON_LBN_DBLCLK(IDC_ENGINE_FUNCTIONS, OnDblclkFunctions)
	ON_LBN_DBLCLK(IDC_ENGINE_OPERATORS, OnDblclkOperators)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuExpressionBuilderDlg::CIuExpressionBuilderDlg(CWnd* pParent /*=NULL*/) : CIuExpressionBuilderDlg_super(CIuExpressionBuilderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuExpressionBuilderDlg)
	m_sExpression = _T("");
	//}}AFX_DATA_INIT
}

void CIuExpressionBuilderDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuExpressionBuilderDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuExpressionBuilderDlg)
	DDX_Control(pDX, IDC_ENGINE_OPERATORS, m_ibOperators);
	DDX_Control(pDX, IDC_ENGINE_FUNCTIONS, m_ibFunctions);
	DDX_Control(pDX, IDC_ENGINE_FIELDS, m_ibFields);
	DDX_Control(pDX, IDC_ENGINE_EXPRESSION, m_editExpression);
	DDX_Text(pDX, IDC_ENGINE_EXPRESSION, m_sExpression);
	//}}AFX_DATA_MAP
}

bool CIuExpressionBuilderDlg::Edit(CString& sExpression, CStringArray& asFields, CWnd* pParent)
{
	CIuExpressionBuilderDlg dlg(pParent);
	dlg.m_sExpression = sExpression;
	dlg.m_asFields.Copy(asFields);
	if (dlg.DoModal() != IDOK)
		return false;
	sExpression = dlg.m_sExpression;
	return true;
}

void CIuExpressionBuilderDlg::OnDblclk(CListBox& lb)
{
	int iCurSel = lb.GetCurSel();
	if (iCurSel == LB_ERR)
		return ;
	CString sText;
	lb.GetText(iCurSel, sText);
	m_editExpression.ReplaceSel(sText, true);
}

void CIuExpressionBuilderDlg::OnDblclkFields()
{
	OnDblclk(m_ibFields);
}

void CIuExpressionBuilderDlg::OnDblclkFunctions() 
{
	OnDblclk(m_ibFunctions);
}

void CIuExpressionBuilderDlg::OnDblclkOperators() 
{
	OnDblclk(m_ibOperators);
}

BOOL CIuExpressionBuilderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_LayoutManager.Attach(this);

	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_BOTTOM,	OX_LMT_SAME, -iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_RIGHT,	OX_LMT_OPPOSITE, -iWindowMargin, IDCANCEL);
	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_BOTTOM,	OX_LMT_SAME, -iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_EXPRESSION,	OX_LMS_TOP,		OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_EXPRESSION,	OX_LMS_LEFT,	OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_EXPRESSION,	OX_LMS_RIGHT,	OX_LMT_OPPOSITE, -iWindowMargin, IDC_ENGINE_FIELDS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_EXPRESSION,	OX_LMS_BOTTOM,	OX_LMT_OPPOSITE, -iWindowMargin, IDOK);

	m_LayoutManager.SetConstraint(IDC_ENGINE_FIELDS,		OX_LMS_TOP,		OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_FIELDS,		OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_OPERATORS,	OX_LMS_TOP,		OX_LMT_OPPOSITE, iWindowMargin, IDC_ENGINE_FIELDS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_OPERATORS,	OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_FUNCTIONS,	OX_LMS_TOP,		OX_LMT_OPPOSITE, iWindowMargin, IDC_ENGINE_OPERATORS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_FUNCTIONS,	OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_FUNCTIONS,	OX_LMS_BOTTOM,	OX_LMT_OPPOSITE, -iWindowMargin, IDOK);

	// Set the minimum size of the window
	m_LayoutManager.SetMinMax(IDC_ENGINE_EXPRESSION, CSize(200,50));
	
	// Draw the layout with the new constraints
	// This is necessary when constraints are implemented and the window must be refreshed
	m_LayoutManager.RedrawLayout();

	int iFields = m_asFields.GetSize();
	for (int iField = 0; iField < iFields; ++iField)
	{
		CString sField = m_asFields[iField];
		if (!sField.IsEmpty() && sField.GetAt(0) != '[')
		{
			CString sNewField = _T("[");
			sNewField += sField;
			sNewField += _T("]");

			m_asFields[iField] = sNewField;
		}
	}

	LBLoad(m_ibFields, m_asFields);

	CStringArray asFunctions;
	CIuExpressionFunction::GetFunctionNames(asFunctions, true);
	LBLoad(m_ibFunctions, asFunctions);

	CStringArray asOperators;
	CIuExpressionElement::GetOperatorNames(asOperators);
	LBLoad(m_ibOperators, asOperators);

	UpdateData(false);

	m_editExpression.SetSel(-1, -1);

	return true;  
}

void CIuExpressionBuilderDlg::OnOK() 
{
	UpdateData();
	CDialog::OnOK();
}
