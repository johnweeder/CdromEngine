#include "StdAfx.h"
//{{Include
#include "FieldName.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

// Create an field name of length at most iMaxLength
IU_API_EXPORT bool MakeFieldName(CString& sNewName, LPCTSTR pcsz, int iMaxLength, int iTry)
{
	sNewName.Empty();
	if (iMaxLength <= 0 || iTry < 0)
		return false;
	// Remove invalid characters from seed
	CString s;
	for (; *pcsz; ++pcsz)
	{
		if (_istascii(*pcsz) && (s.IsEmpty() ? _istalpha(*pcsz) : _istalnum(*pcsz)))
			s += *pcsz;
	}
	s.MakeUpper();
	if (s.IsEmpty())
	{
		if (iMaxLength < 5)
		{
			// Generate the iTry'th identifier
			int iOrd = iTry % 26;
			s += TCHAR(_T('A') + iOrd);
			iTry /= 26;
			while (iTry)
			{
				iOrd = iTry % 36;
				if (iOrd < 10)
					s += TCHAR(_T('0') + iOrd);
				else 
					s += TCHAR(_T('A') + (iOrd - 10));
				iTry /= 36;
			}
			sNewName = s;
			return s.GetLength() <= iMaxLength;
		}
		// Generate identifier of the form Fnnnn, FLDnnnn or FIELDnnnn
		if (iTry >= 10000)
			return false;
		if (iMaxLength < 7)
			sNewName.Format("F%04d", iTry);
		else if (iMaxLength < 9)
			sNewName.Format("FLD%04d", iTry);
		else
			sNewName.Format("FIELD%04d", iTry);  
		return true;
	}
	// Find length of longest numeric suffix of s.
	int n = s.GetLength();
	int iRight = n - 1;
	int cSuffix = 0;
	ASSERT(n > 0 && _istalpha(s.GetAt(0))); // else loop below fails!
	while (_istdigit(s.GetAt(iRight)))
		--iRight, ++cSuffix;
	if (cSuffix == 0)
	{
		// There is no numeric suffix.
		// Advance alpha-only identifier
		while (iTry)
		{
			for (int i = n-1; i >= 0 && s.GetAt(i) == _T('Z'); --i)
				s.SetAt(i, _T('A'));
			if (i >= 0)
				s.SetAt(i, TCHAR(s.GetAt(i) + 1));
			else if (n < iMaxLength)
			{
				s.Insert(0, _T('A'));
				++n;
				ASSERT(n == s.GetLength());
			}
			else
				break;
			--iTry;
		}
		sNewName = s;
		return iTry == 0;
	}
	// Numeric suffix handling.
	// Try to preserve the first character and the numeric suffix.
	// To do so, advance the interior.  If cannot advance interior
	// any more (would require a change in length), see if
	// there is room.  If there is room, insert an A into the interior,
	// and keep advancing.  When the interior is full, advance the first
	// character and try again.  If that fails, move the left-most digit
	// in the suffix into the interior as an 'A'.
	// 
	while (iTry)
	{
		ASSERT(_istalpha(s[0]));
		ASSERT(n == s.GetLength());
		ASSERT(iRight + cSuffix + 1 == n);
		// Advance interior
		for (int i = iRight; i >= 1 && s.GetAt(i) == _T('Z'); --i)
			s.SetAt(i, _T('A'));
		if (i >= 1)
			s.SetAt(i, TCHAR(s.GetAt(i) + 1));
		else if (n < iMaxLength)
		{
			// Room in the interior for another letter.
			s.Insert(iRight, _T('A'));  // could use s.Insert(1, _T('0')) instead.
			++iRight;
			++n;
		}
		else if (s.GetAt(0) != _T('Z'))
		{
			// Interior is full
			// Advance first letter and try again.
			ASSERT(n == iMaxLength);
			s.SetAt(0, TCHAR(s.GetAt(0) + 1));
			// Set interior to A's
			for (i = 1; i <= iRight; ++i)
				s.SetAt(i, _T('A'));
		}
		else if (cSuffix)
		{
			// Leftmost char is Z, interior is full, and there is 
			// a non-empty numeric suffix (s looks like ZZZZZdigits)
			// So, turn left char, interior and leftmost numeric suffix 
			// digit into an A,  (Z^t digits^u -> A^t+1 digits^u-1)
			--cSuffix;
			++iRight;
			for (i = 0; i <= iRight; ++i)
				s.SetAt(i, _T('A'));
		}
		else 
		{
			// Leftmost char is a Z, interior is full (all Z's)
			// and no more digits remain at the end of the string.
			// i.e. the string is all Z's.  done.
			break;
		}
		--iTry;
	}
	sNewName = s;
	return iTry == 0;
}
