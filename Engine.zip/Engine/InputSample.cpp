#include "StdAfx.h"
//{{Include
#include "InputSample.h"
#include "Error\Error.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputSample, CIuInputSample_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputSample)

enum
{
	sampleName = 0,
	samplePriNo,
	samplePreDir,
	sampleStreetName,
	sampleSuffix,
	samplePostDir,
	sampleSecNo,
	sampleCity,
	sampleStateAbbr,
	sampleZIP,
	sampleBusResFlag,
	sampleSicCode,
	sampleAcPhone,
	sampleLatitude,
	sampleLongitude,
	sampleCrLf,
};
//}}Implement

CIuInputSample::CIuInputSample() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputSample::~CIuInputSample()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputSample::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputSample"));
	m_fIncludeBusiness = true;
	m_fIncludeResidential = true;
	//}}Initialize
}

bool CIuInputSample::OnProcess()
{
	LPCTSTR pcszBusResFlag = GetInput(sampleBusResFlag);
	if (!m_fIncludeBusiness && *pcszBusResFlag == 'B')
		return true;
	if (!m_fIncludeResidential && *pcszBusResFlag == 'R')
		return true;
	ASSERT(*pcszBusResFlag == 'B' || *pcszBusResFlag == 'R');
	SetField(inputFieldBusResFlag, pcszBusResFlag);

	SetField(inputFieldName, GetInput(sampleName));

	MakeAddress(GetInput(samplePriNo), GetInput(samplePreDir), GetInput(sampleStreetName), GetInput(sampleSuffix), GetInput(samplePostDir), GetInput(sampleSecNo), 0, 0);

	SetField(inputFieldCity, GetInput(sampleCity));
	MakeState(GetInput(sampleStateAbbr));
	MakeZip(GetInput(sampleZIP), 0, 0);

	SetField(inputFieldSicCode, GetInput(sampleSicCode));
	SetField(inputFieldAcPhone, GetInput(sampleAcPhone));
	SetField(inputFieldLatitude, GetInput(sampleLatitude));
	SetField(inputFieldLongitude, GetInput(sampleLongitude));

	return Output();
}

void CIuInputSample::SetIncludeBusiness(bool f)
{
	m_fIncludeBusiness = f;
}

void CIuInputSample::SetIncludeResidential(bool f)
{
	m_fIncludeResidential = f;
}

void CIuInputSample::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputSample_super::SetSpec(Spec);
}
