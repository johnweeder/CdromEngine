#ifndef _ENGINE_RECORDDEFSPEC_H_
#define _ENGINE_RECORDDEFSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordDefSpec)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordDefSpec, CIuObjectNamed }}
#define CIuRecordDefSpec_super CIuObjectNamed

class CIuRecordDefSpec : public CIuRecordDefSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuRecordDefSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordDefSpec();
	virtual ~CIuRecordDefSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static int GetCount();
	CIuFieldDefSpec& GetFieldDef(int iFieldDef) const;
	int GetFieldDefCount() const;
	int GetLength() const;
	static void GetNames(CStringArray& as);
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void CreateFieldDef(LPCTSTR pcszFieldDef);
	bool FromIndex(int iSpec);
	bool FromName(LPCTSTR pcszName);
	bool FromNo(int iSpec);
	void RemoveAllFieldDefs();
	void SetLength(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iLength;
	CIuFieldDefSpecArray m_apFieldDefs;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuRecordDefSpec::GetLength() const
{
	return m_iLength;
}

#endif // _ENGINE_RECORDDEFSPEC_H_

