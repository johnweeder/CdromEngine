#include "StdAfx.h"
//{{Include
#include "BTrees.h"
#include "BTree.h"
#include "resource.h"
#include "CdromSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTrees, CIuBTrees_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTrees)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREES, CIuBTrees, CIuBTrees_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTrees, IDS_ENGINE_PPG_BTREES, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuBTrees, IDS_ENGINE_PPG_BTREES, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTrees::CIuBTrees() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTrees::~CIuBTrees()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBTrees::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	int iBTrees = GetCount();
	for (int iBTree = 0; iBTree < iBTrees; ++iBTree)
	{
		if (!Get(iBTree).Build(Cdrom, Output, Flags))
			return false;
	}
	// If compressing, go back and make a sanity check run and expand all the records
	if (Flags.Test(cdromsBuildCompressBTree))
	{
		for (int iBTree = 0; iBTree < iBTrees; ++iBTree)
		{
			if (!Get(iBTree).SanityCheck(Cdrom, Output))
				return false;
		}
	}
	return true;
}

void CIuBTrees::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuBTrees::CreateBTree(CIuBTreeSpec& BTreeSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuBTree& BTree = Get(iIndex);
	BTree.SetSpec(BTreeSpec);
}

CIuCollectablePtr CIuBTrees::OnNew(CWnd*) const
{
	CIuBTreePtr pBTree;
	pBTree.Create();
	return pBTree;
}

void CIuBTrees::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();

	// Create the BTree scans
	for (int iBTree = 0; iBTree < Spec.GetBTreeCount(); ++iBTree)
		CreateBTree(Spec.GetBTree(iBTree));
}
