#include "StdAfx.h"
//{{Include
#include "GeoCity.h"
#include "GeoRawCity.h"
#include "City.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "RegEx.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoCity, CIuGeoCity_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoCity)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOCITY, CIuGeoCity, CIuGeoCity_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoCity::CIuGeoCity() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoCity::~CIuGeoCity()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoCity::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoCity"));
	//}}Initialize
}

void CIuGeoCity::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter = RegEx.CreateLikeClause(_T("City"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoCity::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoCity::GetIndexStatic()
{
	return _T("City");
}

void CIuGeoCity::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoCity);
}

int CIuGeoCity::GetSourceType() const
{
	return sourceGeoCollectionCity;
}

void CIuGeoCity::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoCity::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawCity& City = *dynamic_cast<CIuGeoRawCity*>(&Element);
	ASSERT(&City);

	int iExpandedSize = sizeof(CIuCity);
	ASSERT(iExpandedSize == 12);

	// Store the state/city value
	CString sName = City.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	// Add to allow for split city/state
	if (sName.GetLength() > 2)
		iExpandedSize += sName.GetLength() + 2;
	else
		iExpandedSize += 2;

	// Store the MSA
	City.GetMsa().CompressPreferred(Geo, Buffer, Geo.GetMsaMap());

	iExpandedSize += CIuGeoList::Compress(City.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize;
}

int CIuGeoCity::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuCity* pCity = (CIuCity*)AddElement(sizeof(CIuCity));

	// Decompress the various strings
	CIuStaticBuffer256 BufferStateCity;
	iOffset += CIuNybbleString::Get(BufferStateCity, -1, true, NS_ALPHA, Buffer, iOffset);

	// Fill out the constant data in the process. 
	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pCity->m_iMsaNo = uiVal - 1;

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	LPTSTR pszStateCity = LPTSTR(BufferStateCity.GetPtr());
	AddElementName(pszStateCity);
	if (pszStateCity[0] == '\0' || pszStateCity[1] == '\0')
	{
		AddElementString(_T(""));
		AddElementString(_T(""));
	}
	else
	{
		AddElementString(pszStateCity + 2);
		pszStateCity [2] = '\0';
		AddElementString(pszStateCity);
		
	}
	AddElementStringTerm();

	return iOffset;
}
