#include "StdAfx.h"
//{{Include
#include "AddressCodec.h"
#include "AddressSpec.h"
#include "resource.h"
#include "Common\String.h"
#include "Solicit.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddressCodec, CIuAddressCodec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddressCodec)
enum
{
	addressHighRise,
	addressPostDir,
	addressPreDir,
	addressPriNo,
	addressSecNo,
	addressStreetName,
	addressSuffix,
	addressNoSolicitation,
};

static LPCTSTR apcszDirectionals[] = 
{
	"N",
	"S",
	"E",
	"W",
	"NE",
	"NW",
	"SE",
	"SW",
	"",
	0,
};
const TCHAR CIuAddressCodec::m_szRR[]					= _T("RR");
const TCHAR CIuAddressCodec::m_szHC[]					= _T("HC");
const TCHAR CIuAddressCodec::m_szPOBOX[]				= _T("PO BOX");
const TCHAR CIuAddressCodec::m_szGD[]					= _T("GENERAL DELIVERY");
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESSCODEC, CIuAddressCodec, CIuAddressCodec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddressCodec, IDS_ENGINE_PPG_ADDRESSCODEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressCodec, IDS_ENGINE_PROP_MAP, GetMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuAddressCodec, IDS_ENGINE_PROP_MAP, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAddressCodec::CIuAddressCodec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddressCodec::CIuAddressCodec(const CIuAddressCodec& rAddressCodec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rAddressCodec;
}

CIuAddressCodec::~CIuAddressCodec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}


void CIuAddressCodec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pMap.IsNull())
	{
		m_pMap.Create();
	}
	m_iFlags = 0;
	m_iPreDirNo = dirNone;
	m_iPostDirNo = dirNone;
	m_iStreetNo = 0;
	m_iPriNoNo = 0;
	m_iSecNoNo = 0;
	m_sStreet = "Street";
	//}}Initialize
}

void CIuAddressCodec::Copy(const CIuObject& object)
{
	CIuAddressCodec_super::Copy(object);

	const CIuAddressCodec* pAddressCodec = dynamic_cast<const CIuAddressCodec*>(&object);
	if (pAddressCodec == 0 || pAddressCodec == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuAddressCodec)));
	GetMap() = pAddressCodec->GetMap();
}

int CIuAddressCodec::FindDir(LPCTSTR pcszDir)
{
	if (*pcszDir != '\0')
	{
		for (int i = dirFirst; i < dirMax; ++i)
		{
			ASSERT(apcszDirectionals[i]);
			if (_tcsicmp(pcszDir, apcszDirectionals[i]) == 0)
				return i;
		}
	}
	return dirNone;
}

LPCTSTR CIuAddressCodec::GetDir(int iDir)
{
	ASSERT(iDir >= dirFirst && iDir <= dirNone);
	return apcszDirectionals[iDir];
}

CIuObject* CIuAddressCodec::GetMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pMap.Ptr()));
}

LPCTSTR CIuAddressCodec::GetPostDir() const
{
	return apcszDirectionals[m_iPostDirNo];
}

LPCTSTR CIuAddressCodec::GetPreDir() const
{
	return apcszDirectionals[m_iPreDirNo];
}

CString CIuAddressCodec::GetStreet() const
{
	// Trim up the strings
	if (m_iPreDirNo != dirNone)
	{
		m_sStreet = apcszDirectionals[m_iPreDirNo];
		if (!m_sStreetName.IsEmpty())
		{
			ASSERT(!m_sStreet.IsEmpty());
			m_sStreet += _T(" ");
			m_sStreet += m_sStreetName;
		}
	}
	else
		m_sStreet = m_sStreetName;

	if (!m_sSuffix.IsEmpty())
	{
		if (!m_sStreet.IsEmpty())
			m_sStreet += _T(" ");
		m_sStreet += m_sSuffix;
	}

	if (m_iPostDirNo != dirNone)
	{
		if (!m_sStreet.IsEmpty())
			m_sStreet += _T(" ");
		m_sStreet += apcszDirectionals[m_iPostDirNo];
	}
	return m_sStreet;
}

CIuAddressCodec& CIuAddressCodec::operator=(const CIuAddressCodec& rAddressCodec)
{
	Copy(rAddressCodec);
	return *this;
}

bool CIuAddressCodec::Process(const CIuRecord& Record)
{
	// Perform a mapping to get the fields we need
	m_pRecord.Map(Record, GetMap());

	// Get direct pointers
	LPCTSTR pcszHighRise			= _tcsskipws(m_pRecord->GetField(addressHighRise));
	LPCTSTR pcszPostDir			= _tcsskipws(m_pRecord->GetField(addressPostDir));
	LPCTSTR pcszPreDir			= _tcsskipws(m_pRecord->GetField(addressPreDir));
	LPCTSTR pcszPriNo				= _tcsskipws(m_pRecord->GetField(addressPriNo));
	LPCTSTR pcszSecNo				= _tcsskipws(m_pRecord->GetField(addressSecNo));
	LPCTSTR pcszStreetName		= _tcsskipws(m_pRecord->GetField(addressStreetName));
	LPCTSTR pcszSuffix			= _tcsskipws(m_pRecord->GetField(addressSuffix));
	LPCTSTR pcszNoSolicitation	= _tcsskipws(m_pRecord->GetField(addressNoSolicitation));
	return Process(pcszPriNo, pcszPreDir, pcszStreetName, pcszSuffix, pcszPostDir, pcszSecNo, pcszHighRise, pcszNoSolicitation);
}

bool CIuAddressCodec::Process(LPCTSTR pcszPriNo, LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir, LPCTSTR pcszSecNo, LPCTSTR pcszHighRise, LPCTSTR pcszNoSolicitation)
{
	// Get direct pointers
	if (pcszHighRise == 0)
		pcszHighRise			= "";
	if (pcszPostDir == 0)
		pcszPostDir				= "";
	if (pcszPreDir == 0)
		pcszPreDir				= "";
	if (pcszPriNo == 0)
		pcszPriNo				= "";
	if (pcszSecNo == 0)
		pcszSecNo				= "";
	if (pcszStreetName == 0)
		pcszStreetName			= "";
	if (pcszSuffix == 0)
		pcszSuffix				= "";
	if (pcszNoSolicitation == 0)
		pcszNoSolicitation	= "";

	// Initialize parsed data
	m_iFlags = 0;
	m_iPreDirNo = dirNone;
	m_iPostDirNo = dirNone;
	m_iStreetNo = 0;
	m_iPriNoNo = 0;
	m_iSecNoNo = 0;

	if (*pcszNoSolicitation != '\0' && !SolicitCanMail(pcszNoSolicitation[0]))
	{
		pcszHighRise = "";
		pcszPostDir = "";
		pcszPreDir = "";
		pcszPriNo = "";
		pcszSecNo = "";
		pcszStreetName = "";
		pcszSuffix = "";
		pcszNoSolicitation = "";
	}

	// Deal with the highrise flag
	if (*pcszStreetName == '\0' && *pcszHighRise != '\0')
	{
		if (pcszHighRise[0] == 'P')
			pcszStreetName = m_szPOBOX;
		else if (pcszHighRise[0] == 'R')
			pcszStreetName = m_szRR;
	}

	// Start in with the special cases
	// The first thing to deal with is a rural route or highway contract.
	// No star routes are known to exist
	bool fRr = _tcsnicmp(pcszStreetName, m_szRR, sizeof(m_szRR) - 1) == 0;
	bool fHc = _tcsnicmp(pcszStreetName, m_szHC, sizeof(m_szHC) - 1) == 0;
	if (fRr || fHc)
	{
		ASSERT(sizeof(m_szRR) == sizeof(m_szHC));

		pcszStreetName += sizeof(m_szRR) - 1;
		pcszStreetName = _tcsskipws(pcszStreetName);

		m_sPriNo = _tcsskipws(pcszPriNo);
		m_sSecNo = _tcsskipws(pcszSecNo);

		// If the next thing is not the word box && not a #
		// And no RR number
		if (m_sPriNo.IsEmpty())
		{
			if (pcszStreetName[0] != '#' && (pcszStreetName[0] != 'B' || pcszStreetName[1] != 'O' || pcszStreetName[2] != 'X'))
			{
				for (; *pcszStreetName && !_istspace(*pcszStreetName); ++pcszStreetName)
				{
					m_sPriNo += *pcszStreetName;
				}
			}
			pcszStreetName = _tcsskipws(pcszStreetName);
		}

		// If no BOX#, try to find one.
		if (m_sSecNo.IsEmpty())
		{
			if (pcszStreetName[0] == '#')
				++pcszStreetName;
			if (pcszStreetName[0] == 'B' && pcszStreetName[1] == 'O' && pcszStreetName[2] == 'X')
				pcszStreetName += 3;
			pcszStreetName = _tcsskipws(pcszStreetName);
			for (; *pcszStreetName; ++pcszStreetName)
			{
				m_sSecNo += *pcszStreetName;
			}
		}

		if (fRr)
		{
			m_iFlags |= addressRR;
			m_sStreetName = m_szRR;
		}
		else if (fHc)
		{
			m_iFlags |= addressHC;
			m_sStreetName = m_szHC;
		}

		m_sSuffix = "";
	}
	// PO BOX
	else if (_tcsnicmp(pcszStreetName, m_szPOBOX, sizeof(m_szPOBOX) - 1) == 0)
	{
		m_iFlags |= addressPOBOX;

		pcszStreetName += sizeof(m_szPOBOX) - 1;
		pcszStreetName = _tcsskipws(pcszStreetName);

		if (_tcsisempty(pcszPriNo))
			pcszPriNo = _tcsskipws(pcszSecNo);
		if (_tcsisempty(pcszPriNo))
			pcszPriNo = _tcsskipws(pcszStreetName);

		m_sStreetName = m_szPOBOX;
		m_sPriNo = pcszPriNo;
		m_sSecNo = "";
		m_sSuffix = "";

		pcszPostDir = "";
		pcszPreDir = "";
	}
	// General deliver
	else if (_tcsnicmp(pcszStreetName, m_szGD, sizeof(m_szGD) - 1) == 0)
	{
		m_iFlags |= addressGD;

		m_sPriNo = "";
		m_sStreetName = m_szGD;
		m_sSuffix = "";
		m_sSecNo = "";

		pcszPostDir = "";
		pcszPreDir = "";
	}
	// A generic street name
	else if (!_tcsisempty(pcszStreetName))
	{
		m_sPriNo = _tcsskipws(pcszPriNo);
		m_sStreetName = _tcsskipws(pcszStreetName);
		m_sStreetName.TrimRight();
		m_sSuffix = _tcsskipws(pcszSuffix);
		m_sSuffix.TrimRight();
		m_sSecNo = _tcsskipws(pcszSecNo);

		int iStreetNo = 0;
		for (; *pcszStreetName && _istdigit(*pcszStreetName); ++pcszStreetName)
		{
			iStreetNo *= 10;
			iStreetNo += int(*pcszStreetName - '0');
		}

		if (*pcszStreetName == '\0' && iStreetNo != 0)
		{
			m_iFlags |= addressNumericStreet;
			m_iStreetNo = iStreetNo;
		}
		
		if (
			_tcsicmp(pcszStreetName, "TH") == 0 ||
			_tcsicmp(pcszStreetName, "ST") == 0 ||
			_tcsicmp(pcszStreetName, "ND") == 0 ||
			_tcsicmp(pcszStreetName, "RD") == 0 ||
			_tcsicmp(pcszStreetName, "RST") == 0)
		{
			m_iFlags |= addressOrdinalStreet;
			m_iStreetNo = iStreetNo;
		}
	}
	else
	{
		m_iFlags |= addressEmpty;
		// An empty address
		m_sPriNo = "";
		m_sStreetName = "";
		m_sSuffix = "";
		m_sSecNo = "";
		pcszPostDir = "";
		pcszPreDir = "";
	}

	// Validate directionals
	if (*pcszPreDir)
	{
		m_iPreDirNo = FindDir(pcszPreDir);
	}
	if (*pcszPostDir)
	{
		m_iPostDirNo = FindDir(pcszPostDir);
	}

	// Numeric pri/sec no
	if (!m_sPriNo.IsEmpty())
	{
		m_sPriNo.TrimRight();
		LPCTSTR pcszPriNo = m_sPriNo;
		int iPriNo = 0;
		for (; *pcszPriNo && _istdigit(*pcszPriNo); ++pcszPriNo)
		{
			iPriNo *= 10;
			iPriNo += int(*pcszPriNo - '0');
		}
		if (*pcszPriNo == '\0')
		{
			m_iFlags |= addressNumericPriNo;
			m_iPriNoNo = iPriNo;
		}
	}
	if (!m_sSecNo.IsEmpty())
	{
		m_sSecNo.TrimRight();
		LPCTSTR pcszSecNo = m_sSecNo;
		int iSecNo = 0;
		for (; *pcszSecNo && _istdigit(*pcszSecNo); ++pcszSecNo)
		{
			iSecNo *= 10;
			iSecNo += int(*pcszSecNo - '0');
		}
		if (*pcszSecNo == '\0')
		{
			m_iFlags |= addressNumericSecNo;
			m_iSecNoNo = iSecNo;
		}
	}

	return true;
}

void CIuAddressCodec::Resolve(CIuResolveSpec& Spec)
{
	m_pMap->SetCaseConvert(caseUpper);
	m_pMap->Resolve(Spec);
}

void CIuAddressCodec::SetSpec(CIuAddressSpec& Spec)
{
	m_pMap->RemoveAll();
	VERIFY(m_pMap->AddField(Spec.GetHighRise()) == addressHighRise);
	VERIFY(m_pMap->AddField(Spec.GetPostDir()) == addressPostDir);
	VERIFY(m_pMap->AddField(Spec.GetPreDir()) == addressPreDir);
	VERIFY(m_pMap->AddField(Spec.GetPriNo()) == addressPriNo);
	VERIFY(m_pMap->AddField(Spec.GetSecNo()) == addressSecNo);
	VERIFY(m_pMap->AddField(Spec.GetStreetName()) == addressStreetName);
	VERIFY(m_pMap->AddField(Spec.GetSuffix()) == addressSuffix);
	VERIFY(m_pMap->AddField(Spec.GetNoSolicitation()) == addressNoSolicitation);
}

