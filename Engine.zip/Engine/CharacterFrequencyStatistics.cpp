#include "stdafx.h"
//{{Include
#include "CharacterFrequencyStatistics.h"
#include "resource.h"
#include "Data\resource.h"
#include "Data\Archive.h"
#include "Error\Error.h"
#include "Data\File.h"
#include "Common\BigBuffer.h"
#include "Common\SmartPtr.h"
#include "..\Version.h"
//}}Include



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCharacterFrequencyStatistics, CIuCharacterFrequencyStatistics_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuCharacterFrequencyStatistics)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CHARACTERFREQUENCYSTATISTICS, CIuCharacterFrequencyStatistics, CIuCharacterFrequencyStatistics_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCharacterFrequencyStatistics, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)

	IU_ATTRIBUTE_PAGE(CIuCharacterFrequencyStatistics, IDS_ENGINE_PPG_CHARACTERFREQUENCYSTATISTICS, 50, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuCharacterFrequencyStatistics, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_CHARACTERFREQUENCYSTATISTICS, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


struct CIuStatistics
{
	int m_iCount;
	char m_sz[4 + 1];
};

int __cdecl sort_statistics(const void *elem1, const void *elem2)
{
	const CIuStatistics* pStat1 = (const CIuStatistics*)elem1;
	const CIuStatistics* pStat2 = (const CIuStatistics*)elem2;
	return pStat2->m_iCount - pStat1->m_iCount;
}


CIuCharacterFrequencyStatistics::CIuCharacterFrequencyStatistics()
{
	CommonConstruct();
}

CIuCharacterFrequencyStatistics::CIuCharacterFrequencyStatistics(const CIuCharacterFrequencyStatistics& object)
{
	CommonConstruct();
	Copy(object);
}

CIuCharacterFrequencyStatistics::~CIuCharacterFrequencyStatistics()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCharacterFrequencyStatistics::Clear()
{
	CIuCharacterFrequencyStatistics_super::Clear();
	CIuCharacterFrequencyStatistics::CommonConstruct();
}

void CIuCharacterFrequencyStatistics::CommonConstruct()
{
	//{{Initialize
	m_sFilename.Empty();
	SetVersion(IU_VERSION);
	//}}Initialize
}

CString CIuCharacterFrequencyStatistics::GetFilename() const
{
	return m_sFilename;
}

void CIuCharacterFrequencyStatistics::OnRun()
{
	COMMAND_PROGRESS_INSTANCE(instance);

	MessageF("Scanning file %s", LPCTSTR(m_sFilename));

	// Open the file
	CIuFilePhysical file(m_sFilename, CIuFile::openReadOnly);
	CIuFilePosition Length = file.GetLength();

	// Allocate a buffer for scanning the file the
	const int iBufferLength = int(min(Length, __int64(512 * 1024)));
	CIuBigBuffer buffer;
	buffer.SetSize(iBufferLength);

	// Clear the current map and allocate a VERY large hash table
	m_map.RemoveAll();
	m_map.InitHashTable(16 * 1024 * 1024 + 1);

	// Set up the progress bar
	int iRange = int(Length / iBufferLength);
	SetRange(iRange);
	int iPosition = 0;
	SetPosition(iPosition);
	if (!Fire())
		return ;

	// Process the file
	unsigned __int32 uiWord = 0; // This represents the last 4 characters processed
	while (Length)
	{
		// Update the progress bar
		SetPosition(++iPosition);
		if (!Fire())
			return ;

		// Read the next chunk of the file
		CIuFilePosition ReadLength = min(Length, CIuFilePosition(iBufferLength));
		file.Read(buffer.GetPtr(), int(ReadLength));
		Length -= ReadLength;

		// Partially clear the hash table if it grows way too large
		PartialClear(100 * 1024 * 1024);

		// Process the bytes in this segment
		int iBytes = int(ReadLength);
		LPBYTE pb = buffer;
		for (int iByte = 0; iByte < iBytes; ++iByte)
		{
			uiWord >>= 8;
			uiWord |= ((pb[iByte] & 0x7F) << 24);

			UpdateMap(uiWord);
		}
	}

	// Clear out the 3 bytes in the word
	uiWord >>= 8;
	UpdateMap(uiWord);
	uiWord >>= 8;
	UpdateMap(uiWord);
	uiWord >>= 8;
	UpdateMap(uiWord);

	// Do a partial clear down to 10,000 elements
	// This should save us some time on the sort
	Output("Cleaning up...\n");
	Fire();
	PartialClear(10000);

	// Now, do the output
	Output("Finishing...\n");
	Fire();

	CIuSmartPtr2<CIuStatistics> pStatistics(new CIuStatistics[m_map.GetCount()], true, true);

	POSITION pos = m_map.GetStartPosition();
	
	for (int iCurrent = 0; pos; ++iCurrent)
	{
		__int32 uiWord;
		__int32 uiCount;
		m_map.GetNextAssoc(pos, uiWord, uiCount);
		
		pStatistics[iCurrent].m_iCount = uiCount;
		pStatistics[iCurrent].m_sz[3] = char((uiWord >> 24) & 0x7F);
		pStatistics[iCurrent].m_sz[2] = char((uiWord >> 16) & 0x7F);
		pStatistics[iCurrent].m_sz[1] = char((uiWord >> 8) & 0x7F);
		pStatistics[iCurrent].m_sz[0] = char(uiWord & 0x7F);
		pStatistics[iCurrent].m_sz[4] = '\0';
	}

	// Sort
	Output("\n\nSorting...\n");
	if (!Fire())
		return ;
	qsort(pStatistics, m_map.GetCount(), sizeof(CIuStatistics), sort_statistics);

	// Output top 'N'
	int iMaxOutput = 1500;

	OutputF("\n\nTop %d:\n", iMaxOutput);
	CString sSuffix;
	CString s;
	for (int i = 0; i < min(m_map.GetCount(), iMaxOutput); ++i)
	{
		s = "\t\"";
		for (int c = 0; c < 4; ++c)
		{
			if (pStatistics[i].m_sz[c] == 0)
				break;
			s += pStatistics[i].m_sz[c];
		}
		s += "\",";
		for (; c < 4; ++c)
			s += ' ';

		sSuffix.Format(_T(" // (0x%02X 0x%02X 0x%02X 0x%02X): %d\n"),
			pStatistics[i].m_sz[0], pStatistics[i].m_sz[1], pStatistics[i].m_sz[2], pStatistics[i].m_sz[3],
			pStatistics[i].m_iCount);
		 
		s += sSuffix;

		Output(s);
	}
	Output("\n\n");
	Fire();

	// Output top 'N' 3 & 4 character sequences
	iMaxOutput = 1000;

	OutputF("\n\nTop %d 3 & 4 character sequences:\n", iMaxOutput);
	int iOutput = 0;
	for (i = 0; i < m_map.GetCount() && iOutput < iMaxOutput; ++i)
	{
		if (pStatistics[i].m_sz[1] == 0 || pStatistics[i].m_sz[2] == 0)
			continue;
		s = "\t\"";
		for (int c = 0; c < 4; ++c)
		{
			if (pStatistics[i].m_sz[c] == 0)
				break;
			s += pStatistics[i].m_sz[c];
		}
		s += "\",";
		for (; c < 4; ++c)
			s += ' ';

		sSuffix.Format(_T(" // (0x%02X 0x%02X 0x%02X 0x%02X): %d\n"),
			pStatistics[i].m_sz[0], pStatistics[i].m_sz[1], pStatistics[i].m_sz[2], pStatistics[i].m_sz[3],
			pStatistics[i].m_iCount);
		 
		s += sSuffix;

		Output(s);

		++iOutput;
	}
	Output("\n\n");
	Fire();
}


void CIuCharacterFrequencyStatistics::PartialClear(int iSize)
{

	ASSERT(iSize > 0);
	if (m_map.GetCount() <= iSize)
		return ;

	unsigned __int32 uiCountRemove = 1;
	while (m_map.GetCount() > iSize)
	{
		unsigned __int32 uiCountRemoveNext = 0x7FFFFFF;

		POSITION pos = m_map.GetStartPosition();
		while (pos)
		{
			__int32 uiWord;
			__int32 uiCount;
			m_map.GetNextAssoc(pos, uiWord, uiCount);
			if (((unsigned __int32)uiCount) <= uiCountRemove)
				m_map.RemoveKey(uiWord);
			else if (((unsigned __int32)uiCount) < uiCountRemoveNext)
				uiCountRemoveNext = uiCount;
		}
		uiCountRemove = uiCountRemoveNext;
	}
}

void CIuCharacterFrequencyStatistics::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCharacterFrequencyStatistics::UpdateMap(unsigned __int32 uiWord)
{
	UpdateMap2(uiWord & 0xFFFFFFFF);
	if ((uiWord & 0xFFFFFF00) != 0)
		UpdateMap2(uiWord & 0x00FFFFFF);
	if ((uiWord & 0xFFFF0000) != 0)
		UpdateMap2(uiWord & 0x0000FFFF);
	if ((uiWord & 0xFF000000) != 0)
		UpdateMap2(uiWord & 0x000000FF);
}

void CIuCharacterFrequencyStatistics::UpdateMap2(unsigned __int32 uiWord)
{
	int iChar1 = int(uiWord & 0x7F);

	// Must start with a printable character
	if (!isprint(iChar1))
		return ;

	int iChar2 = int((uiWord >> 8) & 0x7F);
	int iChar3 = int((uiWord >> 16) & 0x7F);
	int iChar4 = int((uiWord >> 24) & 0x7F);

	// If the first char is not alpha or space, the remainder must be null
	if (!isalpha(iChar1) && iChar1 != ' ')
		if (iChar2 != 0 || iChar3 != 0 || iChar4 != 0)
			return ;

	// Everything else must be alpha/space/null
	if (iChar1 == ' ' && (!isalpha(iChar2) && !isalpha(iChar3) && !isalpha(iChar4)))
		return ;
	if (!isalpha(iChar2) && iChar2 != ' ' && iChar2 != '\0')
		return ;
	if (!isalpha(iChar3) && iChar3 != ' ' && iChar3 != '\0')
		return ;
	if (!isalpha(iChar4) && iChar4 != ' ' && iChar4 != '\0')
		return ;

	//  Do not process embedded null's
	if (iChar4 != 0 && (iChar1 == 0 || iChar2 == 0 || iChar3 == 0))
			return ;
	if (iChar3 != 0 && (iChar1 == 0 || iChar2 == 0))
			return ;
	if (iChar2 != 0 && (iChar1 == 0))
			return ;

	// Do not process strings with multiple spaces
	if (iChar1 == ' ' && (iChar2 == ' ' || iChar3 == ' ' || iChar4 == ' '))
			return ;
	if (iChar2 == ' ' && (iChar3 == ' ' || iChar4 == ' '))
			return ;
	if (iChar3 == ' ' && (iChar4 == ' '))
			return ;

	// OK, passed all the tests... add it into the map
	__int32 uiCount;
	if (m_map.Lookup(uiWord, uiCount))
		m_map.SetAt(uiWord, uiCount + 1);
	else
		m_map.SetAt(uiWord, 1);
}
