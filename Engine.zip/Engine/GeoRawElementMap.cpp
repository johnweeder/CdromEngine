#include "StdAfx.h"
//{{Include
#include "GeoRawElementMap.h"
#include "GeoRawElementCollection.h"
#include "GeoRawElement.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawElementMap, CIuGeoRawElementMap_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawElementMap)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWELEMENTMAP, CIuGeoRawElementMap, CIuGeoRawElementMap_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawElementMap::CIuGeoRawElementMap() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoRawElementMap::~CIuGeoRawElementMap()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawElementMap::Create(CIuGeoRawElementCollection& collection)
{
	collection.SortByName();
	m_Map.RemoveAll();
	// Make hash table large to avoid collisions...
	if (collection.GetCount())
		m_Map.InitHashTable(collection.GetCount() * 2);

	int iElements = collection.GetCount();
	for (int i = 0; i < iElements; ++i)
	{
		CIuGeoRawElement* pElement = collection.Get(i);
		m_Map.SetAt(pElement->GetName(), i);
	}
}

void CIuGeoRawElementMap::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

void CIuGeoRawElementMap::Empty()
{
	m_Map.RemoveAll();
}
