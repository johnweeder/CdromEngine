#ifndef _ENGINE_DATABASELIST_H_
#define _ENGINE_DATABASELIST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuDatabaseList)
IU_DEFINE_OBJECT_PTR(CIuDatabase)
IU_DEFINE_OBJECT_PTR(CIuQuery)
class CIuEngine;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDatabaseList, CIuObjectNamed }}
#define CIuDatabaseList_super CIuObjectNamed

class IU_CLASS_EXPORT CIuDatabaseList : public CIuDatabaseList_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuDatabaseList)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDatabaseList();
	virtual ~CIuDatabaseList();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuMoniker GetDatabase(int) const;
	int GetDatabaseCount() const;
	CIuID GetDatabaseID(int iIndex) const;
	CString GetDatabaseName(int iIndex) const;
	CIuDatabasePtr GetDatabasePtr(int iWhich) const;
	void GetDatabases(CIuMonikerArray& amoniker) const;
	CIuEngine& GetEngine() const;
	void GetFields(CStringArray& as) const;
	void GetIndexes(CStringArray& as) const;
	CIuQueryPtr GetQueryPtr(int iWhich) const;
	bool HasEngine() const;
	bool IsEmpty() const;
	bool IsQuery(int iWhich) const;
	bool SearchAll() const;
	bool ShowQueries() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int Add(LPCTSTR Name, int Before) ;
	int AddDatabase(const CIuMoniker& moniker, int iBefore) ;
	virtual void Clear();
	void Remove(int iIndex);
	void RemoveAll();
	void RemoveAllDatabases();
	void RemoveDatabase(int);
	bool SelectDlg(int Flags = 0, CWnd* pParent = 0);
	bool SelectDlg(int iFlags = 0, LPCTSTR pcszApplication = 0, CWnd* pParent = 0);
	void SetDatabase(int, const CIuMoniker&);
	void SetDatabases(const CIuMonikerArray&);
	void SetEngine(CIuEngine& Engine);
	void SetShowQueries(bool f);
	void SetSearchAll(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionSelectDlg(const CIuPropertyCollection& Collection, CIuOutput& Output);
	void GetDatabasesAllowed(CStringArray& as) const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
	bool m_fShowQueries;
	bool m_fSearchAll;
	CIuMonikerArray m_amonikerDatabases;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuMoniker CIuDatabaseList::GetDatabase(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetDatabaseCount());
	return m_amonikerDatabases[iWhich];
}

inline int CIuDatabaseList::GetDatabaseCount() const
{
	return m_amonikerDatabases.GetSize();
}

inline CIuEngine& CIuDatabaseList::GetEngine() const
{
	ASSERT(m_pEngine!=0);
	return *m_pEngine;
}

inline bool CIuDatabaseList::HasEngine() const
{
	return m_pEngine!=0;
}

inline bool CIuDatabaseList::SearchAll() const
{
	return m_fSearchAll;
}

inline bool CIuDatabaseList::ShowQueries() const
{
	return m_fShowQueries;
}

#endif // _ENGINE_DATABASELIST_H_
