#include "StdAfx.h"
//{{Include
#include "ExpressionConcat.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionConcat::CIuExpressionConcat() : CIuExpressionElement(exprConcatenation)
{
	SetFormat(exprFormatString);
}

CIuExpressionConcat::CIuExpressionConcat(const CIuExpressionConcat& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionConcat::~CIuExpressionConcat()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionConcat::Clone() const
{
	CIuExpressionConcat* pElement = new CIuExpressionConcat(*this);
	ASSERT(pElement);
	return pElement;
} 

LPCTSTR CIuExpressionConcat::Evaluate(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() >= 2);
	ASSERT(GetType() == exprConcatenation);

	m_sBuffer = "";	
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
		m_sBuffer += EvaluateChild(iChild, pRecord);
	return m_sBuffer;
}

int CIuExpressionConcat::GetMaxLength() const
{
	ASSERT(GetType() == exprConcatenation);
	int iMaxLength = 0;
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
		iMaxLength += GetChild(iChild).GetMaxLength();
	return iMaxLength;
}

LPCTSTR CIuExpressionConcat::GetTypeName() const
{
	switch (GetType())
	{
		case exprBinary:
			return "#Binary Operator#";
		case exprConcatenation:
			return "&";
	}
	return CIuExpressionConcat_super::GetTypeName();
}

bool CIuExpressionConcat::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprBinary || CIuExpressionConcat_super::IsKindOf(Type);
}

CIuExpressionConcat& CIuExpressionConcat::operator=(const CIuExpressionConcat& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionConcat_super::operator=(rExpressionElement);
	return *this;
}
