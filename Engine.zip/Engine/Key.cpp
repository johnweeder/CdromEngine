#include "StdAfx.h"
//{{Include
#include "Key.h"
#include "KeyDef.h"
#include "RecordDef.h"
#include "FieldMap.h"
#include "Source.h"
#include "Common\String.h"
#include "Error\Error.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuKey, CIuKey_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuKey)
//}}Implement

CIuKey::CIuKey() 		   
{
	CommonConstruct();
}

CIuKey::CIuKey(const CIuKey& rKey)
{
	CommonConstruct();
	*this = rKey;
}

CIuKey::CIuKey(LPCTSTR pcsz, const CIuKeyDef& KeyDef)
{
	CommonConstruct();
	if (pcsz)
		Set(pcsz, KeyDef);
}

CIuKey::~CIuKey()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuKey::Append(const TCHAR* pch, int cch, const CIuKeyDef& KeyDef, bool fWildcard)
{
	ASSERT(cch == 0 || pch != 0);
	// This function append a single string to the key. Left/right
	// justification is handled. 
	// However, wildcards and multi-part keys are not handled.
	// Also, embedded special characters are not recognized.

	// NOTE: Keys are always maintained in upper case.
	// Can not append once a wildcard is set.
	// I.E. A*#B is not meaningful.
	ASSERT(!IsWildCard());

	// You must have set the key definition in order to create the
	// key using this method. Otherwise, you won't know whether to 
	// right or left justify each field.
	if (m_iNext >= KeyDef.m_aiWidths.GetSize())
		Error(IU_E_NO_KEY_DEFINITION);

	int iWidth = KeyDef.m_aiWidths[m_iNext];
	++m_iNext;

	// NOTE: Don't append the trailing null on a wildcard'ed key
	if (iWidth > 0 && cch < iWidth)
	{
		ASSERT(int(iWidth - cch) < int(strlen(CIuKeyDef::m_szSpaces)));
		m_Key.Append((const BYTE*)CIuKeyDef::m_szSpaces, iWidth - cch);
		if (cch > 0)
			m_Key.Append((const BYTE*)pch, cch);
		if (!fWildcard)
			m_Key.Append((BYTE)'\0');
	}
	else
	{
		if (cch > 0)
			m_Key.Append((const BYTE*)pch, cch);
		if (!fWildcard)
			m_Key.Append((BYTE)'\0');
	}
	m_iType = keyValue;
	if (fWildcard)
		SetWildCard();
}

void CIuKey::Append(const BYTE* pb, int cb)
{
	if (cb == 0)
		return ;
	ASSERT(AfxIsValidAddress(pb, cb, false));
	int iSize = m_Key.GetSize();
	m_Key.Append(pb, cb);
	// The buffer is always forced to upper case to 
	// optimize comparisons.
	m_Key.MakeUpper(iSize);
	m_iType = keyValue;
}

void CIuKey::Clear()
{
// Performance hack... no need to call base class (for now...)
//	CIuKey_super::Clear();
	CIuKey::CommonConstruct();
}

void CIuKey::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_Key.Empty();
	m_iNext = 0;
	m_fWildCard = false;
	m_iType = keyInvalid;
	m_iExpandNo = -1;
	m_iExpandCount = 0;
	//}}Initialize
}

int CIuKey::Compare(const CIuKey& key, bool* pfPartial) const
{
	// Special compare to allow for empty records (low val) and high vals....
	// NOTE: LoVal and Invalid are considered equal for comparison purposes.
	bool fLoVal1 = IsLoVal() || IsInvalid();
	bool fLoVal2 = key.IsLoVal() || key.IsInvalid();
	bool fHiVal1 = IsHiVal();
	bool fHiVal2 = key.IsHiVal();
	if (fLoVal1 && fLoVal2)
		return 0;
	else if (fHiVal1 && fHiVal2)
		return 0;
	else if (fHiVal1)
		return 1;
	else if (fHiVal2)
		return -1;
	else if (fLoVal1)
		return -1;
	else if (fLoVal2)
		return 1;

	if (pfPartial)
		*pfPartial = false;

	int iCmp = min(GetKeySize(), key.GetKeySize());

	const BYTE* pb1 = GetKeyPtr();
	const BYTE* pb2 = key.GetKeyPtr();

	int iResult = memicmp(pb1, pb2, iCmp);
	if (iResult < 0)
		return -1;
	else if (iResult > 0)
		return 1;
	else if (GetKeySize() < key.GetKeySize())
	{
		if (IsWildCard())
		{
			if (pfPartial)
				*pfPartial = true;
			return 0;
		}
		else
			return -1;
	}
	else if (GetKeySize() > key.GetKeySize())
	{
		if (key.IsWildCard())
		{
			if (pfPartial)
				*pfPartial = true;
			return 0;
		}
		else
			return 1;
	}
	return 0;
}

void CIuKey::Copy(const CIuObject& object)
{
	CIuKey_super::Copy(object);

	const CIuKey* pKey = dynamic_cast<const CIuKey*>(&object);
	if (pKey == 0 || pKey == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuKey)));
	
	m_Key = pKey->m_Key;
	m_iNext = pKey->m_iNext;
	m_fWildCard = pKey->m_fWildCard;
	m_iType = pKey->m_iType;
	m_iExpandNo = pKey->m_iExpandNo;
	m_iExpandCount = pKey->m_iExpandCount;
}

void CIuKey::CopyFast(const CIuKey& Key)
{
	// No base class... simply copy the key data.
	m_Key = Key.m_Key;
	m_iType = Key.m_iType;
	m_iNext = Key.m_iNext;
	m_fWildCard = Key.m_fWildCard;
	m_iExpandNo = Key.m_iExpandNo;
	m_iExpandCount = Key.m_iExpandCount;
}

CIuKey& CIuKey::operator=(const CIuKey& rKey)
{
	Copy(rKey);
	return *this;
}

void CIuKey::Set(const BYTE* pb, int cb)
{
	ASSERT(AfxIsValidAddress(pb, cb, false));
	m_Key.Empty();
	m_iNext = 0;
	m_fWildCard = false;
	m_Key.Append(pb, cb);
	m_iType = keyValue;
}

void CIuKey::Set(LPCTSTR pcsz, const CIuKeyDef& KeyDef)
{
	m_Key.Empty();
	m_iNext = 0;
	m_fWildCard = false;

	// The key is of the form:
	//		key1^key2*
	// The trailing "*" indicates a wildcard and is optional.
	// The "^" is a separator (keySeparatorChar: normally a tab) between key components.
	// A backslash may be used to include special characters as a literal.
	ASSERT(AfxIsValidString(pcsz));
	CString sKey;
	while (*pcsz)
	{
		if (pcsz[0] == '\\' && pcsz[1] != '\0')
		{
			sKey += pcsz[1];
			pcsz += 2;
		}
		else if (pcsz[0] == '*' && pcsz[1] == '\0')
		{
			if (!sKey.IsEmpty())
				Append(sKey, KeyDef, true);
			else
				SetWildCard();
			return ;
		}
#ifdef _DEBUG
		// In debug mode, recognize the ^ as a key separator.
		// This is easier to type than a tab character
		else if (pcsz[0] == '^')
		{
			Append(sKey, KeyDef);
			sKey = _T("");
			++pcsz;
		}
#endif
		else if (pcsz[0] == keySeparatorChar)
		{
			Append(sKey, KeyDef);
			sKey = _T("");
			++pcsz;
		}
		else
		{
			sKey += *pcsz;
			++pcsz;
		}
	}
	if (!sKey.IsEmpty())
		Append(sKey, KeyDef);
	m_iType = keyValue;
}

void CIuKey::SetExpandCount(int iExpandCount)
{
	m_iExpandCount = iExpandCount;
}

void CIuKey::SetExpandNo(int iExpandNo)
{
	m_iExpandNo = iExpandNo;
}

void CIuKey::SetHiVal()
{
	m_iType = keyHiVal;
	m_Key.Empty();
	m_iNext = 0;
	m_fWildCard = false;
	m_iExpandNo = -1;
	m_iExpandCount = 0;
}

void CIuKey::SetLoVal()
{
	m_iType = keyLoVal;	
	m_Key.Empty();
	m_iNext = 0;
	m_fWildCard = false;
	m_iExpandNo = -1;
	m_iExpandCount = 0;
}

void CIuKey::SetType(int iType)
{
	m_iType = iType;
}

void CIuKey::SetWildCard(bool f)
{
	m_fWildCard = f;
}
