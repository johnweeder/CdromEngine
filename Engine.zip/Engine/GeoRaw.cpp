#include "StdAfx.h"
//{{Include
#include "GeoRaw.h"
#include "GeoSpec.h"
#include "GeoRawMap.h"
#include "GeoRawZip.h"
#include "GeoRawAreaCode.h"
#include "GeoRawExchange.h"
#include "GeoRawCity.h"
#include "GeoRawCounty.h"
#include "GeoRawMsa.h"
#include "GeoRawState.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "Data\SerializeEx.h"
#include "Common\BigBuffer.h"
#include "Interop\Conversions.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "CdromSpec.h"
#include "Miscellaneous.h"
#include "RecordIterator.h"
#include "Input.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRaw, CIuGeoRaw_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRaw)
const	CIuVersionNumber versionGeoRawMax(2000,1,5,304);
const	CIuVersionNumber versionGeoRawMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAW, CIuGeoRaw, CIuGeoRaw_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_ZIP, GetZip_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_ZIP, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_CITY, GetCity_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_CITY, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_STATE, GetState_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_STATE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_AREACODE, GetAreaCode_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_AREACODE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_EXCHANGE, GetExchange_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_EXCHANGE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_COUNTY, GetCounty_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_COUNTY, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_MSA, GetMsa_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_MSA, editorUsePropName)

	IU_ATTRIBUTE_ACTION(CIuGeoRaw, IDS_ENGINE_ACTION_READ, ActionRead, 0)

	IU_ATTRIBUTE_PAGE(CIuGeoRaw, IDS_ENGINE_PPG_GEORAW, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRaw, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRaw, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_GEORAW, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRaw, IDS_ENGINE_PROP_MAP, GetMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuGeoRaw, IDS_ENGINE_PROP_MAP, IDS_ENGINE_PPG_GEORAW, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRaw::CIuGeoRaw() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoRaw::~CIuGeoRaw()
{
	Empty();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuGeoRaw::ActionRead(const CIuPropertyCollection&, CIuOutput&)
{
	Read();
	return CString("Success");
}

void CIuGeoRaw::Append(CIuGeoRawInstance& Instance, CIuOutput& Output)
{
	// Append into collections...
	GetZip().Append(Instance.GetZip(), Instance, Output);
	if (!Instance.GetCity().IsEmpty())
		GetCity().Append(Instance.GetStateCity(), Instance, Output);
	if (!Instance.GetStateAbbr().IsEmpty())
		GetState().Append(Instance.GetStateAbbr(), Instance, Output);
	if (Instance.GetCountyCode() != 0)
		GetCounty().Append(Instance.GetCountyCode(), 5, Instance, Output);
	if (Instance.GetMsaCode() != 0)
		GetMsa().Append(Instance.GetMsaCode(), 4, Instance, Output);
	int iPhoneCount = Instance.GetPhoneCount();
	for (int iPhone = 0; iPhone < iPhoneCount; ++iPhone)
	{
		__int64 lAreaCode = Instance.GetAreaCode(iPhone);
		if (lAreaCode != 0)
			GetAreaCode().Append(int(lAreaCode), 3, Instance, Output);
		__int64 lExchange = Instance.GetExchange(iPhone);
		if (lExchange != 0)
			GetExchange().Append(int(lExchange), 6, Instance, Output);
	}
}

void CIuGeoRaw::Clear()
{
	CIuGeoRaw_super::Clear();
	Empty();
}

void CIuGeoRaw::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sFilename.Empty();
	m_Zip.SetElementType(RUNTIME_CLASS(CIuGeoRawZip));
	m_AreaCode.SetElementType(RUNTIME_CLASS(CIuGeoRawAreaCode));
	m_City.SetElementType(RUNTIME_CLASS(CIuGeoRawCity));
	m_County.SetElementType(RUNTIME_CLASS(CIuGeoRawCounty));
	m_Exchange.SetElementType(RUNTIME_CLASS(CIuGeoRawExchange));
	m_Msa.SetElementType(RUNTIME_CLASS(CIuGeoRawMsa));
	m_State.SetElementType(RUNTIME_CLASS(CIuGeoRawState));
	SetVersion(versionGeoRawMax);
	//}}Initialize
	InitHashTables();
}

void CIuGeoRaw::CreateMaps()
{
	GetAreaCodeMap().Create(GetAreaCode());
	GetCityMap().Create(GetCity());
	GetCountyMap().Create(GetCounty());
	GetExchangeMap().Create(GetExchange());
	GetMsaMap().Create(GetMsa());
	GetStateMap().Create(GetState());
	GetZipMap().Create(GetZip());
}

void CIuGeoRaw::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
	// Empty this object as a way of cleaning up un-needed memory
	Empty();
}

void CIuGeoRaw::Empty()
{
	GetZip().Empty();
	GetAreaCode().Empty();
	GetExchange().Empty();
	GetState().Empty();
	GetMsa().Empty();
	GetCounty().Empty();
	GetCity().Empty();

	GetAreaCodeMap().Empty();
	GetCityMap().Empty();
	GetCountyMap().Empty();
	GetExchangeMap().Empty();
	GetMsaMap().Empty();
	GetStateMap().Empty();
	GetZipMap().Empty();
}

CIuObject* CIuGeoRaw::GetAreaCode_() const
{
	return &m_AreaCode;
}

CIuObject* CIuGeoRaw::GetCity_() const
{
	return &m_City;
}

CIuObject* CIuGeoRaw::GetCounty_() const
{
	return &m_County;
}

CIuObject* CIuGeoRaw::GetExchange_() const
{
	return &m_Exchange;
}

CString CIuGeoRaw::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CIuFilename CIuGeoRaw::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

CIuObject* CIuGeoRaw::GetMap_() const
{
	return &m_Map;
}

CIuObject* CIuGeoRaw::GetMsa_() const
{
	return &m_Msa;
}

CIuObject* CIuGeoRaw::GetState_() const
{
	return &m_State;
}

CIuVersionNumber CIuGeoRaw::GetVersionMax() const
{
	return versionGeoRawMax;
}

CIuVersionNumber CIuGeoRaw::GetVersionMaxStatic()
{
	return versionGeoRawMax;
}

CIuVersionNumber CIuGeoRaw::GetVersionMin() const
{
	return versionGeoRawMin;
}

CIuVersionNumber CIuGeoRaw::GetVersionMinStatic()
{
	return versionGeoRawMin;
}

CIuObject* CIuGeoRaw::GetZip_() const
{
	return &m_Zip;
}

void CIuGeoRaw::InitHashTables() 
{
	// NOTE: Hash tables are set to roughly 2X the number of expected elements
	m_Zip.InitHashTable(99881);
	m_AreaCode.InitHashTable(2083);
	m_City.InitHashTable(80111);
	m_County.InitHashTable(6529);
	m_Exchange.InitHashTable(80111);
	m_Msa.InitHashTable(1483);
	m_State.InitHashTable(127);
}

void CIuGeoRaw::Process(const CIuRecord& Record, CIuOutput& Output)
{
	// No need to clear as that happens automatically.
	m_Instance.Set(Record, m_Map);
	int iZip = StringAsInt(m_Instance.GetZip());
	CIuGeoZipCentroid Centroid;
	if (m_mapCentroid.Lookup(iZip, Centroid))
		m_Instance.GetZipCentroid() = Centroid.m_Centroid;
	else
		m_Instance.GetZipCentroid().Clear();
	Append(m_Instance, Output);
}

void CIuGeoRaw::Read()
{
	CIuFilename filename = GetFullFilename();
	if (!filename.Exists())
	{
		TRACE("WARNING: Warning raw geography file '%s' not found.\n", LPCTSTR(filename));
		Clear();
		return ;
	}

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Open(GetFullFilename(), 16 * 1024, CIuFile::openReadOnly);

	pFile->GetData(this);

	CIuFileVirtualPtr pVFile = pFile->Use();

	CIuBigBuffer buffer;
	buffer.SetSize((int)pVFile->GetLength());

	pVFile->Seek(0);
	pVFile->Read(buffer.GetPtr(), buffer.GetSize());

	SerializeFromMemory(buffer, this);
}

void CIuGeoRaw::ReadZipCentroid(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(_T("ZipCentroid"));
	if (!Iterator.Open(Output))
		return ;

	// Set up to read centroids
	CIuGeoZipCentroid Centroid;
	m_mapCentroid.RemoveAll();
	m_mapCentroid.InitHashTable(64157);

	// Process the records in the file
	Output.SetMessageF("Updating ZIP Centroid's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszZip = pRecord->GetField(inputZipCentroidZIP);
		ASSERT(_tcslen(pcszZip) == 5);
		LPCTSTR pcszLatitude = pRecord->GetField(inputZipCentroidLatitude);
		LPCTSTR pcszLongitude = pRecord->GetField(inputZipCentroidLongitude);

		Centroid.m_iZip = StringAsInt(pcszZip);

		// To be consistent with rest of build we don't put negative sign on lat/int
		if (*pcszLatitude == '-')
			++pcszLatitude;
		if (*pcszLongitude == '-')
			++pcszLongitude;

		Centroid.m_Centroid = CIuLatLongCoordinate(pcszLatitude, pcszLongitude);

		m_mapCentroid.SetAt(Centroid.m_iZip, Centroid);
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}

void CIuGeoRaw::Resolve(CIuResolveSpec& Spec)
{
	m_Map.Resolve(Spec);
}

void CIuGeoRaw::Serialize(CArchive& ar)
{
	// We use MFC serialization for performance reasons...
	// NOTE: We are only saving the GeoRaw information via MFC serialization
	const DWORD dwCurrentVersion = 0x00000001;
	if (ar.IsStoring())
	{
		ar << dwCurrentVersion;
	}
	else
	{
		DWORD dwVersion;
		ar >> dwVersion;
		ASSERT(dwVersion == dwCurrentVersion);

		Clear();
	}
	GetZip().Serialize(ar);
	GetCity().Serialize(ar);
	GetState().Serialize(ar);
	GetAreaCode().Serialize(ar);
	GetExchange().Serialize(ar);
	GetMsa().Serialize(ar);
	GetCounty().Serialize(ar);
}


void CIuGeoRaw::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuGeoRaw::SetSpec(CIuGeoSpec& Spec)
{
	SetName(Spec.GetCdrom().GetName());
	SetFilename(Spec.GetCdrom().GetFilename());
	m_Map.SetSpec(Spec);
}

void CIuGeoRaw::Write() const
{
	CIuBigBuffer buffer;
	SerializeToMemory(buffer, *this, 1024 * 1024);

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Create(GetFullFilename(), 16 * 1024, CIuFile::openCreate);

	CIuFileVirtualPtr pVFile = pFile->Use();
	pFile->SetData(*this);

	pVFile->Seek(0);
	pVFile->Write(buffer.GetPtr(), buffer.GetSize());
}
