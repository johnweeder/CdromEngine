#ifndef _ENGINE_EXPRESSIONLITERAL_H_
#define _ENGINE_EXPRESSIONLITERAL_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionLiteral, CIuExpressionElement }} 
#define CIuExpressionLiteral_super CIuExpressionElement

class CIuExpressionLiteral : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionLiteral(LPCTSTR pcsz = 0);
	CIuExpressionLiteral(const CIuExpressionLiteral& rExpressionElement);
	virtual ~CIuExpressionLiteral();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual LPCTSTR Evaluate(const CIuRecord*) const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
	void SetLiteral(LPCTSTR pcsz);
	void SetLiteral(int iLiteral);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionLiteral& operator=(const CIuExpressionLiteral& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// NOTE: m_sBuffer holds the string literal value.
	// This variable holds the pre-computed integer literal
	int m_iLiteral;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONLITERAL_H_
