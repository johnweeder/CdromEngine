#include "StdAfx.h"
//{{Include
#include "AltSpec.h"
#include "AltSpecDft.h"
#include "CdromSpecConst.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltSpec, CIuAltSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTSPEC, CIuAltSpec, CIuAltSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltSpec, IDS_ENGINE_PPG_ALTSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAltSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAltSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ALTSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuAltSpec, IDS_ENGINE_PROP_NUMERICKEY, IsNumericKey, SetNumericKey, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuAltSpec, IDS_ENGINE_PROP_NUMERICKEY, IDS_ENGINE_PPG_ALTSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuAltSpec, IDS_ENGINE_PROP_NOSTORE, IsNoStore, SetNoStore, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuAltSpec, IDS_ENGINE_PROP_NOSTORE, IDS_ENGINE_PPG_ALTSPEC, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAltSpec::CIuAltSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltSpec::~CIuAltSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuAltSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sFilename = "Filename";
	m_fNoStore = false;
	m_fNumericKey = false;
	m_pCdrom = 0;
	m_iAltNo = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuAltSpec::FromIndex(CIuCdromSpec* pCdrom, int iAltSpec)
{
	ASSERT(iAltSpec >= 0);

	const CIuAltSpecDft* pAltSpec = CIuAltSpecDft::Get(iAltSpec);
	ASSERT(pAltSpec);

	FromSpec(pCdrom, pAltSpec);
}

void CIuAltSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszAlt)
{
	FromIndex(pCdrom, CIuAltSpecDft::Find(pcszAlt));
}

void CIuAltSpec::FromNo(CIuCdromSpec* pCdrom, int iAltNo)
{
	FromIndex(pCdrom, CIuAltSpecDft::Find(iAltNo));
}

void CIuAltSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuAltSpecDft* pAltSpec)
{
	SetCdrom(pCdrom);

	SetName(pAltSpec->m_pcszAlt);
	ASSERT(pAltSpec->m_pid);
	SetID(*pAltSpec->m_pid);

	SetAltNo(pAltSpec->m_iAlt);
	SetNumericKey(pAltSpec->m_fNumericKey);
	SetNoStore(pAltSpec->m_fNoStore);
	ASSERT(AfxIsValidString(pAltSpec->m_pcszFilename));
	SetFilename(pAltSpec->m_pcszFilename);
}

int CIuAltSpec::GetCount()
{
	return CIuAltSpecDft::GetCount();
}

void CIuAltSpec::SetAltNo(int iAltNo)
{
	m_iAltNo = iAltNo;
}

void CIuAltSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pCdrom = pCdrom;
}

void CIuAltSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAltSpec::SetNoStore(bool f)
{
	m_fNoStore = f;
}

void CIuAltSpec::SetNumericKey(bool f)
{
	m_fNumericKey = f;
}
