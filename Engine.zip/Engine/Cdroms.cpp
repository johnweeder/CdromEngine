#include "StdAfx.h"
//{{Include
#include "Cdroms.h"
#include "Cdrom.h"
#include "CdromSelectDlg.h"
#include "CdromSpec.h"
#include "CdromSpecDft.h"
#include "resource.h"
#include "Common\SysInfo.h"
#include "Common\NetSend.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Error\Error.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdroms, CIuCdroms_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdroms)
const	CIuVersionNumber versionCdromsMax(2000,1,5,304);
const	CIuVersionNumber versionCdromsMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMS, CIuCdroms, CIuCdroms_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdroms, IDS_ENGINE_PROP_ALTSCANS, GetAltScans_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdroms, IDS_ENGINE_PROP_ALTSCANS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdroms, IDS_ENGINE_PROP_OTHER, GetOther_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdroms, IDS_ENGINE_PROP_OTHER, editorUsePropName)

	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_BUILD, ActionBuild, 0)

	IU_ATTRIBUTE_PAGE(CIuCdroms, IDS_ENGINE_PPG_CDROMS_BUILD, 1, 0)
	IU_ATTRIBUTE_LIST_BEGIN(CIuCdroms, IDS_ENGINE_FLAGS_BUILD)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_DELETE,					cdromsBuildDelete)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_DELETESTART,				cdromsBuildDeleteStart)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_DELETECDROM,				cdromsBuildDeleteCdrom)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_ALT,						cdromsBuildAlt)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_OTHER,						cdromsBuildOther)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUT,						cdromsBuildInput)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTRAW,					cdromsBuildInputRaw)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTSORT,				cdromsBuildInputSort)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTADDRESS,			cdromsBuildInputAddress)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTGEO,					cdromsBuildInputGeo)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTSIC,					cdromsBuildInputSic)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTTOKENS,				cdromsBuildInputTokens)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_INPUTINDEXES,			cdromsBuildInputIndexes)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESS,					cdromsBuildCompress)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSALT,				cdromsBuildCompressAlt)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSADDRESS,		cdromsBuildCompressAddress)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSGEO,				cdromsBuildCompressGeo)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSSIC,				cdromsBuildCompressSic)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSTOKENS,			cdromsBuildCompressTokens)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_COMPRESSBTREE,			cdromsBuildCompressBTree)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_PACK,						cdromsBuildPack)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_PACKDATABASEFILES,		cdromsBuildPackDatabaseFiles)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_PACKDATABASEOBJECTS,	cdromsBuildPackDatabaseObjects)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_PACKAUXILIARYFILES,	cdromsBuildPackAuxiliaryFiles)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_PACKAUXILIARYOBJECTS,	cdromsBuildPackAuxiliaryObjects)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_UPDATE,					cdromsBuildUpdate)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_SPLIT,						cdromsBuildSplit)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_ID,							cdromsBuildID)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_BUILD_DELETEEND,				cdromsBuildDeleteEnd)
	IU_ATTRIBUTE_LIST_END()
	IU_ATTRIBUTE_PROPERTY_FLAGS(CIuCdroms, IDS_ENGINE_PROP_BUILD, IDS_ENGINE_FLAGS_BUILD, GetBuild, SetBuild, 0)
	IU_ATTRIBUTE_EDITOR_FLAGS_LIST(CIuCdroms, IDS_ENGINE_PROP_BUILD, IDS_ENGINE_PPG_CDROMS_BUILD, 14, 0)
	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_STARTBUILD, ActionStartBuild, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdroms, IDS_ENGINE_ACTION_STARTBUILD, IDS_ENGINE_PPG_CDROMS_BUILD, editorAutoUpdate|editorCommand)
	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_ALL, ActionAll, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdroms, IDS_ENGINE_ACTION_ALL, IDS_ENGINE_PPG_CDROMS_BUILD, editorAutoUpdate)
	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_NONE, ActionNone, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdroms, IDS_ENGINE_ACTION_NONE, IDS_ENGINE_PPG_CDROMS_BUILD, editorAutoUpdate)
	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_UPDATE, ActionUpdate, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdroms, IDS_ENGINE_ACTION_UPDATE, IDS_ENGINE_PPG_CDROMS_BUILD, editorAutoUpdate)

	IU_ATTRIBUTE_PAGE(CIuCdroms, IDS_ENGINE_PPG_CDROMS, 50, 0)
	IU_ATTRIBUTE_ACTION(CIuCdroms, IDS_ENGINE_ACTION_SELECTMULTIPLE, ActionSelectMultiple, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuCdroms, IDS_ENGINE_ACTION_SELECTMULTIPLE, IDS_ENGINE_PPG_CDROMS, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuCdroms, IDS_ENGINE_PPG_CDROMS, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdroms, IDS_ENGINE_PROP_NOTIFY, GetNotify, SetNotify, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdroms, IDS_ENGINE_PROP_NOTIFY, IDS_ENGINE_PPG_CDROMS, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdroms, IDS_ENGINE_PROP_DEBUG, IsDebug, SetDebug, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdroms, IDS_ENGINE_PROP_DEBUG, IDS_ENGINE_PPG_CDROMS, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdroms::CIuCdroms() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdroms::~CIuCdroms()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuCdroms::ActionAll(const CIuPropertyCollection&, CIuOutput&)
{
	m_flagsBuild = cdromsBuildAll;
	return CString();
}

CString CIuCdroms::ActionBuild(const CIuPropertyCollection&, CIuOutput& Output)
{
	if (!Build(Output))
		return CString("Aborted!");
	return CString("Success");
}

CString CIuCdroms::ActionNone(const CIuPropertyCollection&, CIuOutput&)
{
	m_flagsBuild = 0;
	return CString();
}

CString CIuCdroms::ActionSelectMultiple(const CIuPropertyCollection&, CIuOutput& Output)
{
	CIuCdromSelectDlg dlg(Output.GetParentWnd());
	if (dlg.DoModal() != IDOK)
		return CString();

	CIuCdromSelectEntryArray Entries;
	dlg.GetEntries(Entries);

	for (int iEntry = 0; iEntry < Entries.GetSize(); ++iEntry)
	{
		CIuCdromSelectEntry& Entry = Entries.ElementAt(iEntry);
		if (!Entry.IsChecked())
			continue;
		if (Entry.GetSpecNo() < 0)
			continue;

		CIuCdromSpec Spec;
		Spec.FromIndex(Entry.GetSpecNo());
		Spec.SetMaxRecords(dlg.GetMaxRecords());

		CIuCdromPtr pCdrom;
		pCdrom.Create();

		Add(pCdrom.Ptr());

		pCdrom->SetSpec(Spec);
	}

	return CString();
}

CString CIuCdroms::ActionStartBuild(const CIuPropertyCollection&, CIuOutput&)
{
	CString sResult;
	sResult.Format("!%s.%s ;\n", LPCTSTR(GetName()), LPCTSTR(S(IDS_ENGINE_ACTION_BUILD)));
	return sResult;
}

CString CIuCdroms::ActionUpdate(const CIuPropertyCollection&, CIuOutput&)
{
	m_flagsBuild = cdromsBuildPackAuxiliaryFiles|cdromsBuildPackAuxiliaryObjects|cdromsBuildUpdate;
	return CString();
}

bool CIuCdroms::Build(CIuOutput& Output)
{
	CIuOutputStateInstance Progress(Output);
	CString sResult = _T("completed successfully");
	IU_TRY_ERROR
	{
		if (!BuildAll(Output))
			sResult = _T("aborted");
	}
	IU_CATCH_ERROR(e)
	{
		Output.Err(e);
		Output.Fire(IU_EVENT_OPERATION_FAIL);
		sResult = _T("failed with an error");
	}

	// Notify anyone if needed
	if (GetNotify().IsEmpty())
		return true;

	CIuSysInfo si;
	CString sComputerName;
	si.GetComputerName(sComputerName);
	if (sComputerName.CompareNoCase(GetNotify()) != 0)
	{
		CString sNotify;
		sNotify.Format("infoUSA Console operation %s on %s.", LPCTSTR(sResult), LPCTSTR(sComputerName));
		NetSend(GetNotify(), sNotify);
	}

	// Display elapsed time
	Progress.Pop(true);
	return true;
}

bool CIuCdroms::Build(CIuOutput& Output, CIuFlags Flags)
{
	if (!GetAltScans().Build(Output, Flags))
		return false;

	if (!GetOther().Build(Output, Flags))
		return false;

	for (int iCdrom = 0; iCdrom < GetCount(); ++iCdrom)
		if (!Get(iCdrom).Build(Output, Flags))
			return false;
	return true;
}

bool CIuCdroms::BuildAll(CIuOutput& Output)
{
	// Delete existing files if needed
	if (GetBuild().Test(cdromsBuildDeleteStart))
		if (!Build(Output, cdromsBuildDeleteStart))
			return false;

	if (GetBuild().Test(cdromsBuildDeleteCdrom))
		if (!Build(Output, cdromsBuildDeleteCdrom))
			return false;

	// Then do the actual build
	if (!Build(Output, (GetBuild() & (~(cdromsBuildDeleteStart|cdromsBuildDeleteCdrom)))))
		return false;

	// If intermediates need to be deleted after the build, do that here
	// If was probably done already, just re-run to be sure.
	if (GetBuild().Test(cdromsBuildDeleteEnd))
	{
		// This is a delete except for the cd-rom		
		if (!Build(Output, cdromsBuildDeleteEnd))
			return false;
	}
	return true;
}

void CIuCdroms::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	// We must have a name because this is usually created from the console as a named object.
	SetName("Cdroms");
	m_fDebug = false;
	m_sNotify = "JohnW1";
#ifdef _DEBUG
	m_flagsBuild = cdromsBuildAll & ~(cdromsBuildAlt|cdromsBuildOther);
#else
	m_flagsBuild = cdromsBuildAll | cdromsBuildDeleteEnd;
#endif
	if (m_pAltScans.IsNull())
	{
		m_pAltScans.Create();
	}
	if (m_pOther.IsNull())
	{
		m_pOther.Create();
	}
	SetVersion(versionCdromsMax);
	//}}Initialize
}

CIuObject* CIuCdroms::GetAltScans_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAltScans.Ptr()));
}

CIuObject* CIuCdroms::GetOther_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pOther.Ptr()));
}

CIuVersionNumber CIuCdroms::GetVersionMax() const
{
	return versionCdromsMax;
}

CIuVersionNumber CIuCdroms::GetVersionMaxStatic()
{
	return versionCdromsMax;
}

CIuVersionNumber CIuCdroms::GetVersionMin() const
{
	return versionCdromsMin;
}

CIuVersionNumber CIuCdroms::GetVersionMinStatic()
{
	return versionCdromsMin;
}

void CIuCdroms::Initialize()
{
	CIuCdroms_super::Initialize();
#ifdef _DEBUG
	// For debugging only... 
	SetDebug(true);

	{
		// You can also select a cd type... usefull for testing
		const int iCount = 2000;
		static LPCTSTR apcszBuild[] =
		{
//			_T("Console"),
//			_T("Ypu_Test_2001"),
//			_T("Rboc_Test_2000"),
			_T("Pf_Test_2001"),
//			_T("Pg_Test_2001"),
//			_T("Pu_Test_2001"),
//			_T("Pb_Test_2001"),
//			_T("104m_Test_2001"),
//			_T("88md_Test_2001"),
			0	
		};
		for (int i = 0; apcszBuild[i]; ++i)
		{
			LPCTSTR pcszBuild = apcszBuild[i];
			CIuCdromSpec Spec(pcszBuild, iCount);

			int iIndex = Add();
			CIuCdrom& Cdrom = Get(iIndex);
			Cdrom.SetSpec(Spec);
		}
	}
#endif
}

CIuCollectablePtr CIuCdroms::OnNew(CWnd* pParent) const
{
	CIuCdromPtr pCdrom;
	pCdrom.Create();
	ASSERT(pCdrom.NotNull());
	if (pParent)
	{
		// If this object is created via a UI. Prompt the user to select
		// a cdrom specification.
		if (!pCdrom->SelectDlg(pParent))
			return CIuCollectablePtr();
	}
	return pCdrom;
}

void CIuCdroms::SetBuild(CIuFlags flagsBuild)
{
	m_flagsBuild = flagsBuild;
}

void CIuCdroms::SetDebug(bool f)
{
	m_fDebug = f;
}

void CIuCdroms::SetNotify(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sNotify = pcsz;
}

