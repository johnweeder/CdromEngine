#include "StdAfx.h"
//{{Include
#include "RecordDefSpec.h"
#include "RecordDefSpecDft.h"
#include "RecordDef.h"
#include "resource.h"
#include "FieldDefSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRecordDefSpec, CIuRecordDefSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordDefSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDDEFSPEC, CIuRecordDefSpec, CIuRecordDefSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuRecordDefSpec, IDS_ENGINE_PPG_RECORDDEFSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordDefSpec, IDS_ENGINE_PROP_LENGTH, GetLength, SetLength, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordDefSpec, IDS_ENGINE_PROP_LENGTH, IDS_ENGINE_PPG_RECORDDEFSPEC, 0, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRecordDefSpec::CIuRecordDefSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRecordDefSpec::~CIuRecordDefSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRecordDefSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iLength = -1;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuRecordDefSpec::CreateFieldDef(LPCTSTR pcszFieldDef)
{
	ASSERT(AfxIsValidString(pcszFieldDef));
	CIuFieldDefSpecPtr pFieldDefSpec;
	pFieldDefSpec.Create();
	pFieldDefSpec->Set(pcszFieldDef);
	m_apFieldDefs.Add(pFieldDefSpec);
}

bool CIuRecordDefSpec::FromIndex(int iIndex)
{
	if (iIndex < 0 || iIndex >= GetCount())
		return false;

	Clear();

	const CIuRecordDefSpecDft* pRecordDefSpec = CIuRecordDefSpecDft::Get(iIndex);

	SetName(pRecordDefSpec->m_pcszRecordDef);
	SetID(CIuID::Create());

	RemoveAllFieldDefs();
	for (int i = 0 ; pRecordDefSpec->m_apcszFields[i]; ++i)
		CreateFieldDef(pRecordDefSpec->m_apcszFields[i]);

	if (pRecordDefSpec->m_iLength > 0)
		SetLength(pRecordDefSpec->m_iLength);

	return true;
}

bool CIuRecordDefSpec::FromName(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	return FromIndex(CIuRecordDefSpecDft::Find(pcszName));
}

bool CIuRecordDefSpec::FromNo(int iRecordDefNo)
{
	return FromIndex(CIuRecordDefSpecDft::Find(iRecordDefNo));
}

int CIuRecordDefSpec::GetCount()
{
	return CIuRecordDefSpecDft::GetCount();
}

CIuFieldDefSpec& CIuRecordDefSpec::GetFieldDef(int iFieldDef) const
{
	ASSERT(iFieldDef >= 0 && iFieldDef < GetFieldDefCount());
	return *m_apFieldDefs[iFieldDef];
}

int CIuRecordDefSpec::GetFieldDefCount() const
{
	return m_apFieldDefs.GetSize();	
}

void CIuRecordDefSpec::GetNames(CStringArray& as)
{
	as.RemoveAll();
	for (int i = 0; i < GetCount(); ++i)
		as.Add(CIuRecordDefSpecDft::Get(i)->m_pcszRecordDef);
}

void CIuRecordDefSpec::RemoveAllFieldDefs() 
{
	m_apFieldDefs.RemoveAll();
}

void CIuRecordDefSpec::SetLength(int iLength)
{
	m_iLength = iLength;
}
