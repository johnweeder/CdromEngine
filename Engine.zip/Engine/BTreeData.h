#ifndef _ENGINE_BTREEDATA_H_
#define _ENGINE_BTREEDATA_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_DATA_H_
#	include "Data\Data.h"
#endif	// _DATA_DATA_H_
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_ENGINE_BTREEINDEXSEPARATOR_H_
#	include "Engine\BTreeIndexSeparator.h"
#endif	// _ENGINE_BTREEINDEXSEPARATOR_H_
#ifndef 	_COMMON_NYBBLEINT_H_
#	include "Common\NybbleInt.h"
#endif	// _COMMON_NYBBLEINT_H_
#ifndef 	_COMMON_NYBBLESTRING_H_
#	include "Common\NybbleString.h"
#endif	// _COMMON_NYBBLESTRING_H_
#ifndef 	_COMMON_NYBBLEDELTA_H_
#	include "Common\NybbleDelta.h"
#endif	// _COMMON_NYBBLEDELTA_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTree)
IU_DEFINE_OBJECT_PTR(CIuBTreeData)
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeData, CIuObject }}
#define CIuBTreeData_super CIuObject

class CIuBTreeData : public CIuBTreeData_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeData)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeData();
	virtual ~CIuBTreeData();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBlockSize() const;
	CIuBTree& GetBTree() const;
	int GetBlocks() const;
	int GetBlockRecordCount() const;
	int GetBlockStartPointerNo() const;
	int GetBlockStartRecordNo() const;
	CIuObjectRepository& GetObjectRepository() const;
	int GetPointerCount() const;
	int GetPointerNo() const;
	CIuNybbleBuffer& GetRecord();
	int GetRecordNo() const;
	int GetRecords() const;
	CIuVersionNumber GetVersion() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	void Goto(int iRecord);
	bool HasObjectRepository() const;
	bool IsDebug() const;
	bool IsOpen() const;
	bool IsPointerInBlock(int iPointer) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Append(const CIuNybbleBuffer& record, int iPointers);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close();
	void Create(CIuOutput& Output);
	void Delete(CIuOutput* pOutput);
	void FindPointer(int iPointer);
	void Open(bool fDebug);
	void ReadBlock(int iBlock);
	bool SanityCheck(CIuOutput& Output);
	void SetBlocks(int i);
	void SetBTree(CIuBTreePtr BTree);
	void SetMinimumRecordSize(int iMinimumRecordSize);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetRecords(int i);
	void SetSpec(CIuBTreeSpec&);
	void SetVersion(CIuVersionNumber);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	CString GetFilename() const;
	CString GetFullFilename() const;
	void WriteBlock();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBTree* m_pBTree;
	// File pointers used during creation
	CIuPrefixFilePtr m_pFile;
	CIuFileVirtualPtr m_pVFile;
	bool m_fAppending;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	// Caching for read
	// Current block
	int m_iBlock;
	// Separator for current block
	CIuBTreeIndexSeparator m_separator;
	// Caching for read/write
	CIuNybbleDelta m_block;
	// Information about the current block
	int m_iBlockStartRecord;
	int m_iBlockStartPointer;
	// Pointers stored in the block... 
	// Used as a sanity check during compression.
	int m_iBlockPointers;
	int m_iBlockRecords;
	// Persistent data
	int m_iRecords;
	int m_iBlocks;
	CIuVersionNumber m_verVersion;
	bool m_fDebug;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBTreeData::GetBlockRecordCount() const
{
	return m_separator.GetRecordCount();
}

inline int CIuBTreeData::GetBlocks() const
{
	return m_iBlocks;
}

inline int CIuBTreeData::GetBlockStartPointerNo() const
{
	return m_iBlockStartPointer;
}

inline int CIuBTreeData::GetBlockStartRecordNo() const
{
	return m_iBlockStartRecord;
}

inline CIuBTree& CIuBTreeData::GetBTree() const
{
	ASSERT(m_pBTree!=0);
	return *m_pBTree;
}

inline CIuObjectRepository& CIuBTreeData::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline int CIuBTreeData::GetPointerCount() const
{
	return m_block.GetCount();
}

inline int CIuBTreeData::GetPointerNo() const
{
	return m_iBlockStartPointer + m_block.GetPrevCount();
}

inline CIuNybbleBuffer& CIuBTreeData::GetRecord() 
{
	return m_block.GetRecord();
}

inline int CIuBTreeData::GetRecordNo() const
{
	return m_iBlockStartRecord + m_block.GetRecordNo();
}

inline int CIuBTreeData::GetRecords() const
{
	return m_iRecords;
}

inline CIuVersionNumber CIuBTreeData::GetVersion() const
{
	return m_verVersion;
}

inline bool CIuBTreeData::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuBTreeData::IsDebug() const
{
	return m_fDebug;
}

#endif // _ENGINE_BTREEDATA_H_

