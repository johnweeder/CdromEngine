#include "StdAfx.h"
//{{Include
#include "AltRawElement.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltRawElement, CIuAltRawElement_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltRawElement)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTRAWELEMENT, CIuAltRawElement, CIuAltRawElement_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltRawElement, IDS_ENGINE_PPG_ALTRAWELEMENT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAltRawElement, IDS_ENGINE_PROP_KEY, GetKey, SetKey, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAltRawElement, IDS_ENGINE_PROP_KEY, IDS_ENGINE_PPG_ALTRAWELEMENT, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuAltRawElement, IDS_ENGINE_PROP_VALUES, GetValues, SetValues, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuAltRawElement, IDS_ENGINE_PROP_VALUES, IDS_ENGINE_PPG_ALTRAWELEMENT, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAltRawElement::CIuAltRawElement() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltRawElement::CIuAltRawElement(CIuAltInstance& Instance)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	m_sKey = Instance.GetKey();
	Instance.GetValues(m_asValues);
}

CIuAltRawElement::~CIuAltRawElement()
{
	// Free next element in chain
	if (m_pNext)
		delete m_pNext;
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuAltRawElement::AddValue(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	return m_asValues.Add(pcsz);
}

void CIuAltRawElement::Append(CIuAltInstance& Instance)
{
	ASSERT(m_sKey.CompareNoCase(Instance.GetKey()) == 0);
	int iValues = Instance.GetValueCount();
	for (int iValue = 0; iValue < iValues; ++iValue)
		m_asValues.Add(Instance.GetValue(iValue));
}

void CIuAltRawElement::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pNext = 0;
	m_sKey = "";
	m_asValues.RemoveAll();
	m_asValues.SetNoCase(true);
	m_asValues.SetDedup(true);
	//}}Initialize
}

void CIuAltRawElement::GetValues(CStringArray& as) const
{
	as.Copy(m_asValues);
}

void CIuAltRawElement::RemoveAllValues()
{
	m_asValues.RemoveAll();
}

void CIuAltRawElement::Serialize(CArchive& ar)
{
	m_asValues.Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_sKey;
	}
	else
	{
		ar >> m_sKey;
	}
}

void CIuAltRawElement::SetKey(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sKey = pcsz;
}

void CIuAltRawElement::SetNext(CIuAltRawElement* pNext)
{
	m_pNext = pNext;
}

void CIuAltRawElement::SetValues(const CStringArray& as)
{
	m_asValues.Copy(as);
}
