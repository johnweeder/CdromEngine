#include "stdafx.h"
#include "engine.h"
#include "MeterTestDlg.h"
#include "Meter.h"
#include "MeterEnableDlg.h"
#include "MeterWarningDlg.h"
#include "Interop\Conversions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterTestDlg, CIuMeterTestDlg_super)
	//{{AFX_MSG_MAP(CIuMeterTestDlg)
	ON_BN_CLICKED(IDC_ENGINE_CORRUPT_METER, OnCorrupt)
	ON_BN_CLICKED(IDC_ENGINE_RESET_METER, OnReset)
	ON_BN_CLICKED(IDC_ENGINE_UPDATE_METER, OnUpdate)
	ON_BN_CLICKED(IDC_ENGINE_SHOW_EXPIRED, OnShowExpired)
	ON_BN_CLICKED(IDC_ENGINE_SHOW_WARNING, OnShowWarning)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterTestDlg::CIuMeterTestDlg(CIuMeter& Meter, CWnd* pParent) : CIuMeterTestDlg_super(CIuMeterTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterTestDlg)
	m_sCount = _T("");
	m_ExpireDate = COleDateTime::GetCurrentTime();
	m_WarningDate = COleDateTime::GetCurrentTime();
	m_LastDate = COleDateTime::GetCurrentTime();
	m_NotifyDate = COleDateTime::GetCurrentTime();
	m_sRemainingRuns = _T("");
	m_fRegistered = FALSE;
	//}}AFX_DATA_INIT
	m_pMeter = &Meter;
}

void CIuMeterTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterTestDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterTestDlg)
	DDX_Control(pDX, IDC_ENGINE_TREE, m_Tree);
	DDX_Text(pDX, IDC_ENGINE_COUNT, m_sCount);
	DDX_DateTimeCtrl(pDX, IDC_ENGINE_EXPIRE_DATE, m_ExpireDate);
	DDX_DateTimeCtrl(pDX, IDC_ENGINE_WARNINGDATE, m_WarningDate);
	DDX_DateTimeCtrl(pDX, IDC_ENGINE_LASTDATE, m_LastDate);
	DDX_DateTimeCtrl(pDX, IDC_ENGINE_NOTIFYDATE, m_NotifyDate);
	DDX_Text(pDX, IDC_ENGINE_REMAININGRUNS, m_sRemainingRuns);
	DDX_Check(pDX, IDC_ENGINE_REGISTERED, m_fRegistered);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CIuMeterTestDlg message handlers

void CIuMeterTestDlg::OnChange()
{
	m_pMeter->GetStatus(m_Tree);
	Int32AsString(m_sCount, m_pMeter->GetCount());
	m_ExpireDate = m_pMeter->GetExpireDate();
	m_WarningDate = m_pMeter->GetWarningDate();
	m_LastDate = m_pMeter->GetLastDate();
	m_NotifyDate = m_pMeter->GetLastNotifyDate();
	Int32AsString(m_sRemainingRuns, m_pMeter->GetRemainingRuns(-1));
	m_fRegistered = m_pMeter->GetRegistered();

	UpdateData(false);
}

void CIuMeterTestDlg::OnCorrupt() 
{
	if (AfxMessageBox("Are you sure you want to set this meter corrupt?", MB_YESNO|MB_APPLMODAL|MB_DEFBUTTON2) != IDYES)
		return ;

	m_pMeter->Corrupt();
	OnChange();
}

BOOL CIuMeterTestDlg::OnInitDialog() 
{ 
	CIuMeterTestDlg_super::OnInitDialog();

	ASSERT(m_pMeter);
	CString sTitle = _T("Meter: ");
	sTitle += m_pMeter->GetName();
	SetWindowText(sTitle);
	
	OnChange();

	CenterWindow();
	
	return TRUE;  
}

void CIuMeterTestDlg::OnOK() 
{
	OnUpdate();
	CIuMeterTestDlg_super::OnOK();
}

void CIuMeterTestDlg::OnReset() 
{
	m_pMeter->Reset();
	OnChange();
}

void CIuMeterTestDlg::OnShowExpired() 
{
	CIuMeterEnableDlg::DoDialog(*m_pMeter, meterEnableExpired, this, true);
}

void CIuMeterTestDlg::OnShowWarning() 
{
	CIuMeterWarningDlg::DoDialog(*m_pMeter, this);
}

void CIuMeterTestDlg::OnUpdate()
{
	UpdateData();

	m_pMeter->SetCount(max(0, StringAsInt32(m_sCount)));
	m_pMeter->SetExpireDate(m_ExpireDate);
	m_pMeter->SetWarningDate(m_WarningDate);
	m_pMeter->SetLastDate(m_LastDate);
	m_pMeter->SetLastNotifyDate(m_NotifyDate);
	m_pMeter->SetRemainingRuns(max(0, StringAsInt32(m_sRemainingRuns)));
	m_pMeter->SetRegistered(m_fRegistered);

	OnChange();
}
