#include "StdAfx.h"
//{{Include
#include "FieldMapSpecDft.h"
#include "FieldMap.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

static const CIuFieldMapSpecDft AddressKeyDft =
{
	mapAddressKey,
	_T("AddressKey"),
	{
		0,
		"CityState",
		"Street",
		"PriNo",
		"SecNo",							
		0
	}
};

static const CIuFieldMapSpecDft AddressStripDft =
{
	mapAddressStrip,
	_T("AddressStrip"),
	{
		0,
		0
	}
};

static const CIuFieldMapSpecDft BusinessKeyDft =
{
	mapBusinessKey,
	_T("BusinessKey"),
	{
		0,
		"SicCode",
		0
	}
};

static const CIuFieldMapSpecDft BusinessFranchiseKeyDft =
{
	mapBusinessFranchiseKey,
	_T("BusinessFranchiseKey"),
	{
		0,
		"SicFranchiseCode",
		0
	}
};

static const CIuFieldMapSpecDft Business1StripDft =
{
	mapBusiness1Strip,
	_T("Business1Strip"),
	{
		"SicCode",
		0,
		0
	}
};

static const CIuFieldMapSpecDft Business6StripDft =
{
	mapBusiness6Strip,
	_T("Business6Strip"),
	{
		"SicCode",
		"SicCode2",
		"SicCode3",
		"SicCode4",
		"SicCode5",
		"SicCode6",
		0,
		0
	}
};

static const CIuFieldMapSpecDft NameKeyDft =
{
	mapNameKey,
	_T("NameKey"),
	{
		0,
		"Name",
		"ZIP",
		0
	}
};

static const CIuFieldMapSpecDft PhoneKeyDft =
{
	mapPhoneKey,
	_T("PhoneKey"),
	{
		0,
		"AcPhone",
		0
	}
};

static const CIuFieldMapSpecDft PhoneStripDft = 
{
	mapPhoneStrip,
	_T("PhoneStrip"),
	{
		"AcPhone",
		0,
		0
	}
};

static const CIuFieldMapSpecDft PriNoTokenDft =
{
	mapPriNoToken,
	_T("PriNoToken"),
	{
		"PriNo",
		0,
		0
	}
};



static const CIuFieldMapSpecDft SecNoTokenDft =
{
	mapSecNoToken,
	_T("SecNoToken"),
	{
		"SecNo",
		0,
		0
	}
};

static const CIuFieldMapSpecDft Sic6Dft =
{
	mapSic6,
	_T("Sic6"),
	{
		"SicCode",
		"SicCode2",
		"SicCode3",
		"SicCode4",
		"SicCode5",
		"SicCode6",
		0,
		0
	}
};

static const CIuFieldMapSpecDft SicSingleDft =
{
	mapSicSingle,
	_T("SicSingle"),
	{
		"SicCode",
		0,
		0
	}
};

static const CIuFieldMapSpecDft StreetTokenDft =
{
	mapStreetToken,
	_T("StreetToken"),
	{
		"Street",
		0,
		0
	}
};

static const CIuFieldMapSpecDft ZipKeyDft =
{
	mapZipKey,
	_T("ZipKey"),
	{
		0,
		"Zip",
		0
	}
};

static const CIuFieldMapSpecDft Zip4KeyDft =
{
	mapZip4Key,
	_T("Zip4Key"),
	{
		0,
		"Zip",
		0
	}
};

static const CIuFieldMapSpecDft Zip5KeyDft =
{
	mapZip5Key,
	_T("Zip5Key"),
	{
		0,
		"Zip",
		0
	}
};

static const CIuFieldMapSpecDft Zip4StripDft =
{
	mapZip4Strip,
	_T("Zip4Strip"),
	{
		"Zip:Left([Zip],9)",
		0,
		0
	}
};

static const CIuFieldMapSpecDft Zip5StripDft =
{
	mapZip5Strip,
	_T("Zip5Strip"),
	{
		"Zip:Left([Zip],5)",
		0,
		0
	}
};

static const CIuFieldMapSpecDft* apFieldMap[] =
{
	// Keys...
	&AddressKeyDft,
	&BusinessKeyDft,
	&BusinessFranchiseKeyDft,
	&NameKeyDft,
	&PhoneKeyDft,
	&ZipKeyDft,
	&Zip4KeyDft,
	&Zip5KeyDft,

	// Key/Value pairs for use by tokenizers
	&PriNoTokenDft,
	&SecNoTokenDft,
	&StreetTokenDft,

	// Mappings....
	&SicSingleDft,
	&Sic6Dft,

	// Strips...
	&AddressStripDft,
	&Business1StripDft,
	&Business6StripDft,
	&PhoneStripDft,
	&Zip4StripDft,
	&Zip5StripDft,
};


/////////////////////////////////////////////////////////////////////////////
// CIuFieldMapSpecDft

int CIuFieldMapSpecDft::Find(LPCTSTR pcszFieldMap)
{
	ASSERT(AfxIsValidString(pcszFieldMap));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszFieldMap, pcszFieldMap) == 0)
			return i;
	}
	return -1;
}

int CIuFieldMapSpecDft::Find(int iFieldMap)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iFieldMap == iFieldMap)
			return i;
	}
	return -1;
}

const CIuFieldMapSpecDft* CIuFieldMapSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return apFieldMap[iWhich];
}

int CIuFieldMapSpecDft::GetCount()
{
	return sizeof(apFieldMap) / sizeof(apFieldMap[0]);
}


