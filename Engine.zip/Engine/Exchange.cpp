#include "StdAfx.h"
//{{Include
#include "Exchange.h"
#include "GeoList.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExchange::GetZipList(CIuGeoList& GeoList) const
{
	GeoList.Extract(((const BYTE*)this) + sizeof(*this));
}
