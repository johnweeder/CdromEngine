#ifndef _ENGINE_COMPAREWILDCARD_H_
#define _ENGINE_COMPAREWILDCARD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCompareWildcard, CObject }}
#define CIuCompareWildcard_super CObject

class CIuCompareWildcard : public CIuCompareWildcard_super
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCompareWildcard();
	CIuCompareWildcard(const CIuCompareWildcard& rCompareWildcard);
	virtual ~CIuCompareWildcard();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int Compare(LPCTSTR pcsz, bool* pfPartial = 0) const;
	void SetExpression(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuCompareWildcard& operator=(const CIuCompareWildcard& rCompareWildcard);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sExpression;
	int m_iLength;
	bool m_fWildcard;
//}}Data
};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_COMPAREWILDCARD_H_
