#include "stdafx.h"
//{{Include
#include "engine.h"
#include "resource.h"
#include "ExportFieldDef.h"
#include "ExportFieldDefSpec.h"
#include "RecordDef.h"
#include "FieldDefSpec.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportFieldDef, CIuExportFieldDef_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportFieldDef)
const	CIuVersionNumber versionExportFieldDefMax(2000,1,5,304);
const	CIuVersionNumber versionExportFieldDefMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTFIELDDEF, CIuExportFieldDef, CIuExportFieldDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_EXPRESSION, GetExpression, SetExpression, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_SHORTNAME, GetShortName, SetShortName, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_LONGNAME, GetLongName, SetLongName, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExportFieldDef, IDS_ENGINE_PROP_LENGTH, GetLength, SetLength, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExportFieldDef, IDS_ENGINE_PROP_OFFSET, GetOffset, SetOffset, 0)

	IU_ATTRIBUTE_PAGE(CIuExportFieldDef, IDS_ENGINE_PPG_EXPORTFIELDDEF, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_LONGNAME, IDS_ENGINE_PPG_EXPORTFIELDDEF, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_SHORTNAME, IDS_ENGINE_PPG_EXPORTFIELDDEF, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_EXPRESSION, IDS_ENGINE_PPG_EXPORTFIELDDEF, 1, editorEdit)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportFieldDef, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_EXPORTFIELDDEF, 1, 0)
	IU_ATTRIBUTE_EDITOR_ALLOWED_VALUES(CIuExportFieldDef, IDS_ENGINE_PROP_EXPRESSION, GetExpressionAllowed, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExportFieldDef, IDS_ENGINE_PROP_LENGTH, IDS_ENGINE_PPG_EXPORTFIELDDEF, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExportFieldDef, IDS_ENGINE_PROP_OFFSET, IDS_ENGINE_PPG_EXPORTFIELDDEF, -1, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuExportFieldDef::CIuExportFieldDef()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportFieldDef::CIuExportFieldDef(const CIuExportFieldDef& rExportFieldDef)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rExportFieldDef;
}

CIuExportFieldDef::~CIuExportFieldDef()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExportFieldDef::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("Name");
	m_sExpression.Empty();
	m_sOptions = "";
	m_iLength = -1;
	m_iOffset = -1;
	m_sLongName = "";
	m_sShortName = "";
	SetVersion(versionExportFieldDefMax);
	//}}Initialize
}

void CIuExportFieldDef::Copy(const CIuObject& object)
{
	CIuExportFieldDef_super::Copy(object);

	const CIuExportFieldDef* pExportFieldDef = dynamic_cast<const CIuExportFieldDef*>(&object);
	if (pExportFieldDef == 0 || pExportFieldDef == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuExportFieldDef)));
	
	SetName(pExportFieldDef->GetName());
	SetOptions(pExportFieldDef->GetOptions());
	SetExpression(pExportFieldDef->GetExpression());
	SetLength(pExportFieldDef->GetLength());
	SetOffset(pExportFieldDef->GetOffset());
	SetLongName(pExportFieldDef->GetLongName());
	SetShortName(pExportFieldDef->GetShortName());
}

void CIuExportFieldDef::GetExpressionAllowed(CStringArray& as) const
{
	CIuFieldDefSpec::GetNames(as);
}

CString CIuExportFieldDef::GetSpecification() const
{
	CIuFieldDefSpec spec;
	spec.SetExpression(GetExpression());
	spec.SetLength(GetLength());
	spec.SetLongName(GetLongName());
	spec.SetName(GetName());
	spec.SetOffset(GetOffset());
	spec.SetOptions(GetOptions());
	spec.SetShortName(GetShortName());
	return spec.GetSpecification();
}

CIuVersionNumber CIuExportFieldDef::GetVersionMax() const
{
	return versionExportFieldDefMax;
}

CIuVersionNumber CIuExportFieldDef::GetVersionMaxStatic()
{
	return versionExportFieldDefMax;
}

CIuVersionNumber CIuExportFieldDef::GetVersionMin() const
{
	return versionExportFieldDefMin;
}

CIuVersionNumber CIuExportFieldDef::GetVersionMinStatic()
{
	return versionExportFieldDefMin;
}

CIuExportFieldDef& CIuExportFieldDef::operator=(const CIuExportFieldDef& rExportFieldDef)
{
	Copy(rExportFieldDef);
	return *this;
}

void CIuExportFieldDef::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
}

void CIuExportFieldDef::SetLength(int iLength)
{
	m_iLength = iLength;
}

void CIuExportFieldDef::SetLongName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongName = pcsz;
}

void CIuExportFieldDef::SetOffset(int iOffset)
{
	m_iOffset = iOffset;
}

void CIuExportFieldDef::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuExportFieldDef::SetShortName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sShortName = pcsz;
}

void CIuExportFieldDef::SetSpec(LPCTSTR pcszDef)
{
	CIuExportFieldDefSpec spec(pcszDef, true);
	SetSpec(spec);
}

void CIuExportFieldDef::SetSpec(CIuExportFieldDefSpec& Spec)
{
	// Update the field information
	// NOTE: This is more of an "update" than a "create".
	// To perform a true create, do a clear first.
	SetName(Spec.GetName());
	int iLength = Spec.GetLength();
	if (iLength < 0)
		iLength = 255;
	if (iLength > 0)
		SetLength(iLength);
	if (GetLength() <= 0)
		SetLength(255);
	if (Spec.GetOffset() >= 0)
		SetOffset(Spec.GetOffset());
	if (!Spec.GetLongName().IsEmpty())
		SetLongName(Spec.GetLongName());
	if (!Spec.GetShortName().IsEmpty())
		SetShortName(Spec.GetShortName());
	if (!Spec.GetExpression().IsEmpty())
		SetExpression(Spec.GetExpression());
	if (!Spec.GetOptions().IsEmpty())
		SetOptions(Spec.GetOptions());
}
