#ifndef _ENGINE_QUERIES_H_ 
#define _ENGINE_QUERIES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_QUERY_H_
#	include "Engine\Query.h"
#endif	// _ENGINE_QUERY_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuQueries)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuQueries, CIuCollection }}
#define CIuQueries_super CIuCollection

class IU_CLASS_EXPORT CIuQueries : public CIuQueries_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuQueries)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuQueries();           // protected constructor used by dynamic creation
	virtual ~CIuQueries();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuQuery& Get(LPCTSTR s) const;
	CIuQuery& Get(int iIndex) const;
	CIuQuery& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	void CancelAll();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnAdd(int);
	virtual CIuCollectablePtr OnNew(CWnd*) const;
	virtual void OnRemove(int);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	friend class CIuEngine;
	 
	void CommonConstruct();
	void SetEngine(CIuEngine& Engine);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuQuery& CIuQueries::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuQuery*>(&CIuCollection::Get(s));
}

inline CIuQuery& CIuQueries::Get(int iIndex) const
{
	return *dynamic_cast<CIuQuery*>(&CIuCollection::Get(iIndex));
}

inline CIuQuery& CIuQueries::Get(CIuID id) const
{
	return *dynamic_cast<CIuQuery*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuQueries::GetEngine() const 
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

#endif // _ENGINE_QUERIES_H_
