#include "StdAfx.h"
//{{Include
#include "RegEx.h"
#include "resource.h"
#include "Common\String.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRegEx, CIuRegEx_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRegEx)
const TCHAR regExCharMin		= 0x20;	// The minimum char value accepted
const TCHAR regExCharMax		= 0x7E;	// The maximum char value accepted
//}}Implement

CIuRegEx::CIuRegEx()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRegEx::CIuRegEx(const CIuRegEx& rRegEx)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rRegEx;
}

CIuRegEx::CIuRegEx(LPCTSTR pcszExpression, int iFlags)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	if (pcszExpression)
		SetExpression(pcszExpression, iFlags);
}

CIuRegEx::~CIuRegEx()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuRegEx::BuildExpression()
{
	CString sExpression = BuildGlobals(m_iFlags);
	for (int iExpr = 0; iExpr < m_aiFlags.GetSize(); ++iExpr)
	{
		if (iExpr > 0)
			sExpression += ',';

		int iFlags = m_aiFlags[iExpr];

		if ((iFlags & regExHasParsedNot) != 0)
			sExpression += '-';
		if ((iFlags & regExHasParsedWithin) != 0)
			sExpression += '!';
		if ((iFlags & regExHasParsedPhonetic) != 0)
			sExpression += '%';
		sExpression += m_asLo[iExpr];
		if ((iFlags & regExHasTermRange) != 0)
		{
			sExpression += '~';
			sExpression += m_asHi[iExpr];
		}
	}
	return sExpression;
}

CString CIuRegEx::BuildGlobals(int iFlags)
{
	if ((iFlags & (regExHasGlobalWildcard|regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin)) == 0)
		return CString();
	CString sExpression;
	sExpression += '{';
	if ((iFlags & regExHasGlobalWildcard) != 0)
		sExpression += '*';
	if ((iFlags & regExHasGlobalNot) != 0)
		sExpression += '-';
	if ((iFlags & regExHasGlobalWithin) != 0)
		sExpression += '!';
	if ((iFlags & regExHasGlobalPhonetic) != 0)
		sExpression += '%';
	sExpression += '}';
	return sExpression;
}

CString CIuRegEx::CleanExpression(LPCTSTR pcsz, int& iTermFlags, int& iGlobalFlags)
{
	CString sClean;

	while (*pcsz)
	{
		switch (*pcsz)
		{
			case '^':
#ifdef _DEBUG
				// As a special case, use the caret to form
				// a separator in debug mode
				if ((iGlobalFlags & regExSeparator) != 0)
				{
					sClean += _T("\\t");
					iTermFlags |= regExHasTermSeparator;
				}
				else
					sClean += _T("\\^");
				++pcsz;
				break;
#else
				// fall through
#endif
			case ',':
			case '~':
			case '!':
			case '%':
			case '-':
			case '{':
			case '}':
			case '\'':
			case '\"':
				// These are all special characters and they get escaped
				sClean += _T('\\');
				sClean += *pcsz;
				++pcsz;
				break;
			case '?':
				// The question mark has a special meaning in expressions
				// Otherwise, escape it
				if ((iGlobalFlags & regExRegEx) == 0)
					sClean += _T('\\');
				else
					iTermFlags |= regExHasTermRegEx;
				sClean += *pcsz;
				++pcsz;
				break;
			case '*':
				// The question mark has a special meaning in expressions or wildcards
				// Otherwise, escape it
				if ((iGlobalFlags & regExRegEx) == 0 && ((iGlobalFlags & regExWildcard) == 0 || pcsz[1] != '\0'))
					sClean += _T('\\');
				else
				{
					if ((iGlobalFlags & regExWildcard) != 0 || pcsz[1] == '\0')
						iTermFlags |= regExHasTermWildcard;
					else // if ((iGlobalFlags & regExRegEx) != 0)
						iTermFlags |= regExHasTermRegEx;
				}
				sClean += *pcsz;
				++pcsz;
				break;
			case '\t':
				// The tab is a separator. Otherwise, drop it.
				if ((iGlobalFlags & regExSeparator) != 0)
				{
					sClean += _T("\\t");
					iTermFlags |= regExHasTermSeparator;
				}
				++pcsz;
				break;
			case '\\':
			{
				// Leave escape sequences as-is (as long as they escape a valid character)
				++pcsz;
				ASSERT(*pcsz != '\0');
				TCHAR ch = *pcsz;
				++pcsz;
				if (BYTE(ch) >= regExCharMin && BYTE(ch) <= regExCharMax)
				{
					sClean += '\\';
					sClean += ch;
				}
				break;
			}
			default:
			{
				// Keep an other valid characters.
				// Upper case if not case sensitive
				// Otherwise, drop them
				TCHAR ch = *pcsz;
				++pcsz;
				if (BYTE(ch) >= regExCharMin && BYTE(ch) <= regExCharMax)
				{
					if ((iGlobalFlags & regExCaseSensitive) == 0)
						ch = (TCHAR)_totupper(ch);
					sClean += ch;
				}
				break;
			}
		}
	}

	return sClean;
}

CString CIuRegEx::CleanName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	pcsz = _tcsskipws(pcsz);
	bool fBracket = false;
	if (*pcsz == '[')
	{
		fBracket = true;
		++pcsz;		
	}

	CString sName;

	// Clean up the name. Remove non-alpha/num, underscore or dollar sign.
	for (; *pcsz; ++pcsz)
	{
		TCHAR ch = *pcsz;
		if (fBracket && ch == ']')
			break;
		if (_istalnum(ch) || ch == '_' || ch == '$' || ch == '.')
			sName += ch;
	}

	// Trim the name string.
	sName.TrimLeft();
	sName.TrimRight();
	return sName;
}

void CIuRegEx::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sExpression = "";
	m_iFlags = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

CString CIuRegEx::Convert(LPCTSTR pcszName, LPCTSTR pcszExpression, int iFlags)
{
	CString sName = ConvertName(pcszName);
	CString sExpression = ConvertExpression(pcszExpression, iFlags);
	
	if (sName.IsEmpty())
		return sExpression;
	else if (sExpression.IsEmpty())
		return sName;

	sName += _T("=");
	sName += sExpression;

	return sName;
}

CString CIuRegEx::ConvertExpression(LPCTSTR pcszExpression, int iFlags)
{
	// Static function to properly format an expression string.
	// Since this function is primarily used to build a query for the engine,
	// we automatically add quotes around the value returned.
	CIuRegEx RegEx(pcszExpression, iFlags);
	CString sExpression;
	sExpression += _T("\'");
	sExpression += RegEx.GetExpression();
	sExpression += _T("\'");
	return sExpression;
}

CString CIuRegEx::ConvertName(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	CString sName;
	if (pcszName)
	{
		sName += _T("[");
		sName += CleanName(pcszName);
		sName += _T("]");
	}
	return sName;
}

void CIuRegEx::Copy(const CIuObject& object)
{
	CIuRegEx_super::Copy(object);

	const CIuRegEx* pRegEx = dynamic_cast<const CIuRegEx*>(&object);
	if (pRegEx == 0 || pRegEx == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuRegEx)));
	m_sExpression = pRegEx->m_sExpression;
	m_iFlags = pRegEx->m_iFlags;
	m_aiFlags.Copy(pRegEx->m_aiFlags);
	m_asLo.Copy(pRegEx->m_asLo);
	m_asHi.Copy(pRegEx->m_asHi);
}

CString CIuRegEx::CreateExpression(int iFlags, LPCTSTR pcszExpression)
{
	ASSERT(AfxIsValidString(pcszExpression));
	CIuRegEx RegEx(pcszExpression, iFlags);

	CString sExpression;
	sExpression += _T("\'");
	if ((iFlags & (regExHasGlobalWildcard|regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin)) != 0)
	{
		sExpression += BuildGlobals(iFlags);
		iFlags |= regExGlobal;
		if ((iFlags & regExHasGlobalWildcard) != 0)
			iFlags |= regExWildcard;
		if ((iFlags & (regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin)) != 0)
			iFlags |= regExRegEx;
	}
	sExpression += RegEx.GetExpression();
	if ((iFlags & regExAddWildcard) != 0)
	{
		sExpression += _T("*");
		iFlags |= regExWildcard;
	}
	sExpression += _T("\'");
	return sExpression;
}

CString CIuRegEx::CreateExpressionF(int iFlags, LPCTSTR pcszExpression, ...)
{
	ASSERT(AfxIsValidString(pcszExpression));
	va_list args;
	va_start(args, pcszExpression);
	CString sFormat;
	sFormat.FormatV(pcszExpression, args);
	va_end(args);
	return CreateExpression(iFlags, sFormat);
}

CString CIuRegEx::CreateLikeClause(LPCTSTR pcszName, LPCTSTR pcszExpression) const
{
	// Create a "like" clause... over-riding either/both the existing name and expression.
	// The passed name and expression are assumed to be valid and will not be cleaned
	CString sFilter;
	sFilter += _T("[");
	if (pcszName)
		sFilter += pcszName;
	else
		sFilter += GetName();
	sFilter += _T("] LIKE '");
	if (pcszExpression)
		sFilter += pcszExpression;
	else
		sFilter += GetExpression();
	sFilter += _T("'");
	return sFilter;
}

int CIuRegEx::GetMasterFlags() const
{
	return GetMasterFlags(GetExpression());
}

int CIuRegEx::GetMasterFlags(LPCTSTR pcsz)
{
	// Given a string, simply parse through it to determine those options
	// which are present in the string.
	// Start by allowing everything.
	int iFlags = regExAll;
	// Parse off globals
	ASSERT(AfxIsValidString(pcsz));
	pcsz = CIuRegEx::ParseGlobal(pcsz, iFlags);

	// Start by assuming all are negated
	iFlags |= regExHasAllNegated;

	// Parse term by term
	while (*pcsz)
	{
		int iTermFlags = 0;
		CString sLo;
		CString sHi;
		pcsz = ParseExpression(pcsz, sLo, sHi, iTermFlags, iFlags);
		CString sCleanLo = CleanExpression(sLo, iTermFlags, iFlags);
		CString sCleanHi = CleanExpression(sHi, iTermFlags, iFlags);

		// Master flags are an accumulation of all the terms
		iFlags |= iTermFlags;
	}

	// Only return the flags of the things which were found
	return iFlags & regExHasMask;
}

int CIuRegEx::GetTerms() const
{
	return m_aiFlags.GetSize();	
}

int CIuRegEx::GetTerm(int iTerm, CString& sLo, CString& sHi) const
{
	ASSERT(iTerm >= 0 && iTerm < m_aiFlags.GetSize());

	sLo = m_asLo[iTerm];
	sHi = m_asHi[iTerm];

	// Return the flags for the term and the global flags
	return m_aiFlags[iTerm]|m_iFlags;
}

CIuRegEx& CIuRegEx::operator=(const CIuRegEx& rRegEx)
{
	Copy(rRegEx);
	return *this;
}

LPCTSTR CIuRegEx::ParseExpression(LPCTSTR pcsz, CString& sLo, CString& sHi, int& iTermFlags, int& iGlobalFlags)
{
	sLo = "";
	sHi = "";
	iTermFlags = 0;

	// Parse off leading options
	while (*pcsz)
	{
		if (*pcsz == '-' && (iGlobalFlags & (regExRegEx|regExRange)) != 0)
		{
			iTermFlags |= regExHasTermNot|regExHasParsedNot;
			++pcsz;
		}
		else if (*pcsz == '!' && (iGlobalFlags & regExRegEx) != 0)
		{
			iTermFlags |= regExHasTermWithin|regExHasParsedWithin;
			++pcsz;
		}
		else if (*pcsz == '%' && (iGlobalFlags & regExRegEx) != 0)
		{
			iTermFlags |= regExHasTermPhonetic|regExHasParsedPhonetic;
			++pcsz;
		}
		else
			break;
	}

	// Manage the master negation flag
	if ((iGlobalFlags & regExHasGlobalNot) == 0 && (iTermFlags & regExHasTermNot) == 0)
		iGlobalFlags &= ~regExHasAllNegated;

	// Parse lo
	while (*pcsz)
	{
		// If start of new list element, done.
		if (*pcsz == ',' && (iGlobalFlags & regExList) != 0)
		{
			break;
		}
		// If start of a range, done.
		else if (*pcsz == '~' && (iGlobalFlags & regExRange) != 0)
		{
			break;
		}
		else if (*pcsz == '\\')
		{
			if (pcsz[1])
			{
				sLo += pcsz[0];
				sLo += pcsz[1];
				pcsz += 2;
			}
			else
			{
				sLo += _T("\\\\");
				++pcsz;
			}
		}
		else
		{
			sLo += *pcsz;
			++pcsz;
		}
	}

	// Parse hi
	if (*pcsz == '~' && (iGlobalFlags & regExRange) != 0)
	{
		iTermFlags |= regExHasTermRange;
		++pcsz;

		while (*pcsz)
		{
			// If start of new list element, done.
			if (*pcsz == ',' && (iGlobalFlags & regExList) != 0)
			{
				break;
			}
			else if (*pcsz == '\\')
			{
				if (pcsz[1])
				{
					sHi += pcsz[0];
					sHi += pcsz[1];
					pcsz += 2;
				}
				else
				{
					sHi += _T("\\\\");
					++pcsz;
				}
			}
			else
			{
				sHi += *pcsz;
				++pcsz;
			}
		}
	}

	// Skip expression separator
	if (*pcsz == ',' && (iGlobalFlags & regExList) != 0)
	{
		++pcsz;
		iTermFlags |= regExHasTermList;
	}
	else if (*pcsz != '\0')
	{
		ASSERT(false);
	}

	// Trim if necessary
	if ((iGlobalFlags & regExIgnoreWhitespace) != 0)
	{
		sLo.TrimLeft();
		sLo.TrimRight();
		sHi.TrimLeft();
		sHi.TrimRight();
	}

	// If a globals flag is set, it implies that a term has that flag
	if ((iGlobalFlags & regExHasGlobalWildcard) != 0)
		iTermFlags |= regExHasTermWildcard;
	if ((iGlobalFlags & regExHasGlobalNot) != 0)
		iTermFlags |= regExHasTermNot;
	if ((iGlobalFlags & regExHasGlobalPhonetic) != 0)
		iTermFlags |= regExHasTermPhonetic;
	if ((iGlobalFlags & regExHasGlobalWithin) != 0)
		iTermFlags |= regExHasTermWithin;
	if ((iTermFlags & regExHasTermRange) != 0)
		iTermFlags &= ~(regExHasParsedPhonetic|regExHasParsedWithin|regExHasTermPhonetic|regExHasTermWithin);

	return pcsz;
}

void CIuRegEx::ParseExpressions(LPCTSTR pcsz)
{
	// Clear to start
	m_aiFlags.RemoveAll();
	m_asLo.RemoveAll();
	m_asHi.RemoveAll();

	m_iFlags |= regExHasAllNegated;

	// Break it into pieces
	while (*pcsz)
	{
		int iFlags = 0;
		CString sLo;
		CString sHi;

		pcsz = ParseExpression(pcsz, sLo, sHi, iFlags, m_iFlags);

		// Save this sub expression
		CString sCleanLo = CleanExpression(sLo, iFlags, m_iFlags);
		m_asLo.Add(sCleanLo);
		CString sCleanHi = CleanExpression(sHi, iFlags, m_iFlags);
		m_asHi.Add(sCleanHi);
		m_aiFlags.Add(iFlags);
	}

	// Make sure we have at least one!
	if (m_aiFlags.GetSize() == 0)
	{
		m_aiFlags.Add(0);
		m_asLo.Add(CString());
		m_asHi.Add(CString());
	}
}

LPCTSTR CIuRegEx::ParseGlobal(LPCTSTR pcsz, int& iFlags)
{
	// Only parse globals if expected
	if ((iFlags & regExGlobal) == 0)
		return pcsz;
	
	if (*pcsz != '{')
		return pcsz;

	++pcsz;
	for (; *pcsz && *pcsz != '}'; ++pcsz)
	{
		switch (*pcsz)
		{
			case '*':
				if ((iFlags & (regExRegEx|regExWildcard)) != 0)
					iFlags |= regExHasGlobalWildcard;
				break;
			case '!':
				if ((iFlags & regExRegEx) != 0)
					iFlags |= regExHasGlobalWithin;
				break;
			case '%':
				if ((iFlags & regExRegEx) != 0)
					iFlags |= regExHasGlobalPhonetic;
				break;
			case '-':
				if ((iFlags & (regExRegEx|regExRange)) != 0)
					iFlags |= regExHasGlobalNot;
				break;
			default:
				TRACE("WARNING: CIuRegEx::SetExpression() has unrecognized global option: '%s'\n", pcsz);
				break;
		}
	}
	if (*pcsz == '}')
		++pcsz;
	return pcsz;
}

void CIuRegEx::SetExpression(LPCTSTR pcsz, int iFlags)
{
	ASSERT(AfxIsValidString(pcsz));

	// Remove conflicting flags

	// Keys can not have expressions
	if ((iFlags & regExSeparator) != 0)
		iFlags &= ~regExRegEx;

	// Mask off lower 16 bits of flags and save
	m_iFlags = regExAll & iFlags;

	// If there are global options, parse them off.
	pcsz = ParseGlobal(pcsz, m_iFlags);

	// Parse off all the sub expressions
	ParseExpressions(pcsz);

	// Build the optimized output expression 
	m_sExpression = BuildExpression();
}

void CIuRegEx::SetName(LPCTSTR pcsz)
{
	CString sName = CleanName(pcsz);
	CIuRegEx_super::SetName(sName);
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(RegEx, pv)
{
	UNUSED_ALWAYS(pv);


	struct CIuRegExTest
	{
		LPCTSTR m_pcszInput;
		int m_iInputFlags;
		LPCTSTR m_pcszExpected;
		int m_iExpectedFlags;
		int m_iTerms;
		LPCTSTR m_pcszTerms;
	};

	static const CIuRegExTest aTest[] = 
	{
		{
			"Omaha",
			regExSimple|regExCaseSensitive,
			"'Omaha'",
			0,
			1,
			"Omaha\0"
		},{ 
			"Omaha",
			regExSimple,
			"'OMAHA'",
			0,
			1,
			"OMAHA\0"
		},{ 
			" Omaha\t ",
			regExSimple|regExIgnoreWhitespace,
			"'OMAHA'",
			0,
			1,
			"OMAHA\0"
		},{ 
			"Om*aha*",
			regExSimple|regExWildcard,
			"'OM\\*AHA*'",
			0,
			1,
			"OM\\*AHA*\0"
		},{ 
			"Omaha\tNE\\tMain St^123",
			regExSimple|regExSeparator,
			"'OMAHA\\tNE\\tMAIN ST\\t123'",
			0,
			1,
			"OMAHA\\tNE\\tMAIN ST\\t123\0"
		},{ 
			"{!*%-}Omaha~Papillion,H?mp*rey*,-%!Lindsay",
			regExSimple,
			"'\\{\\!\\*\\%\\-\\}OMAHA\\~PAPILLION\\,H\\?MP\\*REY\\*\\,\\-\\%\\!LINDSAY'",
			0,
			1,
			"\\{\\!\\*\\%\\-\\}OMAHA\\~PAPILLION\\,H\\?MP\\*REY\\*\\,\\-\\%\\!LINDSAY\0"
		},{ 
			"{!*%-}Omaha~Papillion,H?mp*rey*,-%!Lindsay",
			regExSimple|regExGlobal|regExRegEx,
			"'{*-!%}OMAHA\\~PAPILLION\\,H?MP*REY*\\,\\-\\%\\!LINDSAY'",
			regExHasGlobalWildcard|regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin|regExHasAllNegated,
			1,
			"OMAHA\\~PAPILLION\\,H?MP*REY*\\,\\-\\%\\!LINDSAY\0"
		},{ 
			"{!*%-}Omaha~Papillion,H?mp*rey*,-%!Lindsay",
			regExSimple|regExGlobal|regExRegEx|regExList,
			"'{*-!%}OMAHA\\~PAPILLION,H?MP*REY*,-!%LINDSAY'",
			regExHasGlobalWildcard|regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin|regExHasAllNegated,
			3,
			"OMAHA\\~PAPILLION\0\0H?MP*REY*\0\0LINDSAY\0"
		},{ 
			"{!*%-}Omaha~Papillion,H?mp*rey*,-%!Lindsay",
			regExSimple|regExGlobal|regExRegEx|regExList|regExRange,
			"'{*-!%}OMAHA~PAPILLION,H?MP*REY*,-!%LINDSAY'",
			regExHasGlobalWildcard|regExHasGlobalNot|regExHasGlobalPhonetic|regExHasGlobalWithin|regExHasAllNegated,
			3,
			"OMAHA\0PAPILLION\0H?MP*REY*\0\0LINDSAY\0"
		},{ 
			0
		}
	};

	for (int i = 0; aTest[i].m_pcszInput; ++i)
	{
		LPCTSTR pcszInput = aTest[i].m_pcszInput;
		int iInputFlags = aTest[i].m_iInputFlags;
		CString sOutput = CIuRegEx::ConvertExpression(pcszInput, iInputFlags);
		LPCTSTR pcszExpected = aTest[i].m_pcszExpected;
		ASSERT(sOutput.Compare(pcszExpected) == 0);

		CIuRegEx RegEx(pcszInput, iInputFlags);

		int iOutputFlags = RegEx.GetFlags();
		int iExpectedFlags = aTest[i].m_iExpectedFlags|aTest[i].m_iInputFlags;
		ASSERT(iOutputFlags == iExpectedFlags);

		int iTerms = RegEx.GetTerms();
		ASSERT(iTerms == aTest[i].m_iTerms);

		for (int iTerm = 0; iTerm < iTerms; ++iTerm)
		{
			CString sLo;
			CString sHi;
			int iFlags = RegEx.GetTerm(iTerm, sLo, sHi);

			LPCTSTR pcszExpectLo = StringGetNth(aTest[i].m_pcszTerms, iTerm * 2);
			ASSERT(sLo.Compare(pcszExpectLo) == 0);
			if ((iFlags & regExHasTermRange) != 0)
			{
				LPCTSTR pcszExpectHi = StringGetNth(aTest[i].m_pcszTerms, iTerm * 2 + 1);
				ASSERT(sHi.Compare(pcszExpectHi) == 0);
			}
			else
			{
				ASSERT(sHi.Compare("") == 0);
			}
		}
	}

	return 0;	
}
IU_TEST_END()
#endif
