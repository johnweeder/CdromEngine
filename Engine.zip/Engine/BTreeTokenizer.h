#ifndef _ENGINE_BTREETOKENIZER_H_
#define _ENGINE_BTREETOKENIZER_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_BTREETOKENIZER_H_
#	include "Engine\BTreeTokenizer.h"
#endif	// _ENGINE_BTREETOKENIZER_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_TOKENCODEC_H_
#	include "Engine\TokenCodec.h"
#endif	// _ENGINE_TOKENCODEC_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeTokenizer)
IU_DEFINE_OBJECT_PTR(CIuTokenMap)
IU_DEFINE_OBJECT_PTR(CIuToken)
class CIuBTreeTokenizers;
class CIuCdrom;
class CIuResolveSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// BTree Tokenizer types
enum CIuBTreeTokenizerNo
{
	btreeTokenizerNone = 0,

	btreeTokenizerPriNo, 
	btreeTokenizerSecNo,
	btreeTokenizerStreet, 
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeTokenizer, CIuCollectable }}
#define CIuBTreeTokenizer_super CIuCollectable

class CIuBTreeTokenizer : public CIuBTreeTokenizer_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeTokenizer)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeTokenizer();
	virtual ~CIuBTreeTokenizer();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBitsRequired() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuToken& GetToken() const;
	CIuBTreeTokenizers& GetTokenizers() const;
	CIuMoniker GetTokenMoniker() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool HasToken() const;
	bool HasTokenizers() const;
	CIuTokenCodec& GetInstance() const;
	bool IsExceptional() const;
	bool IsOpen() const;
	bool IsOptional() const;
	bool IsValid() const;
	CIuTokenMap& GetMap() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Close(bool fForce = false);
	void Decode(int iTokenNo, CIuStringBuffer& output) const;
	int Encode(const CIuRecord& Record) const;
	void MakeRecordDef(CIuRecordDef& RecordDef);
	void Open();
	void Resolve(CIuResolveSpec& Spec);
	void SetExceptional(bool);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetOpen(bool);
	void SetOptional(bool = true);
	void SetSpec(CIuBTreeTokenizerSpec& Spec);
	void SetTokenMoniker(const CIuMoniker&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetInstance_() const;
	CIuObject* GetMap_() const;
private:
	void CommonConstruct();
	void SetToken(CIuToken* pToken);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuTokenPtr m_pToken;

	CIuRecordPtr m_pRecordKey;
	int m_iOpen;
	CIuMoniker m_monikerTokenMoniker;
	CIuTokenMapPtr m_pMap;
	mutable CIuTokenCodecPtr m_pInstance;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	// This flag is set if the token is optional. In other words,
	// the token will only be stored if the key exists.
	bool m_fOptional;
	bool m_fExceptional;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuTokenCodec& CIuBTreeTokenizer::GetInstance() const
{
	return m_pInstance.Ref();
}

inline CIuTokenMap& CIuBTreeTokenizer::GetMap() const
{
	return m_pMap.Ref();
}

inline CIuObjectRepository& CIuBTreeTokenizer::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuToken& CIuBTreeTokenizer::GetToken() const
{
	ASSERT(IsOpen());
	ASSERT(m_pToken.NotNull());
	return m_pToken.Ref();
}

inline CIuMoniker CIuBTreeTokenizer::GetTokenMoniker() const
{
	return m_monikerTokenMoniker;
}

inline bool CIuBTreeTokenizer::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuBTreeTokenizer::HasToken() const
{
	return m_pToken.NotNull();
}

inline bool CIuBTreeTokenizer::HasTokenizers() const
{
	return HasCollection();
}

inline bool CIuBTreeTokenizer::IsExceptional() const
{
	return m_fExceptional;
}

inline bool CIuBTreeTokenizer::IsOpen() const
{
	return m_iOpen > 0;
}

inline bool CIuBTreeTokenizer::IsOptional() const
{
	return m_fOptional;
}

#endif // _ENGINE_BTREETOKENIZER_H_
