#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "ReportDefs.h"
#include "CdromSpec.h"
#include "resource.h"
#include "ReportDef.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuReportDefs, CIuReportDefs_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuReportDefs)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REPORTDEFS, CIuReportDefs, CIuReportDefs_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuReportDefs, IDS_ENGINE_PPG_REPORTDEFS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuReportDefs, IDS_ENGINE_PPG_REPORTDEFS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuReportDefs::CIuReportDefs()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReportDefs::~CIuReportDefs()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuReportDefs::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int iReportDef = 0; iReportDef < GetCount(); ++iReportDef)
		if (!Get(iReportDef).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuReportDefs::Create(CIuReportDefSpec& ReportDefSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuReportDef& ReportDef = Get(iIndex);
	ReportDef.SetSpec(ReportDefSpec);
}

void CIuReportDefs::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuReportDefs::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuReportDefPtr pReportDef = dynamic_cast<CIuReportDef*>(pCollectable.Ptr());
	GetEngine().QueryObject(collectionReportDefs, Descriptor, *pReportDef);
}

CIuCollectablePtr CIuReportDefs::OnNew(CWnd*) const
{
	CIuReportDefPtr pReportDef;
	pReportDef.Create();
	return pReportDef;
}

void CIuReportDefs::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuReportDefs::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iReportDef = 0; iReportDef < Spec.GetReportDefCount(); ++iReportDef)
		Create(Spec.GetReportDef(iReportDef));  	
}
