#include "stdafx.h" 
//{{Include
#include "Query.h"
#include "Queries.h"
#include "QueryExecute.h"
#include "QueryThread.h"
#include "Error\Error.h"
#include "resource.h"
#include "Data\Output.h"
#include "Listeners.h"
#include "Engine.h"
#include "Select.h"
#include "Select.h"
#include "SourceDescriptor.h"
#include "SourceProvider.h"
#include "Common\MessagePump.h"
#include "Common\String.h"
#include "RegEx.h"
#include "WorkbookFile.h"
#include "Database.h"
#include "Meter.h"
#include "UserInterface.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Enable this to dump extended trace information
#if 0
#define QUERYTRACE	TRACE
#else
inline void AFX_CDECL QueryTrace(LPCTSTR, ...) { }
#define QUERYTRACE	1 ? (void)0 : ::QueryTrace
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuQuery, CIuQuery_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuQuery)
const	CIuVersionNumber versionQueryMax(2000,1,5,304);
const	CIuVersionNumber versionQueryMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_QUERY, CIuQuery, CIuQuery_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuQuery, IDS_ENGINE_PROP_RECORDSET, GetRecordSet_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuQuery, IDS_ENGINE_PROP_RECORDSET, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuQuery, IDS_ENGINE_PPG_QUERY, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuQuery, IDS_ENGINE_PROP_EXPRESSION, GetExpression, SetExpression, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuQuery, IDS_ENGINE_PROP_EXPRESSION, IDS_ENGINE_PPG_QUERY, 5, 0)
	IU_ATTRIBUTE_PROPERTY_DT(CIuQuery, IDS_ENGINE_PROP_CREATED, GetCreated, SetCreated, 0)
	IU_ATTRIBUTE_EDITOR_DT(CIuQuery, IDS_ENGINE_PROP_CREATED, IDS_ENGINE_PPG_QUERY, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuQuery, IDS_ENGINE_PROP_OPTIONS, GetOptions_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuQuery, IDS_ENGINE_PROP_OPTIONS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuQuery, IDS_ENGINE_PROP_WORKBOOKMODE, IsWorkbookMode, SetWorkbookMode, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuQuery, IDS_ENGINE_PROP_WORKBOOKMODE, IDS_ENGINE_PPG_QUERY, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuQuery, IDS_ENGINE_PROP_WORKBOOK, GetWorkbook_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuQuery, IDS_ENGINE_PROP_WORKBOOK, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuQuery::CIuQuery() : m_eventStarted(false, true)
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuQuery::~CIuQuery()				  
{
	Clear();
	if (m_pThread != 0)
		m_pThread->Stop();
	m_pExecute.Release();
	m_pRecordSet.Release();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuQuery::Cancel()
{
	if (IsCompleted())
		return ;

	ASSERT(!IsWorkbookMode());
	// If pumping, cancel
	// Cancels any pending operation. The current record set is not cleared.
	if (!IsCompleted())
	{
		if (IsThreading())
		{
			if (m_pThread != 0)
			{
				QUERYTRACE("QUERY: Request Cancel\n");
				m_pThread->Cancel();
				m_pThread->Wait();
			}
		}
	}
	// Just mark operation as completed
	SetCompleted(false);
	SetStarted(false);
}

void CIuQuery::CancelWorkbookMode()
{
	GetWorkbook().CancelWorkbookMode();
	Clear();
}

void CIuQuery::Clear()
{
	CIuQuery_super::Clear();

	if (IsWorkbookMode())
	{
		CancelWorkbookMode();
		// This call will recurse into clear... no need to progress
		// through this code twice...
		return ;		
	}

	// Cancel any running query
	Cancel();

	// Just mark operation as not completed and not started
	SetCompleted(false);
	SetStarted(false);

	// Clear the record set
	GetRecordSet().Clear();

	// Double check...
	ASSERT(!m_fStarted);
	ASSERT(!m_fCompleted);

	// Force engine to update providers
	GetEngine().GetSourceProvider().SetRefreshQueries();

	// Do not call CommonConstruct().. we want to preserve name/id/open, etc
	// However, we do clear the database, meter and UI to a default
	m_pDatabase.Release();
	m_pMeter.Create();
	m_pMeter->SetMode(meterModeMemory);
	m_pUserInterface.Create();
}

void CIuQuery::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	// Create unique ID and a name based off of the ID
	if (m_pRecordSet.IsNull())
	{
		m_pRecordSet.Create();
		// The id of the query and the record set should always agree
		m_pRecordSet->SetQuery(*this);
	}
	if (m_pExecute.IsNull())
	{
		m_pExecute.Create();
	}
	SetVersion(versionQueryMax);
	if (m_pWorkbook.IsNull())
	{
		m_pWorkbook.Create();
		m_pWorkbook->SetQuery(*this);
	}
	SetVersion(versionQueryMax);
	// Start with a blank database and a dummy meter and userinterface
	m_pDatabase.Release();
	m_pMeter.Create();
	m_pMeter->SetMode(meterModeMemory);
	m_pUserInterface.Create();

	SetID(CIuID::Create());
	m_dtCreated = COleDateTime::GetCurrentTime();
	m_pEngine = 0;
	m_fStarted = false;
	m_fCompleted = false;
	m_fThreading = true;
	m_pThread = 0;
	m_sExpression = _T("");
	//}}Initialize
}

void CIuQuery::Complete() 
{
	ASSERT(!IsWorkbookMode());
	// Threading, wait til done
	if (IsStarted())
	{
		if (IsThreading())
		{
			if (m_pThread != 0)
			{
				m_pThread->Wait();
			}
		}
	}
	SetCompleted(true);
	SetStarted(false);
}

CIuCountsPtr CIuQuery::Count(LPCTSTR pcsz)
{
	// Trace out our progress
	TRACE("QUERY: '%s' count executing:\n\t%s\n", LPCTSTR(GetName()), pcsz);

	Cancel();
	ASSERT(m_pExecute.NotNull());
	CIuCountsPtr pCounts = m_pExecute->SetCount(pcsz);
	if (!Execute(pcsz))
		return CIuCountsPtr();
	return pCounts;
}

bool CIuQuery::Execute(LPCTSTR pcsz, bool fSingleThread)
{
	ASSERT(!IsWorkbookMode());
	if (IsWorkbookMode())
		CancelWorkbookMode();
	ASSERT(AfxIsValidString(pcsz));
	// Cancel the current operation, if any
	Cancel();

	// Just mark operation as not completed and not started
	SetCompleted(false);
	SetStarted(false);

	// By default, create a dummy meter and userinterface
	m_pDatabase.Release();
	m_pMeter.Create();
	m_pMeter->SetMode(meterModeMemory);
	m_pUserInterface.Create();

	// Set up the output object
	GetOutput().SetAbort(false);
	GetOutput().SetHandle(GetHandle());

	// Create a "Select" object
	CIuSelect Select(GetEngine());
	Select.SetExpression(pcsz);

	// Save our threading mode
	if (fSingleThread || Select.GetThreading() == threadingSingle)
	{
		SetThreading(false);
		GetOutput().SetPump(true);
	}
	else
	{
		SetThreading(true);
		GetOutput().SetPump(false);
	}

	// Clear the start semaphore
	m_eventStarted.ResetEvent();

	// If we are threading, start the thread
	if (IsThreading())
	{
		if (m_pThread == 0)
			m_pThread = CIuQueryThread::Start();
		ASSERT(m_pThread != 0);
		QUERYTRACE("QUERY: Thread Start\n");
		m_pThread->SetEvent(this, &GetOutput());
		// Give up a time slice to make sure the thread starts
		Sleep(0);
		// When this function returns, we promise that if the query is successful,
		// we will have
		{
			QUERYTRACE("QUERY: Thread Waiting for Started Event\n");
			CSingleLock lock(&m_eventStarted);
			// Only use a very short delay here
			// We need to make sure messages will be handled very quickly
			time_t timeStart = time(0);
			while (!lock.Lock(0))
			{
				// Pump messages
				PumpMessages();
				// This should not happen, it means we were unable to get the thread started
				// If we don't do this check, we may wait for ever for a thread which.
				// It can also mean the thread aborted before the start event appeared
				// is not starting.
				time_t timeNow = time(0);
				if (timeNow -  timeStart > 3)
				{
					ASSERT(m_pThread);
					if (!m_pThread->IsProcessing())
					{
						TRACE("WARNING: Query was aborted because it did not start in time.\n");						
						return false;
					}
				}
				// Return time slice to worker thread
				Sleep(0);
			}
		}
		QUERYTRACE("QUERY: Thread Running\n");
	}
	else
	{
		QUERYTRACE("QUERY: Direct Start\n");
		return Run();
		QUERYTRACE("QUERY: Direct Completed\n");
	}
	return true;
}

void CIuQuery::GetBuffer(CIuWorkbookFile& WorkbookFile, CIuBuffer& Buffer) const
{
	Buffer.SetGrowBy(8 * 1024);
	Buffer.Empty();

	Buffer.Append((const BYTE*)&versionQueryMax, sizeof(versionQueryMax));

	WorkbookFile.SetExpression(GetExpression());
	WorkbookFile.SetCreated(GetCreated());
	WorkbookFile.SetMoniker(GetMoniker());

	GetRecordSet().GetBuffer(WorkbookFile, Buffer);
}

CIuDatabasePtr CIuQuery::GetDatabase() const
{
	return m_pDatabase;
}

int CIuQuery::GetHandle() const
{
	return (int)(DWORD)GetID();
}

CIuMeter& CIuQuery::GetMeter() const
{
	ASSERT(m_pMeter.NotNull());
	return m_pMeter.Ref();
}

CIuObject* CIuQuery::GetOptions_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_Options));
}

CIuOutput& CIuQuery::GetOutput() const
{
	ASSERT(HasEngine());
	if (m_pOutput.IsNull())
	{
		m_pOutput.Create();
		m_pOutput->SetOwner(&GetEngine());
		m_pOutput->SetHandle(GetHandle());
		m_pOutput->SetBroadcast(&GetEngine().GetListeners().GetBroadcast());
	}
	return m_pOutput.Ref();
}

CIuQueries& CIuQuery::GetQueries() const
{
	CIuQueries* pParent = dynamic_cast<CIuQueries*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuObject* CIuQuery::GetRecordSet_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRecordSet.Ptr()));
}

void CIuQuery::GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const
{
	Specs.RemoveAll();

	// NOTE: The source has index name is blank
	//			and the ID matches the ID of this object.
	//			The database name is the name of the query.
	CIuSourceDescriptorSpec Spec;
	Spec.SetDatabase(GetName());
	Spec.SetIndex(_T(""));
	Spec.SetID(GetID());
	Spec.SetSource(GetMoniker());
	Spec.SetRecordDef(GetRecordSet().GetRecordDef());
	if (IsWorkbookMode())
		Spec.SetSourceType(sourceWorkbook);
	else
		Spec.SetSourceType(sourceQuery);

	Specs.Add(Spec);
}

CIuUserInterface& CIuQuery::GetUserInterface() const
{
	ASSERT(m_pUserInterface.NotNull());
	return m_pUserInterface.Ref();
}

CIuVersionNumber CIuQuery::GetVersionMax() const
{
	return versionQueryMax;
}

CIuVersionNumber CIuQuery::GetVersionMaxStatic()
{
	return versionQueryMax;
}

CIuVersionNumber CIuQuery::GetVersionMin() const
{
	return versionQueryMin;
}

CIuVersionNumber CIuQuery::GetVersionMinStatic()
{
	return versionQueryMin;
}

CIuObject* CIuQuery::GetWorkbook_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pWorkbook.Ptr()));
}

bool CIuQuery::HasDatabase() const
{
	return m_pDatabase.NotNull();
}

bool CIuQuery::IsCompleted() const
{
	if (IsWorkbookMode())
		return true;
	// Is the pending operation completed
	CSingleLock lock(&m_mutex, true);
	bool fCompleted = m_fCompleted;
	if (m_pThread != 0)
		fCompleted = fCompleted && !m_pThread->IsProcessing();
	return fCompleted;
}

bool CIuQuery::IsRunning() const
{
	if (IsWorkbookMode())
		return false;
	// Is the pending operation completed
	CSingleLock lock(&m_mutex, true);
	bool fRunning = m_fStarted && !m_fCompleted;
	if (m_pThread != 0)
		fRunning = fRunning && m_pThread->IsProcessing();
	return fRunning;
}						 

bool CIuQuery::IsSuccessful() const
{
	if (IsWorkbookMode())
		return true;
	if (IsCompleted())
		return true;
	if (m_pExecute.IsNull())
		return false;
	return m_pExecute->IsSuccessful();
}

bool CIuQuery::IsWorkbookMode() const
{
	return GetWorkbook().IsWorkbookMode();
}

CString CIuQuery::Request(const CIuSelect& Select)
{
	return Request(Select.GetExpression());
}

CString CIuQuery::Request(LPCTSTR pcsz)
{
	TRACE("QUERY: '%s' request executing:\n\t%s\n", LPCTSTR(GetName()), pcsz);
	Cancel();
	ASSERT(m_pExecute.NotNull());
	m_pExecute->SetRequest(pcsz);
	if (!Execute(pcsz, true))
		return CString();
	return m_pExecute->GetResult();
}

bool CIuQuery::Run()
{
	if (IsWorkbookMode())
		return false;

	CIuOutputStateInstance instance(GetOutput());
	QUERYTRACE("QUERY: Running\n");
	// At this point we have either been called directly or by a thread
	// and we are expected process the current query.
	bool fResult = false;
	IU_TRY_ERROR
	{
		// Run the pump once until done
		GetOutput().Fire(IU_EVENT_OPERATION_START);
		fResult = m_pExecute->Run();
	}
	IU_CATCH_ERROR(e)
	{
		QUERYTRACE("QUERY: Run terminated with error\n");

		// Make sure we set the started flag so that anyone
		// blocked can continue on
		SetStarted(true);

		e->ReportError();
		e->Delete();

		SetCompleted(true);
		return false;
	}
	SetCompleted(true);
	GetOutput().Fire(IU_EVENT_OPERATION_COMPLETE);
	QUERYTRACE("QUERY: Run terminated with %s\n", (fResult ? _T("success"): _T("failure")));
	// Display elapsed time
	instance.Pop(true);
	return fResult;
}

void CIuQuery::SetBuffer(const CIuWorkbookFile& WorkbookFile, const CIuBuffer& Buffer)
{
	int iOffset = 0;

	CIuVersionNumber VersionNumber;
	iOffset += Buffer.Get((BYTE*)&VersionNumber, sizeof(VersionNumber), iOffset);
	if (VersionNumber < versionQueryMin || VersionNumber > versionQueryMax)
		Error(IU_E_OBJECT_INVALID_OR_CORRUPT, _T("CIuQuery"));

	SetExpression(WorkbookFile.GetExpression());
	SetCreated(WorkbookFile.GetCreated());
	SetMoniker(WorkbookFile.GetMoniker());

	iOffset = GetRecordSet().SetBuffer(WorkbookFile, Buffer, iOffset);

	// Make sure that _exactly_ the entire buffer has been used
	ASSERT(iOffset == Buffer.GetSize());
}

void CIuQuery::SetCompleted(bool f)
{
	CSingleLock lock(&m_mutex, true);
	m_fCompleted = f;
}

void CIuQuery::SetCreated(const COleDateTime& dt)
{
	m_dtCreated = dt;
}

void CIuQuery::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
	GetRecordSet().SetEngine(GetEngine());
	GetWorkbook().SetEngine(GetEngine());
	m_pExecute->SetQuery(*this);
}

void CIuQuery::SetExpression(LPCTSTR pcszExpression) 
{
	ASSERT(AfxIsValidString(pcszExpression));
	m_sExpression = pcszExpression;
#ifdef _DEBUG
	// In debug mode, make a quick pass to parse the expression.
	// It is easier to track down an offender here as opposed to waiting
	// until a thread starts.
	CIuSelect selectDebug;
	selectDebug.SetExpression(pcszExpression);
#endif
}

void CIuQuery::SetExpression(const CIuSelect& Select)
{
	SetExpression(Select.GetExpression());
}

void CIuQuery::SetID(CIuID ID)
{
	CIuQuery_super::SetID(ID);
	CString sName;
	sName.Format(_T("Query %s"), LPCTSTR(GetID().AsString()));
	SetName(sName);
	m_pRecordSet->SetID(GetID());
	m_pWorkbook->SetID(GetID());
}

void CIuQuery::SetName(LPCTSTR pcsz)
{
	CString sName;
	if (!_tcsisempty(pcsz))
		sName = pcsz;
	else
		sName = GetID().AsString();
	sName = CIuRegEx::CleanName(sName);
	CIuQuery_super::SetName(sName);
	if (HasCollection())
		GetQueries().GetEngine().GetSourceProvider().SetRefreshQueries();
}

void CIuQuery::SetOptions(const CIuOptions& Options)
{
	m_Options = Options;
}

void CIuQuery::SetThreading(bool f)
{
	m_fThreading = f;
}

void CIuQuery::SetStarted(bool f)
{
	m_fStarted = f;
	if (f)
		m_eventStarted.SetEvent();
}

void CIuQuery::SetWorkbookMode(const CStringArray& asFields)
{
	Clear();
	GetWorkbook().SetWorkbookMode(asFields);
	// Force engine to update providers
	GetEngine().GetSourceProvider().SetRefreshQueries();
}

void CIuQuery::Start(const CIuSelect& Select)
{
	Start(Select.GetExpression());
}

void CIuQuery::Start(LPCTSTR pcszExpression)
{
	ASSERT(!IsWorkbookMode());
	if (IsWorkbookMode())
		CancelWorkbookMode();

	// Set the expression to use
	if (pcszExpression)
		SetExpression(pcszExpression);
	TRACE("QUERY: '%s' executing:\n\t%s\n", LPCTSTR(GetName()), LPCTSTR(GetExpression()));
	m_pExecute->SetRecordSet(GetExpression());
	Execute(GetExpression());
}

