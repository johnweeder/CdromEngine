#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Databases.h"
#include "Database.h"
#include "CdromSpecConst.h"
#include "DatabaseSelectDlg.h"
#include "Common\Variant.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Interop\Settings.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuDatabases, CIuDatabases_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuDatabases)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_DATABASES, CIuDatabases, CIuDatabases_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuDatabases, IDS_ENGINE_PPG_DATABASES, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuDatabases, IDS_ENGINE_PPG_DATABASES, 10, editorBrowse)
	IU_ATTRIBUTE_ACTION(CIuDatabases, IDS_ENGINE_ACTION_SELECTDLG, ActionSelectDlg, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuDatabases, IDS_ENGINE_ACTION_SELECTDLG, IDS_ENGINE_PPG_DATABASES, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuDatabases::CIuDatabases()
{

	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuDatabases::~CIuDatabases()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuDatabases::ActionSelectDlg(const CIuPropertyCollection&, CIuOutput& Output)
{
	CIuID id;
	CString sResult;
	if (SelectDlg(id, selectShowCreated, Output.GetParentWnd()))
		sResult.Format("Selected %s\n", LPCTSTR(id.AsString()));
	else
		sResult = "Selection Cancelled\n";
	return sResult;
}

void CIuDatabases::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

CIuDatabasePtr CIuDatabases::GetCurrent() const
{
	ASSERT(m_pEngine!=0);
	// On the first pass, try to load the current database from the settings.
	if (m_pDatabaseCurrent.IsNull())
	{
		CString sCurrent = IuSettingsGet(S(IDS_ENGINE_OPTION_CURRENT_DATABASE));
		if (!sCurrent.IsEmpty() && Exists(sCurrent))
			const_cast<CIuDatabases*>(this)->m_pDatabaseCurrent = &Get(sCurrent);
		else if (GetCount() > 0)
		{
			// Select the first database as the current database
			const_cast<CIuDatabases*>(this)->m_pDatabaseCurrent = &Get(int(0));
		}
	}
	return m_pDatabaseCurrent;
}

void CIuDatabases::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuDatabasePtr pDatabase = dynamic_cast<CIuDatabase*>(pCollectable.Ptr());

	CString sFilename;
	if (GetEngine().QueryObject(collectionDatabases, Descriptor, *pDatabase, &sFilename))
		pDatabase->SetFilename(sFilename);
}

CIuCollectablePtr CIuDatabases::OnNew(CWnd*) const
{
 	CIuDatabasePtr pDatabase;
	pDatabase.Create();
	return pDatabase;
}

void CIuDatabases::OnRemove(int iIndex)
{
	if (m_pDatabaseCurrent.NotNull() && m_pDatabaseCurrent.Ptr() == &Get(iIndex))
		m_pDatabaseCurrent.Release();
}

bool CIuDatabases::SelectDlg(CIuID& id, int iFlags, CWnd* pParent)
{
	return SelectDlgEx(id, iFlags, 0, pParent);
}

bool CIuDatabases::SelectDlgEx(CIuID& id, int iFlags, LPCTSTR pcszApplication, CWnd* pParent)
{
	bool fResult = CIuDatabaseSelectDlg::SelectDlg(id, this, 0, iFlags, pcszApplication, pParent);

	// Close any unused pack files
	// They may all have been opened in order to get the database information
	GetEngine().CloseUnused();

	return fResult;
}

void CIuDatabases::SetCurrent(CIuDatabase* pDatabase)
{
	if (pDatabase)
	{
		m_pDatabaseCurrent = pDatabase;
		IuSettingsSet(S(IDS_ENGINE_OPTION_CURRENT_DATABASE), m_pDatabaseCurrent->GetID().AsString());
	}
	else
	{
		m_pDatabaseCurrent.Release();
		IuSettingsSet(S(IDS_ENGINE_OPTION_CURRENT_DATABASE), 0);
	}
}

void CIuDatabases::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuDatabases::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	for (int iDatabase = 0; iDatabase < GetCount(); ++iDatabase)
		Get(iDatabase).SetObjectRepository(pObjectRepository);
}

