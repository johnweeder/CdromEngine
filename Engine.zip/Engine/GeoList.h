#ifndef _ENGINE_GEOLIST_H_
#define _ENGINE_GEOLIST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoList)
class CIuGeoRawElementAccumulator;
class CIuGeoRawElementMap;
class CIuGeoElementCollection;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoList, CIuObject }}
#define CIuGeoList_super CIuObject

class CIuGeoList : public CIuGeoList_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoList)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoList();
	virtual ~CIuGeoList();
	CIuGeoList(const CIuGeoList&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	void Get(int iIndex, int& iLo, int& iHi) const;
	int GetCount() const;
	bool IsEmpty() const;
	void Validate() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Add(int iLo, int iHi = -1);
	virtual void Clear();
	static int Compress(CIuGeoRawElementAccumulator& accumulator, CIuGeoRawElementMap& map, CIuNybbleBuffer& buffer);
	virtual void Copy(const CIuObject& object);
	static int DeCompress(CIuGeoElementCollection& Collection, const CIuNybbleBuffer& buffer, int iOffset);
	void Dump() const;
	const BYTE* Extract(const BYTE* pb);
	void Intersection(const CIuGeoList& GeoList1, const CIuGeoList& GeoList2);
	void RemoveAll();
	void Union(const CIuGeoList& GeoList1, const CIuGeoList& GeoList2);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	bool operator==(const CIuGeoList&) const;
	bool operator!=(const CIuGeoList&) const;
	CIuGeoList& operator=(const CIuGeoList&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void Retrieve(int* pi);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Lo/Hi for each geo list range.
	CIntArray m_aiLo;
	CIntArray m_aiHi;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuGeoList::GetCount() const
{
	ASSERT(m_aiLo.GetSize() == m_aiHi.GetSize());
	return m_aiLo.GetSize();
}

#endif // _ENGINE_GEOLIST_H_
