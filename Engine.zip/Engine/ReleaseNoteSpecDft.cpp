#include "StdAfx.h"
//{{Include
#include "ReleaseNoteSpecDft.h"
#include "ReleaseNote.h"
#include "..\Version.h"
#include "..\VersionProject.h"
#include "Interop\VersionNumber.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ReleaseNoteernate specifications

static const CIuReleaseNoteSpecDft aReleaseNote[] =
{
	{
		szFormat104m_2001, releaseNote104m_2001,
		IU_CDUSA_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormat88md_2001, releaseNote88md_2001,
		IU_CDUSA_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatAc_V1, releaseNoteAc_V1,
		IU_AC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatConsole, releaseNoteConsole,
		IU_CONSOLE_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatBml_2000, releaseNoteBml_2000,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatCi_V1, releaseNoteCi_V1,
		IU_CI_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatMeterAdmin, releaseNoteMeterAdmin,
		IU_METERADMIN_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatNetAdmin, releaseNoteNetAdmin,
		IU_NETADMIN_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatOam_V1, releaseNoteOam_V1,
		IU_OAM_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPb_2001, releaseNotePb_2001,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPbm_V1, releaseNotePbm_V1,
		IU_CDUSA_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPf_2001, releaseNotePf_2001,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPg_2000, releaseNotePg_2000,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPowerCheck, releaseNotePowerCheck,
		IU_POWERCHECK_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatPu_2001, releaseNotePu_2001,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatRboc_2000, releaseNoteRboc_2000,
		IU_PHONEDISC_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatRp_2001, releaseNoteRp_2001,
		IU_RP_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatSample, releaseNoteSample,
		IU_SAMPLEINTERNAL_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatSlu_2000, releaseNoteSlu_2000,
		IU_CDUSA_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	},{
		szFormatYpu_2001, releaseNoteYpu_2001,
		IU_CDUSA_VERSION_STRING_RELEASE,
		IU_VERSION_MIN_STRING,
		_T(""),
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuReleaseNoteSpecDft

int CIuReleaseNoteSpecDft::Find(LPCTSTR pcszReleaseNote)
{
	ASSERT(AfxIsValidString(pcszReleaseNote));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszReleaseNote, pcszReleaseNote) == 0)
			return i;
	}
	return -1;
}

int CIuReleaseNoteSpecDft::Find(int iReleaseNote)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iReleaseNote == iReleaseNote)
			return i;
	}
	return -1;
}

const CIuReleaseNoteSpecDft* CIuReleaseNoteSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aReleaseNote + iWhich;
}

int CIuReleaseNoteSpecDft::GetCount()
{
	return sizeof(aReleaseNote) / sizeof(aReleaseNote[0]);
}


