#ifndef _ENGINE_RECORDSET_H_
#define _ENGINE_RECORDSET_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ENGINE_H_
#	include "Engine\Engine.h"
#endif	// _ENGINE_ENGINE_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_UI_TAGGED_H_
#	include "Ui\Tagged.h"
#endif	// _UI_TAGGED_H_
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
#ifndef 	_ENGINE_SOURCECONVERT_H_
#	include "Engine\SourceConvert.h"
#endif	// _ENGINE_SOURCECONVERT_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordSet)
IU_DEFINE_OBJECT_PTR(CIuRecordDef)
IU_DEFINE_OBJECT_PTR(CIuSource)
class CIuEngine;
class CIuQuery;
class CIuFieldList;
class CIuQueryExecute;
class CIuWorkbookFile;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Find types
// Each of the searches (First/Next/Previous/Last) take a search mode
//	and a criteria. The result is a match code indicating the match type, and
// the record number of the matching record.
// The Next/Previous call also take the current record.
//		virtual int First(int iType, LPCTSTR pcszCriteria, int& lMatch);
//		virtual int Last(int iType, LPCTSTR pcszCriteria, int& lMatch);
//		virtual int Next(int iType, LPCTSTR pcszCriteria, int iCurrent, int& lMatch);
//		virtual int Previous(int iType, LPCTSTR pcszCriteria, int iCurrent, int& lMatch);

// A key specifier may contain tabs separating the key components. It may 
//	also contain a terminating wildcard.

enum CIuSourceFind
{
	// Generic find functions
		// Find record with a matching key
		// The criteria is a key specifier
		// The source is assumed to be sorted 
		findKey,

		// Find record which contains a field like the criteria.
		// All fields are searched.
		// The criteria is a simple value which may be wildcarded.
		// The source is assumed to be un-sorted and 
		//		the search is implemented as a scan.
		findLike,

		// Find record with a matching expression 
		// The criteria is a valid expression
		// The source is assumed to be un-sorted and 
		//		the search is implemented as a scan.
		findExpression,

		// Find record which has a field containing the criteria.
		// All fields are searched.
		// The criteria is a simple value
		// The source is assumed to be un-sorted and 
		//		the search is implemented as a scan.
		findContains,

	// Field specific search functions.
	// The criteria is in the form "field=value". The specified field is searched.

		// Find record which has a field containing the criteria.
		// Only the specified field is searched.
		// The criteria is a simple value
		// The source is assumed to be un-sorted and 
		//		the search is implemented as a scan.
		findFieldContains,

		// Find record which contains a field like the criteria.
		// Only the specified field is searched.
		// The criteria is a simple value
		// The source is assumed to be un-sorted and 
		//		the search is implemented as a scan.
		findFieldLike,

		// Find record which contains a field like the criteria.
		// Only the specified field is searched.
		// The criteria is a simple value
		// The source is assumed to be sorted on the field.
		// This often happens however when selecting based on a the primary sort order and 
		//		then finding based on a secondary sort... business within an SIC for instance.
		findFieldKey,
};

/////////////////////////////////////////////////////////////////////////////
// Result codes for matching
// The result codes roughly correspond to a comparison of a search key to
//		an actual record key.
//
// No matching record was found, but the record number of the record
// just larger than this record was returned
// Note that this implies that the key is less than the record
const int matchNext			= -3;
// A record with a partial matching key was found.
// Ie "WEED"  compared to "WEEDER"
// Note that this is still actually a "less than" comparison
const int matchPartial		= -2;
// Key is greater than record
const int matchLT				= -1;
// A record with an exact matching key was found
const int matchExact			= 0;
// Key is greater than record
const int matchGT				= 1;
// No matching record was found, but the record number of the record
// just before than this record was returned
// Note that this implies that the key is greater than the record
const int matchPrev			= 3;
// No matching key was found.
// Special case returned in some instances by the search engine
const int matchNone			= 99;
// Operation not supported!
const int matchNotSupported= 98;
// Matching operation was aborted
const int matchAborted		= 97;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordSet, CIuObjectNamed }}
#define CIuRecordSet_super CIuObjectNamed

class IU_CLASS_EXPORT CIuRecordSet : public CIuRecordSet_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuRecordSet)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordSet();           
	CIuRecordSet(const CIuRecordSet&);
	virtual ~CIuRecordSet();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool Get(int iRecord, CIuRecordPtr& pRecord) const;
	int GetCount() const;
	CIuEngine& GetEngine() const;
	bool GetExpanded(int iRecord, int iExpandOffset, CIuRecordPtr& pRecord) const;
	CString GetField(int iRecord, int iIndex) const;
	CString GetFieldList(int iRecord, CIuFieldList& fieldList) const;
	CString GetFieldListExpanded(int iRecord, int iExpandOffset, CIuFieldList& fieldList) const;
	CString GetFieldListExpandedAlt(int iRecord, int iExpandOffset, CIuFieldList& fieldList, CIuFieldList* pFieldListAlt) const;
	CIuQuery& GetQuery() const;
	CIuRecordDefPtr GetRecordDef() const;
	CIuSetListPtr GetSetListTagged(int iMode) const;
	CIuSource& GetSource() const;
	CIuTagged& GetTagged();
	int GetTaggedCount() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasEngine() const;
	bool HasQuery() const;
	bool HasSource() const;
	bool IsAlternate(int iRecord) const;
	bool IsTagged(int iRecord) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	int First(int iType, LPCTSTR Criteria, int* plMatch);
	int Last(int iType, LPCTSTR Criteria, int FAR* plMatch);
	int Next(int iType, LPCTSTR Criteria, int Current, int FAR* plMatch);
	bool NthTaggingDlg(int iMaxOutput = -1, CWnd* pParent = 0);
	int Previous(int iType, LPCTSTR Criteria, int Current, int FAR* plMatch);
	void RemoveAllTagged();
	bool SetTagged(int iRecord, bool fTagged);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuRecordSet& operator=(const CIuRecordSet&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	friend class CIuQuery;
	friend class CIuWorkbook;
	void GetBuffer(CIuWorkbookFile& WorkbookFile, CIuBuffer& Buffer) const;
	int SetBuffer(const CIuWorkbookFile& WorkbookFile, const CIuBuffer& Buffer, int iOffset);
	CIuRecordDef* GetInternal(int iRecord, CIuRecordPtr& pRecord, int iExpandOffset = -1) const;
	void SetEngine(CIuEngine& Engine);
	void SetQuery(CIuQuery& Query);
	void SetSource(CIuSource* pSource);

private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// This semaphore is used to control access to a few of the
	// important objects owned by this class. Most importantly,
	// it controls access to the source.
	mutable CMutex m_mutex;

private:
	friend class CIuQueryExecute;
	friend class CIuSourceQuery;
	friend class CIuExportInstance; // Added for a hack... remove asap

	// Back pointer to engine
	CIuEngine* m_pEngine;
	// Back pointer to query object
	CIuQuery* m_pQuery;
	// The source which is supplying the records
	CIuSourcePtr m_pSource;
	// Tagging information
	CIuTagged m_Tagged;
	// Source conversion object
	mutable CIuSourceConvert m_Convert;
	// Temporary raw record used during record mapping and other
	// operations.
	mutable CIuRecordPtr m_pRecordExpand;
	mutable CIuRecordPtr m_pRecordMap;
	mutable CIuRecordPtr m_pRecordFieldList;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuEngine& CIuRecordSet::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

inline CIuQuery& CIuRecordSet::GetQuery() const
{
	ASSERT(HasQuery());
	return *m_pQuery;
}

inline CIuTagged& CIuRecordSet::GetTagged() 
{
	return m_Tagged;
}

inline bool CIuRecordSet::HasEngine() const
{
	return m_pEngine != 0;
}

inline bool CIuRecordSet::HasQuery() const
{
	return m_pQuery != 0;
}

inline bool CIuRecordSet::HasSource() const
{
	return m_pSource.NotNull();	
}

#endif // _ENGINE_RECORDSET_H_

