#ifndef _ENGINE_INPUTPHYSICALFILE_H_
#define _ENGINE_INPUTPHYSICALFILE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTRECORDFILE_H_
#	include "Engine\InputRecordFile.h"
#endif	// _ENGINE_INPUTRECORDFILE_H_
#ifndef 	_DATA_FILEREADAHEAD_H_
#	include "Data\FileReadAhead.h"
#endif	// _DATA_FILEREADAHEAD_H_
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputPhysicalFile)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputPhysicalFile, CIuInputRecordFile }}
#define CIuInputPhysicalFile_super CIuInputRecordFile

class CIuInputPhysicalFile : public CIuInputPhysicalFile_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputPhysicalFile)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputPhysicalFile();
	virtual ~CIuInputPhysicalFile();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCacheSize() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetCacheSize(int iCacheSize);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnMoveFirst();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	int GetRemaining();
	bool GetMore();
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	// Pointer to buffer. Buffer is null terminated 
	LPTSTR m_psz;
	// The number of new-lines in the buffer
	int m_iLf;
	// The total size of the file
	CIuFilePosition m_Length;
private:
	// The file we are reading from
	CIuFileReadAhead m_File;
	// The cache (buffer)
	CIuBigBuffer m_Cache;
	// Size of cache
	int m_cb;
	// Position at which we read the cache
	CIuFilePosition m_Position;
	int m_iCacheSize;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuInputPhysicalFile::GetCacheSize() const
{
	return m_iCacheSize;
}

#endif // _ENGINE_INPUTPHYSICALFILE_H_
