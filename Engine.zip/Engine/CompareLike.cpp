#include "StdAfx.h"
//{{Include
#include "CompareLike.h"
#include "Common\String.h"
#include "FieldDefConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement

// The grammar consists of a series of ascii characters and/or special operators.
//		,						Separates terms in the expression.
//								Functions as an 'OR' for non-negated terms and an 'AND' for negated terms.
//								'A,B' matches 'A' or 'B'
//		- (leading)			At the start of an sub-expression, functions as a 'NOT'. 
//								'-A' matches anything but 'A'
//		~						Anywhere but the start of a sub-expression, denotes a range.
//								'A~C' matches anything >= A and <= B.
//								NOTE: Ranges are undefined when used with wildcards. They may
//								work for simple expressions, but nothing is guaranteed.
//		\char					Used to insert special characters.
//								'\,' matches a comma character
//		*						Matches zero or more characters
//		?						Matches exactly one character
//		%						At the start of an sub-expression, denotes a phonetic match.
//		!						At the start of an sub-expression, denotes a "within" search.
//								This would be the same as starting the expression with a star.
//								'!OHN' would match any string containing 'OHN'
//								This is the same as '*OHN*'.
//		{x}					Specifies one or more options which apply to each and every sub expression.
//								For example '{!}' specifies that each clause should be a "within" search.
//								'{*}' implies that all strings need only be a partial match. 
//									so '{*}A,B' is the same as 'A*,B*'
//								'{%}' implies that all sub-expressions should be matched phonetically. 
//								'{-}' implies that all sub-expressions should be negated.
//								Multiple options are allowed, as in '{-!}'
//	
//	1) Terms (separated by comma's) are evaluated left to right.
// 2) If a non-negated term is matched, the expression immediately returns true.
// 3) If a negated term is matched, the expression immediately returns false.
//	4) No term was matched, so...
//		4a) If all terms were negated, then the expression is true.
//		4b) If one or more terms were non-negated, then the expression is false.
//	

const BYTE matchNull			= 0x00;	// End of a sub expression
const BYTE matchEnd			= 0x01;	// End of parsed expression

const BYTE matchNot			= 0x10;	// -
const BYTE matchPhonetic	= 0x11;	// %
const BYTE matchRange		= 0x12;	// ~

const BYTE matchAnyOne		= 0x20;	// ?
const BYTE matchZeroOrMore	= 0x21;	//	*, except at the end of a string
const BYTE matchRemainder	= 0x22;	// This was a star which appeared at the end of a sub-expression
												// We use a different token for performance reasons.
//}}Implement

#pragma __TODO("CIuCompareLike(): Add tokens for case sensitivity?")

CIuCompareLike::CIuCompareLike() 
{
	CommonConstruct();
}

CIuCompareLike::CIuCompareLike(const CIuCompareLike& rCompareLike)
{
	CommonConstruct();
	*this = rCompareLike;
}

CIuCompareLike::~CIuCompareLike()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCompareLike::Append(BYTE b)
{
	// Avoid putting matchZeroOrMore/matchRemainder together.
	// '**' sequences are redundant.
	int iSize = m_buffer.GetSize();
	if (iSize == 0)
	{
		m_buffer.Append(&b, sizeof(b));
		return ;	
	}

	BYTE bLast = m_buffer[iSize - 1];

	if (bLast == matchZeroOrMore)
	{
		if (b == matchNull)
		{
			// Convert '{*}{null}' to '{remainder}{null}'
			m_buffer[iSize - 1] = matchRemainder;
		}
		else if (b == matchRemainder)
		{
			m_buffer[iSize - 1] = matchRemainder;
			return ;
		}
		else if (b == matchZeroOrMore)
		{
			// Convert '{*}{*}' to '{*}'
			return ;
		}
	}
	m_buffer.Append(&b, sizeof(b));
}

bool CIuCompareLike::Compare(LPCTSTR pcszValue) const
{
	ASSERT(AfxIsValidString(pcszValue));

	const BYTE* pbPattern = m_buffer;
	while (*pbPattern != matchEnd)
	{
		bool fNot = false;

		if (*pbPattern == matchNot)
		{
			fNot = true;
			++pbPattern;
		}

		if (*pbPattern == matchPhonetic)
		{
			++pbPattern;
#pragma __TODO("CIuCompareLike::Compare(): matchPhonetic")
			// Only return if an actual match is made (with respect to the 'fNot' flag
			return fNot ? false: true;
		}
		else
		{
			int iResult1 = EvaluateTerm((const BYTE*)pcszValue, pbPattern);

			// Skip over present term
			while (*pbPattern != matchNull)
				++pbPattern;
			++pbPattern;

			if (iResult1 < 0)
			{
				// If <, skip over range if present
				if (*pbPattern == matchRange)
				{
					++pbPattern;
					while (*pbPattern != matchNull)
						++pbPattern;
					++pbPattern;
				}
			}
			else if (*pbPattern == matchRange)
			{
				++pbPattern;
				int iResult2 = EvaluateTerm((const BYTE*)pcszValue, pbPattern);

				// Skip over the term
				while (*pbPattern != matchNull)
					++pbPattern;
				++pbPattern;

				if (iResult2 <= 0)
				{
					if (fNot)
						return false;
					else
						return true;
				}
			}
			else if (iResult1 == 0)
			{
				if (fNot)
					return false;
				else
					return true;
			}
		}
	}

	return m_fNotAll ? true: false;
}

void CIuCompareLike::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sPattern = "";
	m_buffer.Empty();
	m_fNotAll = false;
	//}}Initialize
}

void CIuCompareLike::Dump() const
{
#ifdef _DEBUG
	int iSize = m_buffer.GetSize();
	TRACE("(%d): %s", iSize, (m_fNotAll ? _T("{notall}"):_T("")));
	for (int i = 0; i < iSize; ++i)
	{
		switch (m_buffer[i])
		{
			case matchNull:
				TRACE("{null}");
				break;
			case matchEnd:
				TRACE("{end}");
				break;
			case matchNot:
				TRACE("{not}");
				break;
			case matchPhonetic:
				TRACE("{phonetic}");
				break;
			case matchRange:
				TRACE("{range}");
				break;
			case matchAnyOne:
				TRACE("{one}");
				break;
			case matchZeroOrMore:
				TRACE("{zero/more}");
				break;
			case matchRemainder:
				TRACE("{remainder}");
				break;
			default:
				TRACE("%c", m_buffer[i]);
				break;
		}
	}
	TRACE("\n");
#endif
}

int CIuCompareLike::EvaluateTerm(const BYTE* pbValue, const BYTE* pbPattern) const
{
	for (;;)
	{
		if (*pbPattern == matchNull)
		{
			// Matched exactly to end of string
			if (*pbValue == 0)
				break;
			// Pattern at an end of stuff remains in the value string
			else
				return 1;
		}
		// Match remainder of string as a wildcard
		else if (*pbPattern == matchRemainder)
			break;
		// Match exactly one character (it must exist)
		else if (*pbPattern == matchAnyOne)
		{
			if (*pbValue == 0)
				return -1;
			++pbValue;
			++pbPattern;
		}
		else if (*pbPattern == matchZeroOrMore)
		{
			++pbPattern;
			// This assert happens if a matchZeroOrMore token should have been a matchRemainder

			// Keep going through the string character by character seeing if we can find a match.
			// NOTE: Search for things like 'A*B*C*D' can get real ugly performance-wise

			if (_istprint(*pbPattern))
			{
				// This is a small optimization for the common case where the next character following the '*' is a 
				// literal. We do an inline search for the next matching literal.
				while (*pbValue)
				{
					int iResult = EvaluateTerm(pbValue, pbPattern);
					if (iResult == 0)
						return 0;
					++pbValue;
					while (*pbValue && *pbPattern != (BYTE)_totupper(*pbValue))
						++pbValue;
				}
			}
			else
			{
				for (; *pbValue; ++pbValue)
				{
					int iResult = EvaluateTerm(pbValue, pbPattern);
					if (iResult == 0)
						return 0;
				}
			}

			// Always return -1 (value < pattern) even though the result is undefined.
			return -1;
		}
		// Value ended but there is still stuff in the pattern
		else if (*pbValue == 0)
			return -1;
		// Otherwise, just compare the literal characters
		else
		{
			BYTE bValue = (BYTE)_totupper(*pbValue);
			if (bValue < *pbPattern)
				return -1;
			else if (bValue > *pbPattern)
				return 1;
			++pbValue;
			++pbPattern;
		}
	}
	return 0;
}


CIuCompareLike& CIuCompareLike::operator=(const CIuCompareLike& rCompareLike)
{
	if (this == &rCompareLike)
		return *this;
	m_sPattern = rCompareLike.m_sPattern;
	m_buffer = rCompareLike.m_buffer;
	return *this;
}

void CIuCompareLike::ParsePattern()
{
#pragma __TODO("CIuCompareLike::ParsePattern(): Add support for quoted strings, english operands like and/or/not")

	LPCTSTR pcsz = m_sPattern;

	m_buffer.SetSize(0);
	m_buffer.PreAllocate(128);
	m_fNotAll = false;

	if (*pcsz == '\0')
	{
		// Special case for empty string
		Append(matchNull);
		Append(matchEnd);
		return ;
	}

	// First, match any global options
	bool fWildcardAll = false;
	bool fWithinAll = false;
	bool fPhoneticAll = false;
	bool fNotAll = false;
	if (*pcsz == '{' && *pcsz != '\0')
	{
		++pcsz;
		for (; *pcsz && *pcsz != '}'; ++pcsz)
		{
			switch (*pcsz)
			{
				case '*':
					fWildcardAll = true;
					break;
				case '!':
					fWithinAll = true;
					break;
				case '%':
					fPhoneticAll = true;
					break;
				case '-':
					fNotAll = true;
					break;
				default:
					TRACE("WARNING: CIuCompareLike::ParsePattern() has unrecognized global option: '%s'\n", pcsz);
					break;
			}
		}
		if (*pcsz == '}')
			++pcsz;
		if (fWithinAll)
			fWildcardAll = true;
	}

	m_fNotAll = true;

	while (*pcsz)
	{
		// Skip leading whitespace on a term
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == '\0')
			break;

		if (*pcsz == '-')
		{
			Append(matchNot);
			++pcsz;
		}
		else if (fNotAll)
		{
			Append(matchNot);
		}
		else
			m_fNotAll = false;

		if (*pcsz == '%')
		{
			Append(matchPhonetic);
			++pcsz;
		}
		else if (fPhoneticAll)
		{
			Append(matchPhonetic);
		}

		bool fWithin = false;
		if (*pcsz == '!')
		{
			Append(matchZeroOrMore);
			++pcsz;
			fWithin = true;
		}
		else if (fWithinAll)
		{
			Append(matchZeroOrMore);
			fWithin = true;
		}

		while (*pcsz && *pcsz != ',' && *pcsz != '~')
		{
			if (*pcsz == '\\' && *pcsz != '\0')
			{
				if (_istprint(pcsz[1]))
				{
					BYTE b = (BYTE)_totupper(pcsz[1]);
					Append(b);
				}
				pcsz += 2;
			}
			else if (*pcsz == '*')
			{
				Append(matchZeroOrMore);
				++pcsz;
			}
			else if (*pcsz == '?')
			{
				Append(matchAnyOne);
				++pcsz;
			}
			else
			{
				if (_istprint(pcsz[0]))
				{
					BYTE b = (BYTE)_totupper(pcsz[0]);
					Append(b);
				}
				++pcsz;
			}
		}

		Trim();

		if (fWildcardAll || fWithin)
		{
			int iSize = m_buffer.GetSize();
			if (iSize != 0 && m_buffer[iSize - 1] != matchNull)
			{
				// Don't "wildcard all" an empty expression
				Append(matchZeroOrMore);
			}
		}

		Append(matchNull);

		if (*pcsz == '~')
		{
			Append(matchRange);
			++pcsz;
			while (*pcsz && *pcsz != ',')
			{
				if (*pcsz == '\\' && *pcsz != '\0')
				{
					if (_istprint(pcsz[1]))
					{
						BYTE b = (BYTE)_totupper(pcsz[1]);
						Append(b);
					}
					pcsz += 2;
				}
				else if (*pcsz == '*')
				{
					Append(matchZeroOrMore);
					++pcsz;
				}
				else if (*pcsz == '?')
				{
					Append(matchAnyOne);
					++pcsz;
				}
				else
				{
					if (_istprint(pcsz[0]))
					{
						BYTE b = (BYTE)_totupper(pcsz[0]);
						Append(b);
					}
					++pcsz;
				}
			}

			Trim();

			if (fWildcardAll || fWithin)
			{
				int iSize = m_buffer.GetSize();
				if (iSize != 0 && m_buffer[iSize - 1] != matchNull)
				{
					// Don't "wildcard all" an empty expression
					Append(matchZeroOrMore);
				}
			}

			Append(matchNull);
		}

		if (*pcsz == ',')
			++pcsz;
		else
			break;
	}

	Append(matchEnd);
}

void CIuCompareLike::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPattern = pcsz;
	m_buffer.Empty();
	ParsePattern();
}

void CIuCompareLike::Trim()
{
	// Trailing trailing whitespace from buffer
	int iSize = m_buffer.GetSize();
	if (iSize <= 0)
		return ;

	while (iSize > 0)
	{
		BYTE bLast = m_buffer[iSize - 1];
		if (bLast == ' ')
			--iSize;
		else
			break;
	}
	if (iSize != m_buffer.GetSize())
		m_buffer.SetSize(iSize);
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(CompareLike, pv)
{
	UNUSED_ALWAYS(pv);

	// Strings to test: "src\0pattern\0result"
	static LPCTSTR apcsz[] = 
	{
		"" "\0"		
		"" "\0"		
		"\x1",

		"Omaha" "\0"		
		"!MAH" "\0"		
		"\x1",

		"lindsay" "\0"		
		"{!}MAH,NDSAY" "\0"		
		"\x1",

		"lindsay" "\0"		
		"{*}LIND" "\0"		
		"\x1",

		"lindsay" "\0"		
		"{*}-LIND" "\0"		
		"\x0",

		"402" "\0"		
		"{*}-407,-870" "\0"		
		"\x1",

		"402" "\0"		
		"{*}-407,-870,3" "\0"
		"\x0",

		"402" "\0"		
		"{*}-407,-870,4" "\0"
		"\x1",

		"402" "\0"		
		"{*}-402,-870,4" "\0"
		"\x0",

		"407" "\0"		
		"{*}-407,-870" "\0"		
		"\x0",

		0,
	};

	for (int i = 0; apcsz[i]; ++i)
	{
		LPCTSTR pcsz = apcsz[i];
		CString sTarget = pcsz;
		pcsz = _tcschr(pcsz, '\0') + 1;
		CString sPattern = pcsz;
		pcsz = _tcschr(pcsz, '\0') + 1;
		bool fExpected = (*pcsz != 0);

		CIuCompareLike like;
		like.SetExpression(sPattern);
		bool fMatches = like.Compare(sTarget);
		if (!((fMatches && fExpected) || (!fMatches && !fExpected)))
		{
			TRACE("'%s' LIKE '%s'\n", LPCTSTR(sTarget), LPCTSTR(sPattern));
			TRACE("\tExpected: %s", fExpected ? _T("true"): _T("false"));
			TRACE("\tTokens: ");
			like.Dump();
			ASSERT((fMatches && fExpected) || (!fMatches && !fExpected));
		}
	}

	return 0;	
}
IU_TEST_END()
#endif

