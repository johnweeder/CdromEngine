#ifndef _ENGINE_INPUTTOKEN_H_
#define _ENGINE_INPUTTOKEN_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTDELIMITED_H_
#	include "Engine\InputDelimited.h"
#endif	// _ENGINE_INPUTDELIMITED_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputToken)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputToken, CIuInputDelimited }}
#define CIuInputToken_super CIuInputDelimited

class CIuInputToken : public CIuInputToken_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputToken)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputToken();
	virtual ~CIuInputToken();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	bool OnProcess();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CStringArray m_asSeeAlso;
	CString m_sSeeAlso;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_INPUTTOKEN_H_
