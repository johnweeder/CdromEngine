#ifndef _ENGINE_ELEMENT_H_
#define _ENGINE_ELEMENT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_STRINGBUFFER_H_
#	include "Common\StringBuffer.h"
#endif	// _COMMON_STRINGBUFFER_H_
//}}Uses

//{{Predefines
class CIuElementCollection;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuElement, CIuObject }}
//	The base element class consists of a single string identifying the "key"
//	for the element, a count, and 0 or more additional strings associated
//	with the element.
//	The key is set at creation and can not be changed. It must be a string.
class CIuElement 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuElement();
	CIuElement(CIuElementCollection* pCollection, LPCTSTR pcszName);
	virtual ~CIuElement();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	LPCTSTR GetName() const;
	CIuElement* GetNext() const;
	UINT HashKey();
	static UINT HashKey(LPCTSTR pcszName);
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another();
	void Create(LPCTSTR pcszName);
	void SetCollection(CIuElementCollection* pCollection);
	void SetCount(int iCount);
	void SetNext(CIuElement* pNext);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Pointer to next element in bucket
	CIuElement* m_pNext;
	// Pointer back to collection (so we can access the string heap)
	CIuElementCollection* m_pCollection;
	// The name of this element
	LPCTSTR m_pcszName;
	// The current count
	int m_iCount;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuElement::GetCount() const
{
	return m_iCount;
}

inline LPCTSTR CIuElement::GetName() const
{
	return m_pcszName;
}

inline CIuElement* CIuElement::GetNext() const
{
	return m_pNext;
}

#endif // _ENGINE_ELEMENT_H_
