#include "StdAfx.h"
//{{Include
#include "KeyDef.h"
#include "FieldMap.h"
#include "RecordDef.h"
#include "Error\Error.h"
#include "resource.h"
#include "FieldDefConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuKeyDef, CIuKeyDef_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuKeyDef)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_KEYDEF, CIuKeyDef, CIuKeyDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuKeyDef, IDS_ENGINE_PPG_KEYDEF, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuKeyDef, IDS_ENGINE_PROP_WIDTHS, GetWidths, SetWidths, 0)
	IU_ATTRIBUTE_EDITOR_INT_ARRAY(CIuKeyDef, IDS_ENGINE_PROP_WIDTHS, IDS_ENGINE_PPG_KEYDEF, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

// This is simply a large buffer of spaces for use in right justifying keys.
// If the field width exceeds the size of this buffer, feel free to make the
// buffer larger.
const TCHAR CIuKeyDef::m_szSpaces[] =
	"                                                                                     "
	"                                                                                     "
	"                                                                                     ";

CIuKeyDef::CIuKeyDef() 
{
	CommonConstruct();
}

CIuKeyDef::CIuKeyDef(const CIuKeyDef& rKey)
{
	CommonConstruct();
	*this = rKey;
}

CIuKeyDef::~CIuKeyDef()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuKeyDef::AddWidth(int iWidth)
{
	m_aiWidths.Add(iWidth);
	if (iWidth > 0)
		m_fSimple = false;
}

void CIuKeyDef::Clear()
{
	CIuKeyDef_super::Clear();
	CIuKeyDef::CommonConstruct();
}

void CIuKeyDef::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_aiWidths.RemoveAll();
	m_fSimple = true;
	//}}Initialize
}

bool CIuKeyDef::Compare(const CIuKeyDef& KeyDef)
{
	if (m_aiWidths.GetSize() != KeyDef.m_aiWidths.GetSize())
		return false;

	for (int iWidth = 0; iWidth < m_aiWidths.GetSize(); ++iWidth)
	{
		if (m_aiWidths[iWidth] != KeyDef.m_aiWidths[iWidth])
			return false;
	}
	return true;
}

void CIuKeyDef::Copy(const CIuObject& object)
{
	CIuKeyDef_super::Copy(object);

	const CIuKeyDef* pKeyDef = dynamic_cast<const CIuKeyDef*>(&object);
	if (pKeyDef == 0 || pKeyDef == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuKeyDef)));
	
	m_aiWidths.Copy(pKeyDef->m_aiWidths);
	m_fSimple = pKeyDef->m_fSimple;
}

void CIuKeyDef::CreateFromMap_(const CIuFieldMap& keyMap, int iFirst, int iCount)
{
	// This function is really only used by the BTree compressor which
	// creates a key from a group of fields in a map.
	// Normally, the map itself specifies a key.
	if (!keyMap.IsResolved())
	{
		TRACE("WARNING: Field map not resolved before key creation. Resolved automatically.\n");	
		CIuResolveSpec Spec;
		const_cast<CIuFieldMap*>(&keyMap)->Resolve(Spec);
	}

	ASSERT(keyMap.IsResolved());

	Clear();

	for (int iKey = iFirst; iKey < iFirst + iCount; ++iKey)
	{
		if ((keyMap.m_aFieldFlags[iKey] & fieldSortNumeric) != 0)
		{
			AddWidth(keyMap.m_aFieldLength[iKey]);
#ifdef _DEBUG
			{
				ASSERT((int)_tcslen(m_szSpaces) >= keyMap.m_aFieldLength[iKey]);
				for (int i = 0; m_szSpaces[i]; ++i)
					ASSERT(m_szSpaces[i] == ' ');
			}
#endif
		}
		else
			AddWidth(-1);
	}
}

void CIuKeyDef::CreateFromMap(const CIuFieldMap& keyMap)
{
	// This is the normal way to create a key def. It just uses the
	// key fields from the map
	CreateFromMap_(keyMap, keyMap.GetFieldCount(), keyMap.GetKeyCount());
}

void CIuKeyDef::CreateFromMapFields(const CIuFieldMap& keyMap)
{
	// This function is really only used by the BTree compressor which
	// creates a key from a group of fields in a map.
	// Normally, the map itself specifies a key.
	CreateFromMap_(keyMap, 0, keyMap.GetFieldCount());
}

void CIuKeyDef::GetWidths(CIntArray& al) const
{
	al.Copy(m_aiWidths);
}

CIuKeyDef& CIuKeyDef::operator=(const CIuKeyDef& rKey)
{
	Copy(rKey);
	return *this;
}

void CIuKeyDef::SetWidths(const CIntArray& al)
{
	m_aiWidths.Copy(al);
	m_fSimple = true;
	for (int iWidth = 0; iWidth < m_aiWidths.GetSize(); ++iWidth)
	{
		if (m_aiWidths[iWidth] > 0)
		{
			m_fSimple = false;
			break;
		}
	}
}
