#include "StdAfx.h"
//{{Include
#include "LatLongCoordinate.h"
#include "LatLongDistance.h"
#include "LatLongUnit.h"
#include "GeoConst.h"
#include "Error\Error.h"
#include "resource.h"
//}}Include

#include <math.h>
const double cRadiusOfEarthInFeet = 20902221;
const double cPI = 3.1415926535;


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuLatLongCoordinate::CIuLatLongCoordinate(LPCTSTR sLat, LPCTSTR sLong): m_LatLongUnitLat(sLat), m_LatLongUnitLong(sLong)
{
	//{{Initialize
	//}}Initialize
}

CIuLatLongCoordinate::CIuLatLongCoordinate(const CIuLatLongCoordinate& Coord)
{
	ASSERT(sizeof(*this) == sizeof(m_LatLongUnitLat) + sizeof(m_LatLongUnitLong));
	operator=(Coord);
}

CIuLatLongCoordinate::CIuLatLongCoordinate(CIuLatLongUnit geoLat, CIuLatLongUnit geoLong):m_LatLongUnitLat(geoLat), m_LatLongUnitLong(geoLong)
{
	ASSERT(sizeof(*this) == sizeof(m_LatLongUnitLat) + sizeof(m_LatLongUnitLong));
}

CIuLatLongCoordinate::CIuLatLongCoordinate(DWORD dwLat, DWORD dwLong) : m_LatLongUnitLat(dwLat), m_LatLongUnitLong(dwLong)
{
	ASSERT(sizeof(*this) == sizeof(m_LatLongUnitLat) + sizeof(m_LatLongUnitLong));
}

CIuLatLongCoordinate::CIuLatLongCoordinate() : m_LatLongUnitLat((DWORD)dwLatLongInvalid), m_LatLongUnitLong((DWORD)dwLatLongInvalid)
{
	ASSERT(sizeof(*this) == sizeof(m_LatLongUnitLat) + sizeof(m_LatLongUnitLong));
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuLatLongCoordinate::AsString(bool fDms) const
{
	CString s;
	s = m_LatLongUnitLat.AsString(fDms);
	s += _T("/");
	s += m_LatLongUnitLong.AsString(fDms);
	return s;
}

void CIuLatLongCoordinate::Clear()
{
	m_LatLongUnitLat.Clear();
	m_LatLongUnitLong.Clear();
}

CIuLatLongDistance CIuLatLongCoordinate::GetDistance(const CIuLatLongCoordinate& First, const CIuLatLongCoordinate& Second, CString* pDirection)
{
	if (!First.IsValid() || First.IsZero() || !Second.IsValid() || Second.IsZero())
	{
		if (pDirection)
			*pDirection = "";
		return CIuLatLongDistance(DWORD(-1));
	}
	// Assume these are always the same sign...
	double lat1 = First.m_LatLongUnitLat & dwLatLongSignMask;
	double lon1 = First.m_LatLongUnitLong & dwLatLongSignMask;
	double lat2 = Second.m_LatLongUnitLat & dwLatLongSignMask;
	double lon2 = Second.m_LatLongUnitLong & dwLatLongSignMask;

	// compute the direction... the direction is from coordinate 1 to coordinate 2.
	if (pDirection)
	{
		// This code assumes we are in the US. I.E lat's are positive
		// and int's are negative.
		double dx = fabs(lon1 - lon2);
		double dy = fabs(lat1 - lat2);
		
		if (dy * 2.0 > dx)
		{
			if (fabs(lat2) > fabs(lat1))
				*pDirection += 'N';
			else
				*pDirection += 'S';
		}
		if (dx * 2.0 > dy)
		{
			if (fabs(lon2) < fabs(lon1))
				*pDirection += 'E';
			else
				*pDirection += 'W';
		}
	}

	// compute the distance
	lat1 = (lat1 / dwLatLongDegreeMultiplier) * (cPI / 180.0);
	lat2 = (lat2 / dwLatLongDegreeMultiplier) * (cPI / 180.0);
	lon1 = (lon1 / dwLatLongDegreeMultiplier) * (cPI / 180.0);
	lon2 = (lon2 / dwLatLongDegreeMultiplier) * (cPI / 180.0);

	double a = lon1 - lon2;
  	if (a < 0)
    	a = -a;
  	if (a > cPI)
    	a = 2.0 * cPI - a;

	double fractional = acos((cos(lat1) * cos(lat2) * cos(a)) + (sin(lat1) * sin(lat2)));
 	DWORD dwDistance = (DWORD)(cRadiusOfEarthInFeet * fractional);

	// Returns the distance in feet
	return CIuLatLongDistance(dwDistance);
}

bool CIuLatLongCoordinate::IsValid() const
{
	return GetLatitude().IsValid() && GetLongitude().IsValid();
}

bool CIuLatLongCoordinate::IsZero() const
{
	return GetLatitude().IsZero() && GetLongitude().IsZero();
}

CIuLatLongDistance CIuLatLongCoordinate::operator-(const CIuLatLongCoordinate& LatLong) const
{
	if (this == &LatLong)
		return CIuLatLongDistance((DWORD)0);
	return GetDistance(*this, LatLong);
}

CIuLatLongCoordinate& CIuLatLongCoordinate::operator=(const CIuLatLongCoordinate& Coord) 
{
	m_LatLongUnitLat = Coord.m_LatLongUnitLat;
	m_LatLongUnitLong = Coord.m_LatLongUnitLong;
	return *this;
}


bool CIuLatLongCoordinate::operator==(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat == Coord.m_LatLongUnitLat && m_LatLongUnitLong == Coord.m_LatLongUnitLong;
}

bool CIuLatLongCoordinate::operator!=(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat != Coord.m_LatLongUnitLat || m_LatLongUnitLong != Coord.m_LatLongUnitLong;
}

bool CIuLatLongCoordinate::operator<(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat < Coord.m_LatLongUnitLat && m_LatLongUnitLong < Coord.m_LatLongUnitLong;
}

bool CIuLatLongCoordinate::operator>(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat > Coord.m_LatLongUnitLat && m_LatLongUnitLong > Coord.m_LatLongUnitLong;
}
 
bool CIuLatLongCoordinate::operator<=(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat <= Coord.m_LatLongUnitLat && m_LatLongUnitLong <= Coord.m_LatLongUnitLong;
}

bool CIuLatLongCoordinate::operator>=(const CIuLatLongCoordinate& Coord) const
{
	return m_LatLongUnitLat >= Coord.m_LatLongUnitLat && m_LatLongUnitLong >= Coord.m_LatLongUnitLong;
}

