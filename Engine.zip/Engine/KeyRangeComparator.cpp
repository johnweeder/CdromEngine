#include "StdAfx.h"
//{{Include
#include "KeyRangeComparator.h"
#include "Record.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuKeyRangeComparator, CIuKeyRangeComparator_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuKeyRangeComparator)
//}}Implement

CIuKeyRangeComparator::CIuKeyRangeComparator() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuKeyRangeComparator::~CIuKeyRangeComparator()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuKeyRangeComparator::Clear() 
{
	m_aKeyLo.RemoveAll();
	m_aKeyHi.RemoveAll();
}

void CIuKeyRangeComparator::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

int CIuKeyRangeComparator::Compare(CIuRecord& Record) const
{
	if (m_aKeyLo.GetSize() == 0)
		return 0;
	m_KeyRecord.Set(Record.GetKeyPtr(), Record.GetKeySize());
	return Compare(m_KeyRecord);
}

int CIuKeyRangeComparator::Compare(const CIuKey& Key) const
{
	int iRanges = m_aKeyLo.GetSize();
	for (int iRange = 0; iRange < iRanges; ++iRange)
	{
		ASSERT(!m_aKeyLo[iRange]->IsInvalid());
		int iResult = Key.Compare(*m_aKeyLo[iRange], 0);
		if (m_aKeyHi[iRange]->IsInvalid())
		{
			return iResult;
		}
		else
		{
			if (iResult < 0)
				return iResult;
			iResult = Key.Compare(*m_aKeyHi[iRange], 0);
			if (iResult <= 0)
				return 0;
			return 1;
		}
	}
	return 1;
}

void CIuKeyRangeComparator::Set(LPCTSTR pcsz, const CIuKeyDef& KeyDef)
{
	ASSERT(AfxIsValidString(pcsz));
	CIuKeyRange Range(pcsz);
	Set(Range, KeyDef);
}

void CIuKeyRangeComparator::Set(const CIuKeyRange& Range, const CIuKeyDef& KeyDef)
{
	Clear();
	int iRanges = Range.GetCount();
	for (int iRange = 0; iRange < iRanges; ++iRange)
	{
		CIuKeyPtr pKeyLo;
		pKeyLo.Create();
		CIuKeyPtr pKeyHi;
		pKeyHi.Create();
		Range.Get(iRange, *pKeyLo, *pKeyHi, KeyDef);
		m_aKeyLo.Add(pKeyLo);
		m_aKeyHi.Add(pKeyHi);
	}
}
