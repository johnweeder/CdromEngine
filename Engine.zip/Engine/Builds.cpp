#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Builds.h"
#include "Build.h"
#include "Data\DataFilename.h"
#include "resource.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBuilds, CIuBuilds_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuBuilds)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BUILDS, CIuBuilds, CIuBuilds_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBuilds, IDS_ENGINE_PPG_BUILDS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuBuilds, IDS_ENGINE_PPG_BUILDS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()
//}}Implement


CIuBuilds::CIuBuilds()
{
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuBuilds::~CIuBuilds()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuEngine& CIuBuilds::GetEngine() const
{
	ASSERT(m_pEngine!=0);
	return *m_pEngine;
}

CIuCollectablePtr CIuBuilds::OnNew(CWnd*) const
{
	CIuBuildPtr pBuild;
	pBuild.Create();
	return CIuCollectablePtr(pBuild);
}

void CIuBuilds::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back 
	// to the engine.
	m_pEngine = &Engine;
}

