#ifndef _ENGINE_BTREESPEC_H_
#define _ENGINE_BTREESPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
struct CIuBTreeSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeSpec, CIuObjectNamed }}
#define CIuBTreeSpec_super CIuObjectNamed

class CIuBTreeSpec : public CIuBTreeSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeSpec();
	virtual ~CIuBTreeSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool AltCity() const;
	bool AltPhone() const;
	bool CreateTranslation() const;
	CString GetAdSizeCode() const;
	CIuMoniker GetAltMoniker() const;
	int GetBTreeNo() const;
	CString GetBusResFlag() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetEmployeeSizeCode() const;
	CIuMoniker GetExpandMoniker() const;
	CString GetFilename() const;
	CString GetFirstYear() const;
	CString GetFranchiseCode() const;
	CString GetGender() const;
	void GetKeys(CStringArray& as) const;
	int GetLatLongPrecision() const;
	void GetMiscellaneous(CStringArray& as) const;
	CString GetNoSolicit() const;
	void GetPhones(CStringArray& as) const;
	int GetRecordDefNo() const;
	CString GetSalesVolumeCode() const;
	CString GetSicCode() const;
	int GetSicCount() const;
	int GetSortNo() const;
	int GetStripNo() const;
	CIuBTreeTokenizerSpec& GetTokenizer(int iTokenizer) const;
	int GetTokenizerCount() const;
	CIuMoniker GetTryHarderMoniker() const;
	bool HasAddress() const;
	bool HasCdrom() const;
	bool HasData() const;
	bool HasGeo() const;
	bool HasPointers() const;
	bool IsBusOnly() const;
	bool IsDefaultSource() const;
	bool IsResOnly() const;
	bool IsTryHarderComma() const;
	bool NoCityStateCorrection() const;
	bool NoCountyCorrection() const;
	bool NoLatLongCorrection() const;
	bool NoMsaCorrection() const;
	bool NoSolicitMail() const;
	bool NoSolicitPhone() const;
	bool NoZipAddOn() const;
	bool UseTranslation() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iBTreeSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszIndex);
	void FromNo(CIuCdromSpec* pCdrom, int iIndexNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuBTreeSpecDft* pBTreeSpec);
	void RemoveAllTokenizers();
	void SetAdSizeCode(LPCTSTR);
	void SetAltCity(bool);
	void SetAltMoniker(const CIuMoniker&);
	void SetAltPhone(bool);
	void SetBTreeNo(int);
	void SetBusOnly(bool);
	void SetBusResFlag(LPCTSTR);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetCreateTranslation(bool);
	void SetDefaultSource(bool);
	void SetEmployeeSizeCode(LPCTSTR);
	void SetExpandMoniker(const CIuMoniker&);
	void SetFilename(LPCTSTR);
	void SetFirstYear(LPCTSTR);
	void SetFranchiseCode(LPCTSTR);
	void SetGender(LPCTSTR);
	void SetHasAddress(bool);
	void SetHasData(bool);
	void SetHasGeo(bool);
	void SetHasPointers(bool);
	void SetKeys(const CStringArray& as);
	void SetLatLongPrecision(int);
	void SetMiscellaneous(const CStringArray&);
	void SetNoCityStateCorrection(bool);
	void SetNoCountyCorrection(bool);
	void SetNoLatLongCorrection(bool);
	void SetNoMsaCorrection(bool);
	void SetNoSolicit(LPCTSTR);
	void SetNoSolicitMail(bool);
	void SetNoSolicitPhone(bool);
	void SetNoZipAddOn(bool);
	void SetPhones(const CStringArray&);
	void SetRecordDefNo(int iRecordDefNo);
	void SetResOnly(bool);
	void SetSalesVolumeCode(LPCTSTR);
	void SetSicCode(LPCTSTR);
	void SetSicCount(int);
	void SetSortNo(int iSortNo);
	void SetStripNo(int iStripNo);
	void SetTryHarderComma(bool);
	void SetTryHarderMoniker(const CIuMoniker&);
	void SetUseTranslation(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;

	CIuBTreeTokenizerSpecArray m_apTokenizers;
	CString m_sFilename;
	int m_iBTreeNo;
	CIuMoniker m_monikerExpandMoniker;
	bool m_fUseTranslation;
	bool m_fCreateTranslation;
	bool m_fHasData;
	bool m_fHasPointers;
	bool m_fTryHarderComma;
	CIuMoniker m_monikerTryHarderMoniker;
	bool m_fHasGeo;
	CStringArray m_asKeys;
	bool m_fAltCity;
	bool m_fAltPhone;
	CIuMoniker m_monikerAltMoniker;
	CStringArray m_asPhones;
	bool m_fNoMsaCorrection;
	bool m_fNoCountyCorrection;
	bool m_fNoLatLongCorrection;
	int m_iLatLongPrecision;
	bool m_fNoSolicitMail;
	bool m_fNoSolicitPhone;
	CString m_sNoSolicit;
	CString m_sBusResFlag;
	bool m_fBusOnly;
	bool m_fResOnly;
	CStringArray m_asMiscellaneous;
	CString m_sGender;
	int m_iSicCount;
	CString m_sSicCode;
	CString m_sFranchiseCode;
	CString m_sAdSizeCode;
	CString m_sFirstYear;
	CString m_sEmployeeSizeCode;
	CString m_sSalesVolumeCode;
	bool m_fDefaultSource;
	bool m_fNoCityStateCorrection;
	bool m_fNoZipAddOn;
	bool m_fHasAddress;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuBTreeSpec::AltCity() const
{
	return m_fAltCity;
}

inline bool CIuBTreeSpec::AltPhone() const
{
	return m_fAltPhone;
}

inline bool CIuBTreeSpec::CreateTranslation() const
{
	return m_fCreateTranslation;
}

inline CString CIuBTreeSpec::GetAdSizeCode() const
{
	return m_sAdSizeCode;
}

inline CIuMoniker CIuBTreeSpec::GetAltMoniker() const
{
	return m_monikerAltMoniker;
}

inline int CIuBTreeSpec::GetBTreeNo() const
{
	return m_iBTreeNo;
}

inline CString CIuBTreeSpec::GetBusResFlag() const
{
	return m_sBusResFlag;
}

inline CIuCdromSpec& CIuBTreeSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuBTreeSpec::GetEmployeeSizeCode() const
{
	return m_sEmployeeSizeCode;
}

inline CIuMoniker CIuBTreeSpec::GetExpandMoniker() const
{
	return m_monikerExpandMoniker;
}

inline CString CIuBTreeSpec::GetFilename() const
{
	return m_sFilename;
}

inline CString CIuBTreeSpec::GetFirstYear() const
{
	return m_sFirstYear;
}

inline CString CIuBTreeSpec::GetFranchiseCode() const
{
	return m_sFranchiseCode;
}

inline CString CIuBTreeSpec::GetGender() const
{
	return m_sGender;
}

inline int CIuBTreeSpec::GetLatLongPrecision() const
{
	return m_iLatLongPrecision;
}

inline CString CIuBTreeSpec::GetNoSolicit() const
{
	return m_sNoSolicit;
}

inline CString CIuBTreeSpec::GetSalesVolumeCode() const
{
	return m_sSalesVolumeCode;
}

inline CString CIuBTreeSpec::GetSicCode() const
{
	return m_sSicCode;
}

inline int CIuBTreeSpec::GetSicCount() const
{
	return m_iSicCount;
}

inline CIuMoniker CIuBTreeSpec::GetTryHarderMoniker() const
{
	return m_monikerTryHarderMoniker;
}

inline bool CIuBTreeSpec::HasAddress() const
{
	return m_fHasAddress;
}

inline bool CIuBTreeSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

inline bool CIuBTreeSpec::HasData() const
{
	return m_fHasData;
}

inline bool CIuBTreeSpec::HasGeo() const
{
	return m_fHasGeo;
}

inline bool CIuBTreeSpec::HasPointers() const
{
	return m_fHasPointers;
}

inline bool CIuBTreeSpec::IsBusOnly() const
{
	return m_fBusOnly;
}

inline bool CIuBTreeSpec::IsDefaultSource() const
{
	return m_fDefaultSource;
}

inline bool CIuBTreeSpec::IsResOnly() const
{
	return m_fResOnly;
}

inline bool CIuBTreeSpec::IsTryHarderComma() const
{
	return m_fTryHarderComma;
}

inline bool CIuBTreeSpec::NoCityStateCorrection() const
{
	return m_fNoCityStateCorrection;
}

inline bool CIuBTreeSpec::NoCountyCorrection() const
{
	return m_fNoCountyCorrection;
}

inline bool CIuBTreeSpec::NoLatLongCorrection() const
{
	return m_fNoLatLongCorrection;
}

inline bool CIuBTreeSpec::NoMsaCorrection() const
{
	return m_fNoMsaCorrection;
}

inline bool CIuBTreeSpec::NoSolicitMail() const
{
	return m_fNoSolicitMail;
}

inline bool CIuBTreeSpec::NoSolicitPhone() const
{
	return m_fNoSolicitPhone;
}

inline bool CIuBTreeSpec::NoZipAddOn() const
{
	return m_fNoZipAddOn;
}

inline bool CIuBTreeSpec::UseTranslation() const
{
	return m_fUseTranslation;
}

#endif // _ENGINE_BTREESPEC_H_
