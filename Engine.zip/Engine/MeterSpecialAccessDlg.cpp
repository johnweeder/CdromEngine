#include "stdafx.h"
#include "engine.h"
#include "MeterSpecialAccessDlg.h"
#include "MeterDiagnosticDlg.h"
#include "Meter.h"
#include "Meters.h"
#include "Ui\ComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDM_METER_ADMIN			0x0110
#define IDM_METER_DIAGNOSTIC	0x0210


//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterSpecialAccessDlg, CIuMeterSpecialAccessDlg_super)
	//{{AFX_MSG_MAP(CIuMeterSpecialAccessDlg)
	ON_BN_CLICKED(IDC_ENGINE_ENABLE, OnEnable)
	ON_EN_CHANGE(IDC_ENGINE_RESPONSECODE, OnChange)
	ON_BN_CLICKED(IDC_ENGINE_WEBSITE, OnWebsite)
	ON_WM_SYSCOMMAND()
	ON_CBN_SELCHANGE(IDC_ENGINE_ACCESS, OnChange)
	ON_CBN_CLOSEUP(IDC_ENGINE_ACCESS, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterSpecialAccessDlg::CIuMeterSpecialAccessDlg(CWnd* pParent /*=NULL*/) : CIuMeterSpecialAccessDlg_super(CIuMeterSpecialAccessDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterSpecialAccessDlg)
	m_sUserCode = _T("");
	m_sResponse = _T("");
	//}}AFX_DATA_INIT
	m_fCorrupt = false;
	m_pMeter = 0;
	m_iMaxAttempts = 10;
	m_dwMode = meterMagicInvalid;
}

void CIuMeterSpecialAccessDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterSpecialAccessDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterSpecialAccessDlg)
	DDX_Control(pDX, IDC_ENGINE_ACCESS, m_Access);
	DDX_Control(pDX, IDC_ENGINE_WEBSITE, m_btnWebSite);
	DDX_Control(pDX, IDC_ENGINE_PHONE, m_editPhone);
	DDX_Control(pDX, IDC_ENGINE_USERCODE, m_editUserCode);
	DDX_Control(pDX, IDC_ENGINE_RESPONSECODE, m_editResponse);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_ENGINE_ENABLE, m_btnEnable);
	DDX_Text(pDX, IDC_ENGINE_USERCODE, m_sUserCode);
	DDX_Text(pDX, IDC_ENGINE_RESPONSECODE, m_sResponse);
	//}}AFX_DATA_MAP
}

bool CIuMeterSpecialAccessDlg::DoDialog(CIuMeter& Meter, CWnd* pParent)
{
	if (Meter.GetSpecialAccess().IsEmpty())
		return false;
	CIuMeterSpecialAccessDlg Dlg(pParent);
	Dlg.m_pMeter = &Meter;
	return Dlg.DoModal() == IDOK;
}

void CIuMeterSpecialAccessDlg::OnChange()
{
	UpdateData(true);

	m_fCorrupt = m_pMeter->IsCorrupt();

	int iCurSel = m_Access.GetCurSel();
	ASSERT(iCurSel != CB_ERR);
	m_dwMode = meterMagicMeterReset;

	if (iCurSel != CB_ERR)
		m_dwMode = m_Access.GetItemData(iCurSel);
	if (m_fCorrupt)
		m_dwMode = meterMagicMeterCorrupt;

	m_sUserCode = m_Session.GetQuery(m_dwMode, true);
	UpdateData(false);

	m_btnEnable.EnableWindow(CIuQueryResponseSession::IsValid(m_sResponse));
}

void CIuMeterSpecialAccessDlg::OnEnable() 
{
	UpdateData();
	if (!CIuQueryResponseSession::IsValid(m_sResponse))
		return ;

	bool fValid = m_Session.Verify(m_sResponse, m_sUserCode);
	if (!fValid)
	{
		--m_iMaxAttempts;
	}
	else if (m_fCorrupt)
	{
		if (m_pMeter->IsCorrupt())
		{
			m_pMeter->Reset();
			if (!m_pMeter->IsCorrupt())
				AfxMessageBox(IDS_ENGINE_METER_RESET, MB_OK|MB_ICONEXCLAMATION);
			else
				AfxMessageBox(IDS_ENGINE_METER_RESET_FAILED, MB_OK|MB_ICONEXCLAMATION);
		}
		OnOK();
	}
	else
	{
		switch (m_dwMode)
		{
			case meterMagicRev0:
			{
				m_pMeter->SetRev(0);
				m_pMeter->Hack();
				AfxMessageBox(IDS_ENGINE_METER_SPECIAL, MB_OK|MB_ICONEXCLAMATION);
				OnOK();
				break;
			}
			case meterMagicMeterReset:
			{
				m_pMeter->Reset();
				AfxMessageBox(IDS_ENGINE_METER_RESET, MB_OK|MB_ICONEXCLAMATION);
				OnOK();
				break;
			}
			default:
				ASSERT(false);
				break;
		}
	}
}

BOOL CIuMeterSpecialAccessDlg::OnInitDialog() 
{
	CIuMeterSpecialAccessDlg_super::OnInitDialog();

	CMenu* pSysMenu = GetSystemMenu(false);

	// IDM_METER_ADMIN must be in the system command range.
	ASSERT((IDM_METER_ADMIN & 0xFFF0) == IDM_METER_ADMIN);
	ASSERT(IDM_METER_ADMIN < 0xF000);

	if (pSysMenu != NULL)
	{
		int iRights = m_pMeter->GetMeters().GetEngine().GetUserRights();
		if ((iRights & engineRightsMeterAdmin) != 0)
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_METER_ADMIN, _T("Administrator..."));
		}
	}

	ASSERT((IDM_METER_DIAGNOSTIC & 0xFFF0) == IDM_METER_DIAGNOSTIC);
	ASSERT(IDM_METER_DIAGNOSTIC < 0xF000);

	if (pSysMenu != NULL)
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_METER_DIAGNOSTIC, _T("Diagnostics..."));
	}

	CenterWindow();

	ASSERT(m_pMeter);
	CString sKey = m_pMeter->GetKey();
	m_Session.SetKey(sKey);

	CFont* pFont = m_editUserCode.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);
	m_editResponse.SetFont(&m_fontLarge);
	m_editUserCode.SetFont(&m_fontLarge);

	// NOTE: This can be one or more phones
	const int cxEachStop = 130;
	m_editPhone.SetTabStops(cxEachStop);
	CString sPhone = m_pMeter->GetPhone();
	if (!sPhone.IsEmpty() && sPhone.GetAt(0) == '(')
	{
		CString sPhoneEx = _T("Phone: ") + sPhone;
		m_editPhone.SetWindowText(sPhoneEx);
	}
	else
		m_editPhone.SetWindowText(sPhone);

	m_btnWebSite.ShowWindow(m_pMeter->GetWebSite().IsEmpty() ? SW_HIDE: SW_SHOW);

	UpdateData(false);

	Update();

	OnChange();

	return true;
}

void CIuMeterSpecialAccessDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_METER_ADMIN)
	{
		UpdateData();
		if (m_pMeter->GetMeters().AdministratorDlg(this, m_pMeter->GetID(), m_sUserCode, &m_sResponse))
			m_editResponse.SetWindowText(m_sResponse);
		OnChange();
	}
	else if ((nID & 0xFFF0) == IDM_METER_DIAGNOSTIC)
	{
		UpdateData();
		CString sLocation = _T("Special Access");
		if (m_fCorrupt)
			sLocation = _T("Meter Special Access - Special");
		else
		{
			sLocation = _T("Special Access - ");
			int iCurSel = m_Access.GetCurSel();
			ASSERT(iCurSel != CB_ERR);
			if (iCurSel == CB_ERR)
				sLocation += _T("Unknown");
			else
			{
				CString sLbText;
				m_Access.GetLBText(iCurSel, sLbText);
				sLocation += sLbText;
			}
		}
		CIuMeterDiagnosticDlg::DoDialog(*m_pMeter, m_sUserCode, sLocation, this);
		OnChange();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CIuMeterSpecialAccessDlg::OnWebsite() 
{
 	ShellExecute(NULL, _T("open"), m_pMeter->GetWebSite(), NULL, NULL, SW_SHOWNORMAL);
}

void CIuMeterSpecialAccessDlg::Update()
{
	m_Access.ResetContent();
	m_fCorrupt = m_pMeter->IsCorrupt();
	if (m_fCorrupt)
		CBLoad(m_Access, _T("Reset Security Logic"), meterMagicMeterCorrupt);
	else
	{
		CIuOptions Options = m_pMeter->GetSpecialAccess();
		// Combo is not sorted. Add them in order.
		// The first available will be selected.
		if (Options.Find(_T("rev0")) >= 0)
			CBLoad(m_Access, _T("Set Original Security Specification"), meterMagicRev0);
		if (Options.Find(_T("reset")) >= 0)
			CBLoad(m_Access, _T("Reset Security Logic"), meterMagicMeterReset);
	}
	if (m_Access.GetCount() > 0)
		m_Access.SetCurSel(0);
	OnChange();
}

