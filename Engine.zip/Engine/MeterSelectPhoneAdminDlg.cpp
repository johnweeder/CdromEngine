#include "stdafx.h"
#include "Engine.h"
#include "MeterSelectPhoneAdminDlg.h"
#include "Interop/Font.h"
#include "Meter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterSelectPhoneAdminDlg, CDialog)
	//{{AFX_MSG_MAP(CIuMeterSelectPhoneAdminDlg)
	ON_EN_CHANGE(IDC_ENGINE_CUST_CODE, OnChangeCustomerCode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterSelectPhoneAdminDlg::CIuMeterSelectPhoneAdminDlg(CWnd* pParent /*=NULL*/) : CDialog(CIuMeterSelectPhoneAdminDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIUMeterSelectPhoneAdminDlg)
	m_sNotes = _T("");
	//}}AFX_DATA_INIT

	m_sUserCode = _T("");
}

void CIuMeterSelectPhoneAdminDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterSelectPhoneAdminDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterSelectPhoneAdminDlg)
	DDX_Control(pDX, IDC_ENGINE_RESP_CODE, m_responseCode);
	DDX_Control(pDX, IDC_ENGINE_CUST_CODE, m_customerCode);
	DDX_Text(pDX, IDC_ENGINE_NOTES, m_sNotes);
	//}}AFX_DATA_MAP
}


/////////////////////////////////////////////////////////////////////////////
// CIuMeterSelectPhoneAdminDlg message handlers

BOOL CIuMeterSelectPhoneAdminDlg::OnInitDialog()
{
	CIuMeterSelectPhoneAdminDlg_super::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	CFont* pFont = m_customerCode.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);
	m_customerCode.SetFont(&m_fontLarge);
	m_responseCode.SetFont(&m_fontLarge);

	m_Session.SetKey(_T("SP"));
	m_customerCode.SetWindowText(m_sUserCode);

	m_customerCode.SetFocus();

	OnChangeCustomerCode();

	return FALSE;  // return TRUE  unless you set the focus to a control
}

void CIuMeterSelectPhoneAdminDlg::OnChangeCustomerCode() 
{
	CString sCode;
	m_customerCode.GetWindowText(sCode);

	if (m_Session.IsValidQuery(sCode))
	{
		UINT uiUserValue;
		VERIFY(m_Session.GetUserValue(sCode, uiUserValue));
		if (uiUserValue == meterMagicMeterCorrupt)
		{
			m_sNotes = _T("Meter Corrupt!\n\n");
			m_sNotes += _T("The user's meter is corrupt. Giving them this code will reset his meter.\r\n");
		}
		else if ((uiUserValue & 0xFFFF0000) == meterMagicMeterReset)
		{
			DWORD dwCurrent = (uiUserValue & 0x0000FFFF);
			int nCount = dwCurrent;

			m_sNotes.Format(_T("The current meter count is %i.\r\n\r\n"), nCount);
			m_sNotes += _T("The user may be requesting a reset of their meter.\r\n"); 
			m_sNotes += _T("If they are using the Power Check Utility, they will need to press the 'Ctrl', 'Alt', and 'Z' keys simultaneously, enter the code below, and press the 'RESET' button.\r\n");
		}

		CString sResponseCode = m_Session.GetResponse(sCode);
		m_responseCode.SetWindowText(sResponseCode);
	}
	else
	{
		m_sNotes = _T("Invalid Customer Code");
		m_responseCode.SetWindowText(_T(""));
	}

	UpdateData(FALSE);
}
