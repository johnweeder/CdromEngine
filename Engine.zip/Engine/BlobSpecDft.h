#ifndef _ENGINE_BLOBSPECDFT_H_
#define _ENGINE_BLOBSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Descriptions for the various Blobernate record files
struct CIuBlobSpecDft
{
public:
	static int Find(LPCTSTR pcszBlob);
	static int Find(int iBlob);
	static const CIuBlobSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszBlob;
	int m_iBlob;
	// Unique ID for blob
	const CIuID* m_pid;
	// Blobernate filename (this is the "raw" filename)
	LPCTSTR m_pcszFilename;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BLOBSPECDFT_H_
