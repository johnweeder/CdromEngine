#include "StdAfx.h"
//{{Include
#include "InputResidential.h"
#include "Common\String.h"
#include "CdromSpec.h"
#include "resource.h"
#include "Error\Error.h"
#include "Solicit.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputResidential, CIuInputResidential_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputResidential)

enum
{
	resLast,
	resFirst,
	resMiddleName,
	resNickname,
	resGen,
	resTitle,
	resProSuffix,
	resSpouseLast,
	resSpouseFirst,
	resSpouseMiddleName,
	resSpouseNickname,
	resSpouseGen,
	resSpouseTitle,
	resSpouseProSuffix,
	resPriNo,
	resPreDir,
	resStreetName,
	resSuffix,
	resPostDir,
	resSecNo,
	resHighRise,
	resSubUrbanCity,
	resCity,
	resStateAbbr,
	resZIP5,
	resAddOn,
	resCarrierRoute,
	resStateCode,
	resCountyCode,
	resAreaCode,
	resPhone,
	resDPBC,
	resRecordID,
	resPhoneType,
	resLatitude,
	resLongitude,
	resMatchLevel,
	resCensusTract,
	resBlockGroup,
	resYPPANo,
	resPubDate,
	resNoSolicitation,
	resDeceased,
	resMsaCode,
	resUnknown1,
	resUnparsedAddress,
	resSection,
	resYOL,
	resNewListIndicator,
	resCrLf,
};
//}}Implement

CIuInputResidential::CIuInputResidential() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputResidential::~CIuInputResidential()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputResidential::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputResidential"));
	m_fNoSpouse = false;
	m_fNoNoSolicit = false;
	//}}Initialize
}

bool CIuInputResidential::OnOpen(CIuOpenSpec& OpenSpec)
{
	ClearInputFieldDefs();
	AddInputFieldDef(20);
	AddInputFieldDef(15);
	AddInputFieldDef(15);
	AddInputFieldDef(15);
	AddInputFieldDef(3);
	AddInputFieldDef(4);						 
	AddInputFieldDef(4);
	AddInputFieldDef(20);
	AddInputFieldDef(15);				
	AddInputFieldDef(15);		
	AddInputFieldDef(15);
	AddInputFieldDef(3);
	AddInputFieldDef(4);				 
	AddInputFieldDef(4);			 
	AddInputFieldDef(10);						
	AddInputFieldDef(2);						 
	AddInputFieldDef(25);						
	AddInputFieldDef(4);						 
	AddInputFieldDef(2);					 
	AddInputFieldDef(10);							
	AddInputFieldDef(1);					 
	AddInputFieldDef(28);				
	AddInputFieldDef(28);
	AddInputFieldDef(2);					 
	AddInputFieldDef(5);
	AddInputFieldDef(4);						 
	AddInputFieldDef(4);				 
	AddInputFieldDef(2);
	AddInputFieldDef(3);				 
	AddInputFieldDef(3);
	AddInputFieldDef(7);
	AddInputFieldDef(3);
	AddInputFieldDef(10);					
	AddInputFieldDef(4);
	AddInputFieldDef(9);					 
	AddInputFieldDef(9);
	AddInputFieldDef(1);
	AddInputFieldDef(6);				 
	AddInputFieldDef(1);				 
	AddInputFieldDef(6);
	AddInputFieldDef(6);
	AddInputFieldDef(1);
	AddInputFieldDef(1);
	AddInputFieldDef(4);					 
	AddInputFieldDef(2);
	AddInputFieldDef(45);
	AddInputFieldDef(2);
	AddInputFieldDef(6);
	AddInputFieldDef(1);
	AddInputFieldDef(2);
	if (!CIuInputResidential_super::OnOpen(OpenSpec))
		return false;
	return true;
}

bool CIuInputResidential::OnProcess()
{
	LPCTSTR pcszNoSolicitation	= GetInput(resNoSolicitation);
	if (SolicitDiscard(*pcszNoSolicitation))
		return true;

	if (NoNoSolicit())
	{
		if (!SolicitCanMail(*pcszNoSolicitation) || !SolicitCanPhone(*pcszNoSolicitation))
			return true;
	}
	if (!OnProcessPrimary())
		return false;
	if (NoSpouse())
		return true;
	if (!OnProcessSpouse())
		return false;
	return true;
}

bool CIuInputResidential::OnProcessNoSolicit()
{
	LPCTSTR pcszNoSolicitation	= GetInput(resNoSolicitation);

	if (!SolicitCanPhone(*pcszNoSolicitation))
	{
		SetField(inputFieldAcPhone, "");
	}
	if (!SolicitCanMail(*pcszNoSolicitation))
	{
		SetField(inputFieldPriNo, "");
		SetField(inputFieldPreDir, "");
		SetField(inputFieldStreetName, "");
		SetField(inputFieldSuffix, "");
		SetField(inputFieldPostDir, "");
		SetField(inputFieldSecNo, "");
		SetField(inputFieldStreet, "");
		SetField(inputFieldLatitude, "");
		SetField(inputFieldLongitude, "");
		SetField(inputFieldMatchLevel, "");
		m_sTemp = GetField(inputFieldZIP);
		m_sTemp = m_sTemp.Left(5);
		SetField(inputFieldZIP, m_sTemp);
	}
	return true;
}

bool CIuInputResidential::OnProcessPrimary()
{
	MakeName(inputFieldName, GetInput(resLast), GetInput(resFirst), GetInput(resMiddleName), GetInput(resGen), GetInput(resProSuffix), GetInput(resTitle));

	MakeAddress(GetInput(resPriNo), GetInput(resPreDir), GetInput(resStreetName), GetInput(resSuffix), GetInput(resPostDir), GetInput(resSecNo), GetInput(resHighRise), GetInput(resNoSolicitation));

	SetField(inputFieldCity, GetInput(resCity));
	MakeState(GetInput(resStateCode));
	MakeZip(GetInput(resZIP5), GetInput(resAddOn), GetInput(resDPBC));

	MakePhone(inputFieldAcPhone, GetInput(resAreaCode), GetInput(resPhone));

	SetField(inputFieldLatitude, GetInput(resLatitude));
	SetField(inputFieldLongitude, GetInput(resLongitude));
	SetField(inputFieldMatchLevel, GetInput(resMatchLevel));
	SetField(inputFieldPubDate, GetInput(resPubDate));
	SetField(inputFieldNoSolicitation, GetInput(resNoSolicitation));
	SetField(inputFieldMsaCode, GetInput(resMsaCode));
	SetField(inputFieldCountyCode, GetInput(resCountyCode));

	SetField(inputFieldBusResFlag, "R");

	if (!OnProcessNoSolicit())
		return false;

	return Output();
}

bool CIuInputResidential::OnProcessSpouse()
{
	// The first name field (field 1) must not be empty
	// Otherwise, we assume that the spouse fields were empty.
	LPCTSTR pcszFirst = GetInput(resSpouseFirst);
	if (_tcsisempty(pcszFirst))
		return true;

	LPCTSTR pcszLast = GetInput(resSpouseLast);
	if (_tcsisempty(pcszLast))
		pcszLast = GetInput(resLast);

	MakeName(inputFieldName, pcszLast, pcszFirst, GetInput(resSpouseMiddleName), GetInput(resSpouseGen), GetInput(resSpouseProSuffix), GetInput(resSpouseTitle));


	return Output();
}

void CIuInputResidential::SetNoNoSolicit(bool f)
{
	m_fNoNoSolicit = f;
}

void CIuInputResidential::SetNoSpouse(bool f)
{
	m_fNoSpouse = f;
}

void CIuInputResidential::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputResidential_super::SetSpec(Spec);
	SetNoSpouse(Spec.NoSpouse());
	SetNoNoSolicit(Spec.NoNoSolicit());
}
