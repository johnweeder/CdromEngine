#include "StdAfx.h"
//{{Include
#include "AddressRaw.h"
#include "AddressCodec.h"
#include "AddressSpec.h"
#include "resource.h"
#include "Common\String.h"
#include "Common\BigBuffer.h"
#include "Interop\Conversions.h"
#include "Common\Clean.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "CdromSpec.h"
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddressRaw, CIuAddressRaw_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddressRaw)
const	CIuVersionNumber versionAddressRawMax(2000,1,5,304);
const	CIuVersionNumber versionAddressRawMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESSRAW, CIuAddressRaw, CIuAddressRaw_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddressRaw, IDS_ENGINE_PPG_ADDRESSRAW, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressRaw, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuAddressRaw, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ADDRESSRAW, 0)

	IU_ATTRIBUTE_ACTION(CIuAddressRaw, IDS_ENGINE_ACTION_READ, ActionRead, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAddressRaw, IDS_ENGINE_ACTION_READ, IDS_ENGINE_PPG_ADDRESSRAW, editorAutoUpdate)
	IU_ATTRIBUTE_ACTION(CIuAddressRaw, IDS_ENGINE_ACTION_WRITE, ActionWrite, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAddressRaw, IDS_ENGINE_ACTION_WRITE, IDS_ENGINE_PPG_ADDRESSRAW, editorAutoUpdate)

	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressRaw, IDS_ENGINE_PROP_STREETNAMES, GetStreetNames_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuAddressRaw, IDS_ENGINE_PROP_STREETNAMES, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressRaw, IDS_ENGINE_PROP_SUFFIXES, GetSuffixes_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuAddressRaw, IDS_ENGINE_PROP_SUFFIXES, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAddressRaw::CIuAddressRaw() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddressRaw::~CIuAddressRaw()
{
	Empty();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuAddressRaw::ActionRead(const CIuPropertyCollection&, CIuOutput&)
{
	Read();
	return CString();
}

CString CIuAddressRaw::ActionWrite(const CIuPropertyCollection&, CIuOutput&)
{
	Write();
	return CString();
}

bool CIuAddressRaw::Add(CIuAddressCodec& Codec, CIuOutput&)
{
	CString sStreetName = Codec.GetStreetName();
	if (!sStreetName.IsEmpty())
	{
		++m_iNamed;
		const int iExceptions = addressEmpty|addressRR|addressHC|addressGD|addressPOBOX|addressNumericStreet|addressOrdinalStreet;
		if ((Codec.GetFlags() & iExceptions) == 0)
		{
			CString sSuffix = Codec.GetSuffix();
			GetStreetNames().Add(Codec.GetPreDir(), sStreetName, sSuffix, Codec.GetPostDir());
			// Don't add empty suffix. Handled as a special case
			if (!sSuffix.IsEmpty())
				GetSuffixes().Add(sSuffix);
		}
	}

#ifdef _DEBUG
	++m_iTotal;
	if ((Codec.GetFlags() & addressRR) != 0)
		++m_iRr;
	else if ((Codec.GetFlags() & addressHC) != 0)
		++m_iHc;
	else if ((Codec.GetFlags() & addressEmpty) != 0)
		++m_iEmpty;
	else if ((Codec.GetFlags() & addressGD) != 0)
		++m_iGd;
	else if ((Codec.GetFlags() & addressPOBOX) != 0)
		++m_iPoBox;
	else if ((Codec.GetFlags() & addressNumericStreet) != 0)
		++m_iNumeric;
	else if ((Codec.GetFlags() & addressOrdinalStreet) != 0)
		++m_iOrdinal;

	if ((Codec.GetFlags() & (addressNumericStreet|addressOrdinalStreet)) != 0)
	{
		++m_iNumericTotal;
		if (Codec.GetStreetNo() < 16)
			++m_iNumeric16;
		else if (Codec.GetStreetNo() < 256)
			++m_iNumeric256;
		else if (Codec.GetStreetNo() < 4096)
			++m_iNumeric4096;
		else if (Codec.GetStreetNo() < 65536)
			++m_iNumeric65536;
	}

	if ((Codec.GetFlags() & addressNumericPriNo) != 0)
	{
		++m_iPriNo;
		if (Codec.GetPriNoNo() < 16)
			++m_iPriNo16;
		else if (Codec.GetPriNoNo() < 256)
			++m_iPriNo256;
		else if (Codec.GetPriNoNo() < 4096)
			++m_iPriNo4096;
	}

	if ((Codec.GetFlags() & addressNumericSecNo) != 0)
	{
		++m_iSecNo;
		if (Codec.GetSecNoNo() < 16)
			++m_iSecNo16;
		else if (Codec.GetSecNoNo() < 256)
			++m_iSecNo256;
		else if (Codec.GetSecNoNo() < 4096)
			++m_iSecNo4096;
	}

	if (Codec.GetPreDirNo() != dirNone)
		++m_iPreDir;
	if (Codec.GetPostDirNo() != dirNone)
		++m_iPostDir;
#endif
	return true;
}

void CIuAddressRaw::Clear()
{
	CIuAddressRaw_super::Clear();
	CIuAddressRaw::CommonConstruct();
	Empty();
}

void CIuAddressRaw::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sFilename = "AddressRaw";
	SetVersion(versionAddressRawMax);
	if (m_pStreetNames.IsNull())
	{
		m_pStreetNames.Create();
		m_pStreetNames->SetHashSize(4 * 1024 * 1024 - 1);
	}
	if (m_pSuffixes.IsNull())
	{
		m_pSuffixes.Create();
		m_pSuffixes->SetHashSize(1567);
	}
	m_iTotal = 0;
	m_iPreDir = 0;
	m_iPostDir = 0;
	m_iEmpty = 0;
	m_iRr = 0;
	m_iHc = 0;
	m_iGd = 0;
	m_iPoBox = 0;
	m_iOrdinal = 0;
	m_iNumericTotal = 0;
	m_iNamed = 0;
	m_iNumeric = 0;
	m_iNumeric16 = 0;
	m_iNumeric256 = 0;
	m_iNumeric4096 = 0;
	m_iNumeric65536 = 0;
	m_iPriNo = 0;
	m_iPriNo16 = 0;
	m_iPriNo256 = 0;
	m_iPriNo4096 = 0;
	m_iSecNo = 0;
	m_iSecNo16 = 0;
	m_iSecNo256 = 0;
	m_iSecNo4096 = 0;
	//}}Initialize
}

void CIuAddressRaw::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
	// Empty this object as a way of cleaning up un-needed memory
	Empty();
}

void CIuAddressRaw::Dump(CIuOutput& Output)
{
#if 0
	// This is the very detailed dump
	GetStreetNames().SortByCountDecreasing();
	GetStreetNames().Dump(Output);
	Output.Fire();
	GetSuffixes().SortByCountDecreasing();
	GetSuffixes().Dump(Output);
	Output.Fire();
	Output.OutputF("%10d total\n", m_iTotal);
	Output.OutputF("%10d named (%d unique)\n", m_iNamed, GetStreetNames().GetCount());
	Output.OutputF("%10d empty\n", m_iEmpty);
	Output.OutputF("%10d RR\n", m_iRr);
	Output.OutputF("%10d HC\n", m_iHc);
	Output.OutputF("%10d GD\n", m_iGd);
	Output.OutputF("%10d POBOX\n", m_iPoBox);
	Output.OutputF("%10d ordinal/numeric streets\n", m_iNumericTotal);
	Output.OutputF("\n");
	Output.OutputF("%10d ordinal, %d numeric\n", m_iOrdinal, m_iNumeric);
	Output.OutputF("         %d < 16, %d < 256, %d < 4096, %d < 65536\n", m_iNumeric16, m_iNumeric256, m_iNumeric4096, m_iNumeric65536);
	Output.OutputF("%10d numeric prino's\n", m_iPriNo);
	Output.OutputF("         %d < 16, %d < 256, %d < 4096\n", m_iPriNo16, m_iPriNo256, m_iPriNo4096);
	Output.OutputF("%10d numeric secno's\n", m_iSecNo);
	Output.OutputF("         %d < 16, %d < 256, %d < 4096\n", m_iSecNo16, m_iSecNo256, m_iSecNo4096);
	Output.OutputF("%10d predirs\n", m_iPreDir);
	Output.OutputF("%10d postdirs\n", m_iPostDir);
#else
	Output.OutputF("%d unique street names\n", GetStreetNames().GetCount());
	Output.OutputF("%d unique suffix names\n", GetSuffixes().GetCount());
#endif
}

void CIuAddressRaw::Empty()
{
	GetStreetNames().Empty();
	GetSuffixes().Empty();
	m_iTotal = 0;
	m_iPreDir = 0;
	m_iPostDir = 0;
	m_iEmpty = 0;
	m_iRr = 0;
	m_iHc = 0;
	m_iGd = 0;
	m_iPoBox = 0;
	m_iOrdinal = 0;
	m_iNumeric = 0;
	m_iNumeric = 0;
	m_iNumeric16 = 0;
	m_iNumeric256 = 0;
	m_iNumeric4096 = 0;
	m_iNumeric65536 = 0;
	m_iPriNo = 0;
	m_iPriNo16 = 0;
	m_iPriNo256 = 0;
	m_iPriNo4096 = 0;
	m_iSecNo = 0;
	m_iSecNo16 = 0;
	m_iSecNo256 = 0;
	m_iSecNo4096 = 0;
}

CString CIuAddressRaw::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CIuFilename CIuAddressRaw::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

CIuObject* CIuAddressRaw::GetStreetNames_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pStreetNames.Ptr()));
}

CIuObject* CIuAddressRaw::GetSuffixes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSuffixes.Ptr()));
}

CIuVersionNumber CIuAddressRaw::GetVersionMax() const
{
	return versionAddressRawMax;
}

CIuVersionNumber CIuAddressRaw::GetVersionMaxStatic()
{
	return versionAddressRawMax;
}

CIuVersionNumber CIuAddressRaw::GetVersionMin() const
{
	return versionAddressRawMin;
}

CIuVersionNumber CIuAddressRaw::GetVersionMinStatic()
{
	return versionAddressRawMin;
}

void CIuAddressRaw::Read()
{
	CIuFilename filename = GetFullFilename();
	if (!filename.Exists())
	{
		Clear();
		Error(IU_E_ADDRESS_FILE_NOT_FOUND, filename);
		return ;
	}

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Open(GetFullFilename(), 16 * 1024, CIuFile::openReadOnly);

	pFile->GetData(this);

	CIuFileVirtualPtr pVFile = pFile->Use();

	CIuBigBuffer buffer;
	buffer.SetSize((int)pVFile->GetLength());

	pVFile->Seek(0);
	pVFile->Read(buffer.GetPtr(), buffer.GetSize());

	SerializeFromMemory(buffer, this);
}

void CIuAddressRaw::Serialize(CArchive& ar)
{
	// We use MFC serialization for performance reasons...
	// NOTE: We are only saving the AddressRaw information via MFC serialization
	const DWORD dwCurrentVersion = 0x00000001;
	if (ar.IsStoring())
	{
		ar << dwCurrentVersion;
	}
	else
	{
		DWORD dwVersion;
		ar >> dwVersion;
		ASSERT(dwVersion == dwCurrentVersion);

		Empty();
	}
	GetStreetNames().Serialize(ar);
	GetSuffixes().Serialize(ar);
	CIuAddressRaw_super::Serialize(ar);
}

void CIuAddressRaw::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAddressRaw::SetSpec(CIuAddressSpec& Spec)
{
	SetName(Spec.GetCdrom().GetName());
	SetFilename(Spec.GetCdrom().GetFilename());
}

void CIuAddressRaw::Write() const
{
	CIuBigBuffer buffer;
	SerializeToMemory(buffer, *this, 1024 * 1024);

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Create(GetFullFilename(), 16 * 1024, CIuFile::openCreate);

	CIuFileVirtualPtr pVFile = pFile->Use();
	pFile->SetData(*this);

	pVFile->Seek(0);
	pVFile->Write(buffer.GetPtr(), buffer.GetSize());
}
