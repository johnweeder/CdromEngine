#ifndef _ENGINE_REPORTDEF_H_ 
#define _ENGINE_REPORTDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReportDef)
IU_DEFINE_OBJECT_PTR(CIuReportFieldDefs)
class CIuReportDefs;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Report Defs
enum CIuReportDefNo
{
	reportDefNone = 0,

	reportDefXXX,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReportDef, CIuCollectable }}
#define CIuReportDef_super CIuCollectable

class IU_CLASS_EXPORT CIuReportDef : public CIuReportDef_super
{
//{{Declare
	DECLARE_SERIAL(CIuReportDef)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReportDef();           
	virtual ~CIuReportDef();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuReportFieldDefs& GetFieldDefs() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuReportDefs& GetReportDefs() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool HasReportDefs() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	int CreateFieldDef(LPCTSTR pcszDef);
	int CreateFieldDef(CIuReportFieldDefSpec& spec);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuReportDefSpec& ReportDefSpec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetFieldDefs_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	CIuReportFieldDefsPtr m_pFieldDefs;
private:
	CIuObjectRepository* m_pObjectRepository;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuReportFieldDefs& CIuReportDef::GetFieldDefs() const
{
	return m_pFieldDefs.Ref();
}

inline CIuObjectRepository& CIuReportDef::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline bool CIuReportDef::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuReportDef::HasReportDefs() const
{
	return HasCollection();
}

#endif 
