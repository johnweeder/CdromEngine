#ifndef _ENGINE_PARSENAME_H_
#define _ENGINE_PARSENAME_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

enum CIuParseNameParts
{
	parseNamePartLastName				= 'L',
	parseNamePartTitle					= 'T',
	parseNamePartFirstName				= 'F',
	parseNamePartMiddleName				= 'M',
	parseNamePartGeneration				= 'G',
	parseNamePartProfessionalSuffix	= 'S',

	nParseNameParts  // for array allocation
};

const int makeNameFirstLast = 0;
const int makeNameLastFirst = 1;

const int makeNameInitialsOnly = 0x80000000;

IU_API_EXPORT ExtractNamePart(CString& sPart, int iPart, LPCTSTR pcszName, int iFormat = makeNameLastFirst);
IU_API_EXPORT void FlipName(CString& sName, LPCTSTR pcsz, int iFormat = makeNameLastFirst);
IU_API_EXPORT void FirstName(CString& sFirst, LPCTSTR pcsz, int iFormat = makeNameLastFirst);
IU_API_EXPORT void LastName(CString& sLast, LPCTSTR pcsz, int iFormat = makeNameLastFirst);
IU_API_EXPORT CString& MakeName(CString& sName, int iFormat, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMiddle, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle, int iFlags = 0);
IU_API_EXPORT void ParseName(LPCTSTR pcszName, int iFormat, CString* psLast, CString* psFirst, CString* psMiddle, CString* psGen, CString* psProSuffix, CString* psTitle);

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_PARSENAME_H_
