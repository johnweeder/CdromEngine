#include "StdAfx.h" 
//{{Include
#include "BTreeCodec.h"
#include "BTree.h"
#include "BTreeSpec.h"
#include "BTrees.h"
#include "Cdrom.h"
#include "CdromSpec.h"
#include "GeoSpec.h"
#include "SicSpec.h"
#include "AddressSpec.h"
#include "Common\NybbleString.h"
#include "resource.h"
#include "Error\Error.h"
#include "RecordFile.h"
#include "Common\Miscellaneous.h"
#include "Data\Output.h"
#include "Interop\Conversions.h"
#include "Common\String.h"
#include "Common\Clean.h"
#include "Globals\Macros.h"
#include "AltInstance.h"
#include "Solicit.h"
#include "Token.h"
#include "FieldDefConst.h"
#include "DemographicsBusiness.h"
#include "DemographicsResidential.h"
#include "Common\StaticBuffer.h"
#include "ResolveSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeCodec, CIuBTreeCodec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeCodec)
const BYTE bNull = 0;
const int iAdSizeCodeBits = 3;
const	CIuVersionNumber versionBTreeCodecMax(2000,1,6,2200);
const	CIuVersionNumber versionBTreeCodecMin(1999,0,1,100);
//}}Implement

// NOTE: In order to speed up loading of the btree codec, many objects are not serialized... primarily those
//			used only at compression. This means that an object must be "spec'd". You can't simply load it.

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREECODEC, CIuBTreeCodec, CIuBTreeCodec_super)
//{{AttributeMap
	// Some non-editable attributes, used to improve performance
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuBTreeCodec, IDS_ENGINE_PROP_KEYFLAGS, GetKeyFlags, SetKeyFlags, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuBTreeCodec, IDS_ENGINE_PROP_MISCELLANEOUSFLAGS, GetMiscellaneousFlags, SetMiscellaneousFlags, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuBTreeCodec, IDS_ENGINE_PROP_TOKENBITS, GetTokenBits, SetTokenBits, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuBTreeCodec, IDS_ENGINE_PROP_TOKENFLAGS, GetTokenFlags, SetTokenFlags, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuBTreeCodec, IDS_ENGINE_PROP_OPTIONALFLAGS, GetOptionalFlags, SetOptionalFlags, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_KEYDEF, GetKeyDef_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC, 50, 0)
	// Input object is _not_ serialized...
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_INPUT, GetInput_, SetObjectNotSupported, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_INPUT, IDS_ENGINE_PPG_BTREECODEC, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_PHONECOUNT, GetPhoneCount, SetPhoneCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_PHONECOUNT, IDS_ENGINE_PPG_BTREECODEC, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_GEOBITS, GetGeoBits, SetGeoBits, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_GEOBITS, IDS_ENGINE_PPG_BTREECODEC, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_FIXEDBITS, GetFixedBits, SetFixedBits, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_FIXEDBITS, IDS_ENGINE_PPG_BTREECODEC, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_KEYONLY, HasKeyOnly, SetKeyOnly, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_KEYONLY, IDS_ENGINE_PPG_BTREECODEC, editorReadOnly)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_TOKENIZERS, GetTokenizers_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_TOKENIZERS, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_KEYMAP, GetKeyMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_KEYMAP, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_GEOMAP, GetGeoMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_GEOMAP, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_MISCELLANEOUSMAP, GetMiscellaneousMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_MISCELLANEOUSMAP, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_PHONEMAP, GetPhoneMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_PHONEMAP, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_OPTIONALMAP, GetOptionalMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeCodec, IDS_ENGINE_PROP_OPTIONALMAP, IDS_ENGINE_PPG_BTREECODEC_OBJECTS, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_GEO, 50, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_HASGEO, HasGeo, SetHasGeo, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_HASGEO, IDS_ENGINE_PPG_BTREECODEC_GEO, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_GEOMONIKER, GetGeoMoniker, SetGeoMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_GEOMONIKER, IDS_ENGINE_PPG_BTREECODEC_GEO, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOCITYSTATECORRECTION, NoCityStateCorrection, SetNoCityStateCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOCITYSTATECORRECTION, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOMSACORRECTION, NoMsaCorrection, SetNoMsaCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOMSACORRECTION, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOCOUNTYCORRECTION, NoCountyCorrection, SetNoCountyCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOCOUNTYCORRECTION, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOLATLONGCORRECTION, NoLatLongCorrection, SetNoLatLongCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOLATLONGCORRECTION, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_LATLONGPRECISION, GetLatLongPrecision, SetLatLongPrecision, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_LATLONGPRECISION, IDS_ENGINE_PPG_BTREECODEC_GEO, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOZIPADDON, NoZipAddOn, SetNoZipAddOn, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOZIPADDON, IDS_ENGINE_PPG_BTREECODEC_GEO, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_ADDRESS, 50, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_HASADDRESS, HasAddress, SetHasAddress, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_HASADDRESS, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_ADDRESSMONIKER, GetAddressMoniker, SetAddressMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_ADDRESSMONIKER, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_ADDRESSCODEC, GetAddressCodec_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuBTreeCodec, IDS_ENGINE_PROP_ADDRESSCODEC, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_ALT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_ALTPHONE, IsAltPhone, SetAltPhone, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_ALTPHONE, IDS_ENGINE_PPG_BTREECODEC_ALT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_ALTCITY, IsAltCity, SetAltCity, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_ALTCITY, IDS_ENGINE_PPG_BTREECODEC_ALT, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_ALTMONIKER, GetAltMoniker, SetAltMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_ALTMONIKER, IDS_ENGINE_PPG_BTREECODEC_ALT, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_SOLICIT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICIT, GetNoSolicit, SetNoSolicit, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICIT, IDS_ENGINE_PPG_BTREECODEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICITMAIL, NoSolicitMail, SetNoSolicitMail, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICITMAIL, IDS_ENGINE_PPG_BTREECODEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICITPHONE, NoSolicitPhone, SetNoSolicitPhone, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_NOSOLICITPHONE, IDS_ENGINE_PPG_BTREECODEC, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_BUSRESFLAG, GetBusResFlag, SetBusResFlag, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_BUSRESFLAG, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_BUSONLY, IsBusOnly, SetBusOnly, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_BUSONLY, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_RESONLY, IsResOnly, SetResOnly, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeCodec, IDS_ENGINE_PROP_RESONLY, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_EMPLOYEESIZECODE, GetEmployeeSizeCode, SetEmployeeSizeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_EMPLOYEESIZECODE, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_SALESVOLUMECODE, GetSalesVolumeCode, SetSalesVolumeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_SALESVOLUMECODE, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_SICMONIKER, GetSicMoniker, SetSicMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeCodec, IDS_ENGINE_PROP_SICMONIKER, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_SICBITS, GetSicBits, SetSicBits, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_SICBITS, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeCodec, IDS_ENGINE_PROP_SICCOUNT, GetSicCount, SetSicCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeCodec, IDS_ENGINE_PROP_SICCOUNT, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_SICCODE, GetSicCode, SetSicCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_SICCODE, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_FRANCHISECODE, GetFranchiseCode, SetFranchiseCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_FRANCHISECODE, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_ADSIZECODE, GetAdSizeCode, SetAdSizeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_ADSIZECODE, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_FIRSTYEAR, GetFirstYear, SetFirstYear, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_FIRSTYEAR, IDS_ENGINE_PPG_BTREECODEC_BUSRES, 1, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreeCodec, IDS_ENGINE_PPG_BTREECODEC_SPECIAL, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_GENDER, GetGender, SetGender, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeCodec, IDS_ENGINE_PROP_GENDER, IDS_ENGINE_PPG_BTREECODEC_SPECIAL, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Some flags for the codec
const int codecFlagNumeric = 0x00000001;			// Numeric stringizer

// Enough bits to store addon's from 0-9999. Note, we are wasting considerable space.
const int iZipAddonBits = 15;

// Flags for phone numbers
// Note, we store the top 6 phone prefixes. This may seem like an odd number, but it
// has to do with the engine encoding.
//	Prefixes 0-5 are special cases. They are stored along with the 4 lower digits of the phone.
//	Since, the lower 4 digits range from 0-9999 and there are 6 possible prefixes, this gives
//	a combined range or 0-59,999. This fits nicely in a 16-bit number.
// Note that the lower 4 digits would require 16 bits of storage anyway becuase the engine
// aligns bits on 4 bit boundaries.
const BYTE bPhone10	= 0x03;			// The full 10 digit phone is stored
												// The area code matches the geo, so only the lower 7 digits are stored.
const BYTE bPhone7	= 0x02;			// The 7 digit phone is stored. The AC matched the geo.
const BYTE bPhone4	= 0x01;			// Only the lower 4 digits are stored. The AC matched the geo. The top prefix
												// Preferred prefix 0-5 is used.
const BYTE bPhone0	= 0x00;			// Nothing is stored, the phone is empty
												// Preferred prefix 6-11 is used.
const int iPhoneBits = 2;

// "Special" address tokens
const int iAddressEmpty		= 11;
const int iAddressRR			= 12;
const int iAddressHC			= 13;
const int iAddressPOBOX		= 14;
const int iAddressEncoded	= 15;

CIuBTreeCodec::CIuBTreeCodec() 
{
	CommonConstruct();
}

CIuBTreeCodec::~CIuBTreeCodec()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeCodec::Close()
{
	m_pInput->Close();
	m_adwPointers.SetSize(0);
	if (m_pGeo.NotNull())
		m_pGeo->Close(geoCodec, false);
	m_pGeo.Release();
	if (m_pSic.NotNull())
		m_pSic->Close();
	m_pSic.Release();
	if (m_pAddress.NotNull())
		m_pAddress->Close();
	m_pAddress.Release();
	if (m_pAlt.NotNull())
		m_pAlt->Close();
	m_pAlt.Release();
	GetTokenizers().Close();
	m_fNextRecord = false;
	m_pOutput = 0;
}

void CIuBTreeCodec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pStats = 0;
	if (m_pInput.IsNull())
	{
		// Initially, use the standard record layout
		m_pInput.Create();
	}
	if (m_pAddressCodec.IsNull())
	{
		m_pAddressCodec.Create();
	}
	m_fHasGeo = true;
	m_iFixedBits = 0;
	m_iGeoBits = 0;
	m_monikerGeoMoniker.Clear();
	m_aiKeyFlags.RemoveAll();
	m_aiMiscellaneousFlags.RemoveAll();
	m_iPhoneCount = 0;
	m_Tokenizers.SetCodec(this);
	m_aiTokenBits.RemoveAll();
	m_aiTokenFlags.RemoveAll();
	m_aiOptionalFlags.RemoveAll();
	m_fKeyOnly = false;
	m_fNextRecord = false;
	m_fNoZipAddOn = false;
	m_iLatLongPrecision = 0;
	m_pObjectRepository = 0;
	m_monikerAltMoniker.Clear();
	m_iMinimumRecordSize = 0;
	m_fAltPhone = false;
	m_fAltCity = false;
	m_sNoSolicit = "";
	m_fNoSolicitMail = false;
	m_fNoSolicitPhone = false;
	m_fNoCityStateCorrection = false;
	m_fNoMsaCorrection = false;
	m_fNoCountyCorrection = false;
	m_fNoLatLongCorrection = false;
	m_fResOnly = false;
	m_fBusOnly = false;
	m_sBusResFlag = "";
	m_sEmployeeSizeCode = "";
	m_sSalesVolumeCode = "";
	m_sGender = "";
	m_iSicCount = 0;
	m_sSicCode = "";
	m_sFranchiseCode = "";
	m_sAdSizeCode = "";
	m_sFirstYear = "";
	m_monikerSicMoniker.Clear();
	m_fHasAddress = false;
	m_monikerAddressMoniker.Clear();
	m_iSicBits = 0;
	m_iSicCode = -1;
	m_iFranchiseCode = -1;
	m_iAdSizeCode = -1;
	m_iFirstYear = -1;
	// This affects the years in database encoding
	// You can override this if desired. It defaults to the current year.
	m_iCurrentYear = COleDateTime::GetCurrentTime().GetYear();
	m_pObjectRepository = 0;
	SetVersion(versionBTreeCodecMax);
	m_fHasAddress = false;
	//}}Initialize
}

bool CIuBTreeCodec::Compress(CIuOutput&)
{
	// Returns true if a record was compressed, else false if nothing left.

	// Only set pointer array to 1, this prevents a 'delete' from happening.
	// We are going to have at least one pointer anyway (unless this is an alt record).
	m_adwPointers.SetSize(1);

	// If the previous was an alternate record, there is no need to go through all
	// this work to find a key. We already have it.
	// Otherwise, we need to get a key
	if (!m_fPrevAlt)
	{
		// Read a record
		if (m_fNextRecord)
		{
			// Copy record by value.... (Yes, we are copying from a rawrecord to a	
			// rawrecordptr, this is correct)
			m_pRawRecord = *m_pRecordNext.Ptr();
			m_fNextRecord = false;
		}
		else
		{
			if (!GetInput().MoveNext(m_pRawRecord))
				m_fRecordsExhausted = true;
		}

		if (!m_fRecordsExhausted)
		{
			// Build the key fields for the record
			m_pRecord.Map(*m_pRawRecord, m_Map);

			// Build the key itself...
			m_key.Clear();
			for (int iKey = m_iKeyFirst; iKey < m_iKeyFirst + m_iKeyCount; ++iKey)
			{
				LPCTSTR pcszField = m_pRecord->GetField(iKey);
				Clean(m_Temp, pcszField, cleanTrim|cleanTruncateLeft, fieldDftLength);
				m_key.Append(m_Temp, GetKeyDef());
			}

			// Store it's pointer
			m_adwPointers.SetAt(0, m_pRawRecord->GetRecordNo());

			if (GetBTree().HasMultiPointers())
			{
				m_fNextRecord = true;
				while (m_fNextRecord)
				{
					if (!GetInput().MoveNext(m_pRecordNext))
						m_fNextRecord = false;
					else
					{
						m_pRecordNextKey.Map(*m_pRecordNext, GetKeyMap());
						m_keyNext.Clear();
						int iKeys = GetKeyMap().m_iFields;
						for (int iKey = 0; iKey < iKeys; ++iKey)
						{
							Clean(m_Temp, m_pRecordNextKey->GetField(iKey), cleanTrim|cleanTruncateLeft, fieldDftLength);
							m_keyNext.Append(m_Temp, GetKeyDef());
						}
						int iResult = m_keyNext.Compare(GetKey());

						if (iResult < 0)
						{
#ifdef _DEBUG
							afxDump.HexDump("1:", (unsigned char*)m_keyNext.GetKeyPtr(), m_keyNext.GetKeySize(), 16);
							afxDump.HexDump("2:", (unsigned char*)GetKey().GetKeyPtr(), GetKey().GetKeySize(), 16);
							ASSERT(iResult >= 0);
#endif
							CString sError;
							sError.Format("Input records not in sort order @ %d (2).\n%s\n%s",
								GetInput().GetNextRecord() - 1, LPCTSTR(GetKey().GetKeyPtr()), LPCTSTR(m_keyNext.GetKeyPtr()));
							Error(IU_E_COMPRESS_FATAL, LPCTSTR(sError));
						}
						if (iResult > 0)
							break;
						// Same key....
						m_adwPointers.Add(m_pRecordNext->GetRecordNo());
					}
				}
			}
		}
	}
	else
	{
		// Rebuild the record pointers and the record key
		m_adwPointers.Copy(m_adwPrevPointers);

		// Build the key itself...
		m_key.Clear();
		for (int iKey = m_iKeyFirst; iKey < m_iKeyFirst + m_iKeyCount; ++iKey)
		{
			Clean(m_Temp, m_pRecord->GetField(iKey), cleanTrim|cleanTruncateLeft, fieldDftLength);
			m_key.Append(m_Temp, GetKeyDef());
		}	
	}

	// Compress data if needed
	if (!GetBTree().HasData())
		return !m_fRecordsExhausted;

	m_record.Empty();
	int iKeyNybbles = 0;
	int iFixedBits = 0;
	int iVariableBits = 0;
	int iVariableNybbles = 0;

	if (!CompressAlt(m_fRecordsExhausted))
	{
		if (m_fRecordsExhausted)
			return false;

		CompressKey();
		iKeyNybbles = m_record.GetNybbles();

		if (!HasKeyOnly())
		{
			m_bitsFixed.Empty();
			m_bitsVariable.Empty();
			m_nybblesVariable.Empty();

#ifdef _DEBUG
			// In case we want to know what record we were on
			// when we blew up.
			int iNextRecord = GetInput().GetNextRecord();
			UNUSED_ALWAYS(iNextRecord);
#endif

			CompressGeo();
			CompressAddress();
			CompressNoSolicit();
			if (IsBusOnly())
				CompressBus();
			else if (IsResOnly())
				CompressRes();
			else if (HasBusResFlag())
			{
				if (CompressBusResFlag())
					CompressRes();
				else
					CompressBus();
			}

			CompressTokens();
			CompressMiscellaneous();
			CompressPhone();
			CompressOptional();
			CompressSpecial();

			// Finish packing up everything

			// First, append the variable bits to the fixed bits
			if (m_bitsFixed.GetBitCount() != GetFixedBits())
			{
				CString sDebug;
				sDebug.Format(_T("Invalid number of fixed bits output.\nOutput %d, expected %d"), m_bitsFixed.GetBitCount(), GetFixedBits());
				Error(IU_E_COMPRESS_FATAL, sDebug);
			}
			iVariableBits = m_bitsVariable.GetBitCount();
			iFixedBits = m_bitsFixed.GetBitCount();
			m_bitsFixed.Append(m_bitsVariable);

			// Then append both the bits and the variables nybbles to the record
			// Note that the bits actually appended in reverse order.
			// On decompress, bits are consumed from the front while
			// nybbles are consumed from the rear.
			iVariableNybbles = m_nybblesVariable.GetNybbles();
			m_record.Append(m_bitsFixed);
			m_record.AppendReverse(m_nybblesVariable);
		}
		m_fPrevAlt = false;
	}
	else
	{
		m_fPrevAlt = true;
		m_pStats->m_iTotalAlternates++;
	}

	m_pStats->m_iTotalKeyNybbles += iKeyNybbles;
	m_pStats->m_iTotalFixedBits += iFixedBits;
	m_pStats->m_iTotalVariableBits += iVariableBits;
	m_pStats->m_iTotalVariableNybbles += iVariableNybbles;
	return true;
}

void CIuBTreeCodec::CompressAddress()
{
	if (!HasAddress())
		return ;

	// Begin by saving statistics
	int iFixedBits0 = m_bitsFixed.GetBitCount();
	int iVariableBits0 = m_bitsVariable.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();

	//	
	// An Address input consists of:
	//		PriNo
	//		PreDir
	//		StreetName
	//		Suffix
	//		PostDir
	//		SecNo
	//		Street (full name, ouput only)
	// In addition, these fields may be used at input time to properly format an address:
	//		HighRise Flag 
	//		Non-solicitation flag
	//	
	//	These are some sample statistics from a run the address codec.
	// 113 183 716 total
	//  98 735 668 named (909001 unique)
	//  14 448 048 empty
	//   1 475 913 RR
	//     108 104 HC
	//       5 509 GD
	//     667 034 POBOX
	//  10 385 807 ordinal/numeric streets
	//   9 749 414 ordinal, 636393 numeric
	//					4045165 < 16, 5701687 < 256, 579031 < 4096, 59856 < 65536
	//  94 075 270 numeric prino's
	//					4781935 < 16, 18766890 < 256, 47122745 < 4096
	//   2 374 735 numeric secno's
	//					515028 < 16, 1054501 < 256, 769876 < 4096
	//   2 960 685 trailing street numerics
	//					377311 < 16, 1743945 < 256, 811928 < 4096
	//  21 447 592 predirs
	//   6 475 703 postdirs

	// The first step is to map out the raw address pieces
	VERIFY(GetAddressCodec().Process(*m_pRawRecord));

	// We then process one of the following basic address types
	// The first two bits are always part of the "fixed" bits
	// All of the rest of the data is "variable"
	// 00		(0)	Tokenized street (token value < 10 or special)
	// 					Empty
	// 					RR
	// 					HC
	// 					POBOX
	// 					Encoded
	// 01		(1)	Tokenized street < 4906
	// 10		(2)	Tokenized street < 65536
	// 11 0	(6)	Ordinal street < 16
	// 11 1	(7)	Ordinal street < 256

	// These flags control the processing
	int iFlags = GetAddressCodec().GetFlags();
	bool fPriNo = false;
	bool fSecNo = false;
	bool fSuffix = false;
	bool fPrePostDir = false;
	bool fStreetName = false;

	int iDefaultPreDir = dirNone;
	int iDefaultPostDir = dirNone;
	int iDefaultSuffix = 1; // Blank is alway 0, next is the most frequent

	// Handle special cases
	if ((iFlags & addressEmpty) != 0)
	{
		m_bitsFixed.AppendInt(0x00, 2);
		CIuNybbleInt::AppendInt(iAddressEmpty, 4, m_nybblesVariable);
	}
	else if ((iFlags & addressRR) != 0)
	{
		m_bitsFixed.AppendInt(0x00, 2);
		CIuNybbleInt::AppendInt(iAddressRR, 4, m_nybblesVariable);
		fPriNo = true;
		fSecNo = true;
	}
	else if ((iFlags & addressHC) != 0)
	{
		m_bitsFixed.AppendInt(0x00, 2);
		CIuNybbleInt::AppendInt(iAddressHC, 4, m_nybblesVariable);
		fPriNo = true;
		fSecNo = true;
	}
	else if ((iFlags & addressPOBOX) != 0)
	{
		m_bitsFixed.AppendInt(0x00, 2);
		CIuNybbleInt::AppendInt(iAddressPOBOX, 4, m_nybblesVariable);
		fPriNo = true;
	}
	else if ((iFlags & addressOrdinalStreet) != 0)
	{
		int iStreetNo = GetAddressCodec().GetStreetNo();
		ASSERT(iStreetNo >= 0);
		if (iStreetNo < 16)
		{
			m_bitsFixed.AppendInt(0x03, 2);
			m_bitsVariable.AppendInt(0x00, 1);
			CIuNybbleInt::AppendInt(iStreetNo, 4, m_nybblesVariable);
		}
		else if (iStreetNo < 256)
		{
			m_bitsFixed.AppendInt(0x03, 2);
			m_bitsVariable.AppendInt(0x01, 1);
			CIuNybbleInt::AppendInt(iStreetNo, 8, m_nybblesVariable);
		}
		else
			fStreetName = true;

		fPriNo = true;
		fSecNo = true;
		fSuffix = true;
		fPrePostDir = true;
	}
	else
	{
		fStreetName = true;
		fPriNo = true;
		fSecNo = true;
		fSuffix = true;
		fPrePostDir = true;
	}

	if (fStreetName)
	{
		int iSuffixNo = m_pAddress->FindSuffix(GetAddressCodec().GetSuffix());
		int iStreetToken = m_pAddress->FindStreetName(GetAddressCodec().GetStreetName(), iSuffixNo);
		if (iStreetToken >= 0 && iStreetToken < 65536 + 4096 + 11)
		{
			iDefaultPreDir = m_pAddress->GetStreetNamePreDir(iStreetToken);
			iDefaultPostDir = m_pAddress->GetStreetNamePostDir(iStreetToken);
			iDefaultSuffix = m_pAddress->GetStreetNameSuffix(iStreetToken);

			if (iStreetToken < 11)
			{
				m_bitsFixed.AppendInt(0x00, 2);
				CIuNybbleInt::AppendInt(iStreetToken, 4, m_nybblesVariable);
				fStreetName = false;
			}
			else if (iStreetToken < 4096 + 11)
			{
				m_bitsFixed.AppendInt(0x01, 2);
				CIuNybbleInt::AppendInt(iStreetToken - 11, 12, m_nybblesVariable);
				fStreetName = false;
			}
			else 
			{
				ASSERT(iStreetToken < 65536 + 4096 + 11);
				m_bitsFixed.AppendInt(0x02, 2);
				CIuNybbleInt::AppendInt(iStreetToken - (4096 + 11), 16, m_nybblesVariable);
				fStreetName = false;
			}
		}
	}

	// If all else fails, use nybble alpha encoder
	if (fStreetName)
	{
		m_bitsFixed.AppendInt(0x00, 2);
		CIuNybbleInt::AppendInt(iAddressEncoded, 4, m_nybblesVariable);
		CIuNybbleString::Append(GetAddressCodec().GetStreetName(), -1, NS_ALPHA, m_nybblesVariable);
	}

	// Primary number
	//		00	(0)	Numeric < 256 (0==none)
	//		01	(1)	Numeric < 4096+256
	//		10 (2)	Numeric < 65536+4096+256
	//		11 (3)	Other
	//	Note: A numeric primary number is offset by 1. The value 0
	//			implies a blank primary number
	if (fPriNo)
	{
		if (GetAddressCodec().GetPriNo().IsEmpty())
		{
			m_bitsVariable.AppendInt(0x00, 2);
			CIuNybbleInt::AppendInt(0x00, 8, m_nybblesVariable);
			fPriNo = false;
		}
		else if ((iFlags & addressNumericPriNo) != 0)
		{
			int iPriNo = GetAddressCodec().GetPriNoNo();
			ASSERT(iPriNo >= 0);
			++iPriNo;
			if (iPriNo < 256)
			{
				m_bitsVariable.AppendInt(0x00, 2);
				CIuNybbleInt::AppendInt(iPriNo, 8, m_nybblesVariable);
				fPriNo = false;
			}
			else if (iPriNo < 256 + 4096)
			{
				m_bitsVariable.AppendInt(0x01, 2);
				CIuNybbleInt::AppendInt(iPriNo - 256, 12, m_nybblesVariable);
				fPriNo = false;
			}
			else if (iPriNo < 256 + 4096 + 65536)
			{
				m_bitsVariable.AppendInt(0x02, 2);
				CIuNybbleInt::AppendInt(iPriNo - 256 - 4096, 16, m_nybblesVariable);
				fPriNo = false;
			}
		}
		if (fPriNo)
		{
			m_bitsVariable.AppendInt(0x03, 2);
			CIuNybbleString::Append(GetAddressCodec().GetPriNo(), -1, NS_NUMERIC, m_nybblesVariable);
		}
	}

	// Secondary number
	//		0	(0)	No secondary number
	//		10 (2)	Numeric < 4096
	//		11 (3)	Other
	if (fSecNo)
	{
		if (GetAddressCodec().GetSecNo().IsEmpty())
		{
			m_bitsVariable.AppendInt(0x00, 1);
		}
		else 
		{
			m_bitsVariable.AppendInt(0x01, 1);
			if ((iFlags & addressNumericSecNo) != 0 && GetAddressCodec().GetSecNoNo() < 4096)
			{
				m_bitsVariable.AppendInt(0x00, 1);
				CIuNybbleInt::AppendInt(GetAddressCodec().GetSecNoNo(), 12, m_nybblesVariable);
			}
			else
			{
				m_bitsVariable.AppendInt(0x01, 1);
				CIuNybbleString::Append(GetAddressCodec().GetSecNo(), -1, NS_NUMERIC, m_nybblesVariable);
			}
		}
	}

	// Suffix
	//		0									Default suffix
	//		1	bbb	(0-6)					One of the top 7 suffix (covers about 90%)
	//		1	bbb	(7)	nnnn nnnn	Full suffix token (- 7) follows
	if (fSuffix)
	{
		int iSuffixNo = m_pAddress->FindSuffix(GetAddressCodec().GetSuffix());
		// If not found, blank it out
		if (iSuffixNo < 0)
			iSuffixNo = 0;
		if (iSuffixNo == iDefaultSuffix)
			m_bitsVariable.AppendInt(0x00, 1);
		else
		{
			m_bitsVariable.AppendInt(0x01, 1);
			if (iSuffixNo < 7)
			{
				m_bitsVariable.AppendInt(iSuffixNo, 3);
			}
			else 
			{
				m_bitsVariable.AppendInt(0x07, 3);
				iSuffixNo -= 7;
				ASSERT(iSuffixNo >= 0 && iSuffixNo < 256);
				CIuNybbleInt::AppendInt(iSuffixNo, 8, m_nybblesVariable);
			}
		}
	}

	// Pre/Post Directional
	//		0	 (0)					Neither/Default
	//		10	 (2)	nnnn			PreDir only
	//		110 (6)	nnnn			PostDir Only
	//		111 (7)	nnnn nnnn	Both pre/post dir
	// NOTE: Due to a ?bug?, if you "put" bits 01, you are not necessary guaranteed the 
	//	order if you retrieve them one bit at a time. Therefore, bits are output one at a time
	if (fPrePostDir)
	{
		if (GetAddressCodec().GetPreDirNo() == iDefaultPreDir && GetAddressCodec().GetPostDirNo() == iDefaultPostDir)
		{
			m_bitsVariable.AppendInt(0x00, 1);
		}
		else
		{
			m_bitsVariable.AppendInt(0x01, 1);
			if (GetAddressCodec().GetPreDirNo() != iDefaultPreDir && GetAddressCodec().GetPostDirNo() == iDefaultPostDir)
			{
				m_bitsVariable.AppendInt(0x00, 1);
			}
			else
			{
				m_bitsVariable.AppendInt(0x01, 1);
				if (GetAddressCodec().GetPreDirNo() == iDefaultPreDir && GetAddressCodec().GetPostDirNo() != iDefaultPostDir)
				{
					m_bitsVariable.AppendInt(0x00, 1);
				}
				else
				{
					ASSERT(GetAddressCodec().GetPreDirNo() != iDefaultPreDir && GetAddressCodec().GetPostDirNo() != iDefaultPostDir);
					m_bitsVariable.AppendInt(0x01, 1);
				}
			}
		}
		if (GetAddressCodec().GetPreDirNo() != iDefaultPreDir)
		{
			int iPreDirNo = GetAddressCodec().GetPreDirNo();
			ASSERT(iPreDirNo >= 0 && iPreDirNo < 16);
			CIuNybbleInt::AppendInt(iPreDirNo, 4, m_nybblesVariable);
		}
		if (GetAddressCodec().GetPostDirNo() != iDefaultPostDir)
		{
			int iPostDirNo = GetAddressCodec().GetPostDirNo();
			ASSERT(iPostDirNo >= 0 && iPostDirNo < 16);
			CIuNybbleInt::AppendInt(iPostDirNo, 4, m_nybblesVariable);
		}
	}

	// Update statistics
	int iFixedBits1 = m_bitsFixed.GetBitCount();
	int iVariableBits1 = m_bitsVariable.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();

	m_pStats->m_iTotalAddressFixedBits += (iFixedBits1 - iFixedBits0);
	ASSERT((iFixedBits1 - iFixedBits0) == 2);
	m_pStats->m_iTotalAddressVariableBits += (iVariableBits1 - iVariableBits0);
	m_pStats->m_iTotalAddressNybbles += (iNybbles1 - iNybbles0);
}

bool CIuBTreeCodec::CompressAlt(bool fRemainder)
{
	// This routine is used by the codec to find a range of "see also" records
	// to be inserted into the output stream. 
	// See also records are assumed to have a "comma" (',') at the end of the key.
	// This causes them to insert in proper order. For example:
	// Assume the input stream is:
	//		Smith Barber shop
	//		Smith, Zach
	// We need the "see also" for "smith" to insert between those two records. Therefore,
	// we must append a character less than or equal a comma (and less than a alpha/number). 
	// There are some special modes.
	// The "alt phone" mode only inserts records matching the prefix of the next record.
	//		I.e. 402428 is only inserted if the next record has phone# 402428xxxx
	// The "alt city" mode only inserts if the state in the record is part of this
	// region.
	if (!m_fHasAlt)
		return false;

	while (m_iAlt < m_pAlt->GetAltCount())
	{
		// At the end of the file we simply insert the rest of the see-also records.
		// There is no need to bother with these checks.
		if (!fRemainder)
		{
			ASSERT(m_iKeyCount >= 0);

			LPCTSTR pcszKey = m_pRecord->GetField(m_iKeyFirst);
			Clean(m_Temp, pcszKey, cleanTrim|cleanTruncateLeft, fieldDftLength);

			if (m_Temp.GetSize() == 1)
				Error(IU_E_KEY_INVALID, _T("Actual key is empty."));

			int iResult = _tcsicmp(m_sAlt, m_Temp);
			if (iResult == 0)
			{
				CString sError;
				sError.Format(_T("Actual key matches alternate record key.\n[%s]\n[%s]"), LPCTSTR(m_sAlt), LPCTSTR(m_Temp));
				Error(IU_E_KEY_INVALID, LPCTSTR(sError));
			}
			if (iResult > 0)
				return false;
			if (IsAltPhone())
			{
				// Must match prefix of next record
				int iResult = _tcsnicmp(m_sAlt, m_Temp, m_sAlt.GetLength() - 1);
				if (iResult != 0)
				{
					NextAlt();
					continue;
				}
			}
		}
		else
		{
			if (IsAltPhone())
				return false;
		}

		if (IsAltCity())
		{
			// City must be in geography object
			if (m_pGeo.IsNull())
				return false;
			LPCTSTR pcszState = _tcschr(m_sAlt, ',');
			if (pcszState == 0)
			{
				NextAlt();				
				continue;
			}
			++pcszState;
			while (*pcszState && _istspace(*pcszState))
				++pcszState;
			if (pcszState[1] == '\0' || pcszState[2] == '\0')
			{
				NextAlt();				
				continue;
			}
			TCHAR szState[3];
			szState[0] = pcszState[0];
			szState[1] = pcszState[1];
			szState[2] = '\0';
			if (m_pGeo->GetState().Find(szState) < 0)
			{
				NextAlt();				
				continue;
			}
		}

		// Get the record
		CIuAltInstance Instance;
		m_pAlt->Get(m_iAlt, Instance);

		// Append a null character to indicate a "see also" record
		m_record.Append(0);

		// Build a key WITH a trailing comman
		m_key.Clear();
		m_key.Append(m_sAlt, GetKeyDef());

		// Append the key without the trailing comma
		int iLength = m_sAlt.GetLength();
		ASSERT(iLength > 1);
		ASSERT(m_sAlt[iLength - 1] == ',');
		CString sAlt = m_sAlt.Left(iLength - 1);
		bool fNumeric = (m_aiKeyFlags[0] & codecFlagNumeric) != 0;
		CIuNybbleString::Append(sAlt, -1, fNumeric ? NS_NUMERIC: NS_ALPHA, m_record);

		// Get the remainder of the text
		CIuNybbleString::Append(Instance.GetValue(m_iAltValue), -1, NS_ALPHA, m_record);

		// We need to set the size to zero. Unfortunately, this actually frees the
		// memory allocate for the array
		if (!m_fPrevAlt)
			m_adwPrevPointers.Copy(m_adwPointers);
		m_adwPointers.SetSize(0);

		// Pad with nulls to minimum record size
		while (m_record.GetNybbles() < GetMinimumRecordSize())
			m_record.Append(0);
		
		NextAlt();
		return true;
	}
	return false;
}

void CIuBTreeCodec::CompressBus()
{
	++m_pStats->m_iTotalBus;
	int iBits0 = m_bitsFixed.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();
	if (m_iEmployeeSizeCode >= 0)
	{
		ASSERT(::BitsRequired(EmployeeSizeCount()) <= 4);
		// Employee size is a 4-bit code
		LPCTSTR pcszEmployeeSize = m_pRecord->GetField(m_iEmployeeSizeCode);
		ASSERT(pcszEmployeeSize[0] == '\0' || pcszEmployeeSize[1] == '\0');
		int iCode = EmployeeSizeFromCode(*pcszEmployeeSize);
		m_nybblesVariable.Append(BYTE(iCode));
	}
	if (m_iSalesVolumeCode >= 0)
	{
		ASSERT(::BitsRequired(SalesVolumeCount()) <= 4);
		// Sales volume is a 4-bit code
		LPCTSTR pcszSalesVolume = m_pRecord->GetField(m_iSalesVolumeCode);
		ASSERT(pcszSalesVolume[0] == '\0' || pcszSalesVolume[1] == '\0');
		int iCode = SalesVolumeFromCode(*pcszSalesVolume);
		m_nybblesVariable.Append(BYTE(iCode));
	}

	if (GetSicCount() > 0 && m_iSicCode >= 0)
	{
		m_Sics.SetField(*m_pRecord, m_iSicCode);
		int iSics = min(GetSicCount(), m_Sics.GetFields());
		if (m_iFranchiseCode >= 0)
		{
			m_Franchises.SetField(*m_pRecord, m_iFranchiseCode);
			ASSERT(m_Sics.GetFields() == m_Franchises.GetFields());
		}
		if (m_iAdSizeCode >= 0)
		{
			m_AdSizeCodes.SetField(*m_pRecord, m_iAdSizeCode);
			ASSERT(m_Sics.GetFields() == m_AdSizeCodes.GetFields());
		}
		if (m_iFirstYear >= 0)
		{
			m_FirstYears.SetField(*m_pRecord, m_iFirstYear);
			ASSERT(m_Sics.GetFields() == m_FirstYears.GetFields());
		}

		CIuNybbleInt::AppendUIntCompressed(iSics, m_nybblesVariable);

		// Compress them
		for (int iSic = 0; iSic < iSics; ++iSic)
		{
			LPCTSTR pcszSic = m_Sics.GetField(iSic);
			ASSERT(_tcslen(pcszSic) == 6);

			ASSERT(m_pSic.NotNull());
			int iSicCode = m_pSic->Find(pcszSic);
			if (iSicCode < 0)
				Error(IU_E_SIC_NOT_FOUND, pcszSic);

			m_bitsVariable.AppendInt(iSicCode, GetSicBits());

			if (m_iFranchiseCode >= 0)
			{
				LPCTSTR pcszFranchiseCode = m_Franchises.GetField(iSic);
				if (*pcszFranchiseCode)
				{
					m_bitsVariable.AppendInt(1, 1);
					m_pSic->EncodeFranchise(iSicCode, pcszFranchiseCode, m_nybblesVariable);
				}
				else
					m_bitsVariable.AppendInt(0, 1);
			}
			if (m_iAdSizeCode >= 0)
			{
				// Ad size is a iAdSizeCodeBits-bit code
				ASSERT(::BitsRequired(AdSizeCount()) <= iAdSizeCodeBits);
				LPCTSTR pcszAdSizeCode = m_AdSizeCodes.GetField(iSic);
				ASSERT(pcszAdSizeCode[0] == '\0' || pcszAdSizeCode[1] == '\0');

				int iCode = AdSizeFromCode(*pcszAdSizeCode);
				m_bitsVariable.AppendInt(iCode, iAdSizeCodeBits);
			}
			if (m_iFirstYear >= 0)
			{
				LPCTSTR pcszFirstYear = m_FirstYears.GetField(iSic);
				int iFirstYear = StringAsInt(pcszFirstYear);
				int iYearsInDb;
				if (iFirstYear >= m_iCurrentYear)
					iYearsInDb = 0;
				else 
					iYearsInDb = m_iCurrentYear - iFirstYear;
				iYearsInDb = max(0, iYearsInDb);

				ASSERT(iYearsInDb >= 0);
				iYearsInDb = min(iYearsInDb, 15);
				m_nybblesVariable.Append(BYTE(iYearsInDb));
			}
		}
	}
	int iBits1 = m_bitsFixed.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();
	m_pStats->m_iTotalBusBits += (iBits1 - iBits0);
	m_pStats->m_iTotalBusNybbles += (iNybbles1 - iNybbles0);
}

bool CIuBTreeCodec::CompressBusResFlag()
{
	LPCTSTR pcszBusResFlag = m_pRecord->GetField(m_iBusResFlag);
	ASSERT(pcszBusResFlag);
	if (*pcszBusResFlag == 'R' || *pcszBusResFlag == 'r')
	{
		m_bitsFixed.AppendInt(1, 1);
		return true;
	}
	else
	{
		m_bitsFixed.AppendInt(0, 1);
		return false;
	}
}

void CIuBTreeCodec::CompressGeo()
{
	if (!HasGeo())
		return ;

	int iBits0 = m_bitsFixed.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();

	m_GeoCodec.Set(*m_pRawRecord, GetGeoMap());
	m_pGeo->Encode(m_GeoCodec, GetBTree().GetStats());
	m_bitsFixed.AppendInt(m_GeoCodec.GetZipNo(), GetGeoBits());

	if (!NoCityStateCorrection())
	{
		if (m_GeoCodec.HasNoCity() || m_GeoCodec.GetCityDelta() != 0)
		{
			m_bitsFixed.AppendInt(1, 1);
			m_pStats->m_iTotalCityCorrections++;
			if (m_GeoCodec.HasNoCity())
				CIuNybbleInt::AppendIntCompressed(0, m_nybblesVariable);
			else
				CIuNybbleInt::AppendIntCompressed(m_GeoCodec.GetCityDelta(), m_nybblesVariable);
		}
		else
			m_bitsFixed.AppendInt(0, 1);
	}

	if (!NoMsaCorrection())
	{
		if (m_GeoCodec.HasNoMsa() || m_GeoCodec.GetMsaDelta() != 0)
		{
			m_bitsFixed.AppendInt(1, 1);
			m_pStats->m_iTotalMsaCorrections++;
			if (m_GeoCodec.HasNoMsa())
				CIuNybbleInt::AppendIntCompressed(0, m_nybblesVariable);
			else
				CIuNybbleInt::AppendIntCompressed(m_GeoCodec.GetMsaDelta(), m_nybblesVariable);
		}
		else
			m_bitsFixed.AppendInt(0, 1);
	}

	if (!NoCountyCorrection())
	{
		if (m_GeoCodec.HasNoCounty() || m_GeoCodec.GetCountyDelta() != 0)
		{
			m_bitsFixed.AppendInt(1, 1);
			m_pStats->m_iTotalCountyCorrections++;
			if (m_GeoCodec.HasNoCounty())
				CIuNybbleInt::AppendIntCompressed(0, m_nybblesVariable);
			else
				CIuNybbleInt::AppendIntCompressed(m_GeoCodec.GetCountyDelta(), m_nybblesVariable);
		}
		else
			m_bitsFixed.AppendInt(0, 1);
	}

	if (!NoLatLongCorrection())
	{
		if (m_GeoCodec.HasNoLatLong() || m_GeoCodec.GetLatitudeDelta() != 0 || m_GeoCodec.GetLongitudeDelta() != 0)
		{
			m_bitsFixed.AppendInt(1, 1);
			m_pStats->m_iTotalLatLongCentroidCorrections++;
			m_pStats->m_iTotalLatCentroidDelta += ABS(m_GeoCodec.GetLatitudeDelta());
			m_pStats->m_iTotalLongCentroidDelta += ABS(m_GeoCodec.GetLongitudeDelta());
			CIuNybbleInt::AppendIntCompressed(m_GeoCodec.GetLatitudeDelta(), m_nybblesVariable);
			CIuNybbleInt::AppendIntCompressed(m_GeoCodec.GetLongitudeDelta(), m_nybblesVariable);
		}
		else
			m_bitsFixed.AppendInt(0, 1);
	}

	if (!NoZipAddOn())
	{
		CString sAddon = m_GeoCodec.GetZipAddon();
		int iZipAddon = StringAsInt(sAddon);
		if (iZipAddon != 0)
			m_pStats->m_iTotalZip4++;
		ASSERT(iZipAddon < (1 << iZipAddonBits));
		m_bitsVariable.AppendInt(iZipAddon, iZipAddonBits);
	}
	int iBits1 = m_bitsFixed.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();
	m_pStats->m_iTotalGeoBits += (iBits1 - iBits0);
	m_pStats->m_iTotalGeoNybbles += (iNybbles1 - iNybbles0);

}

void CIuBTreeCodec::CompressKey()
{
	ASSERT(m_iKeyCount != 0);
	for (int iKey = m_iKeyFirst; iKey < m_iKeyFirst + m_iKeyCount; ++iKey)
	{
		Clean(m_Temp, m_pRecord->GetField(iKey), cleanTrim|cleanTruncateLeft, fieldDftLength);

		bool fNumeric = (m_aiKeyFlags[iKey - m_iKeyFirst] & codecFlagNumeric) != 0;
		CIuNybbleString::Append(m_Temp, m_Temp.GetSize(), fNumeric ? NS_NUMERIC: NS_ALPHA, m_record);
	}
}

void CIuBTreeCodec::CompressMiscellaneous()
{
	if (m_iMiscellaneousCount == 0)
		return ;

	int iBits0 = m_bitsFixed.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();
	for (int iMisc = m_iMiscellaneousFirst; iMisc < m_iMiscellaneousFirst + m_iMiscellaneousCount; ++iMisc)
	{
		Clean(m_Temp, m_pRecord->GetField(iMisc), cleanTrim|cleanTruncateLeft, fieldDftLength);

		bool fNumeric = (m_aiMiscellaneousFlags[iMisc - m_iMiscellaneousFirst] & codecFlagNumeric) != 0;
		CIuNybbleString::Append(m_Temp, m_Temp.GetSize(), fNumeric ? NS_NUMERIC: NS_ALPHA, m_nybblesVariable);
	}
	int iBits1 = m_bitsFixed.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();
	m_pStats->m_iTotalMiscBits += (iBits1 - iBits0);
	m_pStats->m_iTotalMiscNybbles += (iNybbles1 - iNybbles0);
}

void CIuBTreeCodec::CompressNoSolicit()
{
	if (!NoSolicitPhone() && !NoSolicitMail())
		return ;

	LPCTSTR pcszNoSolicitFlag = m_pRecord->GetField(m_iNoSolicitFirst);
	ASSERT(pcszNoSolicitFlag);

	if (NoSolicitPhone())
	{
		bool fCanPhone = SolicitCanPhone(pcszNoSolicitFlag[0]);
		m_bitsFixed.AppendInt(fCanPhone ? 0: 1, 1);
	}
	if (NoSolicitMail())
	{
		bool fCanMail = SolicitCanMail(pcszNoSolicitFlag[0]);
		m_bitsFixed.AppendInt(fCanMail ? 0: 1, 1);
	}
}

void CIuBTreeCodec::CompressOptional()
{
	if (m_iOptionalCount == 0)
		return ;

	int iBits0 = m_bitsFixed.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();
	for (int iOptional = m_iOptionalFirst; iOptional < m_iOptionalFirst + m_iOptionalCount; ++iOptional)
	{
		Clean(m_Temp, m_pRecord->GetField(iOptional), cleanTrim|cleanTruncateLeft, fieldDftLength);

		BYTE bFlag = 0;
		if (m_Temp.GetSize() > 1)
		{
			bool fNumeric = (m_aiOptionalFlags[iOptional - m_iOptionalFirst] & codecFlagNumeric) != 0;
			CIuNybbleString::Append(m_Temp, m_Temp.GetSize(), fNumeric ? NS_NUMERIC: NS_ALPHA, m_nybblesVariable);
			bFlag = 1;
		}
		m_bitsFixed.AppendInt(bFlag, 1);
	}
	int iBits1 = m_bitsFixed.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();
	m_pStats->m_iTotalOptionalBits += (iBits1 - iBits0);
	m_pStats->m_iTotalOptionalNybbles += (iNybbles1 - iNybbles0);
}

void CIuBTreeCodec::CompressPhone()
{
	if (m_iPhoneNoCount <= 0)
		return ;

	int iBits0 = m_bitsFixed.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();

	for (int iPhone = m_iPhoneNoFirst; iPhone < m_iPhoneNoFirst + m_iPhoneNoCount; ++iPhone)
	{
		LPCTSTR pcszPhone = m_pRecord->GetField(iPhone);

		Clean(m_Temp, pcszPhone, cleanNumeric|cleanTrim|cleanTruncate|cleanAllowEmpty, 10);

		__int64 iPhoneNo = StringAsInt64(m_Temp);

		// NOTE: The following types of phones are suppressed:
		//	000-000-0000
		//	000-???-????
		//	???-000-????
		__int64 iAreaCode = iPhoneNo / 10000000;
		__int64 iPrefix = (iPhoneNo / 10000) % 1000;
		if (iPhoneNo == 0 || iAreaCode == 0 || iPrefix == 0)
		{
			// NOTE: Some phones have a valid area code but the phone is all zeros.
			// Don't store these, they are considered to be unlisted
			m_bitsFixed.AppendInt(bPhone0, iPhoneBits);
			++m_pStats->m_aiTotalPhoneFormat[0];
		}
		// If no geo, must do a full encode (this takes 36 bits because we must nybble align)
		else if (!HasGeo())
		{
			CIuNybbleInt::AppendInt64(iPhoneNo, 36, m_nybblesVariable);
			m_bitsFixed.AppendInt(bPhone10, iPhoneBits);
			++m_pStats->m_aiTotalPhoneFormat[1];
		}
		else
		{
			if (iAreaCode != m_GeoCodec.GetAreaCode())
			{
				CIuNybbleInt::AppendInt64(iPhoneNo, 36, m_nybblesVariable);
				m_bitsFixed.AppendInt(bPhone10, iPhoneBits);
				++m_pStats->m_aiTotalPhoneFormat[2];
			}
			else
			{
				iPhoneNo %= 10000000;
				int iPrefixNo = m_GeoCodec.FindPrefix(int(iPrefix));
				if (iPrefixNo >= 0 && iPrefixNo < 6)
				{
					// Store lower 4 digits(16 bits)
					iPhoneNo %= 10000;
					iPhoneNo += iPrefixNo * 10000;
					ASSERT(iPhoneNo >= 0 && iPhoneNo < 60000);
					CIuNybbleInt::AppendInt64(iPhoneNo, 16, m_nybblesVariable);
					m_bitsFixed.AppendInt(bPhone4, iPhoneBits);
					++m_pStats->m_aiTotalPhoneFormat[3];
				}
				else
				{
					// Store prefix and suffix as a 7-digit number (24 bits)
					iPhoneNo %= 10000000;
					CIuNybbleInt::AppendInt64(iPhoneNo, 24, m_nybblesVariable);
					m_bitsFixed.AppendInt(bPhone7, iPhoneBits);
					++m_pStats->m_aiTotalPhoneFormat[4];
				}
			}
		}
	}
	int iBits1 = m_bitsFixed.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();
	m_pStats->m_iTotalPhoneBits += (iBits1 - iBits0);
	m_pStats->m_iTotalPhoneNybbles += (iNybbles1 - iNybbles0);
}

void CIuBTreeCodec::CompressRes()
{
	++m_pStats->m_iTotalRes;
}

void CIuBTreeCodec::CompressSpecial()
{
	if (m_iGender >= 0)
	{
		LPCTSTR pcszGender = m_pRecord->GetField(m_iGender);
		bool fFemale = (*pcszGender == 'F') || (*pcszGender == 'f');
		m_bitsFixed.AppendInt(fFemale ? 1: 0, 1);
	}
}

void CIuBTreeCodec::CompressTokens()
{
	int iTokenizers = m_aiTokenBits.GetSize();
	if (iTokenizers == 0)
		return ;

	// Begin by saving statistics
	int iFixedBits0 = m_bitsFixed.GetBitCount();
	int iVariableBits0 = m_bitsVariable.GetBitCount();
	int iNybbles0 = m_nybblesVariable.GetNybbles();

	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
	{
		int iTokenNo = 0;
		IU_TRY_ERROR
		{
			iTokenNo = GetTokenizers().Get(iTokenizer).Encode(*m_pRawRecord);
		}
		IU_CATCH_ERROR(e)
		{
			// If tokenizing fails, just keep processing. But, output the message
			m_pOutput->Output(e->GetDescription());
			m_pOutput->Fire();
			e->Delete();
			iTokenNo = 0;
		}
		if ((m_aiTokenFlags[iTokenizer] & tokenOptional) != 0)
		{
			if (iTokenNo >= 0)
			{
				m_bitsFixed.AppendInt(1, 1);
				m_bitsVariable.AppendInt(iTokenNo, m_aiTokenBits[iTokenizer]);
			}
			else
				m_bitsFixed.AppendInt(0, 1);
		}
		else if ((m_aiTokenFlags[iTokenizer] & tokenExceptional) != 0)
		{
			if (iTokenNo >= 0)
				m_bitsFixed.AppendInt(iTokenNo + 1, m_aiTokenBits[iTokenizer]);
			else
			{
				// Store token value of zero
				m_bitsFixed.AppendInt(0, m_aiTokenBits[iTokenizer]);
				// Write actual field value inline
				CIuNybbleString::Append(GetTokenizers().Get(iTokenizer).GetInstance().GetKey(), -1, NS_ALPHA, m_nybblesVariable);
			}
		}
		else
		{
			m_bitsFixed.AppendInt(iTokenNo, m_aiTokenBits[iTokenizer]);
		}
	}
	// Update statistics
	int iFixedBits1 = m_bitsFixed.GetBitCount();
	int iVariableBits1 = m_bitsVariable.GetBitCount();
	int iNybbles1 = m_nybblesVariable.GetNybbles();

	m_pStats->m_iTotalTokenFixedBits += (iFixedBits1 - iFixedBits0);
	m_pStats->m_iTotalTokenVariableBits += (iVariableBits1 - iVariableBits0);
	m_pStats->m_iTotalTokenNybbles += (iNybbles1 - iNybbles0);
}

void CIuBTreeCodec::Create(CIuOutput& Output)
{
	m_pOutput = &Output;

	if (!GetBTree().HasData())
		return ;

	// Initialize the codec info
	SetFixedBits(0);

	// Open the raw input file
	CIuOpenSpec OpenSpec;
	OpenSpec.m_pOutput = &Output;
	OpenSpec.m_pObjectRepository = &GetObjectRepository();

	GetInput().Open(OpenSpec);

	// Open the tokenizers
	GetTokenizers().Open();

	// Open the Geo encoder --- even if no geo information
	// because the alt record encoder may need it
	OpenGeo();

	// Open the address encoder 
	OpenAddress();

	// Open the Geo encoder --- even if no geo information
	// because the alt record encoder may need it
	OpenSic();

	// Open alternate record encode
	OpenAlt();

	// Clear the master field map object
	m_Map.Clear();

	// Resolve the record definition
	Resolve();

	// Finish the setup for the
	SetKeyOnly(true);
	CreateKey();
	CreateGeo();
	CreateAddress();
	CreateNoSolicit();
	if (IsBusOnly())
		CreateBus();
	else if (IsResOnly())
		CreateRes();
	else if (HasBusResFlag())
	{
		CreateBusResFlag();
		CreateBus();
		CreateRes();
	}
	CreateTokens();
	CreateMiscellaneous();
	CreatePhone();
	CreateOptional();
	CreateSpecial();

	// Pre-allocate space for the packed bits
	m_bitsFixed.SetBitCount(GetFixedBits());

	// Start at first record in file
	GetInput().MoveFirst();

	m_fNextRecord = false;
	m_fRecordsExhausted = false;
}

void CIuBTreeCodec::CreateAddress()
{
	if (HasAddress())
	{
		SetKeyOnly(false);
		SetFixedBits(GetFixedBits() + 2);
	}
}

void CIuBTreeCodec::CreateBus()
{
	if (!GetEmployeeSizeCode().IsEmpty())
	{
		SetKeyOnly(false);
	}
	if (!GetSalesVolumeCode().IsEmpty())
	{
		SetKeyOnly(false);
	}
	if (GetSicCount() > 0 && !GetSicCode().IsEmpty())
	{
		SetKeyOnly(false);

		ASSERT(m_pSic.NotNull());
		SetSicBits(m_pSic->GetBitsRequired());
	}

	ASSERT(m_iFranchiseCode < 0 || (GetSicCount() > 0 && m_iSicCode >= 0));
	ASSERT(m_iAdSizeCode < 0 || (GetSicCount() > 0 && m_iSicCode >= 0));
	ASSERT(m_iFirstYear < 0 || (GetSicCount() > 0 && m_iSicCode >= 0));
}

void CIuBTreeCodec::CreateBusResFlag()
{
	// Allow 1 bit for bus/res flag
	SetFixedBits(GetFixedBits() + 1);
}

void CIuBTreeCodec::CreateGeo()
{
	if (HasGeo())
	{
		SetKeyOnly(false);
		SetGeoBits(m_pGeo->GetBitsRequired());
		SetFixedBits(GetFixedBits() + GetGeoBits());
		if (!NoCityStateCorrection())
			SetFixedBits(GetFixedBits() + 1);
		if (!NoMsaCorrection())
			SetFixedBits(GetFixedBits() + 1);
		if (!NoCountyCorrection())
			SetFixedBits(GetFixedBits() + 1);
		if (!NoLatLongCorrection())
			SetFixedBits(GetFixedBits() + 1);
	}
	else
		SetGeoBits(0);
}

void CIuBTreeCodec::CreateKey()
{
	m_aiKeyFlags.RemoveAll();
	int iKeys = GetKeyMap().m_iFields;
	for (int iKey = 0; iKey < iKeys; ++iKey)
	{
		int iFlags = 0;

		if ((GetKeyMap().m_aFieldFlags[iKey] & fieldNumeric) != 0)
			iFlags |= codecFlagNumeric;
		m_aiKeyFlags.Add(iFlags);
	}
}

void CIuBTreeCodec::CreateMiscellaneous()
{
	m_aiMiscellaneousFlags.RemoveAll();
	int iMiscs = GetMiscellaneousMap().m_iFields;
	for (int iMisc = 0; iMisc < iMiscs; ++iMisc)
	{
		SetKeyOnly(false);
		int iFlags = 0;
		if ((GetMiscellaneousMap().m_aFieldFlags[iMisc] & fieldNumeric) != 0)
			iFlags |= codecFlagNumeric;
		m_aiMiscellaneousFlags.Add(iFlags);
	}
}

void CIuBTreeCodec::CreateNoSolicit()
{
	if (NoSolicitMail())
		SetFixedBits(GetFixedBits() + 1);
	if (NoSolicitPhone())
		SetFixedBits(GetFixedBits() + 1);
}

void CIuBTreeCodec::CreateOptional()
{
	m_aiOptionalFlags.RemoveAll();
	int iOptionals = GetOptionalMap().m_iFields;
	for (int iOptional = 0; iOptional < iOptionals; ++iOptional)
	{
		SetKeyOnly(false);
		int iFlags = 0;
		if ((GetOptionalMap().m_aFieldFlags[iOptional] & fieldNumeric) != 0)
			iFlags |= codecFlagNumeric;
		m_aiOptionalFlags.Add(iFlags);
	}
	SetFixedBits(GetFixedBits() + m_aiOptionalFlags.GetSize());
}

void CIuBTreeCodec::CreatePhone()
{
	SetPhoneCount(GetPhoneMap().m_iFields);
	SetFixedBits(GetFixedBits() + GetPhoneCount() * iPhoneBits);
	if (GetPhoneCount() != 0)
		SetKeyOnly(false);
}

void CIuBTreeCodec::CreateRes()
{
}

void CIuBTreeCodec::CreateSpecial()
{
	if (!m_sGender.IsEmpty())
	{
		SetKeyOnly(false);
		SetFixedBits(GetFixedBits() + 1);
	}
}

void CIuBTreeCodec::CreateTokens()
{
	m_aiTokenBits.RemoveAll();
	m_aiTokenFlags.RemoveAll();

	int iTotalFixedBitsRequired = 0;

	int iTokenizers = GetTokenizers().GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
	{
		SetKeyOnly(false);

		bool fIsOptional = GetTokenizers().Get(iTokenizer).IsOptional();
		bool fIsExceptional = GetTokenizers().Get(iTokenizer).IsExceptional();
		int iBitsRequired = GetTokenizers().Get(iTokenizer).GetBitsRequired();

		if (fIsOptional)
		{
			iTotalFixedBitsRequired += 1;
			m_aiTokenFlags.Add(tokenOptional);
		}
		else if (fIsExceptional)
		{
			iTotalFixedBitsRequired += iBitsRequired;
			m_aiTokenFlags.Add(tokenExceptional);
			if (GetTokenizers().Get(iTokenizer).GetToken().GetKeyCount() != 1 || GetTokenizers().Get(iTokenizer).GetToken().GetValueCount() != 0)
			{
				// NOTE: Exceptional tokenizing only allowed for fields where there is but a single key
				// We could support multiple keys... but we don't.
				// There is no good way to support values since they have been discarded by this point.
				Error(IU_E_COMPRESS_FATAL, _T("Exceptional tokenizing not allowed on specified field."));
			}
		}
		else
		{
			iTotalFixedBitsRequired += iBitsRequired;
			m_aiTokenFlags.Add(0);
		}
		m_aiTokenBits.Add(iBitsRequired);
	}

	SetFixedBits(GetFixedBits() + iTotalFixedBitsRequired);
}

void CIuBTreeCodec::DeCompress(CIuNybbleBuffer& buffer, CIuRecordSpec& Spec, bool fKeyOnly)
{
	ASSERT(GetBTree().HasData());

	// Make sure we are reading forward
	buffer.SetReverse(false);

	m_Output.Empty();
	m_iNextNybble = 0;
	m_fPrevAlt = false;

	if (m_fHasAlt && buffer.Get(0) == 0)
	{
		++m_iNextNybble;
		m_fPrevAlt = true;
		m_key.Clear();
		ASSERT(m_aiKeyFlags.GetSize() > 0);

		bool fNumeric = (m_aiKeyFlags[0] & codecFlagNumeric) != 0;
		m_iNextNybble += CIuNybbleString::Get(m_Temp, -1, false, fNumeric ? NS_NUMERIC: NS_ALPHA, buffer, m_iNextNybble);
		m_Output.Append(m_Temp);
		m_Temp.Shrink(1);
		m_Temp.Append((BYTE)',');
		m_Temp.Append((BYTE)'\0');
		m_key.Append(LPCTSTR(m_Temp.GetPtr()), GetKeyDef());
	}
	else
		DeCompressKey(buffer);

	if (fKeyOnly)
		return ;

	if (m_fPrevAlt)
	{
		// Get the values for the see also... 
		m_iNextNybble += CIuNybbleString::Get(m_Output, -1, true, NS_ALPHA, buffer, m_iNextNybble);
	}
	else if (!HasKeyOnly())
	{
		// Pull out the fixed and variable bits into the variable bit buffer
		m_iNextFixedBit = 0;
		m_iNextVariableBit = GetFixedBits();

		int iVariableNybbles = buffer.GetNybbles() - m_iNextNybble;
		int iVariableBits = iVariableNybbles * 4;
		ASSERT(iVariableBits >= GetFixedBits());
		m_iNextNybble += buffer.GetBits(m_bitsVariable, iVariableBits, m_iNextNybble);

		// Set buffer to reverse reading (for nybbles)
		buffer.SetReverse(true);

		m_fResCurrent = false;
		// Decompress
		m_iNextVariableNybble = 0;
		DeCompressGeo(buffer);
		DeCompressAddress(buffer);
		DeCompressNoSolicit(buffer);
		if (IsBusOnly())
		{
			//m_fResCurrent = false;
			DeCompressBus(buffer);
		}
		else if (IsResOnly())
		{
			m_fResCurrent = true;
			DeCompressRes(buffer);
		}
		else if (HasBusResFlag())
		{
			DeCompressBusResFlag(buffer);
			DeCompressBus(buffer);
			DeCompressRes(buffer);
		}

		DeCompressTokens(buffer);
		DeCompressMiscellaneous(buffer);
		DeCompressPhone(buffer);
		DeCompressOptional(buffer);
		DeCompressSpecial(buffer);

		// Check that all bits/nybbles were consumed. This is just a sanity check
		if (m_iNextFixedBit != GetFixedBits() || ((((m_iNextVariableBit + 3) / 4) + m_iNextVariableNybble) != iVariableNybbles))
		{
			CString sDebug;
			sDebug.Format(_T("Bits not consumed by decompressor @ %d.\n"), GetBTree().GetData().GetRecordNo());
			for (int i = 0; i < m_Output.GetStringCount(); ++i)
			{
				sDebug += m_Output.GetString(i);
				sDebug += _T("\n");
			}
			Error(IU_E_COMPRESS_FATAL, LPCTSTR(sDebug));
		}
	}

	// We should have consumed the entire buffer...
	// NOTE: Alternate records may have been padded to the minimum length
	if (!m_fPrevAlt && m_iNextNybble != buffer.GetNybbles())
		Error(IU_E_COMPRESS_FATAL, _T("Nybbles not consumed by decompressor."));

	if (m_fPrevAlt)
	{
		Spec.Set(m_Output);
		Spec.SetExtra(recordSourceNo|recordRecordNo, 50);
		Spec.SetAlt();
	}
	else
	{
		Spec.Set(m_Output);
		Spec.SetExtra(recordExpandNo|recordExpandCount|recordSourceNo|recordLatLong|recordRecordNo, 50);


		// NOTE: When allocating this raw record, allow space for various dwords and a small key...

		if (NoSolicitPhone() && m_fNoSolicitPhoneCurrent)
			Spec.SetNoPhone();
		if (NoSolicitMail() && m_fNoSolicitMailCurrent)
			Spec.SetNoMail();
		if (HasGeo() && !m_fNoSolicitMailCurrent)
			Spec.SetLatLong(m_GeoCodec.GetLatitude(), m_GeoCodec.GetLongitude());
		if (m_fResCurrent)
			Spec.SetRes();
		else
			Spec.SetBus();
	}

	// Create the record
	ASSERT(m_fPrevAlt || Spec.GetFields() == GetBTree().GetRecordDef().GetFieldDefs().GetCount());

	// Restore to forward reading
	buffer.SetReverse(false);
}

void CIuBTreeCodec::DeCompressAddress(CIuNybbleBuffer& buffer)
{
	// See notes in CIuBTreeCodec::CompressAddress()
	if (!HasAddress())
		return ;

	// These variables maintain the state of the address we pull.
	bool fPriNo = false;
	bool fSecNo = false;
	bool fSuffix = false;
	bool fPrePostDir = false;
	bool fRrHc = false;
	bool fPobox = false;

	int iDefaultPreDir = dirNone;
	int iDefaultPostDir = dirNone;
	int iDefaultSuffix = 1; // Blank is alway 0, next is the most frequent

	// Address type
	// 00		(0)	Tokenized street (token value < 10 or special)
	// 					Empty
	// 					RR
	// 					HC
	// 					POBOX
	// 					Encoded
	// 01		(1)	Tokenized street < 4906
	// 10		(2)	Tokenized street < 65536
	// 11 0	(6)	Ordinal street < 16
	// 11 1	(7)	Ordinal street < 256
	TCHAR szStreetName[256];
	szStreetName[0] = '\0';
	LPCTSTR pcszStreetName = szStreetName;
	UINT32 uiType;
	m_iNextFixedBit += m_bitsVariable.GetInt(uiType, 2, m_iNextFixedBit);
	if (uiType == 0)
	{
		UINT32 uiToken;
		m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiToken, 4, buffer, m_iNextVariableNybble);

		if (uiToken == iAddressEmpty)
		{
		}
		else if (uiToken == iAddressRR)
		{
			fPriNo = true;
			fSecNo = true;
			pcszStreetName = CIuAddressCodec::m_szRR;
			fRrHc = true;
		}
		else if (uiToken == iAddressHC)
		{
			pcszStreetName = CIuAddressCodec::m_szHC;
			fPriNo = true;
			fSecNo = true;
			fRrHc = true;
		}
		else if (uiToken == iAddressPOBOX)
		{
			pcszStreetName = CIuAddressCodec::m_szPOBOX;
			fPriNo = true;
			fPobox = true;
		}
		else if (uiToken == iAddressEncoded)
		{
			m_iNextVariableNybble += CIuNybbleString::Get(m_Temp, -1, false, NS_ALPHA, buffer, m_iNextVariableNybble);
			ASSERT(m_Temp.GetSize() <= sizeof(szStreetName));
			memcpy(szStreetName, m_Temp.GetPtr(), min(sizeof(szStreetName), m_Temp.GetSize()));
			szStreetName[sizeof(szStreetName) - 1] = '\0';
			fPriNo = true;
			fSecNo = true;
			fSuffix = true;
			fPrePostDir = true;
		}
		else
		{
			ASSERT(uiToken >= 0 && uiToken < 11);
			pcszStreetName = m_pAddress->GetStreetName(uiToken);
			iDefaultPreDir = m_pAddress->GetStreetNamePreDir(uiToken);
			iDefaultPostDir = m_pAddress->GetStreetNamePostDir(uiToken);
			iDefaultSuffix = m_pAddress->GetStreetNameSuffix(uiToken);
			fPriNo = true;
			fSecNo = true;
			fSuffix = true;
			fPrePostDir = true;
		}
	}
	else if (uiType == 1)
	{
		UINT32 uiToken;
		m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiToken, 12, buffer, m_iNextVariableNybble);

		ASSERT(uiToken >= 0 && uiToken < 4096);
		uiToken += 11;
		pcszStreetName = m_pAddress->GetStreetName(uiToken);
		iDefaultPreDir = m_pAddress->GetStreetNamePreDir(uiToken);
		iDefaultPostDir = m_pAddress->GetStreetNamePostDir(uiToken);
		iDefaultSuffix = m_pAddress->GetStreetNameSuffix(uiToken);

		fPriNo = true;
		fSecNo = true;
		fSuffix = true;
		fPrePostDir = true;
	}
	else if (uiType == 2)
	{
		UINT32 uiToken;
		m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiToken, 16, buffer, m_iNextVariableNybble);

		ASSERT(uiToken >= 0 && uiToken < 65536);
		uiToken += (4096 + 11);
		pcszStreetName = m_pAddress->GetStreetName(uiToken);
		iDefaultPreDir = m_pAddress->GetStreetNamePreDir(uiToken);
		iDefaultPostDir = m_pAddress->GetStreetNamePostDir(uiToken);
		iDefaultSuffix = m_pAddress->GetStreetNameSuffix(uiToken);

		fPriNo = true;
		fSecNo = true;
		fSuffix = true;
		fPrePostDir = true;
	}
	else // if (uiType == 3)
	{
		UINT uiType;
		UINT uiStreetNo;
		m_iNextVariableBit += m_bitsVariable.GetInt(uiType, 1, m_iNextVariableBit);
		if (uiType == 0)
			m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiStreetNo, 4, buffer, m_iNextVariableNybble);
		else
			m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiStreetNo, 8, buffer, m_iNextVariableNybble);

		UIntAsStringEx(szStreetName, sizeof(szStreetName), uiStreetNo);
		if (uiStreetNo >= 4 && uiStreetNo <= 20)
			_tcscat(szStreetName, _T("TH"));
		else if ((uiStreetNo % 10) == 1)
			_tcscat(szStreetName, _T("ST"));
		else if ((uiStreetNo % 10) == 2)
			_tcscat(szStreetName, _T("ND"));
		else if ((uiStreetNo % 10) == 3)
			_tcscat(szStreetName, _T("RD"));
		else
			_tcscat(szStreetName, _T("TH"));
		fPriNo = true;
		fSecNo = true;
		fSuffix = true;
		fPrePostDir = true;
	}

	// Primary number
	//		00	(0)	Numeric < 256 (0==none)
	//		01	(1)	Numeric < 4096+256
	//		10 (2)	Numeric < 65536+4096+256
	//		11 (3)	Other
	//	Note: A numeric primary number is offset by 1. The value 0
	//			implies a blank primary number
	TCHAR szPriNo[128];
	szPriNo[0] = '\0';
	if (fPriNo)
	{
		UINT32 uiType;
		m_iNextVariableBit += m_bitsVariable.GetInt(uiType, 2, m_iNextVariableBit);
		if (uiType == 3)
		{
			m_iNextVariableNybble += CIuNybbleString::Get(m_Temp, -1, false, NS_NUMERIC, buffer, m_iNextVariableNybble);
			ASSERT(m_Temp.GetSize() <= sizeof(szStreetName));
			memcpy(szPriNo, m_Temp.GetPtr(), min(sizeof(szPriNo), m_Temp.GetSize()));
			szPriNo[sizeof(szPriNo) - 1] = '\0';
		}
		else
		{
			UINT uiPriNo;
			if (uiType == 0)
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPriNo, 8, buffer, m_iNextVariableNybble);
			else if (uiType == 1)
			{
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPriNo, 12, buffer, m_iNextVariableNybble);
				uiPriNo += 256;
			}
			else 
			{
				ASSERT(uiType == 2);
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPriNo, 16, buffer, m_iNextVariableNybble);
				uiPriNo += 256 + 4096;
			}
			if (uiPriNo > 0)
				UIntAsStringEx(szPriNo, sizeof(szPriNo), uiPriNo - 1);
		}
	}

	// Secondary number
	//		0	(0)	No secondary number
	//		10 (2)	Numeric < 4096
	//		11 (3)	Other
	TCHAR szSecNo[128];
	szSecNo[0] = '\0';
	if (fSecNo)
	{
		UINT32 uiPresent;
		m_iNextVariableBit += m_bitsVariable.GetInt(uiPresent, 1, m_iNextVariableBit);
		if (uiPresent)
		{
			UINT32 uiType;
			m_iNextVariableBit += m_bitsVariable.GetInt(uiType, 1, m_iNextVariableBit);
			if (uiType == 0)
			{
				UINT uiSecNo;
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiSecNo, 12, buffer, m_iNextVariableNybble);
				UIntAsStringEx(szSecNo, sizeof(szSecNo), uiSecNo);
			}
			else
			{
				ASSERT(uiType == 1);
				m_iNextVariableNybble += CIuNybbleString::Get(m_Temp, -1, false, NS_NUMERIC, buffer, m_iNextVariableNybble);
				ASSERT(m_Temp.GetSize() <= sizeof(szSecNo));
				memcpy(szSecNo, m_Temp.GetPtr(), min(sizeof(szSecNo), m_Temp.GetSize()));
				szSecNo[sizeof(szSecNo) - 1] = '\0';
			}
		}
	}

	// Suffix
	//		0									Default suffix
	//		1	bbb	(0-6)					One of the top 7 suffix (covers about 90%)
	//		1	bbb	(7)	nnnn nnnn	Full suffix token (- 7) follows
	LPCTSTR pcszSuffix = "";
	if (fSuffix)
	{
		UINT32 uiPresent;
		m_iNextVariableBit += m_bitsVariable.GetInt(uiPresent, 1, m_iNextVariableBit);
		if (uiPresent == 1)
		{
			UINT32 uiSuffix;
			m_iNextVariableBit += m_bitsVariable.GetInt(uiSuffix, 3, m_iNextVariableBit);
			if (uiSuffix < 7)
			{
				iDefaultSuffix = uiSuffix;
			}
			else
			{
				ASSERT(uiSuffix == 7);
				UINT uiSuffixToken;
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiSuffixToken, 8, buffer, m_iNextVariableNybble);
				iDefaultSuffix = uiSuffixToken + 7;
			}
		}
		pcszSuffix = m_pAddress->GetSuffix(iDefaultSuffix);
	}

	// Pre/Post Directional
	//		0	 (0)					Neither/Default
	//		10	 (2)	nnnn			PreDir only
	//		110 (6)	nnnn			PostDir Only
	//		111 (7)	nnnn nnnn	Both pre/post dir
	// NOTE: Due to a ?bug?, if you "put" bits 01, you are not necessary guaranteed the 
	//	order if you retrieve them one bit at a time. Therefore, bits are output one at a time
	LPCTSTR pcszPreDir = "";
	LPCTSTR pcszPostDir = "";
	if (fPrePostDir)
	{
		UINT32 uiPresent;
		m_iNextVariableBit += m_bitsVariable.GetInt(uiPresent, 1, m_iNextVariableBit);
		if (uiPresent == 1)
		{
			UINT32 uiPreDirOnly;
			m_iNextVariableBit += m_bitsVariable.GetInt(uiPreDirOnly, 1, m_iNextVariableBit);
			if (uiPreDirOnly == 0)
			{
				UINT uiPreDir;
				m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPreDir, 4, buffer, m_iNextVariableNybble);
				ASSERT(uiPreDir >= dirFirst && uiPreDir <= dirMax);
				iDefaultPreDir = uiPreDir;
			}
			else
			{
				ASSERT(uiPreDirOnly == 1);
				UINT32 uiBoth;
				m_iNextVariableBit += m_bitsVariable.GetInt(uiBoth, 1, m_iNextVariableBit);
				if (uiBoth == 1)
				{
					UINT uiPreDir;
					m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPreDir, 4, buffer, m_iNextVariableNybble);
					ASSERT(uiPreDir >= dirFirst && uiPreDir <= dirMax);
					iDefaultPreDir = uiPreDir;
					UINT uiPostDir;
					m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPostDir, 4, buffer, m_iNextVariableNybble);
					ASSERT(uiPostDir >= dirFirst && uiPostDir <= dirMax);
					iDefaultPostDir = uiPostDir;
				}
				else
				{
					ASSERT(uiBoth == 0);
					UINT uiPostDir;
					m_iNextVariableNybble += CIuNybbleInt::GetUInt(uiPostDir, 4, buffer, m_iNextVariableNybble);
					ASSERT(uiPostDir >= dirFirst && uiPostDir <= dirMax);
					iDefaultPostDir = uiPostDir;
				}
			}
		}
		pcszPreDir = CIuAddressCodec::GetDir(iDefaultPreDir);
		pcszPostDir = CIuAddressCodec::GetDir(iDefaultPostDir);
	}

	// Build a combined street name
	ASSERT(pcszStreetName != 0);

	TCHAR szStreet[fieldDftLength+1];
	szStreet[0] = '\0';
	if (fRrHc)
	{
		_tcsncat(szStreet, pcszStreetName, sizeof(szStreet));
		if (*szPriNo)
		{
			if (szStreet[0])
				_tcsncat(szStreet, " ", sizeof(szStreet));
			_tcsncat(szStreet, szPriNo, sizeof(szStreet));
			szPriNo[0] = '\0';
		}
	}
	else if (fPobox)
	{
		if (szSecNo[0] == '\0')
		{
			_tcscpy(szSecNo, szPriNo);
			szPriNo[0] = '\0';
		}
		_tcsncat(szStreet, pcszStreetName, sizeof(szStreet));
	}
	else
	{
		_tcsncat(szStreet, pcszPreDir, sizeof(szStreet));
		if (*pcszStreetName)
		{
			if (szStreet[0])
				_tcsncat(szStreet, " ", sizeof(szStreet));
			_tcsncat(szStreet, pcszStreetName, sizeof(szStreet));
		}
		if (*pcszSuffix)
		{
			if (szStreet[0])
				_tcsncat(szStreet, " ", sizeof(szStreet));
			_tcsncat(szStreet, pcszSuffix, sizeof(szStreet));
		}
		if (*pcszPostDir)
		{
			if (szStreet[0])
				_tcsncat(szStreet, " ", sizeof(szStreet));
			_tcsncat(szStreet, pcszPostDir, sizeof(szStreet));
		}
	}

	// PriNo
	m_Output.Append(szPriNo);
	// PreDir
	m_Output.Append(pcszPreDir);
	// StreetName
	m_Output.Append(pcszStreetName);
	// Suffix
	m_Output.Append(pcszSuffix);
	// PostDir
	m_Output.Append(pcszPostDir);
	// SecNo
	m_Output.Append(szSecNo);
	// Street
	m_Output.Append(szStreet);
}

void CIuBTreeCodec::DeCompressBus(CIuNybbleBuffer& buffer)
{
	if (m_fResCurrent)
	{
		// This is a residential record. Simply blank out the business specific fields
		if (HasEmployeeSizeCode())
			m_Output.Append(bNull);
		if (HasSalesVolumeCode())
			m_Output.Append(bNull);
		if (GetSicCount() <= 0 || !HasSicCode())
			return ;
		for (int iSic = 0; iSic < GetSicCount(); ++iSic)
		{
			m_Output.Append(bNull);
			m_Output.Append(bNull);
			if (HasFranchiseCode())
			{
				m_Output.Append(bNull);
				m_Output.Append(bNull);
			}
			if (HasAdSizeCode())
				m_Output.Append(bNull);
			if (HasFirstYear())
				m_Output.Append(bNull);
		}
		return ;
	}

	// This is a business record. Decompress any special fields

	// These are business only demographic fields
	if (HasEmployeeSizeCode())
	{
		int iCode = buffer.Get(m_iNextVariableNybble);
		++m_iNextVariableNybble;
		m_Output.AppendString(::EmployeeSizeCode(iCode));
	}
	if (HasSalesVolumeCode())
	{
		int iCode = buffer.Get(m_iNextVariableNybble);
		++m_iNextVariableNybble;
		m_Output.AppendString(::SalesVolumeCode(iCode));
	}

	if (GetSicCount() <= 0 || !HasSicCode())
		return ;

	UINT uiSics;
	m_iNextVariableNybble += CIuNybbleInt::GetUIntCompressed(uiSics, buffer, m_iNextVariableNybble);

	for (int iSic = 0; iSic < GetSicCount(); ++iSic)
	{
		if (UINT(iSic) < uiSics)
		{
			UINT32 iSicCode;
			m_iNextVariableBit += m_bitsVariable.GetInt(iSicCode, GetSicBits(), m_iNextVariableBit);
			ASSERT(iSicCode >= 0);

			ASSERT(m_pSic.NotNull());

			// Get the sic
			if (HasFranchiseCode())
			{
				UINT32 fIsPresent = m_bitsVariable.GetBit(m_iNextVariableBit);
				++m_iNextVariableBit;
				m_pSic->Decode(iSicCode, m_Output);
				if (fIsPresent)
				{
					m_iNextVariableNybble = m_pSic->DecodeFranchise(iSicCode, m_Output, buffer, m_iNextVariableNybble);
				}
				else
				{
					m_Output.Append(bNull);
					m_Output.Append(bNull);
				}
			}
			else
			{
				m_pSic->Decode(iSicCode, m_Output);
			}
			if (HasAdSizeCode())
			{
				UINT32 iAdSizeCode;
				m_iNextVariableBit += m_bitsVariable.GetInt(iAdSizeCode, iAdSizeCodeBits, m_iNextVariableBit);
				m_Output.AppendString(::AdSizeCode(iAdSizeCode));
			}
			if (HasFirstYear())
			{
				int iYearsInDb = buffer.Get(m_iNextVariableNybble);
				ASSERT(iYearsInDb >= 0 && iYearsInDb < 16);
				++m_iNextVariableNybble;
				static LPCTSTR apcszYearsInDb[] = { "1","2","3","4","5","6","7","8","9","10+","10+","10+","10+","10+","10+","10+" };
				m_Output.AppendString(apcszYearsInDb[iYearsInDb]);
			}
		}
		else
		{
			m_Output.Append(bNull);
			m_Output.Append(bNull);
			if (HasFranchiseCode())
			{
				m_Output.Append(bNull);
				m_Output.Append(bNull);
			}
			if (HasAdSizeCode())
				m_Output.Append(bNull);
			if (HasFirstYear())
				m_Output.Append(bNull);
		}
	}
}

void CIuBTreeCodec::DeCompressBusResFlag(CIuNybbleBuffer&)
{
	m_fResCurrent = m_bitsVariable.GetBit(m_iNextFixedBit);
	++m_iNextFixedBit;
	// Only residences are non-solicit
	ASSERT(m_fResCurrent || (!m_fNoSolicitPhoneCurrent && !m_fNoSolicitMailCurrent));
}

void CIuBTreeCodec::DeCompressGeo(CIuNybbleBuffer& buffer)
{
	if (!HasGeo())
		return ;

	m_GeoCodec.Clear();

	UINT32 iVal;
	m_iNextFixedBit += m_bitsVariable.GetInt(iVal, GetGeoBits(), m_iNextFixedBit);

	int iZipNo = iVal;
	m_GeoCodec.SetZipNo(iZipNo);

	if (!NoCityStateCorrection())
	{
		iVal = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
		if (iVal)
		{
			int lCityDelta;
			m_iNextVariableNybble += CIuNybbleInt::GetIntCompressed(lCityDelta, buffer, m_iNextVariableNybble);
			if (lCityDelta == 0)
				m_GeoCodec.SetNoCity();
			else
				m_GeoCodec.SetCityDelta(lCityDelta);
		}
	}

	if (!NoMsaCorrection())
	{
		iVal = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
		if (iVal)
		{
			int lMsaDelta;
			m_iNextVariableNybble += CIuNybbleInt::GetIntCompressed(lMsaDelta, buffer, m_iNextVariableNybble);
			if (lMsaDelta == 0)
				m_GeoCodec.SetNoMsa();
			else
				m_GeoCodec.SetMsaDelta(lMsaDelta);
		}
	}

	if (!NoCountyCorrection())
	{
		m_iNextFixedBit += m_bitsVariable.GetInt(iVal, 1, m_iNextFixedBit);
		if (iVal)
		{
			int iCountyDelta;
			m_iNextVariableNybble += CIuNybbleInt::GetIntCompressed(iCountyDelta, buffer, m_iNextVariableNybble);
			if (iCountyDelta == 0)
				m_GeoCodec.SetNoCounty();
			else
				m_GeoCodec.SetCountyDelta(iCountyDelta);
		}
	}

	if (!NoLatLongCorrection())
	{
		m_iNextFixedBit += m_bitsVariable.GetInt(iVal, 1, m_iNextFixedBit);
		if (iVal)
		{
			int iLatitudeDelta;
			m_iNextVariableNybble += CIuNybbleInt::GetIntCompressed(iLatitudeDelta, buffer, m_iNextVariableNybble);
			m_GeoCodec.SetLatitudeDelta(iLatitudeDelta);
			int iLongitudeDelta;
			m_iNextVariableNybble += CIuNybbleInt::GetIntCompressed(iLongitudeDelta, buffer, m_iNextVariableNybble);
			m_GeoCodec.SetLongitudeDelta(iLongitudeDelta);
		}
	}

	if (!NoZipAddOn())
	{
		UINT32 iAddon;
		m_iNextVariableBit += m_bitsVariable.GetInt(iAddon, iZipAddonBits, m_iNextVariableBit);

		TCHAR szAddon[4+1];
		IntAsStringEx(szAddon, sizeof(szAddon), iAddon, 10, 4, 4, true);

		m_GeoCodec.SetZipAddon(szAddon);
	}
	else
		m_GeoCodec.SetZipAddon(_T(""));
	m_pGeo->Decode(m_GeoCodec);
	m_GeoCodec.Get(m_Output);
}

void CIuBTreeCodec::DeCompressKey(CIuNybbleBuffer& buffer)
{
	m_key.Clear();
	int iKeys = m_aiKeyFlags.GetSize();
	for (int iKey = 0; iKey < iKeys; ++iKey)
	{
		bool fNumeric = (m_aiKeyFlags[iKey] & codecFlagNumeric) != 0;
		m_iNextNybble += CIuNybbleString::Get(m_Temp, -1, false, fNumeric ? NS_NUMERIC: NS_ALPHA, buffer, m_iNextNybble);
		LPCTSTR pcszKey = LPCTSTR(m_Temp.GetPtr());
		m_key.Append(pcszKey, GetKeyDef());
		m_Output.Append(m_Temp);
	}
}

void CIuBTreeCodec::DeCompressMiscellaneous(CIuNybbleBuffer& buffer)
{
	int iCount = m_aiMiscellaneousFlags.GetSize();
	for (int iMiscellaneous = 0; iMiscellaneous < iCount; ++iMiscellaneous)
	{
		bool fNumeric = (m_aiMiscellaneousFlags[iMiscellaneous] & codecFlagNumeric) != 0;
		m_iNextVariableNybble += CIuNybbleString::Get(m_Output, -1, true, fNumeric ? NS_NUMERIC: NS_ALPHA, buffer, m_iNextVariableNybble);
	}
}

void CIuBTreeCodec::DeCompressNoSolicit(CIuNybbleBuffer&)
{
	// NOTE: Currently no fields are output here...
	if (NoSolicitPhone())
	{
		m_fNoSolicitPhoneCurrent = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
	}
	if (NoSolicitMail())
	{
		m_fNoSolicitMailCurrent = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
	}
}

void CIuBTreeCodec::DeCompressOptional(CIuNybbleBuffer& buffer)
{
	int iCount = m_aiOptionalFlags.GetSize();
	if (iCount == 0)
		return ;

	for (int iOptional = 0; iOptional < iCount; ++iOptional)
	{
		UINT32 fExists = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
		if (fExists)
		{
			bool fNumeric = (m_aiOptionalFlags[iOptional] & codecFlagNumeric) != 0;
			m_iNextVariableNybble += CIuNybbleString::Get(m_Output, -1, true, fNumeric ? NS_NUMERIC: NS_ALPHA, buffer, m_iNextVariableNybble);
		}
		else
		{
			m_Output.Append(bNull);
		}
	}
}

void CIuBTreeCodec::DeCompressPhone(CIuNybbleBuffer& buffer)
{
	int iPhones = GetPhoneCount();
	if (iPhones <= 0)
		return ;

	for (int iPhone = 0; iPhone < iPhones; ++iPhone)
	{
		UINT32 iVal;
		m_iNextFixedBit += m_bitsVariable.GetInt(iVal, iPhoneBits, m_iNextFixedBit);
		int iPhoneType = iVal;

		__int64 iPhoneNo = 0;
		if (iPhoneType == bPhone10)
		{
			m_iNextVariableNybble += CIuNybbleInt::GetInt64(iPhoneNo, 36, buffer, m_iNextVariableNybble);
		}
		else if (iPhoneType == bPhone0)
		{
			/* null */ ;
		}
		else
		{
			if (iPhoneType == bPhone7)
			{
				m_iNextVariableNybble += CIuNybbleInt::GetInt64(iPhoneNo, 24, buffer, m_iNextVariableNybble);
			}
			else
			{
				ASSERT(iPhoneType == bPhone4);
				m_iNextVariableNybble += CIuNybbleInt::GetInt64(iPhoneNo, 16, buffer, m_iNextVariableNybble);

				__int64 iPrefix = iPhoneNo / 10000;
				ASSERT(iPrefix >= 0 && iPrefix < 6);

				iPrefix = m_GeoCodec.GetPrefix(int(iPrefix));

				iPhoneNo %= 10000;
				iPhoneNo += iPrefix * 10000;
			}
			__int64 iAreaCodeNo = m_GeoCodec.GetAreaCode();
			iPhoneNo += iAreaCodeNo * 10000000;
		}
		if (iPhoneNo != 0)
		{
			TCHAR szPhone[50];
			Int64AsStringEx(szPhone, sizeof(szPhone) - 1, iPhoneNo);
			m_Output.AppendString(szPhone);
		}
		else
			m_Output.AppendString();
	}
}

void CIuBTreeCodec::DeCompressRes(CIuNybbleBuffer&)
{
	if (!m_fResCurrent)
	{
		// This is a business record. Simply blank out the residential specific fields
		return ;
	}
	// This is a residential record. Decompress any special fields
}

void CIuBTreeCodec::DeCompressSpecial(CIuNybbleBuffer&)
{
	if (!m_sGender.IsEmpty())
	{
		UINT32 fFemale = m_bitsVariable.GetBit(m_iNextFixedBit);
		++m_iNextFixedBit;
		if (fFemale)
			m_Output.AppendString(_T("Female"));
		else
			m_Output.AppendString(_T("Male"));
	}
}

void CIuBTreeCodec::DeCompressTokens(CIuNybbleBuffer& buffer)
{
	int iTokenizers = m_aiTokenBits.GetSize();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
	{
		UINT32 iTokenNo = UINT32(-1);
		if ((m_aiTokenFlags[iTokenizer] & tokenOptional) != 0)
		{
			UINT32 fIsPresent = m_bitsVariable.GetBit(m_iNextFixedBit);
			++m_iNextFixedBit;
			if (fIsPresent)
				m_iNextVariableBit += m_bitsVariable.GetInt(iTokenNo, m_aiTokenBits[iTokenizer], m_iNextVariableBit);
			GetTokenizers().Get(iTokenizer).Decode(iTokenNo, m_Output);
		}
		else if ((m_aiTokenFlags[iTokenizer] & tokenExceptional) != 0)
		{
			m_iNextFixedBit += m_bitsVariable.GetInt(iTokenNo, m_aiTokenBits[iTokenizer], m_iNextFixedBit);
			if (iTokenNo > 0)
				GetTokenizers().Get(iTokenizer).Decode(iTokenNo - 1, m_Output);
			else
			{
				m_iNextVariableNybble += CIuNybbleString::Get(m_Output, -1, true, NS_ALPHA, buffer, m_iNextVariableNybble);
			}
		}
		else
		{
			m_iNextFixedBit += m_bitsVariable.GetInt(iTokenNo, m_aiTokenBits[iTokenizer], m_iNextFixedBit);
			GetTokenizers().Get(iTokenizer).Decode(iTokenNo, m_Output);
		}
	}
}

CIuObject* CIuBTreeCodec::GetAddressCodec_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAddressCodec.Ptr()));
}

int CIuBTreeCodec::GetBitsPerPointer(int iAdditional) const
{
	return BitsRequired(m_pInput->GetMaxRecordNo() + iAdditional);
}

int CIuBTreeCodec::GetEstimatedRecordCount() const
{
	// The estimate record count is used for the progress bar.
	return m_pInput->GetRecords();
}

CIuGeoPtr CIuBTreeCodec::GetGeo()
{
	if (GetGeoMoniker().IsValid())
	{
		if (!HasObjectRepository())
			Error(IU_E_NO_REPOSITORY);

		CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_GEO);
		int iGeo = GetObjectRepository().Find(GetGeoMoniker(), sType);
		if (iGeo < 0)
			Error(IU_E_GEO_NOT_FOUND, LPCTSTR(GetGeoMoniker().AsString()));

		CIuObjectPtr pObject = GetObjectRepository().UnPack(iGeo).Ptr();
		if (pObject.IsNull())
			Error(IU_E_GEO_NOT_FOUND, LPCTSTR(GetGeoMoniker().AsString()));

		m_pGeo = dynamic_cast<CIuGeo*>(pObject.Ptr());
		ASSERT(m_pGeo.NotNull());
		if (HasObjectRepository())
			m_pGeo->SetObjectRepository(&GetObjectRepository());
	}
	else
	{
		m_pGeo.Release();
	}
	return m_pGeo;
}

CIuObject* CIuBTreeCodec::GetGeoMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_GeoMap));
}

CIuObject* CIuBTreeCodec::GetInput_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInput.Ptr()));
}

CIuObject* CIuBTreeCodec::GetKeyDef_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_KeyDef));
}

CIuObject* CIuBTreeCodec::GetKeyMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_KeyMap));
}

void CIuBTreeCodec::GetKeyFlags(CIntArray& al) const
{
	al.Copy(m_aiKeyFlags);
}

void CIuBTreeCodec::GetMiscellaneousFlags(CIntArray& al) const
{
	al.Copy(m_aiMiscellaneousFlags);
}

CIuObject* CIuBTreeCodec::GetMiscellaneousMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_MiscellaneousMap));
}

void CIuBTreeCodec::GetOptionalFlags(CIntArray& al) const
{
	al.Copy(m_aiOptionalFlags);
}

CIuObject* CIuBTreeCodec::GetOptionalMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_OptionalMap));
}

CIuObject* CIuBTreeCodec::GetPhoneMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_PhoneMap));
}

void CIuBTreeCodec::GetTokenBits(CIntArray& al) const
{
	al.Copy(m_aiTokenBits);
}

CIuObject* CIuBTreeCodec::GetTokenizers_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_Tokenizers));
}

void CIuBTreeCodec::GetTokenFlags(CIntArray& al) const
{
	al.Copy(m_aiTokenFlags);
}

CIuVersionNumber CIuBTreeCodec::GetVersionMax() const
{
	return versionBTreeCodecMax;
}

CIuVersionNumber CIuBTreeCodec::GetVersionMaxStatic()
{
	return versionBTreeCodecMax;
}

CIuVersionNumber CIuBTreeCodec::GetVersionMin() const
{
	return versionBTreeCodecMin;
}

CIuVersionNumber CIuBTreeCodec::GetVersionMinStatic()
{
	return versionBTreeCodecMin;
}

CIuRecordDefPtr CIuBTreeCodec::MakeRecordDef()
{
	CIuRecordDefPtr pRecordDef;
	pRecordDef.Create();

	// If no data, clear the record def. 
	// This would be an index without any embedded key values.
	if (!GetBTree().HasData())
		return pRecordDef;

	// Create the various components
	MakeRecordDefKey(*pRecordDef);
	MakeRecordDefGeo(*pRecordDef);
	MakeRecordDefAddress(*pRecordDef);
	MakeRecordDefNoSolicit(*pRecordDef);

	if (IsBusOnly())
		MakeRecordDefBus(*pRecordDef);
	else if (IsResOnly())
		MakeRecordDefRes(*pRecordDef);
	else if (HasBusResFlag())
		MakeRecordDefBusResFlag(*pRecordDef);

	MakeRecordDefTokens(*pRecordDef);
	MakeRecordDefMiscellaneous(*pRecordDef);
	MakeRecordDefPhone(*pRecordDef);
	MakeRecordDefOptional(*pRecordDef);
	MakeRecordDefSpecial(*pRecordDef);

	pRecordDef->Adjust();

	return pRecordDef;
}

void CIuBTreeCodec::MakeRecordDefAddress(CIuRecordDef& RecordDef)
{
	if (!HasAddress())
		return ;

	RecordDef.AddFieldDef(_T("=PriNo"));
	RecordDef.AddFieldDef(_T("=PreDir"));
	RecordDef.AddFieldDef(_T("=StreetName"));
	RecordDef.AddFieldDef(_T("=Suffix"));
	RecordDef.AddFieldDef(_T("=PostDir"));
	RecordDef.AddFieldDef(_T("=SecNo"));
	RecordDef.AddFieldDef(_T("=Street"));
}

void CIuBTreeCodec::MakeRecordDefBus(CIuRecordDef& RecordDef)
{
	if (!GetEmployeeSizeCode().IsEmpty())
		RecordDef.AddFieldDef(GetEmployeeSizeCode());

	if (!GetSalesVolumeCode().IsEmpty())
	{
		RecordDef.AddFieldDef(GetSalesVolumeCode());
	}

	if (GetSicCount() >= 1)
	{
		ASSERT(!GetSicCode().IsEmpty());
		if (HasSicCode())
		{
			for (int iSic = 0; iSic < GetSicCount(); ++iSic)
			{
				CString sField = GetSicCode();
				if (iSic > 0)
					sField.Format("%s%d", LPCTSTR(GetSicCode()), iSic + 1);
				else
					sField = GetSicCode();
				RecordDef.AddFieldDef(sField);

				if (iSic > 0)
					sField.Format("=%s%d", szFieldSicName, iSic + 1);
				else
					sField = szFieldSicName;
				// SIC name is output only...
				RecordDef.AddFieldDef(sField);

				if (!GetFranchiseCode().IsEmpty())
				{
					CString sField = GetFranchiseCode();
					if (iSic > 0)
						sField.Format("%s%d", LPCTSTR(GetFranchiseCode()), iSic + 1);
					else
						sField = GetFranchiseCode();
					RecordDef.AddFieldDef(sField);

					if (iSic > 0)
						sField.Format("=%s%d", szFieldFranchiseName, iSic + 1);
					else
						sField = szFieldFranchiseName;
					// Franchise name is output only...
					RecordDef.AddFieldDef(sField);
				}
				if (!GetAdSizeCode().IsEmpty())
				{
					CString sField = GetAdSizeCode();
					if (iSic > 0)
						sField.Format("%s%d", LPCTSTR(GetAdSizeCode()), iSic + 1);
					else
						sField = GetAdSizeCode();
					RecordDef.AddFieldDef(sField);
				}
				if (!GetFirstYear().IsEmpty())
				{
					// NOTE: We read from the FirstYear field but output "YearsInDb"
					CString sField = GetFirstYear();
					if (iSic > 0)
						sField.Format("%s%d", szFieldYearsInDb, iSic + 1);
					else
						sField = szFieldYearsInDb;
					RecordDef.AddFieldDef(sField);
				}
			}
		}
	}
}

void CIuBTreeCodec::MakeRecordDefBusResFlag(CIuRecordDef& RecordDef)
{
	// Add fields for both business and residential
	MakeRecordDefBus(RecordDef);
	MakeRecordDefRes(RecordDef);
}

void CIuBTreeCodec::MakeRecordDefGeo(CIuRecordDef& RecordDef)
{
	if (!HasGeo())
		return ;
	m_GeoCodec.MakeRecordDef(RecordDef);
}

void CIuBTreeCodec::MakeRecordDefKey(CIuRecordDef& RecordDef)
{
	ASSERT(GetKeyMap().GetFieldCount() > 0);
	RecordDef.AddFieldDefs(GetKeyMap());

	RecordDef.GetKeyDef() = GetKeyDef();
}

void CIuBTreeCodec::MakeRecordDefMiscellaneous(CIuRecordDef& RecordDef)
{
	RecordDef.AddFieldDefs(GetMiscellaneousMap());
}

void CIuBTreeCodec::MakeRecordDefNoSolicit(CIuRecordDef&)
{
	// Currently, the non-solicit flags are pseudo fields only
}

void CIuBTreeCodec::MakeRecordDefOptional(CIuRecordDef& RecordDef)
{
	RecordDef.AddFieldDefs(GetOptionalMap());
}

void CIuBTreeCodec::MakeRecordDefPhone(CIuRecordDef& RecordDef)
{
	RecordDef.AddFieldDefs(GetPhoneMap());
}

void CIuBTreeCodec::MakeRecordDefRes(CIuRecordDef&)
{
}

void CIuBTreeCodec::MakeRecordDefSpecial(CIuRecordDef& RecordDef)
{
	if (!GetGender().IsEmpty())
	{
		RecordDef.AddFieldDef(GetGender());
	}
}

void CIuBTreeCodec::MakeRecordDefTokens(CIuRecordDef& RecordDef)
{
	GetTokenizers().MakeRecordDef(RecordDef);
}

void CIuBTreeCodec::NextAlt()
{
	if (m_iAlt >= 0)
	{
		ASSERT(m_iAltValues > 0);
		ASSERT(m_iAltValue >= 0);
		if (m_iAltValue < m_iAltValues - 1)
		{
			++m_iAltValue;
			return ;
		}				   
	}

	++m_iAlt;
	m_iAltValue = 0;
	m_iAltValues = 0;
	ASSERT(m_iAlt >= 0);
	if (m_iAlt >= m_pAlt->GetAltCount())
		return ;

	CIuAltInstance Instance;
	m_pAlt->Get(m_iAlt, Instance);
	m_sAlt = Instance.GetKey();
	if (m_sAlt.IsEmpty())
		Error(IU_E_KEY_INVALID, _T("Alternate record key is empty."));
	m_iAltValues = Instance.GetValueCount();
}

void CIuBTreeCodec::OnEditBegin()
{
	IU_TRY_ERROR
	{
		if (m_pInput->Exists())
			m_pInput->LoadFromRecordFile(m_pInput->GetFullFilename());
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
	}
}

void CIuBTreeCodec::Open(bool /* fDebug */)
{
	if (GetVersion() < versionBTreeCodecMin)
		Error(IU_E_BTREE_NO_LONGER_SUPPORTED, _T("Record compressor/expander format is obsolsete."));

	if (!GetBTree().HasData())
		return ;

	// Open the Geo encoder --- only if index has geo information
	if (HasGeo())
		OpenGeo();

	if (HasAddress())
		OpenAddress();

	if (GetSicCount() > 0)
		OpenSic();

	m_fHasAlt = GetAltMoniker().IsValid() && GetBTree().HasData();
	GetTokenizers().Open();
}

void CIuBTreeCodec::OpenAddress()
{
	// Open the Address encoder
	if (GetAddressMoniker().IsValid())
	{
		if (!HasObjectRepository())
			Error(IU_E_NO_REPOSITORY);

		CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_ADDRESS);
		int iAddress = GetObjectRepository().Find(GetAddressMoniker(), sType);
		if (iAddress < 0)
			Error(IU_E_ADDRESS_FILE_NOT_FOUND, LPCTSTR(GetAddressMoniker().AsString()));

	
		CIuObjectPtr pObject = GetObjectRepository().UnPack(iAddress).Ptr();
		if (pObject.IsNull())
			Error(IU_E_ADDRESS_FILE_NOT_FOUND, LPCTSTR(GetAddressMoniker().AsString()));

		m_pAddress = dynamic_cast<CIuAddress*>(pObject.Ptr());
		ASSERT(m_pAddress.NotNull());
		if (HasObjectRepository())
			m_pAddress->SetObjectRepository(&GetObjectRepository());
		m_pAddress->Open();
	}
	else
		m_pAddress.Release();
}

void CIuBTreeCodec::OpenAlt()
{
	m_fPrevAlt = false;
	m_fHasAlt = GetAltMoniker().IsValid() && GetBTree().HasData();

	if (!m_fHasAlt)
	{
		m_pAlt.Release();
		return ;
	}

	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_ALT);
	int iAlt = GetObjectRepository().Find(GetAltMoniker(), sType);
	if (iAlt < 0)
	{
		iAlt = GetObjectRepository().Find(GetAltMoniker(), _T("AltFile"));
		if (iAlt < 0)
			Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(GetAltMoniker().AsString()));
	}

	CIuObjectPtr pObject = GetObjectRepository().UnPack(iAlt).Ptr();
	if (pObject.IsNull())
		Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(GetAltMoniker().AsString()));

	m_pAlt = dynamic_cast<CIuAlt*>(pObject.Ptr());
	ASSERT(m_pAlt.NotNull());
	if (HasObjectRepository())
		m_pAlt->SetObjectRepository(&GetObjectRepository());

	m_pAlt->Open();
	m_iAlt = -1;
	m_sAlt = "";
	NextAlt();
}

void CIuBTreeCodec::OpenGeo()
{
	CIuGeoPtr pGeo = GetGeo();
	if (pGeo.NotNull())
		pGeo->Open(geoCodec);

	m_GeoCodec.SetLatLongPrecision(GetLatLongPrecision());
}

void CIuBTreeCodec::OpenSic()
{
	// Open the Sic encoder
	if (GetSicMoniker().IsValid())
	{
		if (!HasObjectRepository())
			Error(IU_E_NO_REPOSITORY);

		CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_SIC);
		int iSic = GetObjectRepository().Find(GetSicMoniker(), sType);
		if (iSic < 0)
		{
			// Obsolete class type
			iSic = GetObjectRepository().Find(GetSicMoniker(), _T("SicFile"));
			if (iSic < 0)
				Error(IU_E_SIC_FILE_NOT_FOUND, LPCTSTR(GetSicMoniker().AsString()));

		}
	
		CIuObjectPtr pObject = GetObjectRepository().UnPack(iSic).Ptr();
		if (pObject.IsNull())
			Error(IU_E_SIC_FILE_NOT_FOUND, LPCTSTR(GetSicMoniker().AsString()));

		m_pSic = dynamic_cast<CIuSic*>(pObject.Ptr());
		ASSERT(m_pSic.NotNull());
		if (HasObjectRepository())
			m_pSic->SetObjectRepository(&GetObjectRepository());
		m_pSic->Open();
	}
	else
		m_pSic.Release();
}

void CIuBTreeCodec::Resolve()
{
	// If no data, clear the record def. 
	// This would be an index without any embedded key values.
	if (!GetBTree().HasData())
		return ;

	// Clear the current mapping
	m_Map.Clear();

	// Set a resolver spec
	CIuResolveSpec Spec;
	Spec.m_pObjectRepository = m_pObjectRepository;
	Spec.m_pRecordDefSrc = &m_pInput->GetRecordDef();

	// Create the various components
	ResolveKey(Spec);
	ResolveGeo(Spec);
	ResolveAddress(Spec);
	ResolveNoSolicit(Spec);

	if (IsBusOnly())
		ResolveBus(Spec);
	else if (IsResOnly())
		ResolveRes(Spec);
	else if (HasBusResFlag())
		ResolveBusResFlag(Spec);

	ResolveTokens(Spec);
	ResolveMiscellaneous(Spec);
	ResolvePhone(Spec);
	ResolveOptional(Spec);
	ResolveSpecial(Spec);

	// Finally, resolve the master record map
	m_Map.Resolve(Spec);
}

void CIuBTreeCodec::ResolveAddress(CIuResolveSpec& Spec)
{
	if (!HasAddress())
		return ;

	// Resolve the address map
	CIuResolveSpec SpecTemp = Spec;
	GetAddressCodec().Resolve(SpecTemp);
}

void CIuBTreeCodec::ResolveBus(CIuResolveSpec&)
{
	if (!GetEmployeeSizeCode().IsEmpty())
	{
		m_iEmployeeSizeCode = m_Map.AddField(GetEmployeeSizeCode());
	}
	else
		m_iEmployeeSizeCode = -1;

	if (!GetSalesVolumeCode().IsEmpty())
	{
		m_iSalesVolumeCode = m_Map.AddField(GetSalesVolumeCode());
	}
	else
		m_iSalesVolumeCode = -1;

	m_iSicCode = -1;
	m_iFranchiseCode = -1;
	m_iAdSizeCode = -1;
	m_iFirstYear = -1;

	if (GetSicCount() >= 1)
	{
		ASSERT(!GetSicCode().IsEmpty());
		if (!HasSicCode())
		{
			SetSicCount(0);
		}
		else
		{
			m_iSicCode = m_Map.GetFieldCount();
			m_Map.AddField(GetSicCode());
			int iOffset = m_iSicCode + 1;
			if (!GetFranchiseCode().IsEmpty())
			{
				m_iFranchiseCode = iOffset++;
				m_Map.AddField(GetFranchiseCode());
			}
			if (!GetAdSizeCode().IsEmpty())
			{
				m_iAdSizeCode = iOffset++;
				m_Map.AddField(GetAdSizeCode());
			}
			if (!GetFirstYear().IsEmpty())
			{
				m_iFirstYear = iOffset++;
				m_Map.AddField(GetFirstYear());
			}
		}
	}
}

void CIuBTreeCodec::ResolveBusResFlag(CIuResolveSpec& Spec)
{
	// Map the field containing the bus/res flag
	m_iBusResFlag = m_Map.AddField(m_sBusResFlag);
	// Add fields for both business and residential
	ResolveBus(Spec);
	ResolveRes(Spec);
}

void CIuBTreeCodec::ResolveGeo(CIuResolveSpec& Spec)
{
	if (!HasGeo())
		return ;
	// Resolve the Geo map 
	CIuRecordDef recordDef;
	GetGeoMap().Resolve(Spec);
}

void CIuBTreeCodec::ResolveKey(CIuResolveSpec& Spec)
{
	// If no key list, build one from the first field of the raw record
	if (GetKeyMap().GetFieldCount() <= 0)
	{
		GetKeyMap().AddField(GetInput().GetRecordDef().GetFieldDefs().Get(int(0)).GetName());
	}

	GetKeyMap().Resolve(Spec);

	// Set the record def into order to resolve the fields...
	GetKeyDef().CreateFromMapFields(GetKeyMap());

	// Append fields to key map
	m_iKeyFirst = m_Map.AppendFields(GetKeyMap(), &m_iKeyCount);
}

void CIuBTreeCodec::ResolveMiscellaneous(CIuResolveSpec& Spec)
{
	GetMiscellaneousMap().Resolve(Spec);
	m_iMiscellaneousFirst = m_Map.AppendFields(GetMiscellaneousMap(), &m_iMiscellaneousCount);
}

void CIuBTreeCodec::ResolveNoSolicit(CIuResolveSpec&)
{
	if (!NoSolicitMail() && !NoSolicitPhone())
		return ;

	ASSERT(!m_sNoSolicit.IsEmpty());

	// Currently, the non-solicit flags are pseudo fields only
	m_iNoSolicitFirst = m_Map.AddField(m_sNoSolicit);
}

void CIuBTreeCodec::ResolveOptional(CIuResolveSpec& Spec)
{

	GetMiscellaneousMap().Resolve(Spec);
	m_iOptionalFirst = m_Map.AppendFields(GetOptionalMap(), &m_iOptionalCount);
}

void CIuBTreeCodec::ResolvePhone(CIuResolveSpec& Spec)
{
	GetPhoneMap().Resolve(Spec);
	m_iPhoneNoFirst = m_Map.AppendFields(GetPhoneMap(), &m_iPhoneNoCount);
}

void CIuBTreeCodec::ResolveRes(CIuResolveSpec&)
{
}

void CIuBTreeCodec::ResolveSpecial(CIuResolveSpec&)
{
	if (!GetGender().IsEmpty())
	{
		m_iGender = m_Map.AddField(GetGender());
	}
	else
		m_iGender = -1;
}

void CIuBTreeCodec::ResolveTokens(CIuResolveSpec& Spec)
{
	CIuRecordDef recordDef;
	GetTokenizers().Resolve(Spec);
}

void CIuBTreeCodec::SetAddressMoniker(const CIuMoniker& moniker)
{
	m_monikerAddressMoniker = moniker;
}

void CIuBTreeCodec::SetAdSizeCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sAdSizeCode = pcsz;
}

void CIuBTreeCodec::SetAltCity(bool f)
{
	m_fAltCity = f;
}

void CIuBTreeCodec::SetAltMoniker(const CIuMoniker& moniker)
{
	m_monikerAltMoniker = moniker;
}

void CIuBTreeCodec::SetAltPhone(bool f)
{
	m_fAltPhone = f;
}

void CIuBTreeCodec::SetBTree(CIuBTree* pBTree)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	ASSERT(pBTree != 0);
	m_pBTree = pBTree;
	m_pStats = &pBTree->m_Stats;
}

void CIuBTreeCodec::SetBusOnly(bool f)
{
	m_fBusOnly = f;
}

void CIuBTreeCodec::SetBusResFlag(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	// For backwards compatibility, we recognize the value "Yes" which was used
	// when this was a boolean value in very early database releases. We simply
	// ignore the value in that case.
	if (_tcscmp(pcsz, _T("Yes")) != 0)
		m_sBusResFlag = pcsz;
	else
		m_sBusResFlag.Empty();
}

void CIuBTreeCodec::SetEmployeeSizeCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sEmployeeSizeCode = pcsz;
}

void CIuBTreeCodec::SetFirstYear(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFirstYear = pcsz;
}

void CIuBTreeCodec::SetFixedBits(int iFixedBits)
{
	m_iFixedBits = iFixedBits;
}

void CIuBTreeCodec::SetFranchiseCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFranchiseCode = pcsz;
}

void CIuBTreeCodec::SetGender(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sGender = pcsz;
}

void CIuBTreeCodec::SetGeoBits(int iGeoBits)
{
	m_iGeoBits = iGeoBits;
}

void CIuBTreeCodec::SetGeoMoniker(const CIuMoniker& moniker)
{
	m_monikerGeoMoniker = moniker;
}

void CIuBTreeCodec::SetHasAddress(bool f)
{
	m_fHasAddress = f;
}

void CIuBTreeCodec::SetHasGeo(bool f)
{
	m_fHasGeo = f;
}

void CIuBTreeCodec::SetKeyFlags(const CIntArray& al)
{
	m_aiKeyFlags.Copy(al);
}

void CIuBTreeCodec::SetKeyOnly(bool f)
{
	m_fKeyOnly = f;
}

void CIuBTreeCodec::SetLatLongPrecision(int iLatLongPrecision)
{
	m_iLatLongPrecision = iLatLongPrecision;
}

void CIuBTreeCodec::SetMinimumRecordSize(int iMinimumRecordSize)
{
	m_iMinimumRecordSize = iMinimumRecordSize;
}

void CIuBTreeCodec::SetMiscellaneousFlags(const CIntArray& al)
{
	m_aiMiscellaneousFlags.Copy(al);
}

void CIuBTreeCodec::SetNoCityStateCorrection(bool f)
{
	m_fNoCityStateCorrection = f;
}

void CIuBTreeCodec::SetNoCountyCorrection(bool f)
{
	m_fNoCountyCorrection = f;
}

void CIuBTreeCodec::SetNoLatLongCorrection(bool f)
{
	m_fNoLatLongCorrection = f;
}

void CIuBTreeCodec::SetNoMsaCorrection(bool f)
{
	m_fNoMsaCorrection = f;
}

void CIuBTreeCodec::SetNoSolicit(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sNoSolicit = pcsz;
}

void CIuBTreeCodec::SetNoSolicitMail(bool f)
{
	m_fNoSolicitMail = f;
}

void CIuBTreeCodec::SetNoSolicitPhone(bool f)
{
	m_fNoSolicitPhone = f;
}

void CIuBTreeCodec::SetNoZipAddOn(bool f)
{
	m_fNoZipAddOn = f;
}

void CIuBTreeCodec::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
	GetTokenizers().SetObjectRepository(pObjectRepository);
}

void CIuBTreeCodec::SetOptionalFlags(const CIntArray& al)
{
	m_aiOptionalFlags.Copy(al);
}

void CIuBTreeCodec::SetPhoneCount(int iPhoneCount)
{
	m_iPhoneCount = iPhoneCount;
}

void CIuBTreeCodec::SetResOnly(bool f)
{
	m_fResOnly = f;
}

void CIuBTreeCodec::SetSalesVolumeCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSalesVolumeCode = pcsz;
}

void CIuBTreeCodec::SetSicBits(int iSicBits)
{
	m_iSicBits = iSicBits;
}

void CIuBTreeCodec::SetSicCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSicCode = pcsz;
}

void CIuBTreeCodec::SetSicCount(int iSicCount)
{
	m_iSicCount = iSicCount;
}

void CIuBTreeCodec::SetSicMoniker(const CIuMoniker& moniker)
{
	m_monikerSicMoniker = moniker;
}

void CIuBTreeCodec::SetSpec(CIuBTreeSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());

	if (Spec.IsDefaultSource())
		GetInput().SetFilename(Spec.GetCdrom().GetFilename());
	else
		GetInput().SetFilename(Spec.GetFilename());

	SetHasGeo(Spec.HasGeo());

	SetNoMsaCorrection(Spec.NoMsaCorrection());
	SetNoCountyCorrection(Spec.NoCountyCorrection());
	SetNoZipAddOn(Spec.NoZipAddOn());
	SetNoCityStateCorrection(Spec.NoCityStateCorrection());
	SetNoLatLongCorrection(Spec.NoLatLongCorrection());
	SetLatLongPrecision(Spec.GetLatLongPrecision());

	SetNoSolicit(Spec.GetNoSolicit());
	SetNoSolicitMail(Spec.NoSolicitMail());
	SetNoSolicitPhone(Spec.NoSolicitPhone());

	SetBusResFlag(Spec.GetBusResFlag());
	SetBusOnly(Spec.IsBusOnly());
	SetResOnly(Spec.IsResOnly());

	// Always attach the geo moniker. Some codecs (address) use it even
	// if not encoding geo information
	if (Spec.GetCdrom().HasGeo())
		SetGeoMoniker(Spec.GetCdrom().GetGeo().GetMoniker());

	GetKeyMap().Clear();

	CStringArray as;

	Spec.GetKeys(as);
	GetKeyMap().Clear();
	for (int iKey = 0; iKey < as.GetSize(); ++iKey)
		GetKeyMap().AddField(as[iKey]);

	Spec.GetPhones(as);
	GetPhoneMap().Clear();
	for (int iPhone = 0; iPhone < as.GetSize(); ++iPhone)
		GetPhoneMap().AddField(as[iPhone]);

	Spec.GetMiscellaneous(as);
	GetMiscellaneousMap().Clear();
	for (int iMiscellaneous = 0; iMiscellaneous < as.GetSize(); ++iMiscellaneous)
		GetMiscellaneousMap().AddField(as[iMiscellaneous]);

	if (Spec.GetCdrom().HasSic())
		SetSicMoniker(Spec.GetCdrom().GetSic().GetMoniker());

	SetSicCount(Spec.GetSicCount());
	SetSicCode(Spec.GetSicCode());
	SetFranchiseCode(Spec.GetFranchiseCode());
	SetAdSizeCode(Spec.GetAdSizeCode());
	SetFirstYear(Spec.GetFirstYear());
	SetEmployeeSizeCode(Spec.GetEmployeeSizeCode());
	SetSalesVolumeCode(Spec.GetSalesVolumeCode());

	SetAltMoniker(Spec.GetAltMoniker());
	SetAltCity(Spec.AltCity());
	SetAltPhone(Spec.AltPhone());

	SetGender(Spec.GetGender());

	// Call this after setting up the input
	// The geo map builds from the input record def
	GetGeoMap().SetSpec(Spec.GetCdrom().GetGeo());

	// Handle address encode
	SetHasAddress(Spec.HasAddress());
	if (HasAddress())
	{
		SetAddressMoniker(Spec.GetCdrom().GetAddress().GetMoniker());
		GetAddressCodec().SetSpec(Spec.GetCdrom().GetAddress());
	}

	GetTokenizers().SetSpec(Spec);
}

void CIuBTreeCodec::SetTokenBits(const CIntArray& al)
{
	m_aiTokenBits.Copy(al);
}

void CIuBTreeCodec::SetTokenFlags(const CIntArray& al)
{
	m_aiTokenFlags.Copy(al);
}

void CIuBTreeCodec::SetVersion(CIuVersionNumber ver)
{
	m_verVersion = ver;
}
