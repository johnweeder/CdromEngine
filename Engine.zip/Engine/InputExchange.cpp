#include "StdAfx.h"
//{{Include
#include "InputExchange.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputExchange, CIuInputExchange_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputExchange)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTEXCHANGE, CIuInputExchange, CIuInputExchange_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputExchange, IDS_ENGINE_PPG_INPUTEXCHANGE, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputExchange::CIuInputExchange() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputExchange::~CIuInputExchange()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputExchange::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input Exchange"));
	SetInputFilename("Exchange");
	SetOutputFilename("Exchange");
	SetFormat(inputExchange);
	//}}Initialize
}

bool CIuInputExchange::OnProcess()
{
	LPCTSTR pcszExchange			= GetInput(0);
	LPCTSTR pcszExchangeName	= GetInput(1);
	SetField(inputFieldExchange, pcszExchange);
	SetField(inputFieldExchangeName,	pcszExchangeName);
	return Output();
}
