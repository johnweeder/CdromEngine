 #ifndef _ENGINE_EXPORTDEFS_H_
#define _ENGINE_EXPORTDEFS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
#ifndef 	_ENGINE_EXPORTDEF_H_
#	include "Engine\ExportDef.h"
#endif	// _ENGINE_EXPORTDEF_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportDefs)
class CIuEngine;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportDefs, CIuExportDefs_super }}
#define CIuExportDefs_super CIuCollection

class IU_CLASS_EXPORT CIuExportDefs : public CIuExportDefs_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportDefs)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportDefs();           
	virtual ~CIuExportDefs();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuExportDef& Get(LPCTSTR s) const;
	CIuExportDef& Get(int iIndex) const;
	CIuExportDef& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Create(CIuExportDefSpec& ExportDefSpec);
	void SetEngine(CIuEngine& Engine);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	CIuCollectablePtr OnNew(CWnd*) const;
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	void CommonConstruct();
private:
	CIuEngine* m_pEngine;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuExportDef& CIuExportDefs::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuExportDef*>(&CIuCollection::Get(s));
}

inline CIuExportDef& CIuExportDefs::Get(int iIndex) const
{
	return *dynamic_cast<CIuExportDef*>(&CIuCollection::Get(iIndex));
}

inline CIuExportDef& CIuExportDefs::Get(CIuID id) const
{
	return *dynamic_cast<CIuExportDef*>(&CIuCollection::Get(id));
}

inline bool CIuExportDefs::HasEngine() const
{
	return m_pEngine!=0;
}

#endif 
