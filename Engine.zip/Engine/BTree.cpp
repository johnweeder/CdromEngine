#include "StdAfx.h"  
//{{Include
#include "BTree.h"
#include "BTreeSpec.h"
#include "BTreeCounts.h"
#include "BTrees.h"
#include "BTreeData.h"
#include "BTreeIndex.h"
#include "BTreePointers.h"
#include "BTreeCodec.h"
#include "resource.h"
#include "Data\Output.h"
#include "Error\Error.h"
#include "RecordDef.h"
#include "Source.h"
#include "KeyList.h"
#include "Data\resource.h"
#include "KeyRange.h"
#include "Alt.h"
#include "AltInstance.h"
#include "CdromSpec.h"
#include "Cdrom.h"
#include "SourceDescriptorSpec.h"
#include "SourceDescriptor.h"
#include "Miscellaneous.h"
#include "Common\String.h"
#include "SetList.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTree, CIuBTree_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTree)
#ifdef _DEBUG
// Allow smaller blocks during development so we can grow multi-level trees
const int iMinBlockSize = 2 * 1024;
#else
const int iMinBlockSize = 8 * 1024;
#endif
const	CIuVersionNumber versionBTreeMax(2000,1,5,304);
const	CIuVersionNumber versionBTreeMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREE, CIuBTree, CIuBTree_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuBTree, IDS_ENGINE_PPG_BTREE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTree, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuBTree, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTree, IDS_ENGINE_PROP_BLOCKSIZE, GetBlockSize, SetBlockSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTree, IDS_ENGINE_PROP_BLOCKSIZE, IDS_ENGINE_PPG_BTREE, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_HASPOINTERS, HasPointers, SetHasPointers, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_HASPOINTERS, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_HASDATA, HasData, SetHasData, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_HASDATA, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_HASMULTIPOINTERS, HasMultiPointers, SetHasMultiPointers, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_HASMULTIPOINTERS, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTree, IDS_ENGINE_PROP_MINIMUMRECORDSIZE, IDS_ENGINE_PPG_BTREE, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTree, IDS_ENGINE_PROP_MINIMUMRECORDSIZE, GetMinimumRecordSize, SetMinimumRecordSize, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTree, IDS_ENGINE_PROP_BTREEEXPAND, GetBTreeExpand, SetBTreeExpand, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTree, IDS_ENGINE_PROP_BTREEEXPAND, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_CREATETRANSLATION, CreateTranslation, SetCreateTranslation, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_CREATETRANSLATION, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_USETRANSLATION, UseTranslation, SetUseTranslation, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_USETRANSLATION, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTree, IDS_ENGINE_PROP_TRANSLATIONFILENAME, GetTranslationFilename, SetTranslationFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuBTree, IDS_ENGINE_PROP_TRANSLATIONFILENAME, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTree, IDS_ENGINE_PROP_ALTMONIKER, GetAltMoniker, SetAltMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTree, IDS_ENGINE_PROP_ALTMONIKER, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_ALTCOMMA, IsAltComma, SetAltComma, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_ALTCOMMA, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTree, IDS_ENGINE_PROP_DEFAULTSOURCE, IsDefaultSource, SetDefaultSource, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTree, IDS_ENGINE_PROP_DEFAULTSOURCE, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTree, IDS_ENGINE_PROP_DATABASE, GetDatabase, SetDatabase, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTree, IDS_ENGINE_PROP_DATABASE, IDS_ENGINE_PPG_BTREE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTree, IDS_ENGINE_PROP_CODEC, GetCodec_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTree, IDS_ENGINE_PROP_CODEC, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTree, IDS_ENGINE_PROP_DATA, GetData_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTree, IDS_ENGINE_PROP_DATA, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTree, IDS_ENGINE_PROP_INDEX, GetIndex_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTree, IDS_ENGINE_PROP_INDEX, IDS_ENGINE_PPG_BTREE, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTree, IDS_ENGINE_PROP_POINTERS, GetPointers_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTree, IDS_ENGINE_PROP_POINTERS, IDS_ENGINE_PPG_BTREE, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTree::CIuBTree() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	//{{Initialize
	m_iOpen = 0;
	m_fDebug = false;
	m_iBlockSize = iMinBlockSize;
	m_pIndex.Create();
	m_pIndex->SetBTree(this);
	m_pData.Create();
	m_pData->SetBTree(this);
	m_pPointers.Create();
	m_pPointers->SetBTree(this);
	m_pCodec.Create();
	m_pCodec->SetBTree(this);
	m_fHasPointers = false;
	m_fHasData = true;
	m_fHasMultiPointers = false;
	m_monikerBTreeExpand.Clear();
	m_sFilename = "BTree";
	m_iMinimumRecordSize = 0;
	m_fCreateTranslation = false;
	m_fUseTranslation = false;
	m_sTranslationFilename = "TranslationFilename";
	m_monikerAltMoniker.Clear();
	m_fAltComma = false;
	m_pObjectRepository = 0;
	m_fDefaultSource = false;
	m_sDatabase = "";
	m_lRecordNoKey = -1;
	SetVersion(versionBTreeMax);
	//}}Initialize
}

CIuBTree::~CIuBTree()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
	while (m_iOpen > 0)
		Close();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBTree::AddSetList(CIuSetLists& SetList, CIuOutput* pOutput, CIuID& ID, UINT32 uiLo, UINT32 uiCount, UINT32 uiMin, UINT32 uiMax)
{
	ASSERT(HasPointers());
	ASSERT(m_monikerBTreeExpand.IsValid());
	ASSERT(m_monikerBTreeExpand.GetID() == ID);
	return GetPointers().AddSetList(SetList, pOutput, ID, uiLo, uiCount, uiMin, uiMax);
}

void CIuBTree::AttachBTreeExpand() const
{
	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	if (!m_monikerBTreeExpand.IsValid())
		return ;

	ASSERT(m_pBTreeExpand.IsNull());
	ASSERT(m_pRecordDefExpand.IsNull());

	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_BTREE);
	int iBTree = GetObjectRepository().Find(m_monikerBTreeExpand, sType);
	if (iBTree >= 0)
	{
		CIuObjectPtr pObject = GetObjectRepository().UnPack(iBTree).Ptr();
		ASSERT(pObject.NotNull());

		m_pBTreeExpand = dynamic_cast<CIuBTree*>(pObject.Ptr());
		ASSERT(m_pBTreeExpand.NotNull());
		m_pBTreeExpand->SetObjectRepository(&GetObjectRepository());

		// Get the expanded record def, but use our own key def!
		m_pRecordDefExpand.Create();
		ASSERT(m_pRecordDefExpand.NotNull());
		*m_pRecordDefExpand = m_pBTreeExpand->GetRecordDef();
		m_pRecordDefExpand->GetKeyDef() = GetRecordDef(false).GetKeyDef();
	}
	else
		m_pBTreeExpand.Release();
}

bool CIuBTree::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (Flags.Test(cdromsBuildCompressBTree))
		if (!BuildCompress(Cdrom, Output))
			return false;
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPack))
		if (!BuildPack(Cdrom, Output, Flags))
			return false;
	return true;
}

bool CIuBTree::BuildCompress(CIuCdrom& Cdrom, CIuOutput& Output)
{
	// Save current progress status
	CIuOutputStateInstance instance(Output);

	m_Stats.Clear();

	// Output description, set range, etc
	Output.OutputF(_T("Compressing %s\n"), LPCTSTR(GetName()));
	if (!Output.Fire())
		return false;

	Close();
	Output.SetMessageF("Creating");
	Create(Output);
	int iEstimatedRecords = GetCodec().GetEstimatedRecordCount();

	Output.SetMessageF(_T("Compressing %ld records from %s\n"), iEstimatedRecords, LPCTSTR(GetName()));
	Output.SetPosition(0);
	Output.SetRange(iEstimatedRecords);
	Output.Fire();

	// The record no of the first record in the block
	int iBlockRecordNo = 0;
	// Number of records in the block
	int iBlockRecordCount = 0;
	// The pointer no of the first record in the block
	int iBlockPointerNo = 0;
	// Number of pointers in the block
	int iBlockPointerCount = 0;

	// First key is empty (loval)
	CIuKey key;
	CIuKey keyPrevious;

	// These are the separator keys from the start of our block
	CIuKey keyBlock;
	CIuKey keyPreviousBlock;

 	Output.SetMessageF("Compressing %s", LPCTSTR(GetName()));

	int iRecords = 0;
	int iNonAltRecords = 0;
	while (GetCodec().Compress(Output))
	{
		if ((iRecords % ((iEstimatedRecords + 99) / 100)) == 0)
		{
			if (iRecords > iEstimatedRecords)
			{
				iEstimatedRecords = iRecords;
				Output.SetRange(iEstimatedRecords);
			}
			Output.SetPosition(iRecords);
			if (!Output.Fire())
				return false;
		}

		if (CreateTranslation() && GetCodec().IsAlt())
			m_AltTranslate.Append(iNonAltRecords);
		else
			++iNonAltRecords;

		int iRecordPointers = 0;
		if (HasPointers())
			iRecordPointers = GetCodec().GetPointers().GetSize();
		if (HasData())
		{
			keyPrevious.CopyFast(key);
			key.CopyFast(GetCodec().GetKey());
			ASSERT(key.Compare(keyPrevious) >= 0);
			if (key.Compare(keyPrevious) < 0)
			{
#ifdef _DEBUG
				afxDump.HexDump("1:", (unsigned char*)keyPrevious.GetKeyPtr(), keyPrevious.GetKeySize(), 16);
				afxDump.HexDump("2:", (unsigned char*)key.GetKeyPtr(), key.GetKeySize(), 16);
#endif
				CString sError;
				sError.Format("Input records not in sort order @ %d (1).\n%s\n%s", 
					iRecords, LPCTSTR(keyPrevious.GetKeyPtr()), LPCTSTR(key.GetKeyPtr()));
				Error(IU_E_COMPRESS_FATAL, LPCTSTR(sError));
			}
			if (!GetData().Append(GetCodec().GetRecord(), iRecordPointers))
			{
				GetIndex().Append(keyBlock, keyPreviousBlock, iBlockRecordNo, iBlockRecordCount, iBlockPointerNo, iBlockPointerCount);

				// Set the keys which will create the separator for the next block
				keyBlock.CopyFast(key);
				keyPreviousBlock.CopyFast(keyPrevious);

				// Adjust counters for next block
				iBlockRecordNo += iBlockRecordCount;
				ASSERT(iBlockRecordNo == iRecords);
				iBlockRecordCount = 0;
				iBlockPointerNo += iBlockPointerCount;
				iBlockPointerCount = 0;

				// Get key for the first record in this block
				key.CopyFast(GetCodec().GetKey());

				// Re-append to the data stream (if _must_ fit this time)
				VERIFY(GetData().Append(GetCodec().GetRecord(), iRecordPointers));
			}
			keyPrevious.CopyFast(key);
		}
		if (HasPointers() && GetCodec().GetPointers().GetSize() > 0)
		{
			if (UseTranslation())
				m_AltTranslate.Translate(GetCodec().GetPointers());
			GetPointers().Append(GetCodec().GetPointers());
		}

		++iBlockRecordCount;
		iBlockPointerCount += iRecordPointers;
		++iRecords;
	}

	if (HasData())
	{
		ASSERT(iRecords == iBlockRecordNo + iBlockRecordCount);
		// Append the key for the final block...
		GetIndex().Append(keyBlock, keyPreviousBlock, iBlockRecordNo, iBlockRecordCount, iBlockPointerNo, iBlockPointerCount);
	}

	Output.SetMessageF("Writing record no translations");
	Output.Fire();
	if (CreateTranslation())
	{
		m_AltTranslate.SetFilename(GetTranslationFilename());
		m_AltTranslate.Write();
	}

	ASSERT(!HasPointers() || GetPointers().GetPointers() == iBlockPointerNo + iBlockPointerCount);

	Output.SetMessageF("Closing");
	Close();
	// Display elapsed time
	instance.Pop(true);

	// Output statistics
	m_Stats.Output(Output);

	// Create the specification for the source and index
	CIuSourceDescriptorSpecArray Specs;
	GetSourceDescriptorSpecs(Specs);
	Cdrom.CreateIndexes(Specs);

	// Return abort status
	return Output.Fire();
}

bool CIuBTree::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	if (HasData())
	{
		if (!GetData().BuildPack(Cdrom, Output, Flags))
			return false;
		if (!GetIndex().BuildPack(Cdrom, Output, Flags))
			return false;
	}
	if (HasPointers())
		if (!GetPointers().BuildPack(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuBTree::Close()
{
	if (m_iOpen <= 0)
		return ;
	--m_iOpen;
	if (m_iOpen != 0)
		return ;

	// The order of closing is important.
	if (m_pAlt.NotNull())
		m_pAlt->Close();
	m_pAlt.Release();
	if (m_pBTreeExpand.NotNull())
		m_pBTreeExpand->Close();
	m_pBTreeExpand.Release();
	m_pRecordDefExpand.Release();

	GetCodec().Close();
	GetData().Close();
	GetPointers().Close();
	GetIndex().Close();

	m_pRecordDef.Release();
}

void CIuBTree::Create(CIuOutput& Output)
{
	while (m_iOpen > 0)
		Close();

	m_pBTreeExpand.Release();
	m_pRecordDefExpand.Release();
	m_pRecordDef.Release();

	SetMinimumRecordSize(1 + (GetCodec().GetFixedBits() + 3) / 4);
	ASSERT(m_iBlockSize >= 512);
	ASSERT((m_iBlockSize % 512) == 0);

	GetCodec().Create(Output);
	if (HasData())
	{
		// Allow for at least one key nybble and all of the fixed bits
		GetData().SetMinimumRecordSize(GetMinimumRecordSize());
		GetCodec().SetMinimumRecordSize(GetMinimumRecordSize());
		GetData().Create(Output);
		GetIndex().Create(Output);
	}
	if (CreateTranslation())
	{
		m_AltTranslate.SetFilename(GetTranslationFilename());
		m_AltTranslate.Clear();
		SetUseTranslation(false);
	}
	else if (UseTranslation())
	{
		m_AltTranslate.SetFilename(GetTranslationFilename());
		m_AltTranslate.Read();
	}

	if (HasPointers())
	{
		int iAdditional = 0;
		if (UseTranslation())
			iAdditional = m_AltTranslate.GetCount();

		GetPointers().SetBitsPerPointer(max(1,GetCodec().GetBitsPerPointer(iAdditional)));
		GetPointers().Create(Output);
	}

	++m_iOpen;
}

void CIuBTree::Delete(CIuOutput* pOutput)
{
	m_AltTranslate.Delete(pOutput);
	if (HasPointers())
		GetPointers().Delete(pOutput);
	if (HasData())
	{
		GetData().Delete(pOutput);
		GetIndex().Delete(pOutput);
	}
}

bool CIuBTree::ExpandSetList(CIuSetLists& SetLists, CIuOutput* pOutput, CIuID& ID, UINT32 uiRecNo, UINT32 uiCount)
{
	// We have a range of keys in the data, we must convert to a range of pointers
	// and then expand the pointers
	ASSERT(HasPointers());
	ASSERT(HasData());

	GetData().Goto(uiRecNo);
	UINT32 uiStart = GetData().GetPointerNo();
	ASSERT(uiCount >= 1);
	if (uiCount > 1)
	{
		GetData().Goto(uiRecNo + uiCount - 1);
		UINT32 uiEnd = GetData().GetPointerNo() + GetData().GetPointerCount() - 1;
		uiCount = uiEnd - uiStart + 1;
	}


	return AddSetList(SetLists, pOutput, ID, uiStart, uiCount);
}

bool CIuBTree::Get(int iRecord, CIuRecordPtr& pRecord, bool fExpanded)
{
	CSingleLock cs(&m_cs, true);
	if (!Get(iRecord, m_RecordSpec, fExpanded))
		return false;
	pRecord.Create(m_RecordSpec);
	return true;
}

bool CIuBTree::Get(int iRecord, CIuRecordSpec& Spec, bool fExpanded)
{
	CSingleLock cs(&m_cs, true);
	Spec.Clear();
	if (HasData())
	{
		if (fExpanded && HasPointers())
		{
			ASSERT(m_pBTreeExpand.NotNull());
			if (m_pBTreeExpand.IsNull())
				Error(IU_E_EXPAND_INVALID);

			// The record no is actually the pointer
			// First, look up the pointer and get the record # in the primary database
			ASSERT(iRecord >= 0 && iRecord < GetCount(fExpanded));
			int iActualRecord = GetPointers().Get(iRecord);
			m_pBTreeExpand->Get(iActualRecord, Spec, false);
#ifdef _DEBUG
			ASSERT(!Spec.IsAlternate());
#endif
			if (HasData())
			{
				// OK, now the tricky part... we need the key for this record.
				// The key currently in the record is from the expanded record set.
				// We want the key based on the record position in this database.
				// There just isn't a good way to do this except to pull the
				// record...
				// It would be nice if we could simply generate the key from the 
				// record but we can't always do that. For example, if a record has
				// multiple SIC's we wouldn't know which one was the key.
				// This operation can be tremendously time consuming so we must
				// do what be can to speed it up.
				GetData().FindPointer(iRecord);

				// Now, store the key
				if (m_lRecordNoKey != GetData().GetRecordNo())
				{
					GetCodec().DeCompress(GetData().GetRecord(), m_RecordSpecKey, true);
					m_lRecordNoKey = GetData().GetRecordNo();
				}
				ASSERT(m_lRecordNoKey >= 0);
				Spec.SetKey(GetCodec().GetKey().GetKeyPtr(), GetCodec().GetKey().GetKeySize());
			}
		}
		else
		{
			ASSERT(iRecord >= 0 && iRecord < GetCount(false));
			GetData().Goto(iRecord);
			GetCodec().DeCompress(GetData().GetRecord(), Spec, false);
			Spec.SetSourceNo(GetID());
			Spec.SetRecordNo(iRecord);
			if (HasPointers())
			{
				ASSERT(Spec.IsAlternate() || GetData().GetPointerNo() >= 0);
				ASSERT(Spec.IsAlternate() || GetData().GetPointerCount() > 0);
				if (!Spec.IsAlternate())
					Spec.SetExpandNo(GetData().GetPointerNo(), GetData().GetPointerCount());
			}
			if (GetCodec().GetKeyDef().IsSimple() && !Spec.IsAlternate())
				Spec.SetKey(GetCodec().GetKeyFields());
			else
				Spec.SetKey(GetCodec().GetKey().GetKeyPtr(), GetCodec().GetKey().GetKeySize());
		}
	}
	else
	{
		// No data, just return blanks...
		return false;
	}
	return true;
}

bool CIuBTree::Get(int iRecord, CIuKey& Key)
{
	CSingleLock cs(&m_cs, true);
	if (HasData())
	{
		ASSERT(iRecord >= 0 && iRecord < GetCount(false));
		GetData().Goto(iRecord);
		m_RecordSpec.Clear();
		GetCodec().DeCompress(GetData().GetRecord(), m_RecordSpec, true);
		Key.Set(GetCodec().GetKey().GetKeyPtr(), GetCodec().GetKey().GetKeySize());
		if (HasPointers())
		{
			Key.SetExpandNo(GetData().GetPointerNo());
			Key.SetExpandCount(GetData().GetPointerCount());
		}
		else
		{
			Key.SetExpandNo(iRecord);
			Key.SetExpandCount(1);
		}
		return true;
	}
	else
	{
		// No data, just return blanks...
		Key.Clear();
		return false;
	}
}

int CIuBTree::GetBlockSize() const
{
	return ((max(512, m_iBlockSize) / 512) * 512);
}

CIuBTrees& CIuBTree::GetBTrees() const
{
	CIuBTrees* pParent = dynamic_cast<CIuBTrees*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuObject* CIuBTree::GetCodec_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pCodec.Ptr()));
}

int CIuBTree::GetCount(bool fExpanded) const
{
	if (fExpanded && HasPointers())
		return GetPointers().GetPointers();
	else
		return GetData().GetRecords();
}

CIuObject* CIuBTree::GetData_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pData.Ptr()));
}

CString CIuBTree::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CIuGeo& CIuBTree::GetGeo() const
{
	ASSERT(GetCodec().HasGeo());
	CIuGeoPtr pGeo = GetCodec().GetGeo();
	ASSERT(pGeo.NotNull());
	return pGeo.Ref();
}

CIuObject* CIuBTree::GetIndex_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pIndex.Ptr()));
}

int CIuBTree::GetKeyStart(const CIuKey& Key, int& iRange) const
{
	ASSERT(!Key.IsInvalid());

	int iBlock = GetIndex().GetSeparatorNoByKey(Key);
	if (iBlock < 0)
		return -1;

	// Get block
	GetData().ReadBlock(iBlock);
	iRange = GetData().GetBlockRecordCount();
	return GetData().GetBlockStartRecordNo();
}

CIuObject* CIuBTree::GetPointers_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pPointers.Ptr()));
}

CIuRecordDef& CIuBTree::GetRecordDef(bool fExpanded) const
{
	if (fExpanded && HasPointers())
	{
		if (m_pBTreeExpand.IsNull())
		{
			AttachBTreeExpand();
			ASSERT(m_pBTreeExpand.NotNull());
			if (m_pBTreeExpand.IsNull())
				Error(IU_E_EXPAND_INVALID);
		}
		return m_pRecordDefExpand.Ref();
	}
	if (m_pRecordDef.IsNull())
	{
		m_pRecordDef = GetCodec().MakeRecordDef();
		ASSERT(m_pRecordDef.NotNull());
	}
	return m_pRecordDef.Ref();
}

void CIuBTree::GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const
{
	ASSERT(HasObjectRepository());
	Specs.RemoveAll();

	// Create the source descriptors
	CString sName = GetName();

	// We need to generate psdeudo id's. Don't just use the next sequential
	// number. The generator has already probably used that ID. Instead, add an 
	// arbitrary large number when forming a new id.
	UINT uiID = GetID();

	// The first simply describes the raw raw
	if (HasData())
	{
		// NOTE: The source has index name matches the name of this object
		//			and the ID matches the ID of this object.
		CIuSourceDescriptorSpec Spec;
		Spec.SetDatabase(GetDatabase());
		Spec.SetIndex(sName);
		Spec.SetID(uiID);
		Spec.SetSource(GetMoniker());
		Spec.SetSourceType(sourceBTree);
		Spec.SetRecordDef(&GetRecordDef(false));
		Spec.AddRecordDef(&GetRecordDef(true));

		// Get a list of all BTREE objects. Find objects which
		// this btree to use for a set list
		CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_BTREE);
		CIuObjectRepository Repository;
		GetObjectRepository().Create(Repository, sType, GetVersionMinStatic(), GetVersionMaxStatic());

		CIuMoniker Moniker = GetMoniker();
		int iObjects = Repository.GetCount();
		for (int iObject = 0; iObject < iObjects; ++iObject)
		{
			CIuObjectPtr pObject = Repository.UnPack(iObject);
			ASSERT(pObject.NotNull());
			CIuBTreePtr pBTree = dynamic_cast<CIuBTree*>(pObject.Ptr());
			ASSERT(pBTree.NotNull());
			pBTree->SetObjectRepository(&GetObjectRepository());

			if (pBTree->m_monikerBTreeExpand == Moniker && pBTree->GetMoniker() != Moniker)
			{
				Spec.AddCriteria(pBTree->GetMoniker(), sourceBTreeSetList);
			}
		}

		if (GetCodec().HasGeo())
		{
			CIuGeoPtr pGeo = GetCodec().GetGeo();
			ASSERT(pGeo.NotNull());
			pGeo->GetSourceDescriptorCriteria(Spec);
		}

		// Add the spec
		Specs.Add(Spec);

		// If this is a default, create a default source (blank index name)
		if (IsDefaultSource())
		{
			ASSERT(HasData());
			// A new source ID is matches this object but the name is blank
			CIuSourceDescriptorSpec SpecDft = Spec;
			SpecDft.SetIndex(_T(""));
			UINT uiIDDft = uiID + 0x4F879A1B;
			SpecDft.SetID(CIuID(uiIDDft));

			Specs.Add(SpecDft);
		}
	}

	// If we have an index with pointers, then we create two additional
	// sources. The first source is the expanded index source
	if (HasPointers())
	{
		CIuSourceDescriptorSpec SpecEx;
		UINT uiIDEx = uiID + 0x57B1F0D6;
		SpecEx.SetID(CIuID(uiIDEx));
		SpecEx.SetDatabase(GetDatabase());
		CString sNameEx = sName + CString(_T("Ex"));
		SpecEx.SetIndex(sNameEx);
		SpecEx.SetSource(GetMoniker());
		SpecEx.SetSourceType(sourceBTreeEx);
		SpecEx.SetRecordDef(&GetRecordDef(true));
		Specs.Add(SpecEx);
	}
}

CIuVersionNumber CIuBTree::GetVersionMax() const
{
	return versionBTreeMax;
}

CIuVersionNumber CIuBTree::GetVersionMaxStatic()
{
	return versionBTreeMax;
}

CIuVersionNumber CIuBTree::GetVersionMin() const
{
	return versionBTreeMin;
}

CIuVersionNumber CIuBTree::GetVersionMinStatic()
{
	return versionBTreeMin;
}

bool CIuBTree::HasGeo() const
{
	return GetCodec().HasGeo();
}

bool CIuBTree::IsOpen() const
{
	return m_iOpen > 0;
}

void CIuBTree::Open(bool fDebug)
{
	CSingleLock cs(&m_cs, true);
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}

	m_pBTreeExpand.Release();
	m_pRecordDefExpand.Release();
	m_pRecordDef.Release();

	m_fDebug = fDebug;
	m_lRecordNoKey = -1;

	if (HasPointers())
		GetPointers().Open(fDebug);
	if (HasData())
	{
		// Allow for at least one key nybble and all of the fixed bits
		GetData().SetMinimumRecordSize(GetMinimumRecordSize());
		GetCodec().SetMinimumRecordSize(GetMinimumRecordSize());
		GetData().Open(fDebug);
		GetIndex().Open(fDebug);
		GetCodec().Open(fDebug);
	}

	++m_iOpen;

	// If expandable, open primary database
	AttachBTreeExpand();
	if (m_pBTreeExpand.NotNull())
		m_pBTreeExpand->Open(fDebug);
}

bool CIuBTree::SanityCheck(CIuCdrom& Cdrom, CIuOutput& Output)
{
	Open(true);

	if (HasPointers())
	{
		if (m_pBTreeExpand.IsNull())
			Error(IU_E_BTREE_INVALID, _T("BTree has pointers but no expand source."));
		if (!GetPointers().SanityCheck(Output))
			return false;
	}
	if (!HasData())
		return true;
	if (!GetIndex().SanityCheck(Output))
		return false;
	if (!GetData().SanityCheck(Output))
		return false;

	// Output description, set range, etc
	int iRecords =  GetData().GetRecords();
	Output.OutputF(_T("Validating BTree %s\n"), LPCTSTR(GetName()));
	Output.OutputF(_T("\t%ld records in blocks of size %d\n"), iRecords, GetBlockSize());

	if (!Output.Fire())
		return false;

	CIuRecordDefPtr pRecordDef = GetCodec().MakeRecordDef();
	int iAcPhone = pRecordDef->GetFieldDefs().Find(_T("AcPhone"));
	int iStateCode = pRecordDef->GetFieldDefs().Find(_T("StateCode"));
	CIuBTreeCounts Counts(GetCodec().HasBusResFlag());

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	Output.SetMessageF(_T("Compressing %ld records"), iRecords);
	Output.SetPosition(0);
	Output.SetRange(iRecords);
	Output.Fire();

	CIuKey KeyPrev;
	CIuKey Key;
	CIuRecordPtr pRecord;
	for (int iRecord = 0; iRecord < iRecords; ++iRecord)
	{
		if ((iRecord % ((iRecords + 99) / 100)) == 0)
		{
			Output.SetPosition(iRecord);
			if (!Output.Fire())
				return false;
		}
		// Basically, we just expand each record to make sure we can...
		Get(iRecord, pRecord, false);

		KeyPrev = Key;
		Key.Set(pRecord->GetKeyPtr(), pRecord->GetKeySize());
		if (Key.Compare(KeyPrev) < 0)
			Error(IU_E_BTREE_INVALID, _T("Primary keys out of sort order."));

		LPCTSTR pcszStateCode = 0;
		if (pcszStateCode >= 0)
			pcszStateCode = pRecord->GetField(iStateCode);
		LPCTSTR pcszAcPhone = 0;
		if (iAcPhone >= 0)
			pcszAcPhone = pRecord->GetField(iAcPhone);
		bool fResidence = pRecord->IsResidence();
		bool fAlt = pRecord->IsAlternate();
		Counts.Add(fAlt, fResidence, pcszStateCode, pcszAcPhone);
	}

	// Display elapsed time
	instance.Pop(true);

	Close();

	// Output the counts information
	CString sTitle;
	sTitle.Format("Compressor Counts for '%s'", LPCTSTR(GetName()));
	CString sOutput = Counts.Output();
	Cdrom.Log(sTitle, sOutput);
	Output.Output(sOutput);

	// Return abort status
	return Output.Fire();
}

void CIuBTree::SetAltComma(bool f)
{
	m_fAltComma = f;
}

void CIuBTree::SetAltMoniker(const CIuMoniker& moniker)
{
	m_monikerAltMoniker = moniker;
}

void CIuBTree::SetBlockSize(int i)
{
	ASSERT(m_iBlockSize >= 512);
	ASSERT((m_iBlockSize % 512) == 0);
	m_iBlockSize = i;
}

void CIuBTree::SetBTreeExpand(const CIuMoniker& moniker)
{
	m_monikerBTreeExpand = moniker;
}

void CIuBTree::SetCreateTranslation(bool f)
{
	m_fCreateTranslation = f;
}

void CIuBTree::SetDatabase(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDatabase = pcsz;
}

void CIuBTree::SetDefaultSource(bool f)
{
	m_fDefaultSource = f;
}

void CIuBTree::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuBTree::SetHasData(bool f)
{
	m_fHasData = f;
}

void CIuBTree::SetHasMultiPointers(bool f)
{
	m_fHasMultiPointers = f;
}

void CIuBTree::SetHasPointers(bool f)
{
	m_fHasPointers = f;
}

void CIuBTree::SetMinimumRecordSize(int iMinimumRecordSize)
{
	m_iMinimumRecordSize = iMinimumRecordSize;
}

void CIuBTree::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
	GetData().SetObjectRepository(pObjectRepository);
	GetIndex().SetObjectRepository(pObjectRepository);
	GetPointers().SetObjectRepository(pObjectRepository);
	GetCodec().SetObjectRepository(pObjectRepository);
}

void CIuBTree::SetSpec(CIuBTreeSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());

	SetBTreeExpand(Spec.GetExpandMoniker());
	SetFilename(Spec.GetFilename());
	SetDefaultSource(Spec.IsDefaultSource());
	SetHasData(Spec.HasData());
	SetHasMultiPointers(Spec.HasPointers());
	SetCreateTranslation(Spec.CreateTranslation());
	SetUseTranslation(Spec.UseTranslation());
	SetAltMoniker(Spec.GetTryHarderMoniker());
	SetAltComma(Spec.IsTryHarderComma());
	if (Spec.UseTranslation() || Spec.CreateTranslation())
	{
		CString sTranslate = Spec.GetCdrom().GetFilename();
		sTranslate += _T(" Translate");
		SetTranslationFilename(sTranslate);
	}

	GetCodec().SetSpec(Spec);
	GetData().SetSpec(Spec);
	GetIndex().SetSpec(Spec);
	GetPointers().SetSpec(Spec);

	SetDatabase(Spec.GetCdrom().GetName());
}

void CIuBTree::SetTranslationFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTranslationFilename = pcsz;
	m_AltTranslate.SetFilename(m_sTranslationFilename);
}

void CIuBTree::SetUseTranslation(bool f)
{
	m_fUseTranslation = f;
}

bool CIuBTree::TryHarder(CIuKeyRange& Range)
{
	// Given an expression specifying some keys. This function attempts to
	// expand the set of keys by "trying harder".
	// Normally, this simply involves looking up the keys in the alternates file.

	// NOTE: The alternates file for the name index contains the last names only.
	// Use a matchesfirst or matchesfirstInitial expression in the WHERE clause.
	if (!GetAltMoniker().IsValid())
		return false;

	if (m_pAlt.IsNull())
	{
		if (!HasObjectRepository())
			Error(IU_E_NO_REPOSITORY);

		CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_ALT);
		int iAlt = GetObjectRepository().Find(GetAltMoniker(), sType);
		if (iAlt < 0)
		{
			iAlt = GetObjectRepository().Find(GetAltMoniker(), _T("AltFile"));
			if (iAlt < 0)
				Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(GetAltMoniker().AsString()));
		}

		CIuObjectPtr pObject = GetObjectRepository().UnPack(iAlt).Ptr();
		if (pObject.IsNull())
			Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(GetAltMoniker().AsString()));

		m_pAlt = dynamic_cast<CIuAlt*>(pObject.Ptr());
		ASSERT(m_pAlt.NotNull());
		if (HasObjectRepository())
			m_pAlt->SetObjectRepository(&GetObjectRepository());
	}

	if (!m_pAlt->IsOpen())
		m_pAlt->Open();

	bool fChanged = false;
	CIuKeyRange RangeNew;
	int iCount = Range.GetCount();
	for (int iRange = 0; iRange < iCount; ++iRange)
	{
		// Always keep the current key...
		CString sKey;
		if (!Range.IsSimpleKey(iRange, &sKey))
		{
			RangeNew.CopyKey(iRange, Range);
			continue;
		}

		// In a multi-part index (city/state,address,pri,sec), we use only the
		// first index component
		int iMultiPart = sKey.Find(keySeparatorChar);
		if (iMultiPart >= 0)
			sKey = sKey.Left(iMultiPart);
#ifdef _DEBUG
		iMultiPart = sKey.Find('^');
		if (iMultiPart >= 0)
			sKey = sKey.Left(iMultiPart);
#endif

		// For comma separated index fields, skip after the comma
		// For example, in a name index
		if (IsAltComma())
		{
			int iComma = sKey.Find(',');
			if (iComma >= 0)
				sKey = sKey.Left(iComma);
		}

		// No wildcards allowed when trying harder, trim...
		int iWildcard = sKey.Find('*');
		if (iWildcard >= 0)
			sKey = sKey.Left(iWildcard);
		iWildcard = sKey.Find('?');
		if (iWildcard >= 0)
			sKey = sKey.Left(iWildcard);

		sKey.TrimLeft();
		sKey.TrimRight();

		int iAlt = m_pAlt->Find(sKey);
		if (iAlt < 0)
		{
			RangeNew.CopyKey(iRange, Range);
			continue;
		}

		// Search the key first
		if (IsAltComma())
			sKey += _T(",*");
		// Otherwise, you must exactly match
		RangeNew.AddKey(sKey);

		// Then search the alternates
		CIuAltInstance instance;
		m_pAlt->Get(iAlt, instance);
	
		int iValues = instance.GetValueCount();
		for (int iValue = 0; iValue < iValues; ++iValue)
		{
			CString sValue = instance.GetValue(iValue);
			if (IsAltComma())
				sValue += _T(",*");
			RangeNew.AddKey(sValue);
			fChanged = true;
		}
	}
	if (fChanged)
		Range = RangeNew;
	return true;
}

bool CIuBTree::Within(CString& sKeys, const CIuLatLongCoordinate& Coord1, const CIuLatLongCoordinate& Coord2) const
{
	CIuMoniker Moniker = GetCodec().GetGeoMoniker();
	if (!Moniker.IsValid())
	{
		// If this index doesn't have a geography
		// Check if the we have an "expander" btree which has a geo
		if (m_pBTreeExpand.IsNull())
		{
			AttachBTreeExpand();
			if (m_pBTreeExpand.NotNull())
			{
				Moniker = m_pBTreeExpand->GetCodec().GetGeoMoniker();
				m_pBTreeExpand.Release();
			}
		}
		else
		{
			Moniker = m_pBTreeExpand->GetCodec().GetGeoMoniker();
		}
		if (!Moniker.IsValid())
			return false;
	}

	ASSERT(HasObjectRepository());
	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_GEO);
	int iGeo = GetObjectRepository().Find(Moniker, sType);
	if (iGeo < 0)
		Error(IU_E_GEO_NOT_FOUND, LPCTSTR(Moniker.AsString()));

	CIuObjectPtr pObject = GetObjectRepository().UnPack(iGeo).Ptr();
	if (pObject.IsNull())
		Error(IU_E_GEO_NOT_FOUND, LPCTSTR(Moniker.AsString()));

	CIuGeoPtr pGeo = dynamic_cast<CIuGeo*>(pObject.Ptr());
	ASSERT(pGeo.NotNull());
	pGeo->SetObjectRepository(&GetObjectRepository());
	bool fResult = pGeo->Within(sKeys, Coord1, Coord2);
	pGeo.Release();
	return fResult;	
}


