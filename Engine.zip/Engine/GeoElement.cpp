#include "StdAfx.h"
//{{Include
#include "GeoElement.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

LPCTSTR CIuGeoElement::GetString(int iString) const
{
	ASSERT(sizeof(*this) == sizeof(m_iStringStart) + sizeof(m_iStringLength));
	LPCTSTR pcsz = reinterpret_cast<LPCTSTR>(this) + m_iStringStart;
	ASSERT(iString >= 0);
	for (; iString > 0; --iString)
	{
		pcsz = _tcschr(pcsz, '\0') + 1;
	}
	return pcsz;
}


