#ifndef _ENGINE_METERSPECIALACCESSDLG_H_
#define _ENGINE_METERSPECIALACCESSDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
#ifndef 	_COMMON_QUERYRESPONSESESSION_H_
#	include "Common\QueryResponseSession.h"
#endif	// _COMMON_QUERYRESPONSESESSION_H_
//}}Uses

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterSpecialAccessDlg, CDialog }}
#define CIuMeterSpecialAccessDlg_super CDialog

class IU_CLASS_EXPORT CIuMeterSpecialAccessDlg : public CIuMeterSpecialAccessDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuMeterSpecialAccessDlg(CWnd* pParent = NULL);   
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool DoDialog(CIuMeter& Meter, CWnd* pParent);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void Update();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
	bool m_fCorrupt;
	int m_iMaxAttempts;
	CFont m_fontLarge;
	CIuQueryResponseSession m_Session;
	DWORD m_dwMode;
//}}Data

public:
	//{{AFX_DATA(CIuMeterSpecialAccessDlg)
	enum { IDD = IDD_ENGINE_METER_SPECIALACCESS };
	CComboBox	m_Access;
	CButton	m_btnWebSite;
	CEdit	m_editPhone;
	CEdit	m_editUserCode;
	CEdit	m_editResponse;
	CButton	m_btnCancel;
	CButton	m_btnEnable;
	CString	m_sUserCode;
	CString	m_sResponse;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterSpecialAccessDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterSpecialAccessDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnEnable();
	afx_msg void OnChange();
	afx_msg void OnWebsite();
	virtual void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERSPECIALACCESSDLG_H_
