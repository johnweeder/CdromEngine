#ifndef _ENGINE_INPUTBUSINESS_H_
#define _ENGINE_INPUTBUSINESS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTRECORDFILE_H_
#	include "Engine\InputRecordFile.h"
#endif	// _ENGINE_INPUTRECORDFILE_H_
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
#ifndef 	_DATA_FILEREADAHEAD_H_
#	include "Data\FileReadAhead.h"
#endif	// _DATA_FILEREADAHEAD_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputBusiness)
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputBusiness, CIuInputRecordFile }}
#define CIuInputBusiness_super CIuInputRecordFile

class CIuInputBusiness : public CIuInputBusiness_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputBusiness)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputBusiness();
	virtual ~CIuInputBusiness();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuFilename GetFullInputFilename() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual int OnGetRange();
	virtual bool OnMoveFirst();
	virtual bool OnMoveNext();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	static int Delimit(CIuBuffer& buffer, LPCTSTR* apcsz, int iPtrs);
private:
	void CommonConstruct();
	bool CreateRecord();
	void Free();
	bool ReadCache();
	int ReadCount();
	bool ReadLine(CIuBuffer& buffer);
	bool ReadRecord();
	bool ReadSkip();
	bool ReadSkip(int iSkip);
	bool ReadSic();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Pointer to a file used for reading the input data
	CIuFileReadAhead m_File;
	// Number of records processed thus far
	int m_iNextRecord;
	// Total length of file
	CIuFilePosition m_Length;
	// Position where current cache read started
	CIuFilePosition m_iCacheNext;
	// The cache itself
	CIuBigBuffer m_Cache;
	// Next byte of data in the cache to processed
	int m_iCacheData;
	// Various buffer for reading the data
	CIuBuffer m_Master;
	CIuBuffer m_Parsed;
	int m_iSics;
	CArray<CIuBuffer*, CIuBuffer*> m_aSic;
	CIuBuffer m_Sic;
	CIuBuffer m_Count;
	CIuBuffer m_Skip;
	// A temporary string used to build fields
	CString m_sSicCode;
	CString m_sFranchiseCode;
	CString m_sAdSizeCode;
	CString m_sFirstYear;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_INPUTBUSINESS_H_
