#include "StdAfx.h"
//{{Include
#include "QueryThread.h"
#include "Query.h"
#include "Globals\Events.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

// Enable this to dump extended trace information
#if 0
#define QUERYTRACE	TRACE
#else
inline void AFX_CDECL QueryTrace(LPCTSTR, ...) { }
#define QUERYTRACE	1 ? (void)0 : ::QueryTrace
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuQueryThread, CIuQueryThread_super)
//}}Implement

CIuQueryThread::CIuQueryThread() 
{
}

CIuQueryThread::~CIuQueryThread()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuQueryThread::OnEvent()
{
	QUERYTRACE("QUERY: Query Thread Event Start\n");

	CIuObjectPtr pObject = GetObject();
	ASSERT_KINDOF(CIuQuery, pObject.Ptr());
	m_pQuery = dynamic_cast<CIuQuery*>(pObject.Ptr());

	m_pQuery->Run();

	m_pQuery.Release();

	QUERYTRACE("QUERY: Query Thread Event Completed\n");
}

CIuQueryThread* CIuQueryThread::Start(bool fPaused)
{
	return dynamic_cast<CIuQueryThread*>(CIuQueryThread_super::Start(RUNTIME_CLASS(CIuQueryThread), CIuID::Create(), fPaused));
}

