#ifndef _ENGINE_METERSELECTPHONEADMINDLG_H_
#define _ENGINE_METERSELECTPHONEADMINDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses											  
#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_
#ifndef 	_COMMON_QUERYRESPONSESESSION_H_
#	include "Common\QueryResponseSession.h"
#endif	// _COMMON_QUERYRESPONSESESSION_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterSelectPhoneAdminDlg, CDialog }}
#define CIuMeterSelectPhoneAdminDlg_super CDialog

class CIuMeterSelectPhoneAdminDlg : public CIuMeterSelectPhoneAdminDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterSelectPhoneAdminDlg(CWnd* pParent = NULL);	// standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	CString m_sUserCode;
private:
	CIuQueryResponseSession m_Session;
	CFont m_fontLarge;
//}}Data

public:
	//{{AFX_DATA(CIuMeterSelectPhoneAdminDlg)
	enum { IDD = IDD_ENGINE_METER_SELECTPHONEADMIN };
	CEdit	m_responseCode;
	CEdit	m_customerCode;
	CString	m_sNotes;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterSelectPhoneAdminDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterSelectPhoneAdminDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeCustomerCode();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERSELECTPHONEADMINDLG_H_
