#include "StdAfx.h"
//{{Include
#include "AltScans.h"
#include "AltScan.h"
#include "Alt.h"
#include "CdromSpecConst.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltScans, CIuAltScans_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltScans)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTSCANS, CIuAltScans, CIuAltScans_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltScans, IDS_ENGINE_PPG_ALTSCANS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuAltScans, IDS_ENGINE_PPG_ALTSCANS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAltScans::CIuAltScans() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltScans::~CIuAltScans()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuAltScans::Build(CIuOutput& Output, CIuFlags Flags)
{
	for (int iAltScan = 0; iAltScan < GetCount(); ++iAltScan)
		if (!Get(iAltScan).Build(Output, Flags))
			return false;
	return true;
}

void CIuAltScans::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuAltScans::Create(int iAlt)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuAltScan& AltScan = Get(iIndex);
	AltScan.SetSpec(iAlt);
}

void CIuAltScans::Initialize()
{
	CIuAltScans_super::Initialize();
	RemoveAll();
	Create(altFirst);
	Create(altLast);
	Create(altCity);
	Create(altPhone);
	Create(altSic);
}

CIuCollectablePtr CIuAltScans::OnNew(CWnd*) const
{
	CIuAltScanPtr pAltScan;
	pAltScan.Create();
	return pAltScan;
}
