#include "stdafx.h" 
//{{Include
#include "Engine.h"
#include "ReportDef.h"
#include "ReportDefSpec.h"
#include "ReportDefs.h"
#include "ReportFieldDefs.h"
#include "resource.h"
#include "CdromSpecConst.h"
#include "Cdrom.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuReportDef, CIuReportDef_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuReportDef)
const	CIuVersionNumber versionReportDefMax(2000,1,5,304);
const	CIuVersionNumber versionReportDefMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REPORTDEF, CIuReportDef, CIuReportDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuReportDef, IDS_ENGINE_PROP_FIELDDEFS, GetFieldDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuReportDef, IDS_ENGINE_PROP_FIELDDEFS, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuReportDef, IDS_ENGINE_PPG_REPORTDEF, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuReportDef, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuReportDef, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_REPORTDEF, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuReportDef::CIuReportDef()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReportDef::~CIuReportDef()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuReportDef::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

void CIuReportDef::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pFieldDefs.IsNull())
	{
		m_pFieldDefs.Create();
		m_pFieldDefs->SetReportDef(this);
	}
	m_pObjectRepository = 0;
	SetVersion(versionReportDefMax);
	//}}Initialize
}

int CIuReportDef::CreateFieldDef(LPCTSTR pcszDef)
{
	return GetFieldDefs().CreateFieldDef(pcszDef);
}

int CIuReportDef::CreateFieldDef(CIuReportFieldDefSpec& spec)
{
	return GetFieldDefs().CreateFieldDef(spec);
}

CIuObject* CIuReportDef::GetFieldDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pFieldDefs.Ptr()));
}

CIuReportDefs& CIuReportDef::GetReportDefs() const
{
	CIuReportDefs* pParent = dynamic_cast<CIuReportDefs*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuVersionNumber CIuReportDef::GetVersionMax() const
{
	return versionReportDefMax;
}

CIuVersionNumber CIuReportDef::GetVersionMaxStatic()
{
	return versionReportDefMax;
}

CIuVersionNumber CIuReportDef::GetVersionMin() const
{
	return versionReportDefMin;
}

CIuVersionNumber CIuReportDef::GetVersionMinStatic()
{
	return versionReportDefMin;
}

void CIuReportDef::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuReportDef::SetSpec(CIuReportDefSpec& ReportDefSpec)
{
	Clear();
	SetMoniker(ReportDefSpec.GetMoniker());
	GetFieldDefs().SetSpec(ReportDefSpec);
}

