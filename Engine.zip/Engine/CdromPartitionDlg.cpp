#include "stdafx.h"
#include "engine.h"
#include "CdromPartitionDlg.h"
#include "ui\resource.h"
#include "ui\FillStatesDlg.h"
#include "ui\Draw3d.h"
#include "ui\InputDlg.h"
#include "Common\SortedStringArray.h"
#include "CdromProductSpecDft.h"
#include "CdromFormatSpecDft.h"
#include "Common\Options.h"
#include "Interop\Conversions.h"
#include "Ui\ContextMenu.h"
#include "Common\Clipboard.h"
#include "Data\DataFilename.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuCdromPartitionDlg, CIuCdromPartitionDlg_super)
	//{{AFX_MSG_MAP(CIuCdromPartitionDlg)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_ENGINE_PRODUCTS, OnChange)
	ON_NOTIFY(NM_RCLICK, IDC_ENGINE_STATES, OnRclickStates)
	ON_BN_CLICKED(IDC_ENGINE_CLIPBOARD, OnClipboard)
	ON_BN_CLICKED(IDC_ENGINE_LOAD, OnLoad)
	ON_BN_CLICKED(IDC_ENGINE_SAVE, OnSave)
	ON_NOTIFY(NM_DBLCLK, IDC_ENGINE_REGIONS, OnDblClickRegions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

struct CIuStateCounts
{
	LPCTSTR m_pcszAbbr;
	int m_iBusinesses;
	int m_iResidences;
};

static CIuStateCounts aStateCounts[] = 
{
	{ "AK",      37678,     283564  }, 
	{ "AL",     167951,    1775993  }, 
	{ "AR",     116918,    1058721  }, 
	{ "AZ",     181229,    1588129  }, 
	{ "CA",    1346172,    9604631  }, 
	{ "CO",     198835,    1667764  }, 
	{ "CT",     154813,    1346701  }, 
	{ "DC",      51226,     194852  }, 
	{ "DE",      35367,     303997  }, 
	{ "FL",     673069,    6777391  }, 
	{ "GA",     324221,    3110073  }, 
	{ "HI",      51994,     333612  }, 
	{ "IA",     134479,    1345433  }, 
	{ "ID",      64044,     552494  }, 
	{ "IL",     500255,    3688005  }, 
	{ "IN",     229586,    2162368  }, 
	{ "KS",     125909,    1159276  }, 
	{ "KY",     146661,    1588488  }, 
	{ "LA",     171686,    1710647  }, 
	{ "MA",     291261,    2628845  }, 
	{ "MD",     213356,    1831218  }, 
	{ "ME",      65377,     736902  }, 
	{ "MI",     397245,    3415196  }, 
	{ "MN",     212006,    2305774  }, 
	{ "MO",     236683,    2232225  }, 
	{ "MS",     104638,    1060504  }, 
	{ "MT",      54089,     451071  }, 
	{ "NC",     331801,    3193565  }, 
	{ "ND",      37637,     331197  }, 
	{ "NE",      82143,     757144  }, 
	{ "NH",      64122,     645519  }, 
	{ "NJ",     363420,    2587638  }, 
	{ "NM",      77408,     591412  }, 
	{ "NV",      79325,     572886  }, 
	{ "NY",     757209,    6368997  }, 
	{ "OH",     452798,    3723078  }, 
	{ "OK",     155513,    1401362  }, 
	{ "OR",     162412,    1460367  }, 
	{ "PA",     493798,    4466292  }, 
	{ "RI",      42999,     389188  }, 
	{ "SC",     159147,    1478038  }, 
	{ "SD",      38583,     359179  }, 
	{ "TN",     230480,    2341454  }, 
	{ "TX",     861609,    7053317  }, 
	{ "UT",      90475,     718033  }, 
	{ "VA",     280166,    2674525  }, 
	{ "VT",      35018,     380742  }, 
	{ "WA",     243995,    2374921  }, 
	{ "WI",     228455,    2603009  }, 
	{ "WV",      67940,     795726  }, 
	{ "WY",      29674,     222823  }, 
	/* End of List */
	{ 0 }
};

static const COLORREF aRegionColors[] = 
{
	RGB(  0,   0, 255),
	RGB(  0, 255,   0),
	RGB(255,   0,   0),
	RGB(  0, 255, 255),
	RGB(255,   0, 255),
	RGB(255, 255,   0),
	RGB(  0,   0, 128),
	RGB(  0, 128,   0),
	RGB(128,   0,   0),
	RGB(  0, 128, 128),
	RGB(128,   0, 128),
	RGB(128, 128,   0),
	RGB(255, 255, 255), // Un-assigned
	RGB(  0,   0,   0), // Multi-assigned
};

const int iMaxRegions				= 12;
const int iRegionUnAssigned		= iMaxRegions;
const int iRegionMultiAssigned	= iMaxRegions + 1;

//}}Implement

CIuCdromPartitionDlg::CIuCdromPartitionDlg(CWnd* pParent) : CIuCdromPartitionDlg_super(CIuCdromPartitionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuCdromPartitionDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_uiBitmap = IDB_UI_STATES;
	m_FillRegions.FromString(CIuFillStatesDlg::m_apcszStates);
	ASSERT(sizeof(aRegionColors)/sizeof(aRegionColors[0]) == iMaxRegions + 2);
}

void CIuCdromPartitionDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuCdromPartitionDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuCdromPartitionDlg)
	DDX_Control(pDX, IDC_ENGINE_PRODUCTS, m_lbProducts);
	DDX_Control(pDX, IDC_ENGINE_STATES, m_listStates);
	DDX_Control(pDX, IDC_ENGINE_REGIONS, m_listRegions);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CIuCdromPartitionDlg message handlers

void CIuCdromPartitionDlg::DoDialog(CWnd* pParent)
{
	CIuCdromPartitionDlg Dlg(pParent);
	Dlg.DoModal();
}

CIuStateInfo* CIuCdromPartitionDlg::FindStateInfo(LPCTSTR pcszAbbr)
{
	for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
	{
		CIuStateInfo& State = m_aStates.ElementAt(iState);
		if (_tcsicmp(State.m_szName, pcszAbbr) == 0)
		{
			return &State;
		}
	}
	return 0;
}

void CIuCdromPartitionDlg::OnChange() 
{
	CString sProduct;
	m_lbProducts.GetWindowText(sProduct);

	bool fNewRegion = m_sPrevious.Compare(sProduct) != 0;
	m_sPrevious = sProduct;

	// Clear the states
	if (fNewRegion)
	{
		for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
		{
			CIuStateInfo& State = m_aStates.ElementAt(iState);
			State.m_iRegion = iRegionUnAssigned;
			State.m_iSelected = 0;
		}
	}

	// Clear the regions
	for (int iRegion = 0; iRegion < m_aRegions.GetSize(); ++iRegion)
	{
		CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);
		Region.m_iStates = 0;
		Region.m_iRecords = 0;
	}

	// Go through and update the states based on the regions
	if (fNewRegion)
	{
		int iProducts = CIuCdromProductSpecDft::GetCount();
		int iRegionsUsed = 0;
		bool fIncludeBusinesses = true;
		bool fIncludeResidences = true;
		for (int iProduct = 0; iProduct < iProducts; ++iProduct)
		{
			const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
			ASSERT(pProduct);
			if (sProduct.CompareNoCase(pProduct->m_pcszProductGroup) != 0)
				continue;

			if (iRegionsUsed >= iMaxRegions)
			{
				AfxMessageBox("Exceeded maximum number of regions");
				continue;
			}

			CIuRegionInfo& Region = m_aRegions.ElementAt(iRegionsUsed);
			if (fNewRegion)
			{
				LPCTSTR pcszName = pProduct->m_pcszProduct;
				ASSERT(pcszName);
				int iLength = _tcslen(pcszName);
				if (iLength >= sizeof(Region.m_szName))
				{
					memcpy(Region.m_szName, pcszName, sizeof(Region.m_szName));
					Region.m_szName[sizeof(Region.m_szName)-1] = '\0';
				}
				else
					_tcscpy(Region.m_szName, pcszName);
			}

			int iFormat = CIuCdromFormatSpecDft::Find(pProduct->m_iFormatNo);
			ASSERT(iFormat >= 0);
			const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iFormat);
			ASSERT(pFormat);

			CIuOptions Options = pFormat->m_pcszOptions;
			fIncludeBusinesses = Options.Find(_T("business")) >= 0;
			fIncludeResidences = Options.Find(_T("residential")) >= 0;

			ASSERT(AfxIsValidString(pProduct->m_pcszStates));
			CStringArray asStates;
			StringAsStringArray(pProduct->m_pcszStates, asStates);

			for (int iState = 0; iState < asStates.GetSize(); ++iState)
			{
				ASSERT(CIuCdromPartitionDlg::FindStateInfo(asStates[iState]));
				CIuStateInfo& State = *CIuCdromPartitionDlg::FindStateInfo(asStates[iState]);
				if (State.m_iRegion != iRegionUnAssigned)
				{
					CString sNotice;
					sNotice.Format(_T("State %s is used in more than one region."), LPCTSTR(asStates[iState]));
					AfxMessageBox(sNotice);

					State.m_iRegion = iRegionMultiAssigned;
				}
				else
					State.m_iRegion = iRegionsUsed;
			}
			++iRegionsUsed;
		}

		for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
		{
			CIuStateInfo& State = m_aStates.ElementAt(iState);
			State.m_iSelected = 0;
			if (fIncludeBusinesses)
				State.m_iSelected += State.m_iBusinesses;
			if (fIncludeResidences)
				State.m_iSelected += State.m_iResidences;
		}
	}

	// Update the state list box
	int iRecords = 0;
	for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
	{
		CIuStateInfo& State = m_aStates.ElementAt(iState);

		if (State.m_iRegion < iMaxRegions)
		{
			CIuRegionInfo& Region = m_aRegions.ElementAt(State.m_iRegion);
			++Region.m_iStates;
			Region.m_iRecords += State.m_iSelected;
		}

		CString s;
		if (State.m_iRegion == iRegionUnAssigned)
		{
	      m_listStates.SetItemText(iState, 1, _T("?"));
			m_listStates.SetItemText(iState, 5, _T(""));
		}
		else if (State.m_iRegion == iRegionMultiAssigned)
		{
	      m_listStates.SetItemText(iState, 1, _T("> 1"));
			m_listStates.SetItemText(iState, 5, _T(""));
		}
		else
		{
			s.Format("%d", State.m_iRegion + 1);
			m_listStates.SetItemText(iState, 1, s);
			s.Format("%d", State.m_iSelected);
			m_listStates.SetItemText(iState, 5, s);
		}
		s.Format("%d", State.m_iBusinesses);
		m_listStates.SetItemText(iState, 2, s);
		s.Format("%d", State.m_iResidences);
		m_listStates.SetItemText(iState, 3, s);
		s.Format("%d", State.m_iBusinesses + State.m_iResidences);
		m_listStates.SetItemText(iState, 4, s);

		iRecords += State.m_iSelected;
	}

	// Get number of used regions.
	int iRegionsUsed = 0;
	for (iRegion = 0; iRegion < m_aRegions.GetSize(); ++iRegion)
	{
		CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);
		if (Region.m_iRecords > 0)
			++iRegionsUsed;
	}

	// Get average
	int iAverage = iRecords;
	if (iRegionsUsed > 0)
		iAverage /= iRegionsUsed;

	// Update the regions list box
	for (iRegion = 0; iRegion < m_aRegions.GetSize(); ++iRegion)
	{
		CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);

		CString s;

		m_listRegions.SetItemText(iRegion, 1, Region.m_szName);
		s.Format("%d", Region.m_iStates);
		m_listRegions.SetItemText(iRegion, 2, s);
		s.Format("%d", Region.m_iRecords);
		m_listRegions.SetItemText(iRegion, 3, s);
		int iVariance = Region.m_iRecords - iAverage;
		s.Format("%d", iVariance);
		m_listRegions.SetItemText(iRegion, 4, s);
		if (iAverage != 0)
		{
			s.Format("%.2f", 100 * double(iVariance)/double(iAverage));
			m_listRegions.SetItemText(iRegion, 5, s);
		}
		else
			m_listRegions.SetItemText(iRegion, 5, _T(""));
	}

	InvalidateRect(0);
}

void CIuCdromPartitionDlg::OnClipboard() 
{
	CString sSave = Save();
	CopyToClipboard(sSave, this);
}

void CIuCdromPartitionDlg::OnDblClickRegions(NMHDR*, LRESULT* pResult)
{
	*pResult = 0;

	int iRegion = m_listRegions.GetNextItem(-1, LVNI_SELECTED);
	if (iRegion < 0 || iRegion >= iMaxRegions)
		return ;

	CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);
	CString sName = Region.m_szName;

	if (!CIuInputDlg::Input(sName, this, _T("Name..."), _T("Enter region name:")))
		return ;

	int iLength = sName.GetLength();
	LPCTSTR pcszName = sName;
	if (iLength >= sizeof(Region.m_szName))
	{
		memcpy(Region.m_szName, pcszName, sizeof(Region.m_szName));
		Region.m_szName[sizeof(Region.m_szName)-1] = '\0';
	}
	else
		_tcscpy(Region.m_szName, pcszName);

	OnChange();
}

BOOL CIuCdromPartitionDlg::OnInitDialog()
{
	CIuCdromPartitionDlg_super::OnInitDialog();
	
	// Load bitmaps
	ASSERT(m_uiBitmap != 0);

	VERIFY(m_Bitmap.LoadBitmap(m_uiBitmap));

   BITMAP bm;
   m_Bitmap.GetObject(sizeof(bm), &bm);

	m_cs.cx = bm.bmWidth;
	m_cs.cy = bm.bmHeight;

	// Position elements relative to bitmap
	m_LayoutManager.Attach(this);

	m_LayoutManager.SetConstraint(IDOK,								OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDOK,								OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_CLIPBOARD,		OX_LMS_LEFT,	OX_LMT_OPPOSITE,	2 * iWindowMargin, IDC_ENGINE_SAVE);
	m_LayoutManager.SetConstraint(IDC_ENGINE_CLIPBOARD,		OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_SAVE,				OX_LMS_LEFT,	OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_LOAD);
	m_LayoutManager.SetConstraint(IDC_ENGINE_SAVE,				OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_LOAD,				OX_LMS_LEFT,	OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_REGIONS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_LOAD,				OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_REGIONS,			OX_LMS_LEFT,	OX_LMT_SAME,		iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_REGIONS,			OX_LMS_TOP,		OX_LMT_SAME,		m_cs.cy + 2 * iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_REGIONS,			OX_LMS_BOTTOM,	OX_LMT_SAME,		-iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_PRODUCTS,			OX_LMS_LEFT,	OX_LMT_SAME,		m_cs.cx + 2 * iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_PRODUCTS,			OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_PRODUCTS,			OX_LMS_TOP,		OX_LMT_SAME,		iWindowMargin, 0);

	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,			OX_LMS_LEFT,	OX_LMT_SAME,		m_cs.cx + 2 * iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,			OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,			OX_LMS_TOP,		OX_LMT_OPPOSITE,	iWindowMargin, IDC_ENGINE_PRODUCTS);
	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,			OX_LMS_BOTTOM,	OX_LMT_OPPOSITE,	-iWindowMargin, IDC_ENGINE_INSTRUCTIONS);

	m_LayoutManager.SetConstraint(IDC_ENGINE_INSTRUCTIONS,	OX_LMS_LEFT,	OX_LMT_SAME,		m_cs.cx + 2 * iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_INSTRUCTIONS,	OX_LMS_RIGHT,	OX_LMT_SAME,		-iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_INSTRUCTIONS,	OX_LMS_BOTTOM,	OX_LMT_OPPOSITE,	-iWindowMargin, IDOK);

	// Draw the layout with the new constraints
	// This is necessary when constraints are implemented and the window must be refreshed
	m_LayoutManager.RedrawLayout();

	// Create states list
	m_listStates.InsertColumn(0, _T("State"),			LVCFMT_LEFT, 50);
	m_listStates.InsertColumn(1, _T("Region"),		LVCFMT_LEFT, 80);
	m_listStates.InsertColumn(2, _T("Businesses"),	LVCFMT_RIGHT, 90);
	m_listStates.InsertColumn(3, _T("Residences"),	LVCFMT_RIGHT, 90);
	m_listStates.InsertColumn(4, _T("Total"),			LVCFMT_RIGHT, 90);
	m_listStates.InsertColumn(5, _T("Selected"),		LVCFMT_RIGHT, 90);

	for (int iState = 0; aStateCounts[iState].m_pcszAbbr; ++iState)
	{
		CIuStateInfo State;
		State.m_szName[0] = aStateCounts[iState].m_pcszAbbr[0];
		State.m_szName[1] = aStateCounts[iState].m_pcszAbbr[1];
		State.m_szName[2] = '\0';
		State.m_iBusinesses = aStateCounts[iState].m_iBusinesses;
		State.m_iResidences = aStateCounts[iState].m_iResidences;
		State.m_iRegion = iRegionUnAssigned;
		State.m_iSelected = 0;

		m_listStates.InsertItem(iState, State.m_szName);

		m_aStates.Add(State);
	}

	// Create regions list
	m_listRegions.InsertColumn(0, _T("Region"),			LVCFMT_LEFT, 75);
	m_listRegions.InsertColumn(1, _T("Name"),				LVCFMT_LEFT, 125);
	m_listRegions.InsertColumn(2, _T("States"),			LVCFMT_RIGHT, 80);
	m_listRegions.InsertColumn(3, _T("Records"),			LVCFMT_RIGHT, 80);
	m_listRegions.InsertColumn(4, _T("Variance"),		LVCFMT_RIGHT, 80);
	m_listRegions.InsertColumn(5, _T("Percent"),			LVCFMT_RIGHT, 80);

   // create the CImageList with 16x15 images
   VERIFY(m_Images.Create (16, 15, TRUE, 0, 1));
   CBitmap bmImages;
   // IDR_MAINFRAME is the toolbar bitmap in a default AppWizard
   // project.
   bmImages.LoadBitmap(IDB_ENGINE_REGION_IMAGES);
   // This will automatically parse the bitmap 
   m_Images.Add(&bmImages, RGB (192, 192, 192));

   // Associate CImageList with CListCtrl.
   m_listRegions.SetImageList(&m_Images, LVSIL_SMALL);

	for (int iRegion = 0; iRegion < iMaxRegions; ++iRegion)
	{
		CIuRegionInfo Region;
		Region.m_szName[256+1];
		_tcscpy(Region.m_szName, _T("No Name"));
		ASSERT(_tcslen(Region.m_szName) < sizeof(Region.m_szName));
		Region.m_iStates = 0;
		Region.m_iRecords = 0;
		m_aRegions.Add(Region);

		CString s;
		s.Format(_T("%d"), iRegion + 1);
		m_listRegions.InsertItem(LVIF_IMAGE|LVIF_TEXT, iRegion, s, 0, 0, iRegion, 0L);
	}

	/// Load products
	CIuSortedStringArray as;
	as.SetNoCase(true);
	as.SetDedup(true);

	int iProducts = CIuCdromProductSpecDft::GetCount();
	for (int iProduct = 0; iProduct < iProducts; ++iProduct)
	{
		const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
		as.Add(pProduct->m_pcszProductGroup);
	}

	for (iProduct = 0; iProduct < as.GetSize(); ++iProduct)
		m_lbProducts.AddString(as[iProduct]);

	m_lbProducts.SetCurSel(0);

	// Set initial contents
	OnChange();

	// Center window
	CenterWindow();
	
	return TRUE;  
}

void CIuCdromPartitionDlg::OnLoad() 
{
	CString sLoadFilename;
	if (!IuDataFilenameQuery(sLoadFilename, extCdromPartition, _T("Load Filename"), this))
		return ;
	CString sLoad;
	CStdioFile LoadFile;
	if (!LoadFile.Open(sLoadFilename, CFile::modeRead|CFile::shareDenyNone|CFile::typeText))
		return ;
	CString s;
	while (LoadFile.ReadString(s))
	{
		sLoad += s;
		sLoad += '\n';
	}
	LoadFile.Close();

	for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
	{
		CIuStateInfo& State = m_aStates.ElementAt(iState);
		State.m_iRegion = iRegionUnAssigned;
	}

	LPCTSTR pcsz = sLoad;
	while (*pcsz)
	{
		CString sRegion;
		for (;*pcsz && *pcsz != '|' && *pcsz != '\n'; ++pcsz)
			sRegion += *pcsz;
		if (*pcsz == '|')
			++pcsz;
		CString sName;
		for (;*pcsz && *pcsz != '|' && *pcsz != '\n'; ++pcsz)
			sName += *pcsz;
		if (*pcsz == '|')
			++pcsz;
		CStringArray asStates;
		CString sState;
		for (;*pcsz && *pcsz != '|' && *pcsz != '\n'; ++pcsz)
		{
			if (*pcsz == ',')
			{
				sState.TrimLeft();
				sState.TrimRight();
				if (!sState.IsEmpty())
					asStates.Add(sState);
				sState.Empty();
			}
			else
				sState += *pcsz;
		}
		sState.TrimLeft();
		sState.TrimRight();
		if (!sState.IsEmpty())
			asStates.Add(sState);
		if (*pcsz == '|')
			++pcsz;
		CString sStatesCpp;
		for (;*pcsz && *pcsz != '\n'; ++pcsz)
			sStatesCpp += *pcsz;
		while (*pcsz == '\n')
			++pcsz;

		sRegion.TrimLeft();
		sRegion.TrimRight();
		int iRegion = atoi(sRegion);
		if (iRegion < 0 || iRegion >= iMaxRegions)
			continue;

		CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);
		sName.TrimLeft();
		sName.TrimRight();

		int iLength = sName.GetLength();
		LPCTSTR pcszName = sName;
		if (iLength >= sizeof(Region.m_szName))
		{
			memcpy(Region.m_szName, pcszName, sizeof(Region.m_szName));
			Region.m_szName[sizeof(Region.m_szName)-1] = '\0';
		}
		else
			_tcscpy(Region.m_szName, pcszName);

		for (int iState = 0; iState < asStates.GetSize(); ++iState)
		{
			CIuStateInfo* pStateInfo = CIuCdromPartitionDlg::FindStateInfo(asStates[iState]);
			if (pStateInfo == 0)
				continue;
			pStateInfo->m_iRegion = iRegion;
		}
	}

	OnChange();
}

void CIuCdromPartitionDlg::OnPaint() 
{
	CPaintDC dc(this);

	const COLORREF m_rgbWhite = RGB(255,255,255);

   // Create a memory DC to do the drawing to
   CDC dcOffScreen;
	dcOffScreen.CreateCompatibleDC(&dc);
   dcOffScreen.SetBkColor(m_rgbWhite);

   // Create a bitmap for the off-screen DC that is really
   // color compatible with the destination DC.
   CBitmap bmOffScreen;
   bmOffScreen.CreateBitmap(m_cs.cx, m_cs.cy, dc.GetDeviceCaps(PLANES), dc.GetDeviceCaps(BITSPIXEL), 0);

   // Select the buffer bitmap into the off-screen DC
   CBitmap* pbmOldOffScreen = dcOffScreen.SelectObject(&bmOffScreen);

	// The simple cases come here for a quick blt
	CDC dcMemory;
	VERIFY(dcMemory.CreateCompatibleDC(&dc));
	CBitmap* pbmpOldMemory = dcMemory.SelectObject(&m_Bitmap);
	ASSERT(pbmpOldMemory);
	VERIFY(dcOffScreen.BitBlt(0, 0, m_cs.cx, m_cs.cy, &dcMemory, 0, 0, SRCCOPY));
	VERIFY(dcMemory.SelectObject(pbmpOldMemory) == &m_Bitmap);

	int iRegions = m_FillRegions.GetSize();
	if (iRegions > 0)
	{

		for (int iRegion = 0; iRegion < iRegions; ++iRegion)
		{
			CIuFillRegion& Region = m_FillRegions.ElementAt(iRegion);

			ASSERT(CIuCdromPartitionDlg::FindStateInfo(Region.GetAbbr()));
			CIuStateInfo& StateInfo = *CIuCdromPartitionDlg::FindStateInfo(Region.GetAbbr());
			ASSERT(StateInfo.m_iRegion >= 0 && StateInfo.m_iRegion <= iMaxRegions + 2);

			COLORREF Color = aRegionColors[StateInfo.m_iRegion];

			CBrush Brush(Color);
			CBrush* pOldBrush = dcOffScreen.SelectObject(&Brush);

			int iPoints = Region.GetPointCount();
			for (int iPoint = 0; iPoint < iPoints; ++iPoint)
			{
				CPoint Point = Region.GetPoint(iPoint);
				dcOffScreen.FloodFill(Point.x, Point.y, RGB(0,0,0));
			}

			dcOffScreen.SelectObject(pOldBrush);
		}
	}

	VERIFY(dc.BitBlt(iWindowMargin, iWindowMargin, m_cs.cx, m_cs.cy, &dcOffScreen, 0, 0, SRCCOPY));
	CRect rect(iWindowMargin,iWindowMargin,m_cs.cx,m_cs.cy);
	rect.InflateRect(1,1,1,1);
	Draw3DInsetRect(dc, rect);

	dcOffScreen.SelectObject(pbmOldOffScreen);
}

void CIuCdromPartitionDlg::OnRclickStates(NMHDR*, LRESULT* pResult)
{
	*pResult = 0;

   DWORD pos = GetMessagePos();
   CPoint ptScreen(LOWORD(pos), HIWORD(pos));
   CPoint ptClient = ptScreen;
   m_listStates.ScreenToClient(&ptClient);

   // Get indexes of the first and last visible items in listview
   // control.
   int iIndex = m_listStates.GetTopIndex();
   int iLastVisibleIndex = iIndex + m_listStates.GetCountPerPage();
   if (iLastVisibleIndex > m_listStates.GetItemCount())
       iLastVisibleIndex = m_listStates.GetItemCount();

   // Loop until number visible items has been reached.
   while (iIndex <= iLastVisibleIndex)
   {
      // Get the bounding rectangle of an item. If the mouse
       // location is within the bounding rectangle of the item,
       // you know you have found the item that was being clicked.
       CRect rect;
       m_listStates.GetItemRect(iIndex, &rect, LVIR_BOUNDS);
       if (rect.PtInRect(ptClient))
       {
           break;
       }
       // Get the next item in listview control.
       iIndex++;
   }
   if (iIndex > iLastVisibleIndex)
		return ;

	if (iIndex < 0 || iIndex >= m_aStates.GetSize())
		return ;
	CIuStateInfo& State = m_aStates.ElementAt(iIndex);

	CIuContextMenu ContextMenu(IDR_ENGINE_CDROMPARTITION);
	UINT uiCommand = ContextMenu.Track(ptScreen, this);

	int iNewRegion = State.m_iRegion;
	switch (uiCommand)
	{
		case ID_ENGINE_REGION1:
			iNewRegion = 0;
			break;
		case ID_ENGINE_REGION2:
			iNewRegion = 1;
			break;
		case ID_ENGINE_REGION3:
			iNewRegion = 2;
			break;
		case ID_ENGINE_REGION4:
			iNewRegion = 3;
			break;
		case ID_ENGINE_REGION5:
			iNewRegion = 4;
			break;
		case ID_ENGINE_REGION6:
			iNewRegion = 5;
			break;
		case ID_ENGINE_REGION7:
			iNewRegion = 6;
			break;
		case ID_ENGINE_REGION8:
			iNewRegion = 7;
			break;
		case ID_ENGINE_REGION9:
			iNewRegion = 8;
			break;
		case ID_ENGINE_REGION10:
			iNewRegion = 9;
			break;
		case ID_ENGINE_REGION11:
			iNewRegion = 10;
			break;
		case ID_ENGINE_REGION12:
			iNewRegion = 11;
			break;
		default:
			return ;
	}
	if (iNewRegion == State.m_iRegion)
		return ;
	State.m_iRegion = iNewRegion;
	OnChange();
}

void CIuCdromPartitionDlg::OnSave() 
{
	CString sSaveFilename;
	if (!IuDataFilenameQuery(sSaveFilename, extCdromPartition, _T("Save Filename"), this))
		return ;

	CString sSave = Save();
	sSave.Replace("\r\n", "\n");
	CStdioFile SaveFile;
	if (SaveFile.Open(sSaveFilename, CFile::modeCreate|CFile::modeReadWrite))
	{
		SaveFile.WriteString(sSave);
		SaveFile.Close();
	}
}

CString CIuCdromPartitionDlg::Save()
{
	OnChange();
	CString sSave;
	for (int iRegion = 0; iRegion < m_aRegions.GetSize(); ++iRegion)
	{
		CIuRegionInfo& Region = m_aRegions.ElementAt(iRegion);
		if (Region.m_iRecords <= 0)
			continue;

		CString s;

		s.Format("%d", iRegion);
		sSave += s;
		sSave += "|";
		sSave += Region.m_szName;
		sSave += "|";

		CString sStates = "_T(\"";
		int iStatesFound = 0;
		for (int iState = 0; iState < m_aStates.GetSize(); ++iState)
		{
			CIuStateInfo& State = m_aStates.ElementAt(iState);
			if (State.m_iRegion != iRegion)
				continue;
			if (iStatesFound)
			{
				sSave += ",";
				sStates += "\\n";
			}
			sSave += State.m_szName;
			sStates += State.m_szName;
			++iStatesFound;
		}

		sSave += "|";

		sStates += "\"),";
		sSave += sStates;

		sSave += "\r\n";
	}
	return sSave;
}
