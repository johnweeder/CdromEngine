#ifndef _ENGINE_BOUGHT_H_
#define _ENGINE_BOUGHT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBought)
IU_DEFINE_OBJECT_PTR(CIuMeters)
IU_DEFINE_OBJECT_PTR(CIuMeter)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBought, CIuObject }}
#define CIuBought_super CIuObject

class CIuBought : public CIuBought_super
{
/////////////////////////////////////////////////////////////////////////////
// Simple bought status class which just tracks bought level internally

//{{Declare
	DECLARE_SERIAL(CIuBought)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBought();
	virtual ~CIuBought();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	int GetLevel(const CIuRecord& Record) const;
	int GetLevel(DWORD dwSource, DWORD dwRecordNo) const;
	int GetLevel(const UINT64& id2) const;
	CIuMeters& GetMeters() const;
	bool HasMeters() const;
	bool IsBought(const CIuRecord& Record) const;
	bool IsBought(const UINT64& id2) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Decrement(DWORD dwSrcNo, int iBuy);
	void RemoveAll();
	void SetCount(int iCount);
	bool SetLevel(const CIuRecord& Record, int iLevel = 1, bool fDecrement = true);
	bool SetLevel(DWORD dwSource, DWORD dwRecordNo, int iLevel, bool fDecrement = true);
	bool SetLevel(const UINT64& id, int iLevel = 1, bool fDecrement = true);
	void SetMeters(CIuMeters* Meters);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	CIuMeterPtr GetMeter(DWORD dwSrcNo) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// A list of meters from the engine
	CIuMeters* m_pMeters;
	// Bought count is maintained as a separated integer in order
	// to support derived classes which do not use the "m_bought" object.
	// NOTE: Bought records always stay bought, even if they are not currently
	//		part of this recordset.
	int m_iCount;
	// Mapping of src/rec no to bought count
	CMap<UINT64, const UINT64&, int, int> m_mapBought;
	// A mapping of src no to meters
	mutable CMap<DWORD, DWORD, CIuMeterPtr, CIuMeter*> m_mapMeter;
	// A caching mechanism to map meters to record sources
	mutable DWORD m_dwLastSrcNo;
	mutable CIuMeterPtr m_pLastMeter;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBought::GetLevel(const CIuRecord& Record) const
{
	return GetLevel(Record.GetSourceNo(), Record.GetRecordNo());
}

inline CIuMeters& CIuBought::GetMeters() const
{
	ASSERT(m_pMeters!=0);
	return *m_pMeters;
}

inline bool CIuBought::HasMeters() const
{
	return m_pMeters!=0;
}

inline bool CIuBought::IsBought(const CIuRecord& Record) const
{
	return GetLevel(Record.GetSourceNo(), Record.GetRecordNo()) != 0;
}

inline bool CIuBought::IsBought(const UINT64& id2) const
{
	return GetLevel(id2) != 0;
}

inline bool CIuBought::SetLevel(const CIuRecord& Record, int iLevel, bool fDecrement)
{
	return SetLevel(Record.GetSourceNo(), Record.GetRecordNo(), iLevel, fDecrement);
}

#endif // _ENGINE_BOUGHT_H_
