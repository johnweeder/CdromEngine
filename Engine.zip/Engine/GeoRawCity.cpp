#include "StdAfx.h"
//{{Include
#include "GeoRawCity.h"
#include "GeoRawInstance.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawCity, CIuGeoRawCity_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawCity)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWCITY, CIuGeoRawCity, CIuGeoRawCity_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawCity, IDS_ENGINE_PROP_MSA, GetMsa_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawCity, IDS_ENGINE_PROP_MSA, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawCity, IDS_ENGINE_PROP_ZIPS, GetZips_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawCity, IDS_ENGINE_PROP_ZIPS, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuGeoRawCity, IDS_ENGINE_PPG_GEORAWCITY, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawCity, IDS_ENGINE_PROP_CITY, GetCity, SetStringNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawCity, IDS_ENGINE_PROP_CITY, IDS_ENGINE_PPG_GEORAWCITY, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawCity, IDS_ENGINE_PROP_STATEABBR, GetStateAbbr, SetStringNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawCity, IDS_ENGINE_PROP_STATEABBR, IDS_ENGINE_PPG_GEORAWCITY, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawCity::CIuGeoRawCity() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoRawCity::~CIuGeoRawCity()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawCity::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput&)
{
	if (Instance.GetMsaCode() != 0)
		GetMsa().Add(Instance.GetMsaCode(), 4);
	GetZips().Add(Instance.GetZip());
	CIuGeoRawCity_super::Another();
}

CString CIuGeoRawCity::GetCity() const
{
	CString sName = GetName();
	int iLength = sName.GetLength();
	if (iLength > 2)
		return sName.Right(iLength - 2);
	return CString();
}

CIuObject* CIuGeoRawCity::GetMsa_() const
{
	return &m_Msa;
}

CString CIuGeoRawCity::GetStateAbbr() const
{
	CString sName = GetName();
	if (sName.GetLength() >= 2)
		return sName.Left(2);
	return CString();
}

CIuObject* CIuGeoRawCity::GetZips_() const
{
	return &m_Zips;
}

void CIuGeoRawCity::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
	GetMsa().Serialize(ar);
	GetZips().Serialize(ar);
	CIuGeoRawCity_super::Serialize(ar);
}

