#include "StdAfx.h"
//{{Include
#include "BlobSpecDft.h"
#include "Blob.h"
#include "IDs.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Blobernate specifications

static const CIuBlobSpecDft aBlob[] =
{
	{
		_T("104mLicense_2001"), blob104mLicense_2001,
		&idBlob_104mLicense_2001,
		_T("104mLicense.txt"),
	},{
		_T("88mdLicense_2001"), blob88mdLicense_2001,
		&idBlob_88mdLicense_2001,
		_T("88mdLicense.txt"),
	},{
		_T("BmlLicense_2000"), blobBmlLicense_2000,
		&idBlob_BmLicense_2000,
		_T("BmlLicense.txt"),
	},{
		_T("OamLicense_V1"), blobOamLicense_V1,
		&idBlob_OamLicense_V1,
		_T("OamLicense.txt"),
	},{
		_T("PbLicense_2001"), blobPbLicense_2001,
		&idBlob_PbLicense_2001,
		_T("PbLicense.txt"),
	},{
		_T("PbmLicense_V1"), blobPbmLicense_V1,
		&idBlob_PbmLicense_V1,
		_T("PbmLicense.txt"),
	},{
		_T("PfLicense_2001"), blobPfLicense_2001,
		&idBlob_PfLicense_2001,
		_T("PfLicense.txt"),
	},{
		_T("PgLicense_2000"), blobPgLicense_2000,
		&idBlob_PgLicense_2000,
		_T("PgLicense.txt"),
	},{
		_T("PuLicense_2001"), blobPuLicense_2001,
		&idBlob_PuLicense_2001,
		_T("PuLicense.txt"),
	},{
		_T("RbocLicense_2000"), blobRbocLicense_2000, 
		&idBlob_RbocLicense_2000,
		_T("RbocLicense.txt"),
	},{
		_T("SampleLicense"), blobSampleLicense, 
		&idBlob_SampleLicense,
		_T("SampleLicense.txt"),
	},{
		_T("SluLicense_2000"), blobSluLicense_2000,
		&idBlob_SluLicense_2000,
		_T("SluLicense.txt"),
	},{
		_T("YpuLicense_2001"), blobYpuLicense_2001,
		&idBlob_YpuLicense_2001,
		_T("YpuLicense.txt"),
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuBlobSpecDft

int CIuBlobSpecDft::Find(LPCTSTR pcszBlob)
{
	ASSERT(AfxIsValidString(pcszBlob));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszBlob, pcszBlob) == 0)
			return i;
	}
	return -1;
}

int CIuBlobSpecDft::Find(int iBlob)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iBlob == iBlob)
			return i;
	}
	return -1;
}

const CIuBlobSpecDft* CIuBlobSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aBlob + iWhich;
}

int CIuBlobSpecDft::GetCount()
{
	return sizeof(aBlob) / sizeof(aBlob[0]);
}
