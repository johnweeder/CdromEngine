#include "StdAfx.h"
//{{Include
#include "ReleaseNoteSpec.h"
#include "ReleaseNoteSpecDft.h"
#include "CdromSpec.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuReleaseNoteSpec, CIuReleaseNoteSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuReleaseNoteSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RELEASENOTESPEC, CIuReleaseNoteSpec, CIuReleaseNoteSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuReleaseNoteSpec, IDS_ENGINE_PPG_RELEASENOTESPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASENOTENO, GetReleaseNoteNo, SetReleaseNoteNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASENOTENO, IDS_ENGINE_PPG_RELEASENOTESPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_VERSION(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASECURRENT, GetReleaseCurrent, SetReleaseCurrent, 0)
	IU_ATTRIBUTE_EDITOR_VERSION(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASECURRENT, IDS_ENGINE_PPG_RELEASENOTESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_VERSION(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASEMIN, GetReleaseMin, SetReleaseMin, 0)
	IU_ATTRIBUTE_EDITOR_VERSION(CIuReleaseNoteSpec, IDS_ENGINE_PROP_RELEASEMIN, IDS_ENGINE_PPG_RELEASENOTESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuReleaseNoteSpec, IDS_ENGINE_PROP_NOTES, GetNotes, SetNotes, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuReleaseNoteSpec, IDS_ENGINE_PROP_NOTES, IDS_ENGINE_PPG_RELEASENOTESPEC, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuReleaseNoteSpec::CIuReleaseNoteSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReleaseNoteSpec::~CIuReleaseNoteSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuReleaseNoteSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_iReleaseNoteNo = 0;
	SetVersion(IU_VERSION);
	m_verReleaseCurrent = IU_VERSION;
	m_verReleaseMin = IU_VERSION_MIN;
	m_sNotes = "";
	//}}Initialize
}

void CIuReleaseNoteSpec::FromIndex(CIuCdromSpec* pCdrom, int iReleaseNoteSpec)
{
	ASSERT(iReleaseNoteSpec >= 0);

	const CIuReleaseNoteSpecDft* pReleaseNoteSpec = CIuReleaseNoteSpecDft::Get(iReleaseNoteSpec);
	ASSERT(pReleaseNoteSpec);

	FromSpec(pCdrom, pReleaseNoteSpec);
}

void CIuReleaseNoteSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszReleaseNote)
{
	FromIndex(pCdrom, CIuReleaseNoteSpecDft::Find(pcszReleaseNote));
}

void CIuReleaseNoteSpec::FromNo(CIuCdromSpec* pCdrom, int iReleaseNoteNo)
{
	FromIndex(pCdrom, CIuReleaseNoteSpecDft::Find(iReleaseNoteNo));
}

void CIuReleaseNoteSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuReleaseNoteSpecDft* pReleaseNoteSpec)
{
	SetCdrom(pCdrom);

	// Release notes are done by application (product), not by cd-rom.
	// They are always created with a consistent name prefix, but the id changes 
	// for each and every build. Because we don't want these objects de-duped away
	// by the repository, we create a fake name based on the original name and
	// the version number
	CIuID ID = CIuID::Create();
	CString sName = pReleaseNoteSpec->m_pcszReleaseNote;
	ASSERT(_tcschr(pReleaseNoteSpec->m_pcszReleaseNote, '.') == 0);
	sName += _T(".");
	sName += pReleaseNoteSpec->m_pcszReleaseCurrent;
	SetName(sName);
	SetID(ID);

	SetNotes(pReleaseNoteSpec->m_pcszNotes);
	SetReleaseCurrent(CIuVersionNumber(pReleaseNoteSpec->m_pcszReleaseCurrent));
	SetReleaseMin(CIuVersionNumber(pReleaseNoteSpec->m_pcszReleaseMin));

	SetReleaseNoteNo(pReleaseNoteSpec->m_iReleaseNote);
}

int CIuReleaseNoteSpec::GetCount()
{
	return CIuReleaseNoteSpecDft::GetCount();
}

void CIuReleaseNoteSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuReleaseNoteSpec::SetNotes(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sNotes = pcsz;
}

void CIuReleaseNoteSpec::SetReleaseCurrent(CIuVersionNumber ver)
{
	m_verReleaseCurrent = ver;
}

void CIuReleaseNoteSpec::SetReleaseMin(CIuVersionNumber ver)
{
	m_verReleaseMin = ver;
}

void CIuReleaseNoteSpec::SetReleaseNoteNo(int iReleaseNoteNo)
{
	m_iReleaseNoteNo = iReleaseNoteNo;
}
