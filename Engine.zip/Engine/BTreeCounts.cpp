#include "StdAfx.h"
//{{Include
#include "BTreeCounts.h"
#include "StatesRaw.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuBTreeCounts::CIuBTreeCounts(bool fHasBusRes)
{
	Clear();
	m_fHasBusRes = fHasBusRes;
}

CIuBTreeCounts::~CIuBTreeCounts()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeCounts::Add(bool fAlt, bool fResidence, LPCTSTR pcszStateCode, LPCTSTR pcszAcPhone)
{
	++m_iTotal;
	if (fAlt)
	{
		++m_iAlts;
		return ;
	}
	else if (fResidence)
		++m_iResidences;
	else
		++m_iBusinesses;
	if (pcszStateCode && *pcszStateCode)
	{
		int iStateCode = StringAsInt(pcszStateCode);
		iStateCode = max(0, iStateCode);
		iStateCode %= 100;
		++m_aiStates[fResidence ? 1: 0][iStateCode];
	}
	if (pcszAcPhone && *pcszAcPhone)
	{
		int iAreaCode = 0;
		for (int i = 0; i < 3; ++i, ++pcszAcPhone)
		{
			if (_istdigit(*pcszAcPhone))
				iAreaCode = iAreaCode * 10 + int(*pcszAcPhone - '0');
		}
		iAreaCode = max(0, iAreaCode);
		iAreaCode %= 1000;
		++m_aiAreaCode[fResidence ? 1: 0][iAreaCode];
	}
}

void CIuBTreeCounts::Clear()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fHasBusRes = false;
	m_iTotal = 0;
	m_iAlts = 0;
	m_iBusinesses = 0;
	m_iResidences = 0;
	memset(m_aiAreaCode, 0, sizeof(m_aiAreaCode));
	memset(m_aiStates, 0, sizeof(m_aiStates));
	//}}Initialize
}

CString CIuBTreeCounts::Output()
{
	// NOTE: Tab separators and space padding is used so that the output lines
	// up nice when viewed as text or when it is copy/pasted into Excel.
	CString sOutput;
	CString sTemp;

	sTemp.Format("%10ld total records\n", m_iTotal);
	sOutput += sTemp;
	sTemp.Format("%10ld alternate records\n", m_iAlts);
	sOutput += sTemp;
	if (m_fHasBusRes)
	{
		sTemp.Format("%10ld business records\n", m_iBusinesses);
		sOutput += sTemp;
		sTemp.Format("%10ld residential records\n", m_iResidences);
		sOutput += sTemp;
	}
	else
	{
		sTemp.Format("%10ld data records\n", m_iBusinesses + m_iResidences);
		sOutput += sTemp;
	}
	sOutput += _T("\n");

	bool fHeader = false;

	int iBusinesses = 0;
	int iResidences = 0;
	int iGrandTotal = 0;

	for (int i = 0; i < 100; ++i)
	{
		int iTotal = m_aiStates[0][i] + m_aiStates[1][i];
		iBusinesses += m_aiStates[0][i];
		iResidences += m_aiStates[1][i];
		iGrandTotal += iTotal;
		if (iTotal == 0)
			continue;

		if (!fHeader)
		{
			sOutput += _T("By State:\n");

			if (m_fHasBusRes)
				sTemp.Format(_T("\t ST\t%10.10s\t%10.10s\t%10.10s\n"), "Businesses", "Residences", "Total");
			else
				sTemp.Format(_T("\t ST\t%10.10s\t%10.10s\t%10.10s\n"), "", "", "Total");
			sOutput += sTemp;

			fHeader = true;
		}

		const CIuStatesRaw* pState = CIuStatesRaw::FindCode(i);
		LPCTSTR pcszState;
		if (pState != 0)
			pcszState = pState->m_pcszAbbr;
		else
			pcszState = "??";

		if (m_fHasBusRes)
			sTemp.Format("\t%3.3s\t%10ld\t%10ld\t%10ld\n", pcszState, m_aiStates[0][i], m_aiStates[1][i], iTotal);
		else
			sTemp.Format("\t%3.3s\t%10s\t%10s\t%10ld\n", pcszState, "", "", iTotal);

		sOutput += sTemp;
	}

	if (fHeader)
	{
		if (m_fHasBusRes)
			sTemp.Format("\t%3.3s\t%10ld\t%10ld\t%10ld\n", "", iBusinesses, iResidences, iGrandTotal);
		else
			sTemp.Format("\t%3.3s\t%10s\t%10s\t%10ld\n", "", "", "", iGrandTotal);
		sOutput += sTemp;
		sOutput += _T("\n");
	}

	fHeader = false;
	iBusinesses = 0;
	iResidences = 0;
	iGrandTotal = 0;

	for (i = 0; i < 1000; ++i)
	{
		int iTotal = m_aiAreaCode[0][i] + m_aiAreaCode[1][i];
		iBusinesses += m_aiAreaCode[0][i];
		iResidences += m_aiAreaCode[1][i];
		iGrandTotal += iTotal;
		if (iTotal == 0)
			continue;

		if (!fHeader)
		{
			sOutput += _T("By Area Code:\n");

			if (m_fHasBusRes)
				sTemp.Format(_T("\tA/C\t%10.10s\t%10.10s\t%10.10s\n"), "Businesses", "Residences", "Total");
			else
				sTemp.Format(_T("\tA/C\t%10.10s\t%10.10s\t%10.10s\n"), "", "", "Total");
			sOutput += sTemp;

			fHeader = true;
		}

		if (m_fHasBusRes)
			sTemp.Format("\t%03d\t%10ld\t%10ld\t%10ld\n", i, m_aiAreaCode[0][i], m_aiAreaCode[1][i], iTotal);
		else
			sTemp.Format("\t%03d\t%10s\t%10s\t%10ld\n", i, "", "", iTotal);
		sOutput += sTemp;
	}

	if (fHeader)
	{
		if (m_fHasBusRes)
			sTemp.Format("\t%3.3s\t%10ld\t%10ld\t%10ld\n", "", iBusinesses, iResidences, iGrandTotal);
		else
			sTemp.Format("\t%3.3s\t%10s\t%10s\t%10ld\n", "", "", "", iGrandTotal);
		sOutput += sTemp;
		sOutput += _T("\n");
	}

	return sOutput;
}
