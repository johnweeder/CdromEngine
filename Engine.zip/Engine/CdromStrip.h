#ifndef _ENGINE_CDROMSTRIP_H_
#define _ENGINE_CDROMSTRIP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdromStrip)
IU_DEFINE_OBJECT_PTR(CIuStrip)
IU_DEFINE_OBJECT_PTR(CIuRecordSort)
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Index Types
enum CIuCdromStripNo
{
	cdromStripNone = 0, // A terminator

	cdromStripAddress,
	cdromStripBusiness1,
	cdromStripBusiness6,
	cdromStripBusinessFranchise1,
	cdromStripBusinessFranchise6,
	cdromStripName,
	cdromStripPhone,
	cdromStripZip4,
	cdromStripZip5,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromStrip, CIuCollectable }}
#define CIuCdromStrip_super CIuCollectable

class CIuCdromStrip : public CIuCdromStrip_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromStrip)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromStrip();
	virtual ~CIuCdromStrip();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetFilename() const;
	CIuStrip& GetStrip() const;
	CIuRecordSort& GetSort() const;
	CIuRecordFile& GetRecords() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags);
	void Delete(CIuOutput* pOutput);
	void SetFilename(LPCTSTR);
	void SetSpec(CIuCdromStripSpec& CdromStripSpec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetRecords_() const;
	CIuObject* GetSort_() const;
	CIuObject* GetStrip_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuStripPtr m_pStrip;
	CIuRecordSortPtr m_pSort;
	CIuRecordFilePtr m_pRecords;
	CString m_sFilename;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuCdromStrip::GetFilename() const
{
	return m_sFilename;
}

inline CIuRecordFile& CIuCdromStrip::GetRecords() const
{
	return m_pRecords.Ref();
}

inline CIuRecordSort& CIuCdromStrip::GetSort() const
{
	return m_pSort.Ref();
}

inline CIuStrip& CIuCdromStrip::GetStrip() const
{
	return m_pStrip.Ref();
}

#endif // _ENGINE_CDROMSTRIP_H_
