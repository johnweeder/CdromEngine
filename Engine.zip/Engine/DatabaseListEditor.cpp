#include "StdAfx.h"
#include "DatabaseListEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CIuDatabaseListEditor::CIuDatabaseListEditor()
{
}

void CIuDatabaseListEditor::Initialize(UINT uiID, CWnd* pwndParent, CIuDatabaseList& DatabaseList)
{
	m_pDatabaseList = &DatabaseList;
	CIuDatabaseListEditor_super::Initialize(uiID, pwndParent, LBE_BUTTONS|LBE_TOOLTIPS|LBE_SHORTCUTS|LBE_DRAG|LBE_ADD|LBE_DELETE|LBE_AUTOEDIT|LBE_BROWSE);
	OnLoad();
}

bool CIuDatabaseListEditor::OnAdd(int iIndex, CString& sValue)
{
	m_pDatabaseList->Add("", iIndex);
	sValue = m_pDatabaseList->GetDatabaseName(iIndex);
	return true;
}

bool CIuDatabaseListEditor::OnBrowse(int iIndex, CString& s, DWORD&)
{
	if (!m_pDatabaseList->SelectDlg(iIndex, this))
		return false;
	s = m_pDatabaseList->GetDatabaseName(iIndex);
	return true;
}

bool CIuDatabaseListEditor::OnDelete(int iIndex)
{
	ASSERT(iIndex >= 0 && iIndex < m_pDatabaseList->GetDatabaseCount());
	m_pDatabaseList->Remove(iIndex);
	return true;
}

bool CIuDatabaseListEditor::OnDrag(int iDst, int iSrc)
{
	CIuID ID = m_pDatabaseList->GetDatabaseID(iSrc);
	m_pDatabaseList->Remove(iSrc);
	m_pDatabaseList->Add(ID.AsString(), iDst);
	return true;
}

void CIuDatabaseListEditor::OnLoad()
{
	CStringArray as;
	int iCount = m_pDatabaseList->GetDatabaseCount();
	for (int iItem = 0; iItem < iCount; ++iItem)
		as.Add(m_pDatabaseList->GetDatabaseName(iItem));

	Set(as);
}
