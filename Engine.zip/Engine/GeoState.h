#ifndef _ENGINE_GEOSTATE_H_
#define _ENGINE_GEOSTATE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENTCOLLECTION_H_
#	include "Engine\GeoElementCollection.h"
#endif	// _ENGINE_GEOELEMENTCOLLECTION_H_
#ifndef 	_ENGINE_STATE_H_
#	include "Engine\State.h"
#endif	// _ENGINE_STATE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoState)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoState, CIuGeoElementCollection }}
#define CIuGeoState_super CIuGeoElementCollection

class CIuGeoState : public CIuGeoState_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoState)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoState();
	virtual ~CIuGeoState();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	const CIuState& Get(int iElement) const;
	void GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const;
	LPCTSTR GetIndex() const;
	static LPCTSTR GetIndexStatic();
	virtual void GetRecordDef(CIuRecordDef&) const;
	virtual int GetSourceType() const;
	virtual void GetZipList(int iElement, CIuGeoList& GeoList) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual int OnCompressElement(CIuNybbleBuffer&, CIuGeoRaw&, CIuGeoRawElement&, CIuGeoRawElementCollection&, CIuOutput&);
	virtual int OnDeCompressElement(CIuNybbleBuffer&, int);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline const CIuState& CIuGeoState::Get(int iElement) const
{
	ASSERT(IsOpen());
	ASSERT(iElement >= 0 && iElement < m_aiOffsets.GetSize());
	int iOffset = m_aiOffsets[iElement];
	return *reinterpret_cast<const CIuState*>(m_Buffer.GetPtr(iOffset));
}

#endif // _ENGINE_GEOSTATE_H_
