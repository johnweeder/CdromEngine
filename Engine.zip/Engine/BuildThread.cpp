#include "StdAfx.h"
//{{Include
#include "BuildThread.h"
#include "Data\Command.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuBuildThread, CIuBuildThread_super)
//}}Implement

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBuildThread::OnEvent()
{
	CIuCommand* pCommand = dynamic_cast<CIuCommand*>(GetObject().Ptr());
	ASSERT(pCommand);
	pCommand->SetOutput(GetOutput());

	pCommand->Start();
}

CIuBuildThread* CIuBuildThread::Start(bool fPaused)
{
	return dynamic_cast<CIuBuildThread*>(CIuBuildThread_super::Start(RUNTIME_CLASS(CIuBuildThread), CIuID::Create(), fPaused));
}
