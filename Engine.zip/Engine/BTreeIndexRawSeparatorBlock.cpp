#include "StdAfx.h"
//{{Include
#include "BTreeIndexRawSeparatorBlock.h"
#include "BTreeIndexRawSeparator.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuBTreeIndexRawSeparatorBlock::CIuBTreeIndexRawSeparatorBlock() 
{
	ASSERT(sizeof(CIuBTreeIndexRawSeparator) == 10);
	ASSERT(sizeof(CIuBTreeIndexRawSeparatorBlockHeader) == 12);
	CommonConstruct();
}

CIuBTreeIndexRawSeparatorBlock::CIuBTreeIndexRawSeparatorBlock(const CIuBTreeIndexRawSeparatorBlock& rBlock)
{
	CommonConstruct();
	*this = rBlock;
}

CIuBTreeIndexRawSeparatorBlock::~CIuBTreeIndexRawSeparatorBlock()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeIndexRawSeparatorBlock::Append(const CIuBTreeIndexSeparator& separator)
{
	ASSERT(WillFit(separator));

	// Clear EOB flag on last entry
	if (m_iUsed > sizeof(CIuBTreeIndexRawSeparatorBlockHeader))
	{
		const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
		while (!pSeparator->IsEob())
			pSeparator = pSeparator->Next();
			
		const_cast<CIuBTreeIndexRawSeparator*>(pSeparator)->SetEob(false);
	}

	// Append new record
	BYTE* pb = m_block.GetPtr(m_iUsed);
	CIuBTreeIndexRawSeparator* pSeparator = reinterpret_cast<CIuBTreeIndexRawSeparator*>(pb);

	int iNeeded =	CIuBTreeIndexRawSeparator::GetSizeNeeded(separator.GetSeparatorSize());
	WORD wSize = WORD(iNeeded);
	ASSERT(wSize != 0xFFFF);
	pSeparator->SetSize(wSize);
	pSeparator->SetRecordNo(separator.GetRecordNo());
	pSeparator->SetPointerNo(separator.GetPointerNo());
	if (separator.IsContinuation())
		pSeparator->SetContinuation();
	memcpy(pSeparator->GetSeparatorPtr(), separator.GetSeparatorPtr(), separator.GetSeparatorSize());
	pSeparator->SetEob(true);

	SetPointerCount(GetPointerCount() + separator.GetPointerCount());
	SetRecordCount(GetRecordCount() + separator.GetRecordCount());

	m_iUsed += iNeeded;
}

void CIuBTreeIndexRawSeparatorBlock::Clear()
{
	ASSERT(m_iBlockSize > sizeof(CIuBTreeIndexRawSeparatorBlockHeader));
	m_block.Clear();
	m_iUsed = sizeof(CIuBTreeIndexRawSeparatorBlockHeader);
	GetHeader()->Clear();
}

void CIuBTreeIndexRawSeparatorBlock::CommonConstruct()
{
	ASSERT(CIuBTreeIndexRawSeparator::GetSizeNeeded(0) == 10);
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iBlockSize = 0;
	m_iUsed = 0;
	//}}Initialize
}

int CIuBTreeIndexRawSeparatorBlock::FindPointerNo(int iPointer) const
{
	ASSERT(iPointer >= 0);
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	ASSERT(iPointer >= 0 && iPointer < pSeparator->GetPointerNo() + GetPointerCount());
	// If only one block present, exit here
	if (pSeparator->IsEob())
		return 0;
	pSeparator = pSeparator->Next();
	for (int i = 0; ; ++i)
	{
		int iSeparatorPointer = pSeparator->GetPointerNo();
		if (iPointer < iSeparatorPointer)
			return i;
		if (pSeparator->IsEob())
			break;
		pSeparator = pSeparator->Next();
	}
	// Pointer is in last block
	return i + 1;
}

int CIuBTreeIndexRawSeparatorBlock::FindRecordNo(int iRecord) const
{
	ASSERT(iRecord >= 0);
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	ASSERT(iRecord >= 0 && iRecord < pSeparator->GetRecordNo() + GetRecordCount());
	// If only one block present, exit here
	if (pSeparator->IsEob())
		return 0;
	pSeparator = pSeparator->Next();
	for (int i = 0; ; ++i)
	{
		int iSeparatorRecord = pSeparator->GetRecordNo();
		if (iRecord < iSeparatorRecord)
			return i;
		if (pSeparator->IsEob())
			break;
		pSeparator = pSeparator->Next();
	}
	// Record is in last block
	return i + 1;
}

int CIuBTreeIndexRawSeparatorBlock::FindSeparator(const CIuKey& key) const
{
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	for (int i = 0; ; ++i)
	{
		int iResult = pSeparator->Compare(key);
		if (iResult == 0)
		{
			if (pSeparator->IsContinuation())
				return i - 1;
			else
				return i;
		}
		else if (iResult > 0)
		{
			ASSERT(i != 0);			
			return i - 1;
		}
		if (pSeparator->IsEob())
			break;
		pSeparator = pSeparator->Next();
	}
	// Separator is in last block
	return i;
}

void CIuBTreeIndexRawSeparatorBlock::Get(int iIndex, CIuBTreeIndexSeparator& separator) const
{
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	ASSERT(iIndex >= 0);
	for (; iIndex > 0; --iIndex)
	{
		if (pSeparator->IsEob())
		{
			ASSERT(false);
			separator.Clear();
			return ;
		}
		pSeparator = pSeparator->Next();
	}

	pSeparator->Get(separator);

	// Calculate record and pointer counts for this block...
	if (pSeparator->IsEob())
	{
		const CIuBTreeIndexRawSeparator* pSeparatorFirst = GetFirstSeparator();

		int iPointerCount = pSeparatorFirst->GetPointerNo() + GetPointerCount();
		separator.SetPointerCount(iPointerCount - separator.GetPointerNo());

		int iRecordCount = pSeparatorFirst->GetRecordNo() + GetRecordCount();
		separator.SetRecordCount(iRecordCount - separator.GetRecordNo());
	}
	else
	{
		pSeparator = pSeparator->Next();

		separator.SetPointerCount(pSeparator->GetPointerNo() - separator.GetPointerNo());
		separator.SetRecordCount(pSeparator->GetRecordNo() - separator.GetRecordNo());
	}
}

int CIuBTreeIndexRawSeparatorBlock::GetBlockSize() const
{
	return m_iBlockSize;
}

const BYTE* CIuBTreeIndexRawSeparatorBlock::GetData() const
{
	ASSERT(m_block.GetSize() == GetBlockSize());
	BYTE* pb = const_cast<CIuBTreeIndexRawSeparatorBlock*>(this)->m_block.GetPtr(m_iUsed);
	int iRemaining = GetBlockSize() - m_iUsed;
	if (iRemaining > 0)
		memset(pb, 0xFF, iRemaining);
	return m_block;
}

BYTE* CIuBTreeIndexRawSeparatorBlock::GetData()
{
	ASSERT(m_block.GetSize() == GetBlockSize());
	return m_block;
}

const CIuBTreeIndexRawSeparator* CIuBTreeIndexRawSeparatorBlock::GetFirstSeparator() const
{
	const BYTE* pb = m_block.GetPtr(sizeof(CIuBTreeIndexRawSeparatorBlockHeader));
	const CIuBTreeIndexRawSeparator* pSeparator = reinterpret_cast<const CIuBTreeIndexRawSeparator*>(pb);
	return pSeparator;
}

CIuBTreeIndexRawSeparatorBlockHeader* CIuBTreeIndexRawSeparatorBlock::GetHeader() const
{
	CIuBTreeIndexRawSeparatorBlockHeader* pHeader = const_cast<CIuBTreeIndexRawSeparatorBlockHeader*>(reinterpret_cast<const CIuBTreeIndexRawSeparatorBlockHeader*>(m_block.GetPtr()));
	return pHeader;
}

int CIuBTreeIndexRawSeparatorBlock::GetPointerCount() const
{
	return GetHeader()->m_iPointerCount;
}

int CIuBTreeIndexRawSeparatorBlock::GetRecordCount() const
{
	return GetHeader()->m_iRecordCount;
}

const CIuBTreeIndexRawSeparator* CIuBTreeIndexRawSeparatorBlock::GetSeparator(int iSeparator) const
{
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	ASSERT(pSeparator);
	for (; iSeparator > 0; --iSeparator)
	{
		ASSERT(!pSeparator->IsEob());
		pSeparator = pSeparator->Next();
	}
	return pSeparator;
}

int CIuBTreeIndexRawSeparatorBlock::GetSeparatorCount() const
{
	const CIuBTreeIndexRawSeparator* pSeparator = GetFirstSeparator();
	for (int i = 0; !pSeparator->IsEob(); ++i)
		pSeparator = pSeparator->Next();
	return i + 1;
}

int CIuBTreeIndexRawSeparatorBlock::GetSeparatorNo() const
{
	return GetHeader()->m_iSeparatorNo;
}

void CIuBTreeIndexRawSeparatorBlock::GrowBlockSize(int iBlockSize)
{
	ASSERT(iBlockSize > m_iBlockSize);
	m_block.SetSize(iBlockSize);
	m_block.Clear(0, m_iBlockSize);
	m_iBlockSize = iBlockSize;
}

CIuBTreeIndexRawSeparatorBlock& CIuBTreeIndexRawSeparatorBlock::operator=(const CIuBTreeIndexRawSeparatorBlock& rBlock)
{
	if (this == &rBlock)
		return *this;
	m_block = rBlock.m_block;
	m_iBlockSize = rBlock.m_iBlockSize;
	m_iUsed = rBlock.m_iUsed;
	return *this;
}

void CIuBTreeIndexRawSeparatorBlock::SetBlockSize(int iBlockSize)
{
	ASSERT(iBlockSize > 0);
	m_iBlockSize = iBlockSize;
	m_block.SetSize(iBlockSize);
	Clear();
}

void CIuBTreeIndexRawSeparatorBlock::SetPointerCount(int iPointerCount)
{
	GetHeader()->m_iPointerCount = iPointerCount;
}

void CIuBTreeIndexRawSeparatorBlock::SetRecordCount(int iRecordCount)
{
	GetHeader()->m_iRecordCount = iRecordCount;
}

void CIuBTreeIndexRawSeparatorBlock::SetSeparatorNo(int iSeparatorNo)
{
	GetHeader()->m_iSeparatorNo = iSeparatorNo;
}

bool CIuBTreeIndexRawSeparatorBlock::WillFit(const CIuBTreeIndexSeparator& separator)
{
	int iSizeNeeded =	CIuBTreeIndexRawSeparator::GetSizeNeeded(separator.GetSeparatorSize());
	ASSERT(GetBlockSize() - m_iUsed >= 0);
	return iSizeNeeded <= GetBlockSize() - m_iUsed;
}
