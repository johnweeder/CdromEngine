#include "StdAfx.h"
//{{Include
#include "ExpressionPhonetic.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionPhonetic::CIuExpressionPhonetic() : CIuExpressionElement(exprSoundsLike)
{
	SetFormat(exprFormatBool);
	CommonConstruct();
}

CIuExpressionPhonetic::CIuExpressionPhonetic(const CIuExpressionPhonetic& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionPhonetic::~CIuExpressionPhonetic()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionPhonetic::Clone() const
{
	CIuExpressionPhonetic* pElement = new CIuExpressionPhonetic(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionPhonetic::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

bool CIuExpressionPhonetic::EvaluateBool(const CIuRecord*) const
{
#pragma __TODO("John Weeder: Phonetic Evaluation")
	return false;
}

int CIuExpressionPhonetic::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionPhonetic::GetMaxLength() const
{
	// Always returns boolean "0" or "1"
	return BooiMaxLength();
}

LPCTSTR CIuExpressionPhonetic::GetTypeName() const
{
	switch (GetType())
	{
		case exprStringLiteral:
			return "SOUNDSLIKE";
	}
	return CIuExpressionPhonetic_super::GetTypeName();
}

CIuExpressionPhonetic& CIuExpressionPhonetic::operator=(const CIuExpressionPhonetic& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionPhonetic_super::operator=(rExpressionElement);
	return *this;
}
