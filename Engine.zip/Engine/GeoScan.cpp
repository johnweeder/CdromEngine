#include "StdAfx.h"
//{{Include
#include "GeoScan.h"
#include "RecordFile.h"
#include "GeoRaw.h"
#include "GeoSpec.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Interop\Conversions.h"
#include "GeoRawMsa.h"
#include "GeoRawCounty.h"
#include "GeoRawZip.h"
#include "GeoRawAreaCode.h"
#include "GeoRawExchange.h"
#include "CdromSpecConst.h"
#include "..\Version.h"
#include "Input.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoScan, CIuGeoScan_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoScan)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOSCAN, CIuGeoScan, CIuGeoScan_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuGeoScan, IDS_ENGINE_PPG_GEOSCAN, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoScan, IDS_ENGINE_PROP_RAW, GetRaw_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuGeoScan, IDS_ENGINE_PROP_RAW, IDS_ENGINE_PPG_GEOSCAN, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuGeoScan, IDS_ENGINE_PROP_APPEND, ShouldAppend, SetAppend, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuGeoScan, IDS_ENGINE_PROP_APPEND, IDS_ENGINE_PPG_GEOSCAN, 0)

	IU_ATTRIBUTE_PAGE(CIuGeoScan, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 51, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoScan, IDS_ENGINE_PROP_MSAFILENAME, GetMsaFilename, SetMsaFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuGeoScan, IDS_ENGINE_PROP_MSAFILENAME, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoScan, IDS_ENGINE_PROP_COUNTYFILENAME, GetCountyFilename, SetCountyFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuGeoScan, IDS_ENGINE_PROP_COUNTYFILENAME, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoScan, IDS_ENGINE_PROP_CENSUSFILENAME, GetCensusFilename, SetCensusFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuGeoScan, IDS_ENGINE_PROP_CENSUSFILENAME, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoScan, IDS_ENGINE_PROP_AREACODEFILENAME, GetAreaCodeFilename, SetAreaCodeFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuGeoScan, IDS_ENGINE_PROP_AREACODEFILENAME, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoScan, IDS_ENGINE_PROP_EXCHANGEFILENAME, GetExchangeFilename, SetExchangeFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuGeoScan, IDS_ENGINE_PROP_EXCHANGEFILENAME, IDS_ENGINE_PPG_GEOSCAN_UPDATE, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoScan::CIuGeoScan() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoScan::~CIuGeoScan()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoScan::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pRaw.IsNull())
	{
		m_pRaw.Create();
	}
	SetName("GeoScan");
	m_sMsaFilename = "msa";
	m_sCountyFilename = "county";
	m_sCensusFilename = "census";
	m_sAreaCodeFilename = "areacode";
	m_sExchangeFilename = "exchange";
	m_fAppend = false;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuGeoScan::Delete(CIuOutput* pOutput)
{
	GetRaw().Delete(pOutput);
}

CIuObject* CIuGeoScan::GetRaw_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRaw.Ptr()));
}

void CIuGeoScan::OnClose(CIuOutput& Output)
{
	CIuGeoScan_super::OnClose(Output);

	UpdateAreaCode(Output);
	UpdateExchange(Output);
	UpdateCensus(Output);
	UpdateCounty(Output);
	UpdateMsa(Output);

	Output.SetMessage("Writing raw geographies");
	Output.Fire();
	GetRaw().Write();

	// Having completed the scan and written the output, we now clear the
	// output. Otherwise, the output will be a huge drag on memory resources.
	Output.SetMessage("Clearing raw geographies");
	Output.Fire();
	GetRaw().Empty();
}

bool CIuGeoScan::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuGeoScan_super::OnOpen(OpenSpec))
		return false;

	if (ShouldAppend())
		GetRaw().Read();
	else
		GetRaw().Empty();

	CIuResolveSpec Spec = OpenSpec;
	Spec.m_pRecordDefSrc = &GetInput().GetRecordDef();
	GetRaw().Resolve(Spec);

	ASSERT(OpenSpec.m_pOutput);
	GetRaw().ReadZipCentroid(*OpenSpec.m_pOutput);
	OpenSpec.m_pOutput->SetMessageF("Geography Scan");
	return OpenSpec.m_pOutput->Fire();
}

bool CIuGeoScan::OnProcess(const CIuRecord& Record, CIuOutput& Output)
{
	GetRaw().Process(Record, Output);
	return true;
}

void CIuGeoScan::SetAppend(bool f)
{
	m_fAppend = f;
}

void CIuGeoScan::SetAreaCodeFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sAreaCodeFilename = pcsz;
}

void CIuGeoScan::SetCensusFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCensusFilename = pcsz;
}

void CIuGeoScan::SetCountyFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCountyFilename = pcsz;
}

void CIuGeoScan::SetExchangeFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExchangeFilename = pcsz;
}

void CIuGeoScan::SetMsaFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMsaFilename = pcsz;
}

void CIuGeoScan::SetSpec(CIuGeoSpec& Spec)
{
	CIuGeoScan_super::SetSpec(Spec.GetCdrom());
	GetRaw().SetSpec(Spec);
}

void CIuGeoScan::UpdateAreaCode(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	CIuGeoRawElementCollection& AreaCodes = GetRaw().GetAreaCode();

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetAreaCodeFilename());
	if (!Iterator.Open(Output))
		return ;

	// Process the records in the file
	Output.SetMessageF("Updating AreaCode's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszAreaCode = pRecord->GetField(inputAreaCodeAreaCode);

		CIuGeoRawAreaCode* pAreaCode = dynamic_cast<CIuGeoRawAreaCode*>(AreaCodes.Find(pcszAreaCode));
		if (pAreaCode)
		{
			LPCTSTR pcszAreaCodeName = pRecord->GetField(inputAreaCodeAreaCodeName);
			pAreaCode->SetTitle(pcszAreaCodeName);
		}
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}

void CIuGeoScan::UpdateCensus(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	CIuGeoRawElementCollection& Zips = GetRaw().GetZip();

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetCensusFilename());
	if (!Iterator.Open(Output))
		return ;

	// Process the records in the file
	Output.SetMessageF("Updating Census's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszZIP = pRecord->GetField(inputCensusZIP);
		CIuGeoRawZip* pZip = dynamic_cast<CIuGeoRawZip*>(Zips.Find(pcszZIP));
		if (pZip)
		{
			LPCTSTR pcszMedianIncome = pRecord->GetField(inputCensusMedianIncome);
			pZip->SetMedianIncome(StringAsInt(pcszMedianIncome));
			LPCTSTR pcszMedianHomeValue = pRecord->GetField(inputCensusMedianHomeValue);
			pZip->SetMedianHomeValue(StringAsInt(pcszMedianHomeValue));
		}
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}

void CIuGeoScan::UpdateCounty(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	CIuGeoRawElementCollection& Countys = GetRaw().GetCounty();

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetCountyFilename());
	if (!Iterator.Open(Output))
		return ;

	// Process the records in the file
	Output.SetMessageF("Updating County's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszCountyCode = pRecord->GetField(inputCountyCountyCode);

		CIuGeoRawCounty* pCounty = dynamic_cast<CIuGeoRawCounty*>(Countys.Find(pcszCountyCode));
		if (pCounty)
		{
			LPCTSTR pcszCountyName = pRecord->GetField(inputCountyCountyName);
			pCounty->SetTitle(pcszCountyName);
		}
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}

void CIuGeoScan::UpdateExchange(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	CIuGeoRawElementCollection& Exchanges = GetRaw().GetExchange();

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetExchangeFilename());
	if (!Iterator.Open(Output))
		return ;

	// Process the records in the file
	Output.SetMessageF("Updating Exchange's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszExchange = pRecord->GetField(inputExchangeExchange);

		CIuGeoRawExchange* pExchange = dynamic_cast<CIuGeoRawExchange*>(Exchanges.Find(pcszExchange));
		if (pExchange)
		{
			LPCTSTR pcszExchangeName = pRecord->GetField(inputExchangeExchangeName);
			pExchange->SetTitle(pcszExchangeName);
		}
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}

void CIuGeoScan::UpdateMsa(CIuOutput& Output)
{
	// Save output state
	CIuOutputStateInstance instance(Output);

	CIuGeoRawElementCollection& Msas = GetRaw().GetMsa();

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename(GetMsaFilename());
	if (!Iterator.Open(Output))
		return ;

	// Process the records in the file
	Output.SetMessageF("Updating MSA's\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		LPCTSTR pcszMsaCode = pRecord->GetField(inputMsaMsaCode);

		CIuGeoRawMsa* pMsa = dynamic_cast<CIuGeoRawMsa*>(Msas.Find(pcszMsaCode));
		if (pMsa)
		{
			LPCTSTR pcszMsaName = pRecord->GetField(inputMsaMsaName);
			pMsa->SetTitle(pcszMsaName);
		}
	}
	Iterator.Close(Output);

	// Display elapsed time
	instance.Pop(true);
}
