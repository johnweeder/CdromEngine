#include "StdAfx.h"
//{{Include
#include "InputToken.h"
#include "resource.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputToken, CIuInputToken_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputToken)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTTOKEN, CIuInputToken, CIuInputToken_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputToken, IDS_ENGINE_PPG_INPUTTOKEN, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputToken::CIuInputToken() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputToken::~CIuInputToken()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputToken::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input Token"));
	SetInputFilename("Token");
	SetOutputFilename("Token");
	SetFormat(inputToken);
	//}}Initialize
}

bool CIuInputToken::OnProcess()
{
	int iFields = GetInputs();
	if (iFields < 2)
		return true;
	LPCTSTR pcszToken = GetInput(0);
	m_asSeeAlso.RemoveAll();
	for (int iField = 1; iField < iFields; ++iField)
	{
		LPCTSTR pcszSeeAlso = GetInput(iField);
		if (*pcszSeeAlso == '\0')
			continue;
		m_asSeeAlso.Add(pcszSeeAlso);
	}
	StringArrayAsString(m_sSeeAlso, m_asSeeAlso, '\n');
	SetField(inputFieldToken, pcszToken);
	SetField(inputFieldSeeAlso, m_sSeeAlso);
	return Output();
}
