#include "stdafx.h"
#include "Engine.h"
#include "MeterAdministratorDlg.h"
#include "MeterCodesDlg.h"
#include "MeterTestDlg.h"
#include "Interop\Conversions.h"
#include "Ui\AboutInfo.h"
#include "Common\QueryResponseSession.h"
#include "Common\QueryResponseCode.h"
#include "Ui\ViewFileDlg.h"
#include "Data\SearchWhereDlg.h"
#include "Engine.h"
#include "Common\Clipboard.h"
#include "MeterSelectPhoneAdminDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDM_METER_ABOUT 0x0110
#define IDM_METER_TEST	0x0120

CIuMeterAdministratorDlg::CIuMeterAdministratorDlg(CWnd* pParent /*=NULL*/) : CIuMeterAdministratorDlg_super(CIuMeterAdministratorDlg::IDD, pParent)
{

	//{{Initialize
	m_pMeters = 0;
	//}}Initialize													 
																			   
	//{{AFX_DATA_INIT(CIuMeterAdministratorDlg)
	m_sUserCode = _T("");
	m_sCount = _T("");
	m_sResponse = _T("");
	m_sCurrent = _T("");
	m_sNotes = _T("");
	m_sResponseCheckSum = _T("");
	//}}AFX_DATA_INIT
	m_pMeters = NULL;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_ENGINE_ICON);
}

void CIuMeterAdministratorDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterAdministratorDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterAdministratorDlg)
	DDX_Control(pDX, IDC_ENGINE_TEST_METER, m_btnTestMeter);
	DDX_Control(pDX, IDC_ENGINE_SPECIAL, m_btnSpecial);
	DDX_Control(pDX, IDC_ENGINE_RESPONSE_CODE_CHECKSUM, m_editResponseCheckSum);
	DDX_Control(pDX, IDC_ENGINE_RESPONSE_CODE, m_editResponse);
	DDX_Control(pDX, IDC_ENGINE_RESET_METER, m_btnResetMeter);
	DDX_Control(pDX, IDC_ENGINE_METER_LIST, m_cbMeters);
	DDX_Control(pDX, IDC_ENGINE_CUSTOMER_CODE, m_editUserCode);
	DDX_Text(pDX, IDC_ENGINE_CUSTOMER_CODE, m_sUserCode);
	DDX_Text(pDX, IDC_ENGINE_NUMBER_REQUESTED, m_sCount);
	DDX_Text(pDX, IDC_ENGINE_RESPONSE_CODE, m_sResponse);			 
	DDX_Text(pDX, IDC_ENGINE_CURRENT, m_sCurrent);
	DDX_Text(pDX, IDC_ENGINE_NOTES, m_sNotes);
	DDX_Text(pDX, IDC_ENGINE_RESPONSE_CODE_CHECKSUM, m_sResponseCheckSum);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIuMeterAdministratorDlg, CIuMeterAdministratorDlg_super)
	//{{AFX_MSG_MAP(CIuMeterAdministratorDlg)
	ON_EN_CHANGE(IDC_ENGINE_CUSTOMER_CODE, OnChange)
	ON_BN_CLICKED(IDC_ENGINE_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_ENGINE_REFRESH, OnRefresh)
	ON_BN_CLICKED(IDC_ENGINE_RESET_METER, OnResetMeter)
	ON_WM_QUERYDRAGICON()
	ON_WM_PAINT()
	ON_WM_SYSCOMMAND()
	ON_BN_CLICKED(IDC_ENGINE_SPECIAL, OnSpecial)
	ON_BN_CLICKED(IDC_ENGINE_SELECTPHONE, OnSelectPhone)
	ON_BN_CLICKED(IDC_ENGINE_TEST_METER, OnTestMeter)
	ON_CBN_SELCHANGE(IDC_ENGINE_METER_LIST, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuMeterAdministratorDlg::DoDialog(CIuMeters& Meters, CWnd* pParent, CIuID idMeter, LPCTSTR pcszQueryCode, CString* pResponseCode)
{
	if ((Meters.GetUserRights() & engineRightsInternal) == 0)
	{
		Meters.GetEngine().ShowUserRightsException();
		return false;
	}
	CIuMeterAdministratorDlg Dlg(pParent);
	Dlg.m_idMeter = idMeter;
	if (pcszQueryCode)
		Dlg.m_sUserCode = pcszQueryCode;
	Dlg.SetMeters(&Meters);
	if (Dlg.DoModal() != IDOK)
		return false;
	if (pResponseCode)
	{
		if (!Dlg.m_sResponse.IsEmpty())
			*pResponseCode = Dlg.m_sResponse;
		else
			*pResponseCode = "";
	}
	return true;
}

void CIuMeterAdministratorDlg::OnChange()
{													 
	static const TCHAR szUnauthorized[] = _T("Unauthorized request");

	UpdateData();

	m_sNotes.Empty();
	m_sResponse.Empty();
	m_sResponseCheckSum.Empty();
	m_sCount.Empty();
	m_sCurrent.Empty();

	int iSel = m_cbMeters.GetCurSel();
	if (iSel == CB_ERR)
	{
		m_editUserCode.EnableWindow(false);
		m_sNotes = _T("Please select a meter from the drop-down list.\r\n");
		UpdateData(false);
		return ;
	}

	UpdateData(false);

	m_editUserCode.EnableWindow(true);
	
	CIuID id(int(m_cbMeters.GetItemData(iSel)));

	int iMeter = m_pMeters->Find(id);
	ASSERT(iMeter >= 0);

	CIuMeter& Meter = m_pMeters->Get(iMeter);

	if (Meter.IsCorrupt())
		m_sNotes += _T("*** WARNING! Your local meter has been corrupted! ***\r\n\r\n");

	CString sKey = Meter.GetKey();
	CIuQueryResponseSession Session(sKey);

	if (!m_sUserCode.IsEmpty())
	{
		if (Session.HasCheckSum(m_sUserCode) && !Session.IsValidCheckSum(m_sUserCode))
		{
			m_sNotes += _T("User code has an invalid check sum. An invalid code was given. Validate the code with the user.\r\n");
			UpdateData(false);
			return ;
		}

		if (!Session.IsValid(m_sUserCode))
		{
			m_sNotes += _T("Invalid user code. The code is not the correct format or has the wrong number of characters.\r\n");
			UpdateData(false);
			return ;
		}
		if (!Session.IsValidQuery(m_sUserCode))
		{
			m_sNotes += _T("Invalid user code. The code may be for a different product, or the code may be incorrect.\r\n");
			m_sNotes += _T("If the customer is inquiring about a SelectPhone product, please press the 'SelectPhone' button.\r\n");
			UpdateData(false);
			return ;
		}

		if (Session.IsSuper0(m_sUserCode))
		{
			m_sNotes += _T("The user has given the super secret code.\r\n");
			UpdateData(false);
			return ;
		}
	}
	else
	{
		UpdateData(false);
		return ;
	}

	UINT uiUserValue;
	VERIFY(Session.GetUserValue(m_sUserCode, uiUserValue));
	CString sResponse = Session.GetResponse(m_sUserCode);
	if (uiUserValue == meterMagicNetworkEnable_MultiUser)
	{
		m_sCount = _T("Multi-User Network Access Enable");
		m_sNotes += _T("The user is requesting multi user network access to a product.\r\n");
		if ((GetMeters().GetUserRights() & engineRightsMultiUserLicense) == 0)
		{
			m_sNotes += _T("You are not authorized to respond to this code.\r\nPlease contact your supervisor.\r\n");
			sResponse = szUnauthorized;
		}
	}
	else if (uiUserValue == meterMagicNetworkEnable_SingleUser)
	{
		m_sCount = _T("Single-User Network Access Enable");
		m_sNotes += _T("The user is requesting single user network access to a product.\r\n");
	}
	else if (uiUserValue == meterMagicAccessCodeEnable_MultiUser)
	{
		m_sCount = _T("Multi-User Product Access Enable");
		m_sNotes += _T("The user is requesting multi user access to a product.\r\n");
		if ((GetMeters().GetUserRights() & engineRightsMultiUserLicense) == 0)
		{
			m_sNotes += _T("You are not authorized to respond to this code.\r\nPlease contact your supervisor.\r\n");
			sResponse = szUnauthorized;
		}
	}
	else if (uiUserValue == meterMagicAccessCodeEnable_SingleUser)
	{
		m_sCount = _T("Single-User Product Access Enable");
		m_sNotes += _T("The user is requesting single user access to a product.\r\n");
	}
	else if (uiUserValue == meterMagicMeterCorrupt)
	{
		m_sCount = _T("Meter Corrupt!");
		m_sNotes += _T("The user's meter is corrupt. Giving him this code will reset his meter.\r\n")
						_T("You can then proceed with the normal code.\r\n");
	}
	else if (uiUserValue == meterMagicRev0)
	{
		m_sCount = _T("Revision 0");
		m_sNotes += _T("The user is requesting his meter be reset to revision level 0\r\n")
						_T("This will change licensing and metering by resetting the meter to the level defined in revision 0.\r\n");
	}
	else if ((uiUserValue & 0xFFFF0000) == meterMagicMeterReset)
	{
		m_sCount = _T("Meter Reset!");
		m_sNotes += _T("The user may be requesting a reset of their meter.\r\n"); 
		m_sNotes += _T("If they are using the Power Check Utility, they will need to press the 'Ctrl', 'Alt', and 'Z' keys simultaneously, enter the code below, and press the 'RESET' button.\r\n");
		m_sNotes += _T("The current meter count is shown.\r\n");
		DWORD dwCurrent = (uiUserValue & 0x0000FFFF);
		Int32AsString(m_sCurrent, dwCurrent);
		if (dwCurrent >= meterMagicMeterCurrentMax)
			m_sCurrent += _T("+");
	}
	else if (uiUserValue == meterMagicExpireOverRide)
	{
		m_sCount = _T("30 Day Meter Over-Ride");
		m_sNotes += _T("The user's meter has expired. This code will grant a 30-day grace period.\r\n");
	}
	else
	{
		// This is the standard meter profile update.
		// Get high word, this is the current count
		DWORD dwRequested = (uiUserValue & 0x0000FFFF);
		ASSERT(dwRequested < meterMagicMeterUpdateMax);
		Int32AsString(m_sCount, dwRequested);
		DWORD dwCurrent = ((uiUserValue & 0xFFFF0000) >> 16);
		if (dwCurrent <= meterMagicMeterCurrentMax)
		{
			Int32AsString(m_sCurrent, dwCurrent);
			if (dwCurrent == meterMagicMeterCurrentMax)
				m_sCurrent += _T("+");
			m_sNotes += _T("The user is requesting a record profile purchase.\r\n");
		}
		else
		{
			m_sNotes += _T("Internal error. The user code contained an invalid request amount.\r\n");
			UpdateData(false);
			return ;
		}
	}

	if (CIuQueryResponseCode::IsValid(sResponse))
	{
		m_sResponse = CIuQueryResponseCode::Reformat(sResponse, queryFormatCode);
		m_sResponseCheckSum = CIuQueryResponseCode::Reformat(sResponse, queryFormatCheckSum);
	}
	else
		m_sResponse = sResponse;

	UpdateData(false);
}

BOOL CIuMeterAdministratorDlg::OnInitDialog() 
{
	SetIcon(m_hIcon, true);			// Set big icon
	SetIcon(m_hIcon, false);		// Set small icon

	CIuMeterAdministratorDlg_super::OnInitDialog();
	

	CMenu* pSysMenu = GetSystemMenu(false);
	if (pSysMenu != NULL)
	{
		if ((GetMeters().GetUserRights() & (engineRightsTest|engineRightsSuper)) != 0)
		{
			ASSERT((IDM_METER_TEST & 0xFFF0) == IDM_METER_TEST);
			ASSERT(IDM_METER_TEST < 0xF000);
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_METER_TEST, _T("Test..."));
		}


		ASSERT((IDM_METER_ABOUT & 0xFFF0) == IDM_METER_ABOUT);
		ASSERT(IDM_METER_ABOUT < 0xF000);
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_METER_ABOUT, _T("About..."));
	}

	OnRefresh();

	CFont* pFont = m_editUserCode.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);
	m_editUserCode.SetFont(&m_fontLarge);
	m_editResponse.SetFont(&m_fontLarge);
	m_editResponseCheckSum.SetFont(&m_fontLarge);

	// Allow anyone to clear their meter...
	m_btnResetMeter.ShowWindow(SW_SHOW);
	m_btnSpecial.ShowWindow((GetMeters().GetUserRights() & (engineRightsDateRange|engineRightsSuper)) != 0 ? SW_SHOW: SW_HIDE);
	m_btnTestMeter.ShowWindow((GetMeters().GetUserRights() & (engineRightsTest|engineRightsSuper)) != 0 ? SW_SHOW: SW_HIDE);
		
	CenterWindow();

	return true;  
}

void CIuMeterAdministratorDlg::OnOK() 
{
	if (!m_sResponse.IsEmpty())
		CopyToClipboard(m_sResponse, this);
	CIuMeterAdministratorDlg_super::OnOK();
}

void CIuMeterAdministratorDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CIuMeterAdministratorDlg_super::OnPaint();
	}
}

HCURSOR CIuMeterAdministratorDlg::OnQueryDragIcon() 
{
	return (HCURSOR) m_hIcon;
}

void CIuMeterAdministratorDlg::OnRefresh() 
{
	m_cbMeters.ResetContent();
	int iMeterCount = m_pMeters->GetCount();
	if (iMeterCount < 1)
	{
		m_cbMeters.EnableWindow(false);
		m_editUserCode.EnableWindow(false);
	}
	else
	{
		m_cbMeters.EnableWindow(true);
		m_editUserCode.EnableWindow(true);

		bool fSelected = false;
		for (int i=0; i < iMeterCount; i++)
		{
			int iIndex = m_cbMeters.AddString(m_pMeters->Get(i).GetTitle());
			m_cbMeters.SetItemData(iIndex, m_pMeters->Get(i).GetID());
			CIuID idMeter = m_pMeters->Get(i).GetID();
			ASSERT(!idMeter.IsInvalid());
			if (!fSelected && !idMeter.IsInvalid() && !m_idMeter.IsInvalid() && idMeter == m_idMeter)
			{
				fSelected = true;
				m_cbMeters.SetCurSel(iIndex);
			}
		}

		if (!fSelected)
			m_cbMeters.SetCurSel(0);

		OnChange();
	}
}

void CIuMeterAdministratorDlg::OnResetMeter() 
{
	int iSel = m_cbMeters.GetCurSel();
	if (iSel == CB_ERR)
		return ;

	CIuID id(int(m_cbMeters.GetItemData(iSel)));

	int iMeter = m_pMeters->Find(id);
	ASSERT(iMeter >= 0);

	CIuMeter& Meter = m_pMeters->Get(iMeter);

	Meter.Delete();
	OnChange();
}

void CIuMeterAdministratorDlg::OnSearch() 
{
	if (CIuSearchWhereDlg::Edit(this))
	{
		m_pMeters->GetEngine().Refresh();
		OnRefresh();
	}
}

void CIuMeterAdministratorDlg::OnSpecial() 
{
	UpdateData();

	CIuMeter* pMeter = 0;

	int iSel = m_cbMeters.GetCurSel();
	if (iSel != CB_ERR)
	{
		CIuID id(int(m_cbMeters.GetItemData(iSel)));
		int iMeter = m_pMeters->Find(id);
		ASSERT(iMeter >= 0);

		pMeter = &m_pMeters->Get(iMeter);
	}

	UINT uiUserValue = meterMagicInvalid;
	if (pMeter)
	{
		CString sKey = pMeter->GetKey();
		CIuQueryResponseSession Session(sKey);
		if (!Session.GetUserValue(m_sUserCode, uiUserValue))
			uiUserValue = meterMagicInvalid;
	}

	CIuMeterCodesDlg::DoDialog(*m_pMeters, pMeter, uiUserValue, this);
}

void CIuMeterAdministratorDlg::OnSelectPhone()
{
	CIuMeterSelectPhoneAdminDlg dlg;
	dlg.m_sUserCode = m_sUserCode;
	dlg.DoModal();
}

void CIuMeterAdministratorDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{																								   
	if ((nID & 0xFFF0) == IDM_METER_ABOUT)
	{
		CIuAboutInfo AboutInfo;
		AboutInfo.ShowAbout(this);
	}
	else if ((nID & 0xFFF0) == IDM_METER_TEST)
	{
		OnTestMeter();
	}
	else
	{
		CIuMeterAdministratorDlg_super::OnSysCommand(nID, lParam);
	}
}

void CIuMeterAdministratorDlg::OnTestMeter()
{
		int iSel = m_cbMeters.GetCurSel();
		if (iSel == CB_ERR)
			return ;

		CIuID id(int(m_cbMeters.GetItemData(iSel)));

		int iMeter = m_pMeters->Find(id);
		ASSERT(iMeter >= 0);

		CIuMeter& Meter = m_pMeters->Get(iMeter);

		CIuMeterTestDlg MeterTest(Meter, this);
		MeterTest.DoModal();

		OnChange();
}

void CIuMeterAdministratorDlg::SetMeters(CIuMeters* pMeters)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pMeters != 0);
	m_pMeters = pMeters;
} 


