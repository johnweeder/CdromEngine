#ifndef _ENGINE_INPUTFRANCHISE_H_
#define _ENGINE_INPUTFRANCHISE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTRECORDFILE_H_
#	include "Engine\InputRecordFile.h"
#endif	// _ENGINE_INPUTRECORDFILE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputFranchise)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputFranchise, CIuInputRecordFile }}
#define CIuInputFranchise_super CIuInputRecordFile

class CIuInputFranchise : public CIuInputFranchise_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputFranchise)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputFranchise();
	virtual ~CIuInputFranchise();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Delete(CIuOutput* pOutput);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnMoveNext();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnOutput();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Input file
	CStdioFile m_FileInput;
	CStdioFile m_FileOutput;
	// Temporary strings to process input
	CString m_sInput;
	CString m_sOutput;
	CString m_sSicCode;
	CString m_sFranchiseCode;
	CString m_sFranchiseName;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_INPUTFRANCHISE_H_
