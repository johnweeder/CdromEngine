#include "StdAfx.h"
//{{Include
#include "GeoRawElementCollection.h"
#include "GeoRawElement.h"
#include "resource.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawElementCollection, CIuGeoRawElementCollection_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawElementCollection)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWELEMENTCOLLECTION, CIuGeoRawElementCollection, CIuGeoRawElementCollection_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoRawElementCollection, IDS_ENGINE_PPG_GEORAWELEMENTCOLLECTION, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuGeoRawElementCollection, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuGeoRawElementCollection, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_GEORAWELEMENTCOLLECTION, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl sort_elements_by_count(const void *elem1, const void *elem2)
{
	const CIuGeoRawElement** ppElement1 = (const CIuGeoRawElement**)elem1;
	const CIuGeoRawElement** ppElement2 = (const CIuGeoRawElement**)elem2;
	return int((*ppElement1)->GetCount() - (*ppElement2)->GetCount());
}

static int __cdecl sort_elements_by_name(const void *elem1, const void *elem2)
{
	const CIuGeoRawElement** ppElement1 = (const CIuGeoRawElement**)elem1;
	const CIuGeoRawElement** ppElement2 = (const CIuGeoRawElement**)elem2;
	return _tcsicmp((*ppElement1)->GetName(), (*ppElement2)->GetName());
}

CIuGeoRawElementCollection::CIuGeoRawElementCollection() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	// Default the has table size to about 1000
	// Later, we will adjust on an individual basis
	m_Map.InitHashTable(1019);
}

CIuGeoRawElementCollection::~CIuGeoRawElementCollection()
{
	Clear();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuGeoRawElement* CIuGeoRawElementCollection::Append(int iValue, int iPad, const CIuGeoRawInstance& instance, CIuOutput& Output)
{
	TCHAR sz[IntMaxStringLength];
	if (iPad > 0)
		IntAsStringEx(sz, sizeof(sz), iValue, 10, iPad, iPad, true);
	else
		IntAsStringEx(sz, sizeof(sz), iValue);
	return Append(sz, instance, Output);
}

CIuGeoRawElement* CIuGeoRawElementCollection::Append(LPCTSTR pcszName, const CIuGeoRawInstance& instance, CIuOutput& Output)
{
	CIuGeoRawElement* pElement = Find(pcszName, true);
	ASSERT(pElement);
	pElement->Another(*this, instance, Output);
	return pElement;
}

void CIuGeoRawElementCollection::Clear()
{
	CIuGeoRawElementCollection_super::Clear();
	Empty();
	// Do not CommonConstruct(), we don't want to zero out prt
	// CIuGeoRawElementCollection::CommonConstruct();
}

void CIuGeoRawElementCollection::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_prt = 0;
	//}}Initialize
}

void CIuGeoRawElementCollection::Empty()
{
	POSITION pos = m_Map.GetStartPosition();
	while (pos)
	{
		CString sName;
		__int32 pv;
		m_Map.GetNextAssoc(pos, sName, pv);
		CIuGeoRawElement* pElement = reinterpret_cast<CIuGeoRawElement*>(pv);
		ASSERT(pElement);
		delete pElement;
	}
	m_Map.RemoveAll();
	m_Array.RemoveAll();
}

CIuGeoRawElement* CIuGeoRawElementCollection::Find(LPCTSTR pcszName, bool fAdd)
{
	ASSERT(AfxIsValidString(pcszName));
	__int32 pv;
	CIuGeoRawElement* pElement;
	if (!m_Map.Lookup(pcszName, pv))
	{
		if (!fAdd)
			return 0;

		ASSERT(m_prt);
		CObject* pObject = m_prt->CreateObject();
		ASSERT(pObject);
		pElement = dynamic_cast<CIuGeoRawElement*>(pObject);
		ASSERT(pElement);

		m_Map.SetAt(pcszName, (__int32)(void*)pElement);
		pElement->SetName(pcszName);
	}
	else
		pElement = reinterpret_cast<CIuGeoRawElement*>(pv);

	ASSERT(pElement);
	return pElement;
}

CIuGeoRawElement* CIuGeoRawElementCollection::Get(int iWhich) const
{
	if (iWhich < 0 || iWhich >= GetCount())
		return 0;

	CIuGeoRawElement* pElement = m_Array[iWhich];
	ASSERT(pElement);
	return pElement;
}

int CIuGeoRawElementCollection::GetCount() const
{
	ASSERT(m_Map.GetCount() == m_Array.GetSize());
	return m_Array.GetSize();
}

bool CIuGeoRawElementCollection::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			SortByName();

			static TCHAR szName[] = _T("CIuGeoRawElementCollectionGrid");
			rq.SetName(szName);
			rq.Load();
			rq.SetSize(CSize(2, GetCount()));
			rq.SetColumn(0, "Name", 100, gridWidthOptional);
			rq.SetColumn(1, "Count", 100, gridWidthOptional);
			return true;
		}
		case gridRqTerminate:
			rq.Save();
			return true;
		case gridRqDblClickRow:
		case gridRqDblClickCell:
			if (rq.GetRow() >= 0 && rq.GetRow() < GetCount())
			{
				CIuGeoRawElement* pElement = Get(rq.GetRow());
				pElement->Edit();
				return true;
			}
			return false;
		case gridRqGet:
		{
			if (rq.GetRow() < 0 || rq.GetRow() >= GetCount())
				return false;

			CIuGeoRawElement* pElement = Get(rq.GetRow());
			switch (rq.GetColumn())
			{
				case 0:
					rq.SetValue(pElement->GetName());
					return true;
				case 1:
					CString sResult;
					rq.SetValue(Int32AsString(sResult, pElement->GetCount()));
					return true;
			}
			return false;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

void CIuGeoRawElementCollection::InitHashTable(int iHashTableSize)
{
	ASSERT(iHashTableSize > 0);
	m_Map.InitHashTable(iHashTableSize);
}

void CIuGeoRawElementCollection::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		DWORD dwCount = m_Map.GetCount();
		ar << dwCount;

		POSITION pos = m_Map.GetStartPosition();
		while (pos)
		{
			CString sName;
			__int32 pv;
			m_Map.GetNextAssoc(pos, sName, pv);
			CIuGeoRawElement* pElement = reinterpret_cast<CIuGeoRawElement*>(pv);
			ASSERT(pElement);
			pElement->Serialize(ar);
		}
	}
	else
	{
		Clear();

		DWORD dwCount;
		ar >> dwCount;

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			ASSERT(m_prt);
			CObject* pObject = m_prt->CreateObject();
			ASSERT(pObject);
			CIuGeoRawElement* pElement = dynamic_cast<CIuGeoRawElement*>(pObject);
			ASSERT(pElement);

			pElement->Serialize(ar);

			m_Map.SetAt(pElement->GetName(), (__int32)(void*)pElement);
		}
	}
}

void CIuGeoRawElementCollection::SetElementType(CRuntimeClass* prt)
{
	ASSERT(prt);
	m_prt = prt;
	ASSERT(m_prt->IsDerivedFrom(RUNTIME_CLASS(CIuGeoRawElement)));
}

void CIuGeoRawElementCollection::Sort()
{
	m_Array.SetSize(m_Map.GetCount());

	POSITION pos = m_Map.GetStartPosition();
	for (int i = 0; pos; ++i)
	{
		CString sName;
		__int32 pv;
		m_Map.GetNextAssoc(pos, sName, pv);
		CIuGeoRawElement* pElement = reinterpret_cast<CIuGeoRawElement*>(pv);
		ASSERT(pElement);

		m_Array.SetAt(i, pElement);
	}
}

void CIuGeoRawElementCollection::SortByCount()
{
	Sort();
	if (m_Array.GetSize() > 0)
		qsort(m_Array.GetData(), m_Array.GetSize(), sizeof(CIuGeoRawElement*), sort_elements_by_count);
}

void CIuGeoRawElementCollection::SortByName()
{
	Sort();
	if (m_Array.GetSize() > 0)
		qsort(m_Array.GetData(), m_Array.GetSize(), sizeof(CIuGeoRawElement*), sort_elements_by_name);
}
