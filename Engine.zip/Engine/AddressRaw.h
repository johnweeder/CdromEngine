#ifndef _ENGINE_ADDRESSRAW_H_
#define _ENGINE_ADDRESSRAW_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_ENGINE_ELEMENTCOLLECTION_H_
#	include "Engine\ElementCollection.h"
#endif	// _ENGINE_ELEMENTCOLLECTION_H_
#ifndef 	_ENGINE_ADDRESSSTREETNAMES_H_
#	include "Engine\AddressStreetNames.h"
#endif	// _ENGINE_ADDRESSSTREETNAMES_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddressRaw)
class CIuAddressCodec;
class CIuAddressSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddressRaw, CIuObjectNamed }}
#define CIuAddressRaw_super CIuObjectNamed

class CIuAddressRaw : public CIuAddressRaw_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddressRaw)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddressRaw();
	virtual ~CIuAddressRaw();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetFilename() const;
	CIuFilename GetFullFilename() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	CIuAddressStreetNames& GetStreetNames() const;
	CIuElementCollection& GetSuffixes() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Add(CIuAddressCodec& Codec, CIuOutput& Output);
	virtual void Clear();
	void Delete(CIuOutput* pOutput = 0);
	void Dump(CIuOutput& Output);
	void Empty();
	void Read();
	void SetFilename(LPCTSTR);
	void SetSpec(CIuAddressSpec& Spec);
	void Write() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionRead(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionWrite(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CIuObject* GetStreetNames_() const;
	CIuObject* GetSuffixes_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Filename
	CString m_sFilename;
	CIuAddressStreetNamesPtr m_pStreetNames;
	CIuElementCollectionPtr m_pSuffixes;

	// Statistics
	int m_iTotal;
	int m_iRr;
	int m_iHc;
	int m_iGd;
	int m_iPoBox;
	int m_iOrdinal;
	int m_iNamed;
	int m_iNumeric;
	int m_iNumericTotal;
	int m_iNumeric16;
	int m_iNumeric256;
	int m_iNumeric4096;
	int m_iNumeric65536;
	int m_iPriNo;
	int m_iPriNo16;
	int m_iPriNo256;
	int m_iPriNo4096;
	int m_iSecNo;
	int m_iSecNo16;
	int m_iSecNo256;
	int m_iSecNo4096;
	int m_iPreDir;
	int m_iPostDir;
	int m_iEmpty;

//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddressStreetNames& CIuAddressRaw::GetStreetNames() const
{
	return m_pStreetNames.Ref();
}

inline CIuElementCollection& CIuAddressRaw::GetSuffixes() const
{
	return m_pSuffixes.Ref();
}

#endif // _ENGINE_ADDRESSRAW_H_
