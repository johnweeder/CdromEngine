#include "stdafx.h"
#include "engine.h"
#include "MeterUpdateDlg.h"
#include "MeterDiagnosticDlg.h"
#include "Meter.h"
#include "Meters.h"
#include "Interop\Conversions.h"
#include "Common\QueryResponseSession.h"
#include "MeterUpdate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDM_METER_ADMIN 0x0110
#define IDM_METER_DIAGNOSTIC	0x0210

/////////////////////////////////////////////////////////////////////////////
// CIuMeterUpdateDlg dialog

CIuMeterUpdateDlg::CIuMeterUpdateDlg(CWnd* pParent /*=NULL*/) : CIuMeterUpdateDlg_super(CIuMeterUpdateDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterUpdateDlg)
	m_sRemaining = _T("");
	m_sAdd = _T("");
	m_sResponse = _T("");
	m_sUserCode = _T("");
	//}}AFX_DATA_INIT
	m_pMeterUpdate = 0;
	m_fUpdated = false;
}

void CIuMeterUpdateDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterUpdateDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterUpdateDlg)
	DDX_Control(pDX, IDC_ENGINE_USERCODE, m_editUserCode);
	DDX_Control(pDX, IDC_ENGINE_PHONE, m_editPhone);
	DDX_Control(pDX, IDC_ENGINE_ADD, m_editAdd);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_ENGINE_RESPONSECODE, m_editResponse);
	DDX_Control(pDX, IDC_ENGINE_WEBSITE, m_btnWeb);
	DDX_Control(pDX, IDC_ENGINE_ADDPROFILES, m_btnAdd);
	DDX_Text(pDX, IDC_ENGINE_REMAINING, m_sRemaining);
	DDX_Text(pDX, IDC_ENGINE_ADD, m_sAdd);
	DDV_MaxChars(pDX, m_sAdd, 6);
	DDX_Text(pDX, IDC_ENGINE_RESPONSECODE, m_sResponse);
	DDX_Text(pDX, IDC_ENGINE_USERCODE, m_sUserCode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIuMeterUpdateDlg, CIuMeterUpdateDlg_super)
	//{{AFX_MSG_MAP(CIuMeterUpdateDlg)
	ON_WM_SYSCOMMAND()
	ON_EN_CHANGE(IDC_ENGINE_ADD, OnChange)
	ON_EN_CHANGE(IDC_ENGINE_RESPONSECODE, OnChange)
	ON_BN_CLICKED(IDC_ENGINE_ADDPROFILES, OnAddProfiles)
	ON_BN_CLICKED(IDC_ENGINE_WEBSITE, OnWebsite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////
//	{{Message Handlers}}

void CIuMeterUpdateDlg::OnAddProfiles() 
{
	if (m_fUpdated)
	{
		OnOK();
		return ;
	}

	UpdateData(true);
	if (!CIuQueryResponseSession::IsValid(m_sResponse))
		return ;
	
	m_pMeterUpdate->SetResponseCode(m_sResponse);

	if (m_pMeterUpdate->IsCorrupt())
	{
		if (m_pMeterUpdate->Update())
		{
			// We just reset a corrupted meter...
			UpdateProfiles(true);
			OnChange();
		}

		if (!m_pMeterUpdate->IsCorrupt())
			AfxMessageBox(IDS_ENGINE_METER_RESET, MB_OK|MB_ICONEXCLAMATION);
		else
			AfxMessageBox(IDS_ENGINE_METER_RESET_FAILED, MB_OK|MB_ICONEXCLAMATION);
	}
	else if (m_pMeterUpdate->Update())
	{
		m_fUpdated = true;
		m_btnAdd.SetWindowText(_T("&Close"));
		UpdateProfiles(false);
		OnChange();
	}
	else
		AfxMessageBox(IDS_ENGINE_METER_UPDATE_FAILED, MB_OK|MB_ICONEXCLAMATION);
}

void CIuMeterUpdateDlg::OnChange()
{
	if (m_fUpdated)
	{
		m_btnAdd.EnableWindow(true);
		m_editAdd.EnableWindow(false);
		m_editResponse.EnableWindow(false);
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnCancel.EnableWindow(false);
		return ;		
	}

	UpdateData(true);

	m_sAdd.TrimLeft();
	m_sAdd.TrimRight();

	int iAdd = StringAsInt(m_sAdd);
	if (m_sAdd.IsEmpty() || iAdd <= 0 || iAdd > meterMagicMeterUpdateMax)
	{
		m_editResponse.EnableWindow(false);
		m_btnAdd.EnableWindow(false);
		m_sUserCode = "";
		UpdateData(false);
		return ;
	}

	m_pMeterUpdate->SetCount(iAdd);

	m_sUserCode = m_pMeterUpdate->GetQueryCode();
	UpdateData(false);

	m_editResponse.EnableWindow(true);

	m_btnAdd.EnableWindow(CIuQueryResponseSession::IsValid(m_sResponse));
}

BOOL CIuMeterUpdateDlg::OnInitDialog() 
{
	CIuMeterUpdateDlg_super::OnInitDialog();

	CMenu* pSysMenu = GetSystemMenu(false);

	// In debug mode, allow popping up the meter admin dialog
	// IDM_METER_ADMIN must be in the system command range.
	ASSERT((IDM_METER_ADMIN & 0xFFF0) == IDM_METER_ADMIN);
	ASSERT(IDM_METER_ADMIN < 0xF000);

	if (pSysMenu != NULL)
	{
		int iRights = m_pMeterUpdate->GetMeter().GetMeters().GetEngine().GetUserRights();
		if ((iRights & engineRightsMeterAdmin) != 0)
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_METER_ADMIN, _T("Administrator"));
		}
	}

	ASSERT((IDM_METER_DIAGNOSTIC & 0xFFF0) == IDM_METER_DIAGNOSTIC);
	ASSERT(IDM_METER_DIAGNOSTIC < 0xF000);

	if (pSysMenu != NULL)
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_METER_DIAGNOSTIC, _T("Diagnostics..."));
	}

	CenterWindow();

	CFont* pFont = m_editUserCode.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);
	m_editResponse.SetFont(&m_fontLarge);
	m_editUserCode.SetFont(&m_fontLarge);

	// Get remaining records
	UpdateProfiles(true);

	Int64AsString(m_sAdd, m_pMeterUpdate->GetCount());

	// NOTE: This can be one or more phones
	const int cxEachStop = 130;
	m_editPhone.SetTabStops(cxEachStop);
	CString sPhone = m_pMeterUpdate->GetMeter().GetPhone();
	if (!sPhone.IsEmpty() && sPhone.GetAt(0) == '(')
	{
		CString sPhoneEx = _T("Phone: ") + sPhone;
		m_editPhone.SetWindowText(sPhoneEx);
	}
	else
		m_editPhone.SetWindowText(sPhone);

	m_btnWeb.ShowWindow(m_pMeterUpdate->GetMeter().GetWebSite().IsEmpty() ? SW_HIDE: SW_SHOW);

	OnChange();

	UpdateData(false);
	return true;  
}

void CIuMeterUpdateDlg::OnWebsite() 
{
 	ShellExecute(NULL, _T("open"), m_pMeterUpdate->GetMeter().GetWebSite(), NULL, NULL, SW_SHOWNORMAL);
}

void CIuMeterUpdateDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_METER_ADMIN)
	{
		UpdateData();
		if (m_pMeterUpdate->GetMeter().GetMeters().AdministratorDlg(this, m_pMeterUpdate->GetMeter().GetID(), m_sUserCode, &m_sResponse))
			m_editResponse.SetWindowText(m_sResponse);
	}
	else if ((nID & 0xFFF0) == IDM_METER_DIAGNOSTIC)
	{
		UpdateData();
		CIuMeterDiagnosticDlg::DoDialog(m_pMeterUpdate->GetMeter(), m_sUserCode, _T("Add Profiles"), this);
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CIuMeterUpdateDlg::SetMeterUpdatePtr(CIuMeterUpdate* pMeterUpdate)
{
	ASSERT(pMeterUpdate != NULL);
	m_pMeterUpdate = pMeterUpdate;
}

void CIuMeterUpdateDlg::UpdateProfiles(bool fUpdate)
{
	m_sRemaining.Format("You have %d profiles remaining.", m_pMeterUpdate->GetMeter().GetCount());
	if (fUpdate)
		 m_sRemaining += _T(" To purchase additional profiles:");
	UpdateData(false);
}
