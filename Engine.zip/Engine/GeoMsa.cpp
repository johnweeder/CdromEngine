#include "StdAfx.h"
//{{Include
#include "GeoMsa.h"
#include "GeoRawMsa.h"
#include "Msa.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "RegExCompare.h"
#include "RegEx.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoMsa, CIuGeoMsa_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoMsa)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOMSA, CIuGeoMsa, CIuGeoMsa_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoMsa::CIuGeoMsa() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoMsa::~CIuGeoMsa()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoMsa::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoMSA"));
	//}}Initialize
}

void CIuGeoMsa::FindScan(CIuGeoList& GeoList, const CIuRegExCompare& RegExCompare) const
{
	int iElements = GetCount();
	for (int iElement = 0; iElement < iElements; ++iElement)
	{
		const CIuMsa& Msa = Get(iElement);
		LPCTSTR pcsz = Msa.GetMsaName();
		int iResult = RegExCompare.Compare(pcsz);
		if (!REGEX_EQ(iResult))
			continue;
		GeoList.Add(iElement, iElement);
	}
}

void CIuGeoMsa::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter;
	sFilter += RegEx.CreateLikeClause(_T("MsaCode"));
	sFilter += _T(" OR ");
	sFilter += RegEx.CreateLikeClause(_T("MsaName"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoMsa::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoMsa::GetIndexStatic() 
{
	return _T("MSA");
}

void CIuGeoMsa::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoMsa);
}

int CIuGeoMsa::GetSourceType() const
{
	return sourceGeoCollectionMsa;
}

void CIuGeoMsa::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoMsa::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawMsa& Msa = *dynamic_cast<CIuGeoRawMsa*>(&Element);
	ASSERT(&Msa);

	int iExpandedSize = sizeof(CIuMsa);
	ASSERT(iExpandedSize == 16);

	CString sName = Msa.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CString sTitle = Msa.GetTitle();
	CheckField(sTitle);
	CIuNybbleString::Append(sTitle, -1, NS_ALPHA, Buffer);
	iExpandedSize += sTitle.GetLength() + 1;

	Msa.GetState().CompressPreferred(Geo, Buffer, Geo.GetStateMap());

	iExpandedSize += CIuGeoList::Compress(Msa.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize;
}

int CIuGeoMsa::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuMsa* pMsa = (CIuMsa*)AddElement(sizeof(CIuMsa));

	// Decompress the various strings
	CIuStaticBuffer256 BufferMsa;
	iOffset += CIuNybbleString::Get(BufferMsa, -1, true, NS_ALPHA, Buffer, iOffset);
	pMsa->m_iMsaCode = StringAsInt(LPCTSTR(BufferMsa.GetPtr()));

	CIuStaticBuffer256 BufferMsaName;
	iOffset += CIuNybbleString::Get(BufferMsaName, -1, true, NS_ALPHA, Buffer, iOffset);

	// Fill out the constant data in the process. 
	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pMsa->m_iStateNo = uiVal - 1;

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferMsa.GetPtr()));
	AddElementString(LPCTSTR(BufferMsaName.GetPtr()));
	AddElementStringTerm();

	return iOffset;
}
