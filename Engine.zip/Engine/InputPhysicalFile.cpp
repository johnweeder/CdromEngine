#include "StdAfx.h"
//{{Include
#include "InputPhysicalFile.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputPhysicalFile, CIuInputPhysicalFile_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputPhysicalFile)
const int iDefaultCacheSize = 8 * 1024 * 1024;
//}}Implement

CIuInputPhysicalFile::CIuInputPhysicalFile() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputPhysicalFile::~CIuInputPhysicalFile()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputPhysicalFile::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputPhysicalFile"));
	m_Cache.Empty();
	m_psz = 0;
	m_iLf = 0;
	m_Length = 0;
	m_cb = 0;
	m_Position = 0;
	m_iCacheSize = iDefaultCacheSize;
	//}}Initialize
}

bool CIuInputPhysicalFile::GetMore()
{
	if (m_psz)
	{
		int iUsed = int(m_psz - LPTSTR(m_Cache.GetPtr()));
		ASSERT(iUsed > 0);
		m_Position += iUsed;
	}

	if (m_Position >= m_Length)
		return false;

	// Terminators added just to make sure scanning algorithms will terminate
	ASSERT(m_File.IsOpen());
	m_cb = int(min(GetCacheSize(), m_Length - m_Position));
	m_Cache.SetSize(m_cb + 1);
	m_psz = LPTSTR(m_Cache.GetPtr());
	m_File.Read(m_Position, (BYTE*)m_psz, m_cb);
	m_iLf = 0;
	for (int i = 0; i < m_cb; ++i)
	{
		if (m_psz[i] == '\0' || !_istascii(m_psz[i]))
			m_psz[i] = ' ';
		else if (m_psz[i] == '\n')
			++m_iLf;
	}
	m_psz[m_cb] = '\0';
	return true;
}

int CIuInputPhysicalFile::GetRemaining()
{
	if (m_psz == 0)
		return 0;
	int iUsed = int(m_psz - LPTSTR(m_Cache.GetPtr()));
	return m_cb - iUsed;
}

void CIuInputPhysicalFile::OnClose()
{
	m_File.Close();
	m_Cache.Destroy();
	m_psz = 0;
	m_iLf = 0;
	m_cb = 0;
	m_Position = 0;
	m_Length = 0;
	CIuInputPhysicalFile_super::OnClose();
}

bool CIuInputPhysicalFile::OnMoveFirst()
{
	ASSERT(m_File.IsOpen());
	m_psz = 0;
	m_iLf = 0;
	m_cb = 0;
	m_Position = 0;
	return CIuInputPhysicalFile_super::OnMoveFirst();
}

bool CIuInputPhysicalFile::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputPhysicalFile_super::OnOpen(OpenSpec))
		return false;

	CIuFilename FilenameInput = GetFullInputFilename();
	m_File.SetCacheSize(GetCacheSize()); 
	m_File.Open(FilenameInput);
	m_Length = m_File.GetLength();
	m_Cache.Empty();
	m_psz = 0;
	m_iLf = 0;
	m_cb = 0;
	m_Position = 0;
	return true;
}

void CIuInputPhysicalFile::SetCacheSize(int iCacheSize)
{
	m_iCacheSize = max(1, iCacheSize);
	m_File.SetCacheSize(m_iCacheSize);
}

void CIuInputPhysicalFile::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputPhysicalFile_super::SetSpec(Spec);
}

