#ifndef _ENGINE_BTREEINDEXRAWSEPARATORBLOCK_H_
#define _ENGINE_BTREEINDEXRAWSEPARATORBLOCK_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_INTEGER_H_
#	include "Interop\Integer.h"
#endif	// _INTEROP_INTEGER_H_
#ifndef 	_ENGINE_BTREEINDEXSEPARATOR_H_
#	include "Engine\BTreeIndexSeparator.h"
#endif	// _ENGINE_BTREEINDEXSEPARATOR_H_
//}}Uses

//{{Predefines
struct CIuBTreeIndexRawSeparator;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

struct CIuBTreeIndexRawSeparatorBlockHeader
{
	CIuBTreeIndexRawSeparatorBlockHeader()
	{
		Clear();
	}
	void Clear()
	{
		m_iSeparatorNo = 0;
		m_iRecordCount = 0;
		m_iPointerCount = 0;
	}
	CIuUInt32 m_iSeparatorNo;	// The actual id of the first Separator in this block
	CIuUInt32 m_iRecordCount;	// Number of records accounted for in this block
	CIuUInt32 m_iPointerCount;	// Number of pointers accounted for in this block
};


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeIndexRawSeparatorBlock }}

class CIuBTreeIndexRawSeparatorBlock
{
/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeIndexRawSeparatorBlock();
	CIuBTreeIndexRawSeparatorBlock(const CIuBTreeIndexRawSeparatorBlock& rRawBlock);
	virtual ~CIuBTreeIndexRawSeparatorBlock();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int FindRecordNo(int iRecord) const;
	int FindPointerNo(int iPointer) const;
	int FindSeparator(const CIuKey& key) const;
	void Get(int iIndex, CIuBTreeIndexSeparator&) const;
	int GetBlockSize() const;
	const BYTE* GetData() const;
	BYTE* GetData();
	int GetPointerCount() const;
	int GetRecordCount() const;
	int GetSeparatorCount() const;
	int GetSeparatorNo() const;
	bool IsEmpty() const;
	bool WillFit(const CIuBTreeIndexSeparator&);
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(const CIuBTreeIndexSeparator& separator);
	void Clear();
	void GrowBlockSize(int iBlockSize);
	void SetBlockSize(int);
	void SetSeparatorNo(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuBTreeIndexRawSeparatorBlock& operator=(const CIuBTreeIndexRawSeparatorBlock& rRawBlock);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	const CIuBTreeIndexRawSeparator* GetFirstSeparator() const;
	CIuBTreeIndexRawSeparatorBlockHeader* GetHeader() const;
	const CIuBTreeIndexRawSeparator* GetSeparator(int iSeparator) const;
	void SetPointerCount(int);
	void SetRecordCount(int);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBuffer m_block;	// The start of the block contains a is a 32 bit integer containing the number of sepators in previous blocks.
								// OR, alternately, the start separator no in this block
	int m_iBlockSize;
	int m_iUsed;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//}}Export2

//{{Inline}}

inline bool CIuBTreeIndexRawSeparatorBlock::IsEmpty() const
{
	return m_iUsed == 0;
}

#endif // _ENGINE_BTREEINDEXRAWSEPARATORBLOCK_H_
