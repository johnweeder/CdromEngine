#ifndef _ENGINE_LATLONGCOORDINATE_H_
#define _ENGINE_LATLONGCOORDINATE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_LATLONGUNIT_H_
#	include "Engine\LatLongUnit.h"
#endif	// _ENGINE_LATLONGUNIT_H_
#ifndef 	_ENGINE_LATLONGDISTANCE_H_
#	include "Engine\LatLongDistance.h"
#endif	// _ENGINE_LATLONGDISTANCE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuLatLongCoordinate}}

class IU_CLASS_EXPORT CIuLatLongCoordinate 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuLatLongCoordinate();
	CIuLatLongCoordinate(const CIuLatLongCoordinate&);
	CIuLatLongCoordinate(CIuLatLongUnit, CIuLatLongUnit);
	CIuLatLongCoordinate(DWORD dwLat, DWORD dwLong);
	CIuLatLongCoordinate(LPCTSTR, LPCTSTR);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString AsString(bool fDms = false) const;
	CIuLatLongUnit GetLatitude() const;
	CIuLatLongUnit GetLongitude() const;
	bool IsValid() const;
	bool IsZero() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	static CIuLatLongDistance GetDistance(const CIuLatLongCoordinate& First, const CIuLatLongCoordinate& Second, CString* pDirection = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuLatLongCoordinate& operator=(const CIuLatLongCoordinate& Coord);
	CIuLatLongDistance operator-(const CIuLatLongCoordinate& Coord) const;

	bool operator==(const CIuLatLongCoordinate& Coord) const;
	bool operator!=(const CIuLatLongCoordinate& Coord) const;

	// Note: These operations are not reflexive!
	// a < b does NOT imply b >= a.
	// a < b implies that both the lat and int of a is <
	// that of b
	bool operator<(const CIuLatLongCoordinate& Coord) const;
	bool operator>(const CIuLatLongCoordinate& Coord) const;
	bool operator<=(const CIuLatLongCoordinate& Coord) const;
	bool operator>=(const CIuLatLongCoordinate& Coord) const;
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuLatLongUnit m_LatLongUnitLat;
	CIuLatLongUnit m_LatLongUnitLong;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuLatLongUnit CIuLatLongCoordinate::GetLatitude() const
{
	return m_LatLongUnitLat;
}

inline CIuLatLongUnit CIuLatLongCoordinate::GetLongitude() const
{
	return m_LatLongUnitLong;
}

#endif // _ENGINE_LATLONGCOORDINATE_H_
