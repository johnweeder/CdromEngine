#ifndef _ENGINE_DIALDLG_H_
#define _ENGINE_DIALDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDialDlg, CDialog }}
#define CIuDialDlg_super CDialog

class CIuDialDlg : public CIuDialDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()			  

//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDialDlg(CIuTapi* pTapi, CWnd* pParent = NULL);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuTapi& GetTapi() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Data
private :
	CIuTapi*	m_pTapi;
//}}Data

public:
	//{{AFX_DATA(CIuDialDlg)
	enum { IDD = IDD_ENGINE_DIAL };
	CButton	m_btnHelp;
	CComboBox	m_cbPort;
	CButton	m_Dial1;
	CButton m_Dial2;
	CButton m_Dial3; 
	CButton m_Dial4;
	CString	m_sLocalAreaCode;
	CString	m_sLDPrefix;
	CString	m_sLDSufix;
	CString	m_sLocalPrefix;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuDialDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuDialDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSave();
	afx_msg void OnHelpDial();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuTapi& CIuDialDlg::GetTapi() const
{
	ASSERT(m_pTapi);
	return *m_pTapi;
}

#endif // _ENGINE_DIALDLG_H_
