#ifndef _ENGINE_FIELDDEFS_H_
#define _ENGINE_FIELDDEFS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_FIELDDEF_H_
#	include "Engine\FieldDef.h"
#endif	// _ENGINE_FIELDDEF_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldDefs)
class CIuRecordDefSpec;
//}}Predefines

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldDefs, CIuFieldDefs_super }}

#define CIuFieldDefs_super CIuCollection

class IU_CLASS_EXPORT CIuFieldDefs : public CIuFieldDefs_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuFieldDefs)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldDefs();     
	CIuFieldDefs(const CIuFieldDefs&);
	virtual ~CIuFieldDefs();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuFieldDef& Get(CIuID id) const;
	CIuFieldDef& Get(int iIndex) const;
	CIuFieldDef& Get(LPCTSTR s) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int AddFieldDef(LPCTSTR pcszDef);
	int AddFieldDef(CIuFieldDefSpec& spec);
	void Adjust();
	void SetSpec(CIuRecordDefSpec& RecordDefSpec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnAdjust();
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldDefs& operator=(const CIuFieldDefs&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionAdjust(const CIuPropertyCollection& Collection, CIuOutput& Output);
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuFieldDef& CIuFieldDefs::Get(CIuID id) const
{
	return *dynamic_cast<CIuFieldDef*>(&CIuCollection::Get(id));
}

inline CIuFieldDef& CIuFieldDefs::Get(int iIndex) const
{
	return *dynamic_cast<CIuFieldDef*>(&CIuCollection::Get(iIndex));
}

inline CIuFieldDef& CIuFieldDefs::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuFieldDef*>(&CIuCollection::Get(s));
}

#endif // _ENGINE_FIELDDEFS_H_
