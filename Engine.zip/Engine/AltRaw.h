#ifndef _ENGINE_ALTRAW_H_
#define _ENGINE_ALTRAW_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ALTRAWELEMENT_H_
#	include "Engine\AltRawElement.h"
#endif	// _ENGINE_ALTRAWELEMENT_H_
#ifndef 	_ENGINE_ALTINSTANCE_H_
#	include "Engine\AltInstance.h"
#endif	// _ENGINE_ALTINSTANCE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltRaw)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltRaw, CIuObjectNamed }}
#define CIuAltRaw_super CIuObjectNamed
class CIuAltRaw : public CIuAltRaw_super
{
//{{Declare
	DECLARE_SERIAL(CIuAltRaw)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltRaw();
	virtual ~CIuAltRaw();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAltRawElement* Get(int iWhich) const;
	int GetCount() const;
	CString GetFilename() const;
	CIuFilename GetFullFilename() const;
	int GetHashSize() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(CIuAltInstance& instance);
	void Clear();
	void Delete(CIuOutput* pOutput = 0);
	void Empty();
	void Read();
	void SetCount(int);
	void SetFilename(LPCTSTR);
	void SetHashSize(int);
	void SetSpec(int iAlt);
	void SortByKey();
	void Write() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionRead(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionWrite(const CIuPropertyCollection& collection, CIuOutput&);
	void AllocateMap(int iHashSize);
	bool GetGridInfo(int iRq, CIuGridRq& rq);
	void Serialize(CArchive& ar);
	void Sort();
private:
	void CommonConstruct();
	CString GetGridElement(int iRow, int iCol) const;
	int HashBucket(LPCTSTR key) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Persistent
	CString m_sFilename;
	// Non-persistent
	CArray<CIuAltRawElement*, CIuAltRawElement*> m_ElementMap;
	CArray<CIuAltRawElement*, CIuAltRawElement*> m_ElementArray;
	// Size of hash table and number of elements
	int m_iCount;
	int m_iHashSize;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAltRaw::GetCount() const
{
	return m_iCount;
}

inline CString CIuAltRaw::GetFilename() const
{
	return m_sFilename;
}

inline int CIuAltRaw::GetHashSize() const
{
	return m_iHashSize;
}

#endif // _ENGINE_ALTRAW_H_
