#include "StdAfx.h"
//{{Include
#include "InputSic.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputSic, CIuInputSic_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputSic)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTSIC, CIuInputSic, CIuInputSic_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputSic, IDS_ENGINE_PPG_INPUTSIC, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


static int __cdecl sort_sic_raw0(const void *elem1, const void *elem2)
{
	const CIuInputSicRaw* pSic1= (const CIuInputSicRaw*)elem1;
	const CIuInputSicRaw* pSic2 = (const CIuInputSicRaw*)elem2;
	int iResult = stricmp(pSic1->m_szSicCode, pSic2->m_szSicCode);
	if (iResult != 0)
		return iResult;
	iResult = stricmp(pSic1->m_szSicName, pSic2->m_szSicName);
	if (iResult != 0)
		return iResult;
	return 0;
}

static int __cdecl sort_sic_raw1(const void *elem1, const void *elem2)
{
	const CIuInputSicRaw* pSic1= (const CIuInputSicRaw*)elem1;
	const CIuInputSicRaw* pSic2 = (const CIuInputSicRaw*)elem2;
	int iResult = stricmp(pSic1->m_szSicCode, pSic2->m_szSicCode);
	if (iResult != 0)
		return iResult;
	if (pSic1->m_fPreferred && !pSic2->m_fPreferred)
		return -1;
	if (!pSic1->m_fPreferred && pSic2->m_fPreferred)
		return 1;
	iResult = stricmp(pSic1->m_szSicName, pSic2->m_szSicName);
	if (iResult != 0)
		return iResult;
	return 0;
}

CIuInputSic::CIuInputSic() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputSic::~CIuInputSic()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputSic::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input SIC"));
	SetInputFilename("PCode.");
	SetOutputFilename("Sic");
	SetFormat(inputSic);
	//}}Initialize
}

void CIuInputSic::Delete(CIuOutput* pOutput)
{
	CIuInputSic_super::Delete(pOutput);
	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	CdromDelete(FilenameOutput, pOutput);
}

void CIuInputSic::OnClose()
{
	m_FileInput.Close();

	// De-dup
	qsort(m_Sics.GetData(), m_Sics.GetSize(), sizeof(CIuInputSicRaw), sort_sic_raw0);
	for (int iRecord = 1; iRecord < m_Sics.GetSize(); )
	{
		CIuInputSicRaw& SicRaw0 = m_Sics.ElementAt(iRecord - 1);
		CIuInputSicRaw& SicRaw1 = m_Sics.ElementAt(iRecord);

		if (_tcsicmp(SicRaw0.m_szSicCode, SicRaw1.m_szSicCode) != 0)
		{
			++iRecord;
			continue;
		}
		if (_tcsicmp(SicRaw0.m_szSicName, SicRaw1.m_szSicName) != 0)
		{
			++iRecord;
			continue;
		}
		m_Sics.RemoveAt(iRecord);
	}

	// Updated "preferred" flag
	qsort(m_Sics.GetData(), m_Sics.GetSize(), sizeof(CIuInputSicRaw), sort_sic_raw1);
	for (iRecord = 0; iRecord < m_Sics.GetSize(); )
	{
		CIuInputSicRaw& SicRaw0 = m_Sics.ElementAt(iRecord);
		SicRaw0.m_fPreferred = true;

		for (int iNext = iRecord + 1; iNext < m_Sics.GetSize(); ++iNext)
		{
			CIuInputSicRaw& SicRaw1 = m_Sics.ElementAt(iNext);
			if (_tcsicmp(SicRaw0.m_szSicCode, SicRaw1.m_szSicCode) != 0)
				break;
			SicRaw1.m_fPreferred = false;
		}

		iRecord = iNext;
	}

	// Output
	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	CStdioFile FileOutput(FilenameOutput, CFile::modeCreate|CFile::modeReadWrite|CFile::shareExclusive|CFile::typeText);

	CString sOutput;
	GetOutput().SetRange(m_Sics.GetSize());
	for (iRecord = 0; iRecord < m_Sics.GetSize(); ++iRecord)
	{
		if ((iRecord % engineNoise) == 0)
		{
			GetOutput().SetPosition(iRecord);
			if (!GetOutput().Fire(IU_EVENT_OPERATION_CONTINUE))
				return ;
		}

		CIuInputSicRaw& SicRaw = m_Sics.ElementAt(iRecord);

		ClearFields();
		SetField(inputFieldSicCode, SicRaw.m_szSicCode);
		SetField(inputFieldSicName, SicRaw.m_szSicName);
		SetField(inputFieldSicPreferred, SicRaw.m_fPreferred ? "X": "");

		Output();

		// Just to be nice, we dump a text file version of the output
		sOutput = _T("\"");
		sOutput += GetField(inputFieldSicCode);
		sOutput += _T("\",\"");
		sOutput += GetField(inputFieldSicName);
		sOutput += _T("\",\"");
		sOutput += GetField(inputFieldSicPreferred);
		sOutput += _T("\"\n");

		FileOutput.WriteString(sOutput);

		// We also dump the record file version
	}

	m_Sics.SetSize(0);

	GetOutput().Fire();

	CIuInputSic_super::OnClose();
}

bool CIuInputSic::OnMoveNext()
{
	if (!m_FileInput.ReadString(m_sInput))
		return false;

	if (m_sInput.GetLength() < 6)
		return true;

	m_sSicCode = m_sInput.Mid(65, 6);
	m_sSicCode.TrimRight();
	m_sSicCode.MakeUpper();
	if (m_sSicCode.GetLength() != 6)
	{
		TRACE("WARNING: Invalid SIC code '%s'\n", LPCTSTR(m_sSicCode));
		return true;
	}

	m_sSicName = m_sInput.Mid(2, 45);
	m_sSicName.TrimRight();
	m_sSicName.MakeUpper();
	if (m_sSicName.IsEmpty())
	{
		TRACE("WARNING: Blank SIC name '%s'\n", LPCTSTR(m_sSicCode));
		return true;
	}

	m_sPreferred = m_sInput.Mid(1, 1);
	m_sPreferred.TrimRight();
	m_sPreferred.MakeUpper();

	CIuInputSicRaw SicRaw;
	ASSERT(m_sSicCode.GetLength() + 1 <= sizeof(SicRaw.m_szSicCode));
	_tcscpy(SicRaw.m_szSicCode, m_sSicCode);
	ASSERT(m_sSicName.GetLength() + 1 <= sizeof(SicRaw.m_szSicName));
	_tcscpy(SicRaw.m_szSicName, m_sSicName);
	SicRaw.m_fPreferred = true;
	if (m_sPreferred.GetLength() == 1)
		SicRaw.m_fPreferred = (m_sPreferred.GetAt(0) != '-');

	m_Sics.Add(SicRaw);
	return true;
}

bool CIuInputSic::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputSic_super::OnOpen(OpenSpec))
		return false;

	m_Sics.RemoveAll();

	CIuFilename FilenameInput = GetFullInputFilename();
	if (!FilenameInput.Exists())
	{
		GetOutput().OutputF(_T("*** WARNING: SIC master file, %s, not found\n"), LPCTSTR(FilenameInput));
		return false;
	}

	m_FileInput.Open(FilenameInput, CFile::modeRead|CFile::shareDenyNone|CFile::typeText);

	return true;
}
