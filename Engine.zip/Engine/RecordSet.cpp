#include "stdafx.h"
//{{Include
#include "RecordSet.h"
#include "resource.h"
#include "Engine.h"
#include "SourceProvider.h"
#include "FieldList.h"
#include "Query.h"
#include "Error\Error.h"
#include "SourceSetList.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuRecordSet, CIuRecordSet_super)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordSet)
const	CIuVersionNumber versionRecordSetMax(2000,1,5,304);
const	CIuVersionNumber versionRecordSetMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDSET, CIuRecordSet, CIuRecordSet_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuRecordSet, IDS_ENGINE_PPG_RECORDSET, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRecordSet::CIuRecordSet()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRecordSet::CIuRecordSet(const CIuRecordSet& rRecordSet)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rRecordSet;
}

CIuRecordSet::~CIuRecordSet()
{
	SetSource(0);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRecordSet::Clear()
{
	// Do not call CommonConstruct().. we want to preserve name/id/open, etc
	CIuRecordSet_super::Clear();
	CIuSourceSetListPtr pSource;
	pSource.Create();
	SetSource(pSource);
	m_Convert.Clear();
}

void CIuRecordSet::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetName("RecordSet");
	SetID(CIuID::Create());
	m_pQuery = 0;
	// Always start with a setlist source so that
	// the user can simply add/delete records
	CIuSourceSetListPtr pSource;
	pSource.Create();
	SetSource(pSource);
	SetVersion(IU_VERSION);
	SetVersion(versionRecordSetMax);
	//}}Initialize
}

int CIuRecordSet::First(int iType, LPCTSTR Criteria, int* piMatch)
{
	ASSERT(Criteria);
	// Only skip leading spaces, tabs are important
	while (*Criteria && *Criteria == ' ')
		++Criteria;
	TRACE("RECORDSET: First [%s]\n", Criteria);
	ASSERT(HasSource());
	int iMatch;
	if (piMatch == 0)
		piMatch = &iMatch;
	if (!HasSource())
	{
		*piMatch = -1;
		return matchNone;	
	}
	return GetSource().First(iType, Criteria, *piMatch);
}

bool CIuRecordSet::Get(int iRecord, CIuRecordPtr& pRecord) const
{
	CIuRecordDef* pRecordDef = GetInternal(iRecord, pRecord, -1);
	return pRecordDef != 0;
}

void CIuRecordSet::GetBuffer(CIuWorkbookFile& /* WorkbookFile */, CIuBuffer& Buffer) const
{
	Buffer.Append((const BYTE*)&versionRecordSetMax, sizeof(versionRecordSetMax));

	m_Tagged.GetBuffer(Buffer);

	CIuSource& Source = GetSource();
	Source.GetBuffer(Buffer);
}

int CIuRecordSet::GetCount() const
{
	// If the complete flag is set, the recordset will 
	// wait until a complete count is obtained.
	// Except, of course, that the user can cancel if desired.
	if (!HasSource())
		return 0;
	ASSERT(HasSource());
	return GetSource().GetCount(sourceModeDefault);
}

bool CIuRecordSet::GetExpanded(int iRecord, int iExpandOffset, CIuRecordPtr& pRecord) const
{
	ASSERT(iExpandOffset >= 0);
	CIuRecordDef* pRecordDef = GetInternal(iRecord, pRecord, iExpandOffset);
	return pRecordDef != 0;
}

CString CIuRecordSet::GetField(int iRecord, int iIndex) const
{
	CIuRecordDef* pRecordDef = GetInternal(iRecord, m_pRecordFieldList, -1);
	if (pRecordDef == 0)
		return CString();

	return CString(m_pRecordFieldList->GetField(iIndex));
}

CString CIuRecordSet::GetFieldList(int iRecord, CIuFieldList& FieldList) const
{
	CIuRecordDef* pRecordDef = GetInternal(iRecord, m_pRecordFieldList, -1);
	if (pRecordDef == 0)
		return CString();

	if (!FieldList.IsResolved() || FieldList.GetRecordDef() != pRecordDef)
	{
		CIuResolveSpec Spec;
		Spec.m_pRecordDefSrc = pRecordDef;
		FieldList.Resolve(Spec);
	}

	CString s = FieldList.Evaluate(m_pRecordFieldList.Ptr());
	s.TrimRight();
	return s;
}

CString CIuRecordSet::GetFieldListExpanded(int iRecord, int iExpandOffset, CIuFieldList& FieldList) const
{
	ASSERT(iExpandOffset >= 0);
	CIuRecordDef* pRecordDef = GetInternal(iRecord, m_pRecordFieldList, iExpandOffset);
	if (pRecordDef == 0)
		return CString();

	if (!FieldList.IsResolved() || FieldList.GetRecordDef() != pRecordDef)
	{
		CIuResolveSpec Spec;
		Spec.m_pRecordDefSrc = pRecordDef;
		FieldList.Resolve(Spec);
	}

	CString s = FieldList.Evaluate(m_pRecordFieldList.Ptr());
	s.TrimRight();
	return s;
}

CString CIuRecordSet::GetFieldListExpandedAlt(int iRecord, int iExpandOffset, CIuFieldList& FieldList, CIuFieldList* pFieldListAlt) const
{
	ASSERT(iExpandOffset >= 0);
	CIuRecordDef* pRecordDef = GetInternal(iRecord, m_pRecordFieldList, iExpandOffset);
	if (pRecordDef == 0)
		return CString();

	CIuFieldList* pFieldList = 0;
	if (m_pRecordFieldList->IsAlternate())
	{
		if (pFieldListAlt == 0)
			return CString();

		pFieldList = pFieldListAlt;
	}
	else
	{
		pFieldList = &FieldList;
	}
	ASSERT(pFieldList);

	if (!pFieldList->IsResolved() || pFieldList->GetRecordDef() != pRecordDef)
	{
		CIuResolveSpec Spec;
		Spec.m_pRecordDefSrc = pRecordDef;
		FieldList.Resolve(Spec);
	}

	CString s = FieldList.Evaluate(m_pRecordFieldList.Ptr());
	s.TrimRight();
	return s;
}

CIuRecordDef* CIuRecordSet::GetInternal(int iRecord, CIuRecordPtr& pRecord, int iExpandOffset) const
{
	ASSERT(HasSource());
	if (!HasSource())
		return 0;

	CIuRecordDef* pRecordDef = GetSource().Get(iRecord, pRecord, sourceModeDefault);
	if (pRecordDef == 0)
		return 0;

	if (iExpandOffset >= 0)
	{
		m_pRecordExpand = *pRecord;
		CIuRecordDef* pRecordDefEx = m_Convert.Expand(pRecord, iExpandOffset, m_pRecordExpand);
		if (pRecordDefEx != 0)
		{
			pRecordDef = pRecordDefEx;
		}
	}

	if (m_Convert.NeedsMap())
	{
		m_pRecordMap = *pRecord;
		m_Convert.MapFields(pRecord, m_pRecordMap, pRecordDef);
	}

	return pRecordDef;
}

CIuRecordDefPtr CIuRecordSet::GetRecordDef() const
{
	// If we have no source, we have no record def
	ASSERT(HasSource());
	if (!HasSource())
		return CIuRecordDefPtr();

	// If the source has a single record def, use it
	CIuRecordDef* pRecordDef = GetSource().GetRecordDef(sourceModeDefault);
	if (pRecordDef)
		return CIuRecordDefPtr(pRecordDef);

	// Otherwise, see if the conversion object has a record def
	pRecordDef = m_Convert.GetRecordDef();
	if (pRecordDef)
		return CIuRecordDefPtr(pRecordDef);

	// If not, there is no consistent record def
	return CIuRecordDefPtr();
}

CIuSetListPtr CIuRecordSet::GetSetListTagged(int iMode) const
{
	CIuSetListPtr pSetList;
	pSetList.Create();
	pSetList->SetSorted(false);

	int iRecord = m_Tagged.GetFirst();
	while (iRecord >= 0)
	{
		UINT64 uiSrcRecNo = GetSource().GetSrcRecNo(iRecord, iMode);
		pSetList->Add(uiSrcRecNo);

		iRecord = m_Tagged.GetNext(iRecord);
	}
	return pSetList;
}

CIuSource& CIuRecordSet::GetSource() const
{
	return m_pSource.Ref();
}

int CIuRecordSet::GetTaggedCount() const
{
	ASSERT(HasSource());
	if (!HasSource())
		return 0;
	// Get the total number of tagged records
	return m_Tagged.GetCount();
}

CIuVersionNumber CIuRecordSet::GetVersionMax() const
{
	return versionRecordSetMax;
}

CIuVersionNumber CIuRecordSet::GetVersionMaxStatic()
{
	return versionRecordSetMax;
}

CIuVersionNumber CIuRecordSet::GetVersionMin() const
{
	return versionRecordSetMin;
}

CIuVersionNumber CIuRecordSet::GetVersionMinStatic()
{
	return versionRecordSetMin;
}

bool CIuRecordSet::IsAlternate(int iRecord) const
{
	ASSERT(HasSource());
	if (!HasSource())
		return false;
	CIuRecordPtr pRecord;
	if (!Get(iRecord, pRecord))
		return false;
	return pRecord->IsAlternate();
}

bool CIuRecordSet::IsTagged(int iRecord) const
{
	if (!HasSource())
		return false;
	ASSERT(HasSource());
	// Check if a record is tagged
	return m_Tagged.IsTagged(iRecord);
}

int CIuRecordSet::Last(int iType, LPCTSTR Criteria, int FAR* piMatch) 
{
	ASSERT(Criteria);
	// Only skip leading spaces, tabs are important
	while (*Criteria && *Criteria == ' ')
		++Criteria;
	ASSERT(HasSource());
	int iMatch;
	if (piMatch == 0)
		piMatch = &iMatch;
	if (!HasSource())
	{
		*piMatch = -1;
		return matchNone;	
	}
	return GetSource().Last(iType, Criteria, *piMatch);
}

int CIuRecordSet::Next(int iType, LPCTSTR Criteria, int Current, int FAR* piMatch) 
{
	ASSERT(Criteria);
	// Only skip leading spaces, tabs are important
	while (*Criteria && *Criteria == ' ')
		++Criteria;
	ASSERT(HasSource());
	int iMatch;
	if (piMatch == 0)
		piMatch = &iMatch;
	if (!HasSource())
	{
		*piMatch = -1;
		return matchNone;	
	}
	return GetSource().Next(iType, Criteria, Current, *piMatch);
}

bool CIuRecordSet::NthTaggingDlg(int iMaxOutput, CWnd* pParent)
{
	return m_Tagged.NthTaggingDlg(GetCount(), iMaxOutput, pParent);
}

CIuRecordSet& CIuRecordSet::operator=(const CIuRecordSet& rRecordSet)
{
	Copy(rRecordSet);
	return *this;
}

int CIuRecordSet::Previous(int iType, LPCTSTR Criteria, int Current, int FAR* piMatch) 
{
	ASSERT(Criteria);
	// Only skip leading spaces, tabs are important
	while (*Criteria && *Criteria == ' ')
		++Criteria;
	ASSERT(HasSource());
	int iMatch;
	if (piMatch == 0)
		piMatch = &iMatch;
	if (!HasSource())
	{
		*piMatch = -1;
		return matchNone;	
	}
	return GetSource().Previous(iType, Criteria, Current, *piMatch);
}

void CIuRecordSet::RemoveAllTagged() 
{
	if (!HasSource())
		return ;
	ASSERT(HasSource());
	// Remove the tagging from all records
	m_Tagged.ClearTagged();
}

int CIuRecordSet::SetBuffer(const CIuWorkbookFile& /* WorkbookFile */, const CIuBuffer& Buffer, int iOffset)
{
	ASSERT(iOffset >= 0);
	CIuVersionNumber VersionNumber;
	iOffset += Buffer.Get((BYTE*)&VersionNumber, sizeof(VersionNumber), iOffset);
	if (VersionNumber < versionRecordSetMin || VersionNumber > versionRecordSetMax)
		Error(IU_E_OBJECT_INVALID_OR_CORRUPT, _T("CIuRecordSet"));

	CSingleLock lock(&m_mutex, true);

	iOffset = m_Tagged.SetBuffer(Buffer, iOffset);

	// We must already have a source of the correct type.
	// Currently only workbook sources are supported.
	ASSERT(HasSource());
	iOffset = GetSource().SetBuffer(Buffer, iOffset);

	return iOffset;
}

void CIuRecordSet::SetEngine(CIuEngine& Engine)
{
	m_pEngine = &Engine;
	m_Convert.SetEngine(*m_pEngine);
	if (m_pSource.NotNull())
	{
		if (!m_pSource->HasEngine())
			m_pSource->SetEngine(GetEngine());
	}
}

void CIuRecordSet::SetQuery(CIuQuery& Query)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pQuery = &Query;
}

void CIuRecordSet::SetSource(CIuSource* pSource)
{
	// Keep a pointer to the object.
	// Be very careful that this does not create a circular reference.
	CSingleLock lock(&m_mutex, true);
	m_pSource = pSource;
	if (m_pSource.NotNull())
	{
		if (HasEngine() && !m_pSource->HasEngine())
			m_pSource->SetEngine(GetEngine());
	}
}

bool CIuRecordSet::SetTagged(int iRecord, bool fTagged)
{
	ASSERT(HasSource());
	if (!HasSource())
		return false;
	// Set the tagging state of a record
	m_Tagged.SetTagged(iRecord, fTagged);
	// Returns true if tagging successful. Could return false if
	// max tagging count is exceeded.
	return true;
}
