#include "StdAfx.h"
//{{Include
#include "ExpressionElement.h"
#include "Error\Error.h"
#include "Common\String.h"
#include "Interop\Conversions.h"
#include "Error\Error.h"
#include "CaseConversion.h"
#include "ExpressionBinary.h"
#include "ExpressionConcat.h"
#include "ExpressionBool.h"
#include "ExpressionCompare.h"
#include "ExpressionMatches.h"
#include "ExpressionField.h"
#include "ExpressionFunction.h"
#include "ExpressionLike.h"
#include "ExpressionContains.h"
#include "ExpressionWord.h"
#include "ExpressionLiteral.h"
#include "ExpressionPhonetic.h"
#include "ExpressionUnary.h"
#include "FieldDefConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionElement::CIuExpressionElement(CIuExpressionType Type)
{
	CommonConstruct();
	SetType(Type);
}

CIuExpressionElement::CIuExpressionElement(const CIuExpressionElement& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionElement::~CIuExpressionElement()
{
	RemoveAllChildren();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExpressionElement::AddChild(CIuExpressionElement* pExpressionElement)
{
	ASSERT(pExpressionElement);
	m_array.Add(pExpressionElement);
}

int CIuExpressionElement::BooiMaxLength() const
{
	// "0" or "1"
	return 1;
}

CIuExpressionElement* CIuExpressionElement::Clone() const
{
	CIuExpressionElement* pElement = new CIuExpressionElement(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionElement::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_Type = exprUnknown;
	m_pObjectRepository = 0;
	m_Format = exprFormatBool;
	m_iCaseConvert = caseNoConvert;
	//}}Initialize
}

void CIuExpressionElement::ConvertToExpression(CIuExpressionArray& Array, int iToken)
{
	ASSERT(iToken >= 0 || iToken < Array.GetSize());
	CIuExpressionElement* pElement = new CIuExpressionElement(exprExpression);
	ASSERT(pElement);
	pElement->AddChild(Array[iToken]);
	Array.SetAt(iToken, pElement);
}

CIuExpressionElement* CIuExpressionElement::DetachChild(int iChild) 
{
	if (iChild < 0 || iChild >= GetChildCount())
	{
		// Return an empty literal
		CIuExpressionLiteral* pLiteral = new CIuExpressionLiteral("");
		return pLiteral;
	}

	ASSERT(iChild >= 0 && iChild < GetChildCount());
	CIuExpressionElement* pElement = m_array[iChild];
	m_array.RemoveAt(iChild);
	return pElement;
}

void CIuExpressionElement::Dump(int iLevel, bool fDeep) const
{
	CString s;
	for (int i = 0; i < iLevel; ++i)
		s += _T("  ");

	s += "Type: '";
	s += GetTypeName();
	s += "' (";
	CString sType;
	s += Int32AsString(sType, GetType());
	s += ")";

	if (GetChildCount() > 0)
	{
		s += ", Children:";
		CString sChildren;
		s += Int32AsString(sChildren, GetChildCount());
	}
	s += "\n";

	TRACE(LPCTSTR(s));

	// Dump the children
	if (fDeep)
	{
		int iChildren = GetChildCount();
		for (int iChild = 0; iChild < iChildren; ++iChild)
			GetChild(iChild).Dump(iLevel + 1);
	}
}

LPCTSTR CIuExpressionElement::Evaluate(const CIuRecord* pRecord) const
{
	// Each derived class must do its own evaluation.
	// You may provide a default evalation for either a string, an int or a bool.
	// The base class provides conversions between the basic types of return values.
	int iValue = EvaluateInt(pRecord);
	IntAsString(m_sBuffer, iValue);
	return m_sBuffer;
}

int CIuExpressionElement::EvaluateInt(const CIuRecord* pRecord) const
{
	// See notes in CIuExpressionElement::Evaluate()
	LPCTSTR pcszValue = Evaluate(pRecord);
	return StringAsInt(pcszValue);
}

bool CIuExpressionElement::EvaluateBool(const CIuRecord* pRecord) const
{
	// See notes in CIuExpressionElement::Evaluate()
	return EvaluateInt(pRecord) != 0;
}

LPCTSTR CIuExpressionElement::EvaluateChild(int iChild, const CIuRecord* pRecord) const
{
	ASSERT(iChild >= 0);
	if (iChild >= GetChildCount())
		return CString();
	return GetChild(iChild).Evaluate(pRecord);
}

int CIuExpressionElement::EvaluateChildInt(int iChild, const CIuRecord* pRecord) const
{
	ASSERT(iChild >= 0);
	if (iChild >= GetChildCount())
		return 0;
	return GetChild(iChild).EvaluateInt(pRecord);
}

bool CIuExpressionElement::EvaluateChildBool(int iChild, const CIuRecord* pRecord) const
{
	if (iChild >= GetChildCount())
		return false;
	return GetChild(iChild).EvaluateBool(pRecord);
}

int CIuExpressionElement::GetBoughtLevel() const
{
	int iBoughtLevel = 0;
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
		iBoughtLevel = max(iBoughtLevel, GetChild(iChild).GetBoughtLevel());
	return iBoughtLevel;
}

CIuExpressionFormat CIuExpressionElement::GetChildFormat(int iChild) const
{
	if (iChild < 0 || iChild >= GetChildCount())
		return exprFormatString;
	return GetChild(iChild).GetFormat();
}

int CIuExpressionElement::GetChildMaxLength(int iChild) const
{
	if (iChild < 0 || iChild >= GetChildCount())
		return 0;
	return GetChild(iChild).GetMaxLength();
}

int CIuExpressionElement::GetChildMaxLength(int iChild0, int iChild1) const
{
	if (iChild1 < 0)
		iChild1 = GetChildCount();

	int iMaxLength = 0;
	for (; iChild0 <= iChild1; ++iChild0)
	{
		if (iChild0 >= 0 && iChild0 < GetChildCount())
			iMaxLength += GetChild(iChild0).GetMaxLength();
	}
	return iMaxLength;
}

void CIuExpressionElement::GetOperatorNames(CStringArray& as)
{
	static LPCTSTR apcsz[] = 
	{
		_T("!"),
		_T("&"),
		_T("/"),
		_T("*"),
		_T("-"),
		_T("+"),
		_T("AND"),
		_T("OR"),
		_T("=="),
		_T("!="),
		_T(">"),
		_T(">="),
		_T("<"),
		_T("<="),
		_T("CONTAINS"),
		_T("CONTAINSWORD"),
		_T("LIKE"),
		_T("MATCHESFIRST"),
		_T("MATCHESFIRSTINITIAL"),
		_T("MATCHESLAST"),
		_T("MATCHESCITY"),
		_T("SOUNDSLIKE"),
		0
	};

	as.RemoveAll();
	for (int i = 0; apcsz[i]; ++i)
		as.Add(apcsz[i]);
}

int CIuExpressionElement::GetMaxLength() const
{
	return fieldDftLength;
}

LPCTSTR CIuExpressionElement::GetTypeName() const
{
	switch (GetType())
	{
		case exprUnknown:
			return "#Unknown#";
		case exprArg:
			return "#Arg#";
		case exprArgList:
			return "#Arg List#";
		case exprCloseParen:
			return "#Close Paren#";
		case exprComma:
			return "#Comma#";
		case exprExpression:
			return "#Expression#";
		case exprOpenParen:
			return "#Open Paren#";
	}

	// Unknown type...
	ASSERT(false);
	return "#Invalid Type#";
}

bool CIuExpressionElement::IsA(CIuExpressionArray& Array, int i, CIuExpressionType Type)
{
	if (i < 0 || i >= Array.GetSize())
		return false;

	return Array[i]->IsKindOf(Type);
}

bool CIuExpressionElement::IsChildConst(int iChild) const
{
	if (iChild < 0 || iChild >= GetChildCount())
		return true;
	return GetChild(iChild).IsConst();
}

bool CIuExpressionElement::IsConst() const
{
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
		if (!GetChild(iChild).IsConst())
			return false;
	return true;
}

bool CIuExpressionElement::IsKindOf(CIuExpressionType Type) const
{
	return GetType() == Type;
}

void CIuExpressionElement::InsertChild(int iIndex, CIuExpressionElement* pExpressionElement)
{
	ASSERT(pExpressionElement);
	m_array.InsertAt(iIndex, pExpressionElement);
}

void CIuExpressionElement::MakeChild(CIuExpressionArray& Array, int iParent, int iChild1, int iChild2)
{
	ASSERT(iParent >= 0 && iParent < Array.GetSize());
	ASSERT(iChild1 >= 0 && iChild1 < Array.GetSize());
	ASSERT(iChild2 == -1 || (iChild2 >= 0 && iChild2 < Array.GetSize()));
	ASSERT(iChild1 != iChild2);
	CIuExpressionElement* pParent = Array[iParent];
	CIuExpressionElement* pChild1 = Array[iChild1];
	CIuExpressionElement* pChild2 = iChild2 >= 0 ? Array[iChild2]: 0;

	pParent->AddChild(pChild1);
	if (pChild2)
		pParent->AddChild(pChild2);
	if (iChild2 < 0)
		Array.RemoveAt(iChild1);
	else
	{
		// NOTE: Be very careful when removing elements... because all position then shift...
		// Remove the higher indexed child first...
		if (iChild2 > iChild1)
		{
			Array.RemoveAt(iChild2);
			Array.RemoveAt(iChild1);
		}
		else
		{
			Array.RemoveAt(iChild1);
			Array.RemoveAt(iChild2);
		}
	}
}

int CIuExpressionElement::NumericMaxLength() const
{
	return 11;
}

CIuExpressionElement& CIuExpressionElement::operator=(const CIuExpressionElement& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	RemoveAllChildren();
	for (int iChild = 0; iChild < rExpressionElement.GetChildCount(); ++iChild)
		AddChild(rExpressionElement.GetChild(iChild).Clone());
	m_pObjectRepository = rExpressionElement.m_pObjectRepository;
	m_sBuffer = rExpressionElement.m_sBuffer;
	m_Type = rExpressionElement.m_Type;
	m_Format = rExpressionElement.m_Format;
	m_iCaseConvert = rExpressionElement.m_iCaseConvert;
	return *this;
}

CIuExpressionElement* CIuExpressionElement::Optimize()
{
	// This virtual function is special in that the object being
	// called may delete itself! Be careful when doing this. If you 
	// delete yourself, do it as the last thing before exitting.

	// Go through each of the children
	for (int i = 0 ; i < m_array.GetSize(); ++i)
	{
		CIuExpressionElement* pChild = m_array[i]->Optimize();
		ASSERT(pChild);
		m_array.SetAt(i, pChild);
	}

	// Now, check if this object is const
	// If so, convert it to a string literal.
	if (IsConst())
	{
		CIuExpressionLiteral* pLiteral = new CIuExpressionLiteral(Evaluate(0));
		ASSERT(pLiteral);
		delete this;
		return pLiteral;
	}
	return this;
}

CIuExpressionElement* CIuExpressionElement::Parse(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));

	// Skip any leading whitespace or a leading equal sign
	pcsz = _tcsskipws(pcsz);
	if (*pcsz == '=')
	{
		++pcsz;
		pcsz = _tcsskipws(pcsz);

	}

	CIuExpressionArray Array;
	IU_TRY_ERROR
	{
		ParseTokens(pcsz, Array);
		return Reduce(pcsz, Array);
	}
	IU_CATCH_ERROR(e)
	{
		// Empty the Array
		for (int i = 0; i < Array.GetSize(); ++i)
			delete Array[i];
		Array.RemoveAll();

		// Re-throw the exception
		throw e;
	}

	return 0;
}

CIuExpressionElement* CIuExpressionElement::ParseField(LPCTSTR& pcsz)
{
	// Is this a bracketed literal, it is a field specifier
	if (*pcsz != _T('['))
		return 0;

	CString sSubscript;
	LPCTSTR pcszResult = ExtractBracket(pcsz, sSubscript, _T("["), _T("]"));
	if (pcszResult == 0)
		return 0;
	pcsz = pcszResult;
	CString sField = UnBracket(sSubscript, _T("["), _T("]"));
	return new CIuExpressionField(sField);
}

CIuExpressionElement* CIuExpressionElement::ParseIdentifier(LPCTSTR& pcsz)
{
		// Is this an alpha literal
	if (!_istalpha(*pcsz))
		return 0;

	CString s = *pcsz;
	++pcsz;

	for (; *pcsz && (_istalnum(*pcsz) || *pcsz == _T('_')); ++pcsz)
		s += *pcsz;

	// Check for special operators
	if (s.CompareNoCase(_T("MATCHESCITY")) == 0)
		return new CIuExpressionMatches(exprMatchesCity);
	else if (s.CompareNoCase(_T("MATCHESFIRST")) == 0)
		return new CIuExpressionMatches(exprMatchesFirst);
	else if (s.CompareNoCase(_T("MATCHESFIRSTINITIAL")) == 0)
		return new CIuExpressionMatches(exprMatchesFirstInitial);
	else if (s.CompareNoCase(_T("MATCHESLAST")) == 0)
		return new CIuExpressionMatches(exprMatchesLast);
	else if (s.CompareNoCase(_T("LIKE")) == 0)
		return new CIuExpressionLike();
	else if (s.CompareNoCase(_T("CONTAINS")) == 0)
		return new CIuExpressionContains();
	else if (s.CompareNoCase(_T("CONTAINSWORD")) == 0)
		return new CIuExpressionWord();
	else if (s.CompareNoCase(_T("SOUNDSLIKE")) == 0)
		return new CIuExpressionPhonetic();
	else if (s.CompareNoCase(_T("AND")) == 0)
		return new CIuExpressionBool(exprAnd);
	else if (s.CompareNoCase(_T("OR")) == 0)
		return new CIuExpressionBool(exprOr);
	else if (s.CompareNoCase(_T("NOT")) == 0)
		return new CIuExpressionUnary(exprNot);
	else
	{
		CIuExpressionFunction* pFunction = CIuExpressionFunction::CreateFunction(s);
		if (pFunction)
			return pFunction;
	}
	return new CIuExpressionField(s);
}

CIuExpressionElement* CIuExpressionElement::ParseNumeric(LPCTSTR& pcsz)
{
	// Is this the start of a literal numeric?
	if ((*pcsz != _T('-') || !_istdigit(pcsz[1])) && !_istdigit(*pcsz))
		return 0;

	CString s = *pcsz;
	++pcsz;
	for (; *pcsz && _istdigit(*pcsz); ++pcsz)
		s += *pcsz;

	return new CIuExpressionLiteral(s);
}

CIuExpressionElement* CIuExpressionElement::ParseOperator(LPCTSTR& pcsz)
{
	if (pcsz[0] == _T('=') && pcsz[1] == _T('='))
	{
		pcsz += 2;
		return new CIuExpressionCompare(exprEqual);
	}
	else if ((pcsz[0] == _T('!') && pcsz[1] == _T('=')) || (pcsz[0] == _T('<') && pcsz[1] == _T('>')))
	{
		pcsz += 2;			
		return new CIuExpressionCompare(exprNotEqual);
	}
	else if (pcsz[0] == _T('<') && pcsz[1] == _T('='))
	{
		pcsz += 2;			
		return new CIuExpressionCompare(exprLessThanOrEqual);
	}
	else if (pcsz[0] == _T('>') && pcsz[1] == _T('='))
	{
		pcsz += 2;			
		return new CIuExpressionCompare(exprGreaterThanOrEqual);
	}
	else if (pcsz[0] == _T('&') && pcsz[1] == _T('&'))
	{
		pcsz += 2;			
		return new CIuExpressionBool(exprAnd);
	}
	else if (pcsz[0] == _T('|') && pcsz[1] == _T('|'))
	{
		++pcsz;
		return new CIuExpressionBool(exprOr);
	}
	else if (pcsz[0] == _T('='))
	{
		++pcsz;
		return new CIuExpressionCompare(exprEqual);
	}
	else if (pcsz[0] == _T('&'))
	{
		++pcsz;
		return new CIuExpressionConcat();
	}
	else if (pcsz[0] == _T('<'))
	{
		++pcsz;
		return new CIuExpressionCompare(exprLessThan);
	}
	else if (pcsz[0] == _T('>'))
	{
		++pcsz;
		return new CIuExpressionCompare(exprGreaterThan);
	}
	else if (pcsz[0] == _T('+'))
	{
		++pcsz;
		return new CIuExpressionBinary(exprPlus);
	}
	else if (pcsz[0] == _T('-'))
	{
		++pcsz;
		return new CIuExpressionBinary(exprMinus);
	}
	else if (pcsz[0] == _T('/'))
	{
		++pcsz;
		return new CIuExpressionBinary(exprDivide);
	}
	else if (pcsz[0] == _T('*'))
	{
		++pcsz;
		return new CIuExpressionBinary(exprMultiply);
	}
	else if (pcsz[0] == _T('!'))
	{
		++pcsz;
		return new CIuExpressionUnary(exprNot);
	}
	// These next tokens are only generated as an aid to the
	// compiler. They will ultimately be delete.
	else if (pcsz[0] == _T('('))
	{
		++pcsz;
		return new CIuExpressionElement(exprOpenParen);
	}
	else if (pcsz[0] == _T(','))
	{
		++pcsz;
		return new CIuExpressionElement(exprComma);
	}
	else if (pcsz[0] == _T(')'))
	{
		++pcsz;
		return new CIuExpressionElement(exprCloseParen);
	}
	return 0;
}

CIuExpressionElement* CIuExpressionElement::ParseStringLiteral(LPCTSTR& pcsz)
{
	// Is this a quoted string literal
	if (*pcsz != _T('\'') && *pcsz != _T('\"'))
		return 0;
	TCHAR chQuote = *pcsz;
	++pcsz;
	
	CString s;
	for (; *pcsz && *pcsz != chQuote; ++pcsz)
	{
		if (*pcsz == _T('\\'))
		{
			if (pcsz[1] != _T('\0'))
			{
				if (pcsz[1] == _T('n'))
					s += _T('\n');
				else if (pcsz[1] == _T('r'))
					s += _T('\r');
				else if (pcsz[1] == _T('t'))
					s += _T('\t');
				else if (pcsz[1] == _T('\"'))
					s += _T('\"');
				else if (pcsz[1] == _T('\''))
					s += _T('\'');
				else if (pcsz[1] == _T('\\'))
					s += _T('\\');
				else
					s += pcsz[1];
				++pcsz;
			}
		}
		else
			s += *pcsz;
	}

	if (*pcsz == chQuote)
		++pcsz;

	return new CIuExpressionLiteral(s);
}

void CIuExpressionElement::ParseTokens(LPCTSTR pcsz, CIuExpressionArray& Array)
{
	// Keep parsing until everything is used up
	while (*pcsz)
	{
		pcsz = _tcsskipws(pcsz);

		// Get a token
		CIuExpressionElement* pElement;
		pElement = ParseNumeric(pcsz);
		if (pElement == 0)
			pElement = ParseOperator(pcsz);
		if (pElement == 0)
			pElement = ParseField(pcsz);
		if (pElement == 0)
			pElement = ParseStringLiteral(pcsz);
		if (pElement == 0)
			pElement = ParseIdentifier(pcsz);

		// If found, add it to the end of the Array
		if (pElement)
			Array.Add(pElement);
		// Otherwise, spit out an error
		else
			Error(IU_E_EXPRESSION_TEXT_NOT_RECOGNIZED, pcsz);
	}
}

CIuExpressionElement* CIuExpressionElement::Reduce(LPCTSTR pcsz, CIuExpressionArray& Array)
{
	// The following basic tokens are present:
	//		Fields
	//		Literals
	//		Functions
	//			Open parenthesis			(compilation only)
	//			Close parenthesis			(compilation only)
	//			Comma 						(compilation only)
	//			Arg List						(compilation only)
	//			Arg							(compilation only)
	//		Unary operator
	//			! NOT
	//		Binary operators
	//			* /
	//			+ -
	//			&	(concat)
	//		Special
	//			"Like" operator
	//			"Contains" operator
	//			"ContainsWord" operator
	//			"MatchesFirst" operator
	//			"MatchesFirstInitial" operator
	//			"MatchesLast" operator
	//			"MatchesCity" operator
	//			"SoundsLike" (phonetic) operator
	//		Comparison operators
	//			= == != <>
	//			> >=
	//			< <=
	//		Boolean operators
	//			AND &&
	//			OR ||
	//		Expression					(compilation only)
	//	
	//	We keep combining tokens unless we have reduced the list (stack)
	//	to a single token of type "expression".
	//	All evaluation is simply left-to-right
	//
	//	The following reductions are performed asap
	//			String Literal								=>		Expr
	//			Field Literal								=>		Expr
	ReduceLiteral(Array);

	for (;;)
	{
		//		Func+OpenParen+Expr+CloseParen		=>		Expr
		//		Func+ArgList								=>		Expr
		if (ReduceFunction(Array))
			continue;
		//		Unary+Expr									=>		Expr
		if (ReduceUnary(Array))
			continue;
		//		Expr+Mult/Div+Expr						=>		Expr
		if (ReduceMultDiv(Array))
			continue;
		//		Expr+Plus/Minus+Expr						=>		Expr
		if (ReducePlusMinus(Array))
			continue;
		//		Expr+Concat+Expr							=>		Expr
		if (ReduceConcat(Array))
			continue;
		//		Expr+Like+Expr								=>		Expr
		//		Expr+Contains+Expr						=>		Expr
		//		Expr+ContainsWord+Expr					=>		Expr
		//		Expr+MatchesFirst+Expr					=>		Expr
		//		Expr+MatchesFirstInitial+Expr			=>		Expr
		//		Expr+MatchesLast+Expr					=>		Expr
		//		Expr+MatchesCity+Expr					=>		Expr
		//		Expr+SoundsLike+Expr						=>		Expr
		if (ReduceSpecial(Array))
			continue;
		//		Expr+Compare+Expr							=>		Expr
		if (ReduceCompare(Array))
			continue;
		//		Expr+Bool+Expr								=>		Expr
		if (ReduceBool(Array))
			continue;
		//		Open Paren+Expr+Comma+Expr				=>		Open Paren+Arg
		//		Arg+Comma+Expr								=>		Arg
		if (ReduceArg(Array))
			continue;
		//		OpenParen+Arg+CloseParen				=>		ArgList
		if (ReduceArgList(Array))
			continue;
		//		OpenParen+Expr+CloseParen				=>		Expr
		if (ReduceParen(Array))
			continue;

		// If we got here, no reduction were found, we're either done
		//	or we failed.
		break;
	}

	// This can happen when a null expression is parsed
	if (Array.GetSize() == 0)
		return 0;

	// Only one token can remain and it must be an expression
	if (Array.GetSize() != 1 || !IsA(Array, 0, exprExpression))
	{
#ifdef _DEBUG
		TRACE("ERROR: %d tokens on heap\n", Array.GetSize());
		// Do a shallow dump, it is more useful
		for (int i = 0; i < Array.GetSize(); ++i)
			Array[i]->Dump(0, false);
#endif		
		Error(IU_E_EXPRESSION_INVALID, pcsz);
	}

	CIuExpressionElement* pExpression = Array[0];
	pExpression = ReduceExpressions(pExpression);
	pExpression = ReduceCommutative(pExpression);
	return pExpression;
}

bool CIuExpressionElement::ReduceArg(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprOpenParen) && 
			IsA(Array, iToken + 1, exprExpression) && 
			IsA(Array, iToken + 2, exprComma) &&
			IsA(Array, iToken + 3, exprExpression))
		{
			// Make the comma into the arg
			Array[iToken+2]->SetType(exprArg);
			// Make expressions into children 
			MakeChild(Array, iToken + 2, iToken + 1, iToken + 3);
			return true;
		}
		if (IsA(Array, iToken, exprArg) &&
			IsA(Array, iToken + 1, exprComma) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			// Add new expression as child or arg
			MakeChild(Array, iToken, iToken + 2);
			// Delete the comma...
			delete Array[iToken + 1];
			Array.RemoveAt(iToken + 1);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceArgList(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprOpenParen) &&
			IsA(Array, iToken + 1, exprArg) &&
			IsA(Array, iToken + 2, exprCloseParen))
		{
			// Make the arg into the arglist
			Array[iToken+1]->SetType(exprArgList);
			// Delete the parens
			delete Array[iToken + 2];
			Array.RemoveAt(iToken + 2);
			delete Array[iToken];
			Array.RemoveAt(iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceBool(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			IsA(Array, iToken + 1, exprBool) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

CIuExpressionElement* CIuExpressionElement::ReduceCommutative(CIuExpressionElement* pExpression)
{
	// Reduce commutative operators. This would be the various binary and boolean operators.
	//	For example, "A+B+C" gets combined into a single node.

	// First, process our children...
	for (int iChild = 0; iChild < pExpression->GetChildCount(); ++iChild)
		pExpression->m_array.SetAt(iChild, ReduceCommutative(pExpression->m_array[iChild]));

	if (!pExpression->IsKindOf(exprBinary) && !pExpression->IsKindOf(exprBool))
		return pExpression;

	ASSERT(pExpression->GetChildCount() >= 2);

	// If our non-left-most children are of the same type, move them up
	for (iChild = 1; iChild < pExpression->GetChildCount(); )
	{
		if (pExpression->GetType() == pExpression->GetChild(iChild).GetType())
		{
			// Insert children directly into parent
			CIuExpressionElement* pChild = pExpression->DetachChild(iChild);
			for (int iInsert = iChild; pChild->GetChildCount(); ++iInsert)
				pExpression->InsertChild(iInsert, pChild->DetachChild(0));

			// Delete the child node... it is now empty
			delete pChild;
		}
		else
			++iChild;
	}

	// If we can combine with our left-most child, make it the parent, add our other children to it,
	// and continue processing with that child
	if (pExpression->GetType() == pExpression->GetChild(0).GetType())
	{
		CIuExpressionElement* pChild = pExpression->DetachChild(0);
		while (pExpression->GetChildCount())
			pChild->AddChild(pExpression->DetachChild(0));

		// Delete ourself
		delete pExpression;

		// Continue processing with our left most child
		return ReduceCommutative(pChild);
	}

	return pExpression;
}

bool CIuExpressionElement::ReduceCompare(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			IsA(Array, iToken + 1, exprCompare) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceConcat(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			IsA(Array, iToken + 1, exprConcatenation) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

CIuExpressionElement* CIuExpressionElement::ReduceExpressions(CIuExpressionElement* pExpression)
{
	// All of the "expression" objects are placeholders....
	// We now remove them.
	ASSERT(pExpression);

	// If this is an expression, delete this and return our child.
	if (pExpression->GetType() == exprExpression)
	{
		ASSERT(pExpression->GetChildCount() == 1);
		CIuExpressionElement* pChild = pExpression->DetachChild(0);
		delete pExpression;
		return ReduceExpressions(pChild);
	}

	// Otherwise, process our children
	for (int iChild = 0; iChild < pExpression->GetChildCount(); ++iChild)
		pExpression->m_array.SetAt(iChild, ReduceExpressions(pExpression->m_array[iChild]));

	return pExpression;
}

bool CIuExpressionElement::ReduceFunction(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprFunction) &&
			IsA(Array, iToken + 1, exprOpenParen) &&
			IsA(Array, iToken + 2, exprExpression) &&
			IsA(Array, iToken + 3, exprCloseParen))
		{
			// Make expression a child of the function
			ASSERT(Array[iToken + 2]->GetChildCount() == 1);
			Array[iToken]->AddChild(Array[iToken + 2]->DetachChild(0));

			// Delete the parens & expr (which is now empty)
			delete Array[iToken + 3];
			Array.RemoveAt(iToken + 3);
			delete Array[iToken + 2];
			Array.RemoveAt(iToken + 2);
			delete Array[iToken + 1];
			Array.RemoveAt(iToken + 1);

			// Convert the function to an expression
			ConvertToExpression(Array, iToken);
			return true;
		}
		// Function without arguments, e.g. Tab()
		if (IsA(Array, iToken, exprFunction) &&
			IsA(Array, iToken + 1, exprOpenParen) &&
			IsA(Array, iToken + 2, exprCloseParen))
		{
			// Delete the parens
			delete Array[iToken + 2];
			Array.RemoveAt(iToken + 2);
			delete Array[iToken + 1];
			Array.RemoveAt(iToken + 1);

			// Convert the function to an expression
			ConvertToExpression(Array, iToken);
			return true;
		}
		if (IsA(Array, iToken, exprFunction) &&
			IsA(Array, iToken + 1, exprArgList))
		{
			// Move the children from the arglist to the function
			while (Array[iToken+1]->GetChildCount())
				Array[iToken]->AddChild(Array[iToken + 1]->DetachChild(0));
			// Delete the arglist (which is now empty)
			delete Array[iToken + 1];
			Array.RemoveAt(iToken + 1);
			// Convert the function to an expression
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceLiteral(CIuExpressionArray& Array)
{
	// Convert all on first pass....
	// No need to ever try again
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprStringLiteral) || IsA(Array, iToken, exprFieldLiteral))
			ConvertToExpression(Array, iToken);
	}
	return false;
}

bool CIuExpressionElement::ReduceMultDiv(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			(IsA(Array, iToken + 1, exprMultiply) || IsA(Array, iToken + 1, exprDivide)) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceParen(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprOpenParen) &&
			IsA(Array, iToken + 1, exprExpression) &&
			IsA(Array, iToken + 2, exprCloseParen))
		{
			// Delete the parens
			delete Array[iToken + 2];
			Array.RemoveAt(iToken + 2);
			delete Array[iToken];
			Array.RemoveAt(iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReducePlusMinus(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			(IsA(Array, iToken + 1, exprPlus) || IsA(Array, iToken + 1, exprMinus)) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceSpecial(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprExpression) && 
			(IsA(Array, iToken + 1, exprMatchesFirst) ||
			IsA(Array, iToken + 1, exprMatchesFirstInitial) ||
			IsA(Array, iToken + 1, exprMatchesLast) || 
			IsA(Array, iToken + 1, exprMatchesCity) || 
			IsA(Array, iToken + 1, exprLike) || 
			IsA(Array, iToken + 1, exprContains) ||
			IsA(Array, iToken + 1, exprContainsWord) ||
			IsA(Array, iToken + 1, exprSoundsLike)) &&
			IsA(Array, iToken + 2, exprExpression))
		{
			MakeChild(Array, iToken + 1, iToken, iToken + 2);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

bool CIuExpressionElement::ReduceUnary(CIuExpressionArray& Array)
{
	for (int iToken = 0; iToken < Array.GetSize(); ++iToken)
	{
		if (IsA(Array, iToken, exprUnary) && 
			IsA(Array, iToken + 1, exprExpression))
		{
			MakeChild(Array, iToken, iToken + 1);
			ConvertToExpression(Array, iToken);
			return true;
		}
	}
	return false;
}

void CIuExpressionElement::RemoveAllChildren()
{
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
		delete m_array[iChild];
	m_array.RemoveAll();
}

void CIuExpressionElement::Resolve(CIuResolveSpec& Spec)
{
	SetCaseConvert(Spec.m_iCaseConvert);
	SetObjectRepository(Spec.m_pObjectRepository);
	// Resolve each of the children
	int iCount = GetChildCount();
	for (int i = 0 ; i < iCount; ++i)
		GetChild(i).Resolve(Spec);
}

void CIuExpressionElement::SetCaseConvert(int iCaseConvert)
{
	m_iCaseConvert = iCaseConvert;
}

void CIuExpressionElement::SetFormat(CIuExpressionFormat Format)
{
	m_Format = Format;
}

void CIuExpressionElement::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	m_pObjectRepository = pObjectRepository;
}

void CIuExpressionElement::SetType(CIuExpressionType Type)
{
	m_Type = Type;
}

