#include "StdAfx.h"
//{{Include
#include "GeoExchange.h"
#include "GeoRawExchange.h"
#include "Exchange.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "RegEx.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoExchange, CIuGeoExchange_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoExchange)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOEXCHANGE, CIuGeoExchange, CIuGeoExchange_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoExchange::CIuGeoExchange() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoExchange::~CIuGeoExchange()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}


void CIuGeoExchange::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoExchange"));
	//}}Initialize
}

void CIuGeoExchange::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter = RegEx.CreateLikeClause(_T("Exchange"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoExchange::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoExchange::GetIndexStatic() 
{
	return _T("Exchange");
}

void CIuGeoExchange::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoExchange);
}

int CIuGeoExchange::GetSourceType() const
{
	return sourceGeoCollectionExchange;
}

void CIuGeoExchange::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoExchange::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawExchange& Exchange = *dynamic_cast<CIuGeoRawExchange*>(&Element);
	ASSERT(&Exchange);

	int iExpandedSize = sizeof(CIuExchange);
	ASSERT(iExpandedSize == 12);

	CString sName = Exchange.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CString sTitle = Exchange.GetTitle();
	CheckField(sTitle);
	CIuNybbleString::Append(sTitle, -1, NS_ALPHA, Buffer);
	iExpandedSize += sTitle.GetLength() + 1;

	iExpandedSize += CIuGeoList::Compress(Exchange.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize;
}

int CIuGeoExchange::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuExchange* pExchange = (CIuExchange*)AddElement(sizeof(CIuExchange));

	// Decompress the various strings
	CIuStaticBuffer256 BufferExchange;
	iOffset += CIuNybbleString::Get(BufferExchange, -1, true, NS_ALPHA, Buffer, iOffset);
	pExchange->m_iExchange = StringAsInt(LPCTSTR(BufferExchange.GetPtr()));

	CIuStaticBuffer256 BufferExchangeName;
	iOffset += CIuNybbleString::Get(BufferExchangeName, -1, true, NS_ALPHA, Buffer, iOffset);

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferExchange.GetPtr()));
	AddElementString(LPCTSTR(BufferExchangeName.GetPtr()));
	AddElementStringTerm();

	return iOffset;
}

