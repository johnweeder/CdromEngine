#include "stdafx.h"
#include "Interop\VersionInfo.h"
#include <afxdllx.h>
#include "Engine\Samples.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace
{
	static AFX_EXTENSION_MODULE IuEngineDLL = { NULL, NULL };
};

IU_API_EXPORT void IuEngineInit()
{
	// Do not attempt to wrap this function in a guard.
	// Any number of MFC DLL's may need to call this in order to 
	// add this extension DLL to their resource chain.
	new CDynLinkLibrary(IuEngineDLL);
}

void IU_API_EXPORT IuEngineInfo(CIuVersionInfo& VersionInfo)
{
	ASSERT(IuEngineDLL.hModule);
	VersionInfo.Load(IuEngineDLL.hModule);
}

IU_REGISTER_DLL_INFO(IuEngineInfo)

extern "C" int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("iuEngine.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(IuEngineDLL, hInstance))
			return 0;

		IuEngineInit();
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		CIuEngineSamples::TerminateEngine();

		TRACE0("iuEngine.DLL Terminating!\n");
		// Terminate the library before destructors are called
		AfxTermExtensionModule(IuEngineDLL);
	}
	return 1;   // ok
}
