#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Meter.h"
#include "Meters.h"
#include "Registration.h"
#include "RegistrationSpec.h"
#include "CdromSpecConst.h"
#include "Cdrom.h"
#include "..\Registration\Registrar.h"
#include "..\Registration\RegistrarData.h"
#include "resource.h"
#include "Common\Registry.h"
#include "Error\Error.h"
#include "..\Version.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Ids.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRegistration, CIuRegistration_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuRegistration)
const DWORD dwIdentifier		= 0x53FD38A0;
const DWORD dwVersion1			= 1;
const DWORD dwCurrentVersion	= 1;

// Attribute id's. NOTE: Default value is always assumed to be zero!
const DWORD dwRegistered		= 0x000000001;
const DWORD dwRemainingRuns	= 0x000000002;

const	CIuVersionNumber versionRegistrationMax(2000,1,5,304);
const	CIuVersionNumber versionRegistrationMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REGISTRATION, CIuRegistration, CIuRegistration_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuRegistration, IDS_ENGINE_PPG_REGISTRATION, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PRODUCTNAME, GetProductName, SetProductName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PRODUCTNAME, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PRODUCTID, GetProductID, SetProductID, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PRODUCTID, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRegistration, IDS_ENGINE_PROP_MAXRUNS, GetMaxRuns, SetMaxRuns, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRegistration, IDS_ENGINE_PROP_MAXRUNS, IDS_ENGINE_PPG_REGISTRATION, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_FAXPHONE, GetFaxPhone, SetFaxPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_FAXPHONE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_MAILADDRESS, GetMailAddress, SetMailAddress, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_MAILADDRESS, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_URL, GetURL, SetURL, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_URL, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuRegistration, IDS_ENGINE_PROP_VALIDRESPONSES, GetValidResponses, SetValidResponses, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuRegistration, IDS_ENGINE_PROP_VALIDRESPONSES, IDS_ENGINE_PPG_REGISTRATION, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_ACTION(CIuRegistration, IDS_ENGINE_ACTION_REGISTER, ActionRegister, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuRegistration, IDS_ENGINE_ACTION_REGISTER, IDS_ENGINE_PPG_REGISTRATION, editorAutoUpdate)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONE, GetModemPhone, SetModemPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONECOUNTRYCODE, GetModemPhoneCountryCode, SetModemPhoneCountryCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONECOUNTRYCODE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONEAREACODE, GetModemPhoneAreaCode, SetModemPhoneAreaCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_MODEMPHONEAREACODE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_VOICEPHONE, GetVoicePhone, SetVoicePhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_VOICEPHONE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_ID(CIuRegistration, IDS_ENGINE_PROP_METER, GetMeterID, SetMeterID, 0)
	IU_ATTRIBUTE_EDITOR_ID(CIuRegistration, IDS_ENGINE_PROP_METER, IDS_ENGINE_PPG_REGISTRATION, 0)

	// Obsolete attributes
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONE, GetVoicePhone, SetVoicePhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONEAREACODE, GetModemPhoneAreaCode, SetModemPhoneAreaCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONEAREACODE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONECOUNTRYCODE, GetModemPhoneCountryCode, SetModemPhoneCountryCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONECOUNTRYCODE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONEPHONE, GetModemPhone, SetModemPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistration, IDS_ENGINE_PROP_PHONEPHONE, IDS_ENGINE_PPG_REGISTRATION, 1, 0)
	// Obsolete attributes

//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRegistration::CIuRegistration()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRegistration::CIuRegistration(const CIuRegistration& rRegistration)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rRegistration;
}

CIuRegistration::~CIuRegistration()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuRegistration::ActionRegister(const CIuPropertyCollection&, CIuOutput& Output)
{
	return CString(Register(Output.GetParentWnd()) ? _T("Success"): _T("Failure"));
}

bool CIuRegistration::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

void CIuRegistration::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pObjectRepository = 0;
	m_iMaxRuns = -1;
	SetVersion(versionRegistrationMax);
	m_sModemPhone = "ModemPhone";
	m_sModemPhoneCountryCode = "ModemPhoneCountryCode";
	m_sModemPhoneAreaCode = "ModemPhoneAreaCode";
	m_sVoicePhone = "VoicePhone";
	m_pEngine = 0;
	m_fDebug = false;
	//}}Initialize
}

void CIuRegistration::Copy(const CIuObject& object)
{
	CIuRegistration_super::Copy(object);

	const CIuRegistration* pRegistration = dynamic_cast<const CIuRegistration*>(&object);
	if (pRegistration == 0 || pRegistration == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuRegistration)));
	m_sProductName = pRegistration->m_sProductName;
	m_sProductID = pRegistration->m_sProductID;
	m_iMaxRuns = pRegistration->m_iMaxRuns;
	m_sFaxPhone = pRegistration->m_sFaxPhone;
	m_sMailAddress = pRegistration->m_sMailAddress;
	m_sURL = pRegistration->m_sURL;
	m_sVoicePhone = pRegistration->m_sVoicePhone;
	m_sModemPhoneAreaCode = pRegistration->m_sModemPhoneAreaCode;
	m_sModemPhoneCountryCode = pRegistration->m_sModemPhoneCountryCode;
	m_sModemPhone = pRegistration->m_sModemPhone;
	m_idMeter = pRegistration->m_idMeter;
	m_asValidResponses.Copy(pRegistration->m_asValidResponses);
	m_fDebug = pRegistration->m_fDebug;
}

CIuMeterPtr CIuRegistration::GetMeter() const
{
	ASSERT(HasEngine());
	if (!HasEngine())
		return CIuMeterPtr();
	CIuMeters& Meters = GetEngine().GetMeters();
	int iMeter = Meters.Find(GetMeterID());
	ASSERT(iMeter >= 0);
	if (iMeter < 0)
		return CIuMeterPtr();
	CIuMeterPtr pMeter = &Meters.Get(iMeter);
	ASSERT(pMeter.NotNull());
	if (!pMeter->IsOpen())
		pMeter->Open();
	return pMeter;
}

int CIuRegistration::GetRemainingRuns() const
{
	CIuMeterPtr pMeter = GetMeter();
	if (pMeter.IsNull())
		return m_iMaxRuns;
	return pMeter->GetRemainingRuns(m_iMaxRuns);
}

void CIuRegistration::GetValidResponses(CStringArray& as) const
{
	as.Copy(m_asValidResponses);
}

CIuVersionNumber CIuRegistration::GetVersionMax() const
{
	return versionRegistrationMax;
}

CIuVersionNumber CIuRegistration::GetVersionMaxStatic()
{
	return versionRegistrationMax;
}

CIuVersionNumber CIuRegistration::GetVersionMin() const
{
	return versionRegistrationMin;
}

CIuVersionNumber CIuRegistration::GetVersionMinStatic()
{
	return versionRegistrationMin;
}

bool CIuRegistration::IsRegistered() const
{
	CIuMeterPtr pMeter = GetMeter();
	if (pMeter.IsNull())
		return false;
	return pMeter->GetRegistered();
}

CIuRegistration& CIuRegistration::operator=(const CIuRegistration& rRegistration)
{
	Copy(rRegistration);
	return *this;
}

bool CIuRegistration::Register(CWnd* pParent, bool fAutoDecrement)
{
	CIuRegistrarData RegistrationData;
	RegistrationData.m_pParentWindow = pParent;
	RegistrationData.m_ProductInformation.m_strProductID = m_sProductID;
	if (m_iMaxRuns < 0)
		RegistrationData.m_ProductInformation.m_iNumberOfProgramRunsLeft = -1;
	else
		RegistrationData.m_ProductInformation.m_iNumberOfProgramRunsLeft = GetRemainingRuns();
	RegistrationData.m_ProductInformation.m_strModemRegistrationPhone_CountryCode = m_sModemPhoneCountryCode;
	RegistrationData.m_ProductInformation.m_strModemRegistrationPhone_AreaCode = m_sModemPhoneAreaCode;
	RegistrationData.m_ProductInformation.m_strModemRegistrationPhone_Phone = m_sModemPhone;
	RegistrationData.m_ProductInformation.m_strVoiceRegistrationPhone = m_sVoicePhone;
	RegistrationData.m_ProductInformation.m_strFaxRegistrationNumber = m_sFaxPhone;
	RegistrationData.m_ProductInformation.m_strMailRegistrationAddress = m_sMailAddress;
	RegistrationData.m_ProductInformation.m_strValidRegistrationCodes.Copy(m_asValidResponses);
	RegistrationData.m_ProductInformation.m_strProductName = m_sProductName;
	RegistrationData.m_ProductInformation.m_strRegisterURL = m_sURL;

	RegistrationData.m_fDebug = m_fDebug;
	int iRights = GetEngine().GetUserRights();
	if ((iRights & engineRightsMeterAdmin) != 0)
		RegistrationData.m_fDebug = true;

	CIuRegistrar Registrar;
	bool fSuccess = Registrar.Register(&RegistrationData, 0);
	TRACE("REGISRATION: %s\n", fSuccess ? _T("Succeeded"): _T("Failed!"));

	if (fAutoDecrement)
	{
		int iRemainingRuns = GetRemainingRuns();
		iRemainingRuns = max(0, iRemainingRuns - 1);
		SetRemainingRuns(iRemainingRuns);
	}

	if (fSuccess)
		SetRegistered(true);

	CIuMeterPtr pMeter = GetMeter();
	if (pMeter.NotNull())
		pMeter->Flush();

	return fSuccess;
}

void CIuRegistration::SetDebug(bool f)
{
	m_fDebug = f;
}

void CIuRegistration::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuRegistration::SetFaxPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFaxPhone = pcsz;
}

void CIuRegistration::SetMailAddress(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMailAddress = pcsz;
}

void CIuRegistration::SetMaxRuns(int iMaxRuns)
{
	m_iMaxRuns = iMaxRuns;
}

void CIuRegistration::SetMeterID(CIuID id)
{
	m_idMeter = id;
}

void CIuRegistration::SetModemPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhone = pcsz;
}

void CIuRegistration::SetModemPhoneAreaCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhoneAreaCode = pcsz;
}

void CIuRegistration::SetModemPhoneCountryCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhoneCountryCode = pcsz;
}

void CIuRegistration::SetName(LPCTSTR pcszName)
{
	CIuRegistration_super::SetName(pcszName);

	// When we moved the security logic to separate code,
	// we needed to update old objects to use the meter instead
	// of their built-in security logic. We added a hack here
	// Move registration data from separate key to meter
	ASSERT(AfxIsValidString(pcszName));
	if (_tcsicmp(pcszName, _T("88md")) == 0)
		SetMeterID(idMeter_88md_2001);
	else if (_tcsicmp(pcszName, _T("Ac")) == 0)
		SetMeterID(idMeter_Ac_V1);
	else if (_tcsicmp(pcszName, _T("Bml")) == 0)
		SetMeterID(idMeter_Bml_2000);
	else if (_tcsicmp(pcszName, _T("Ci")) == 0)
		SetMeterID(idMeter_Ci_V1);
	else if (_tcsicmp(pcszName, _T("Pbm")) == 0)
		SetMeterID(idMeter_Pbm_V1);
	else if (_tcsicmp(pcszName, _T("Pf")) == 0)
		SetMeterID(idMeter_Pf_2000);
	else if (_tcsicmp(pcszName, _T("PfUsa")) == 0)
		SetMeterID(idMeter_Pu_2000);
	else if (_tcsicmp(pcszName, _T("Rp")) == 0)
		SetMeterID(idMeter_Rp_2001);
	else if (_tcsicmp(pcszName, _T("Sample")) == 0)
		SetMeterID(idMeter_Sample);
	else if (_tcsicmp(pcszName, _T("Slu")) == 0)
		SetMeterID(idMeter_Slu_2000);
	else if (_tcsicmp(pcszName, _T("Ypu")) == 0)
		SetMeterID(idMeter_Ypu_2001);
}

void CIuRegistration::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuRegistration::SetProductID(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sProductID = pcsz;
}

void CIuRegistration::SetProductName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sProductName = pcsz;
}

void CIuRegistration::SetRegistered(bool f)
{
	CIuMeterPtr pMeter = GetMeter();
	if (pMeter.NotNull())
	{
		pMeter->SetRegistered(f);
		pMeter->Flush();
	}
}

void CIuRegistration::SetRemainingRuns(int iRemainingRuns)
{
	CIuMeterPtr pMeter = GetMeter();
	if (pMeter.NotNull())
	{
		pMeter->SetRemainingRuns(iRemainingRuns);
		pMeter->Flush();
	}
}

void CIuRegistration::SetSpec(CIuRegistrationSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());
	SetFaxPhone(Spec.GetFaxPhone());
	SetMailAddress(Spec.GetMailAddress());
	SetMaxRuns(Spec.GetMaxRuns());
	SetVoicePhone(Spec.GetVoicePhone());
	SetModemPhoneAreaCode(Spec.GetModemPhoneAreaCode());
	SetModemPhoneCountryCode(Spec.GetModemPhoneCountryCode());
	SetModemPhone(Spec.GetModemPhone());
	SetProductID(Spec.GetProductID());
	SetProductName(Spec.GetProductName());
	SetURL(Spec.GetURL());
	SetMeterID(Spec.GetMeter());
	CStringArray as;
	Spec.GetValidResponses(as);
	SetValidResponses(as);
}

void CIuRegistration::SetURL(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sURL = pcsz;
}

void CIuRegistration::SetValidResponses(const CStringArray& as)
{
	m_asValidResponses.Copy(as);
}

void CIuRegistration::SetVoicePhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sVoicePhone = pcsz;
}
