#ifndef _ENGINE_INPUTDELIMITED_H_
#define _ENGINE_INPUTDELIMITED_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTPHYSICALFILE_H_
#	include "Engine\InputPhysicalFile.h"
#endif	// _ENGINE_INPUTPHYSICALFILE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputDelimited)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputDelimited, CIuInputPhysicalFile }}
#define CIuInputDelimited_super CIuInputPhysicalFile

class CIuInputDelimited : public CIuInputDelimited_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputDelimited)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputDelimited();
	virtual ~CIuInputDelimited();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuFilename GetFullInputFilename() const;
	LPCTSTR GetInput(int iField) const;
	int GetInputs() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnMoveNext();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void AddInput(LPCTSTR pcsz, int cb);
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iFields;
	int m_aiOffset[recordMaxFields];
	CIuBuffer m_Buffer;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline LPCTSTR CIuInputDelimited::GetInput(int iField) const
{
	if (iField < 0 || iField >= m_iFields)
		return "";
	return LPCTSTR(m_Buffer.GetPtr(m_aiOffset[iField]));
}

inline int CIuInputDelimited::GetInputs() const
{
	return m_iFields;
}

#endif // _ENGINE_INPUTDELIMITED_H_
