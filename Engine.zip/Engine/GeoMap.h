#ifndef _ENGINE_GEOMAP_H_
#define _ENGINE_GEOMAP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoMap)
class CIuGeoSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoMap, CIuCollectable }}
#define CIuGeoMap_super CIuCollectable

class CIuGeoMap : public CIuGeoMap_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoMap)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoMap();
	virtual ~CIuGeoMap();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetCity() const;
	CString GetCountyCode() const;
	CString GetLatitude() const;
	CString GetLongitude() const;
	CString GetMatchLevel() const;
	CString GetMsaCode() const;
	CString GetState() const;
	CString GetZip() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	void Resolve(CIuResolveSpec& Spec);
	void Set(CIuRecordPtr& pRecordOut, const CIuRecord& RecordIn) const;
	void SetCity(LPCTSTR);
	void SetCountyCode(LPCTSTR);
	void SetLatitude(LPCTSTR);
	void SetLongitude(LPCTSTR);
	void SetMatchLevel(LPCTSTR);
	void SetMsaCode(LPCTSTR);
	void SetSpec(CIuGeoSpec& Spec);
	void SetState(LPCTSTR);
	void SetZip(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
protected:
	virtual void CreateMap(CIuFieldMap& map);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// The offsets of the fields in the resolved record definition
	// These are public for enhanced performance.
	int m_iZip;
	int m_iCity;
	int m_iState;
	int m_iMsaCode;
	int m_iCountyCode;
	int m_iLatitude;
	int m_iLongitude;
	int m_iMatchLevel;
private:
	// The names of the fields
	CString m_sZip;
	CString m_sCity;
	CString m_sState;
	CString m_sMsaCode;
	CString m_sCountyCode;
	CString m_sLatitude;
	CString m_sLongitude;
	CString m_sMatchLevel;
	// The record definition and the field mapping
	CIuFieldMap m_Map;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuGeoMap::GetCity() const
{
	return m_sCity;
}

inline CString CIuGeoMap::GetCountyCode() const
{
	return m_sCountyCode;
}

inline CString CIuGeoMap::GetLatitude() const
{
	return m_sLatitude;
}

inline CString CIuGeoMap::GetLongitude() const
{
	return m_sLongitude;
}

inline CString CIuGeoMap::GetMatchLevel() const
{
	return m_sMatchLevel;
}

inline CString CIuGeoMap::GetMsaCode() const
{
	return m_sMsaCode;
}

inline CString CIuGeoMap::GetState() const
{
	return m_sState;
}

inline CString CIuGeoMap::GetZip() const
{
	return m_sZip;
}

inline void CIuGeoMap::Set(CIuRecordPtr& pRecordOut, const CIuRecord& RecordIn) const
{
	pRecordOut.Map(RecordIn, m_Map);
}

#endif // _ENGINE_GEOMAP_H_
