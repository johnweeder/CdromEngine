#ifndef _ENGINE_COMPAREWORD_H_
#define _ENGINE_COMPAREWORD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_STRINGBUFFER_H_
#	include "Common\StringBuffer.h"
#endif	// _COMMON_STRINGBUFFER_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

// Maximum number of words allowed in a compare...
const int MaxCompareWords = 32;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCompareWord, CObject }}
#define CIuCompareWord_super CObject

class CIuCompareWord : public CIuCompareWord_super
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCompareWord();
	CIuCompareWord(const CIuCompareWord& rCompareWord);
	virtual ~CIuCompareWord();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Compare(LPCTSTR pcsz) const;
	void SetExpression(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuCompareWord& operator=(const CIuCompareWord& rCompareWord);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The original expression
	CString m_sExpression;
	// Number of words
	int m_iWords;
	// A buffer containing a series of strings to match
	CIuStringBuffer m_Buffer;
	// Wildcarded?
	bool m_afWildcarded[MaxCompareWords];
	// An array of pointers to the start of each word
	LPCTSTR m_apcsz[MaxCompareWords];
	// Length of each word
	int m_aiLength[MaxCompareWords];
	// Matched?
	mutable bool m_afMatched[MaxCompareWords];
//}}Data

};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_COMPAREWORD_H_
