#ifndef _ENGINE_EXPORTINSTANCE_H_
#define _ENGINE_EXPORTINSTANCE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportInstance)
class CIuExport;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportInstance, CIuObject }}
#define CIuExportInstance_super CIuObject
class CIuExportInstance : public CIuExportInstance_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportInstance)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportInstance();
	virtual ~CIuExportInstance();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual int Export(CIuExport&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_EXPORTINSTANCE_H_
