#include "StdAfx.h"
//{{Include
#include "RecordDefSpecDft.h"
#include "RecordDef.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

static const CIuRecordDefSpecDft AddressDft =
{
	_T("Address"), recordDefAddress,
	-1,
	{
		"=StateAbbr(2)",
		"=City(28)",
		"=Street(40)",
		"=PriNo(15)",
		"=SecNo(20)",							
		0,
	}
};

static const CIuRecordDefSpecDft AreaCodeUpdateDft =
{
	_T("AreaCodeUpdate"), recordDefAreaCodeUpdate,
	-1,
	{
		"=AreaCode(3)",
		"=AreaCodeName(30)",
		0,
	}
};

static const CIuRecordDefSpecDft BusinessDft =
{
	_T("Business"), recordDefBusiness,
	-1,
	{
		"=SicCode(6)",
		0,
	}
};

static const CIuRecordDefSpecDft CensusDft =
{
	_T("Census"), recordDefCensus,
	-1,
	{
		"=ZIP(5)",
		"=MedianIncome(10)",
		"=MedianHV(10)",
		0,
	}
};

static const CIuRecordDefSpecDft CountyUpdateDft =
{
	_T("CountyUpdate"), recordDefCountyUpdate,
	-1,
	{
		"=CountyCode(5)",
		"=CountyName(15)",
		0,
	}
};

static const CIuRecordDefSpecDft ExchangeUpdateDft =
{
	_T("ExchangeUpdate"), recordDefExchangeUpdate,
	-1,
	{
		"=Exchange(6)",
		"=ExchangeName(40)",
		0,
	}
};

static const CIuRecordDefSpecDft FranchiseDft =
{
	_T("Franchise"), recordDefFranchise,
	-1,
	{
		"=SicCode(6)",
		"=FranchiseCode(1)",
		"=FranchiseName(40)",
		0,
	}
};

static const CIuRecordDefSpecDft GeoAreaCodeDft =
{
	_T("GeoAreaCode"), recordDefGeoAreaCode,
	-1,
	{
		"=AreaCode(3)",
		"=AreaCodeName(30)",
		0,
	}
};

static const CIuRecordDefSpecDft GeoCityDft =
{
	_T("GeoCity"), recordDefGeoCity,
	-1,
	{
		"=StateCity",
		"=City",
		"=StateAbbr",
		0,
	}
};

static const CIuRecordDefSpecDft GeoCountyDft =
{
	_T("GeoCounty"), recordDefGeoCounty,
	-1,
	{
		// These are raw input
		"=CountyCode(5)",
		"=CountyName(15)",
		// These are generated
		"=StateAbbr(2)",
		0,
	}
};

static const CIuRecordDefSpecDft GeoExchangeDft =
{
	_T("GeoExchange"), recordDefGeoExchange,
	-1,
	{
		"=Exchange(6)",
		"=ExchangeName(40)",
		0,
	}
};

static const CIuRecordDefSpecDft GeoMsaDft =
{
	_T("GeoMsa"), recordDefGeoMsa,
	-1,
	{
		"=MsaCode(4)",
		"=MsaName(64)",
		0,
	}
};

static const CIuRecordDefSpecDft GeoStateDft =
{
	_T("GeoState"), recordDefGeoState,
	-1,
	{
		"=StateAbbr",
		"=StateName",
		"=StateCode",
		0,
	}
};

static const CIuRecordDefSpecDft GeoZipDft =
{
	_T("GeoZip"), recordDefGeoZip,
	-1,
	{
		"=Zip(5)",
		0,
	}
};

static const CIuRecordDefSpecDft MsaUpdateDft =
{
	_T("MsaUpdate"), recordDefMsaUpdate,
	-1,
	{
		"=MsaCode(4)",
		"=MsaName(64)",
		0,
	}
};

static const CIuRecordDefSpecDft PhoneDft =
{
	_T("Phone"), recordDefPhone,
	-1,
	{
		"=AcPhone(10)",
		0,
	}
};

static const CIuRecordDefSpecDft SicDft =
{
	_T("Sic"), recordDefSic,
	-1,
	{
		"=SicCode(6)",
		"=SicName(40)",
		"=Count(40)",
		0,
	}
};

static const CIuRecordDefSpecDft SicDescriptionDft =
{
	_T("SicDescription"), recordDefSicDescription,
	-1,
	{
		"=SicCode(6)",
		"=SicName(40)",
		"Primary(1):",
		0,
	}
};

static const CIuRecordDefSpecDft SicSeeAlsoDft =
{
	_T("SicSeeAlso"), recordDefSicSeeAlso,
	-1,
	{
		"=SicCode(6)",
		"Alt1(40):",
		"Alt2(40):",
		"Alt3(40):",
		0,
	}
};

static const CIuRecordDefSpecDft ZipDft =
{
	_T("Zip"), recordDefZip,
	-1,
	{
		"=Zip(12)",
		0,
	}
};

static const CIuRecordDefSpecDft Zip4Dft =
{
	_T("Zip4"), recordDefZip4,
	-1,
	{
		"=Zip(9)",
		0,
	}
};

static const CIuRecordDefSpecDft Zip5Dft =
{
	_T("Zip5"), recordDefZip5,
	-1,
	{
		"=Zip(5)",
		0,
	}
};

static const CIuRecordDefSpecDft ZipCentroidDft = 
{
	_T("ZipCentroid"), recordDefZipCentroid,
	-1,
	{
		"=Zip(5)",
		"=Latitude(9)",
		"=Longitude(9)",
		0,
	}
};

static const CIuRecordDefSpecDft* apRecordDef[] =
{
	&AddressDft,
	&AreaCodeUpdateDft,
	&CountyUpdateDft,
	&CensusDft,
	&BusinessDft,
	&ExchangeUpdateDft,
	&FranchiseDft,
	&GeoAreaCodeDft,
	&GeoCountyDft,
	&GeoCityDft,
	&GeoExchangeDft,
	&GeoMsaDft,
	&GeoStateDft,
	&GeoZipDft,
	&MsaUpdateDft,
	&PhoneDft,
	&SicDft,
	&SicDescriptionDft,
	&SicSeeAlsoDft,
	&ZipDft,
	&Zip4Dft,
	&Zip5Dft,
	&ZipCentroidDft,
};


/////////////////////////////////////////////////////////////////////////////
// CIuRecordDefSpecDft

int CIuRecordDefSpecDft::Find(LPCTSTR pcszRecordDef)
{
	ASSERT(AfxIsValidString(pcszRecordDef));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszRecordDef, pcszRecordDef) == 0)
			return i;
	}
	return -1;
}

int CIuRecordDefSpecDft::Find(int iRecordDef)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iRecordDef == iRecordDef)
			return i;
	}
	return -1;
}

const CIuRecordDefSpecDft* CIuRecordDefSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return apRecordDef[iWhich];
}

int CIuRecordDefSpecDft::GetCount()
{
	return sizeof(apRecordDef) / sizeof(apRecordDef[0]);
}
