#include "StdAfx.h"
//{{Include
#include "ReleaseNotes.h"
#include "ReleaseNote.h"
#include "Engine.h"
#include "resource.h"
#include "CdromSpec.h"
#include "CdromSpecConst.h"
#include "Cdrom.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuReleaseNotes, CIuReleaseNotes_super)
IU_IMPLEMENT_OBJECT_PTR(CIuReleaseNotes)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RELEASENOTES, CIuReleaseNotes, CIuReleaseNotes_super)
//{{AttributeMap
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuReleaseNotes, IDS_ENGINE_PPG_RELEASENOTES, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PAGE(CIuReleaseNotes, IDS_ENGINE_PPG_RELEASENOTES, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuReleaseNotes::CIuReleaseNotes()
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuReleaseNotes::~CIuReleaseNotes()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuReleaseNotes::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int i = 0; i < GetCount(); ++i)
		if (!Get(i).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

bool CIuReleaseNotes::CheckVersion(LPCTSTR pcszName, CIuVersionNumber version, bool fShowDlg, CWnd* pParent)
{
	// Find a release note with the correct name and the latest version
	int iReleaseNotes = GetCount();
	int iFound = -1;
	CIuVersionNumber verFound(0,0,0,0);
	for (int iReleaseNote = 0; iReleaseNote < iReleaseNotes; ++iReleaseNote)
	{
		CIuReleaseNote& ReleaseNote = Get(iReleaseNote);
		CString sName = ReleaseNote.GetName();
		CString sApp;
		CString sVersion;
		int iVersion = sName.Find('.');
		if (iVersion >= 0)
		{
			sApp = sName.Left(iVersion);
			sVersion = sName.Mid(iVersion + 1);
		}
		else
		{
			sApp = sName;
		}
		if (sApp.CompareNoCase(pcszName) != 0)
			continue;
		CIuVersionNumber verThis = sVersion;
		if (iFound < 0)
		{
			iFound = iReleaseNote;
			verFound = verThis;
		}
		else if (verThis > verFound)
		{
			iFound = iReleaseNote;
			verFound = verThis;
		}
	}
	if (iFound < 0)
	{
		TRACE("WARNING: Release notes not found for '%s'\n", pcszName);
		return true;
	}
	CIuReleaseNote& ReleaseNote = Get(iFound);
	return ReleaseNote.CheckVersion(version, fShowDlg, pParent);
}

void CIuReleaseNotes::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuReleaseNotes::Create(CIuReleaseNoteSpec& ReleaseNoteSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuReleaseNote& ReleaseNote = Get(iIndex);
	ReleaseNote.SetSpec(ReleaseNoteSpec);
}

void CIuReleaseNotes::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuReleaseNotePtr pReleaseNote = dynamic_cast<CIuReleaseNote*>(pCollectable.Ptr());
	GetEngine().QueryObject(collectionReleaseNotes, Descriptor, *pReleaseNote);
}

CIuCollectablePtr CIuReleaseNotes::OnNew(CWnd*) const
{
	CIuReleaseNotePtr pReleaseNote;
	pReleaseNote.Create();
	return pReleaseNote;
}

void CIuReleaseNotes::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuReleaseNotes::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	for (int iReleaseNote = 0; iReleaseNote < GetCount(); ++iReleaseNote)
		Get(iReleaseNote).SetObjectRepository(pObjectRepository);
}

void CIuReleaseNotes::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iReleaseNote = 0; iReleaseNote < Spec.GetReleaseNoteCount(); ++iReleaseNote)
		Create(Spec.GetReleaseNote(iReleaseNote));
}
