#include "StdAfx.h"
//{{Include
#include "LatLongDistance.h"
#include "LatLongCoordinate.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuLatLongDistance::CIuLatLongDistance()
{
	CommonConstruct();
}

CIuLatLongDistance::CIuLatLongDistance(const CIuLatLongDistance& dist)
{
	CommonConstruct();
	operator=(dist);
}

CIuLatLongDistance::CIuLatLongDistance(DWORD dw, CIuLatLongDistanceUnits units)
{
	CommonConstruct();
	FromDWORD(dw, units);
}

CIuLatLongDistance::CIuLatLongDistance(LPCTSTR pcsz, CIuLatLongDistanceUnits units)
{
	CommonConstruct();
	FromString(pcsz, units);
}

CIuLatLongDistance::~CIuLatLongDistance()
{
}

DWORD CIuLatLongDistance::AsDWORD() const
{
	return m_dwDistance;
}

CString CIuLatLongDistance::AsString(CIuLatLongDistanceUnits units, bool fUnits) const
{
	if (!IsValid())
		return CString();

	DWORD dwDistanceConverted = m_dwDistance;
	CString s;
	switch (units)
	{
		case LatLongUnitsMiles:
		{
			dwDistanceConverted += 5280 / 2;
			dwDistanceConverted /= 5280;
			if (dwDistanceConverted > 0)
				IntAsString(s, dwDistanceConverted);
			else				
			{
				ASSERT(m_dwDistance <= 5280);
				dwDistanceConverted = (m_dwDistance * 100) / 5280;
				IntAsString(s, dwDistanceConverted);
				s = CString("0.") + s;
			}
			if (fUnits)
				s += _T(" miles");
			break;
		}
		default:
		case LatLongUnitsFeet:
		{
			IntAsString(s, dwDistanceConverted);
			if (fUnits)
				s += _T(" feet");
			break;
		}
	}
	return s;
}

void CIuLatLongDistance::CommonConstruct()
{
	m_dwDistance = 0;
}

void CIuLatLongDistance::FromDWORD(DWORD dw, CIuLatLongDistanceUnits units)
{
	switch (units)
	{
		case LatLongUnitsMiles:
			m_dwDistance = dw / 5280;
			break;
		default:
		case LatLongUnitsFeet:
			m_dwDistance = dw;
			break;
	}
	m_dwDistance = dw;
}

void CIuLatLongDistance::FromString(LPCTSTR pcsz, CIuLatLongDistanceUnits units)
{
	ASSERT(AfxIsValidString(pcsz));
	double distance = atof(pcsz);

	switch (units)
	{
		case LatLongUnitsMiles:
			m_dwDistance = DWORD(distance * 5280);
			break;
		default:
		case LatLongUnitsFeet:
			m_dwDistance = DWORD(distance);
			break;
	}
}

CIuLatLongDistance::operator DWORD() const
{
	return AsDWORD();
}

CIuLatLongDistance::operator CString() const
{
	return AsString();
}

CIuLatLongDistance& CIuLatLongDistance::operator=(const CIuLatLongDistance& dist)
{
	if (&dist == this)
		return *this;
	m_dwDistance = dist.m_dwDistance;
	return *this;
}


CIuLatLongDistance& CIuLatLongDistance::operator=(DWORD dw)
{
	FromDWORD(dw);
	return *this;
}

CIuLatLongDistance& CIuLatLongDistance::operator=(LPCTSTR pcsz)
{
	FromString(pcsz);
	return *this;
}

CIuLatLongDistance CIuLatLongDistance::operator+(const CIuLatLongDistance& dist) const
{
	return CIuLatLongDistance(m_dwDistance + dist.m_dwDistance);
}

const CIuLatLongDistance& CIuLatLongDistance::operator+=(const CIuLatLongDistance dist)
{
	return *this = *this + dist;
}

const CIuLatLongDistance& CIuLatLongDistance::operator-=(const CIuLatLongDistance dist)
{

	return *this = *this - dist;
}

CIuLatLongDistance CIuLatLongDistance::operator-(const CIuLatLongDistance& dist) const
{
	return CIuLatLongDistance(m_dwDistance - dist.m_dwDistance);
}

bool CIuLatLongDistance::operator==(const CIuLatLongDistance& dist) const
{
	return m_dwDistance == dist.m_dwDistance;
}

bool CIuLatLongDistance::operator!=(const CIuLatLongDistance& dist) const
{
	return !(operator==(dist));
}

bool CIuLatLongDistance::operator<(const CIuLatLongDistance& dist) const
{
	return m_dwDistance < dist.m_dwDistance;
}

bool CIuLatLongDistance::operator>(const CIuLatLongDistance& dist) const
{
	return m_dwDistance > dist.m_dwDistance;
}

bool CIuLatLongDistance::operator<=(const CIuLatLongDistance& dist) const
{
	return m_dwDistance <= dist.m_dwDistance;
}

bool CIuLatLongDistance::operator>=(const CIuLatLongDistance& dist) const
{
	return m_dwDistance >= dist.m_dwDistance;
}
