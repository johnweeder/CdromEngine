#include "StdAfx.h"
//{{Include
#include "CdromSpecConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NOTE: On future releases, be sure to include a release identifier with the
//			format name.
//			For example: pf2001

/////////////////////////////////////////////////////////////////////////////
//	Miscellaneous

// This is a blank description which forces the build engine
//	to create a description.
const LPCTSTR szDescriptionGenerate		= 0;

/////////////////////////////////////////////////////////////////////////////
// Releases
const TCHAR szRelease_Test[]						= _T("Test!");
const TCHAR szRelease_Sample[]					= _T("Sample!");
const TCHAR szRelease_Internal[]					= _T("Internal!");

const TCHAR szRelease_V1[]							= _T("Version 1");
const TCHAR szRelease_V2[]							= _T("Version 2");

const TCHAR szRelease_2000R1[]					= _T("2000 1st Edition");
const TCHAR szRelease_2000R2[]					= _T("2000 2nd Edition");

const TCHAR szRelease_2001R1[]					= _T("2001 1st Edition");

const TCHAR szRelease_Feb2000[]					= _T("February 2000");
const TCHAR szRelease_Mar2000[]					= _T("March 2000");
const TCHAR szRelease_Apr2000[]					= _T("April 2000");
const TCHAR szRelease_May2000[]					= _T("May 2000");
const TCHAR szRelease_Jun2000[]					= _T("June 2000");
const TCHAR szRelease_Jul2000[]					= _T("July 2000");
const TCHAR szRelease_Aug2000[]					= _T("August 2000");
const TCHAR szRelease_Sep2000[]					= _T("September 2000");
const TCHAR szRelease_Oct2000[]					= _T("October 2000");
const TCHAR szRelease_Nov2000[]					= _T("November 2000");
const TCHAR szRelease_Dec2000[]					= _T("December 2000");


/////////////////////////////////////////////////////////////////////////////
// Format
//	Formats are generally abbreviated strings describing the 
//		format and the release. A format string should also be
//		a valid identifier and a valid filename

const TCHAR szFormat104m_2001[]					= _T("104m_2001");
const TCHAR szFormat88md_2001[]					= _T("88md_2001");
const TCHAR szFormatAc_V1[]						= _T("Ac");
const TCHAR szFormatBml_2000[]					= _T("Bml");
const TCHAR szFormatBml1_2000[]					= _T("Bml1");
const TCHAR szFormatBml2_2000[]					= _T("Bml2");
const TCHAR szFormatCi_V1[]						= _T("Ci");
const TCHAR szFormatConsole[]						= _T("Console");
const TCHAR szFormatMeterAdmin[]					= _T("MeterAdmin");
const TCHAR szFormatNetAdmin[]					= _T("NetAdmin");
const TCHAR szFormatOam_V1[]						= _T("Oam_V1");
const TCHAR szFormatPb_2001[]						= _T("Pb_2001");
const TCHAR szFormatPbm_V1[]						= _T("Pbm");
const TCHAR szFormatPf_2000[]						= _T("Pf");
const TCHAR szFormatPf_2001[]						= _T("Pf_2001");
const TCHAR szFormatPg_2000[]						= _T("Pg");
const TCHAR szFormatPowerCheck[]					= _T("PowerCheck");
const TCHAR szFormatPu_2000[]						= _T("PfUsa");
const TCHAR szFormatPu_2001[]						= _T("Pu_2001");
const TCHAR szFormatRboc_2000[]					= _T("Rboc");
const TCHAR szFormatRbocGreatLakes_2000[]		= _T("RbocGl_2000");
const TCHAR szFormatRbocSeAtlantic1_2000[]	= _T("RbocSe1_2000");
const TCHAR szFormatRbocSeAtlantic2_2000[]	= _T("RbocSe2_2000");
const TCHAR szFormatRbocNeAtlantic1_2000[]	= _T("RbocNe1_2000");
const TCHAR szFormatRbocNeAtlantic2_2000[]	= _T("RbocNe2_2000");
const TCHAR szFormatRbocPacific_2000[]			= _T("RbocPa_2000");
const TCHAR szFormatRbocSouthWest_2000[]		= _T("RbocSw_2000");
const TCHAR szFormatRbocMidWest_2000[]			= _T("RbocMw_2000");
const TCHAR szFormatRbocTest_2000[]				= _T("RbocTest_2000");
const TCHAR szFormatRp_2001[]						= _T("Rp");
const TCHAR szFormatReleaseNotes[]				= _T("ReleaseNotes");
const TCHAR szFormatSample[]						= _T("Sample");
const TCHAR szFormatSlu_2000[]					= _T("Slu");
const TCHAR szFormatYpu_2001[]					= _T("Ypu");

/////////////////////////////////////////////////////////////////////////////
// Products and Product Groups
//	These are generally human read-able strings.
//	Products describe a specific CD-ROM (ex 88MD Central)
//	Product groups describe a grouping of products (ex 88MD)

const TCHAR szProductGroup104m_Test_2001[]		= _T("104 Million Businesses & Households 2001 (Test)");
const TCHAR szProductGroup104m_Usa_2001[]			= _T("104 Million Businesses & Households 2001 (USA)");
const TCHAR szProductGroup104m_Regional_2001[]	= _T("104 Million Businesses & Households 2001 (Regional)");
const TCHAR szProductGroup88md_Test_2001[]		= _T("88 Million Households Deluxe 2001 (Test)");
const TCHAR szProductGroup88md_Usa_2001[]			= _T("88 Million Households Deluxe 2001 (USA)");
const TCHAR szProductGroup88md_Regional_2001[]	= _T("88 Million Households Deluxe 2001 (Regional)");
const TCHAR szProductGroupAc_Ui_V1[]				= _T("Address Corrector (UI)");
const TCHAR szProductGroupAc_Usa_V1[]				= _T("Address Corrector (USA)");
const TCHAR szProductGroupAc_Test_V1[]				= _T("Address Corrector (Test)");
const TCHAR szProductGroupAc_Regional_V1[]		= _T("Address Corrector (Regional)");
const TCHAR szProductGroupBml1_Test_2000[]		= _T("Business Mailing Lists1 (Test)");
const TCHAR szProductGroupBml1_Usa_2000[]			= _T("Business Mailing Lists1 (USA)");
const TCHAR szProductGroupBml2_Test_2000[]		= _T("Business Mailing Lists2 (Test)");
const TCHAR szProductGroupBml2_Usa_2000[]			= _T("Business Mailing Lists2 (USA)");
const TCHAR szProductGroupCi_Test_V1[]				= _T("CallerID (Test)");
const TCHAR szProductGroupCi_Ui_V1[]				= _T("CallerID (UI)");
const TCHAR szProductGroupCi_Regional_V1[]		= _T("CallerID (Regional)");
const TCHAR szProductGroupCi_Usa_V1[]				= _T("CallerID (USA)");
const TCHAR szProductGroupConsole[]					= _T("Console");
const TCHAR szProductGroupMeterAdmin[]				= _T("Meter Administator");
const TCHAR szProductGroupNetAdmin[]				= _T("Net Administator");
const TCHAR szProductGroupOam_Test_V1[]			= _T("OAM V1 (Test)");
const TCHAR szProductGroupOam_Usa_V1[]				= _T("OAM V1 (USA)");
const TCHAR szProductGroupPb_Test_2001[]			= _T("Power Business 2001 (Test)");
const TCHAR szProductGroupPb_Usa_2001[]			= _T("Power Business 2001 (USA)");
const TCHAR szProductGroupPbm_Test_V1[]			= _T("Personalized Business Mailings (Test)");
const TCHAR szProductGroupPbm_Usa_V1[]				= _T("Personalized Business Mailings (USA)");
const TCHAR szProductGroupPf_2000[]					= _T("PowerFinder");
const TCHAR szProductGroupPf_Test_2001[]			= _T("PowerFinder Commercial 2001 (Test)");
const TCHAR szProductGroupPf_Regional_2001[]		= _T("PowerFinder Commercial 2001 (Regional)");
const TCHAR szProductGroupPg_Test_2000[]			= _T("PowerFinder Government (Test)");
const TCHAR szProductGroupPg_Regional_2000[]		= _T("PowerFinder Government (Regional)");
const TCHAR szProductGroupPg_Usa_2000[]			= _T("PowerFinder Government (USA)");
const TCHAR szProductGroupPowerCheck[]				= _T("PowerCheck");
const TCHAR szProductGroupPu_2000[]					= _T("PowerFinderUSA1");
const TCHAR szProductGroupPu_Test_2001[]			= _T("PowerFinder USA1 2001 (Test)");
const TCHAR szProductGroupPu_Usa_2001[]			= _T("PowerFinder USA1 2001 (USA)");
const TCHAR szProductGroupRboc_Test_2000[]		= _T("Rboc (Test)");
const TCHAR szProductGroupRboc_Regional_2000[]	= _T("Rboc (Regional)");
const TCHAR szProductGroupReleaseNotes[]			= _T("ReleaseNotes");
const TCHAR szProductGroupRp_Test_2001[]			= _T("ResumePlus (Test)");
const TCHAR szProductGroupRp_Usa_2001[]			= _T("ResumePlus (USA)");
const TCHAR szProductGroupSample[]					= _T("Sample");
const TCHAR szProductGroupSlu_Test_2000[]			= _T("SalesLeadsUSA (Test)");
const TCHAR szProductGroupSlu_Usa_2000[]			= _T("SalesLeadsUSA (USA)");
const TCHAR szProductGroupYpu_Test_2001[]			= _T("YellowPagesUSA 2001 (Test)");
const TCHAR szProductGroupYpu_Usa_2001[]			= _T("YellowPagesUSA 2001 (USA)");

/////////////////////////////////////////////////////////////////////////////
// Application Types
const TCHAR szAppAc[]								= _T("AddressCorrector");
const TCHAR szAppCdu[]								= _T("CdUsa");
const TCHAR szAppCi[]								= _T("CallerID");
const TCHAR szAppMeterAdmin[]						= _T("MeterAdmin");
const TCHAR szAppConsole[]							= _T("Console");
const TCHAR szAppNetAdmin[]						= _T("NetAdmin");
const TCHAR szAppPd[]								= _T("PhoneDisc");
const TCHAR szAppReleaseNotes[]					= _T("ReleaseNotes");
const TCHAR szAppRp[]								= _T("ResumePlus");
const TCHAR szAppSlu[]								= _T("Slu");
const TCHAR szAppPowerCheck[]						= _T("PowerCheck");


