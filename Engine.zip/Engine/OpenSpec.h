#ifndef _ENGINE_OPENSPEC_H_
#define _ENGINE_OPENSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
class CIuObjectRepository;
class CIuOptions;
class CIuOutput;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuOpenSpec}}
// This is a helper class used by various classes to resolve field mappings.
class IU_CLASS_EXPORT CIuOpenSpec 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuOpenSpec();
	CIuOpenSpec(CIuOutput* pOutput, CIuObjectRepository* pObjectRepository, const CIuOptions* pOptions);
	CIuOpenSpec(const CIuOpenSpec&);
	virtual ~CIuOpenSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuOpenSpec& operator=(const CIuOpenSpec&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// An output object
	CIuOutput* m_pOutput;
	// An object repository. Sometimes used within the expression evaluator
	CIuObjectRepository* m_pObjectRepository;
	// Option used during resolution (global variables for instance)
	const CIuOptions* m_pOptions;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_OPENSPEC_H_
