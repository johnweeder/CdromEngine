#include "StdAfx.h"
//{{Include
#include "BTreeSpecDft.h"
#include "BTree.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BTree collections
static int aiBTreeTokenizerNone[]		=  { btreeTokenizerNone };
// static int aiBTreeTokenizerStreet[]		=  { btreeTokenizerPriNo, btreeTokenizerStreet, btreeTokenizerSecNo, btreeTokenizerNone };


/////////////////////////////////////////////////////////////////////////////
// BTree specifications

static const CIuBTreeSpecDft aBTree[] =
{
	{
		_T("Address"), btreeAddress,
		_T("Address"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		_T("AltCity"), false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("CityState\nStreet\nPriNo\nSecNo"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		_T("AltCity"), true, false,
	},{
		_T("Business"), btreeBusiness,
		_T("Business"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		_T("AltSic"), false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("SicCode"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("BusinessFranchise"), btreeBusinessFranchise,
		_T("BusinessFranchise"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		_T("AltSic"), false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("SicFranchiseCode"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("Name104m_2001"), btreeName104m_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, true, false, true, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("Name88md_2001"), btreeName88md_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, true,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("NameAc_V1"), btreeNameAc_V1,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, true, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("NameBml_2000"), btreeNameBml_2000,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		1, _T("SicCode"), 0, 0, 0, 0, 0,
		0,
		_T("AltLast"), false, false,
	},{
		_T("NameCi_V1"), btreeNameCi_V1,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, true, true, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("NameOam_V1"), btreeNameOam_V1,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		1, _T("SicCode"), 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("NamePb_2001"), btreeNamePb_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		_T("AltLast"), false, false,
	},{
		_T("NamePbm_V1"), btreeNamePbm_V1,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		0, false, false,
	},{
		_T("NamePf_2001"), btreeNamePf_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		_T("AltLast"), false, false,
	},{
		_T("NamePg_2000"), btreeNamePg_2000,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		6, _T("SicCode"), _T("FranchiseCode"), 0, 0, _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		_T("AltLast"), false, false,
	},{
		_T("NamePu_2001"), btreeNamePu_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		_T("AltLast"), false, false,
	},{
		_T("NameRboc_2000"), btreeNameRboc_2000,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		6, _T("SicCode"), _T("FranchiseCode"), 0, 0, _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		0,
		_T("AltLast"), false, false,
	},{
		_T("NameRp_2001"), btreeNameRp_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		1, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		0,
		0, false, false,
	},{
		_T("NameSample"), btreeNameSample,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		_T("AltLast"), true,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), false, false,
		1, _T("SicCode"), 0, 0, 0, 0, 0,
		0,
		_T("AltLast"), false, false,
	},{
		_T("NameSlu_2000"), btreeNameSlu_2000,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		_T("Contact"),
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		_T("Gender"),
		0, false, false,
	},{
		_T("NameYpu_2001"), btreeNameYpu_2001,
		_T("Name"),
		true,
		aiBTreeTokenizerNone,
		0,
		true, false,
		true, false,
		0, false,
		true,
		true, true, false, false, false, 3, // +/- 24 ft
		true,
		_T("Name"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
		0,
		_T("NoSolicitation"), true, true,
		_T("BusResFlag"), true, false,
		6, _T("SicCode"), _T("FranchiseCode"), _T("AdSizeCode"), _T("FirstYear"), _T("EmployeeSizeCode"), _T("SalesVolumeCode"),
		0,
		0, false, false,
	},{
		_T("Phone"), btreePhone,
		_T("Phone"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		0, false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("AcPhone"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		_T("AltPhone"), false, true,
	},{
		_T("Zip4"), btreeZip4,
		_T("Zip4"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		0, false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("Zip"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	},{
		_T("Zip5"), btreeZip5,
		_T("Zip5"),
		false,
		aiBTreeTokenizerNone,
		_T("Name"),
		true, true,
		false, true,
		0, false,
		false,
		false, false, false, false, false, 0,
		false,
		_T("Zip"),
		0,
		0,
		0, false, false,
		0, false, false,
		0, 0, 0, 0, 0, 0, 0,
		0,
		0, false, false,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuBTreeSpecDft

int CIuBTreeSpecDft::Find(LPCTSTR pcszBTree)
{
	ASSERT(AfxIsValidString(pcszBTree));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszBTree, pcszBTree) == 0)
			return i;
	}
	return -1;
}

int CIuBTreeSpecDft::Find(int iBTree)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iBTree == iBTree)
			return i;
	}
	return -1;
}

const CIuBTreeSpecDft* CIuBTreeSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aBTree + iWhich;
}

int CIuBTreeSpecDft::GetCount()
{
	return sizeof(aBTree) / sizeof(aBTree[0]);
}


