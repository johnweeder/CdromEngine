#ifndef _ENGINE_GEOELEMENTCOLLECTION_H_
#define _ENGINE_GEOELEMENTCOLLECTION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_COMMON_NYBBLESTRING_H_
#	include "Common\NybbleString.h"
#endif	// _COMMON_NYBBLESTRING_H_
#ifndef 	_COMMON_NYBBLEINT_H_
#	include "Common\NybbleInt.h"
#endif	// _COMMON_NYBBLEINT_H_
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
#ifndef 	_ENGINE_SOURCEDESCRIPTORSPEC_H_
#	include "Engine\SourceDescriptorSpec.h"
#endif	// _ENGINE_SOURCEDESCRIPTORSPEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoElementCollection)
class CIuGeoSpec;
class CIuCdrom;
class CIuGeo;
class CIuGeoRaw;
class CIuGeoList;
class CIuGeoRawElementCollection;
class CIuGeoRawElement;
class CIuGeoElement;
class CIuRegEx;
class CIuRegExCompare;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoElementCollection, CIuCollectable }}
#define CIuGeoElementCollection_super CIuCollectable

class CIuGeoElementCollection : public CIuGeoElementCollection_super
{
	// This object is an in-memory representation of some geography type (zips/states/msas/etc).
	// For performance and space, the actual elements are compressed into a packed byte buffer.
	// The collection maintains a set of pointers to "pseudo-struct's" which are used
	// to access each element type.
//{{Declare
	DECLARE_SERIAL(CIuGeoElementCollection)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoElementCollection();
	virtual ~CIuGeoElementCollection();
	CIuGeoElementCollection(const CIuGeoElementCollection&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	const CIuGeoElement& Get(int iElement) const;
	int GetBitsRequired() const;
	int GetCount() const;
	void GetElementKey(int iElement, CIuKey& key) const;
	LPCTSTR GetElementName(int iElement) const;
	int GetExpandedSize() const;
	CString GetFilename() const;
	CString GetFullFilename() const;
	CIuGeo& GetGeo() const;
	virtual void GetGeoList(CIuGeoList& GeoList, const CIuRegEx& RegEx) const;
	virtual void	GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const;
	virtual LPCTSTR GetIndex() const;
	CIuObjectRepository& GetObjectRepository() const;
	virtual void GetRecord(int iRecordNo, CIuRecordPtr& pRecord);
	virtual void GetRecordDef(CIuRecordDef&) const;
	int GetSize() const;
	virtual int GetSourceType() const;
	void GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	virtual void GetZipList(int, CIuGeoList&) const;
	bool HasGeo() const;
	bool HasObjectRepository() const;
	bool IsOpen() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool BuildCompress(CIuGeoRaw& geo, CIuGeoRawElementCollection& collection, CIuCdrom& Cdrom, CIuOutput& Output);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close(bool fForce = false);
	virtual void Copy(const CIuObject& object);
	void Delete(CIuOutput* pOutput);
	void Empty();
	int Find(LPCTSTR pcszName);
	int Find(int iValue, int iPad);
	void Open();
	virtual bool Request(CString& sResult, const CStringArray& as);
	bool SanityCheck(CIuGeoRawElementCollection& collection, CIuOutput& Output);
	void SetCount(int);
	void SetExpandedSize(int);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuGeoSpec& Spec);
	void SetSize(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
protected:
	virtual void FindScan(CIuGeoList&, const CIuRegExCompare&) const;
	virtual int OnCompressElement(CIuNybbleBuffer& buffer, CIuGeoRaw& geo, CIuGeoRawElement& element, CIuGeoRawElementCollection& collection, CIuOutput&);
	virtual int OnDeCompressElement(CIuNybbleBuffer&, int);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuGeoElementCollection& operator=(const CIuGeoElementCollection&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	bool GetGridInfo(int iRq, CIuGridRq& rq);
protected:
	friend CIuGeoList;
	CIuGeoElement* AddElement(int iFixedSize);
	int AddElementData(const BYTE* pbSrc, int cbSrc);
	int AddElementName(LPCTSTR pcsz);
	int AddElementString(LPCTSTR pcsz);
	CIuGeoElement* AddElementStringTerm();
	void CheckField(CString& s);
private:
	friend class CIuGeo;

	void CommonConstruct();
	bool FindLo(const CIuRegExCompare& Compare, int& iMatch) const;
	bool FindHi(const CIuRegExCompare& Compare, int& iMatch) const;
	void SetGeo(CIuGeo* pGeo);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuGeo* m_pGeo;
	// Open flag
	int m_iOpen;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	// Used during expansion to track current element
	int m_iCurrentElement;
protected:
	static const CIuVersionNumber versionGeo1;
	static const CIuVersionNumber versionGeo2;
	// Expanded record buffer and offsets for records
	CIuBigBuffer m_Buffer;
	CIntArray m_aiOffsets;
private:
	// Persistent date
	int m_iCount;
	int m_iSize;
	int m_iExpandedSize;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline const CIuGeoElement& CIuGeoElementCollection::Get(int iElement) const
{
	ASSERT(IsOpen());
	ASSERT(iElement >= 0 && iElement < m_aiOffsets.GetSize());
	int iOffset = m_aiOffsets[iElement];
	return *reinterpret_cast<const CIuGeoElement*>(m_Buffer.GetPtr(iOffset));
}

inline int CIuGeoElementCollection::GetCount() const
{
	return m_iCount;
}

inline int CIuGeoElementCollection::GetExpandedSize() const
{
	return m_iExpandedSize;
}

inline CIuGeo& CIuGeoElementCollection::GetGeo() const
{
	ASSERT(m_pGeo!=0);
	return *m_pGeo;
}

inline CIuObjectRepository& CIuGeoElementCollection::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline int CIuGeoElementCollection::GetSize() const
{
	return m_iSize;
}

inline bool CIuGeoElementCollection::HasGeo() const
{
	return m_pGeo!=0;
}

inline bool CIuGeoElementCollection::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_GEOELEMENTCOLLECTION_H_
