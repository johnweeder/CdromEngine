#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Build.h"
#include "Builds.h"
#include "Engine.h"
#include "Data\SerializeEx.h"
#include "Error\Error.h"
#include "resource.h"
#include "Data\Command.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBuild, CIuBuild_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuBuild)
//}}Implement

CIuBuild::CIuBuild()
{
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	m_pThread = CIuBuildThread::Start();
}

CIuBuild::~CIuBuild()
{
	if (m_pThread)
		m_pThread->Stop();

	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBuild::Command(LPCTSTR CommandString, int hWnd)
{
	// Close any unused pack files
	// They may all have been opened in order to get the database information
	GetBuilds().GetEngine().CloseUnused();

	// Create an output object
	if (m_pOutput.IsNull())
		m_pOutput = GetBuilds().GetEngine().CreateOutput();

	ASSERT(m_pThread);
	if (m_pThread->IsProcessing())
		Error(IU_E_COMMAND_RUNNING);

	CIuCommandPtr pCommand;
	pCommand.Create();
	pCommand->SetCommand(CommandString);

	m_pOutput->SetHandle(GetHandle());
	m_pOutput->SetAbort(false);
	m_pOutput->SetHWND(hWnd);

	m_pThread->SetEvent(pCommand, m_pOutput);
}

bool CIuBuild::GetAbort() 
{
	return m_pThread->ShouldCancel();
}

CIuBuilds& CIuBuild::GetBuilds() const
{
	CIuBuilds* pParent = dynamic_cast<CIuBuilds*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

int CIuBuild::GetHandle() 
{
	return reinterpret_cast<int>(this);
}

bool CIuBuild::IsRunning()
{
	return m_pThread->IsProcessing();
}

void CIuBuild::SetAbort(bool fCancel)
{
	if (fCancel)
		m_pThread->Cancel();
}

