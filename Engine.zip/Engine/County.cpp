#include "StdAfx.h"
//{{Include
#include "County.h"
#include "GeoList.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCounty::GetZipList(CIuGeoList& GeoList) const
{
	GeoList.Extract(((const BYTE*)this) + sizeof(*this));
}
