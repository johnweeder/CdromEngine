#ifndef _ENGINE_BTREETOKENIZERSPECDFT_H_
#define _ENGINE_BTREETOKENIZERSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Descriptions for the various BTreeTokenizerernate record files
struct CIuBTreeTokenizerSpecDft
{
public:
	static int Find(LPCTSTR pcszBTreeTokenizer);
	static int Find(int iBTreeTokenizer);
	static const CIuBTreeTokenizerSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszBTreeTokenizer;
	int m_iBTreeTokenizer;
	// Compressed token filename
	LPCTSTR m_pcszFilename;
	// Mapping for the tokenizer
	int m_iTokenNo;
	// Options
	bool m_fOptional;
	bool m_fExceptional;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BTREETOKENIZERSPECDFT_H_
