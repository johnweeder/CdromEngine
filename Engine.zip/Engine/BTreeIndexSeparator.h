#ifndef _ENGINE_BTREEINDEXSEPARATOR_H_
#define _ENGINE_BTREEINDEXSEPARATOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeIndexSeparator)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeIndexSeparator, CIuKey }}
#define CIuBTreeIndexSeparator_super CIuKey

class CIuBTreeIndexSeparator : public CIuBTreeIndexSeparator_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeIndexSeparator)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeIndexSeparator();
	CIuBTreeIndexSeparator(const CIuBTreeIndexSeparator&);
	virtual ~CIuBTreeIndexSeparator();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetPointerCount() const;
	int GetPointerNo() const;
	int GetRecordCount() const;
	int GetRecordNo() const;
	const BYTE* GetSeparatorPtr() const;
	int GetSeparatorSize() const;
	bool IsContinuation() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void CreateSeparator(const CIuKey& key, const CIuKey& keyPrevious);
	void SetContinuation(bool);
	void SetPointerCount(int);
	void SetPointerNo(int);
	void SetRecordCount(int);
	void SetRecordNo(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuBTreeIndexSeparator& operator=(const CIuBTreeIndexSeparator&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fContinuation;
	int m_iRecordNo;
	int m_iPointerNo;
	int m_iPointerCount;
	int m_iRecordCount;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBTreeIndexSeparator::GetPointerCount() const
{
	return m_iPointerCount;
}

inline int CIuBTreeIndexSeparator::GetPointerNo() const
{
	return m_iPointerNo;
}

inline int CIuBTreeIndexSeparator::GetRecordCount() const
{
	return m_iRecordCount;
}

inline int CIuBTreeIndexSeparator::GetRecordNo() const
{
	return m_iRecordNo;
}

inline const BYTE* CIuBTreeIndexSeparator::GetSeparatorPtr() const
{
	return GetKeyPtr();
}

inline int CIuBTreeIndexSeparator::GetSeparatorSize() const
{
	return GetKeySize();
}

inline bool CIuBTreeIndexSeparator::IsContinuation() const
{
	return m_fContinuation;
}

#endif // _ENGINE_BTREEINDEXSEPARATOR_H_
