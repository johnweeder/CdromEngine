#ifndef _ENGINE_METERDIAGNOSTICDLG_H_
#define _ENGINE_METERDIAGNOSTICDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
//}}Uses

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: MeterDiagnosticDlg, CDialog }}
#define CIuMeterDiagnosticDlg_super CDialog

class CIuMeterDiagnosticDlg : public CIuMeterDiagnosticDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterDiagnosticDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static void DoDialog(CIuMeter& Meter, LPCTSTR pcszCode, LPCTSTR pcszLocation, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
//}}Data

private:
	//{{AFX_DATA(CIuMeterDiagnosticDlg)
	enum { IDD = IDD_ENGINE_METER_DIAGNOSTIC };
	CString	m_sNotes;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterDiagnosticDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterDiagnosticDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnClipboard();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERDIAGNOSTICDLG_H_
