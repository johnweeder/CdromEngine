#ifndef _ENGINE_CDROMSTRIPSPECDFT_H_
#define _ENGINE_CDROMSTRIPSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Strip files used to create the btree indexes
struct CIuCdromStripSpecDft
{
public:
	static int Find(LPCTSTR pcszStrip);
	static int Find(int iStrip);
	static const CIuCdromStripSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszStrip;
	int m_iStrip;
	// Strip filename
	LPCTSTR m_pcszFilename;
	// The specification for the data stripped from input file
	int m_iStripNo;
	int m_iSortNo;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMSTRIPSPECDFT_H_
