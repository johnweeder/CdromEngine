#include "StdAfx.h"
//{{Include
#include "LatLongUnit.h"
#include "Error\Error.h"
#include "Common\String.h"
#include "Interop\Conversions.h"
#include "GeoConst.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

#define LATLONGINVALID(x) (((x) & dwLatLongSignMask) == (dwLatLongInvalid & dwLatLongSignMask))


// Assumed length of buffer for lat/int formatted as string (in any format)
const int iAssumedLength = 20;

IU_API_EXPORT CArchive& operator>>(CArchive& ar, CIuLatLongUnit& unit)
{
	ar >> unit.m_dwLatLong;
	return ar;
}

IU_API_EXPORT CArchive& operator<<(CArchive& ar, const CIuLatLongUnit& unit)
{
	ar << unit.m_dwLatLong;
	return ar;
}

CIuLatLongUnit::CIuLatLongUnit()
{
	ASSERT(sizeof(*this) == sizeof(m_dwLatLong));
	Clear();
}

CIuLatLongUnit::CIuLatLongUnit(const CIuLatLongUnit& latlong)
{
	ASSERT(sizeof(*this) == sizeof(m_dwLatLong));
	Clear();
	operator=(latlong);
}

CIuLatLongUnit::CIuLatLongUnit(DWORD dw)
{
	ASSERT(sizeof(*this) == sizeof(m_dwLatLong));
	Clear();
	operator=(dw);
}

CIuLatLongUnit::CIuLatLongUnit(LPCTSTR pcsz)
{
	ASSERT(sizeof(*this) == sizeof(m_dwLatLong));
	Clear();
	operator=(pcsz);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

DWORD CIuLatLongUnit::AsDWORD() const
{
	return m_dwLatLong;
}

CString CIuLatLongUnit::AsString(bool fDms) const
{
	TCHAR sz[iAssumedLength];
	AsStringInternal(sz, fDms);
	return CString(sz);
}

int CIuLatLongUnit::AsString(LPTSTR psz, int cb, bool fDms) const
{
	if (cb >= iAssumedLength)
		return AsStringInternal(psz, fDms);

	TCHAR sz[iAssumedLength];
	int iLength = AsStringInternal(sz, fDms);
	memcpy(psz, sz, cb);
	psz[cb - 1] = '\0';
	return min(iLength, cb);
}

int CIuLatLongUnit::AsStringInternal(LPTSTR psz, bool fDms) const
{
	// NOTE: psz is assumed to be of sufficient size (>= 20)
	// Returns length including null
	ASSERT(psz);
	LPTSTR pszStart = psz;
	if (LATLONGINVALID(m_dwLatLong))
	{
// Make an invalid lat/int be a blank!
//		static TCHAR szInvalid[] = "#invalid#";
//		_tcscpy(psz, szInvalid);
//		return sizeof(szInvalid);
		psz[0] = '\0';
		return 0;
	}
	else
	{
		DWORD dwUnsigned = m_dwLatLong & dwLatLongSignMask;
		DWORD dwDegrees = dwUnsigned / dwLatLongDegreeMultiplier;
		DWORD dwDegreesDecimal = dwUnsigned % dwLatLongDegreeMultiplier;

		if (fDms)
		{
			dwDegreesDecimal *= 60;

			DWORD dwMinutes = dwDegreesDecimal / dwLatLongDegreeMultiplier;
			ASSERT(dwMinutes < 60);

			dwDegreesDecimal %= dwLatLongDegreeMultiplier;
			dwDegreesDecimal *= 60;

			DWORD dwSeconds = dwDegreesDecimal / dwLatLongDegreeMultiplier;
			ASSERT(dwSeconds < 60);

			dwDegreesDecimal %= dwLatLongDegreeMultiplier;

			// dwDegreesDecimal is in the range 0...dwLatLongDegreeMultiplier
			// We want to scale down from 5 digits of precision to 4
			DWORD dwSecondsDecimal = dwDegreesDecimal / 10;

			if ((m_dwLatLong & dwLatLongSignFlag) != 0)
				*psz++ = '-';
			psz += UIntAsStringEx(psz, iAssumedLength, dwDegrees, 10, 0, 0, false);
			*psz++ = ':';
			psz += UIntAsStringEx(psz, iAssumedLength, dwMinutes, 10, 2, 2, true);
			*psz++ = ':';
			psz += UIntAsStringEx(psz, iAssumedLength, dwSeconds, 10, 2, 2, true);
			*psz++ = '.';
			psz += UIntAsStringEx(psz, iAssumedLength, dwSecondsDecimal, 10, 4, 4, true);
			*psz = '\0';
		}
		else
		{
			if ((m_dwLatLong & dwLatLongSignFlag) != 0)
				*psz++ = '-';
			psz += UIntAsStringEx(psz, iAssumedLength, dwDegrees, 10, 0, 0, false);
			*psz++ = '.';
			psz += UIntAsStringEx(psz, iAssumedLength, dwDegreesDecimal, 10, 5, 5, true);
			*psz = '\0';
		}
#ifdef _DEBUG
		{
			// Convert string back and verify it matches (or is very close).
			// We do allow some small errors due to rounding and for eliminating the 6th decimal of precision.
			CIuLatLongUnit unitDebug = pszStart;
			ASSERT(m_dwLatLong == 0 || (m_dwLatLong <= unitDebug.m_dwLatLong + 5 && m_dwLatLong >= unitDebug.m_dwLatLong - 5));
		}
#endif
	}
	ASSERT(*psz == '\0');
	int iLength = (psz - pszStart) + 1;
	ASSERT(iLength <= iAssumedLength);
	return iLength;
}

void CIuLatLongUnit::Clear()
{
	// A LatLongUnit must be representable as a DWORD
	ASSERT(sizeof(*this) == sizeof(DWORD));
	m_dwLatLong = dwLatLongInvalid;
}

bool CIuLatLongUnit::Constrain(const CIuLatLongUnit& Centroid)
{
	// This function is used to contrain a geo coordinate to within 
	// one degree of a centroid (i.e. about +/- 69 miles).
	if (LATLONGINVALID(m_dwLatLong) || m_dwLatLong == 0)
		return false;

	if (LATLONGINVALID(Centroid.m_dwLatLong) || Centroid.m_dwLatLong == 0)
		return false;

	DWORD dwLatLongCentroid = Centroid.m_dwLatLong & dwLatLongSignMask;
	 
	DWORD dwDegreesCentroid = dwLatLongCentroid / dwLatLongDegreeMultiplier;
	if (dwDegreesCentroid == 0)
		return false;

	DWORD dwMin;
	if (dwDegreesCentroid == 0)
		dwMin = 0;
	else 
		dwMin = (dwDegreesCentroid - 1) * dwLatLongDegreeMultiplier + (dwLatLongCentroid % dwLatLongDegreeMultiplier);

	DWORD dwMax = (dwDegreesCentroid + 1) * dwLatLongDegreeMultiplier + (dwLatLongCentroid % dwLatLongDegreeMultiplier);
	ASSERT(dwMin <= dwMax);

	DWORD dwLatLong = m_dwLatLong & dwLatLongSignMask;
	if (dwLatLong > dwMax)
	{
		m_dwLatLong = dwMax | (m_dwLatLong & dwLatLongSignFlag);
		return true;
	}
	if (dwLatLong < dwMin)
	{
		dwLatLong = dwMin | (m_dwLatLong & dwLatLongSignFlag);
		return true;
	}
	return false;
}

void CIuLatLongUnit::FromDWORD(DWORD dwUnit)
{
	m_dwLatLong = dwUnit;
}

void CIuLatLongUnit::FromString(LPCTSTR pcsz)
{
	// Converts Text into DWORD Lat or Long 
	// Input can be in the following formats:
	//		[+/-]DDD:MM:SS.ssss
	//		[+/-]DDD:MM.mmm
	//		[+/-]DDD.ddddd[d]
	//		[+/-]nnnnnnnnn		(This has an implied decimal place at the 6th position)
	//
	//	The result is stored in a DWORD in [+/-]DDD.ddddd format. There is an implied
	//		decimal point in the 5th position.
	//	The high bit is a sign bit.

	ASSERT(AfxIsValidString(pcsz));
	pcsz = _tcsskipws(pcsz);

	// First, extract the sign
	bool fMinus = false;
	if (*pcsz == '+')
		++pcsz;
	else if (*pcsz == '-')
	{
		fMinus = true;
		++pcsz;
	}

	// Next, extract the degrees
	int iDegreeDigits = 0;
	DWORD dwDegrees = 0;
	for (; _istdigit(*pcsz); ++pcsz, ++iDegreeDigits)
		dwDegrees = dwDegrees * 10 + DWORD(*pcsz - '0');

	// Decimal degrees
	if (*pcsz == '.')
	{
		++pcsz;

		dwDegrees = min(dwDegrees, 180);

		int iDecimalDegreeDigits = 0;
		DWORD dwDecimalDegrees = 0;
		for (; _istdigit(*pcsz); ++pcsz, ++iDecimalDegreeDigits)
		{
			if (iDecimalDegreeDigits >= dwLatLongDecimalDegreePrecision)
				break;

			dwDecimalDegrees = dwDecimalDegrees * 10 + DWORD(*pcsz - '0');
		}

		for (; iDecimalDegreeDigits < dwLatLongDecimalDegreePrecision; ++iDecimalDegreeDigits)
			dwDecimalDegrees *= 10;

		m_dwLatLong = dwDegrees * dwLatLongDegreeMultiplier + min(dwDecimalDegrees, dwLatLongDegreeMultiplier - 1);
	}
	// Minutes
	else if (*pcsz == ':')
	{
		++pcsz;

		dwDegrees = min(dwDegrees, 180);

		DWORD dwMinutes = 0;
		for (; _istdigit(*pcsz); ++pcsz)
			dwMinutes = dwMinutes * 10 + DWORD(*pcsz - '0');

		dwMinutes = min(dwMinutes, 59);

		m_dwLatLong = dwDegrees * dwLatLongDegreeMultiplier + (dwMinutes * dwLatLongDegreeMultiplier) / 60;

		DWORD dwMinuteMultiplier = dwLatLongDegreeMultiplier / 60;

		// Decimal minutes
		if (*pcsz == '.')
		{
			++pcsz;

			DWORD dwDecimaiMinuteDivisor = 1;
			DWORD dwDecimaiMinutes = 0;
			for (; _istdigit(*pcsz); ++pcsz)
			{
				dwDecimaiMinutes = dwDecimaiMinutes * 10 + DWORD(*pcsz - '0');
				dwDecimaiMinuteDivisor *= 10;
			}

			dwDecimaiMinutes = dwDecimaiMinutes * dwMinuteMultiplier / dwDecimaiMinuteDivisor;
			dwDecimaiMinutes = min(dwDecimaiMinutes, dwMinuteMultiplier - 1);

			m_dwLatLong += dwDecimaiMinutes;
		}
		// Seconds
		else if (*pcsz == ':')
		{
			++pcsz;

			DWORD dwSeconds = 0;
			for (; _istdigit(*pcsz); ++pcsz)
				dwSeconds = dwSeconds * 10 + DWORD(*pcsz - '0');

			dwSeconds = min(dwSeconds, 59);

			m_dwLatLong += (dwSeconds * dwMinuteMultiplier) / 60;

			// Decimal seconds
			if (*pcsz == '.')
			{
				++pcsz;

				DWORD dwSecondMultiplier = dwMinuteMultiplier / 60;

				DWORD dwDecimalSecondDivisor = 1;
				DWORD dwDecimalSeconds = 0;
				for (; _istdigit(*pcsz); ++pcsz)
				{
					dwDecimalSeconds = dwDecimalSeconds * 10 + DWORD(*pcsz - '0');
					dwDecimalSecondDivisor *= 10;
				}

				dwDecimalSeconds = dwDecimalSeconds * dwSecondMultiplier / dwDecimalSecondDivisor;
				dwDecimalSeconds = min(dwDecimalSeconds, dwSecondMultiplier - 1);

				m_dwLatLong += dwDecimalSeconds;
			}
		}
	}
	// If at 8 digits were specified, this was a fixed point number in proper format for us
	// Just use the number "as-is"
	else if (iDegreeDigits == 8)
	{
		m_dwLatLong = dwDegrees;
	}
	// If at 9 digits were specified, this was a fixed point number
	// Just use the number "as-is"
	else if (iDegreeDigits == 9)
	{
		m_dwLatLong = dwDegrees / 10;
	}
	// Just degrees were specified
	else
	{
		m_dwLatLong = min(dwDegrees, 180) * dwLatLongDegreeMultiplier;
	}

	// Limit to a valid range
	m_dwLatLong = min(m_dwLatLong, 180 * dwLatLongDegreeMultiplier);

	// Add the sign on
	if (fMinus)
		m_dwLatLong |= dwLatLongSignFlag;
	else
		m_dwLatLong &= dwLatLongSignMask;
}

bool CIuLatLongUnit::IsValid() const
{
	return !LATLONGINVALID(m_dwLatLong);
}

bool CIuLatLongUnit::IsZero() const
{
	return m_dwLatLong == 0;
}

void CIuLatLongUnit::NonNegative()
{
	m_dwLatLong &= dwLatLongSignMask;
}

CIuLatLongUnit::operator CString() const
{
	return AsString();
}

CIuLatLongUnit& CIuLatLongUnit::operator=(LPCTSTR pcsz)
{
	FromString(pcsz);
	return *this;
}

CIuLatLongUnit CIuLatLongUnit::operator+(LPCTSTR s) const
{
	return CIuLatLongUnit(s);	
}

CIuLatLongUnit CIuLatLongUnit::operator+(DWORD dw) const
{
	return CIuLatLongUnit(dw);
}

CIuLatLongUnit CIuLatLongUnit::operator-(LPCTSTR s) const
{
	return CIuLatLongUnit(s);	
}

CIuLatLongUnit CIuLatLongUnit::operator-(DWORD dw) const
{
	return CIuLatLongUnit(dw);
}

CIuLatLongUnit& CIuLatLongUnit::operator+=(LPCTSTR s)
{
	return *this = *this + s;
}

CIuLatLongUnit& CIuLatLongUnit::operator+=(DWORD dw)
{
	return *this = *this + dw;
}

CIuLatLongUnit& CIuLatLongUnit::operator-=(LPCTSTR s)
{
	return *this = *this - s;
}

CIuLatLongUnit& CIuLatLongUnit::operator-=(DWORD dw)
{
	return *this = *this - dw;
}

bool CIuLatLongUnit::operator<(const CIuLatLongUnit& LatLongUnit) const
{
	// NOTE: m_dwLatLong is _not_ a two's complement number. It is
	// a one's complement and so must be treat specially in comparison
	// No that comparing a lat or int is for GT/LT is not really meaningful
	// within establishing some origin.
	// So, we basically just ignore the minus sign
	return (m_dwLatLong & dwLatLongSignMask) < (LatLongUnit.m_dwLatLong & dwLatLongSignMask);
}

bool CIuLatLongUnit::operator<=(const CIuLatLongUnit& LatLongUnit) const
{
	// See operator<
	return (m_dwLatLong & dwLatLongSignMask) <= (LatLongUnit.m_dwLatLong & dwLatLongSignMask);
}

bool CIuLatLongUnit::operator>(const CIuLatLongUnit& LatLongUnit) const
{
	// See operator<
	return (m_dwLatLong & dwLatLongSignMask) > (LatLongUnit.m_dwLatLong & dwLatLongSignMask);
}

bool CIuLatLongUnit::operator>=(const CIuLatLongUnit& LatLongUnit) const
{
	// See operator<
	return (m_dwLatLong & dwLatLongSignMask) >= (LatLongUnit.m_dwLatLong & dwLatLongSignMask);
}
