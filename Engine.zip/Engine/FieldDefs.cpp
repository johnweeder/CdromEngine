#include "stdafx.h"
//{{Include
#include "FieldDefs.h"
#include "resource.h"
#include "Data\Archive.h"
#include "FieldDefs.h"
#include "Data\Output.h"
#include "Common\String.h"
#include "FieldName.h"
#include "Error\Error.h"
#include "FieldDefConst.h"
#include "RecordDefSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuFieldDefs, CIuFieldDefs_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldDefs)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_FIELDDEFS, CIuFieldDefs, CIuFieldDefs_super)
//{{AttributeMap
	IU_ATTRIBUTE_ACTION(CIuFieldDefs, IDS_ENGINE_ACTION_ADJUST, ActionAdjust, 0)

	IU_ATTRIBUTE_PAGE(CIuFieldDefs, IDS_ENGINE_PPG_FIELDDEFS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuFieldDefs, IDS_ENGINE_PPG_FIELDDEFS, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuFieldDefs, IDS_ENGINE_ACTION_ADJUST, IDS_ENGINE_PPG_FIELDDEFS, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldDefs::CIuFieldDefs()
{

	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize

	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuFieldDefs::CIuFieldDefs(const CIuFieldDefs& rFieldDefs)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	*this = rFieldDefs;
}

CIuFieldDefs::~CIuFieldDefs()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuFieldDefs::ActionAdjust(const CIuPropertyCollection&, CIuOutput&)
{
	Adjust();
	return CString("Success");
}

int CIuFieldDefs::AddFieldDef(LPCTSTR pcszDef)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuFieldDef& FieldDef = Get(iIndex);
	FieldDef.SetSpec(pcszDef);
	return iIndex;
}

int CIuFieldDefs::AddFieldDef(CIuFieldDefSpec& spec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuFieldDef& FieldDef = Get(iIndex);
	FieldDef.SetSpec(spec);
	return iIndex;
}

void CIuFieldDefs::Adjust()
{
	OnAdjust();
}

void CIuFieldDefs::OnAdjust()
{
	// This is a virtual function used by special record def types to "validate" a record
	// definition. For example, a fixed length record might adjust the fields so that they
	// don't overlap.

	// Rules:
	// Name:
	//		Valid identifier (so that it works with the console and expression evaluators).
	//		Unique.
	//		No length restriction
	//	Short Name: 
	//		Valid identifier. 
	//		Less than 10 characters (for DB support)
	//		Unique.
	//	Long Name: 
	//		No character restrictions.
	//		No length restrictions.
	//		Unique.

	// Check all names
	CString sOriginalName;
	CString sNewName;
	bool fDuplicate = true;

	int iFields = GetCount();
	for (int iField = 0; iField < iFields; ++iField)
	{
		CIuFieldDef& fieldDef = Get(iField);

		// Validate name
		sOriginalName = fieldDef.GetName();
		sNewName = sOriginalName;
		ASSERT(!sNewName.IsEmpty());
		if (sNewName.IsEmpty())
		{
			sNewName.Format("Field%03d", iField);
		}
		if (!IsIdentifier(sNewName, true))
		{
			VERIFY(MakeFieldName(sNewName, sOriginalName, fieldDftLength));
			fieldDef.SetName(sNewName);
		}

		fDuplicate = true;
		for (int iTry = 1; fDuplicate; ++iTry)
		{
			fDuplicate = false;
			for (int iField2 = iField + 1; iField2 < iFields; ++iField2)
			{
				if (sNewName.CompareNoCase(Get(iField2).GetName()) == 0)
				{
					fDuplicate = true;
					break;
				}
			}
			if (fDuplicate)
			{
				if (!MakeFieldName(sNewName, sOriginalName, fieldDftLength, iTry))
					Error(IU_E_DUPLICATE_FIELD_NAME, LPCTSTR(sOriginalName));
			}
		}

		if (sNewName.CompareNoCase(sOriginalName) != 0)
		{
#ifdef _DEBUG
			if (!sOriginalName.IsEmpty())
				TRACE("NOTE: Field name '%s' changed to '%s'\n", LPCTSTR(sOriginalName), LPCTSTR(sNewName));
#endif
			fieldDef.SetName(sNewName);
		}

		// Validate int name
		sOriginalName = fieldDef.GetLongName();
		sNewName = sOriginalName;
		if (sNewName.IsEmpty())
		{
			sNewName = fieldDef.GetName();
		}

		fDuplicate = true;
		for (iTry = 1; fDuplicate; ++iTry)
		{
			fDuplicate = false;
			for (int iField2 = iField + 1; iField2 < iFields; ++iField2)
			{
				if (sNewName.CompareNoCase(Get(iField2).GetLongName()) == 0)
				{
					fDuplicate = true;
					break;
				}
			}
			if (fDuplicate)
			{
				if (!MakeFieldName(sNewName, sOriginalName, fieldDftLength, iTry))
					Error(IU_E_DUPLICATE_FIELD_NAME, LPCTSTR(sOriginalName));
			}
		}

		if (sNewName.CompareNoCase(sOriginalName) != 0)
		{
#ifdef _DEBUG
			if (!sOriginalName.IsEmpty())
				TRACE("NOTE: Long field name '%s' changed to '%s'\n", LPCTSTR(sOriginalName), LPCTSTR(sNewName));
#endif
			fieldDef.SetLongName(sNewName);
		}

		// Validate short name
		sOriginalName = fieldDef.GetShortName();
		sNewName = sOriginalName;
		if (sNewName.IsEmpty())
		{
			sNewName = fieldDef.GetName();
		}
		if (!IsIdentifier(sNewName, true) || sOriginalName.GetLength() > MaxShortNameLength)
		{
			VERIFY(MakeFieldName(sNewName, sOriginalName, MaxShortNameLength));
			fieldDef.SetName(sNewName);
		}

		fDuplicate = true;
		for (iTry = 1; fDuplicate; ++iTry)
		{
			fDuplicate = false;
			for (int iField2 = iField + 1; iField2 < iFields; ++iField2)
			{
				if (sNewName.CompareNoCase(Get(iField2).GetShortName()) == 0)
				{
					fDuplicate = true;
					break;
				}
			}
			if (fDuplicate)
			{
				if (!MakeFieldName(sNewName, sOriginalName, MaxShortNameLength, iTry))
					Error(IU_E_DUPLICATE_FIELD_NAME, LPCTSTR(sOriginalName));
			}
		}

		if (sNewName.CompareNoCase(sOriginalName) != 0)
		{
#ifdef _DEBUG
			if (!sOriginalName.IsEmpty())
				TRACE("NOTE: Short field name '%s' changed to '%s'\n", LPCTSTR(sOriginalName), LPCTSTR(sNewName));
#endif
			fieldDef.SetShortName(sNewName);
		}
	}

	// Verify record length. Increase the record length if necessary to accomodate
	// all the fields.
	int iLength = 1;
	for (iField = 0; iField < iFields; ++iField)
	{
		int iFieldLength = Get(iField).GetLength();
		if (iFieldLength < 1)
		{
			Get(iField).SetLength(1);
			iFieldLength = 1;
		}
		int iFieldOffset = Get(iField).GetOffset();
		iLength = max(iLength, iFieldOffset + iFieldLength);
	}
}

CIuCollectablePtr CIuFieldDefs::OnNew(CWnd*) const
{
	CIuFieldDefPtr pFieldDef;
	pFieldDef.Create();
	return pFieldDef;
}

CIuFieldDefs& CIuFieldDefs::operator=(const CIuFieldDefs& rFieldDefs)
{
	if (this == &rFieldDefs)
		return *this;
	Copy(rFieldDefs);
	return *this;
}

void CIuFieldDefs::SetSpec(CIuRecordDefSpec& RecordDefSpec)
{
	RemoveAll();
	int iOffset = 0;
	for (int iField = 0; iField < RecordDefSpec.GetFieldDefCount(); ++iField)
	{
		int iIndex = AddFieldDef(RecordDefSpec.GetFieldDef(iField));

		CIuFieldDef& field = Get(iIndex);
		field.SetOffset(iOffset);
		iOffset += field.GetLength();
	}

	Adjust();
}
