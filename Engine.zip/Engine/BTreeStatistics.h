#ifndef _ENGINE_BTREESTATISTICS_H_
#define _ENGINE_BTREESTATISTICS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_NYBBLEDELTASTATISTICS_H_
#	include "Common\NybbleDeltaStatistics.h"
#endif	// _COMMON_NYBBLEDELTASTATISTICS_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeStatistics, CIuNybbleDeltaStatistics }}
#define CIuBTreeStatistics_super CIuNybbleDeltaStatistics

class CIuBTreeStatistics : public CIuBTreeStatistics_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeStatistics();
	virtual ~CIuBTreeStatistics();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	void Output(CIuOutput& Output);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	CString Percentage(__int64 iNum, __int64 iDen);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// Total nybbles in keys
	__int64 m_iTotalKeyNybbles;
	// Total fixed bits
	__int64 m_iTotalFixedBits;
	// Total variable bits
	__int64 m_iTotalVariableBits;
	// Total variable nybbles
	__int64 m_iTotalVariableNybbles;
	// Number of corrections for various geography components
	__int64 m_iTotalLatLongCentroidCorrections;
	__int64 m_iTotalLatCentroidDelta;
	__int64 m_iTotalLongCentroidDelta;
	__int64 m_iTotalLatLongMinMaxCorrections;
	__int64 m_iTotalLatMinMaxDelta;
	__int64 m_iTotalLongMinMaxDelta;
	__int64 m_iTotalCountyCorrections;
	__int64 m_iTotalMsaCorrections;
	__int64 m_iTotalCityCorrections;
	// Number of records w/ ZIP+4
	__int64 m_iTotalZip4;
	// Total number of alternate records included
	__int64 m_iTotalAlternates;
	// totals for bus/res records
	__int64 m_iTotalBus;
	__int64 m_iTotalRes;
	// Amount of data used for various btree components
	__int64 m_iTotalGeoBits;
	__int64 m_iTotalGeoNybbles;
	__int64 m_iTotalTokenVariableBits;
	__int64 m_iTotalTokenFixedBits;
	__int64 m_iTotalTokenNybbles;
	__int64 m_iTotalPhoneBits;
	__int64 m_iTotalPhoneNybbles;
	__int64 m_aiTotalPhoneFormat[5];
	__int64 m_iTotalBusBits;
	__int64 m_iTotalBusNybbles;
	__int64 m_iTotalMiscBits;
	__int64 m_iTotalMiscNybbles;
	__int64 m_iTotalOptionalBits;
	__int64 m_iTotalOptionalNybbles;
	__int64 m_iTotalAddressFixedBits;
	__int64 m_iTotalAddressVariableBits;
	__int64 m_iTotalAddressNybbles;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BTREESTATISTICS_H_
