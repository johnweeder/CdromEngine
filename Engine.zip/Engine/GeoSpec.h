#ifndef _ENGINE_GEOSPEC_H_
#define _ENGINE_GEOSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoSpec)
struct CIuGeoSpecDft;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoSpec, CIuObjectNamed }}
#define CIuGeoSpec_super CIuObjectNamed
class CIuGeoSpec : public CIuGeoSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoSpec();
	virtual ~CIuGeoSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	CString GetCity() const;
	static int GetCount();
	CString GetCountyCode() const;
	int GetGeoNo() const;
	CString GetLatitude() const;
	CString GetLongitude() const;
	CString GetMatchLevel() const;
	CString GetMsaCode() const;
	void GetPhones(CStringArray& as) const;
	CString GetState() const;
	CString GetZip() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iGeoSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszGeo);
	void FromNo(CIuCdromSpec* pCdrom, int iGeoNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuGeoSpecDft* pGeoSpec);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetCity(LPCTSTR);
	void SetCountyCode(LPCTSTR);
	void SetGeoNo(int);
	void SetLatitude(LPCTSTR);
	void SetLongitude(LPCTSTR);
	void SetMatchLevel(LPCTSTR);
	void SetMsaCode(LPCTSTR);
	void SetPhones(const CStringArray&);
	void SetState(LPCTSTR);
	void SetZip(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	int m_iGeoNo;
	CString m_sZip;
	CString m_sCity;
	CString m_sState;
	CString m_sMsaCode;
	CString m_sCountyCode;
	CString m_sLatitude;
	CString m_sLongitude;
	CStringArray m_asPhones;
	CString m_sMatchLevel;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuGeoSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuGeoSpec::GetCity() const
{
	return m_sCity;
}

inline CString CIuGeoSpec::GetCountyCode() const
{
	return m_sCountyCode;
}

inline int CIuGeoSpec::GetGeoNo() const
{
	return m_iGeoNo;
}

inline CString CIuGeoSpec::GetLatitude() const
{
	return m_sLatitude;
}

inline CString CIuGeoSpec::GetLongitude() const
{
	return m_sLongitude;
}

inline CString CIuGeoSpec::GetMatchLevel() const
{
	return m_sMatchLevel;
}

inline CString CIuGeoSpec::GetMsaCode() const
{
	return m_sMsaCode;
}

inline CString CIuGeoSpec::GetState() const
{
	return m_sState;
}

inline CString CIuGeoSpec::GetZip() const
{
	return m_sZip;
}

inline bool CIuGeoSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_GEOSPEC_H_
