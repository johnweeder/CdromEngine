#include "StdAfx.h"
//{{Include
#include "GeoList.h"
#include "GeoRawElementAccumulator.h"
#include "GeoRawElementMap.h"
#include "GeoElementCollection.h"
#include "Interop\Conversions.h"
#include "Common\NybbleInt.h"
#include "Common\NybbleString.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoList, CIuGeoList_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoList)
//}}Implement

CIuGeoList::CIuGeoList() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoList::CIuGeoList(const CIuGeoList& rGeoList)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	*this = rGeoList;
}

CIuGeoList::~CIuGeoList()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoList::Add(int iLo, int iHi)
{
	// This function is optimized for inserting on to the end of a geo list
	// It is much less efficient when simply appending at random
	if (iHi < 0)
		iHi = iLo;
	ASSERT(iLo >= 0);
	ASSERT(iLo <= iHi);

	if (m_aiLo.GetSize() == 0)
	{
		// Insert as first element.
		m_aiLo.Add(iLo);
		m_aiHi.Add(iHi);
		return ;
	}	
	// Check for overlap with an existing
	// Note, we start from the end of the list
	// because we typically add in increasing order. 
	// This allows use to early out for performance
	for (int i = m_aiLo.GetSize() - 1; i >= 0; --i)
	{
		int iRangeHi = m_aiHi[i];
		if (iLo > iRangeHi + 1)
		{
			m_aiLo.InsertAt(i + 1, iLo);
			m_aiHi.InsertAt(i + 1, iHi);
			return ;
		}
		// If the new range butts up against or is included in the current range or includes,
		// the current range, simply extend the existing range.
		int iRangeLo = m_aiLo[i];
		if ((iLo >= iRangeLo && iLo <= iRangeHi + 1) ||
			(iHi >= iRangeLo - 1 && iHi <= iRangeHi) ||
			(iLo <= iRangeLo && iHi >= iRangeHi))
		{
			iRangeLo = min(iLo, iRangeLo);
			m_aiLo.SetAt(i, iRangeLo);
			iRangeHi = max(iHi, iRangeHi);
			m_aiHi.SetAt(i, iRangeHi);
			break;
		}
	}

	// If still not added, insert at beginning
	if (i < 0)
	{
		m_aiLo.InsertAt(0, iLo);
		m_aiHi.InsertAt(0, iHi);
		return ;
	}

	// We've changed an existing range, lets see if we can merge it with those around it
	for (;;)
	{
		// Try to merge with previous range
		if (i > 0)
		{
			int iRangeHi1 = m_aiHi[i-1];
			int iRangeLo2 = m_aiLo[i];
			if (iRangeLo2 <= iRangeHi1 + 1)
			{
				int iRangeLo1 = m_aiLo[i-1];
				int iRangeHi2 = m_aiHi[i];
				iRangeLo1 = min(iRangeLo1, iRangeLo2);
				iRangeHi1 = max(iRangeHi1, iRangeHi2);
				m_aiLo.RemoveAt(i);
				m_aiHi.RemoveAt(i);
				m_aiLo.SetAt(i-1, iRangeLo1);
				m_aiHi.SetAt(i-1, iRangeHi1);
				--i;
				continue;
			}
		}
		// Try to merge with next range
		if (i < m_aiLo.GetSize() - 1)
		{
			int iRangeHi1 = m_aiHi[i];
			int iRangeLo2 = m_aiLo[i+1];
			if (iRangeLo2 <= iRangeHi1 + 1)
			{
				int iRangeLo1 = m_aiLo[i];
				int iRangeHi2 = m_aiHi[i+1];
				iRangeLo1 = min(iRangeLo1, iRangeLo2);
				iRangeHi1 = max(iRangeHi1, iRangeHi2);
				m_aiLo.RemoveAt(i + 1);
				m_aiHi.RemoveAt(i + 1);
				m_aiLo.SetAt(i, iRangeLo1);
				m_aiHi.SetAt(i, iRangeHi1);
				continue;
			}
		}
		break;
	}
#ifdef _DEBUG
	Validate();
#endif
}

void CIuGeoList::Clear()
{
	CIuGeoList_super::Clear();
	m_aiLo.RemoveAll();
	m_aiHi.RemoveAll();
}

int CIuGeoList::Compress(CIuGeoRawElementAccumulator& Accumulator, CIuGeoRawElementMap& Map, CIuNybbleBuffer& buffer)
{
	// This could go in the GeoRawElementAccumulator class but I put it here to keep the comressor and
	// decompressor in the same file.

	// First, create a sorted list of indexes
	CIntArray List;

	Accumulator.SortByName();

	int iCount = Accumulator.GetAccumulated();
#ifdef _DEBUG
	int iDebugPreviousIndex = -1;
#endif
	for (int i = 0; i < iCount; ++i)
	{
		CString sName = Accumulator.GetName(i);
		__int32 iIndex;
		if (Map.Lookup(sName, iIndex))
		{
			List.Add(iIndex);
#ifdef _DEBUG
			ASSERT(iIndex > iDebugPreviousIndex);
			iDebugPreviousIndex = iIndex;
#endif
		}
		else
		{
			// This should not happen!
			ASSERT(false);
		}
	}

	// Compression consists of either outputting the geo element index
	// or a range of indexes.
	// The first index is always stored as a constant value.
	// The index is offset by 1. An index value of zero means that
	// no indexes are stored.
	// All succeeding indexes are stored as a delta from the previous index.
	// A delta of "0" means that a range is starting. A range consists of a start delta and a count.
	//		A range always consists of at least 3 index values...
	int iExpandedSize = 0;

	iCount = List.GetSize();
	int iPreviousIndex = 0;
	if (iCount > 0)
		iPreviousIndex = List[0];
	for (i = 0; i < iCount;)
	{
		// Check for a range
		for (int j = i + 1; j < iCount; ++j)
		{
			if (List[j] != List[j-1] + 1)
				break;
		}

		int iRange = j - i;
		ASSERT(iRange >= 1);

		// If range is >= 3, output a zero to indicate a range
		if (iRange >= 3)
		{
			CIuNybbleInt::AppendUIntCompressed(0, buffer);
		}
		else
			iRange = 1;

		// Output the delta or initial element
		int iIndex = List[i];
		if (i > 0)
		{
			int iDelta = iIndex - iPreviousIndex;
			ASSERT(iDelta > 0);
			CIuNybbleInt::AppendUIntCompressed(iDelta, buffer);
		}
		else
		{
			// Offset by one so it is not confused with a range
			ASSERT(iIndex + 1 > 0);
			CIuNybbleInt::AppendUIntCompressed(iIndex + 1, buffer);
		}

		// If ranged, output the range. Note that the range _must_ be
		// output after the index, because the "Range-3" value might be 
		// zero (which would signify end of List).
		if (iRange >= 3)
		{
			// Output the actual range
			// Offset range by 3, since a range of at least 3 is implied.
			CIuNybbleInt::AppendUIntCompressed(iRange - 3, buffer);
		}

		if (iRange > 1)
			iExpandedSize += 2 * sizeof(int);
		else
			iExpandedSize += 1 * sizeof(int);

		iPreviousIndex = iIndex + iRange - 1;
		i += iRange;
	}

	// Terminate the List with two nulls (i.e. a range of length zero)
	CIuNybbleInt::AppendUIntCompressed(0, buffer);
	CIuNybbleInt::AppendUIntCompressed(0, buffer);

	// Returns the number of bytes needed to expand the list
	// Add terminator size
	iExpandedSize += 1 * sizeof(int);
	return iExpandedSize;
}

void CIuGeoList::Copy(const CIuObject& object)
{
	CIuGeoList_super::Copy(object);

	const CIuGeoList* pGeoList = dynamic_cast<const CIuGeoList*>(&object);
	if (pGeoList == 0 || pGeoList == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuGeoList)));
	m_aiLo.Copy(pGeoList->m_aiLo);
	m_aiHi.Copy(pGeoList->m_aiHi);
}

int CIuGeoList::DeCompress(CIuGeoElementCollection& Collection, const CIuNybbleBuffer& buffer, int iOffset)
{
	// This is simply a reversing of the encoding described above.
	int iPreviousIndex = -1;
	for (;;)
	{
		int iIndex = -1;
		int iRange = 1;

		unsigned int uiVal;
		iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, buffer, iOffset);

		int iValue = uiVal;

		// If it is a null, this is the start of a range
		if (iValue == 0)
		{
			iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, buffer, iOffset);
			iIndex = uiVal;
			if (iIndex == 0)
				break;

			// A second null terminates the list
			iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, buffer, iOffset);
			iRange = uiVal;
			iRange += 3;
		}
		else
		{
			iIndex = iValue;
		}

		ASSERT(iIndex > 0);
		if (iPreviousIndex < 0)
			iIndex = iIndex - 1;
		else
			iIndex += iPreviousIndex;

		int iLo = iIndex;
		ASSERT(iLo >= 0);
		++iLo;
		int iHi = iIndex + iRange - 1;
		++iHi;
		ASSERT(iLo <= iHi);
		if (iLo == iHi)
		{
			ASSERT(iLo != 0);
			iLo = -iLo;
			Collection.AddElementData((const BYTE*)&iLo, sizeof(iLo));
		}
		else
		{
			Collection.AddElementData((const BYTE*)&iLo, sizeof(iLo));
			Collection.AddElementData((const BYTE*)&iHi, sizeof(iHi));
		}

		iPreviousIndex = iIndex + iRange - 1;
	}

	int iTerminator = 0;
	Collection.AddElementData((const BYTE*)&iTerminator, sizeof(iTerminator));

	return iOffset;
}

void CIuGeoList::Dump() const
{
#ifdef _DEBUG
	TRACE("GEOLIST with %d elements\n", GetCount());
	for (int iRange = 0; iRange < GetCount(); ++iRange)
	{
		int iLo, iHi;
		Get(iRange, iLo, iHi);
		ASSERT(iLo <= iHi);
		if (iLo == iHi)
			TRACE("\t%6d\n", iLo);
		else
			TRACE("\t%6d - %6d\n", iLo, iHi);
	}
#endif
}

const BYTE* CIuGeoList::Extract(const BYTE* pb)
{
	ASSERT(pb);
	const int* pi = (const int*)pb;

	for (;;)
	{
		if (*pi == 0)
		{
			++pi;			
			break;
		}
		else if (*pi < 0)
		{
			int iElement = *pi;
			iElement = -iElement;
			ASSERT(iElement > 0);
			--iElement;
			Add(iElement, iElement);
			++pi;			
		}
		else
		{
			int iLo = pi[0] - 1;
			ASSERT(iLo >= 0);
			int iHi = pi[1] - 1;
			ASSERT(iHi >= 0);
			ASSERT(iLo < iHi);
			Add(iLo, iHi);
			pi += 2;
		}
	}
	return (const BYTE*)pi;
}

void CIuGeoList::Get(int iIndex, int& iLo, int& iHi) const
{
	iLo = m_aiLo[iIndex];
	iHi = m_aiHi[iIndex];
}

void CIuGeoList::Intersection(const CIuGeoList& GeoList1, const CIuGeoList& GeoList2)
{
	Clear();
	GeoList1.Validate();
	GeoList2.Validate();
	// This is a more common operation so we work at making it reasonable efficient.
	int iCount1 = GeoList1.GetCount();
	int i1 = 0;
	int iCount2 = GeoList2.GetCount();
	int i2 = 0;
	while (i1 < iCount1)
	{
		int iLo1 = GeoList1.m_aiLo[i1];
		int iHi1 = GeoList1.m_aiHi[i1];

		while (i2 < iCount2 && iLo1 > GeoList2.m_aiHi[i2])
			++i2;
		if (i2 >= iCount2)
			return ;
		int iLo2 = GeoList2.m_aiLo[i2];
		int iHi2 = GeoList2.m_aiHi[i2];

		ASSERT(iLo1 <= iHi2);
		if (iHi1 < iLo2)
		{
			++i1;
			continue;
		}

		// Add a new range
		int iAddLo = max(iLo1, iLo2);
		int iAddHi = min(iHi1, iHi2);
		ASSERT(iAddLo <= iAddHi);
		Add(iAddLo, iAddHi);

		// Be careful, don't just increment i1 or i2 arbitrarily.
		// Remember that a range in one list can span zero or more
		// ranges in the other. 
		// So, pick the list with the lowest "hi" in the current range
		// and increment it
		if (iHi1 < iHi2)
		{
			++i1;
		}
		else if (iHi2 < iHi1)
		{
			++i2;
		}
		else
		{
			++i1;
			++i2;
		}
	}
	Validate();
}

bool CIuGeoList::IsEmpty() const
{
	return m_aiLo.GetSize() == 0;
}

CIuGeoList& CIuGeoList::operator=(const CIuGeoList& rGeoList)
{
	Copy(rGeoList);
	return *this;
}

bool CIuGeoList::operator!=(const CIuGeoList& rList) const
{
	return !operator==(rList);
}

bool CIuGeoList::operator==(const CIuGeoList& rList) const
{
	if (this == &rList)
		return true;

	if (m_aiLo.GetSize() != rList.m_aiLo.GetSize())
		return false;

	int iCount = m_aiLo.GetSize();
	for (int i = 0; i < iCount; ++i)
		if (m_aiLo[i] != rList.m_aiLo[i] || m_aiHi[i] != rList.m_aiHi[i])
			return false;

	return true;
}

void CIuGeoList::RemoveAll()
{
	m_aiLo.RemoveAll();
	m_aiHi.RemoveAll();
}

void CIuGeoList::Retrieve(int* pi)
{
	ASSERT(pi);
	for (int i = 0; *pi; ++i)
	{
		int iLo = *pi;
		++pi;
		m_aiLo.SetAtGrow(i, iLo);
		if (iLo < 0)
		{
			m_aiHi.SetAtGrow(i, iLo);
		}
		else
		{
			int iHi = *pi;
			++pi;
			ASSERT(iHi >= iLo);
			m_aiHi.SetAtGrow(i, iHi);
		}
	}
	m_aiLo.SetSize(i);
	m_aiHi.SetSize(i);
	Validate();
}

void CIuGeoList::Union(const CIuGeoList& GeoList1, const CIuGeoList& GeoList2)
{
	Clear();
	GeoList1.Validate();
	GeoList2.Validate();
	// Low performance... copy... then add the other
	(*this) = GeoList1;
	for (int i = 0; i < GeoList2.m_aiLo.GetSize(); ++i)
		Add(GeoList2.m_aiLo[i], GeoList2.m_aiHi[i]);
}

void CIuGeoList::Validate() const
{
#ifdef _DEBUG
	ASSERT(m_aiLo.GetSize() == m_aiHi.GetSize());
	for (int i = 0; i < m_aiLo.GetSize(); ++i)
	{
		ASSERT(m_aiLo[i] <= m_aiHi[i]);
		ASSERT(m_aiLo[i] >= 0);
		if (i > 0)
		{
			ASSERT(m_aiLo[i] > m_aiHi[i - 1]);
		}
	}
#endif
}
