#include "StdAfx.h"
//{{Include
#include "BTreePointers.h"
#include "BTree.h"
#include "Data\FileVirtual.h"
#include "Data\PrefixFile.h"
#include "Data\DataFilename.h"
#include "Data\PackRepository.h"
#include "resource.h"
#include "Error\Error.h"
#include "Cdrom.h"
#include "CdromSpecConst.h"
#include "Miscellaneous.h"
#include "SetLists.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreePointers, CIuBTreePointers_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreePointers)
const	CIuVersionNumber versionBTreePointersMax(2000,1,5,304);
const	CIuVersionNumber versionBTreePointersMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREEPOINTERS, CIuBTreePointers, CIuBTreePointers_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreePointers, IDS_ENGINE_PROP_POINTERS, GetPointers, SetPointers, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreePointers, IDS_ENGINE_PROP_BLOCKS, GetBlocks, SetBlocks, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreePointers, IDS_ENGINE_PROP_BITSPERPOINTER, GetBitsPerPointer, SetBitsPerPointer, 0)

	IU_ATTRIBUTE_PAGE(CIuBTreePointers, IDS_ENGINE_PPG_BTREEPOINTERS, 50, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreePointers, IDS_ENGINE_PROP_POINTERS, IDS_ENGINE_PPG_BTREEPOINTERS, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreePointers, IDS_ENGINE_PROP_BLOCKS, IDS_ENGINE_PPG_BTREEPOINTERS, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreePointers, IDS_ENGINE_PROP_BITSPERPOINTER, IDS_ENGINE_PPG_BTREEPOINTERS, 0, INT_MAX, editorReadOnly)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl SortUint32(const void *elem1, const void *elem2)
{
	return int(*((const UINT32*)elem1) - *((const UINT32*)elem2));
}

CIuBTreePointers::CIuBTreePointers() 
{
	//{{Initialize
	m_iBlock = -1;
	m_iBlocks = 0;
	m_fAppending = false;
	m_iPointers = 0;
	m_iBitsPerPointer = 0;
	m_pObjectRepository = 0;
	m_iPointersPerBlock = 0;
	SetVersion(versionBTreePointersMax);
	//}}Initialize
}

CIuBTreePointers::~CIuBTreePointers()
{
	Close();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBTreePointers::AddSetList(CIuSetLists& SetLists, CIuOutput* pOutput, CIuID& ID, UINT32 uiLo, UINT32 uiCount, UINT32 uiMin, UINT32 uiMax)
{
	ASSERT(uiLo >= 0 && uiLo < (UINT32)GetPointers());
	ASSERT(uiLo + uiCount <= (UINT32)GetPointers());
	ASSERT(GetBitsPerPointer() > 0);

	UINT32 uiBitsPerPointer = GetBitsPerPointer();
	UINT32 uiPointersPerBlock = GetBlockSize() * 8 / uiBitsPerPointer;
	UINT32 uiEnd = uiLo + uiCount;
	UINT32 uiSrcNo = ID;

	while (uiLo < uiEnd)
	{
		if (pOutput && !pOutput->Fire(IU_EVENT_OPERATION_CONTINUE))
			return false;

		UINT32 uiBlock = uiLo / uiPointersPerBlock;
		if (uiBlock != (UINT32)m_iBlock)
			ReadBlock(uiBlock);

		UINT32 uiBlockPointer = uiLo % uiPointersPerBlock;
		UINT32 uiPointersRemainingInBlock = uiPointersPerBlock - uiBlockPointer;
		UINT32 uiOffset = uiBlockPointer * uiBitsPerPointer;

		uiPointersRemainingInBlock = min(uiPointersRemainingInBlock, uiEnd - uiLo);

		for (UINT32 uiPointer = 0; uiPointer < uiPointersRemainingInBlock; )
		{
			// To be efficient, we use the call to unpack an array of integers
			const UINT32 iMaxInts = 4096;
			UINT32 auiInts[iMaxInts];
			UINT32 uiPointers = min(iMaxInts, uiPointersRemainingInBlock);

			bool fAscending;
			uiOffset += m_block.GetInts(auiInts, uiPointers, uiBitsPerPointer, uiOffset, fAscending);
			if (!fAscending)
				qsort(auiInts, uiPointers, sizeof(UINT32), SortUint32);

			SetLists.Add(uiSrcNo, auiInts, uiPointers, uiMin, uiMax);

			uiLo += uiPointers;
			uiPointer += uiPointers;
			uiPointersRemainingInBlock -= uiPointers;
		}
	}
	return true;
}

void CIuBTreePointers::Append(const CDWordArray& adw)
{
	DWORD dwPrev = 0;
	int iPointers = adw.GetSize();
	for (int iPointer = 0; iPointer < iPointers; ++iPointer)
	{
		DWORD dwThis = adw[iPointer];
		if (iPointer && dwThis <= dwPrev)
		{
			CString sError;
			sError.Format(_T("Indexes pointers out of order @ %d\n%d\n%d"), m_iPointers, dwPrev, dwThis);
			Error(IU_E_COMPRESS_FATAL, LPCTSTR(sError));
		}
		Append(dwThis);
		dwPrev = dwThis;
	}
}

void CIuBTreePointers::Append(DWORD dwPointerNo)
{
	ASSERT(GetBitsPerPointer() > 0);
	ASSERT(m_fAppending);
	if (GetBlockSize() * 8 - m_block.GetBitCount() < GetBitsPerPointer())
	{
		ASSERT((m_iPointers % (m_iPointersPerBlock)) == 0);
		WriteBlock();
	}
#ifdef _DEBUG
	int iBits = m_block.GetBitCount();
#endif
	m_block.AppendInt(dwPointerNo, GetBitsPerPointer());

#ifdef _DEBUG
	UINT32 iPointerNo;
	m_block.GetInt(iPointerNo, GetBitsPerPointer(), iBits);
	ASSERT(DWORD(iPointerNo) == dwPointerNo);
#endif

	++m_iPointers;
}

bool CIuBTreePointers::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseFiles))
		GetObjectRepository().PackFile(GetBTree(), Cdrom.GetPack(), &Output, GetFilename());
	return Output.Fire();
}

void CIuBTreePointers::Close()
{
	if (m_fAppending)
	{
		if (m_block.GetBitCount() > 0)
			WriteBlock();
		m_pFile->SetData(*this);
	}
	m_pVFile.Release();
	m_pFile.Release();
	m_iBlock = -1;
	m_fAppending = false;
}

void CIuBTreePointers::Create(CIuOutput&)
{
	Close();
	m_iBlocks = 0;
	m_iPointers = 0;
	m_pFile.Create();
	ASSERT(m_pObjectRepository);
	CIuFilename filename = GetObjectRepository().GetFullFilename(GetBTree(), GetFilename());
	m_pFile->Create(filename, 16 * 1024, CIuFile::openCreate);
	m_pVFile = m_pFile->Use();
	m_block.PreAllocate(GetBlockSize());
	m_fAppending = true;
	ASSERT(GetBitsPerPointer() > 0);
	m_iPointersPerBlock = GetBlockSize() * 8 / GetBitsPerPointer();
}

void CIuBTreePointers::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
}

DWORD CIuBTreePointers::Get(int iPointer)
{
	ASSERT(iPointer >= 0 && iPointer < GetPointers());
	ASSERT(GetBitsPerPointer() > 0);
	int iBlock = iPointer / m_iPointersPerBlock;
	if (iBlock != m_iBlock)
		ReadBlock(iBlock);

	int iOffset = iPointer % m_iPointersPerBlock;

	UINT32 iVal;
	m_block.GetInt(iVal, GetBitsPerPointer(), iOffset * GetBitsPerPointer());

	return DWORD(iVal);
}

int CIuBTreePointers::GetBlockSize() const
{
	return GetBTree().GetBlockSize();
}

CString CIuBTreePointers::GetFilename() const
{
	CString sName;
	sName += GetBTree().GetFilename();
	sName += _T(" Pointers");
	return sName;
}

CString CIuBTreePointers::GetFullFilename() const
{
	CString sFilename = GetObjectRepository().GetFullFilename(GetBTree(), GetFilename());
	return sFilename;
}

CIuVersionNumber CIuBTreePointers::GetVersionMax() const
{
	return versionBTreePointersMax;
}

CIuVersionNumber CIuBTreePointers::GetVersionMaxStatic()
{
	return versionBTreePointersMax;
}

CIuVersionNumber CIuBTreePointers::GetVersionMin() const
{
	return versionBTreePointersMin;
}

CIuVersionNumber CIuBTreePointers::GetVersionMinStatic()
{
	return versionBTreePointersMin;
}

bool CIuBTreePointers::IsOpen() const
{
	return m_pVFile.NotNull() && m_pVFile->IsOpen();
}

void CIuBTreePointers::Open(bool /* fDebug */)
{
	Close();
	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	GetObjectRepository().Use(GetBTree(), m_pFile, m_pVFile, GetFilename(), 0, 0);

	m_block.PreAllocate(GetBlockSize());
	m_iBlock = -1;
	m_iPointersPerBlock = GetBlockSize() * 8 / GetBitsPerPointer();
}

void CIuBTreePointers::ReadBlock(int iBlock)
{
	ASSERT(iBlock >= 0 && iBlock < m_iBlocks);
	if (iBlock == m_iBlock)
		return ;
	m_pVFile->Seek(CIuFilePosition(iBlock) * GetBlockSize());
	m_pVFile->Read(m_block.GetData(), GetBlockSize());
	m_block.SetBitCount(GetBlockSize() * 8);
	m_iBlock = iBlock;
}

bool CIuBTreePointers::SanityCheck(CIuOutput& Output)
{
	// Output description, set range, etc
	Output.OutputF(_T("Validating BTree pointers in %s\n"), GetBTree().GetName());
	Output.OutputF(_T("\t%ld %d-bit pointers in %d blocks of size %d\n"), GetPointers(), GetBitsPerPointer(), GetBlocks(), GetBlockSize());

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	Output.SetMessageF(_T("Validating pointers\n"));
	Output.SetPosition(0);
	Output.SetRange(GetPointers());
	Output.Fire();

	int iCount = GetPointers();
	int iExpanded = GetBTree().GetBTreeExpandPtr()->GetCount(false);

	for (int iRecord = 0; iRecord < iCount; ++iRecord)
	{
		if ((iRecord % ((iCount + 99) / 100)) == 0)
		{
			Output.SetPosition(iRecord);
			if (!Output.Fire())
				return false;
		}

		// Simply expand out the pointer... 
		DWORD dwPointer = Get(iRecord);

		if (dwPointer >= DWORD(iExpanded))
			Error(IU_E_BTREE_INVALID, _T("Pointer exceeeds expanded record count."));
	}

	// Display elapsed time
	instance.Pop(true);

	return true;
}

void CIuBTreePointers::SetBitsPerPointer(int iBitsPerPointer)
{
	m_iBitsPerPointer = iBitsPerPointer;
}

void CIuBTreePointers::SetBlocks(int i)
{
	m_iBlocks = i;
}

void CIuBTreePointers::SetBTree(CIuBTreePtr pBTree)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pBTree = pBTree;
}

void CIuBTreePointers::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuBTreePointers::SetPointers(int iPointers)
{
	m_iPointers = iPointers;
}

void CIuBTreePointers::SetSpec(CIuBTreeSpec&)
{
}

void CIuBTreePointers::SetVersion(CIuVersionNumber ver)
{
	m_verVersion = ver;
}

void CIuBTreePointers::WriteBlock()
{
	if (m_block.GetBitCount() <= 0)
		return ;
	ASSERT(m_block.GetBitCount() > 0);
	m_pVFile->Seek(CIuFilePosition(m_iBlocks)  * GetBlockSize());
	m_pVFile->Write(m_block.GetData(), GetBlockSize());
	++m_iBlocks;
	m_block.Clear();
}

