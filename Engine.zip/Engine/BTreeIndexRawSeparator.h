#ifndef _ENGINE_BTREEINDEXRAWSEPARATOR_H_
#define _ENGINE_BTREEINDEXRAWSEPARATOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_INTEGER_H_
#	include "Interop\Integer.h"
#endif	// _INTEROP_INTEGER_H_
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
//}}Uses

//{{Predefines
class CIuBTreeIndexSeparator;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeIndexRawSeparator }}
// NOTE: Do NOT add virtual functions.
// This is a variable length data structure... be VERY careful in its use.
// There is no constructor or destructor... this class is normally cast directly over
// an existing memory location.
#pragma pack(1)
struct CIuBTreeIndexRawSeparator
{
	int Compare(const CIuKey&) const;
	void Get(CIuBTreeIndexSeparator&) const;
	int GetPointerNo() const;
	int GetRecordNo() const;
	const BYTE* GetSeparatorPtr() const
	{
		return reinterpret_cast<const BYTE*>(this) + sizeof(*this);
	}
	BYTE* GetSeparatorPtr() 
	{
		return reinterpret_cast<BYTE*>(this) + sizeof(*this);
	}
	int GetSeparatorSize() const
	{
		ASSERT(sizeof(*this) == 10);
		return m_wSize - sizeof(*this);
	}
	static int GetSizeNeeded(int iSize) 
	{
		ASSERT(iSize >= 0);
		return sizeof(CIuBTreeIndexRawSeparator) + iSize;
	}
	bool HasSeparator() const
	{
		return GetSeparatorSize() > 0;
	}
	bool IsContinuation() const;
	bool IsEob() const;
	const CIuBTreeIndexRawSeparator* Next() const
	{
		return reinterpret_cast<const CIuBTreeIndexRawSeparator*>(reinterpret_cast<const BYTE*>(this) + m_wSize);
	}
	CIuBTreeIndexRawSeparator* Next()
	{
		return reinterpret_cast<CIuBTreeIndexRawSeparator*>(reinterpret_cast<BYTE*>(this) + m_wSize);
	}
	void SetContinuation(bool fContinuation = true);
	void SetEob(bool fEob = true);
	void SetPointerNo(DWORD dwPointerNo);
	void SetRecordNo(DWORD dwRecordNo);
	void SetSize(WORD wSize)
	{
		ASSERT(wSize >= sizeof(*this));
		m_wSize = wSize;
	}

private:
	CIuUInt16 m_wSize;		// Total size of this structure
	CIuUInt32 m_dwRecordNo;	// Record number.
									// Bit 31 is set to indicate the last record in a block.
									// Bit 30: is a continuation flag which indicates that
									// this record matches the separator of the last record in the previous block
	CIuUInt32 m_dwPointerNo;// Pointer number for first record in block
#pragma warning(disable: 4200)
	BYTE m_bSeparator[];		// Separator data. May actually be empty...
#pragma warning(default: 4200)
									// This is actually a separator (not a separator). The individual fields
									// are separated with a null.
									// A null terminator is _not_ guaranteed
};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BTREEINDEXRAWSEPARATOR_H_
