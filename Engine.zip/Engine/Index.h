#ifndef _ENGINE_INDEX_H_ 
#define _ENGINE_INDEX_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuIndex)
IU_DEFINE_OBJECT_PTR(CIuRecordDef)
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuIndex, CIuCollectable_super }}
#define CIuIndex_super CIuCollectable

class IU_CLASS_EXPORT CIuIndex : public CIuIndex_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuIndex)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuIndex();
	virtual ~CIuIndex();
	CIuIndex(const CIuIndex&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuRecordDef& GetRecordDef() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuIndex& operator=(const CIuIndex&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetRecordDef_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuRecordDefPtr m_pRecordDef;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuRecordDef& CIuIndex::GetRecordDef() const
{
	return m_pRecordDef.Ref();
}

#endif 
