#ifndef _ENGINE_COMPARELIKE_H_
#define _ENGINE_COMPARELIKE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCompareLike, CObject }}
#define CIuCompareLike_super CObject

class CIuCompareLike : public CIuCompareLike_super
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCompareLike();
	CIuCompareLike(const CIuCompareLike& rCompareLike);
	virtual ~CIuCompareLike();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Compare(LPCTSTR pcsz) const;
	void Dump() const;
	void SetExpression(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuCompareLike& operator=(const CIuCompareLike& rCompareLike);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void Append(BYTE b);
	void CommonConstruct();
	int EvaluateTerm(const BYTE* pbValue, const BYTE* pbPattern) const;
	void ParsePattern();
	void Trim();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// RHS of "name LIKE pattern"
	// Cached here so that we don't have to re-parse it all the time.
	CString m_sPattern; 
	// Parsed version of pattern
	CIuBuffer m_buffer;
	// Were all terms negated?
	bool m_fNotAll;
//}}Data

};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_COMPARELIKE_H_
