#ifndef _ENGINE_COUNTS_H_
#define _ENGINE_COUNTS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCounts)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCounts, CIuObject }}
#define CIuCounts_super CIuObject
class IU_CLASS_EXPORT CIuCounts : public CIuCounts_super
{
//{{Declare
	DECLARE_SERIAL(CIuCounts)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCounts();
	virtual ~CIuCounts();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetExpression() const;
	int GetMatched() const;
	int GetRemaining() const;
	int GetTotal() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Empty();
	void SetExpression(LPCTSTR);
	void SetMatched(int iMatched);
	void SetRemaining(int iRemaining);
	void SetTotal(int iTotal);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	// This semaphore is used in derived classes to provide
	// mutual exclusion with respect to the pump
	mutable CMutex m_mutex;
private:
	int m_iTotal;
	int m_iMatched;
	int m_iRemaining;
	CString m_sExpression;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuCounts::GetExpression() const
{
	return m_sExpression;
}

inline int CIuCounts::GetMatched() const
{
	return m_iMatched;
}

inline int CIuCounts::GetRemaining() const
{
	return m_iRemaining;
}

inline int CIuCounts::GetTotal() const
{
	return m_iTotal;
}

#endif // _ENGINE_COUNTS_H_
