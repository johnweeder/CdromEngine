#include "StdAfx.h"
//{{Include
#include "RecordSpec.h"
#include "FieldMap.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuRecordSpec::CIuRecordSpec() 
{
	Clear();
}

CIuRecordSpec::~CIuRecordSpec()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRecordSpec::Add(const BYTE* pb, int cb)
{
	ASSERT(cb >= 0);
	if (cb == 0 || pb == 0)
	{
		AddBlank();
		return ;
	}
	// Field size does _not_ include null!
	ASSERT(pb[cb - 1] != '\0');
	ASSERT(m_iFields < recordMaxFields);
	m_apb[m_iFields] = pb;
	m_acb[m_iFields] = cb;
	++m_iFields;
}

BYTE* CIuRecordSpec::AddStore(const BYTE* pb, int cb)
{
	ASSERT(cb >= 0);
	// Field size does _not_ include null!
	if (cb == 0 || pb == 0)
	{
		AddBlank();
		return 0;
	}

	// Field size does _not_ include null!
	ASSERT(pb[cb - 1] != '\0');
	ASSERT(m_iFields < recordMaxFields);
	int iSize = m_Buffer.GetSize();
	m_Buffer.Append(pb, cb);
	pb = m_Buffer.GetPtr(iSize);
	m_apb[m_iFields] = pb;
	m_acb[m_iFields] = cb;
	++m_iFields;
	return const_cast<BYTE*>(pb);
}

void CIuRecordSpec::Clear()
{
	//{{Initialize
	m_Buffer.Empty();
	m_Buffer.SetGrowBy(4906);
	m_iFields = 0;
	m_iRecordFields = -1;
	m_wFlags = 0;
	m_wExtra = 0;
	m_dwRecordNo = recordRecordNoInvalid;
	m_dwSourceNo = recordSourceNoInvalid;
	m_dwLatitude = dwLatLongInvalid;
	m_dwLongitude = dwLatLongInvalid;
	m_dwExpandNo = recordExpandNoInvalid;
	m_dwExpandCount = 0;
	m_iKeyFields = -1;
	m_pbKey = 0;
	m_cbKey = 0;
	m_cbKeyExtra = 0;
	m_Key.Clear();
	//}}Initialize
}

void CIuRecordSpec::Map(const CIuRecord& Record, const CIuFieldMap& FieldMap)
{
	// Create the fields and keys
	FieldMap.Map(*this, Record);
	// Copy miscellaneous flags and dwords
	Set(Record);
}

void CIuRecordSpec::Set(const CStringArray& as)
{
	// Values are not "stored", only referenced!
	for (int i = 0; i < as.GetSize(); ++i)
		Add(as[i]);
}

void CIuRecordSpec::Set(const BYTE* pb, int cb)
{
	// Buffer of null terminated strings....
	// Values are not "stored", only referenced!
	ASSERT(pb && cb > 0);
	ASSERT(pb[cb - 1] == '\0');
	while (cb > 0)
	{
		const BYTE* pbStart = pb;
		for (; *pb != 0; ++pb, --cb)
			/* null */ ;
		ASSERT(*pb == 0);
		++pb;
		--cb;
		ASSERT(cb >= 0);
		Add(pbStart, int(pb - pbStart) - 1);
	}
}

void CIuRecordSpec::Set(const CIuRecord& Record)
{
	// This copies all the miscellaneous data except for the 
	// fields and the key.
	// Copy miscellaneous fields
	if (Record.HasRecordNo())
		SetRecordNo(Record.GetRecordNo());
	if (Record.HasSourceNo())
		SetSourceNo(Record.GetSourceNo());
	if (Record.HasLatLong())
	{
		DWORD dwLat, dwLong;
		Record.GetLatLong(dwLat, dwLong);
		SetLatLong(dwLat, dwLong);
	}
	if (Record.HasExpandNo())
	{
		DWORD dwExpandNo, dwExpandCount;
		Record.GetExpandNo(dwExpandNo, dwExpandCount);
		SetExpandNo(dwExpandNo, dwExpandCount);
	}
	else if (Record.HasExpandCount())
	{
		DWORD dwCount = Record.GetExpandCount();
		SetExpandCount(dwCount);
	}
	WORD wMask = WORD(recordAlternate|recordTagged|recordNoMail|recordNoPhone|recordResidence|recordBoughtMask);
	m_wFlags |= (Record.GetFlags() & wMask);
}

void CIuRecordSpec::SetAlt()
{
	m_wFlags |= recordAlternate;
}

void CIuRecordSpec::SetBoughtLevel(int iBoughtLevel)
{
	m_wFlags &= ~recordBoughtMask;
	m_wFlags |= (recordBoughtMask & WORD(iBoughtLevel));
}

void CIuRecordSpec::SetBus()
{
	m_wFlags &= ~recordResidence;
}

void CIuRecordSpec::SetExpandCount(DWORD dwExpandCount)
{
	m_wFlags |= recordExpandCount;
	m_dwExpandCount = dwExpandCount;
}

void CIuRecordSpec::SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount)
{
	m_wFlags |= recordExpandNo|recordExpandCount;
	m_dwExpandNo = dwExpandNo;
	m_dwExpandCount = dwExpandCount;
}

void CIuRecordSpec::SetExtra(WORD wExtra, int cbKey)
{
	m_wExtra |= wExtra;
	m_cbKeyExtra = cbKey;
}

void CIuRecordSpec::SetFieldSize(int iField, int iSize)
{
	ASSERT(iField >= 0 && iField < m_iFields);
	m_acb[iField] = iSize;
}

void CIuRecordSpec::SetFlags(WORD wFlags)
{
	m_wFlags |= wFlags;
}

void CIuRecordSpec::SetKey()
{
	// Uses the internal key object
	m_wFlags |= recordKey;
	m_iKeyFields = -1;
	m_pbKey = 0;
	m_cbKey = 0;
}

void CIuRecordSpec::SetKey(int iKeyFields)
{
	// Uses the "offset" form of the key
	m_wFlags |= recordKey;
	ASSERT(iKeyFields > 0);
	m_iKeyFields = iKeyFields;
	m_pbKey = 0;
	m_cbKey = 0;
}

void CIuRecordSpec::SetKey(const BYTE* pbKey, int cbKey)
{
	// Uses the ptr/size form of the key
	m_wFlags |= recordKey;
	m_iKeyFields = -1;
	ASSERT(pbKey && cbKey >= 0);
	m_pbKey = pbKey;
	m_cbKey = cbKey;
}

void CIuRecordSpec::SetLatLong(DWORD dwLatitude, DWORD dwLongitude)
{
	m_wFlags |= recordLatLong;
	m_dwLatitude = dwLatitude;
	m_dwLongitude = dwLongitude;
}

void CIuRecordSpec::SetNoMail()
{
	m_wFlags |= recordNoMail;
}

void CIuRecordSpec::SetNoPhone()
{
	m_wFlags |= recordNoPhone;
}

void CIuRecordSpec::SetRecordFields(int iRecordFields)
{
	ASSERT(iRecordFields >= 0 && iRecordFields <= m_iFields);
	m_iRecordFields = iRecordFields;
}

void CIuRecordSpec::SetRecordNo(DWORD dwRecordNo)
{
	m_wFlags |= recordRecordNo;
	m_dwRecordNo = dwRecordNo;			
}

void CIuRecordSpec::SetRes()
{
	m_wFlags |= recordResidence;
}

void CIuRecordSpec::SetSourceNo(DWORD dwSourceNo)
{
	m_wFlags |= recordSourceNo;
	m_dwSourceNo = dwSourceNo;
}

void CIuRecordSpec::SetTagged()
{
	m_wFlags |= recordTagged;
}
