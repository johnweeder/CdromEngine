#ifndef _ENGINE_ALT_H_
#define _ENGINE_ALT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_COMMON_BIGNYBBLEBUFFER_H_
#	include "Common\BigNybbleBuffer.h"
#endif	// _COMMON_BIGNYBBLEBUFFER_H_
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
#ifndef 	_COMMON_MISCELLANEOUS_H_
#	include "Common\Miscellaneous.h"
#endif	// _COMMON_MISCELLANEOUS_H_
#ifndef 	_COMMON_STRINGBUFFER_H_
#	include "Common\StringBuffer.h"
#endif	// _COMMON_STRINGBUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAlt)
class CIuAlts;
class CIuAltInstance;
class CIuAltRaw;
class CIuCdromSpec;
class CIuAltSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Alternate file types
enum CIuAltNo
{
	altNone = 0,

	altFirst,
	altLast,
	altCity,
	altPhone,
	altSic,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAlt, CIuCollectable }}
#define CIuAlt_super CIuCollectable

class CIuAlt : public CIuAlt_super
{
//{{Declare
	DECLARE_SERIAL(CIuAlt)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAlt();
	virtual ~CIuAlt();
	CIuAlt(const CIuAlt&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool Exists() const;
	void Get(int iAlt, CIuAltInstance& instance) const;
	int GetAltCount() const;
	CString GetDatabase() const;
	int GetExpandedKeySize() const;
	CString GetFilename() const;
	CString GetFullFilename() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuAlts& GetAlts() const;
	int GetAltSize() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasAlts() const;
	bool HasObjectRepository() const;
	bool IsNoStore() const;
	bool IsNumericKey() const;
	bool IsOpen() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close(bool fForce = false);
	virtual void Copy(const CIuObject& object);
	void Delete(CIuOutput* pOutput = 0);
	void Empty();
	int Find(LPCTSTR pcsz) const;
	void Open();
	void SetDatabase(LPCTSTR);
	void SetExpandedKeySize(int);
	void SetFilename(LPCTSTR);
	void SetNoStore(bool);
	void SetNumericKey(bool);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetAltCount(int);
	void SetAltSize(int);
	void SetSpec(CIuAltSpec& Alt);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuAlt& operator=(const CIuAlt&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	bool GetGridInfo(int iRq, CIuGridRq& rq);
private:
	bool BuildCompress(CIuOutput& Output);
	void CommonConstruct();
	void ExpandKeys();
	void SanityCheck(CIuOutput& Output, CIuAltRaw& raw);
	void Write(CIuNybbleBuffer& nb);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Non-persistent
	CIuBigNybbleBuffer m_Buffer;
	CIntArray m_Elements;
	CIntArray m_Frequency;
	CIuBigBuffer m_BufferKeys;
	CIntArray m_ElementKeys;
	mutable bool m_fKeysExpanded;
	int m_iOpen;
	// Data related to the persistent storage location
	// Persistent information
	int m_iAltCount;
	int m_iAltSize;
	CString m_sFilename;
	bool m_fNumericKey;
	bool m_fNoStore;
	int m_iExpandedKeySize;
	CIuObjectRepository* m_pObjectRepository;
	CString m_sDatabase;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAlt::GetAltCount() const
{
	return m_iAltCount;
}

inline CString CIuAlt::GetDatabase() const
{
	return m_sDatabase;
}

inline int CIuAlt::GetExpandedKeySize() const
{
	return m_iExpandedKeySize;
}

inline CIuObjectRepository& CIuAlt::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline int CIuAlt::GetAltSize() const
{
	return m_iAltSize;
}

inline bool CIuAlt::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuAlt::IsNoStore() const
{
	return m_fNoStore;
}

inline bool CIuAlt::IsNumericKey() const
{
	return m_fNumericKey;
}

inline bool CIuAlt::IsOpen() const
{
	return m_iOpen > 0;
}

#endif // _ENGINE_ALT_H_
