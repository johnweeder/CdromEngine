#include "StdAfx.h"
//{{Include
#include "BTreeData.h"
#include "BTreeIndex.h"
#include "BTreePointers.h"
#include "Data\PrefixFile.h"
#include "Data\PackRepository.h"
#include "BTree.h"
#include "resource.h"
#include "CdromSpecConst.h"
#include "Data\Output.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "Data\Pack.h"
#include "Cdrom.h"
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeData, CIuBTreeData_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeData)
const	CIuVersionNumber versionBTreeDataMax(2000,1,5,304);
const	CIuVersionNumber versionBTreeDataMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREEDATA, CIuBTreeData, CIuBTreeData_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTreeData, IDS_ENGINE_PPG_BTREEDATA, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeData, IDS_ENGINE_PROP_RECORDS, GetRecords, SetRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeData, IDS_ENGINE_PROP_RECORDS, IDS_ENGINE_PPG_BTREEDATA, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeData, IDS_ENGINE_PROP_BLOCKS, GetBlocks, SetBlocks, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeData, IDS_ENGINE_PROP_BLOCKS, IDS_ENGINE_PPG_BTREEDATA, 0, INT_MAX, editorReadOnly)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeData::CIuBTreeData() 
{
	//{{Initialize
	m_iRecords = 0;
	m_iBlocks = 0;
	m_iBlock = -1;
	m_fAppending = false;
	m_pObjectRepository = 0;
	m_fDebug = false;
	SetVersion(versionBTreeDataMax);
	//}}Initialize
}


CIuBTreeData::~CIuBTreeData()
{
	Close();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBTreeData::Append(const CIuNybbleBuffer& record, int iPointers)
{
	if (!m_block.Append(record, iPointers, &GetBTree().GetStats()))
	{
		WriteBlock();
		return false;
	}
	m_iBlockPointers += iPointers;
	++m_iBlockRecords;
	++m_iRecords;
	return true;
}

bool CIuBTreeData::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseFiles))
		GetObjectRepository().PackFile(GetBTree(), Cdrom.GetPack(), &Output, GetFilename());
	return Output.Fire();
}

void CIuBTreeData::Close()
{
	if (m_pFile.NotNull() && m_fAppending)
	{
		if (m_block.GetNybbles() > 0)
			WriteBlock();
		m_pFile->SetData(*this);
	}
	m_pVFile.Release();
	m_pFile.Release();
}

void CIuBTreeData::Create(CIuOutput&)
{
	Close();

	GetBTree().GetStats().m_iBytesPerBlocks = GetBlockSize();
	
	m_block.SetBlockSize(GetBlockSize());
	m_iRecords = 0;
	m_iBlocks = 0;
	m_iBlock = -1;
	m_fAppending = true;
	m_pFile.Create();
	ASSERT(m_pObjectRepository);
	CIuFilename filename = GetObjectRepository().GetFullFilename(GetBTree(), GetFilename());
	m_pFile->Create(filename, 16 * 1024, CIuFile::openCreate);
	m_pVFile = m_pFile->Use();
	m_block.Empty();
	m_block.SetHasCounters(GetBTree().HasMultiPointers());
	m_iBlockPointers = 0;
	m_iBlockRecords = 0;
}

void CIuBTreeData::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
}

void CIuBTreeData::FindPointer(int iPointer)
{
	if (!IsPointerInBlock(iPointer))
	{
		int iBlock = GetBTree().GetIndex().GetSeparatorNoByPointerNo(iPointer);
		ASSERT(iBlock >= 0);
		// Get block
		ReadBlock(iBlock);
		ASSERT(iPointer >= GetBlockStartPointerNo());
	}

	int iRecord = m_block.GetRecordNo();
	if (iPointer < GetPointerNo())
	{
		iRecord = 0;
		m_block.Goto(iRecord);
		ASSERT(iPointer >= GetPointerNo());
	}

	for (; iRecord < m_iBlockRecords; ++iRecord)
	{
		m_block.Goto(iRecord);
		int iThisPointerNo = GetPointerNo();
		if (iPointer >= iThisPointerNo && iPointer < iThisPointerNo + GetPointerCount())
			return ;
	}

	// The specified pointer should have been in this block!
	ASSERT(false);
}

int CIuBTreeData::GetBlockSize() const
{
	return GetBTree().GetBlockSize();
}

CString CIuBTreeData::GetFilename() const
{
	CString sName;
	sName += GetBTree().GetFilename();
	sName += _T(" Data");
	return sName;
}

CString CIuBTreeData::GetFullFilename() const
{
	CString sFilename = GetObjectRepository().GetFullFilename(GetBTree(), GetFilename());
	return sFilename;
}

CIuVersionNumber CIuBTreeData::GetVersionMax() const
{
	return versionBTreeDataMax;
}

CIuVersionNumber CIuBTreeData::GetVersionMaxStatic()
{
	return versionBTreeDataMax;
}

CIuVersionNumber CIuBTreeData::GetVersionMin() const
{
	return versionBTreeDataMin;
}

CIuVersionNumber CIuBTreeData::GetVersionMinStatic()
{
	return versionBTreeDataMin;
}

void CIuBTreeData::Goto(int iRecord)
{
	ASSERT(iRecord >= 0 && iRecord < GetRecords());
	ASSERT(IsOpen());

	// If no block or not current record in this block....
	if (m_iBlock < 0 || iRecord != m_iBlockStartRecord + m_block.GetRecordNo())
	{
		// Check if we either don't have a block in memory or if this record is not in this block
		if (m_iBlock < 0 || iRecord < m_iBlockStartRecord || iRecord >= m_iBlockStartRecord + m_iBlockRecords)
		{
			int iBlock = GetBTree().GetIndex().GetSeparatorNoByRecordNo(iRecord);
			ASSERT(iBlock >= 0 && iBlock < m_iBlocks);
			ReadBlock(iBlock);
		}
	}

	ASSERT(iRecord >= m_iBlockStartRecord);
	m_block.Goto(iRecord - m_iBlockStartRecord);
}

bool CIuBTreeData::IsOpen() const
{
	return m_pVFile.NotNull() && m_pVFile->IsOpen();
}

bool CIuBTreeData::IsPointerInBlock(int iPointer) const
{
	if (m_iBlock < 0)
		return false;
	if (iPointer < m_iBlockStartPointer || iPointer >= m_iBlockStartPointer + m_iBlockPointers)
		return false;
	return true;
}

void CIuBTreeData::Open(bool fDebug)
{
	Close();

	m_fDebug = fDebug;
	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	GetObjectRepository().Use(GetBTree(), m_pFile, m_pVFile, GetFilename(), 0, 0);
	m_block.SetBlockSize(GetBlockSize());
	m_block.SetDebug(fDebug);
	m_fAppending = false;
	m_iBlock = -1;
	m_block.SetHasCounters(GetBTree().HasMultiPointers());
	ASSERT(IsOpen());
	m_iBlockPointers = 0;
	m_iBlockRecords = 0;
}

void CIuBTreeData::ReadBlock(int iBlock)
{
	ASSERT(iBlock >= 0 && iBlock < m_iBlocks);
	if (iBlock == m_iBlock)
		return ;

	// NOTE: It is assumed that the separator for this block has been set.
	ASSERT(m_block.GetBlockSize() == GetBlockSize());
	m_pVFile->Seek(CIuFilePosition(iBlock)  * GetBlockSize());
	m_pVFile->Read(m_block.GetBlock(), GetBlockSize());
	m_block.Reset();
	m_iBlock = iBlock;
	GetBTree().GetIndex().GetSeparator(m_iBlock, m_separator);
	m_iBlockStartRecord = m_separator.GetRecordNo();
	m_iBlockStartPointer = m_separator.GetPointerNo();
	m_iBlockPointers = m_separator.GetPointerCount();
	m_iBlockRecords = m_separator.GetRecordCount();
	if (m_fDebug)
		m_block.Validate(m_separator.GetRecordCount(), m_separator.GetPointerCount());
}

bool CIuBTreeData::SanityCheck(CIuOutput& Output)
{
	// Output description, set range, etc
	Output.OutputF(_T("Validating BTree data in %s\n"), GetBTree().GetName());
	Output.OutputF(_T("\t%ld records in %d blocks of size %d\n"), GetRecords(), GetBlocks(), GetBlockSize());

	if (GetRecords() <= 0)
		Error(IU_E_BTREE_INVALID, _T("Record count is invalid."));

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	Output.SetMessageF(_T("Validating pointers\n"));
	Output.SetPosition(0);
	Output.SetRange(GetRecords());
	Output.Fire();

	int iPointers = 0;
	int iCount = GetRecords();
	for (int iRecord = 0; iRecord < iCount; ++iRecord)
	{
		if ((iRecord % ((iCount + 99) / 100)) == 0)
		{
			Output.SetPosition(iRecord);
			if (!Output.Fire())
				return false;
		}

		// Move to the specified record
		Goto(iRecord);

		if (GetRecordNo() != iRecord)
			Error(IU_E_BTREE_INVALID, _T("Record seek failed."));

		if (GetBTree().HasPointers() && GetPointerNo() != iPointers)
			Error(IU_E_BTREE_INVALID, _T("Pointer no is invalid."));

		iPointers += GetPointerCount();
	}

	if (GetBTree().HasPointers() && iPointers != GetBTree().GetPointers().GetPointers())
		Error(IU_E_BTREE_INVALID, _T("Pointer count does not match accumulated count."));

	// Display elapsed time
	instance.Pop(true);

	return true;
}

void CIuBTreeData::SetBlocks(int i)
{
	m_iBlocks = i;
}

void CIuBTreeData::SetBTree(CIuBTreePtr pBTree)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pBTree = pBTree;
}

void CIuBTreeData::SetMinimumRecordSize(int iMinimumRecordSize)
{
	m_block.SetMinimumRecordSize(iMinimumRecordSize);
}

void CIuBTreeData::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuBTreeData::SetRecords(int i)
{
	m_iRecords = i;
}

void CIuBTreeData::SetSpec(CIuBTreeSpec&)
{
}

void CIuBTreeData::SetVersion(CIuVersionNumber ver)
{
	m_verVersion = ver;
}

void CIuBTreeData::WriteBlock()
{
	ASSERT(m_block.GetBlockSize() == GetBlockSize());

	m_block.SanityCheck(m_iBlockRecords, m_iBlockPointers);

	m_pVFile->Seek(CIuFilePosition(m_iBlocks)  * GetBlockSize());
	m_pVFile->Write(m_block.GetBlock(), GetBlockSize());
	++m_iBlocks;
	GetBTree().GetStats().m_iBlocks++;
	m_block.Empty();
	m_iBlockPointers = 0;
	m_iBlockRecords = 0;
}
