#include "StdAfx.h"
//{{Include
#include "GeoAreaCode.h"
#include "GeoRawAreaCode.h"
#include "AreaCode.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "RegEx.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoAreaCode, CIuGeoAreaCode_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoAreaCode)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOAREACODE, CIuGeoAreaCode, CIuGeoAreaCode_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoAreaCode::CIuGeoAreaCode() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoAreaCode::~CIuGeoAreaCode()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoAreaCode::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoAreaCode"));
	//}}Initialize
}

LPCTSTR CIuGeoAreaCode::GetIndex() const
{
	return GetIndexStatic();
}

void CIuGeoAreaCode::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter = RegEx.CreateLikeClause(_T("AreaCode"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoAreaCode::GetIndexStatic() 
{
	return _T("AreaCode");
}

void CIuGeoAreaCode::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoAreaCode);
}

int CIuGeoAreaCode::GetSourceType() const
{
	return sourceGeoCollectionAreaCode;
}

void CIuGeoAreaCode::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoAreaCode::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawAreaCode& AreaCode = *dynamic_cast<CIuGeoRawAreaCode*>(&Element);
	ASSERT(&AreaCode);

	int iExpandedSize = sizeof(CIuAreaCode);
	ASSERT(iExpandedSize == 16);

	CString sName = AreaCode.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CString sTitle = AreaCode.GetTitle();
	CheckField(sTitle);
	CIuNybbleString::Append(sTitle, -1, NS_ALPHA, Buffer);
	iExpandedSize += sTitle.GetLength() + 1;

	AreaCode.GetState().CompressPreferred(Geo, Buffer, Geo.GetStateMap());

	iExpandedSize += CIuGeoList::Compress(AreaCode.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize;
}

int CIuGeoAreaCode::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuAreaCode* pAreaCode = (CIuAreaCode*)AddElement(sizeof(CIuAreaCode));

	// Decompress the various strings
	CIuStaticBuffer256 BufferAreaCode;
	iOffset += CIuNybbleString::Get(BufferAreaCode, -1, true, NS_ALPHA, Buffer, iOffset);
	pAreaCode->m_iAreaCode = StringAsInt(LPCTSTR(BufferAreaCode.GetPtr()));

	CIuStaticBuffer256 BufferAreaCodeName;
	iOffset += CIuNybbleString::Get(BufferAreaCodeName, -1, true, NS_ALPHA, Buffer, iOffset);

	// Fill out the constant data in the process. 
	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pAreaCode->m_iStateNo = uiVal - 1;

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferAreaCode.GetPtr()));
	AddElementString(LPCTSTR(BufferAreaCodeName.GetPtr()));
	AddElementStringTerm();

	return iOffset;
}

