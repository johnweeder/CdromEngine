#ifndef _ENGINE_EXPORTDEFSPECDFT_H_
#define _ENGINE_EXPORTDEFSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// User Interface Default
#pragma warning(disable: 4200)
struct CIuExportDefSpecDft
{
public:
	static int Find(LPCTSTR pcszExportDef);
	static int Find(int iExportDef);
	static const CIuExportDefSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The name and number
	LPCTSTR m_pcszExportDef;
	int m_iExportDef;
	// These static id for this def
	const CIuID* m_pid;
	// Miscellaneous information
	LPCTSTR m_pcszTitle;
	LPCTSTR m_pcszDescription;
	LPCTSTR m_pcszExtension;
	LPCTSTR m_pcszOptions;
	LPCTSTR m_pcszExporter;
	int m_iExportDefType;
	int m_iRecordLength;
	// This field is variable length and must be last...
	LPCTSTR m_apcszFields[];
};
#pragma warning(default: 4200)

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_EXPORTDEFSPECDFT_H_
