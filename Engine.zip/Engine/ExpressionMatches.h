#ifndef _ENGINE_EXPRESSIONMATCHES_H_
#define _ENGINE_EXPRESSIONMATCHES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
#ifndef 	_ENGINE_ALT_H_
#	include "Engine\Alt.h"
#endif	// _ENGINE_ALT_H_
#ifndef 	_ENGINE_ALTINSTANCE_H_
#	include "Engine\AltInstance.h"
#endif	// _ENGINE_ALTINSTANCE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionMatches, CIuExpressionElement }} 
#define CIuExpressionMatches_super CIuExpressionElement

class CIuExpressionMatches : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionMatches(CIuExpressionType Type);
	CIuExpressionMatches(const CIuExpressionMatches& rExpressionElement);
	virtual ~CIuExpressionMatches();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
	virtual void Resolve(CIuResolveSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionMatches& operator=(const CIuExpressionMatches& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
private:
	void CommonConstruct();
	void ResolveFile();
	void ResolvePattern() const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	mutable bool m_fPatternConst;
	mutable CString m_sPattern;
	mutable bool m_fPatternExists;
	mutable CIuAltInstance m_Instance;
	CIuAltPtr m_pAlt;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONMATCHES_H_
