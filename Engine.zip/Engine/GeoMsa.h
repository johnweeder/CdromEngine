#ifndef _ENGINE_GEOMSA_H_
#define _ENGINE_GEOMSA_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENTCOLLECTION_H_
#	include "Engine\GeoElementCollection.h"
#endif	// _ENGINE_GEOELEMENTCOLLECTION_H_
#ifndef 	_ENGINE_MSA_H_
#	include "Engine\Msa.h"
#endif	// _ENGINE_MSA_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoMsa)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoMsa, CIuGeoElementCollection }}
#define CIuGeoMsa_super CIuGeoElementCollection

class CIuGeoMsa : public CIuGeoMsa_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoMsa)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoMsa();
	virtual ~CIuGeoMsa();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	const CIuMsa& Get(int iElement) const;
	void GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const;
	LPCTSTR GetIndex() const;
	static LPCTSTR GetIndexStatic();
	virtual void GetRecordDef(CIuRecordDef&) const;
	virtual int GetSourceType() const;
	virtual void GetZipList(int iElement, CIuGeoList& GeoList) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void FindScan(CIuGeoList& GeoList, const CIuRegExCompare& RegExCompare) const;
	virtual int OnCompressElement(CIuNybbleBuffer&, CIuGeoRaw&, CIuGeoRawElement&, CIuGeoRawElementCollection&, CIuOutput&);
	virtual int OnDeCompressElement(CIuNybbleBuffer&, int);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline const CIuMsa& CIuGeoMsa::Get(int iElement) const
{
	ASSERT(IsOpen());
	ASSERT(iElement >= 0 && iElement < m_aiOffsets.GetSize());
	int iOffset = m_aiOffsets[iElement];
	return *reinterpret_cast<const CIuMsa*>(m_Buffer.GetPtr(iOffset));
}

#endif // _ENGINE_GEOMSA_H_
