#include "StdAfx.h"
//{{Include
#include "BTreeIndex.h"
#include "BTreePointers.h"
#include "BTreeData.h"
#include "BTree.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "Data\PackRepository.h"
#include "resource.h"
#include "Error\Error.h"
#include "Cdrom.h"
#include "CdromSpecConst.h"
#include "Miscellaneous.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeIndex, CIuBTreeIndex_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeIndex)
const	CIuVersionNumber versionBTreeIndexMax(2000,1,5,304);
const	CIuVersionNumber versionBTreeIndexMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREEINDEX, CIuBTreeIndex, CIuBTreeIndex_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTreeIndex, IDS_ENGINE_PPG_BTREEINDEX, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_BLOCKS, GetBlocks, SetBlocks, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_BLOCKS, IDS_ENGINE_PPG_BTREEINDEX, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_SEPARATORS, GetSeparators, SetSeparators, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_SEPARATORS, IDS_ENGINE_PPG_BTREEINDEX, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_RECORDS, GetRecords, SetRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_RECORDS, IDS_ENGINE_PPG_BTREEINDEX, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_POINTERS, GetPointers, SetPointers, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_POINTERS, IDS_ENGINE_PPG_BTREEINDEX, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_TOPBLOCKSIZE, GetTopBlockSize, SetTopBlockSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_TOPBLOCKSIZE, IDS_ENGINE_PPG_BTREEINDEX, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeIndex, IDS_ENGINE_PROP_SEPARATORSIZE, GetSeparatorSize, SetSeparatorSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeIndex, IDS_ENGINE_PROP_SEPARATORSIZE, IDS_ENGINE_PPG_BTREEINDEX, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeIndex::CIuBTreeIndex() 
{
	//{{Initialize
	m_pObjectRepository = 0;
	m_iBlock = 0;
	m_iBlocks = 0;
	m_fAppending = false;
	m_iSeparators = 0;
	m_iRecords = 0;
	m_iPointers = 0;
	m_iTopBlockSize = 1;
	m_iSeparatorSize = 1;
	m_pObjectRepository = 0;
	SetVersion(versionBTreeIndexMax);
	//}}Initialize
}

CIuBTreeIndex::~CIuBTreeIndex()
{
	Close();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeIndex::Append(const CIuKey& key, const CIuKey& keyPrevious, int iRecordNo, int iRecordCount, int iPointerNo, int iPointerCount)
{
	CIuBTreeIndexSeparator separator;
	separator.CreateSeparator(key, keyPrevious);
	separator.SetPointerNo(iPointerNo);
	separator.SetPointerCount(iPointerCount);
	separator.SetRecordNo(iRecordNo);
	separator.SetRecordCount(iRecordCount);

	if (!m_block.WillFit(separator))
		WriteBlock();

	ASSERT(m_block.WillFit(separator));

	m_block.Append(separator);

	m_iRecords += iRecordCount;
	m_iPointers += iPointerCount;
	++m_iSeparators;
}

bool CIuBTreeIndex::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseFiles))
		GetObjectRepository().PackFile(GetBTree(), Cdrom.GetPack(), &Output, GetFilename());
	return Output.Fire();
}

void CIuBTreeIndex::Close()
{
	if (m_fAppending)
	{
		WriteTop();
		m_pFile->SetData(*this);
	}
	m_pVFile.Release();
	m_pFile.Release();
	m_iBlock = -1;
	m_fAppending = false;
}

void CIuBTreeIndex::Create(CIuOutput&)
{
	Close();

	m_iBlocks = 0;
	m_iSeparators = 0;
	m_iPointers = 0;
	m_iRecords = 0;
	m_pFile.Create();
	ASSERT(m_pObjectRepository);
	CIuFilename filename = m_pObjectRepository->GetFullFilename(GetBTree(), GetFilename());
	m_pFile->Create(filename, 16 * 1024, CIuFile::openCreate);
	m_pVFile = m_pFile->Use();
	m_block.SetBlockSize(GetBlockSize());
	m_block.SetSeparatorNo(m_iSeparators);
	SetTopBlockSize(1);
	m_blockTop.SetBlockSize(GetBlockSize() * GetTopBlockSize());
	m_block.SetSeparatorNo(m_iSeparators);

	m_fAppending = true;
}

void CIuBTreeIndex::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
}

int CIuBTreeIndex::GetBlockSize() const
{
	return GetBTree().GetBlockSize();
}

CString CIuBTreeIndex::GetFilename() const
{
	CString sName;
	sName += GetBTree().GetFilename();
	sName += _T(" Index");
	return sName;
}

CString CIuBTreeIndex::GetFullFilename() const
{
	CString sFilename = m_pObjectRepository->GetFullFilename(GetBTree(), GetFilename());
	return sFilename;
}

void CIuBTreeIndex::GetSeparator(int iSeparator, CIuBTreeIndexSeparator& separator) const
{
	ASSERT(IsOpen());
	ASSERT(m_iBlocks > 0);
	ASSERT(iSeparator >= 0 && iSeparator < GetSeparators());

	// Easy when there is only one block. Each Separator is represented in this block.
	if (m_iBlocks == 1)
	{
		m_blockTop.Get(iSeparator, separator);
		return ;
	}

	// It gets a bit harder for a two level index.
	// We have to locate the block which our separator is located in
	const CIuInt32* pSeparator = reinterpret_cast<const CIuInt32*>(m_blockSeparators.GetPtr());
	ASSERT(pSeparator);
	int iBlocks = GetBlocks();
	for (int iBlock = 0; iBlock < iBlocks; ++iBlock)
	{
		if (iSeparator >= pSeparator[iBlock] && iSeparator < pSeparator[iBlock + 1])
			break;
	}

	ASSERT(iBlock < iBlocks);
	const_cast<CIuBTreeIndex*>(this)->ReadBlock(iBlock);
	ASSERT(m_block.GetSeparatorNo() == pSeparator[iBlock]);
	m_block.Get(iSeparator - pSeparator[iBlock], separator);
}

int CIuBTreeIndex::GetSeparatorNoByKey(const CIuKey& key, CIuBTreeIndexSeparator* pSeparator) const
{
	ASSERT(IsOpen());
	ASSERT(m_iBlocks > 0);

	int iSeparator0 = m_blockTop.FindSeparator(key);
	if (m_iBlocks == 1)
	{
		if (pSeparator)
			m_blockTop.Get(iSeparator0, *pSeparator);
		return iSeparator0;
	}

	const_cast<CIuBTreeIndex*>(this)->ReadBlock(iSeparator0);
	int iSeparator1 = m_block.FindSeparator(key);
	ASSERT(iSeparator1 >= 0);
	if (pSeparator)
		m_block.Get(iSeparator1, *pSeparator);
	return m_block.GetSeparatorNo() + iSeparator1;
}

int CIuBTreeIndex::GetSeparatorNoByPointerNo(int iPointer, CIuBTreeIndexSeparator* pSeparator) const
{
	ASSERT(IsOpen());
	ASSERT(m_iBlocks > 0);
	ASSERT(iPointer >= 0 && iPointer < GetPointers());

	int iSeparator0 = m_blockTop.FindPointerNo(iPointer);
	if (m_iBlocks == 1)
	{
		if (pSeparator)
			m_blockTop.Get(iSeparator0, *pSeparator);
		return iSeparator0;
	}

	const_cast<CIuBTreeIndex*>(this)->ReadBlock(iSeparator0);
	int iSeparator1 = m_block.FindPointerNo(iPointer);
	ASSERT(iSeparator1 >= 0);
	if (pSeparator)
		m_block.Get(iSeparator1, *pSeparator);
	return m_block.GetSeparatorNo() + iSeparator1;
}

int CIuBTreeIndex::GetSeparatorNoByRecordNo(int iRecord, CIuBTreeIndexSeparator* pSeparator) const
{
	ASSERT(IsOpen());
	ASSERT(m_iBlocks > 0);
	ASSERT(iRecord >= 0 && iRecord < GetRecords());

	int iSeparator0 = m_blockTop.FindRecordNo(iRecord);
	if (m_iBlocks == 1)
	{
		if (pSeparator)
			m_blockTop.Get(iSeparator0, *pSeparator);
		return iSeparator0;
	}

	const_cast<CIuBTreeIndex*>(this)->ReadBlock(iSeparator0);
	int iSeparator1 = m_block.FindRecordNo(iRecord);
	ASSERT(iSeparator1 >= 0);
	if (pSeparator)
		m_block.Get(iSeparator1, *pSeparator);
	return m_block.GetSeparatorNo() + iSeparator1;
}

CIuVersionNumber CIuBTreeIndex::GetVersionMax() const
{
	return versionBTreeIndexMax;
}

CIuVersionNumber CIuBTreeIndex::GetVersionMaxStatic()
{
	return versionBTreeIndexMax;
}

CIuVersionNumber CIuBTreeIndex::GetVersionMin() const
{
	return versionBTreeIndexMin;
}

CIuVersionNumber CIuBTreeIndex::GetVersionMinStatic()
{
	return versionBTreeIndexMin;
}

bool CIuBTreeIndex::IsOpen() const
{
	return m_pVFile.NotNull() && m_pVFile->IsOpen();
}

void CIuBTreeIndex::Open(bool /* fDebug */)
{
	Close();

	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	m_pObjectRepository->Use(GetBTree(), m_pFile, m_pVFile, GetFilename(), 0, 0);

	m_iBlock = -1;
	m_fAppending = false;
	m_block.SetBlockSize(GetBlockSize());
	if (m_iBlocks == 1)
	{
		// If only one block, just read it. No separators or anything
		m_pVFile->Seek(0);
		m_blockTop.SetBlockSize(GetBlockSize());
		m_pVFile->Read(m_blockTop.GetData(), m_blockTop.GetBlockSize());
	}
	else
	{
		// Otherwise, we have 1) Data Blocks, 2) Separators, 3) Master Block
		m_pVFile->Seek(CIuFilePosition(m_iBlocks) * GetBlockSize());
		const	CIuVersionNumber versionFixedTopBlock(1999,0,8,600);
		if (GetVersion() > versionFixedTopBlock)
		{
			// This code supported top level blocks which are sized in multiples
			// of the basic block size. This supports large databases like USA1
			// The separators can also span multiple blocks.
			ASSERT(GetSeparatorSize() >= 1);
			ASSERT(int((GetBlockSize() * GetSeparatorSize()) / sizeof(CIuInt32)) >= GetBlocks());
			m_blockSeparators.SetSize(GetBlockSize() * GetSeparatorSize());
			ASSERT(GetTopBlockSize() >= 1);
			m_blockTop.SetBlockSize(GetBlockSize() * GetTopBlockSize());
		}
		else
		{
			m_blockSeparators.SetSize(GetBlockSize());
			m_blockTop.SetBlockSize(GetBlockSize());
		}
		m_pVFile->Read(m_blockSeparators.GetPtr(), m_blockSeparators.GetSize());
		m_pVFile->Read(m_blockTop.GetData(), m_blockTop.GetBlockSize());
	}
}

void CIuBTreeIndex::ReadBlock(int iBlock)
{
	ASSERT(iBlock >= 0 && iBlock < m_iBlocks);
	if (iBlock == m_iBlock)
		return ;

	m_pVFile->Seek(CIuFilePosition(iBlock) * GetBlockSize());
	m_pVFile->Read(m_block.GetData(), GetBlockSize());
	m_iBlock = iBlock;
}

bool CIuBTreeIndex::SanityCheck(CIuOutput& Output)
{
	// Output description, set range, etc
	Output.OutputF(_T("Validating BTree index in %s\n"), GetBTree().GetName());
	Output.OutputF(_T("\t%ld separators in %d blocks of size %d\n"), GetSeparators(), GetBlocks(), GetBlockSize());

	if (GetPointers() != 0 && GetPointers() != GetBTree().GetPointers().GetPointers())
		Error(IU_E_BTREE_INVALID, _T("Pointer count does not match pointer file size."));
	if (GetRecords() != 0 && GetRecords() != GetBTree().GetData().GetRecords())
		Error(IU_E_BTREE_INVALID, _T("Record count does not match data file size."));

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	Output.SetMessageF(_T("Validating pointers\n"));
	Output.SetPosition(0);
	Output.SetRange(GetSeparators());
	Output.Fire();

	int iCount = GetSeparators();
	int iPointers = 0;
	int iRecords = 0;

	CIuBTreeIndexSeparator separator;
	for (int iSeparator = 0; iSeparator < iCount; ++iSeparator)
	{
		if ((iSeparator % ((iCount + 99) / 100)) == 0)
		{
			Output.SetPosition(iSeparator);
			if (!Output.Fire())
				return false;
		}
		// Expand... just to expand it
		GetSeparator(iSeparator, separator);

		if (separator.GetPointerNo() != iPointers)
			Error(IU_E_BTREE_INVALID, _T("Pointer offset is not consistent."));
		if (separator.GetRecordNo() != iRecords)
			Error(IU_E_BTREE_INVALID, _T("Record offset is not consistent."));

		iPointers += separator.GetPointerCount();
		iRecords += separator.GetRecordCount();
	}

	if (GetPointers() != 0 && GetPointers() != iPointers)
		Error(IU_E_BTREE_INVALID, _T("Pointer count does not match accumulated count."));
	if (GetRecords() != 0 && GetRecords() != iRecords)
		Error(IU_E_BTREE_INVALID, _T("Record count does not match accumulated count."));

	// Display elapsed time
	instance.Pop(true);

	return true;
}

void CIuBTreeIndex::SetBlocks(int iBlocks)
{
	m_iBlocks = iBlocks;
}

void CIuBTreeIndex::SetBTree(CIuBTreePtr pBTree)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pBTree = pBTree;
}

void CIuBTreeIndex::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuBTreeIndex::SetPointers(int iPointers)
{
	m_iPointers = iPointers;
}

void CIuBTreeIndex::SetRecords(int iRecords)
{
	m_iRecords = iRecords;
}

void CIuBTreeIndex::SetSeparators(int iSeparators)
{
	m_iSeparators = iSeparators;
}

void CIuBTreeIndex::SetSeparatorSize(int iSeparatorSize)
{
	m_iSeparatorSize = iSeparatorSize;
}

void CIuBTreeIndex::SetSpec(CIuBTreeSpec&)
{
}

void CIuBTreeIndex::SetTopBlockSize(int iTopBlockSize)
{
	m_iTopBlockSize = iTopBlockSize;
}

void CIuBTreeIndex::SetVersion(CIuVersionNumber ver)
{
	m_verVersion = ver;
}

void CIuBTreeIndex::WriteBlock()
{
	ASSERT(!m_block.IsEmpty());
	m_pVFile->Seek(CIuFilePosition(m_iBlocks)  * GetBlockSize());
	m_pVFile->Write(m_block.GetData(), GetBlockSize());
	++m_iBlocks;
	m_block.Clear();
	m_block.SetSeparatorNo(m_iSeparators);
}

void CIuBTreeIndex::WriteTop()
{
	ASSERT(m_fAppending);

	// Empty the current block
	if (!m_block.IsEmpty())
		WriteBlock();

	// If only one block, no top level block / separators
	if (m_iBlocks <= 1)
	{
		if (m_pFile.NotNull())
			m_pFile->SetData(*this);
		return ;
	}

	// Computer number of separator blocks needed
	int iTotalSeparators = GetBlocks() + 1;
	int iSeparatorsPerBlock = GetBlockSize() / sizeof(CIuInt32);
	int iSeparatorBlocks = (iTotalSeparators + iSeparatorsPerBlock - 1) / iSeparatorsPerBlock;
	SetSeparatorSize(iSeparatorBlocks);

	int iSeparator = 0;
	m_blockSeparators.SetSize(GetBlockSize() * GetSeparatorSize());
	CIuInt32* pSeparator = reinterpret_cast<CIuInt32*>(m_blockSeparators.GetPtr());
	ASSERT(pSeparator);

	// Start with a default size for top block
	SetTopBlockSize(1);

	// Start with a default sized block.
	m_blockTop.SetBlockSize(GetBlockSize() * GetTopBlockSize());
	m_blockTop.Clear();

	// Now, try and build the top level block
	CIuBTreeIndexSeparator key;

	for (int iBlock = 0; iBlock < GetBlocks(); ++iBlock)
	{
		pSeparator[iBlock] = iSeparator;
		ReadBlock(iBlock);
		ASSERT(m_block.GetSeparatorNo() == pSeparator[iBlock]);

		ASSERT(m_block.GetSeparatorCount() > 0);

		m_block.Get(0, key);

		// These two are al
		key.SetPointerCount(m_block.GetPointerCount());
		key.SetRecordCount(m_block.GetRecordCount());

		if (!m_blockTop.WillFit(key))
		{
			SetTopBlockSize(GetTopBlockSize() + 1);
			m_blockTop.GrowBlockSize(GetBlockSize() * GetTopBlockSize());
			if (!m_blockTop.WillFit(key))
				Error(IU_E_INDEX_BLOCK_SIZE_TOO_SMALL);
		}

		m_blockTop.Append(key);

		iSeparator += m_block.GetSeparatorCount();
	}

	pSeparator[iBlock] = iSeparator;

	m_pVFile->Seek(CIuFilePosition(m_iBlocks) * GetBlockSize());
	m_pVFile->Write(m_blockSeparators.GetPtr(), m_blockSeparators.GetSize());
	m_pVFile->Write(m_blockTop.GetData(), m_blockTop.GetBlockSize());

	if (m_pFile.NotNull())
		m_pFile->SetData(*this);
}
