#ifndef _ENGINE_IDS_H_
#define _ENGINE_IDS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

/////////////////////////////////////////////////////////////////////////////
//	
// This header contains various global ID's which are used. 
// Usually, an id is the global way to identify an object.
//	
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//	Meter ID's
//	
// NOTE: Meters 1&2 in this sequence were discarded during development when
//			record count logic changed.
const CIuID idMeter_Pf_2000									= CIuID(0xF6E074F0);
const CIuID idMeter_Bml_2000									= CIuID(0xF6E074F1);
const CIuID idMeter_Pu_2000									= CIuID(0xF6E074F2);
const CIuID idMeter_Slu_2000									= CIuID(0xF6E074F3);
const CIuID idMeter_Sample										= CIuID(0xF6E074F5);
const CIuID idMeter_Ac_V1										= CIuID(0xF6E074F6);
const CIuID idMeter_Pbm_V1										= CIuID(0xF6E074F7);
const CIuID idMeter_Ci_V1										= CIuID(0xF6E074F8);
const CIuID idMeter_Ypu_2001									= CIuID(0xF6E074F9);
const CIuID idMeter_Rp_2001									= CIuID(0xF6E074FA);
const CIuID idMeter_Oam_V1										= CIuID(0xF6E074FC);
const CIuID idMeter_RbocGreatLakes_2000					= CIuID(0xF6E00003);
const CIuID idMeter_RbocNeAtlantic1_2000					= CIuID(0xF6E00005);
const CIuID idMeter_RbocNeAtlantic2_2000					= CIuID(0xF6E00006);
const CIuID idMeter_RbocPacific_2000						= CIuID(0xF6E00007);
const CIuID idMeter_RbocSouthWest_2000						= CIuID(0xF6E00008);
const CIuID idMeter_RbocMidWest_2000						= CIuID(0xF6E00009);
const CIuID idMeter_RbocTest_2000							= CIuID(0xF6E0000A);
const CIuID idMeter_RbocSeAtlantic1_2000					= CIuID(0xF6E0000B);
const CIuID idMeter_RbocSeAtlantic2_2000					= CIuID(0xF6E0000C);
const CIuID idMeter_Pg_2000									= CIuID(0xF6E0000D);
const CIuID idMeter_Pb_2001									= CIuID(0xF6E0000E);
const CIuID idMeter_Pf_2001									= CIuID(0xF6E0000F);
const CIuID idMeter_Pu_2001									= CIuID(0xF6E00010);
const CIuID idMeter_88md_2001									= CIuID(0xF6E00011);
const CIuID idMeter_104m_2001									= CIuID(0xF6E00012);

/////////////////////////////////////////////////////////////////////////////
//	Database ID's

// Miscellaneous
const CIuID idMeterAdmin										= CIuID(0xF6E674F1);
const CIuID idNetAdmin											= CIuID(0xF6E674F2);
const CIuID idSample												= CIuID(0xF6E674F4);
const CIuID idReleaseNotes										= CIuID(0xF6E674F5);
const CIuID idPowerCheck										= CIuID(0xF6E674F6);
const CIuID idConsole											= CIuID(0xF6E674F7);

//	PowerFinder (Commercial)
const CIuID idPf_Test_2001										= CIuID(0xF6E10001);
const CIuID idPf_Western_2000R1								= CIuID(0xF6E174F2);
const CIuID idPf_NorthEast_2000R1							= CIuID(0xF6E174F3);
const CIuID idPf_Central_2000R1								= CIuID(0xF6E174F4);
const CIuID idPf_MidAtlantic_2000R1							= CIuID(0xF6E174F5);
const CIuID idPf_SouthEast_2000R1							= CIuID(0xF6E174F6);
const CIuID idPf_MidWest_2000R1								= CIuID(0xF6E174F7);

const CIuID idPf_Western_2000R2								= CIuID(0xF6E10021);
const CIuID idPf_NorthEast_2000R2							= CIuID(0xF6E10022);
const CIuID idPf_Central_2000R2								= CIuID(0xF6E10023);
const CIuID idPf_MidAtlantic_2000R2							= CIuID(0xF6E10024);
const CIuID idPf_SouthEast_2000R2							= CIuID(0xF6E10025);
const CIuID idPf_MidWest_2000R2								= CIuID(0xF6E10026);

const CIuID idPf_East_2001R1									= CIuID(0xF6F30011);
const CIuID idPf_MidAtlantic_2001R1							= CIuID(0xF6F30012);
const CIuID idPf_MidWest_2001R1								= CIuID(0xF6F30013);
const CIuID idPf_Mountain_2001R1								= CIuID(0xF6F30014);
const CIuID idPf_NorthCentral_2001R1						= CIuID(0xF6F30015);
const CIuID idPf_Pacific_2001R1								= CIuID(0xF6F30016);
const CIuID idPf_Southern_2001R1								= CIuID(0xF6F30017);

//	PowerFinder (Business)
const CIuID idPb_Test_2001										= CIuID(0xF6F20011);
const CIuID idPb_Usa_2001R1									= CIuID(0xF6F20012);

//	PowerFinder (USA1)
const CIuID idPu_Test_2001										= CIuID(0xF6F10001);
const CIuID idPu_2000R1											= CIuID(0xF6E174F8);
const CIuID idPu_2000R2											= CIuID(0xF6E10027);
const CIuID idPu_Usa_2001R1									= CIuID(0xF6F10012);

//	Business Mailing Lists
const CIuID idBml_Test1_2000									= CIuID(0xF6E20001);
const CIuID idBml_Test2_2000									= CIuID(0xF6E20002);
const CIuID idBml_Usa1_2000R1									= CIuID(0xF6E274F3);
const CIuID idBml_Usa2_2000R1									= CIuID(0xF6E274F4);
const CIuID idBml_Usa1_2000R2									= CIuID(0xF6E20021);
const CIuID idBml_Usa2_2000R2									= CIuID(0xF6E20022);
				 
//	SalesLeads USA
const CIuID idSlu_Test_2000									= CIuID(0xF6E30001);
const CIuID idSlu_Usa_2000R1									= CIuID(0xF6E374F2);
const CIuID idSlu_Usa_2000R2									= CIuID(0xF6E30022);

//	PowerFinder Government
const CIuID idPg_Test_2000										= CIuID(0xF6E40001);

const CIuID idPg_Western_2000R1								= CIuID(0xF6E40011);
const CIuID idPg_NorthEast_2000R1							= CIuID(0xF6E40012);
const CIuID idPg_Central_2000R1								= CIuID(0xF6E40013);
const CIuID idPg_MidAtlantic_2000R1							= CIuID(0xF6E40014);
const CIuID idPg_SouthEast_2000R1							= CIuID(0xF6E40015);
const CIuID idPg_MidWest_2000R1								= CIuID(0xF6E40016);
const CIuID idPg_Usa_2000R1									= CIuID(0xF6E40017);

const CIuID idPg_Western_2000R2								= CIuID(0xF6F40011);
const CIuID idPg_NorthEast_2000R2							= CIuID(0xF6F40012);
const CIuID idPg_Central_2000R2								= CIuID(0xF6F40013);
const CIuID idPg_MidAtlantic_2000R2							= CIuID(0xF6F40014);
const CIuID idPg_SouthEast_2000R2							= CIuID(0xF6F40015);
const CIuID idPg_MidWest_2000R2								= CIuID(0xF6F40016);
const CIuID idPg_Usa_2000R2									= CIuID(0xF6F40017);

//	YellowPagesUSA
const CIuID idYpu_Test_2001									= CIuID(0xF6EA0001);
const CIuID idYpu_Usa_2001R1									= CIuID(0xF6EA0002);

// Resume Plus
const CIuID idRp_Test_2001										= CIuID(0xF6EB0001);
const CIuID idRp_Usa_2001R1									= CIuID(0xF6EB0002);

// 88 Million Households Deluxe
const CIuID id88md_Test_2001									= CIuID(0xF6F50001);

const CIuID id88md_Western_2001R1							= CIuID(0xF6F50012);
const CIuID id88md_NorthEast_2001R1							= CIuID(0xF6F50013);
const CIuID id88md_Central_2001R1							= CIuID(0xF6F50014);
const CIuID id88md_SouthEast_2001R1							= CIuID(0xF6F50015);
const CIuID id88md_MidWest_2001R1							= CIuID(0xF6F50016);
const CIuID id88md_Usa_2001R1									= CIuID(0xF6F50017);

// 104 Million Businesses & Households 
const CIuID id104m_Test_2001									= CIuID(0xF6F60001);

const CIuID id104m_Western_2001R1							= CIuID(0xF6F60011);
const CIuID id104m_NorthEast_2001R1							= CIuID(0xF6F60012);
const CIuID id104m_SouthEast_2001R1							= CIuID(0xF6F60013);
const CIuID id104m_GreatLakes_2001R1						= CIuID(0xF6F60014);
const CIuID id104m_Central_2001R1							= CIuID(0xF6F60015);

const CIuID id104m_Usa_2001R1									= CIuID(0xF6F60016);

// OAM
const CIuID idOam_Test_V1   									= CIuID(0xF6ED0001);
const CIuID idOam_Usa_V1										= CIuID(0xF6ED1001);

// RBOC 
const CIuID idRboc_Test_2000									= CIuID(0xF6E50001);

const CIuID idRboc_GreatLakes_2000R2						= CIuID(0xF6E50021);
const CIuID idRboc_MidWest_2000R2							= CIuID(0xF6E50022);
const CIuID idRboc_NeAtlantic1_2000R2						= CIuID(0xF6E50023);
const CIuID idRboc_NeAtlantic2_2000R2						= CIuID(0xF6E50024);
const CIuID idRboc_Pacific_2000R2							= CIuID(0xF6E50025);
const CIuID idRboc_SouthWest_2000R2							= CIuID(0xF6E50027);
const CIuID idRboc_SeAtlantic1_2000R2						= CIuID(0xF6E50028);
const CIuID idRboc_SeAtlantic2_2000R2						= CIuID(0xF6E50029);

const CIuID idRboc_GreatLakes_2000R3						= CIuID(0xF6E50031);
const CIuID idRboc_MidWest_2000R3							= CIuID(0xF6E50032);
const CIuID idRboc_NeAtlantic1_2000R3						= CIuID(0xF6E50033);
const CIuID idRboc_NeAtlantic2_2000R3						= CIuID(0xF6E50034);
const CIuID idRboc_Pacific_2000R3							= CIuID(0xF6E50035);
const CIuID idRboc_SouthWest_2000R3							= CIuID(0xF6E50037);
const CIuID idRboc_SeAtlantic1_2000R3						= CIuID(0xF6E50038);
const CIuID idRboc_SeAtlantic2_2000R3						= CIuID(0xF6E50039);

const CIuID idRboc_GreatLakes_2000R4						= CIuID(0xF6E50041);
const CIuID idRboc_MidWest_2000R4							= CIuID(0xF6E50042);
const CIuID idRboc_NeAtlantic1_2000R4						= CIuID(0xF6E50043);
const CIuID idRboc_NeAtlantic2_2000R4						= CIuID(0xF6E50044);
const CIuID idRboc_Pacific_2000R4							= CIuID(0xF6E50045);
const CIuID idRboc_SouthWest_2000R4							= CIuID(0xF6E50047);
const CIuID idRboc_SeAtlantic1_2000R4						= CIuID(0xF6E50048);
const CIuID idRboc_SeAtlantic2_2000R4						= CIuID(0xF6E50049);

const CIuID idRboc_GreatLakes_2000R5						= CIuID(0xF6E50051);
const CIuID idRboc_MidWest_2000R5							= CIuID(0xF6E50052);
const CIuID idRboc_NeAtlantic1_2000R5						= CIuID(0xF6E50053);
const CIuID idRboc_NeAtlantic2_2000R5						= CIuID(0xF6E50054);
const CIuID idRboc_Pacific_2000R5							= CIuID(0xF6E50055);
const CIuID idRboc_SouthWest_2000R5							= CIuID(0xF6E50057);
const CIuID idRboc_SeAtlantic1_2000R5						= CIuID(0xF6E50058);
const CIuID idRboc_SeAtlantic2_2000R5						= CIuID(0xF6E50059);

const CIuID idRboc_GreatLakes_2000R6						= CIuID(0xF6E50061);
const CIuID idRboc_MidWest_2000R6							= CIuID(0xF6E50062);
const CIuID idRboc_NeAtlantic1_2000R6						= CIuID(0xF6E50063);
const CIuID idRboc_NeAtlantic2_2000R6						= CIuID(0xF6E50064);
const CIuID idRboc_Pacific_2000R6							= CIuID(0xF6E50065);
const CIuID idRboc_SouthWest_2000R6							= CIuID(0xF6E50067);
const CIuID idRboc_SeAtlantic1_2000R6						= CIuID(0xF6E50068);
const CIuID idRboc_SeAtlantic2_2000R6						= CIuID(0xF6E50069);

const CIuID idRboc_GreatLakes_2000R7						= CIuID(0xF6E50071);
const CIuID idRboc_MidWest_2000R7							= CIuID(0xF6E50072);
const CIuID idRboc_NeAtlantic1_2000R7						= CIuID(0xF6E50073);
const CIuID idRboc_NeAtlantic2_2000R7						= CIuID(0xF6E50074);
const CIuID idRboc_Pacific_2000R7							= CIuID(0xF6E50075);
const CIuID idRboc_SouthWest_2000R7							= CIuID(0xF6E50077);
const CIuID idRboc_SeAtlantic1_2000R7						= CIuID(0xF6E50078);
const CIuID idRboc_SeAtlantic2_2000R7						= CIuID(0xF6E50079);

const CIuID idRboc_GreatLakes_2000R8						= CIuID(0xF6E50081);
const CIuID idRboc_MidWest_2000R8							= CIuID(0xF6E50082);
const CIuID idRboc_NeAtlantic1_2000R8						= CIuID(0xF6E50083);
const CIuID idRboc_NeAtlantic2_2000R8						= CIuID(0xF6E50084);
const CIuID idRboc_Pacific_2000R8							= CIuID(0xF6E50085);
const CIuID idRboc_SouthWest_2000R8							= CIuID(0xF6E50087);
const CIuID idRboc_SeAtlantic1_2000R8						= CIuID(0xF6E50088);
const CIuID idRboc_SeAtlantic2_2000R8						= CIuID(0xF6E50089);

const CIuID idRboc_GreatLakes_2000R9						= CIuID(0xF6E50091);
const CIuID idRboc_MidWest_2000R9							= CIuID(0xF6E50092);
const CIuID idRboc_NeAtlantic1_2000R9						= CIuID(0xF6E50093);
const CIuID idRboc_NeAtlantic2_2000R9						= CIuID(0xF6E50094);
const CIuID idRboc_Pacific_2000R9							= CIuID(0xF6E50095);
const CIuID idRboc_SouthWest_2000R9							= CIuID(0xF6E50096);
const CIuID idRboc_SeAtlantic1_2000R9						= CIuID(0xF6E50097);
const CIuID idRboc_SeAtlantic2_2000R9						= CIuID(0xF6E50098);

// Personalized Business Mailings
const CIuID idPbm_Test_V1										= CIuID(0xF6E70001);
const CIuID idPbm_Usa_V1										= CIuID(0xF6E70002);

// Address Corrector
const CIuID idAc_Test_V1										= CIuID(0xF6E80001);
const CIuID idAc_Western_V1									= CIuID(0xF6E80011);
const CIuID idAc_NorthEast_V1									= CIuID(0xF6E80012);
const CIuID idAc_Central_V1									= CIuID(0xF6E80013);
const CIuID idAc_MidAtlantic_V1								= CIuID(0xF6E80014);
const CIuID idAc_SouthEast_V1									= CIuID(0xF6E80015);
const CIuID idAc_MidWest_V1									= CIuID(0xF6E80016);
const CIuID idAc_Usa_V1											= CIuID(0xF6E80017);
const CIuID idAc_Ui_V1											= CIuID(0xF6E80018);

// Caller ID
const CIuID idCi_Test_V1											= CIuID(0xF6E90001);
const CIuID idCi_Ui_V1											= CIuID(0xF6E90011);
const CIuID idCi_Usa_V1											= CIuID(0xF6E90012);
const CIuID idCi_West_V1										= CIuID(0xF6E90013);
const CIuID idCi_MidWest_V1									= CIuID(0xF6E90014);
const CIuID idCi_East_V1										= CIuID(0xF6E90015);

/////////////////////////////////////////////////////////////////////////////
// Blobs
const CIuID idBlob_BmLicense_2000							= CIuID(0xF6FD0001);
const CIuID idBlob_PfLicense_2000							= CIuID(0xF6FD0002);
const CIuID idBlob_PgLicense_2000							= CIuID(0xF6FD0003);
const CIuID idBlob_RbocLicense_2000							= CIuID(0xF6FD0004);
const CIuID idBlob_SampleLicense								= CIuID(0xF6FD0005);
const CIuID idBlob_SluLicense_2000							= CIuID(0xF6FD0006);
const CIuID idBlob_PbmLicense_V1								= CIuID(0xF6FD0007);
const CIuID idBlob_YpuLicense_2001							= CIuID(0xF6FD0008);
const CIuID idBlob_88mdLicense_2001							= CIuID(0xF6FD0009);
const CIuID idBlob_OamLicense_V1								= CIuID(0xF6FD000A);
const CIuID idBlob_PuLicense_2000							= CIuID(0xF6FD000B);
const CIuID idBlob_PbLicense_2001							= CIuID(0xF6FD000C);
const CIuID idBlob_PfLicense_2001							= CIuID(0xF6FD000D);
const CIuID idBlob_PuLicense_2001							= CIuID(0xF6FD000E);
const CIuID idBlob_104mLicense_2001							= CIuID(0xF6FD000F);

/////////////////////////////////////////////////////////////////////////////
// Report defs
const CIuID idReportDefXXX										= CIuID(0xF6FE0001);

/////////////////////////////////////////////////////////////////////////////
// Export defs
const CIuID idExportDefSingleLine							= CIuID(0xF6FF0001);
const CIuID idExportDefAct										= CIuID(0xF6FF0002);
const CIuID idExportDefWordproMailMerge					= CIuID(0xF6FF0003);
const CIuID idExportDefAutomapStreets						= CIuID(0xF6FF0004);
const CIuID idExportDefDbaseIiIii							= CIuID(0xF6FF0005);
const CIuID idExportDefDesktopManager						= CIuID(0xF6FF0006);
const CIuID idExportDefGoldmine								= CIuID(0xF6FF0007);
const CIuID idExportDefLotusOrganizer21					= CIuID(0xF6FF0008);
const CIuID idExportDefMaximizer								= CIuID(0xF6FF0009);
const CIuID idExportDefMaplinx								= CIuID(0xF6FF000A);
const CIuID idExportDefMicrosoftWordMailMerge			= CIuID(0xF6FF000B);
const CIuID idExportDefMicrosoftOutlook					= CIuID(0xF6FF000C);
const CIuID idExportDefMymaillist							= CIuID(0xF6FF000D);
const CIuID idExportDefWordPerfectMailMerge				= CIuID(0xF6FF000E);
const CIuID idExportDefExcel									= CIuID(0xF6FF000F);
const CIuID idExportDefLotus123								= CIuID(0xF6FF0010);
const CIuID idExportDefWinfaxPro70							= CIuID(0xF6FF0011);
const CIuID idExportDefMailingLabel							= CIuID(0xF6FF0012);
const CIuID idExportDefMailingLabelWPhone					= CIuID(0xF6FF0013);
const CIuID idExportDefTabDelimited							= CIuID(0xF6FF0014);
const CIuID idExportDefCommaDelimitedWHeaders			= CIuID(0xF6FF0015);
const CIuID idExportDefCommaDelimited						= CIuID(0xF6FF0016);
const CIuID idExportDefCommaDelWLatLongDist				= CIuID(0xF6FF0017);
const CIuID idExportDefStreets2000Interoperability		= CIuID(0xF6FF0018);
const CIuID idExportDefPowerStreets							= CIuID(0xF6FF0019);
const CIuID idExportDefBusinessMapping						= CIuID(0xF6FF001A);
const CIuID idExportDefPalmPilot1							= CIuID(0xF6FF001B);
const CIuID idExportDefELetter								= CIuID(0xF6FF001C);

/////////////////////////////////////////////////////////////////////////////
// Other
const CIuID idExporterCsv										= CIuID(0xF6000001);
const CIuID idExporterTab										= CIuID(0xF6000002);
const CIuID idExporterFix										= CIuID(0xF6000003);
const CIuID idExporterDbf										= CIuID(0xF6000004);
const CIuID idExporterTxt										= CIuID(0xF6000005);

const CIuID idAltCity											= CIuID(0xF6FC0001);
const CIuID idAltFirst											= CIuID(0xF6FC0002);
const CIuID idAltLast											= CIuID(0xF6FC0003);
const CIuID idAltPhone											= CIuID(0xF6FC0004);
const CIuID idAltSic												= CIuID(0xF6FC0005);

#endif // _ENGINE_IDS_H_
