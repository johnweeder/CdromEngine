#include "StdAfx.h"
//{{Include
#include "CdromStripSpec.h"
#include "CdromStripSpecDft.h"
#include "CdromSpec.h"
#include "TokenSpec.h"
#include "Token.h"
#include "Strip.h"
#include "RecordDef.h"
#include "RecordSort.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromStripSpec, CIuCdromStripSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromStripSpec)
//}}Implement

CIuCdromStripSpec::CIuCdromStripSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromStripSpec::~CIuCdromStripSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCdromStripSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iStripNo = stripNone;
	m_iSortNo = sortNone;
	m_sFilename = "";
	m_pCdrom = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuCdromStripSpec::FromIndex(CIuCdromSpec* pCdrom, int iCdromStripSpec)
{
	ASSERT(iCdromStripSpec >= 0);

	const CIuCdromStripSpecDft* pCdromStripSpec = CIuCdromStripSpecDft::Get(iCdromStripSpec);
	ASSERT(pCdromStripSpec);

	FromSpec(pCdrom, pCdromStripSpec);
}

void CIuCdromStripSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszIndex)
{
	FromIndex(pCdrom, CIuCdromStripSpecDft::Find(pcszIndex));
}

void CIuCdromStripSpec::FromNo(CIuCdromSpec* pCdrom, int iIndexNo)
{
	FromIndex(pCdrom, CIuCdromStripSpecDft::Find(iIndexNo));
}

void CIuCdromStripSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuCdromStripSpecDft* pCdromStripSpec)
{
	SetCdrom(pCdrom);

	SetName(pCdromStripSpec->m_pcszStrip);
	SetID(CIuID::Create());

	SetStripNo(pCdromStripSpec->m_iStripNo);
	SetSortNo(pCdromStripSpec->m_iSortNo);

	ASSERT(AfxIsValidString(pCdromStripSpec->m_pcszFilename));
	CString sFilename = GetCdrom().GetFilename();
	sFilename += _T(" ");
	sFilename += pCdromStripSpec->m_pcszFilename;
	SetFilename(sFilename);
}

int CIuCdromStripSpec::GetCount()
{
	return CIuCdromStripSpecDft::GetCount();
}

void CIuCdromStripSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuCdromStripSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCdromStripSpec::SetSortNo(int iSortNo)
{
	m_iSortNo = iSortNo;
}

void CIuCdromStripSpec::SetStripNo(int iStripNo)
{
	m_iStripNo = iStripNo;
}
