#ifndef _ENGINE_EXPRESSION_H_
#define _ENGINE_EXPRESSION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_OPTIONS_H_
#	include "Common\Options.h"
#endif	// _COMMON_OPTIONS_H_
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
#ifndef 	_ENGINE_RESOLVESPEC_H_
#	include "Engine\ResolveSpec.h"
#endif	// _ENGINE_RESOLVESPEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExpression)
class CIuExpressionElement;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpression, CIuObject }}
#define CIuExpression_super CIuObject

class CIuExpression : public CIuExpression_super
{
//{{Declare
	DECLARE_SERIAL(CIuExpression)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpression();
	virtual ~CIuExpression();
	CIuExpression(const CIuExpression&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBoughtLevel() const;
	int GetCaseConvert() const;
	int GetMaxLength() const;
	const CIuRecordDef* GetRecordDef() const;
	bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	virtual void Copy(const CIuObject& object);
	void Dump(int iLevel = 0) const;
	LPCTSTR Evaluate(const CIuRecord* = 0) const;
	int EvaluateInt(const CIuRecord* = 0) const;
	bool EvaluateBool(const CIuRecord* = 0) const;
	void Parse(LPCTSTR pcsz);
	void Resolve(CIuResolveSpec& Spec);
	void SetCaseConvert(int iCaseConvert);
//}}Operations


/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpression& operator=(const CIuExpression&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuExpressionElement* m_pElement;
	int m_iMaxLength;
	// The recorddef which was used to resolve this object.
	// Maintained as a pointer. Usually only used to compare against.
	const CIuRecordDef* m_pRecordDef;
	int m_iCaseConvert;
#ifdef _DEBUG
	// Keep the expression around as a handy means to identify this thing in 
	//	the debugger.
	CString m_sExpression;
#endif
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuExpression::GetCaseConvert() const
{
	return m_iCaseConvert;
}

inline const CIuRecordDef* CIuExpression::GetRecordDef() const
{
	return m_pRecordDef;	
}

#endif // _ENGINE_EXPRESSION_H_
