#include "StdAfx.h"
//{{Include
#include "GeoRawState.h"
#include "GeoRawInstance.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawState, CIuGeoRawState_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawState)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWSTATE, CIuGeoRawState, CIuGeoRawState_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawState, IDS_ENGINE_PROP_ZIPS, GetZips_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawState, IDS_ENGINE_PROP_ZIPS, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawState::CIuGeoRawState() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoRawState::~CIuGeoRawState()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawState::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput&)
{
	// Just store the abbr, don't bother with code/name. We'll add it later.
	GetZips().Add(Instance.GetZip());
	CIuGeoRawState_super::Another();
}

CIuObject* CIuGeoRawState::GetZips_() const
{
	return &m_Zips;
}

void CIuGeoRawState::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
	GetZips().Serialize(ar);
	CIuGeoRawState_super::Serialize(ar);
}
