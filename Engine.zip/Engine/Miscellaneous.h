#ifndef _ENGINE_MISCELLANEOUS_H_
#define _ENGINE_MISCELLANEOUS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// A couple helper functions for converting to/from 64-bit src/rec no's
inline UINT64 MAKE_SRCRECNO(UINT32 uiSrcNo, UINT32 uiRecNo)
{
	return ((UINT64)((((UINT64)(uiSrcNo)) << 32)|((UINT64)(uiRecNo))));
}

inline UINT32 GET_SRCNO(UINT64 uiSrcRecNo)
{
	return ((UINT32)((uiSrcRecNo) >> 32));
}

inline UINT32 GET_RECNO(UINT64 uiSrcRecNo)
{
	return ((UINT32)(uiSrcRecNo));
}

IU_API_EXPORT bool CdromDelete(LPCTSTR pcszFilename, CIuOutput* pOutput = 0);

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_MISCELLANEOUS_H_
