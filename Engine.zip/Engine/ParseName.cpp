#include "StdAfx.h"
//{{Include
#include "ParseName.h"
#include "Common\String.h"  // RemoveLTMISpaces()
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

#pragma __TODO("Recognize common compound names like Mary Lou")	

// Strings should be all upper case.
// Trailing period do _not_ have to match.
// Second part of string is what is output.
static LPCTSTR apcszTitles[] = 
{
	"MRS.\0Mrs",
	"MR.\0Mr",
	"MS.\0Ms",
	"DR.\0Dr",
	"REV.\0Rev",
	0
};

static LPCTSTR apcszGen[] = 
{
	"JR.\0Jr",
	"SR.\0Sr",
	"III\0III",
	"II\0II",
	"IV\0IV",
	"V\0V",  
	"2ND\02nd",  
	"3RD\03rd",  
	0
};

// prefix free; should be ordered by frequency.
static LPCTSTR apcszProSuffix[] = 
{
	"MD\0MD",
	"CPA\0CPA",
	"PHD\0PhD",
	"DDS\0DDS",
	"DO\0DO",
	"DVM\0DVM",
	"DC\0DC",
	"PE\0PE",
	"OD\0OD",
	"DPM\0DPM",
	"CA\0CA",
	"QC\0QC",
	0
};

static int FindFirstSubstring(LPCTSTR pcszSearch, LPCTSTR apcszWords[], LPCTSTR& pcszNext)
{
	// Check if the next word in the input string matches a word in the words array.
	// Words are delimited by spaces.
	// The list of words must be null terminated.

	for (int iWord = 0; apcszWords[iWord]; ++iWord)
	{
		bool fMatch = true;
		LPCTSTR pcszWord = apcszWords[iWord];
		for (int iChar = 0;; ++iChar)
		{
			if (pcszSearch[iChar] == '\0' || _istspace(pcszSearch[iChar]))
			{
				// If at end of string or at trailing period, then this was a match
				if (pcszWord[iChar] == '\0' || (pcszWord[iChar] == '.' && pcszWord[iChar + 1] == '\0'))
					break;
				fMatch = false;
				break;
			}
			if (int(_totupper(pcszSearch[iChar])) != int(pcszWord[iChar]))
			{
				fMatch = false;
				break;
				
			}
		}
		if (fMatch)
		{
			pcszNext = _tcsskipws(pcszSearch + iChar);
			return iWord;
		}
	}
	pcszNext = pcszSearch;
	return -1;
}

static void AdjustNameParts(CString* psFirst, CString& sMiddle, CString& sPart, LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	// If the part is empty, just move in the new string
	if (sPart.IsEmpty())
	{
		sPart = pcsz;
		return ;
	}
	// Otherwise, move the existing value of the part to the middle name
	if (sMiddle.IsEmpty())
	{
		sMiddle = sPart;
		sPart = pcsz;
		return ;
	}
	// Otherwise, append the middle to the first and then do the rest...
	if (psFirst)
	{
		if (!psFirst->IsEmpty())
			*psFirst += ' ';
		*psFirst += sMiddle;
	}
	sMiddle = sPart;
	sPart = pcsz;
}

IU_API_EXPORT ExtractNamePart(CString& sPart, int iPart, LPCTSTR pcszName, int iFormat)
{
	switch (sPart.GetAt(0))
	{
		case 'L': case 'l': // Last Name
			ParseName(pcszName, iFormat, &sPart, 0, 0, 0, 0, 0);
			break;
		case 'F': case 'f': // First Name
			ParseName(pcszName, iFormat, 0, &sPart, 0, 0, 0, 0);
			break;
		case 'M': case 'm': // Middle name
			ParseName(pcszName, iFormat, 0, 0, &sPart, 0, 0, 0);
			break;
		case 'G': case 'g': // Generational
			ParseName(pcszName, iFormat, 0, 0, 0, &sPart, 0, 0);
			break;
		case 'S': case 's': // Professional Suffix
		case 'P': case 'p': 
			ParseName(pcszName, iFormat, 0, 0, 0, 0, &sPart, 0);
			break;
		case 'T': case 't': // title
			ParseName(pcszName, iFormat, 0, 0, 0, 0, 0, &sPart);
			break;
		default:
			TRACE("WARNING: Unrecognized name part %c (%d)\n", iPart, iPart);
			sPart = pcszName;
			break;
	}
}

IU_API_EXPORT void FlipName(CString& sName, LPCTSTR pcsz, int /* iFormat */)
{
	// Given a name of the form "Last, First" return "First Last". 
	// Otherwise, returns the input string
	ASSERT(AfxIsValidString(pcsz));
	LPCTSTR pcszComma = _tcschr(pcsz, ',');
	if (pcszComma == 0)
		sName = pcsz;
	else
	{
		sName = _tcsskipws(pcszComma + 1);
		if (!sName.IsEmpty())
			sName += ' ';
		Concat(sName, pcsz, pcszComma - pcsz);
		sName.TrimRight();
	}
}

IU_API_EXPORT void FirstName(CString& sFirst, LPCTSTR pcsz, int /* iFormat */)
{
	// Given a name of the form "Last, First" return "First". 
	// Otherwise, returns the input string
	ASSERT(AfxIsValidString(pcsz));
	LPCTSTR pcszComma = _tcschr(pcsz, ',');
	if (pcszComma == 0)
		sFirst = pcsz;
	else
		sFirst = _tcsskipws(pcszComma + 1);
}

IU_API_EXPORT void LastName(CString& sLast, LPCTSTR pcsz, int /* iFormat */)
{
	// Given a name of the form "Last, First" return "Last". 
	// Otherwise, returns the input string
	ASSERT(AfxIsValidString(pcsz));
	LPCTSTR pcszComma = _tcschr(pcsz, ',');
	if (pcszComma == 0)
		sLast = pcsz;
	else
	{
		Assign(sLast, pcsz, pcszComma - pcsz);
		sLast.TrimRight();
	}
}

IU_API_EXPORT CString& MakeName(CString& sName, int iFormat, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMiddle, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle, int iFlags)
{
	if (iFormat == makeNameFirstLast)
	{
		sName = "";
		if (!_tcsisempty(pcszTitle))
		{
			sName += _T(" ");
			sName += pcszTitle;
		}
		if (!_tcsisempty(pcszFirst))
		{
			sName += _T(" ");
			if ((iFlags & makeNameInitialsOnly) != 0)
				sName += *pcszFirst;
			else
				sName += pcszFirst;
		}
		if (!_tcsisempty(pcszMiddle))
		{
			sName += _T(" ");
			if ((iFlags & makeNameInitialsOnly) != 0)
				sName += *pcszMiddle;
			else
				sName += pcszMiddle;
		}
		if (!_tcsisempty(pcszLast))
		{
			sName += _T(" ");
			sName += pcszLast;
		}
		if (!_tcsisempty(pcszGen))
		{
			sName += _T(" ");
			sName += pcszGen;
		}
		if (!_tcsisempty(pcszProSuffix))
		{
			sName += _T(" ");
			sName += pcszProSuffix;
		}
		sName = pcszLast;
		sName += ",";
	}
	else
	{
		ASSERT(iFormat == makeNameLastFirst);
		ASSERT(AfxIsValidString(pcszLast));

		sName = pcszLast;
		bool fTitle = !_tcsisempty(pcszTitle);
		bool fFirst = !_tcsisempty(pcszFirst);
		bool fMiddle = !_tcsisempty(pcszMiddle);
		bool fGen = !_tcsisempty(pcszGen);
		bool fProsuffix = !_tcsisempty(pcszProSuffix);
		if (!sName.IsEmpty() && (fTitle || fFirst || fMiddle || fGen || fProsuffix))
			sName += ",";
		if (fTitle)
		{
			sName += _T(" ");
			sName += pcszTitle;
		}
		if (fFirst)
		{
			sName += _T(" ");
			if ((iFlags & makeNameInitialsOnly) != 0)
				sName += *pcszFirst;
			else
				sName += pcszFirst;
		}
		if (fMiddle)
		{
			sName += _T(" ");
			if ((iFlags & makeNameInitialsOnly) != 0)
				sName += *pcszMiddle;
			else
				sName += pcszMiddle;
		}
		if (fGen)
		{
			sName += _T(" ");
			sName += pcszGen;
		}
		if (fProsuffix)
		{
			sName += _T(" ");
			sName += pcszProSuffix;
		}
	}
	return sName;
}

IU_API_EXPORT void ParseName(LPCTSTR pcszName, int iFormat, CString* psLast, CString* psFirst, CString* psMiddle, CString* psGen, CString* psProSuffix, CString* psTitle)
{
	ASSERT(AfxIsValidString(pcszName));
	// NOTE: This needs to be a relatively high performance function since it tends to get called a lot.
	if (iFormat == makeNameFirstLast)
	{
		ASSERT(false);
#pragma __TODO("Implement name parsing for names in First-Last format")
	}
	else
	{
		ASSERT(iFormat == makeNameLastFirst);

		// These fields aren't used much. Blank them here at the top
		if (psMiddle)
			*psMiddle = "";
		if (psGen)
			*psGen = "";
		if (psProSuffix)
			*psProSuffix = "";
		if (psTitle)
			*psTitle = "";

		// The name will be in the following form:
		// last, [title] [first [middle]] [gen]|[pro]
		LPCTSTR pcszComma = _tcschr(pcszName, ',');
		if (pcszComma == 0)
		{
			// If no comma, assume name is deformed and put entire thing in last name
			if (psLast)
				*psLast = pcszName;
			if (psFirst)
				*psFirst = "";
			return ;
		}

		// Otherwise, suck off last name.
		if (psLast)
		{
			Assign(*psLast, pcszName, pcszComma - pcszName);
			psLast->TrimRight();
		}

		// Move to first name
		LPCTSTR pcszFirst = _tcsskipws(pcszComma + 1);

		// See if a leading title is found
		int iTitle = FindFirstSubstring(pcszFirst, apcszTitles, pcszFirst);
		if (iTitle >= 0)
		{
			if (psTitle)
				*psTitle = _tcschr(apcszTitles[iTitle], '\0') + 1;
		}

		LPCTSTR pcszFirstEnd = pcszFirst;
		while (*pcszFirstEnd && !_istspace(*pcszFirstEnd))
			pcszFirstEnd++;

		if (psFirst)
			Assign(*psFirst, pcszFirst, pcszFirstEnd - pcszFirst);

		LPCTSTR pcszMiddle = _tcsskipws(pcszFirstEnd);

		// Special cases for early out without try to figure out the title/suffix/etc
		// Look for MI followed by end of string or period
		if (*pcszMiddle == '\0' || (_istalpha(pcszMiddle[0]) && pcszMiddle[1] == '\0'))
		{
			if (psMiddle)
				*psMiddle = pcszMiddle;
			return ;
		}
		if (_istalpha(pcszMiddle[0]) && pcszMiddle[1] == '.'  && pcszMiddle[2] == '\0')
		{
			// Keep the period. It is significant for middle names.
			if (psMiddle)
				Assign(*psMiddle, pcszMiddle, 2);
			return ;
		}

		// OK, this is the worst case. Pick off the rest of the string word by word
		// And try to recognize gen/pro suffix/title.
		// If extra words are found, then they are either part of the middle name or the first name
		LPCTSTR pcszWord = pcszMiddle;

		// Start by emptying any of the strings.
		CString sMiddle, sGen, sTitle, sProSuffix;
		if (psMiddle == 0)
			psMiddle  = &sMiddle;
		if (psGen == 0)
			psGen = &sGen;
		if (psProSuffix == 0)
			psProSuffix = &sProSuffix;
		if (psTitle == 0)
			psTitle = &sTitle;

		while (*pcszWord)
		{
			LPCTSTR pcszNext;
			int iTitle = FindFirstSubstring(pcszWord, apcszTitles, pcszNext);
			if (iTitle >= 0)
			{
				AdjustNameParts(psFirst, *psMiddle, *psTitle, _tcschr(apcszTitles[iTitle], '\0') + 1);
				pcszWord = pcszNext;
				continue;
			}
			int iGen = FindFirstSubstring(pcszWord, apcszGen, pcszNext);
			if (iGen >= 0)
			{
				AdjustNameParts(psFirst, *psMiddle, *psGen, _tcschr(apcszGen[iGen], '\0') + 1);
				pcszWord = pcszNext;
				continue;
			}
			int iProSuffix = FindFirstSubstring(pcszWord, apcszProSuffix, pcszNext);
			if (iProSuffix >= 0)
			{
				AdjustNameParts(psFirst, *psMiddle, *psProSuffix, _tcschr(apcszProSuffix[iProSuffix], '\0') + 1);
				pcszWord = pcszNext;
				continue;
			}

			LPCTSTR pcszWordEnd = pcszWord;
			while (*pcszWordEnd && !_istspace(*pcszWordEnd))
				++pcszWordEnd;

			if (!psMiddle->IsEmpty())
			{
				if (!psFirst->IsEmpty())
					*psFirst += ' ';
				*psFirst += *psMiddle;
			}

			Assign(*psMiddle, pcszWord, pcszWordEnd - pcszWord);

			pcszWord = _tcsskipws(pcszWordEnd);
		}
	}
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(ParseName, pv) 
{
	// To run this test, execute "test ParseName" in the console.
	UNUSED_ALWAYS(pv);

	struct ParseNameTest
	{
		LPCTSTR pcszName;
		LPCTSTR pcszLast;
		LPCTSTR pcszTitle;
		LPCTSTR pcszFirst;
		LPCTSTR pcszMiddle;
		LPCTSTR pcszGen;
		LPCTSTR pcszProSuffix;
		LPCTSTR pcszFirstName;
		LPCTSTR pcszLastName;
		LPCTSTR pcszFlipName;
	};

	static ParseNameTest Names[] = 
	{
		// Name									Last			Title		First			Middle		Gen		Pro		FirstName					LastName			FlipName
		{ "Last, First Middle",				"Last",		"",		"First",		"Middle",	"",		"",		"First Middle",			"Last",			"First Middle Last" },
		{ "Jones, John J. PhD",				"Jones",		"",		"John",		"J.",			"",		"PhD",	"John J. PhD",				"Jones",			"John J. PhD Jones" },
		{ "Smith, John II OD",				"Smith",		"",		"John",		"",			"II",		"OD",		"John II OD",				"Smith",			"John II OD Smith" },
		{ "Smith, John II OD T DR",		"Smith",		"DR",		"John",		"T",			"II",		"OD",		"John II OD T DR",		"Smith",			"John II OD T DR Smith" },
		{ "Smith, John II OD T DR.",		"Smith",		"DR",		"John",		"T",			"II",		"OD",		"John II OD T DR.",		"Smith",			"John II OD T DR. Smith" },
		{ "Smith, John Boy II OD T DR.",	"Smith",		"DR",		"John Boy",	"T",			"II",		"OD",		"John Boy II OD T DR.",	"Smith",			"John Boy II OD T DR. Smith" },
		// Terminator for End of Data
		{ 0 }
	};

	for (int iName = 0; Names[iName].pcszName; ++iName)
	{
		CString sLast, sFirst, sMiddle, sGen, sProSuffix, sTitle;
		ParseName(Names[iName].pcszName, makeNameLastFirst, &sLast, &sFirst, &sMiddle, &sGen, &sProSuffix, &sTitle);
		ASSERT(sLast.CompareNoCase(Names[iName].pcszLast) == 0);
		ASSERT(sTitle.CompareNoCase(Names[iName].pcszTitle) == 0);
		ASSERT(sFirst.CompareNoCase(Names[iName].pcszFirst) == 0);
		ASSERT(sMiddle.CompareNoCase(Names[iName].pcszMiddle) == 0);
		ASSERT(sGen.CompareNoCase(Names[iName].pcszGen) == 0);
		ASSERT(sProSuffix.CompareNoCase(Names[iName].pcszProSuffix) == 0);

		CString sFirstName;
		FirstName(sFirstName, Names[iName].pcszName);
		ASSERT(sFirstName.CompareNoCase(Names[iName].pcszFirstName) == 0);

		CString sLastName;
		LastName(sLastName, Names[iName].pcszName);
		ASSERT(sLastName.CompareNoCase(Names[iName].pcszLastName) == 0);

		CString sFlipName;
		FlipName(sFlipName, Names[iName].pcszName);
		ASSERT(sFlipName.CompareNoCase(Names[iName].pcszFlipName) == 0);
	}
	return 0;
}
IU_TEST_END()
#endif

