#ifndef _ENGINE_GEORAWELEMENTCOLLECTION_H_
#define _ENGINE_GEORAWELEMENTCOLLECTION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_MAPSI_H_
#	include "Common\MapSI.h"
#endif	// _COMMON_MAPSI_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawElementCollection)
class CIuGeoRawInstance;
class CIuGeoRawElement;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawElementCollection, CIuObject }}
#define CIuGeoRawElementCollection_super CIuObject

class CIuGeoRawElementCollection : public CIuGeoRawElementCollection_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawElementCollection)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawElementCollection();
	virtual ~CIuGeoRawElementCollection();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoRawElement* Get(int iWhich) const;
	int GetCount() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	CIuGeoRawElement* Append(int iValue, int iPad, const CIuGeoRawInstance& instance, CIuOutput& Output);
	CIuGeoRawElement* Append(LPCTSTR pcszName, const CIuGeoRawInstance& instance, CIuOutput& Output);
	virtual void Clear();
	void Empty();
	CIuGeoRawElement* Find(LPCTSTR pcszName, bool fAdd = false);
	void InitHashTable(int iHashTableSize);
	void SetElementType(CRuntimeClass* prt);
	void SortByCount();
	void SortByName();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	bool GetGridInfo(int iRq, CIuGridRq& rq);
private:
	void CommonConstruct();
	void Sort();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Run-time class of element collection element type
	CRuntimeClass* m_prt;
	// Mapping of names to collection elements
	CIuMapStringToInt32 m_Map;
	// Array of collection elements
	// Only valid for after collection is sorted...
	CArray<CIuGeoRawElement*, CIuGeoRawElement*> m_Array;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_GEORAWELEMENTCOLLECTION_H_
