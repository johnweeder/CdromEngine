#include "StdAfx.h"
//{{Include
#include "Bought.h"
#include "Meter.h"
#include "Meters.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBought, CIuBought_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBought)
//}}Implement

CIuBought::CIuBought() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBought::~CIuBought()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBought::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_mapBought.InitHashTable(1031);
	m_iCount = 0;
	m_dwLastSrcNo = DWORD(-1);
	SetVersion(IU_VERSION);
	//}}Initialize
}

bool CIuBought::Decrement(DWORD dwSrcNo, int iBuy)
{
	// A useful function... but not used...
	CIuMeterPtr pMeter = GetMeter(dwSrcNo);
	if (pMeter.IsNull())
		return false;
	return pMeter->Decrement(iBuy);
}

int CIuBought::GetCount() const
{
	return m_iCount;
}

int CIuBought::GetLevel(const UINT64& id2) const
{
	return GetLevel(GET_SRCNO(id2), GET_RECNO(id2));
}

int CIuBought::GetLevel(DWORD dwSrcNo, DWORD dwRecordNo) const
{
	UINT64 id2 = MAKE_SRCRECNO(dwSrcNo, dwRecordNo);
	int iLevelNonPersistent = 0;
	if (!m_mapBought.Lookup(id2, iLevelNonPersistent))
		iLevelNonPersistent = 0;

	CIuMeterPtr pMeter = GetMeter(dwSrcNo);
	int iLevelPersistent = 0;
	if (pMeter.NotNull())
		iLevelPersistent = pMeter->GetBoughtLevel(dwSrcNo, dwRecordNo);

	int iLevel = max(iLevelNonPersistent, iLevelPersistent);
	return iLevel;
}

CIuMeterPtr CIuBought::GetMeter(DWORD /* dwSrcNo */) const
{
#pragma __TODO("CIuBought::GetMeter(DWORD dwSrcNo)")
#if 0
	// Find a meter attached to a source no
	if (dwSrcNo != DWORD(-1) && dwSrcNo == m_dwLastSrcNo)
		return m_pLastMeter;

	if (!HasMeters())
		return CIuMeterPtr();
	ASSERT(HasMeters());
	const_cast<CIuBought*>(this)->m_dwLastSrcNo = dwSrcNo;
	if (!m_mapMeter.Lookup(dwSrcNo, const_cast<CIuBought*>(this)->m_pLastMeter))
	{
		CIuMeterPtr pMeter = GetMeters().FindMeter(m_dwLastSrcNo);
		if (pMeter.IsNull())
		{
			const_cast<CIuBought*>(this)->m_pLastMeter.Release();
			return m_pLastMeter;
		}
		ASSERT(pMeter->HasInstance());
		const_cast<CIuBought*>(this)->m_pLastMeter = &pMeter->GetInstance();
		const_cast<CIuBought*>(this)->m_mapMeter.SetAt(m_dwLastSrcNo, const_cast<CIuBought*>(this)->m_pLastMeter.Ptr());
	}
#endif
	return m_pLastMeter;
}

void CIuBought::RemoveAll()
{
	m_mapBought.RemoveAll();
	SetCount(0);
}

void CIuBought::SetCount(int iCount)
{
	m_iCount = iCount;
}

bool CIuBought::SetLevel(const UINT64& id, int iLevel, bool fDecrement)
{
	return SetLevel(GET_SRCNO(id), GET_RECNO(id), iLevel, fDecrement);
}

bool CIuBought::SetLevel(DWORD dwSrcNo, DWORD dwRecordNo, int iLevel, bool fDecrement)
{
	UINT64 id2 = MAKE_SRCRECNO(dwSrcNo, dwRecordNo);
	if (iLevel > 0)
	{
		int iPreviousNonPersistentLevel;
		if (!m_mapBought.Lookup(id2, iPreviousNonPersistentLevel))
			iPreviousNonPersistentLevel = 0;

		bool fNonPersistentNewBuy = false;
		if (iPreviousNonPersistentLevel != iLevel)
		{
			m_mapBought.SetAt(id2, iLevel);
			fNonPersistentNewBuy = true;
		}

		CIuMeterPtr pMeter = GetMeter(dwSrcNo);
		bool fPersistentNewBuy = false;
		if (pMeter.NotNull())
		{
			if (!pMeter->SetBoughtLevel(dwSrcNo, dwRecordNo, iLevel, fDecrement, &fPersistentNewBuy))
				return false;
		}
		if (fNonPersistentNewBuy || fPersistentNewBuy)
			SetCount(GetCount() + 1);
	}
	else
	{
		// Don't change the persistent state...
		// Just remove from local 
		m_mapBought.RemoveKey(id2); 
	}
	return true;
}

void CIuBought::SetMeters(CIuMeters* pMeters)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	ASSERT(pMeters!= 0);
	m_pMeters = pMeters;
	m_mapMeter.RemoveAll();
}
