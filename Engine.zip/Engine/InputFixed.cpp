#include "StdAfx.h"
//{{Include
#include "InputFixed.h"
#include "resource.h"
#include "Data\DataFilename.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputFixed, CIuInputFixed_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputFixed)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTFIXED, CIuInputFixed, CIuInputFixed_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputFixed::CIuInputFixed() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputFixed::~CIuInputFixed()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputFixed::AddInput(int iField, LPCTSTR pcsz, int cb)
{
	ASSERT(iField >= 0 && iField < m_iFields);

	while (cb > 0 && _istspace(pcsz[0]))
	{
		++pcsz;
		--cb;
	}

	while (cb > 0 && _istspace(pcsz[cb - 1]))
		--cb;

	m_aiOffset[iField] = m_Buffer.GetSize();
	if (cb > 0)
		m_Buffer.Append((const BYTE*)pcsz, cb);
	m_Buffer.Append((BYTE)0);
}

void CIuInputFixed::AddInputFieldDef(int iLength)
{
	ASSERT(iLength > 0);
	m_iRecordLength += iLength;
	if (m_iFields >= recordMaxFields)
	{
		TRACE("WARNING: CIuInputDelimited::Add() exceeded maximum number of fields");
		ASSERT(false);
		return ;
	}
	if (m_iFields == 0)
		m_aiFieldOffset[m_iFields] = 0;
	else
		m_aiFieldOffset[m_iFields] = m_aiFieldOffset[m_iFields - 1] + m_aiFieldLength[m_iFields - 1];
	m_aiFieldLength[m_iFields] = iLength;
	++m_iFields;
}

void CIuInputFixed::ClearInputFieldDefs()
{
	m_iRecordLength = 0;
	m_iFields = 0;
}

void CIuInputFixed::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputFixed"));
	m_Buffer.PreAllocate(4096);
	m_iRecordLength = 0;
	m_iFields = 0;
	//}}Initialize
}

CIuFilename CIuInputFixed::GetFullInputFilename() const
{
	CIuFilename Filename = IuDataFilenameSearch(GetInputFilename(), ".fix");
	return Filename;
}

void CIuInputFixed::OnClose()
{
	m_Buffer.Destroy();
	CIuInputFixed_super::OnClose();
}

int CIuInputFixed::OnGetRange()
{
	// Return -1 to indicate range is not known
	// Used to indicate position of status bar....
	return int(m_Length / m_iRecordLength);
}

bool CIuInputFixed::OnMoveNext()
{
	ASSERT(m_iRecordLength >= 0);
	if (GetRemaining() < m_iRecordLength)
		if (!GetMore())
			return false;
	if (GetRemaining() < m_iRecordLength)
		return false;

	int iReps = GetRemaining() / m_iRecordLength;
	for (int i = 0; i < iReps; ++i)
	{
		m_Buffer.Empty();

		for (int iField = 0; iField < m_iFields; ++iField)
		{
			LPTSTR psz = m_psz + m_aiFieldOffset[iField];
			int cb = m_aiFieldLength[iField];
			AddInput(iField, psz, cb);
		}

		m_psz += m_iRecordLength;

		if (!Process())
			return false;
	}

	return true;
}

bool CIuInputFixed::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputFixed_super::OnOpen(OpenSpec))
		return false;

	int iCacheSize = GetCacheSize();
	ASSERT(m_iRecordLength != 0);
	iCacheSize += m_iRecordLength - 1;
	iCacheSize /= m_iRecordLength;
	iCacheSize *= m_iRecordLength;
	SetCacheSize(iCacheSize);
	return true;
}

void CIuInputFixed::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputFixed_super::SetSpec(Spec);
}

