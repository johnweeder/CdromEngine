#ifndef _ENGINE_ALTS_H_
#define _ENGINE_ALTS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ALT_H_
#	include "Engine\Alt.h"
#endif	// _ENGINE_ALT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAlts)
class CIuCdromSpec;
class CIuAltSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAlts, CIuCollection }}
#define CIuAlts_super CIuCollection

class CIuAlts : public CIuAlts_super
{
//{{Declare
	DECLARE_SERIAL(CIuAlts)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAlts();
	virtual ~CIuAlts();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAlt& Get(const CIuMoniker& moniker) const;
	CIuAlt& Get(LPCTSTR s) const;
	CIuAlt& Get(int iIndex) const;
	CIuAlt& Get(CIuID id) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Delete(CIuOutput* pOutput = 0);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void Create(CIuAltSpec& Alt);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAlt& CIuAlts::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuAlt*>(&CIuCollection::Get(moniker));
}

inline CIuAlt& CIuAlts::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuAlt*>(&CIuCollection::Get(s));
}

inline CIuAlt& CIuAlts::Get(int iIndex) const
{
	return *dynamic_cast<CIuAlt*>(&CIuCollection::Get(iIndex));
}

inline CIuAlt& CIuAlts::Get(CIuID id) const
{
	return *dynamic_cast<CIuAlt*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_ALTS_H_
