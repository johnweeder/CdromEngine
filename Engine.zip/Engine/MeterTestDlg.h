#ifndef _ENGINE_METERTESTDLG_H_
#define _ENGINE_METERTESTDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
//}}Uses

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// CIuMeterTestDlg dialog

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterTestDlg, CDialog }}
#define CIuMeterTestDlg_super CDialog

class CIuMeterTestDlg : public CIuMeterTestDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterTestDlg(CIuMeter&, CWnd* pParent);   
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void OnChange();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
//}}Data

public:
	//{{AFX_DATA(CIuMeterTestDlg)
	enum { IDD = IDD_ENGINE_METER_TEST };
	CTreeCtrl	m_Tree;
	CString	m_sCount;
	COleDateTime	m_ExpireDate;
	COleDateTime	m_WarningDate;
	COleDateTime	m_LastDate;
	COleDateTime	m_NotifyDate;
	CString	m_sRemainingRuns;
	BOOL	m_fRegistered;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnCorrupt();
	afx_msg void OnReset();
	afx_msg void OnUpdate();
	afx_msg void OnShowExpired();
	afx_msg void OnShowWarning();
	virtual void OnOK();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERTESTDLG_H_
