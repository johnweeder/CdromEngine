#ifndef _ENGINE_CDROMSPECCONST_H_
#define _ENGINE_CDROMSPECCONST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Some types used in specifications
class CIuCdrom;
class CIuCdromSpec;
IU_DEFINE_OBJECT_PTR(CIuAltSpec)
typedef CArray<CIuAltSpecPtr,CIuAltSpec*> CIuAltSpecArray;
IU_DEFINE_OBJECT_PTR(CIuBlobSpec)
typedef CArray<CIuBlobSpecPtr,CIuBlobSpec*> CIuBlobSpecArray;
IU_DEFINE_OBJECT_PTR(CIuBTreeSpec)
typedef CArray<CIuBTreeSpecPtr,CIuBTreeSpec*> CIuBTreeSpecArray;
IU_DEFINE_OBJECT_PTR(CIuBTreeTokenizerSpec)
typedef CArray<CIuBTreeTokenizerSpecPtr,CIuBTreeTokenizerSpec*> CIuBTreeTokenizerSpecArray;
IU_DEFINE_OBJECT_PTR(CIuMeterSpec)
typedef CArray<CIuMeterSpecPtr,CIuMeterSpec*> CIuMeterSpecArray;
IU_DEFINE_OBJECT_PTR(CIuRegistrationSpec)
IU_DEFINE_OBJECT_PTR(CIuReleaseNoteSpec)
typedef CArray<CIuReleaseNoteSpecPtr,CIuReleaseNoteSpec*> CIuReleaseNoteSpecArray;
IU_DEFINE_OBJECT_PTR(CIuSplashSpec)
IU_DEFINE_OBJECT_PTR(CIuTokenSpec)
typedef CArray<CIuTokenSpecPtr,CIuTokenSpec*> CIuTokenSpecArray;
IU_DEFINE_OBJECT_PTR(CIuUserInterfaceSpec)
IU_DEFINE_OBJECT_PTR(CIuCdromStripSpec)
typedef CArray<CIuCdromStripSpecPtr,CIuCdromStripSpec*> CIuCdromStripSpecArray;
IU_DEFINE_OBJECT_PTR(CIuExportDefSpec)
typedef CArray<CIuExportDefSpecPtr,CIuExportDefSpec*> CIuExportDefSpecArray;
IU_DEFINE_OBJECT_PTR(CIuReportDefSpec)
typedef CArray<CIuReportDefSpecPtr,CIuReportDefSpec*> CIuReportDefSpecArray;
IU_DEFINE_OBJECT_PTR(CIuFieldDefSpec)
typedef CArray<CIuFieldDefSpecPtr,CIuFieldDefSpec*> CIuFieldDefSpecArray;
IU_DEFINE_OBJECT_PTR(CIuExportFieldDefSpec)
typedef CArray<CIuExportFieldDefSpecPtr,CIuExportFieldDefSpec*> CIuExportFieldDefSpecArray;
IU_DEFINE_OBJECT_PTR(CIuReportFieldDefSpec)
typedef CArray<CIuReportFieldDefSpecPtr,CIuReportFieldDefSpec*> CIuReportFieldDefSpecArray;
IU_DEFINE_OBJECT_PTR(CIuCdromSourceSpec)
IU_DEFINE_OBJECT_PTR(CIuSicSpec)
IU_DEFINE_OBJECT_PTR(CIuAddressSpec)
IU_DEFINE_OBJECT_PTR(CIuGeoSpec)

/////////////////////////////////////////////////////////////////////////////
// Build flags

// Read in the raw alternate file data
const int cdromsBuildAlt						= 0x00000001;
const int cdromsBuildOther						= 0x00000002;

const int cdromsBuildInputRaw					= 0x00000010;
const int cdromsBuildInputSort				= 0x00000020;
const int cdromsBuildInputAddress			= 0x00000040;
const int cdromsBuildInputGeo					= 0x00000080;
const int cdromsBuildInputSic					= 0x00000100;
const int cdromsBuildInputTokens				= 0x00000200;
const int cdromsBuildInputIndexes			= 0x00000400;
const int cdromsBuildInput						= cdromsBuildInputRaw|cdromsBuildInputSort|cdromsBuildInputGeo|cdromsBuildInputAddress|cdromsBuildInputSic|cdromsBuildInputTokens|cdromsBuildInputIndexes;


const int cdromsBuildCompressAlt				= 0x00001000;
const int cdromsBuildCompressAddress		= 0x00002000;
const int cdromsBuildCompressGeo				= 0x00004000;
const int cdromsBuildCompressSic				= 0x00008000;
const int cdromsBuildCompressTokens			= 0x00010000;
const int cdromsBuildCompressBTree			= 0x00020000;
const int cdromsBuildCompress					= cdromsBuildCompressAlt|cdromsBuildCompressGeo|cdromsBuildCompressAddress|cdromsBuildCompressSic|cdromsBuildCompressTokens|cdromsBuildCompressBTree;

// Pack data files related to database (both files and objects)
const int cdromsBuildPackDatabaseFiles		= 0x00100000;
const int cdromsBuildPackDatabaseObjects	= 0x00200000;
// Pack auxiliary files (splash screens/blobs)
const int cdromsBuildPackAuxiliaryFiles	= 0x00400000;
const int cdromsBuildPackAuxiliaryObjects	= 0x00800000;
// Pack everything
const int cdromsBuildPack						= cdromsBuildPackDatabaseFiles|cdromsBuildPackDatabaseObjects|cdromsBuildPackAuxiliaryFiles|cdromsBuildPackAuxiliaryObjects;

// Split the cd-rom into pieces
const int cdromsBuildSplit						= 0x00000004;

// Special flag which causes certain objects in the database to be updated.
// Generally, only non-database objects can be updated.
const int cdromsBuildUpdate					= 0x00000008;

// Build the *.ID file associated with the database
const int cdromsBuildID							= 0x00000800;

// This deletes all files except the raw input
// files and the CD-ROM image.
// Generally each process is responsible for deleting any
// output files it creates.
// Object should also free any un-needed memory as part of 
// the delete process.
const int cdromsBuildDeleteStart				= 0x01000000;
// Called _after_ the build to delete any intermediate 
// or temporary files which were created. Basically, this
// just leaves the cd-rom image around.
const int cdromsBuildDeleteEnd				= 0x02000000;
// This flag deletes the CD-ROM image at the start of a build.
// This is a special case because the output file is
// obviously the most important.
const int cdromsBuildDeleteCdrom				= 0x04000000;

const int cdromsBuildDelete					= cdromsBuildDeleteStart|cdromsBuildDeleteEnd|cdromsBuildDeleteCdrom;

// Internal flag to raw record iterator
const int cdromsBuildProcess					= 0x80000000;

// Internal flag passed to build objects asking them
// to update the object repository
const int cdromsBuildUpdateRepository		= 0x40000000;
const int cdromsBuildSetRepository			= 0x20000000;

const int cdromsBuildAll						= cdromsBuildDeleteCdrom|cdromsBuildAlt|cdromsBuildOther|cdromsBuildInput|cdromsBuildCompress|cdromsBuildPack|cdromsBuildSplit|cdromsBuildID;

/////////////////////////////////////////////////////////////////////////////
// Product Types
enum CIuCdromProductNo
{
	cdromProductNone = 0,

	cdromProduct104mTest_2001,
	cdromProduct104mCentral_2001,
	cdromProduct104mGreatLakes_2001,
	cdromProduct104mNorthEast_2001,
	cdromProduct104mSouthEast_2001,
	cdromProduct104mWestern_2001,
	cdromProduct104mUsa_2001,

	cdromProduct88mdTest_2001,
	cdromProduct88mdUsa_2001,
	cdromProduct88mdWestern_2001,
	cdromProduct88mdSouthEast_2001,
	cdromProduct88mdCentral_2001,
	cdromProduct88mdNorthEast_2001,
	cdromProduct88mdMidWest_2001,

	cdromProductAcTest_V1,
	cdromProductAcUi_V1,
	cdromProductAcUsa_V1,
	cdromProductAcWestern_V1,
	cdromProductAcSouthEast_V1,
	cdromProductAcCentral_V1,
	cdromProductAcMidAtlantic_V1,
	cdromProductAcNorthEast_V1,
	cdromProductAcMidWest_V1,

	cdromProductBml1Test_2000,
	cdromProductBml1Usa_2000,

	cdromProductBml2Test_2000,
	cdromProductBml2Usa_2000,

	cdromProductCiTest_V1,
	cdromProductCiUi_V1,
	cdromProductCiUsa_V1,
	cdromProductCiWest_V1,
	cdromProductCiMidWest_V1,
	cdromProductCiEast_V1,

	cdromProductConsole,
	cdromProductMeterAdmin,
	cdromProductNetAdmin,

	cdromProductOamTest_V1,
	cdromProductOamUsa_V1,

	cdromProductPowerCheck,
	cdromProductReleaseNotes,
	cdromProductSample,

	cdromProductPbTest_2001,
	cdromProductPbUsa_2001,

	cdromProductPbmTest_V1,
	cdromProductPbmUsa_V1,

	cdromProductPfTest_2001,
	cdromProductPfEast_2001,
	cdromProductPfMidAtlantic_2001,
	cdromProductPfMidWest_2001,
	cdromProductPfMountain_2001,
	cdromProductPfNorthCentral_2001,
	cdromProductPfPacific_2001,
	cdromProductPfSouthern_2001,

	cdromProductPuTest_2001,
	cdromProductPuUsa_2001,

	cdromProductPgTest_2000,
	cdromProductPgWestern_2000,
	cdromProductPgSouthEast_2000,
	cdromProductPgCentral_2000,
	cdromProductPgMidAtlantic_2000,
	cdromProductPgNorthEast_2000,
	cdromProductPgMidWest_2000,
	cdromProductPgUsa_2000,

	cdromProductRbocTest_2000,
	cdromProductRbocGreatLakes_2000,
	cdromProductRbocMidWest_2000,
	cdromProductRbocNeAtlantic1_2000,
	cdromProductRbocNeAtlantic2_2000,
	cdromProductRbocPacific_2000,
	cdromProductRbocSeAtlantic1_2000,
	cdromProductRbocSeAtlantic2_2000,
	cdromProductRbocSouthWest_2000,

	cdromProductRpTest_2001,
	cdromProductRpUsa_2001,

	cdromProductSluTest_2000,
	cdromProductSluUsa_2000,

	cdromProductYpuTest_2001,
	cdromProductYpuUsa_2001,
};

/////////////////////////////////////////////////////////////////////////////
// Format Types
enum CIuCdromFormatNo
{
	cdromFormatNone = 0,

	cdromFormat104m_2001,
	cdromFormat88md_2001,
	cdromFormatAc_V1,
	cdromFormatBml1_2000,
	cdromFormatBml2_2000,
	cdromFormatCi_V1,
	cdromFormatConsole,
	cdromFormatMeterAdmin,
	cdromFormatNetAdmin,
	cdromFormatOam_V1,
	cdromFormatPb_2001,
	cdromFormatPbm_V1,
	cdromFormatPf_2001,
	cdromFormatPg_2000,
	cdromFormatPu_2001,
	cdromFormatPowerCheck,
	cdromFormatRboc_2000,
	cdromFormatReleaseNotes,
	cdromFormatRp_2001,
	cdromFormatSample,
	cdromFormatSlu_2000,
	cdromFormatYpu_2001,
};

/////////////////////////////////////////////////////////////////////////////
// Some constant strings
extern const LPCTSTR szDescriptionGenerate;

/////////////////////////////////////////////////////////////////////////////
// Release Descriptions
extern const TCHAR szRelease_Test[];
extern const TCHAR szRelease_Sample[];
extern const TCHAR szRelease_Internal[];

extern const TCHAR szRelease_V1[];
extern const TCHAR szRelease_V2[];

extern const TCHAR szRelease_2000R1[];
extern const TCHAR szRelease_2000R2[];

extern const TCHAR szRelease_2001R1[];

extern const TCHAR szRelease_Feb2000[];
extern const TCHAR szRelease_Mar2000[];
extern const TCHAR szRelease_Apr2000[];
extern const TCHAR szRelease_May2000[];
extern const TCHAR szRelease_Jun2000[];
extern const TCHAR szRelease_Jul2000[];
extern const TCHAR szRelease_Aug2000[];
extern const TCHAR szRelease_Sep2000[];
extern const TCHAR szRelease_Oct2000[];
extern const TCHAR szRelease_Nov2000[];
extern const TCHAR szRelease_Dec2000[];

/////////////////////////////////////////////////////////////////////////////
// Products and Product Groups
extern const TCHAR szProductGroup104m_Test_2001[];
extern const TCHAR szProductGroup104m_Usa_2001[];
extern const TCHAR szProductGroup104m_Regional_2001[];
extern const TCHAR szProductGroup88md_Test_2001[];
extern const TCHAR szProductGroup88md_Usa_2001[];
extern const TCHAR szProductGroup88md_Regional_2001[];
extern const TCHAR szProductGroupAc_Ui_V1[];
extern const TCHAR szProductGroupAc_Usa_V1[];
extern const TCHAR szProductGroupAc_Test_V1[];
extern const TCHAR szProductGroupAc_Regional_V1[];
extern const TCHAR szProductGroupBml1_Test_2000[];
extern const TCHAR szProductGroupBml1_Usa_2000[];
extern const TCHAR szProductGroupBml2_Test_2000[];
extern const TCHAR szProductGroupBml2_Usa_2000[];
extern const TCHAR szProductGroupCi_Test_V1[];
extern const TCHAR szProductGroupCi_Ui_V1[];
extern const TCHAR szProductGroupCi_Regional_V1[];
extern const TCHAR szProductGroupCi_Usa_V1[];
extern const TCHAR szProductGroupConsole[];
extern const TCHAR szProductGroupMeterAdmin[];
extern const TCHAR szProductGroupNetAdmin[];
extern const TCHAR szProductGroupOam_Test_V1[];
extern const TCHAR szProductGroupOam_Usa_V1[];
extern const TCHAR szProductGroupPb_Test_2001[];
extern const TCHAR szProductGroupPb_Usa_2001[];
extern const TCHAR szProductGroupPbm_Test_V1[];
extern const TCHAR szProductGroupPbm_Usa_V1[];
extern const TCHAR szProductGroupPf_2000[];
extern const TCHAR szProductGroupPf_Test_2001[];
extern const TCHAR szProductGroupPf_Regional_2001[];
extern const TCHAR szProductGroupPg_Test_2000[];
extern const TCHAR szProductGroupPg_Regional_2000[];
extern const TCHAR szProductGroupPg_Usa_2000[];
extern const TCHAR szProductGroupPowerCheck[];
extern const TCHAR szProductGroupPu_2000[];
extern const TCHAR szProductGroupPu_Test_2001[];
extern const TCHAR szProductGroupPu_Usa_2001[];
extern const TCHAR szProductGroupRboc_Test_2000[];
extern const TCHAR szProductGroupRboc_Regional_2000[];
extern const TCHAR szProductGroupReleaseNotes[];
extern const TCHAR szProductGroupRp_Test_2001[];
extern const TCHAR szProductGroupRp_Usa_2001[];
extern const TCHAR szProductGroupSample[];
extern const TCHAR szProductGroupSlu_Test_2000[];
extern const TCHAR szProductGroupSlu_Usa_2000[];
extern const TCHAR szProductGroupYpu_Test_2001[];
extern const TCHAR szProductGroupYpu_Usa_2001[];

/////////////////////////////////////////////////////////////////////////////
// Format Types
extern const TCHAR szFormat104m_2001[];
extern const TCHAR szFormat88md_2001[];
extern const TCHAR szFormatAc_V1[];
extern const TCHAR szFormatBml_2000[];
extern const TCHAR szFormatBml1_2000[];
extern const TCHAR szFormatBml2_2000[];
extern const TCHAR szFormatCi_V1[];
extern const TCHAR szFormatConsole[];
extern const TCHAR szFormatMeterAdmin[];
extern const TCHAR szFormatNetAdmin[];
extern const TCHAR szFormatOam_V1[];
extern const TCHAR szFormatPb_2001[];
extern const TCHAR szFormatPbm_V1[];
extern const TCHAR szFormatPf_2000[];
extern const TCHAR szFormatPf_2001[];
extern const TCHAR szFormatPg_2000[];
extern const TCHAR szFormatPowerCheck[];
extern const TCHAR szFormatPu_2000[];
extern const TCHAR szFormatPu_2001[];
extern const TCHAR szFormatRboc_2000[];
extern const TCHAR szFormatRbocGreatLakes_2000[];
extern const TCHAR szFormatRbocSeAtlantic1_2000[];
extern const TCHAR szFormatRbocSeAtlantic2_2000[];
extern const TCHAR szFormatRbocNeAtlantic1_2000[];
extern const TCHAR szFormatRbocNeAtlantic2_2000[];
extern const TCHAR szFormatRbocPacific_2000[];
extern const TCHAR szFormatRbocSouthWest_2000[];
extern const TCHAR szFormatRbocMidWest_2000[];
extern const TCHAR szFormatRbocTest_2000[];
extern const TCHAR szFormatRp_2001[];
extern const TCHAR szFormatReleaseNotes[];
extern const TCHAR szFormatSample[];
extern const TCHAR szFormatSlu_2000[];
extern const TCHAR szFormatYpu_2001[];

/////////////////////////////////////////////////////////////////////////////
// Application Types
extern const TCHAR szAppAc[];
extern const TCHAR szAppCdu[];
extern const TCHAR szAppCi[];
extern const TCHAR szAppMeterAdmin[];
extern const TCHAR szAppConsole[];
extern const TCHAR szAppNetAdmin[];
extern const TCHAR szAppPd[];
extern const TCHAR szAppReleaseNotes[];
extern const TCHAR szAppRp[];
extern const TCHAR szAppSlu[];
extern const TCHAR szAppPowerCheck[];

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMSPECCONST_H_
