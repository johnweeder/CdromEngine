#ifndef _ENGINE_OAMBROKER_H_
#define _ENGINE_OAMBROKER_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_XMLBROKER_H_
#	include "Data\XmlBroker.h"
#endif	// _DATA_XMLBROKER_H_
#ifndef 	_ENGINE_ENGINE_H_
#	include "Engine\Engine.h"
#endif	// _ENGINE_ENGINE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuOamBroker)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuOamBroker, CIuXmlBroker }}
#define CIuOamBroker_super CIuXmlBroker

class IU_CLASS_EXPORT CIuOamBroker : public CIuOamBroker_super
{
//{{Declare
	DECLARE_SERIAL(CIuOamBroker)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuOamBroker();
	virtual ~CIuOamBroker();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual bool Connect(LPCTSTR pcszConnect);
	virtual void DisConnect();
	virtual bool Transact(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	bool XmlConnect(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
	bool XmlDisconnect(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
	bool XmlError(CIuXmlDocumentPtr& pResponse, int iErrorCode, LPCTSTR pcszDescription = 0);
	bool XmlGetQueryDef(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
	bool XmlGetQueryNames(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
	bool XmlSuccess(CIuXmlDocumentPtr& pResponse);
	bool XmlWorkspace(CIuXmlDocumentPtr pRequest, CIuXmlDocumentPtr& pResponse);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Recursion flag
	bool m_fRecurse;
	// A mapping of workspace id's to instances of the engine
	CMap<CString, LPCTSTR, CIuEnginePtr, CIuEnginePtr> m_Workspaces;
	// Variables related to the current request
	CString m_sWorkspaceID;
	CIuEnginePtr m_pCurrent;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_OAMBROKER_H_
