#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Indexes.h"
#include "resource.h"
#include "Index.h"
#include "Database.h"
#include "CdromSpecConst.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuIndexes, CIuIndexes_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuIndexes)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INDEXES, CIuIndexes, CIuIndexes_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuIndexes, IDS_ENGINE_PPG_INDEXES, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuIndexes, IDS_ENGINE_PPG_INDEXES, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuIndexes


CIuIndexes::CIuIndexes()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuIndexes::~CIuIndexes()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuIndexes::Build(CIuCdrom&, CIuOutput& Output, CIuFlags)
{
	return Output.Fire();
}

void CIuIndexes::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pDatabase = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

CIuDatabase& CIuIndexes::GetDatabase() const
{
	ASSERT(m_pDatabase);
	return *m_pDatabase;
}

CIuCollectablePtr CIuIndexes::OnNew(CWnd*) const
{
	CIuIndexPtr pIndex;
	pIndex.Create();
	return CIuObjectPtr(pIndex);
}

void CIuIndexes::SetDatabase(CIuDatabase* pDatabase)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the Database
	m_pDatabase=pDatabase;
}

void CIuIndexes::SetSpec(CIuCdromSpec&)
{
}
