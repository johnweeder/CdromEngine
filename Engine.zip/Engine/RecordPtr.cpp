#include "StdAfx.h" 
//{{Include
#include "RecordPtr.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif


CIuRecordPtr::CIuRecordPtr()
{
	ASSERT(sizeof(*this) == sizeof(m_p));
	m_p = 0;
}

CIuRecordPtr::CIuRecordPtr(const CIuRecordPtr& pRecord)
{
	// This increments the reference count
	ASSERT(sizeof(*this) == sizeof(m_p));
	m_p = pRecord.m_p;
	if (m_p)
		m_p->AddRef();
}

CIuRecordPtr::CIuRecordPtr(const CIuRecord& Record)
{
	// This makes a copy
	m_p = 0;
	Set(Record);
}

CIuRecordPtr::CIuRecordPtr(const CIuRecord& Record, const CIuFieldMap& FieldMap)
{
	// This make a mapping
	m_p = 0;
	Map(Record, FieldMap);
}

CIuRecordPtr::CIuRecordPtr(CIuRecordSpec& RecordSpec)
{
	// This creates from a specification
	m_p = 0;
	Create(RecordSpec);
}

CIuRecordPtr::~CIuRecordPtr()
{
	Release();	
}

void CIuRecordPtr::Attach(const CIuRecord* pRecord, bool fInitial)
{
	ASSERT(pRecord);
	Release();
	m_p = (CIuRecord*)pRecord;
	if (fInitial)
	{
		ASSERT(pRecord->m_wRef == 0);
		m_p->m_wRef = 1;
	}
	else
	{
		ASSERT(pRecord->m_wRef >= 1 && pRecord->m_wRef != WORD(-1));
		++m_p->m_wRef;
	}
}

void CIuRecordPtr::Clear(bool fHiVal)
{
	if (m_p == 0)
	{
		m_p = CIuRecord::New(int(0));
		if (m_p)
			m_p->AddRef();
	}
	ASSERT(m_p);
	m_p->Clear(fHiVal);
}

void CIuRecordPtr::Create(CIuRecordSpec& RecordSpec)
{
	if (m_p != 0)
	{
		if (m_p->WillFitSpec(RecordSpec))
		{
			m_p->Set(RecordSpec);
			return ;			
		}
	}
	Release();
	m_p = CIuRecord::New(RecordSpec);
	if (m_p)
		m_p->AddRef();
}

void CIuRecordPtr::Map(const CIuRecord& Record, const CIuFieldMap& FieldMap)
{
	CIuRecordSpec Spec;
	Spec.Map(Record, FieldMap);
	Create(Spec);
}

void CIuRecordPtr::Release()
{
	if (m_p)
	{
		DWORD dwRef = m_p->Release();
		if (dwRef == 0)
		{
			CIuRecord::Delete(m_p);
		}
	}
	m_p = 0;
}

bool CIuRecordPtr::ResizeFlags(WORD wFlags)
{
	ASSERT(m_p);
	if (m_p->WillFitFlags(wFlags))
		return true;
	CIuRecord* p = CIuRecord::New(*m_p, wFlags);
	Release();
	ASSERT(p);
	if (p == 0)
		return false;
	m_p = p;
	m_p->AddRef();
	return true;
}

bool CIuRecordPtr::ResizeKey(int cbKey)
{
	ASSERT(m_p);
	if (m_p->WillFitKey(cbKey))
		return true;

	CIuRecord* p = CIuRecord::New(*m_p, 0, cbKey);
	Release();
	ASSERT(p);
	if (p == 0)
		return false;
	m_p = p;
	m_p->AddRef();
	return true;
}

void CIuRecordPtr::Set(const CIuRecord& Record)
{
	if (m_p != 0)
	{
		if (m_p->WillFitRecord(Record))
		{
			m_p->Set(Record);
			return ;			
		}
	}
	Release();
	m_p = CIuRecord::New(Record);
	if (m_p)
		m_p->AddRef();
}

void CIuRecordPtr::SetBuffer(const BYTE* pb, int cb)
{
	if (m_p != 0)
	{
		if (m_p->WillFitBuffer(pb, cb))
		{
			m_p->SetBuffer(pb, cb);
			return ;			
		}
	}
	Release();
	m_p = CIuRecord::NewBuffer(pb, cb);
	if (m_p)
		m_p->AddRef();
}


void CIuRecordPtr::SetExpandCount(DWORD dwExpandCount)
{
	if (m_p == 0)
		return ;
	if (!ResizeFlags(recordExpandCount))
		return ;
	m_p->SetExpandCount(dwExpandCount);
}

void CIuRecordPtr::SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount)
{
	if (m_p == 0)
		return ;
	if (!ResizeFlags(recordExpandNo|recordExpandCount))
		return ;
	m_p->SetExpandNo(dwExpandNo, dwExpandCount);
}

void CIuRecordPtr::SetKey(int iFields)
{
	if (m_p == 0)
		return ;
	m_p->SetKey(iFields);
}

void CIuRecordPtr::SetKey(const BYTE* pbKey, int cbKey)
{ 
	if (m_p == 0)
		return ;
	if (!ResizeKey(cbKey))
		return ;
	m_p->SetKey((const char*)pbKey, cbKey);
}

void CIuRecordPtr::SetLatLong(DWORD dwLat, DWORD dwLong)
{
	if (m_p == 0)
		return ;
	if (!ResizeFlags(recordLatLong))
		return ;
	m_p->SetLatLong(dwLat, dwLong);
}

void CIuRecordPtr::SetRecordNo(DWORD dwRecordNo)
{
	if (m_p == 0)
		return ;
	if (!ResizeFlags(recordRecordNo))
		return ;
	m_p->SetRecordNo(dwRecordNo);
}

void CIuRecordPtr::SetSourceNo(DWORD dwSourceNo)
{
	if (m_p == 0)
		return ;
	if (!ResizeFlags(recordSourceNo))
		return ;
	m_p->SetSourceNo(dwSourceNo);
}

void CIuRecordPtr::SetSubSet(const CIuRecord& Record, int iFirst, int iCount)
{
	ASSERT(&Record != m_p);

	int iFields = Record.GetFields();
	if (Record.IsLoVal() || Record.IsHiVal() || iFields <= 0 || Record.IsAlternate())
	{
		// Deal with the record separately
		Set(Record);
		return ;
	}

	ASSERT(iFirst >= 0);
	iFirst = min(iFirst, iFields - 1);
	iCount = min(iCount, iFields - iFirst);

	CIuRecordSpec Spec;
	for (int i = iFirst; i < iFirst + iCount; ++i)
	{
		int iSize;
		LPCTSTR pcsz = Record.GetField(i, iSize);
		if (iSize == 0)
			Spec.AddBlank();
		else
		{
			ASSERT(pcsz[iSize - 1] == '\0');
			Spec.Add(reinterpret_cast<const BYTE*>(pcsz), iSize - 1);
		}
	}

	// Copy miscellaneous flags and dwords
	Spec.Set(Record);

	// As a last step, copy the key value
	// This happens for both standard and alt records
	if (Record.HasKey())
	{
		// If input record had a key, copy it.
		// Be careful, there are two kinds of keys. One is appended.
		// The other is the first "N" fields.
		if (Record.m_wKeyOffset <= recordMaxKeyOffset)
		{
			Spec.SetKey(Record.GetKeyPtr(), Record.GetKeySize());
		}
		else
		{
			Spec.SetKey(Record.m_wKeyOffset - recordMaxKeyOffset);
		}
	}

	Create(Spec);
}
