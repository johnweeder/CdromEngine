#include "StdAfx.h"
//{{Include
#include "RecordHeap.h"
#include "Record.h"
#include "Error\Error.h"
#include "..\Version.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif


//{{Implement
IMPLEMENT_SERIAL(CIuRecordHeap, CIuRecordHeap_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordHeap)
const int iDefaultGrowBy = 64 * 1024;
const	CIuVersionNumber versionRecordHeapMax(2000,1,5,304);
const	CIuVersionNumber versionRecordHeapMin(1999,0,1,100);
//}}Implement

// NOTE: This structure must match the initial elements in a raw record.
#pragma pack(1)
struct CIuRecordHeader
{
	WORD m_wRef;					// Reference count
										// This value should never be zero.
										// NOTE: The value of 0xFFFF is reserved. The record heap uses this to
										// indicate a free node.
	DWORD m_dwTotalSize;			// Total allocated size of this block
										// This has been expand to 4 bytes where the raw record is 2
	DWORD m_dwNextFree;			// Offset of next free element or 0xFFFFFFFF
};
#pragma pack()

CIuRecordHeap::CIuRecordHeap() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRecordHeap::~CIuRecordHeap()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
	Empty();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuRecordHeap::Add(const CIuRecord* pRecord)
{
	ASSERT(pRecord);

	// Try to add it into a free block
	int iOffset = Insert(pRecord);
	if (iOffset >= 0)
		return iOffset;

	// There are no free blocks left, so we need to either allocate or free or exit
	switch (GetMode())
	{
		default:
			ASSERT(false);
			break;
		case rawRecordHeapModeSimple:
		case rawRecordHeapModeVariable:
			// Grow by an amount sufficient to hold the new record
			Grow(max(iDefaultGrowBy, pRecord->m_wUsedSize));
			// fall through
		case rawRecordHeapModeFixed:
			// Try to combine free space...
			Combine();
			break;
		case rawRecordHeapModeCache:
			// In caching mode, flush part of the cache
			Flush();
			break;
	}

	// Try again, return the offset of the record or -1
	iOffset = Insert(pRecord);
	return iOffset;
}

CIuRecord* CIuRecordHeap::Append(const CIuRecord* pRecord)
{
	// Simple mode function to add a record to the end of the set
	ASSERT(IsSimple() || IsVariable());
	// Add the record
	int iOffset = Add(pRecord);
	if (iOffset < 0)
		return 0;
	// Store the offset in an array
	m_Array.Add(iOffset);
	// Return a pointer to the record
	++m_iCount;
	ASSERT(m_iCount == m_Array.GetSize());
	return (CIuRecord*)m_Buffer.GetPtr(iOffset);
}

int CIuRecordHeap::AppendAt(const CIuRecord* pRecord)
{
	// Head mode function to add a record and return the offset
	// Returns -1 if record does not fit
	ASSERT(IsFixed());
	int iOffset = Add(pRecord);
	if (iOffset < 0)
		return -1;
	++m_iCount;
	return iOffset;
}

void CIuRecordHeap::Combine()
{
#ifdef _DEBUG
	if (m_fDebug)
		Validate();
#endif

	// If no free blocks, no need to really attempt to combine them.
	if (m_dwFree == 0xFFFFFFFF)
		return ;

	// Combine any adjacent free blocks. We do this simply by rebuilding 
	// the free list
	DWORD dwEnd = m_Buffer.GetSize();
	if (dwEnd == 0)
		return ;

	// Start with an empty free list
	m_dwFree = 0xFFFFFFFF;

	// Walk the heap
	const BYTE* pb = m_Buffer.GetPtr();
	DWORD dw = 0;
	while (dw < dwEnd)
	{
		CIuRecordHeader* pHeader = (CIuRecordHeader*)(pb + dw);

		if (pHeader->m_wRef == 0xFFFF)
		{
			// Add this block to the free list
			pHeader->m_dwNextFree = m_dwFree;
			m_dwFree = dw;

			// Move to next block
			dw += pHeader->m_dwTotalSize;
			ASSERT(dw <= dwEnd);

			// Combine with all subsequent free blocks.
			while (dw < dwEnd)
			{
				CIuRecordHeader* pHeaderNext = (CIuRecordHeader*)(pb + dw);
				if (pHeaderNext->m_wRef == 0xFFFF)
				{
					pHeader->m_dwTotalSize += pHeaderNext->m_dwTotalSize;
					dw += pHeaderNext->m_dwTotalSize;
					ASSERT(dw <= dwEnd);
				}
				else
					break;
			}
		}
		else
		{
			// This is a record, skip over it
			const CIuRecord* pRecord = (const CIuRecord*)pHeader;
			dw += pRecord->m_wTotalSize;
			ASSERT(dw <= dwEnd);
		}
	}

	// Make sure we end up at the end of the heap
	ASSERT(dw == dwEnd);
}

void CIuRecordHeap::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iMode = rawRecordHeapModeNone;
	m_dwFree = 0xFFFFFFFF;
	m_fFlushTopHalf = true;
	m_iCount = 0;
	m_Buffer.SetGrowBy(0);
	m_fDebug = false;
	SetVersion(IU_VERSION);
	SetVersion(versionRecordHeapMax);
	//}}Initialize
}

void CIuRecordHeap::Delete(int iOffset)
{
	// Validate this block before we delete it
#ifdef _DEBUG
	if (m_fDebug)
		Validate(iOffset);
#endif

	// Get a pointer to the record
	ASSERT(iOffset >= 0 && iOffset < m_Buffer.GetSize());
	BYTE* pb = m_Buffer.GetPtr() + iOffset;
	CIuRecord* pRecord = (CIuRecord*)pb;

#ifdef _DEBUG
	if (pRecord->m_wRef == 0xFFFF)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Attempt to free an unallocated record."));
	if (pRecord->m_wRef != 1)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Attempt to free a record which is in use."));
#endif

	if (IsCache())
	{
		UINT64 uiSrcRecNo = MAKE_SRCRECNO(pRecord->GetSourceNo(), pRecord->GetRecordNo());
		m_Map.RemoveKey(uiSrcRecNo);
	}

	// Turn this into a free block
	DWORD dwTotalSize = pRecord->m_wTotalSize;

	CIuRecordHeader* pHeader = (CIuRecordHeader*)pRecord;
	pHeader->m_wRef = 0xFFFF;
	pHeader->m_dwTotalSize = dwTotalSize;
	pHeader->m_dwNextFree = m_dwFree;

	m_dwFree = DWORD(iOffset);

	ASSERT(m_iCount > 0);
	--m_iCount;


	// NOTE: You must explicitly call Combine() to combine adjacent free block.
}

void CIuRecordHeap::Empty()
{
	if (Validate() != 0)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Can not free heap. Records are in use."));

	m_fFlushTopHalf = true;
	m_iCount = 0;
	m_Map.RemoveAll();
	m_Array.RemoveAll();
	m_dwFree = 0xFFFFFFFF;

	DWORD dwTotalSize = m_Buffer.GetSize();
	if (dwTotalSize <= 0)
		return ;

	// Create a header at the start of the block
	BYTE* pb = m_Buffer.GetPtr();
	CIuRecordHeader* pHeader = (CIuRecordHeader*)pb;
	pHeader->m_wRef = 0xFFFF;
	pHeader->m_dwTotalSize = dwTotalSize;
	pHeader->m_dwNextFree = 0xFFFFFFFF;

	// Entire buffer is a free block
	m_dwFree = 0;
}

void CIuRecordHeap::Flush()
{
#ifdef _DEBUG
	if (m_fDebug)
		Validate();
#endif

	// Get the size and early out on an empty buffer
	DWORD dwEnd = m_Buffer.GetSize();
	ASSERT(dwEnd != 0);
	if (dwEnd == 0)
		return ;

	// Set up our pointers
	const BYTE* pb = m_Buffer.GetPtr();
	DWORD dw = 0;
	DWORD dwMiddle = dwEnd / 2;

	// Walk the heap
	while (dw < dwEnd)
	{
		// Get pointers to this block
		CIuRecordHeader* pHeader = (CIuRecordHeader*)(pb + dw);
		CIuRecord* pRecord = 0;
		DWORD dwSize;

		// Get the size
		if (pHeader->m_wRef == 0xFFFF)
			dwSize = pHeader->m_dwTotalSize;
		else
		{
			// Actual data record
			pRecord = (CIuRecord*)pHeader;
			dwSize = pRecord->m_wTotalSize;
			// If this record has a reference count, skip over it
			ASSERT(pRecord->m_wRef != 0);
			if (pRecord->m_wRef > 1)
			{
				dw += dwSize;
				continue;
			}
		}

		ASSERT((dwSize % sizeof(CIuRecordHeader)) == 0);

		// If we are flushing the top half, skip blocks until then
		if (m_fFlushTopHalf)
		{
			if (dw < dwMiddle)
			{
				dw += dwSize;
				continue;
			}
		}
		else
		{
			// If we are flushing the bottom and we are done, break
			if (dw >= dwMiddle)
			{
				dw = dwEnd;
				break;
			}
		}

		// Only delete the non-free blocks
		if (pRecord != 0)
			Delete(dw);

		dw += dwSize;
	}

	// We should end up at the end of the buffer
	ASSERT(dw == dwEnd);

	// Toggle the "half" which will be flushed on the next pass.
	m_fFlushTopHalf = !m_fFlushTopHalf;

	// Combine adjacent free blocks
	Combine();

#ifdef _DEBUG
	if (m_fDebug)
		Validate();
#endif
}
	 
CIuRecord* CIuRecordHeap::Get(int iIndex) const
{
	// Simple mode function to retrieve a record by index
	ASSERT(IsSimple() || IsVariable());
	ASSERT(iIndex >= 0 && iIndex < m_Array.GetSize());
	ASSERT(m_iCount == m_Array.GetSize());
	int iOffset = m_Array[iIndex];
	ASSERT(iOffset >= 0 && iOffset < m_Buffer.GetSize());
	return (CIuRecord*)m_Buffer.GetPtr(iOffset);
}

CIuRecord* CIuRecordHeap::GetAt(int iOffset) const
{
	// Heap mode function to retrieve a record by offset
	ASSERT(IsFixed());
	ASSERT(iOffset >= 0 && iOffset < m_Buffer.GetSize());
	return (CIuRecord*)m_Buffer.GetPtr(iOffset);
}

void CIuRecordHeap::GetBuffer(CIuBuffer& Buffer) const
{
#pragma __TODO("CIuRecordHeap::GetBuffer(): Improve efficiency. Dont write whole buffer if it is not full.")
	Buffer.Append((const BYTE*)&versionRecordHeapMax, sizeof(versionRecordHeapMax));

	ASSERT(IsFixed() || IsSimple() || IsVariable());

	Buffer.Append((const BYTE*)&m_iMode, sizeof(m_iMode));
	Buffer.Append((const BYTE*)&m_dwFree, sizeof(m_dwFree));
	Buffer.Append((const BYTE*)&m_iCount, sizeof(m_iCount));

	int iGrowBy = m_Buffer.GetGrowBy();
	Buffer.Append((const BYTE*)&iGrowBy, sizeof(iGrowBy));
	int iSize = m_Buffer.GetSize();
	Buffer.Append((const BYTE*)&iSize, sizeof(iSize));
	Buffer.Append(m_Buffer.GetPtr(), m_Buffer.GetSize());

	int iArray = m_Array.GetSize();
	Buffer.Append((const BYTE*)&iArray, sizeof(iArray));
	Buffer.Append((const BYTE*)m_Array.GetData(), iArray * sizeof(int));
}

CIuVersionNumber CIuRecordHeap::GetVersionMax() const
{
	return versionRecordHeapMax;
}

CIuVersionNumber CIuRecordHeap::GetVersionMaxStatic()
{
	return versionRecordHeapMax;
}

CIuVersionNumber CIuRecordHeap::GetVersionMin() const
{
	return versionRecordHeapMin;
}

CIuVersionNumber CIuRecordHeap::GetVersionMinStatic()
{
	return versionRecordHeapMin;
}

void CIuRecordHeap::Grow(int iGrowBy)
{
	int iSize = m_Buffer.GetSize();
	iGrowBy += sizeof(CIuRecordHeader) - 1;
	iGrowBy /= sizeof(CIuRecordHeader);
	iGrowBy *= sizeof(CIuRecordHeader);
	ASSERT((iGrowBy % sizeof(CIuRecordHeader)) == 0);
	ASSERT((iSize % sizeof(CIuRecordHeader)) == 0);

	m_Buffer.SetSize(iSize + iGrowBy);
	
	BYTE* pb = m_Buffer.GetPtr();
	CIuRecordHeader* pHeader = (CIuRecordHeader*)(pb + iSize);
	pHeader->m_wRef = 0xFFFF;
	pHeader->m_dwTotalSize = DWORD(iGrowBy);
	pHeader->m_dwNextFree = m_dwFree;

	m_dwFree = iSize;

#ifdef _DEBUG
	if (m_fDebug)
		Validate();
#endif
}

int CIuRecordHeap::Insert(const CIuRecord* pRecord)
{
	// Check if we can add this record in a free block
	if (m_dwFree == 0xFFFFFFFF)
		return -1;

#ifdef _DEBUG
	if (m_fDebug)
		Validate();
#endif

	BYTE* pb = m_Buffer.GetPtr();
	DWORD dwNext = m_dwFree;
	DWORD dwPrevious = 0xFFFFFFFF;
	while (dwNext != 0xFFFFFFFF)
	{
		CIuRecordHeader* pHeader = (CIuRecordHeader*)(pb + dwNext);
		if (pHeader->m_dwTotalSize >= pRecord->m_wUsedSize)
		{
			DWORD dwTotalSize = pHeader->m_dwTotalSize;
			WORD wNeeded = pRecord->m_wUsedSize;
			wNeeded += sizeof(CIuRecordHeader) - 1;
			wNeeded /= sizeof(CIuRecordHeader);
			wNeeded *= sizeof(CIuRecordHeader);
			ASSERT(wNeeded >= pRecord->m_wUsedSize);
			ASSERT(wNeeded <= dwTotalSize);

			// Split this block if we can
			if (dwTotalSize - wNeeded >= sizeof(CIuRecordHeader))
			{
				DWORD dwFreeSize = dwTotalSize - wNeeded;
				ASSERT((dwFreeSize % sizeof(CIuRecordHeader)) == 0);

				pHeader->m_dwTotalSize = dwFreeSize;
				dwNext += dwFreeSize;
				dwTotalSize -= dwFreeSize;
			}
			// Otherwise, use the whole block
			else
			{
				if (dwPrevious == 0xFFFFFFFF)
				{
					m_dwFree = pHeader->m_dwNextFree;
				}
				else
				{
					CIuRecordHeader* pHeaderPrevious = (CIuRecordHeader*)(pb + dwPrevious);
					pHeaderPrevious->m_dwNextFree = pHeader->m_dwNextFree;
				}
			}

			ASSERT(dwTotalSize <= recordMaxSize);
			ASSERT((dwTotalSize % sizeof(CIuRecordHeader)) == 0);
			ASSERT(dwTotalSize >= pRecord->m_wUsedSize);

			CIuRecord* pRecordNew = (CIuRecord*)(pb + dwNext);
			memcpy(pRecordNew, pRecord, pRecord->m_wUsedSize);

			pRecordNew->m_wRef = 1;
			pRecordNew->m_wTotalSize = WORD(dwTotalSize);
			pRecordNew->m_wUsedSize = pRecord->m_wUsedSize;

#ifdef _DEBUG
			if (m_fDebug)
				Validate();
#endif
			return dwNext;
		}
		dwPrevious = dwNext;
		dwNext = pHeader->m_dwNextFree;
	}

	// No free block of sufficient size available
	return -1;
}

CIuRecord* CIuRecordHeap::Lookup(UINT32 uiSrcNo, UINT32 uiRecNo) const
{
	// Caching mode function to retrieve a record from the cache
	ASSERT(IsCache());

	// Try to find it in the cache
	UINT64 uiSrcRecNo = MAKE_SRCRECNO(uiSrcNo, uiRecNo);
	__int32 iOffset;
	if (!m_Map.Lookup(uiSrcRecNo, iOffset))
		return 0;

	ASSERT(iOffset >= 0 && iOffset < m_Buffer.GetSize());
	return (CIuRecord*)m_Buffer.GetPtr(iOffset);
}

void CIuRecordHeap::Remove(int iIndex) 
{
	// Delete a record from a variable sized cache.
	ASSERT(IsVariable());
	ASSERT(iIndex >= 0 && iIndex < m_Array.GetSize());
	ASSERT(m_iCount == m_Array.GetSize());
	int iOffset = m_Array[iIndex];
	ASSERT(iOffset >= 0 && iOffset < m_Buffer.GetSize());
	Delete(iOffset);
	m_Array.RemoveAt(iIndex);
}

void CIuRecordHeap::RemoveAt(int iOffset) 
{
	// Heap mode function to remove a record by offset
	ASSERT(IsFixed());
	Delete(iOffset);
}

CIuRecord* CIuRecordHeap::Set(const CIuRecord* pRecord)
{
	// Caching function which stores a raw record in the cache
	ASSERT(IsCache());

	// Create the key
	ASSERT(pRecord);
	UINT64 uiSrcRecNo = MAKE_SRCRECNO(pRecord->GetSourceNo(), pRecord->GetRecordNo());

	// See if it is alread in the cache
	__int32 iOffset;
	if (m_Map.Lookup(uiSrcRecNo, iOffset))
	{
		// If it is, delete it.
		Delete(iOffset);
		m_Map.RemoveKey(uiSrcRecNo);
	}

	// Add it to the cache
	iOffset = Add(pRecord);
	if (iOffset < 0)
		return 0;

	// And to the mapping
	m_Map.SetAt(uiSrcRecNo, iOffset);

	// Return the record
	++m_iCount;
	return (CIuRecord*)m_Buffer.GetPtr(iOffset);
}
	 
int CIuRecordHeap::SetBuffer(const CIuBuffer& Buffer, int iOffset)
{
	ASSERT(iOffset >= 0);
	CIuVersionNumber VersionNumber;
	iOffset += Buffer.Get((BYTE*)&VersionNumber, sizeof(VersionNumber), iOffset);
	if (VersionNumber < versionRecordHeapMin || VersionNumber > versionRecordHeapMax)
		Error(IU_E_OBJECT_INVALID_OR_CORRUPT, _T("CIuRecordHeap"));

	int iMode;
	iOffset += Buffer.Get((BYTE*)&iMode, sizeof(iMode), iOffset);
	SetMode(iMode);
	ASSERT(IsFixed() || IsSimple() || IsVariable());

	iOffset += Buffer.Get((BYTE*)&m_dwFree, sizeof(m_dwFree), iOffset);
	iOffset += Buffer.Get((BYTE*)&m_iCount, sizeof(m_iCount), iOffset);

	int iGrowBy;
	iOffset += Buffer.Get((BYTE*)&iGrowBy, sizeof(iGrowBy), iOffset);
	m_Buffer.SetGrowBy(iGrowBy);
	int iSize;
	iOffset += Buffer.Get((BYTE*)&iSize, sizeof(iSize), iOffset);
	m_Buffer.SetSize(iSize);
	iOffset += Buffer.Get(m_Buffer.GetPtr(), m_Buffer.GetSize(), iOffset);

	int iArray;
	iOffset += Buffer.Get((BYTE*)&iArray, sizeof(iArray), iOffset);
	m_Array.SetSize(iArray);
	iOffset += Buffer.Get((BYTE*)m_Array.GetData(), iArray * sizeof(int), iOffset);

	return iOffset;
}

void CIuRecordHeap::SetMode(int iMode, int iSize)
{
	// Must be a valid mode
	ASSERT(iMode == rawRecordHeapModeSimple || iMode == rawRecordHeapModeCache || iMode == rawRecordHeapModeFixed || iMode == rawRecordHeapModeVariable);

	// Setting the mode forces an empty
	Empty();

	// Set the mode again
	m_iMode = iMode;
	m_fFlushTopHalf = true;
	m_iCount = 0;
	m_Map.RemoveAll();
	m_Array.RemoveAll();
	m_dwFree = 0xFFFFFFFF;

	// Allocate a buffer
	iSize /= sizeof(CIuRecordHeader);
	iSize = max(1, iSize);
	iSize *= sizeof(CIuRecordHeader);
	m_Buffer.SetSize(iSize);

	// Make the enture buffer into a free block
	BYTE* pb = m_Buffer.GetPtr();
	CIuRecordHeader* pHeader = (CIuRecordHeader*)pb;
	pHeader->m_wRef = 0xFFFF;
	pHeader->m_dwTotalSize = DWORD(iSize);
	pHeader->m_dwNextFree = 0xFFFFFFFF;

	// Entire buffer is free
	m_dwFree = 0;

	// Set a grow-by size for the array which tracks record offset
	if (IsSimple())
		m_Array.SetSize(0, 1024);
	// Pick a relative large size for the hash table
	else if (IsCache())
		m_Map.InitHashTable(15031);
}

int CIuRecordHeap::Validate(int iOffset) const
{
	ASSERT(sizeof(CIuRecordHeader) == 10);
	ASSERT((recordMaxSize % sizeof(CIuRecordHeader)) == 0);

	int cb = m_Buffer.GetSize();
	if (cb == 0)
		return 0;

	if ((cb % sizeof(CIuRecordHeader)) != 0)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Heap size is not a multiple of sizeof(CIuRecordHeader)."));
	ASSERT((cb % sizeof(CIuRecordHeader)) == 0);

	if (iOffset >= cb)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Record offset past end of heap."));

	const BYTE* pb = m_Buffer.GetPtr();
	const BYTE* pbEnd = pb + cb;
	const BYTE* pbOffset = pb + iOffset;

	int iUnFreed = 0;
	bool fFound = false;
	while (pb < pbEnd)
	{
		const CIuRecordHeader* pHeader = (const CIuRecordHeader*)pb;

		if (pb == pbOffset)
			fFound = true;
		
		if (pHeader->m_wRef == 0)
			Error(IU_E_RECORDHEAP_FAILURE, _T("Record has invalid reference count."));
		if (pHeader->m_wRef != 0xFFFF)
		{
			const CIuRecord* pRecord = (const CIuRecord*)pHeader;

			if (pRecord->m_wTotalSize < sizeof(CIuRecordHeader))
				Error(IU_E_RECORDHEAP_FAILURE, _T("Raw record size is < sizeof(CIuRecordHeader)."));
			if ((pRecord->m_wTotalSize % sizeof(CIuRecordHeader)) != 0)
				Error(IU_E_RECORDHEAP_FAILURE, _T("Raw record size is not MOD sizeof(CIuRecordHeader)."));
			if (pRecord->m_wUsedSize > pRecord->m_wTotalSize)
				Error(IU_E_RECORDHEAP_FAILURE, _T("Raw record size exceeds block size."));
			if (pRecord->m_wRef > 1)
				++iUnFreed;

			pb += pRecord->m_wTotalSize;
		}
		else
		{
			if (pHeader->m_dwTotalSize < sizeof(CIuRecordHeader))
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block size is < sizeof(CIuRecordHeader)."));
			if ((pHeader->m_dwTotalSize % sizeof(CIuRecordHeader)) != 0)
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block size is not MOD sizeof(CIuRecordHeader)."));
			if (pHeader->m_dwNextFree != 0xFFFFFFFF && pHeader->m_dwNextFree >= DWORD(cb))
				Error(IU_E_RECORDHEAP_FAILURE, _T("Next free block offset is out of range."));

			pb += pHeader->m_dwTotalSize;
		}
	}

	if (pb != pbEnd)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Heap corrupted."));

	if (!fFound && iOffset >= 0)
		Error(IU_E_RECORDHEAP_FAILURE, _T("Record not found on heap."));

	// Walk the empty blocks
	if (m_dwFree != 0xFFFFFFFF)
	{
		const BYTE* pb = m_Buffer.GetPtr();
		DWORD dwNext = m_dwFree;
		while (dwNext != 0xFFFFFFFF)
		{
			if (dwNext >= DWORD(cb - sizeof(CIuRecordHeader)))
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block offset is out of range."));

			const CIuRecordHeader* pHeader = (const CIuRecordHeader*)(pb + dwNext);
			if (pHeader->m_wRef != 0xFFFF)
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block has incorrect reference count."));
			if (pHeader->m_dwTotalSize < sizeof(CIuRecordHeader))
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block size is < sizeof(CIuRecordHeader)."));
			if ((pHeader->m_dwTotalSize % sizeof(CIuRecordHeader)) != 0)
				Error(IU_E_RECORDHEAP_FAILURE, _T("Free block size is not MOD sizeof(CIuRecordHeader)."));
			dwNext = pHeader->m_dwNextFree;
		}
	}

	// Return the number of records on the heap which have not been free'd
	return iUnFreed;
}
