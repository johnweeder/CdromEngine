#ifndef _ENGINE_EXPRESSIONLISTBOXEDITOR_H_
#define _ENGINE_EXPRESSIONLISTBOXEDITOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif
//{{Uses
#ifndef 	_UI_LISTBOXEDITOR_H_
#	include "Ui\ListBoxEditor.h"
#endif	// _UI_LISTBOXEDITOR_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionListBoxEditor, CIuListBoxEditor }}
#define CIuExpressionListBoxEditor_super CIuListBoxEditor

class IU_CLASS_EXPORT CIuExpressionListBoxEditor : public CIuExpressionListBoxEditor_super
{

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

	/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual bool Initialize(UINT uiID, CWnd* pwndParent, int iFlags = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
protected:
	virtual bool OnAdd(int iIndex, CString& sValue);
	virtual bool OnBrowse(int iIndex, CString& s, DWORD& dw);
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2
#endif // _ENGINE_EXPRESSIONLISTBOXEDITOR_H_
