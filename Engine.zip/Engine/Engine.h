#ifndef _ENGINE_ENGINE_H_
#define _ENGINE_ENGINE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ENGINEAPP_H_
#	include "Engine\EngineApp.h"
#endif	// _ENGINE_ENGINEAPP_H_
#ifndef 	_DATA_PACKREPOSITORY_H_
#	include "Data\PackRepository.h"
#endif	// _DATA_PACKREPOSITORY_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuEngine)
IU_DEFINE_OBJECT_PTR(CIuExporters)
IU_DEFINE_OBJECT_PTR(CIuExportDefs)
IU_DEFINE_OBJECT_PTR(CIuBuilds)
IU_DEFINE_OBJECT_PTR(CIuDatabases)
IU_DEFINE_OBJECT_PTR(CIuListeners)
IU_DEFINE_OBJECT_PTR(CIuGps)
IU_DEFINE_OBJECT_PTR(CIuTapi)
IU_DEFINE_OBJECT_PTR(CIuMeters)
IU_DEFINE_OBJECT_PTR(CIuQueries)
IU_DEFINE_OBJECT_PTR(CIuUserInterfaces)
IU_DEFINE_OBJECT_PTR(CIuSplashes)
IU_DEFINE_OBJECT_PTR(CIuBlobs)
IU_DEFINE_OBJECT_PTR(CIuReleaseNotes)
IU_DEFINE_OBJECT_PTR(CIuRegistrations)
IU_DEFINE_OBJECT_PTR(CIuReporters)
IU_DEFINE_OBJECT_PTR(CIuReportDefs)
IU_DEFINE_OBJECT_PTR(CIuSourceProvider)
IU_DEFINE_OBJECT_PTR(CIuDatabaseList)
IU_DEFINE_OBJECT_PTR(CIuExport)
IU_DEFINE_OBJECT_PTR(CIuSelect)
IU_DEFINE_OBJECT_PTR(CIuSimpleQuery)
IU_DEFINE_OBJECT_PTR(CIuQuery)
class CIuProgressDlg;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// A list of collections maintained by the engine
enum CIuEngineCollections
{
	collectionDatabases,
	collectionExportDefs,
	collectionExporters,
	collectionMeters,
	collectionReleaseNotes,
	collectionReportDefs,
	collectionReporters,
	collectionUserInterfaces,
	collectionBlobs,
	collectionSplashes,
	collectionSourceDescriptors,
	collectionBTrees,
	collectionTokens,
	collectionSics,
	collectionGeos,
	collectionRegistrations,
};

/////////////////////////////////////////////////////////////////////////////
// Flags describing rights allowed by the current user

const int engineRightsNone								= 0x00000000;
const int engineRightsAll								= 0xFFFFFFFF;

// Implies the person is on an interal infoUSA network
// and gets minimal access rights
const int engineRightsInternal						= 0x80000000;

// Can see the various super code
const int engineRightsSuper							= 0x00000001;

// Can grant access codes for multi-user licenses
const int engineRightsMultiUserLicense				= 0x00000002;

// Can grant access codes for multi-user licenses
const int engineRightsBuild							= 0x00000004;

// Can access meter admin in release mode
const int engineRightsMeterAdmin						= 0x00000008;

// Can invoke the "test" mode mode of the meter
//	Basically, this allows access to a special dialog to 
//		configure the meter for testing.
const int engineRightsTest		 						= 0x00000010;

// Can generate meter codes valid for a range of dates.
const int engineRightsDateRange						= 0x00000020;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuEngine, CIuObjectNamed }}

#define CIuEngine_super CIuObjectNamed

class IU_CLASS_EXPORT CIuEngine : public CIuEngine_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuEngine)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuEngine();           // protected constructor used by dynamic creation
	virtual ~CIuEngine();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuBlobs& GetBlobs() const;
	CIuProgressBroadcast& GetBroadcast() const;
	CIuBuilds& GetBuilds() const;
	bool GetConnected();
	CIuDatabases& GetDatabases() const;
	CIuExportDefs& GetExportDefs() const;
	CIuExporters& GetExporters() const;
	CIuGps& GetGps() const;
	CIuListeners& GetListeners() const;
	CIuMeters& GetMeters() const;
	CIuPackRepository& GetPackRepository() const;
	CIuRegistrations& GetRegistrations() const;
	CIuReleaseNotes& GetReleaseNotes() const;
	CIuQueries& GetQueries() const;
	CIuTapi& GetTapi() const;
	CIuSplashes& GetSplashes() const;
	CIuUserInterfaces& GetUserInterfaces() const;
	CIuReporters& GetReporters() const;
	CIuReportDefs& GetReportDefs() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuSourceProvider& GetSourceProvider() const;
	int GetUserRights() const;
	bool IsDebug() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool CheckVersion(LPCTSTR pcszName, CIuVersionNumber version, bool fShowDlg = true, CWnd* pParent = 0);
	void CloseUnused();
	bool Connect(LPCTSTR ConnectString = 0);
	bool ConnectDlg(int ForceDialog, CWnd* pWnd);
	CIuDatabaseListPtr CreateDatabaseList() const;
	CIuExportPtr CreateExport() const;
	CIuOutputPtr CreateOutput() const;
	CIuProgressDlg* CreateProgressDlg(CWnd* pParent, LPCTSTR pcszTitle = _T("Stand by..."), int iHandle = -1) const;
	CIuQueryPtr CreateQuery() const;
	CIuSelectPtr CreateSelect() const;
	CIuSimpleQueryPtr CreateSimpleQuery() const;
	void DisConnect();
	bool QueryCollection(int iCollection, CIuObjectRepository& Repository);
	bool QueryObject(int iCollection, const CIuObjectDescriptor& Descriptor, CIuObject& Object, CString* = 0);
	void Refresh();
	bool RefreshCollection(int iCollection, CIuCollection& Collection);
	bool SearchWhereDlg(CWnd* pParent);
	void SetDebug(bool);
	void ShowUserRightsException() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionCreateDatabaseList(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionCreateExport(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionCreateSelect(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionRefresh(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionSearchWhere(const CIuPropertyCollection&, CIuOutput&);
	CIuObject* GetBlobs_() const;
	CIuObject* GetBuilds_() const;
	CIuObject* GetDatabases_() const;
	CIuObject* GetExportDefs_() const;
	CIuObject* GetExporters_() const;
	CIuObject* GetGps_() const;
	CIuObject* GetMeters_() const;
	CIuObject* GetQueries_() const;
	CIuObject* GetRegistrations_() const;
	CIuObject* GetReleaseNotes_() const;
	CIuObject* GetReportDefs_() const;
	CIuObject* GetReporters_() const;
	CIuObject* GetSourceProvider_() const;
	CIuObject* GetSplashes_() const;
	CIuObject* GetTapi_() const;
	CIuObject* GetUserInterfaces_() const;
protected:
	void CheckConnected() const;
	void CommonConstruct();
	void RefreshPackRepository();
private:
	bool IsValidIp() const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Child objects
	CIuExportersPtr m_pExporters;
	CIuExportDefsPtr m_pExportDefs;
	CIuBuildsPtr m_pBuilds;
	CIuDatabasesPtr m_pDatabases;
	CIuListenersPtr m_pListeners;
	CIuGpsPtr m_pGps;
	CIuTapiPtr m_pTapi;
	CIuMetersPtr m_pMeters;
	CIuQueriesPtr m_pQueries;
	CIuUserInterfacesPtr m_pUserInterfaces;
	CIuSplashesPtr m_pSplashes;
	CIuBlobsPtr m_pBlobs;
	CIuReleaseNotesPtr m_pReleaseNotes;
	CIuRegistrationsPtr m_pRegistrations;
	CIuReportDefsPtr m_pReportDefs;
	CIuReportersPtr m_pReporters;
	CIuSourceProviderPtr m_pSourceProvider;

	// Other data
	CIuPackRepositoryPtr m_pPackRepository;
	bool m_fConnected;
	CIuObjectRepositoryPtr m_pObjectRepository;
	bool m_fDebug;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuBlobs& CIuEngine::GetBlobs() const
{
	return m_pBlobs.Ref();
}

inline CIuMeters& CIuEngine::GetMeters() const
{
	return m_pMeters.Ref();
}

inline CIuObjectRepository& CIuEngine::GetObjectRepository() const
{
	return m_pObjectRepository.Ref();
}

inline CIuQueries& CIuEngine::GetQueries() const
{
	return m_pQueries.Ref();
}

inline CIuRegistrations& CIuEngine::GetRegistrations() const
{
	return m_pRegistrations.Ref();
}

inline CIuReleaseNotes& CIuEngine::GetReleaseNotes() const
{
	return m_pReleaseNotes.Ref();
}

inline CIuReportDefs& CIuEngine::GetReportDefs() const
{
	return m_pReportDefs.Ref();
}

inline CIuReporters& CIuEngine::GetReporters() const
{
	return m_pReporters.Ref();
}

inline CIuSourceProvider& CIuEngine::GetSourceProvider() const
{
	return m_pSourceProvider.Ref();
}

inline CIuSplashes& CIuEngine::GetSplashes() const
{
	return m_pSplashes.Ref();
}

inline CIuUserInterfaces& CIuEngine::GetUserInterfaces() const
{
	return m_pUserInterfaces.Ref();
}

inline bool CIuEngine::IsDebug() const
{
	return m_fDebug;
}

#endif // _ENGINE_ENGINE_H_
