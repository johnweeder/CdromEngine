#ifndef _ENGINE_CDROMS_H_
#define _ENGINE_CDROMS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROM_H_
#	include "Engine\Cdrom.h"
#endif	// _ENGINE_CDROM_H_
#ifndef 	_ENGINE_ALTSCANS_H_
#	include "Engine\AltScans.h"
#endif	// _ENGINE_ALTSCANS_H_
#ifndef 	_ENGINE_CDROMOTHER_H_
#	include "Engine\CdromOther.h"
#endif	// _ENGINE_CDROMOTHER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdroms)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdroms, CIuCollection }}
#define CIuCdroms_super CIuCollection

class CIuCdroms : public CIuCdroms_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdroms)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdroms();
	virtual ~CIuCdroms();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdrom& Get(const CIuMoniker& moniker) const;
	CIuCdrom& Get(LPCTSTR s) const;
	CIuCdrom& Get(int iIndex) const;
	CIuCdrom& Get(CIuID id) const;
	CIuFlags GetBuild() const;
	CIuAltScans& GetAltScans() const;
	CString GetNotify() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool IsDebug() const;
	CIuCdromOther& GetOther() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output);
	void SetBuild(CIuFlags);
	void SetDebug(bool);
	void SetNotify(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void Initialize();
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionAll(const CIuPropertyCollection&, CIuOutput&);
	CString ActionBuild(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionNone(const CIuPropertyCollection&, CIuOutput&);
	CString ActionSelectMultiple(const CIuPropertyCollection&, CIuOutput&);
	CString ActionStartBuild(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionUpdate(const CIuPropertyCollection&, CIuOutput&);
	CIuObject* GetAltScans_() const;
	CIuObject* GetOther_() const;
private:
	void CommonConstruct();
	bool BuildAll(CIuOutput& Output);
	bool Build(CIuOutput& Output, CIuFlags Flags);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fDebug;
	CString m_sNotify;
	CIuAltScansPtr m_pAltScans;
	CIuFlags m_flagsBuild;
	CIuCdromOtherPtr m_pOther;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdrom& CIuCdroms::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuCdrom*>(&CIuCollection::Get(moniker));
}

inline CIuCdrom& CIuCdroms::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuCdrom*>(&CIuCollection::Get(s));
}

inline CIuCdrom& CIuCdroms::Get(int iIndex) const
{
	return *dynamic_cast<CIuCdrom*>(&CIuCollection::Get(iIndex));
}

inline CIuCdrom& CIuCdroms::Get(CIuID id) const
{
	return *dynamic_cast<CIuCdrom*>(&CIuCollection::Get(id));
}

inline CIuAltScans& CIuCdroms::GetAltScans() const
{
	return m_pAltScans.Ref();
}

inline CIuFlags CIuCdroms::GetBuild() const
{
	return m_flagsBuild;
}

inline CString CIuCdroms::GetNotify() const
{
	return m_sNotify;
}

inline CIuCdromOther& CIuCdroms::GetOther() const
{
	return m_pOther.Ref();
}

inline bool CIuCdroms::IsDebug() const
{
	return m_fDebug;
}

#endif // _ENGINE_CDROMS_H_
