#ifndef _ENGINE_GEORAWAREACODE_H_
#define _ENGINE_GEORAWAREACODE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENT_H_
#	include "Engine\GeoRawElement.h"
#endif	// _ENGINE_GEORAWELEMENT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawAreaCode)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawAreaCode, CIuGeoRawElement }}
#define CIuGeoRawAreaCode_super CIuGeoRawElement

class CIuGeoRawAreaCode : public CIuGeoRawAreaCode_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawAreaCode)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawAreaCode();
	virtual ~CIuGeoRawAreaCode();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoRawElementAccumulator& GetState() const;
	CString GetTitle() const;
	CIuGeoRawElementAccumulator& GetZips() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
	void SetTitle(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetState_() const;
	CIuObject* GetZips_() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sTitle;
	mutable CIuGeoRawElementAccumulator m_State;
	mutable CIuGeoRawElementAccumulator m_Zips;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoRawElementAccumulator& CIuGeoRawAreaCode::GetState() const
{
	return m_State;
}

inline CString CIuGeoRawAreaCode::GetTitle() const
{
	return m_sTitle;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawAreaCode::GetZips() const
{
	return m_Zips;
}

#endif // _ENGINE_GEORAWAREACODE_H_
