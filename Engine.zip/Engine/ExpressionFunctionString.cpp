#include "StdAfx.h"
//{{Include
#include "ExpressionFunctionString.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement

// NOTE: Function names _ending_ with an underscore are considered to be "internal"
//			and should not be exposed to external customers.
//			The second part of the function name is a list of parameters

static const CIuExpressionFunctionDef adefs[] =
{
	// Functions
	// NOTE: This array should match the enum in ExpressionElement.h
	{ 
		exprNewlineDelimited,
		"NewlineDelimited\0",                   
		PFNFUNCTION(CIuExpressionFunctionString::NewlineDelimited), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionString::NewlineDelimitedMaxLength), 
		CIuExpressionFunctionString::Create
	},{ 
		exprTabDelimited,
		"TabDelimited\0",                   
		PFNFUNCTION(CIuExpressionFunctionString::TabDelimited), 0, 0,
		PFNFUNCTIONMAXLENGTH(CIuExpressionFunctionString::TabDelimitedMaxLength), 
		CIuExpressionFunctionString::Create
	},{ 
		exprUnknown, 0
	}
};
//}}Implement


CIuExpressionFunctionString::CIuExpressionFunctionString(CIuExpressionType Type) : CIuExpressionFunction(Type)
{
}

CIuExpressionFunctionString::CIuExpressionFunctionString(const CIuExpressionFunctionString& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionFunctionString::~CIuExpressionFunctionString()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionFunctionString::Clone() const
{
	CIuExpressionFunctionString* pElement = new CIuExpressionFunctionString(*this);
	ASSERT(pElement);
	return pElement;
} 

CIuExpressionFunction* CIuExpressionFunctionString::Create()
{
	return new CIuExpressionFunctionString;
}

const CIuExpressionFunctionDef* CIuExpressionFunctionString::GetFunctionDefs()
{
	return adefs;
}

bool CIuExpressionFunctionString::IsConst() const
{
	return CIuExpressionFunctionString_super::IsConst();
}

LPCTSTR CIuExpressionFunctionString::NewlineDelimited(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	int iWhich = EvaluateChildInt(1, pRecord);
	_tcstok(m_sBuffer, pcsz, iWhich, '\n');
	return m_sBuffer;
}

int CIuExpressionFunctionString::NewlineDelimitedMaxLength() const
{
	return GetChildMaxLength(0);
}

CIuExpressionFunctionString& CIuExpressionFunctionString::operator=(const CIuExpressionFunctionString& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionFunctionString_super::operator=(rExpressionElement);
	return *this;
}

CIuExpressionElement* CIuExpressionFunctionString::Optimize()
{
	// This virtual function is special in that the object being
	// called may delete itself! Be careful when doing this. If you 
	// delete yourself, do it as the last thing before exitting.
	return CIuExpressionFunctionString_super::Optimize();
}

LPCTSTR CIuExpressionFunctionString::TabDelimited(const CIuRecord* pRecord) const
{
	LPCTSTR pcsz = EvaluateChild(0, pRecord);
	int iWhich = EvaluateChildInt(1, pRecord);
	_tcstok(m_sBuffer, pcsz, iWhich, '\t');
	return m_sBuffer;
}

int CIuExpressionFunctionString::TabDelimitedMaxLength() const
{
	return GetChildMaxLength(0);
}

