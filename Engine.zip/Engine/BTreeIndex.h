#ifndef _ENGINE_BTREEINDEX_H_
#define _ENGINE_BTREEINDEX_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_DATA_H_
#	include "Data\Data.h"
#endif	// _DATA_DATA_H_
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
#ifndef 	_ENGINE_BTREEINDEXRAWSEPARATORBLOCK_H_
#	include "Engine\BTreeIndexRawSeparatorBlock.h"
#endif	// _ENGINE_BTREEINDEXRAWSEPARATORBLOCK_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeIndex)
IU_DEFINE_OBJECT_PTR(CIuBTree)
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeIndex, CIuObject }}
#define CIuBTreeIndex_super CIuObject

class CIuBTreeIndex : public CIuBTreeIndex_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeIndex)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeIndex();
	virtual ~CIuBTreeIndex();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBlocks() const;
	int GetBlockSize() const;
	CIuBTree& GetBTree() const;
	CIuObjectRepository& GetObjectRepository() const;
	int GetSeparators() const;
	int GetPointers() const;
	int GetRecords() const;
	void GetSeparator(int iKey, CIuBTreeIndexSeparator& separator) const;
	int GetSeparatorNoByKey(const CIuKey& key, CIuBTreeIndexSeparator* pSeparator = 0) const;
	int GetSeparatorNoByPointerNo(int iPointer, CIuBTreeIndexSeparator* pSeparator = 0) const;
	int GetSeparatorNoByRecordNo(int iRecord, CIuBTreeIndexSeparator* pSeparator = 0) const;
	int GetSeparatorSize() const;
	int GetTopBlockSize() const;
	CIuVersionNumber GetVersion() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool IsOpen() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(const CIuKey& key, const CIuKey& keyPrevious, int iRecordNo, int iRecordCount, int iPointerNo, int iPointerCount);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close();
	void Create(CIuOutput& Output);
	void Delete(CIuOutput* pOutput);
	void Open(bool fDebug);
	bool SanityCheck(CIuOutput& Output);
	void SetBTree(CIuBTreePtr BTree);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSeparatorSize(int);
	void SetSpec(CIuBTreeSpec&);
	void SetTopBlockSize(int);
	void SetVersion(CIuVersionNumber);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	void SetBlocks(int);
	void SetPointers(int);
	void SetRecords(int);
	void SetSeparators(int);
private:
	CString GetFilename() const;
	CString GetFullFilename() const;
	void ReadBlock(int iBlock);
	void WriteBlock();
	void WriteTop();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Back pointer to btree
	CIuBTree* m_pBTree;
	// File pointers used during creation
	CIuPrefixFilePtr m_pFile;
	CIuFileVirtualPtr m_pVFile;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	// Information used during index creation
	bool m_fAppending;
	CIuKey m_keyPrevious;
	// Caching information
	// NOTE: The top level block may be a multiple of the block
	// size. This is done to accomodate large builds like USA1 
	// which need a large top-level block.
	int m_iBlock;
	CIuBTreeIndexRawSeparatorBlock m_blockTop;
	CIuBTreeIndexRawSeparatorBlock m_block;
	CIuBuffer m_blockSeparators;
	// Persistent information
	int m_iBlocks;
	int m_iSeparators;
	int m_iRecords;
	int m_iPointers;
	CIuVersionNumber m_verVersion;
	int m_iTopBlockSize;
	int m_iSeparatorSize;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBTreeIndex::GetBlocks() const
{
	return m_iBlocks;
}

inline CIuBTree& CIuBTreeIndex::GetBTree() const
{
	ASSERT(m_pBTree!=0);
	return *m_pBTree;
}

inline CIuObjectRepository& CIuBTreeIndex::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline int CIuBTreeIndex::GetPointers() const
{
	return m_iPointers;
}

inline int CIuBTreeIndex::GetRecords() const
{
	return m_iRecords;
}

inline int CIuBTreeIndex::GetSeparators() const
{
	return m_iSeparators;
}

inline int CIuBTreeIndex::GetSeparatorSize() const
{
	return m_iSeparatorSize;
}

inline int CIuBTreeIndex::GetTopBlockSize() const
{
	return m_iTopBlockSize;
}

inline CIuVersionNumber CIuBTreeIndex::GetVersion() const
{
	return m_verVersion;
}

inline bool CIuBTreeIndex::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_BTREEINDEX_H_
