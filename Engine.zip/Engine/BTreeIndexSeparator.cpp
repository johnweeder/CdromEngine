#include "StdAfx.h"
//{{Include
#include "BTreeIndexSeparator.h"
#include "Key.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeIndexSeparator, CIuBTreeIndexSeparator_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeIndexSeparator)
//}}Implement

CIuBTreeIndexSeparator::CIuBTreeIndexSeparator() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTreeIndexSeparator::CIuBTreeIndexSeparator(const CIuBTreeIndexSeparator& rBTreeIndexSeparator)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rBTreeIndexSeparator;
}

CIuBTreeIndexSeparator::~CIuBTreeIndexSeparator()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeIndexSeparator::Clear()
{
	CIuBTreeIndexSeparator_super::Clear();
	CIuBTreeIndexSeparator::CommonConstruct();
}

void CIuBTreeIndexSeparator::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fContinuation = false;
	m_iRecordNo = 0;
	m_iPointerNo = 0;
	m_iPointerCount = 0;
	m_iRecordCount = 0;
	//}}Initialize
}

void CIuBTreeIndexSeparator::Copy(const CIuObject& object)
{
	CIuBTreeIndexSeparator_super::Copy(object);

	const CIuBTreeIndexSeparator* pBTreeIndexSeparator = dynamic_cast<const CIuBTreeIndexSeparator*>(&object);
	if (pBTreeIndexSeparator == 0 || pBTreeIndexSeparator == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuBTreeIndexSeparator)));
	
	m_fContinuation = pBTreeIndexSeparator->m_fContinuation;
	m_iRecordNo = pBTreeIndexSeparator->m_iRecordNo;
	m_iPointerNo = pBTreeIndexSeparator->m_iPointerNo;
}

void CIuBTreeIndexSeparator::CreateSeparator(const CIuKey& key, const CIuKey& keyPrevious)
{
	const BYTE* pb1 = key.GetKeyPtr();
	const BYTE* pb2 = keyPrevious.GetKeyPtr();

	int iKeySize = key.GetKeySize();
	int iPrevKeySize = keyPrevious.GetKeySize();

	ASSERT(iKeySize <=0 || iPrevKeySize <= 0 || memicmp(pb1, pb2, min(iKeySize, iPrevKeySize)) >= 0);

	for (int iPrefix = 0; iPrefix < iKeySize; ++iPrefix)
	{
		if (iPrefix >= iPrevKeySize)
		{
			++iPrefix;
			break;
		}

		ASSERT(pb1[iPrefix] >= pb2[iPrefix]);
		if (pb1[iPrefix] != pb2[iPrefix])
		{
			++iPrefix;
			break;
		}
	}

	Clear();
	// Special note: no continuation is set on consectutive "null" keys.
	// This handle the case where the first separator is created against a previous null key.
	SetContinuation(iKeySize > 0 && iKeySize == iPrevKeySize && memicmp(pb1, pb2, iKeySize) == 0);
	Append(pb1, iPrefix);
}

CIuBTreeIndexSeparator& CIuBTreeIndexSeparator::operator=(const CIuBTreeIndexSeparator& rBTreeIndexSeparator)
{
	Copy(rBTreeIndexSeparator);
	return *this;
}

void CIuBTreeIndexSeparator::SetContinuation(bool f)
{
	m_fContinuation = f;
}

void CIuBTreeIndexSeparator::SetPointerCount(int iPointerCount)
{
	ASSERT(iPointerCount >= 0);
	m_iPointerCount = iPointerCount;
}

void CIuBTreeIndexSeparator::SetPointerNo(int iPointerNo)
{
	ASSERT(iPointerNo >= 0);
	m_iPointerNo = iPointerNo;
}

void CIuBTreeIndexSeparator::SetRecordCount(int iRecordCount)
{
	ASSERT(iRecordCount >= 0);
	m_iRecordCount = iRecordCount;
}

void CIuBTreeIndexSeparator::SetRecordNo(int iRecordNo)
{
	ASSERT(iRecordNo >= 0);
	m_iRecordNo = iRecordNo;
}
