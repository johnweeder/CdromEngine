#include "StdAfx.h"
//{{Include
#include "ExpressionFunction.h"
#include "ExpressionFunctionBuild.h"
#include "ExpressionFunctionDemographics.h"
#include "ExpressionFunctionString.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif


CIuExpressionFunction::CIuExpressionFunction(CIuExpressionType Type) : CIuExpressionElement(Type)
{
#ifdef _DEBUG
	bool fFirstPass = true;
	if (fFirstPass)
	{
		fFirstPass = false;
		CStringArray as;
		GetFunctionNames(as);
		int iExpected = exprMaxFunction - exprFirstFunction;
		ASSERT(as.GetSize() == iExpected);
	}
#endif
	m_pFunctionDef = 0;
}

CIuExpressionFunction::CIuExpressionFunction(const CIuExpressionFunction& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionFunction::~CIuExpressionFunction()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionFunction::Clone() const
{
	CIuExpressionFunction* pElement = new CIuExpressionFunction(*this);
	ASSERT(pElement);
	return pElement;
} 

CIuExpressionFunction* CIuExpressionFunction::CreateFunction(LPCTSTR pcsz)
{
	const CIuExpressionFunctionDef* pFunctionDef = FindFunctionDef(pcsz);
	if (pFunctionDef == 0)
		return 0;

	ASSERT(pFunctionDef->m_pfnCreate);
	CIuExpressionFunction* pFunction = (pFunctionDef->m_pfnCreate)();
	if (pFunction == 0)
		return pFunction;

	pFunction->SetType(pFunctionDef->m_Type);

	if (pFunctionDef->m_pfnInt)
		pFunction->SetFormat(exprFormatInt);
	else if (pFunctionDef->m_pfnBool)
		pFunction->SetFormat(exprFormatBool);
	else
		pFunction->SetFormat(exprFormatString);

	pFunction->m_pFunctionDef = pFunctionDef;

	return pFunction;
}

LPCTSTR CIuExpressionFunction::Evaluate(const CIuRecord* pRecord) const
{
	if (m_pFunctionDef->m_pfn)
		return (this->*m_pFunctionDef->m_pfn)(pRecord);
	if (m_pFunctionDef->m_pfnInt)
	{
		int iValue = (this->*m_pFunctionDef->m_pfnInt)(pRecord);
		IntAsString(m_sBuffer, iValue);
		return m_sBuffer;
	}
	if (m_pFunctionDef->m_pfnBool)
	{
		bool fValue = (this->*m_pFunctionDef->m_pfnBool)(pRecord);
		if (fValue)
			return _T("1");
		else
			return _T("0");
	}
	return _T("");
}

bool CIuExpressionFunction::EvaluateBool(const CIuRecord* pRecord) const
{
	if (m_pFunctionDef->m_pfnBool)
	{
		bool fValue = (this->*m_pFunctionDef->m_pfnBool)(pRecord);
		return fValue;
	}
	if (m_pFunctionDef->m_pfnInt)
	{
		int iValue = (this->*m_pFunctionDef->m_pfnInt)(pRecord);
		return iValue != 0;
	}
	return CIuExpressionFunction_super::EvaluateBool(pRecord);
}

int CIuExpressionFunction::EvaluateInt(const CIuRecord* pRecord) const
{
	if (m_pFunctionDef->m_pfnInt)
	{
		int iValue = (this->*m_pFunctionDef->m_pfnInt)(pRecord);
		return iValue;
	}
	if (m_pFunctionDef->m_pfnBool)
	{
		bool fValue = (this->*m_pFunctionDef->m_pfnBool)(pRecord);
		return fValue ? 1: 0;
	}
	return CIuExpressionFunction_super::EvaluateInt(pRecord);
}

const CIuExpressionFunctionDef* CIuExpressionFunction::FindFunctionDef(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));

	const CIuExpressionFunctionDef* pFunctionDef = 0;
	pFunctionDef = FindFunctionDef(pcsz, CIuExpressionFunctionBuild::GetFunctionDefs());
	if (pFunctionDef)
		return pFunctionDef;
	pFunctionDef = FindFunctionDef(pcsz, CIuExpressionFunctionDemographics::GetFunctionDefs());
	if (pFunctionDef)
		return pFunctionDef;
	pFunctionDef = FindFunctionDef(pcsz, CIuExpressionFunctionString::GetFunctionDefs());
	if (pFunctionDef)
		return pFunctionDef;

	return pFunctionDef;
}

const CIuExpressionFunctionDef* CIuExpressionFunction::FindFunctionDef(LPCTSTR pcsz, const CIuExpressionFunctionDef* pFunctionDefs)
{
	ASSERT(pFunctionDefs);
	ASSERT(AfxIsValidString(pcsz));
	for (int i = 0; pFunctionDefs[i].m_pcsz; ++i)
		if (_tcsicmp(pcsz, pFunctionDefs[i].m_pcsz) == 0)
			return pFunctionDefs + i;
	return 0;
}

void CIuExpressionFunction::GetFunctionNames(CStringArray& as, bool fSyntax)
{
	as.RemoveAll();
	GetFunctionNames(as, fSyntax, CIuExpressionFunctionBuild::GetFunctionDefs());
	GetFunctionNames(as, fSyntax, CIuExpressionFunctionDemographics::GetFunctionDefs());
	GetFunctionNames(as, fSyntax, CIuExpressionFunctionString::GetFunctionDefs());
}

void CIuExpressionFunction::GetFunctionNames(CStringArray& as, bool fSyntax, const CIuExpressionFunctionDef* pFunctionDefs)
{
	CString s;
	for (int i = 0; pFunctionDefs[i].m_pcsz; ++i)
	{
		s = pFunctionDefs[i].m_pcsz;
		if (fSyntax)
		{
			s += _T("(");
			s += _tcschr(pFunctionDefs[i].m_pcsz, '\0') + 1;
			s += _T(")");
		}
		as.Add(s);
	}
}

int CIuExpressionFunction::GetMaxLength() const
{
	ASSERT(m_pFunctionDef->m_pfnMaxLength != 0);
	return (this->*m_pFunctionDef->m_pfnMaxLength)();
}

LPCTSTR CIuExpressionFunction::GetTypeName() const
{
	if (GetType() == exprFunction)
		return "#Function#";
	if (GetType() >= exprFirstFunction && GetType() < exprMaxFunction)
	{
		ASSERT(m_pFunctionDef);
		return m_pFunctionDef->m_pcsz;
	}
	return CIuExpressionFunction_super::GetTypeName();
}

bool CIuExpressionFunction::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprFunction || CIuExpressionFunction_super::IsKindOf(Type);
}

CIuExpressionFunction& CIuExpressionFunction::operator=(const CIuExpressionFunction& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionFunction_super::operator=(rExpressionElement);
	m_pFunctionDef = rExpressionElement.m_pFunctionDef;
	return *this;
}

