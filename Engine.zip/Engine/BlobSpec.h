#ifndef _ENGINE_BLOBSPEC_H_
#define _ENGINE_BLOBSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBlobSpec)
struct CIuBlobSpecDft;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBlobSpec, CIuObjectNamed }}
#define CIuBlobSpec_super CIuObjectNamed

class CIuBlobSpec : public CIuBlobSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuBlobSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBlobSpec();
	virtual ~CIuBlobSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBlobNo() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetFilename() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iBlobSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszBlob);
	void FromNo(CIuCdromSpec* pCdrom, int iBlobNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuBlobSpecDft* pBlobSpec);
	void SetBlobNo(int);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetFilename(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	CString m_sFilename;
	int m_iBlobNo;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuBlobSpec::GetBlobNo() const
{
	return m_iBlobNo;
}

inline CIuCdromSpec& CIuBlobSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuBlobSpec::GetFilename() const
{
	return m_sFilename;
}

inline bool CIuBlobSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_BLOBSPEC_H_
