#ifndef _ENGINE_FIELDNTH_H_
#define _ENGINE_FIELDNTH_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
//}}Uses

//{{Predefines
#ifndef 	_COMMON_STATICBUFFER_H_
#	include "Common\StaticBuffer.h"
#endif	// _COMMON_STATICBUFFER_H_
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldNth, CIuStaticBuffer512 }}
//	This is a help class used to manage fields in a record which contain
//		sub-fields. For example, the SIC code field can contain 'N' SIC codes
//		within a single field.
#define CIuFieldNth_super CIuStaticBuffer512

class IU_CLASS_EXPORT CIuFieldNth : public CIuFieldNth_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldNth();
	virtual ~CIuFieldNth();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	LPCTSTR GetField(int iField) const;
	int GetFields() const;
	int GetFieldSize(int iField) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetField(const CIuRecord& Record, int iField);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	int m_iFields;
	CArray<int, int> m_aiOffset;
//}}Implementation

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline LPCTSTR CIuFieldNth::GetField(int iField) const
{
	ASSERT(iField >= 0 && iField < m_iFields);
	return LPCTSTR(GetPtr(m_aiOffset[iField]));
}

inline int CIuFieldNth::GetFields() const
{
	return m_iFields;
}

inline int CIuFieldNth::GetFieldSize(int iField) const
{
	// Field size does not include null!
	ASSERT(iField >= 0 && iField < m_iFields);
	return (m_aiOffset[iField + 1] - m_aiOffset[iField]) - 1;
}

#endif // _ENGINE_FIELDNTH_H_
