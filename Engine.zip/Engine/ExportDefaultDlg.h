#ifndef _ENGINE_EXPORTDEFAULTDLG_H_
#define _ENGINE_EXPORTDEFAULTDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_

#ifndef 	_ENGINE_EXPORT_H_
#	include "Engine\Export.h"
#endif	// _ENGINE_EXPORT_H_

#ifndef 	_UI_BROWSEEDITFILE_H_
#include "UI\BrowseEditFile.h"
#endif	// _UI_BROWSEEDITFILE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportDefaultDlg, CDialog }}
#define CIuExportDefaultDlg_super CDialog

class CIuExportDefaultDlg : public CIuExportDefaultDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportDefaultDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool GetAppendFlag();
	CIuExport& GetExport() const;
	CString GetExportDef() const;
	CString GetFileName() const;
	bool GetHeaderFlag();
	int GetSelected();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetAppendFlag(bool bVal);
	static bool ExportDlg(CIuExport&, CWnd* pParent);
	void SetExportDef(const CString sExportDef);
	void SetFileName(const CString sFileName);
	void SetHeaderFlag(bool bVal);
	void SetSelected(int index);
//}}Operations

public:
	void SetDistinctArray(const CStringArray &asDistinct);
	const CStringArray& GetDistinctArray()const;
	void SetOrderByArray(const CStringArray& asOrderBy);
	const CStringArray& GetOrderByArray()const;
	void SetBought(const CString sBought);
	CString GetBought()const;
	void SetDefaultArray(const CStringArray &asDefault);
	void SetSelectedArray(const CStringArray &asSelected);
	void SetUniversalArray(const CStringArray &asUniversal);

	//{{AFX_DATA(CIuExportDefaultDlg)
	enum { IDD = IDD_ENGINE_EXPORT_DEFAULT };

	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuExportDefaultDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuExportDefaultDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnAdvanced();
	//}}AFX_MSG

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CStringArray m_asDistinct;
	CStringArray m_asOrderBy;
	CString m_sBought;
	CStringArray m_asUniversal;
	CStringArray m_asDefault;
	CStringArray m_asSelected;
	CComboBox	m_Format;
	BOOL	m_bAppend;
	BOOL	m_bHeader;
	int		m_nSelected;	
	CString m_sFormat;
	CString m_sFileName;
	CIuBrowseEditFile m_EditFilename;
	CIuExportPtr m_pExport;

	void InitializeDlgMembers();
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuExport& CIuExportDefaultDlg::GetExport() const
{
	return m_pExport.Ref();
}

#endif // _ENGINE_EXPORTDEFAULTDLG_H_
