#ifndef _ENGINE_GEO_H_
#define _ENGINE_GEO_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOSTATE_H_
#	include "Engine\GeoState.h"
#endif	// _ENGINE_GEOSTATE_H_
#ifndef 	_ENGINE_GEOZIP_H_
#	include "Engine\GeoZip.h"
#endif	// _ENGINE_GEOZIP_H_
#ifndef 	_ENGINE_GEOCOUNTY_H_
#	include "Engine\GeoCounty.h"
#endif	// _ENGINE_GEOCOUNTY_H_
#ifndef 	_ENGINE_GEOCITY_H_
#	include "Engine\GeoCity.h"
#endif	// _ENGINE_GEOCITY_H_
#ifndef 	_ENGINE_GEOMSA_H_
#	include "Engine\GeoMsa.h"
#endif	// _ENGINE_GEOMSA_H_
#ifndef 	_ENGINE_GEOAREACODE_H_
#	include "Engine\GeoAreaCode.h"
#endif	// _ENGINE_GEOAREACODE_H_
#ifndef 	_ENGINE_GEOEXCHANGE_H_
#	include "Engine\GeoExchange.h"
#endif	// _ENGINE_GEOEXCHANGE_H_
#ifndef 	_ENGINE_GEOCODEC_H_
#	include "Engine\GeoCodec.h"
#endif	// _ENGINE_GEOCODEC_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeo)
class CIuGeos;
class CIuBTreeStatistics;
class CIuGeoSpec;
class CIuCdrom;
class CIuGeoList;
class CIuRegExList;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Geography selections
const int geoAreaCode			= 0x00000001;
const int geoCity					= 0x00000002;
const int geoCounty				= 0x00000004;
const int geoMsa					= 0x00000008;
const int geoState				= 0x00000010;
const int geoZip					= 0x00000020;
const int geoExchange			= 0x00000040;

const int geoCodec				= geoAreaCode|geoCity|geoCounty|geoMsa|geoState|geoZip;
const int geoAll					= 0x0000FFFF;

/////////////////////////////////////////////////////////////////////////////
// Geo Types
enum CIuGeoNo
{
	geoNone = 0,

	geoStandard,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeo, CIuCollectable }}
#define CIuGeo_super CIuCollectable

class IU_CLASS_EXPORT CIuGeo : public CIuGeo_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeo)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeo();
	virtual ~CIuGeo();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoElementCollection& Get(int iGeoType) const;
	CIuGeoAreaCode& GetAreaCode() const;
	int GetBitsRequired() const;
	CIuGeoCity& GetCity() const;
	CIuGeoCounty& GetCounty() const;
	CString GetDatabase() const;
	CIuGeoExchange& GetExchange() const;
	CString GetFilename() const;
	bool GetGeoList(const CIuRegExList& Criteria, CString& sCriteria) const;
	void GetGeoListFilter(CIuRegExList& Criteria, CStringArray& asFilter) const;
	static LPCTSTR GetIndex();
	CIuObjectRepository& GetObjectRepository() const;
	void GetSourceDescriptorCriteria(CIuSourceDescriptorSpec& Spec) const;
	void GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const;
	CIuGeoState& GetState() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	CIuGeoZip& GetZip() const;
	CIuGeoMsa& GetMsa() const;
	bool HasObjectRepository() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close(int iFlags, bool fForce);
	void Delete(CIuOutput* pOutput = 0);
	void Decode(CIuGeoCodec& codec);
	void Encode(CIuGeoCodec& codec, CIuBTreeStatistics& Stats);
	void Open(int iFlags);
	bool Request(CString&, const CStringArray& as);
	void SetDatabase(LPCTSTR);
	void SetFilename(LPCTSTR);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuGeoSpec& Spec);
	bool Within(CString& sKeys, const CIuLatLongCoordinate& Coord1, const CIuLatLongCoordinate& Coord2) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetAreaCode_() const;
	CIuObject* GetCity_() const;
	CIuObject* GetCounty_() const;
	CIuObject* GetExchange_() const;
	CIuObject* GetMsa_() const;
	CIuObject* GetState_() const;
	CIuObject* GetZip_() const;
private:
	friend class CIuGeoElementCollection; // RequestGeo()

	bool BuildCompress(CIuCdrom& Cdrom, CIuOutput& Output);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void CommonConstruct();
	bool RequestGeo(CString& sResult, const CStringArray& as);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The name of the database owning this geo object
	CString m_sDatabase;
	// The sub-geo objects
	CIuGeoState m_State;
	CIuGeoCounty m_County;
	CIuGeoZip m_Zip;
	CIuGeoMsa m_Msa;
	CIuGeoCity m_City;
	CIuGeoAreaCode m_AreaCode;
	CIuGeoExchange m_Exchange;
	CString m_sFilename;
	// Temporary variable used during encoding
	CIuObjectRepository* m_pObjectRepository;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoAreaCode& CIuGeo::GetAreaCode() const
{
	return *const_cast<CIuGeoAreaCode*>(&m_AreaCode);
}

inline CIuGeoCity& CIuGeo::GetCity() const
{
	return *const_cast<CIuGeoCity*>(&m_City);
}

inline CIuGeoCounty& CIuGeo::GetCounty() const
{
	return *const_cast<CIuGeoCounty*>(&m_County);
}

inline CString CIuGeo::GetDatabase() const
{
	return m_sDatabase;
}

inline CIuGeoExchange& CIuGeo::GetExchange() const
{
	return *const_cast<CIuGeoExchange*>(&m_Exchange);
}

inline CString CIuGeo::GetFilename() const
{
	return m_sFilename;
}

inline CIuGeoMsa& CIuGeo::GetMsa() const
{
	return *const_cast<CIuGeoMsa*>(&m_Msa);
}

inline CIuObjectRepository& CIuGeo::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuGeoState& CIuGeo::GetState() const
{
	return *const_cast<CIuGeoState*>(&m_State);
}

inline CIuGeoZip& CIuGeo::GetZip() const
{
	return *const_cast<CIuGeoZip*>(&m_Zip);
}

inline bool CIuGeo::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_GEO_H_
