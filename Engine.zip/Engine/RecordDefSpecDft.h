#ifndef _ENGINE_RECORDDEFSPECDFT_H_
#define _ENGINE_RECORDDEFSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Default records

// Disable "zero-sized array in struct/enum" warning
#pragma warning(disable:4200)
struct CIuRecordDefSpecDft
{
public:
	static int Find(LPCTSTR pcszRecordDef);
	static int Find(int iRecordDef);
	static const CIuRecordDefSpecDft* Get(int iWhich);
	static int GetCount();

public:
	LPCTSTR m_pcszRecordDef;
	int m_iRecordDef;
	int m_iLength;
	// A null terminated array of field descriptions
	LPCTSTR m_apcszFields[];
};
#pragma warning(default:4200)


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_RECORDDEFSPECDFT_H_
