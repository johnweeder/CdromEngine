#ifndef _ENGINE_BUILDS_H_ 
#define _ENGINE_BUILDS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBuilds)
class CIuEngine;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBuilds, CIuBuilds_super }}

#define CIuBuilds_super CIuCollection

class IU_CLASS_EXPORT CIuBuilds : public CIuBuilds_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuBuilds)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBuilds();           
	virtual ~CIuBuilds();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuEngine& GetEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetEngine(CIuEngine& Engine);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

#endif // !defined(AFX_BUILDS_H__F337C0F9_4718_11D2_9310_00104B885529__INCLUDED_)
