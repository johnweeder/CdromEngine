#include "stdafx.h"
#include "ExportDefaultAdvancedDlg.h"
#include "FieldSelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIuExportDefaultAdvancedDlg dialog


CIuExportDefaultAdvancedDlg::CIuExportDefaultAdvancedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIuExportDefaultAdvancedDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuExportDefaultAdvancedDlg)
	m_sBought = _T("");
	//}}AFX_DATA_INIT
}


void CIuExportDefaultAdvancedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuExportDefaultAdvancedDlg)
	DDX_Control(pDX, IDC_ENGINE_DISTINCT, m_Distinct);
	DDX_Control(pDX, IDC_ENGINE_ORDERBY, m_OrderBy);
	DDX_Text(pDX, IDC_ENGINE_BOUGHT, m_sBought);
	DDV_MaxChars(pDX, m_sBought, 3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIuExportDefaultAdvancedDlg, CDialog)
	//{{AFX_MSG_MAP(CIuExportDefaultAdvancedDlg)
	ON_BN_CLICKED(IDC_ENGINE_DISTINCT, OnDistinct)
	ON_BN_CLICKED(IDC_ENGINE_ORDERBY, OnOrderby)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuExportDefaultAdvancedDlg message handlers

void CIuExportDefaultAdvancedDlg::OnDistinct() 
{
	if (m_asDistinct.GetSize() > 0)
		m_asDistinct.RemoveAll();

	DoFieldModal(m_asDistinct);
}

void CIuExportDefaultAdvancedDlg::OnOrderby() 
{
	if (m_asOrderBy.GetSize() > 0)
		m_asOrderBy.RemoveAll();

	DoFieldModal(m_asOrderBy);
}

void CIuExportDefaultAdvancedDlg::SetDefaultArray(const CStringArray &asDefault)
{
	if (m_asDefault.GetSize() > 0)
		m_asDefault.RemoveAll();

	m_asDefault.Copy(asDefault);
}

void CIuExportDefaultAdvancedDlg::SetSelectedArray(const CStringArray &asSelected)
{
	if (m_asSelected.GetSize() > 0)
		m_asSelected.RemoveAll();

	m_asSelected.Copy(asSelected);
}

void CIuExportDefaultAdvancedDlg::SetUniversalArray(const CStringArray &asUniversal)
{
	if (m_asUniversal.GetSize() > 0)
		m_asUniversal.RemoveAll();

	m_asUniversal.Copy(asUniversal);
}

void CIuExportDefaultAdvancedDlg::DoFieldModal(CStringArray &asSelection)
{
	CIuFieldDlg dlg(this);
	dlg.SetUniversalArray(m_asUniversal);
	dlg.SetSelectedArray(asSelection);
	dlg.SetDefaultArray(m_asDefault);

	if (IDOK == dlg.DoModal())
		dlg.GetExportFields(asSelection);
}

BOOL CIuExportDefaultAdvancedDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_asUniversal.GetSize() <= 0)
	{
		m_Distinct.EnableWindow(false);
		m_OrderBy.EnableWindow(false);
	}
	
	

	return true;  // return true unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return false
}

const CStringArray& CIuExportDefaultAdvancedDlg::GetDistinctArray() const
{
	return m_asDistinct;
}

const CStringArray& CIuExportDefaultAdvancedDlg::GetOrderByArray() const
{
	return m_asOrderBy;
}

CString CIuExportDefaultAdvancedDlg::GetBought()
{
	return m_sBought;
}

void CIuExportDefaultAdvancedDlg::SetBought(CString sBought)
{
	ASSERT(AfxIsValidString(sBought));
	m_sBought = sBought;
}

void CIuExportDefaultAdvancedDlg::OnOK() 
{
	
	
	CDialog::OnOK();
}

void CIuExportDefaultAdvancedDlg::SetOrderByArray(const CStringArray &asOrderBy)
{
	if (m_asOrderBy.GetSize() > 0)
		m_asOrderBy.RemoveAll();

	m_asOrderBy.Copy(asOrderBy);
}

void CIuExportDefaultAdvancedDlg::SetDistinctArray(const CStringArray &asDistinct)
{
	if (m_asDistinct.GetSize() > 0)
		m_asDistinct.RemoveAll();

	m_asDistinct.Copy(asDistinct);
}
