#ifndef _ENGINE_KEYLIST_H_
#define _ENGINE_KEYLIST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuKeyList)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuKeyList, CIuObject }}
#define CIuKeyList_super CIuObject

class CIuKeyList : public CIuKeyList_super
{
//{{Declare
	DECLARE_SERIAL(CIuKeyList)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuKeyList();
	virtual ~CIuKeyList();
	CIuKeyList(const CIuKeyList&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddKey(LPCTSTR);
	CString GetIndex(int iWhich) const;
	CString GetKey(int) const;
	void GetKeys(CStringArray& as) const;
	int GetKeyCount() const;
	CString GetValue(int iWhich) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
	void RemoveAllKeys();
	void RemoveKey(int);
	void SetKey(int, LPCTSTR);
	void SetKeys(const CStringArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuKeyList& operator=(const CIuKeyList&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void Extract(int iKey, CString&, CString&) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CStringArray m_asKeys;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuKeyList::GetKeyCount() const
{
	return m_asKeys.GetSize();
}

#endif // _ENGINE_KEYLIST_H_
