#ifndef _ENGINE_DEMOGRAPHICSBUSINESS_H_
#define _ENGINE_DEMOGRAPHICSBUSINESS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


IU_API_EXPORT LPCTSTR AdSizeCode(int iSize);
IU_API_EXPORT int AdSizeCount();
IU_API_EXPORT int AdSizeFromCode(TCHAR ch);
IU_API_EXPORT LPCTSTR AdSizeName(int iSize);
IU_API_EXPORT int AdSizeNameMaxLength();

IU_API_EXPORT LPCTSTR EmployeeSizeCode(int iSize);
IU_API_EXPORT int EmployeeSizeCount();
IU_API_EXPORT int EmployeeSizeFromCode(TCHAR ch);
IU_API_EXPORT LPCTSTR EmployeeSizeName(int iSize);
IU_API_EXPORT int EmployeeSizeNameMaxLength();

IU_API_EXPORT LPCTSTR SalesVolumeCode(int iSize);
IU_API_EXPORT int SalesVolumeCount();
IU_API_EXPORT int SalesVolumeFromCode(TCHAR ch);
IU_API_EXPORT LPCTSTR SalesVolumeName(int iSize);
IU_API_EXPORT int SalesVolumeNameMaxLength();

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_DEMOGRAPHICSBUSINESS_H_
