#ifndef _ENGINE_QUERYTHREAD_H_
#define _ENGINE_QUERYTHREAD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_EVENTTHREAD_H_
#	include "Data\EventThread.h"
#endif	// _DATA_EVENTTHREAD_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuQuery)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuQueryThread, CIuEventThread }}
#define CIuQueryThread_super CIuEventThread

class CIuQueryThread : public CIuQueryThread_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuQueryThread)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
protected:
	// You must create a thread using the Start() function. It will delete itself.
	CIuQueryThread();
	virtual ~CIuQueryThread();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static CIuQueryThread* Start(bool fPaused = false);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnEvent();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuQueryPtr m_pQuery;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_QUERYTHREAD_H_
