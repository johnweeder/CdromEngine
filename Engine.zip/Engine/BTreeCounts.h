#ifndef _ENGINE_BTREECOUNTS_H_
#define _ENGINE_BTREECOUNTS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeCounts }}

class CIuBTreeCounts
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeCounts(bool fHasBusRes = true);
	virtual ~CIuBTreeCounts();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Add(bool fAlt, bool fResidence, LPCTSTR pcszStateCode, LPCTSTR pcszAcPhone);
	void Clear();
	CString Output();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fHasBusRes;
	int m_iTotal;
	int m_iAlts;
	int m_iBusinesses;
	int m_iResidences;
	int m_aiAreaCode[2][1000];
	int m_aiStates[2][100];
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BTREECOUNTS_H_
