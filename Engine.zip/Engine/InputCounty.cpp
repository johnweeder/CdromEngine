#include "StdAfx.h"
//{{Include
#include "InputCounty.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputCounty, CIuInputCounty_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputCounty)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTCOUNTY, CIuInputCounty, CIuInputCounty_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputCounty, IDS_ENGINE_PPG_INPUTCOUNTY, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuInputCounty::CIuInputCounty() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputCounty::~CIuInputCounty()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputCounty::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input County"));
	SetInputFilename("PCounty.");
	SetOutputFilename("County");
	SetFormat(inputCounty);
	//}}Initialize
}

void CIuInputCounty::Delete(CIuOutput* pOutput)
{
	CIuInputCounty_super::Delete(pOutput);
	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	CdromDelete(FilenameOutput, pOutput);
}

void CIuInputCounty::OnClose()
{
	m_FileInput.Close();
	m_FileOutput.Close();
	CIuInputCounty_super::OnClose();
}

bool CIuInputCounty::OnMoveNext()
{
	if (!m_FileInput.ReadString(m_sInput))
		return false;

	if (m_sInput.GetLength() < 5)
		return true;

	m_sCountyCode = m_sInput.Mid(0, 5);
	m_sCountyCode.TrimRight();
	m_sCountyCode.MakeUpper();
	if (m_sCountyCode.GetLength() != 5)
	{
		TRACE("WARNING: Invalid County code '%s'\n", LPCTSTR(m_sCountyCode));
		return true;
	}

	m_sCountyName = m_sInput.Mid(5, 14);
	m_sCountyName.TrimRight();
	m_sCountyName.MakeUpper();
	if (m_sCountyName.IsEmpty())
		return true;

	ClearFields();
	SetField(inputFieldCountyCode, m_sCountyCode);
	SetField(inputFieldCountyName, m_sCountyName);

	return Output();
}

bool CIuInputCounty::OnOutput()
{
	// Just to be nice, we dump a text file version of the output
	m_sOutput = _T("\"");
	m_sOutput += GetField(inputFieldCountyCode);
	m_sOutput += _T("\",\"");
	m_sOutput += GetField(inputFieldCountyName);
	m_sOutput += _T("\"\n");

	m_FileOutput.WriteString(m_sOutput);

	return CIuInputCounty_super::OnOutput();
}

bool CIuInputCounty::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputCounty_super::OnOpen(OpenSpec))
		return false;

	CIuFilename FilenameInput = GetFullInputFilename();
	if (!FilenameInput.Exists())
	{
		GetOutput().OutputF(_T("*** WARNING: County master file, %s, not found\n"), LPCTSTR(FilenameInput));
		return false;
	}
	m_FileInput.Open(FilenameInput, CFile::modeRead|CFile::shareDenyNone|CFile::typeText);

	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	m_FileOutput.Open(FilenameOutput, CFile::modeCreate|CFile::modeReadWrite|CFile::shareExclusive|CFile::typeText);

	return true;
}

