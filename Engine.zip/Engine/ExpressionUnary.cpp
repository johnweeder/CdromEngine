#include "StdAfx.h"
//{{Include
#include "ExpressionUnary.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionUnary::CIuExpressionUnary(CIuExpressionType Type) : CIuExpressionElement(Type)
{
	SetFormat(exprFormatBool);
}

CIuExpressionUnary::CIuExpressionUnary(const CIuExpressionUnary& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionUnary::~CIuExpressionUnary()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionUnary::Clone() const
{
	CIuExpressionUnary* pElement = new CIuExpressionUnary(*this);
	ASSERT(pElement);
	return pElement;
} 

bool CIuExpressionUnary::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 1);
	switch (GetType())
	{
		case exprNot:
		{
			ASSERT(GetChildCount() == 1);
			return !EvaluateChildBool(0, pRecord);
		}
	}

	ASSERT(false);
	return false;
}

int CIuExpressionUnary::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionUnary::GetMaxLength() const
{
	return BooiMaxLength();
}

LPCTSTR CIuExpressionUnary::GetTypeName() const
{
	switch (GetType())
	{
		case exprUnary:
			return "#Unary Operator#";
		case exprNot:
			return "NOT";
	}
	return CIuExpressionUnary_super::GetTypeName();
}

bool CIuExpressionUnary::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprUnary || CIuExpressionUnary_super::IsKindOf(Type);
}

CIuExpressionUnary& CIuExpressionUnary::operator=(const CIuExpressionUnary& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionUnary_super::operator=(rExpressionElement);
	return *this;
}
