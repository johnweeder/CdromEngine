#ifndef _ENGINE_KEYRANGECOMPARATOR_H_
#define _ENGINE_KEYRANGECOMPARATOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
#ifndef 	_ENGINE_KEYRANGE_H_
#	include "Engine\KeyRange.h"
#endif	// _ENGINE_KEYRANGE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuKeyRangeComparator)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuKeyRangeComparator, CIuObject }}
#define CIuKeyRangeComparator_super CIuObject
class CIuKeyRangeComparator : public CIuKeyRangeComparator_super
{
//{{Declare
	DECLARE_SERIAL(CIuKeyRangeComparator)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuKeyRangeComparator();
	virtual ~CIuKeyRangeComparator();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	int Compare(CIuRecord& Record) const;
	int Compare(const CIuKey& Key) const;
	void Set(LPCTSTR pcsz, const CIuKeyDef& KeyDef);
	void Set(const CIuKeyRange& Range, const CIuKeyDef& KeyDef);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CArray<CIuKeyPtr, CIuKey*> m_aKeyLo;
	CArray<CIuKeyPtr, CIuKey*> m_aKeyHi;
	mutable CIuKey m_KeyRecord;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_KEYRANGECOMPARATOR_H_
