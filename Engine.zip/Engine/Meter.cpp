#include "stdafx.h" 
//{{Include
#include "Meter.h"
#include "Meters.h"
#include "Engine.h"
#include "Error\Error.h"
#include "resource.h"
#include "CdromSpecConst.h"
#include "MeterSpec.h"
#include "MeterHack.h"
#include "Data\Output.h"
#include "..\Version.h"
#include "IDs.h"
#include "Cdrom.h"
#include "Common\String.h"
#include "MeterAcknowledgeDlg.h"
#include "SecurityCdrom.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuMeter, CIuMeter_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuMeter)
const TCHAR szDefaultPhone[] = _T("(800) 284-8353");
const int meterMaxCache = 100;
const int iCurrentVersionNo = 1;
const	CIuVersionNumber versionMeterMax(2000,1,5,304);
const	CIuVersionNumber versionMeterMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_METER, CIuMeter, CIuMeter_super)
//{{AttributeMap
	IU_ATTRIBUTE_ACTION(CIuMeter, IDS_ENGINE_ACTION_CREATEMETERUPDATE, ActionCreateMeterUpdate, 0)

	IU_ATTRIBUTE_PAGE(CIuMeter, IDS_ENGINE_PPG_METER, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_KEY, GetKey, SetKey, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_KEY, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_GUID(CIuMeter, IDS_ENGINE_PROP_GUID1, GetGuid1, SetGuid1, 0)
	IU_ATTRIBUTE_EDITOR_GUID(CIuMeter, IDS_ENGINE_PROP_GUID1, IDS_ENGINE_PPG_METER, 0)
	IU_ATTRIBUTE_PROPERTY_GUID(CIuMeter, IDS_ENGINE_PROP_GUID2, GetGuid2, SetGuid2, 0)
	IU_ATTRIBUTE_EDITOR_GUID(CIuMeter, IDS_ENGINE_PROP_GUID2, IDS_ENGINE_PPG_METER, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_INITIALCOUNT, GetInitialCount, SetInitialCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_INITIALCOUNT, IDS_ENGINE_PPG_METER, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuMeter, IDS_ENGINE_PROP_ALLOWUPDATE, AllowUpdate, SetAllowUpdate, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuMeter, IDS_ENGINE_PROP_ALLOWUPDATE, IDS_ENGINE_PPG_METER, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_MAXOUTPUT, GetMaxOutput, SetMaxOutput, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_MAXOUTPUT, IDS_ENGINE_PPG_METER, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_EXPIREDAYS, GetExpireDays, SetExpireDays, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_EXPIREDAYS, IDS_ENGINE_PPG_METER, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_WARNINGDAYS, GetWarningDays, SetWarningDays, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_WARNINGDAYS, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_DT(CIuMeter, IDS_ENGINE_PROP_RELEASEDATE, GetReleaseDate, SetReleaseDate, 0)
	IU_ATTRIBUTE_EDITOR_DT(CIuMeter, IDS_ENGINE_PROP_RELEASEDATE, IDS_ENGINE_PPG_METER, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_WEBSITE, GetWebSite, SetWebSite, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_WEBSITE, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_PHONE, GetPhone, SetPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_PHONE, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_SPECIALACCESS, GetSpecialAccess, SetSpecialAccess, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_SPECIALACCESS, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_UPGRADECOUNT, GetUpgradeCount, SetUpgradeCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_UPGRADECOUNT, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_UPGRADELEVEL, GetUpgradeLevel, SetUpgradeLevel, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_UPGRADELEVEL, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeter, IDS_ENGINE_PROP_WARNINGTEXT, GetWarningText, SetWarningText, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeter, IDS_ENGINE_PROP_WARNINGTEXT, IDS_ENGINE_PPG_METER, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_FLAGS, GetFlags, SetFlags, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_FLAGS, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_INITIALREV, GetInitialRev, SetInitialRev, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_INITIALREV, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuMeter, IDS_ENGINE_PROP_PREVIOUS, GetPrevious, SetPrevious, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuMeter, IDS_ENGINE_PROP_PREVIOUS, IDS_ENGINE_PPG_METER, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeter, IDS_ENGINE_PROP_INITIALCOUNTUPGRADE, GetInitialCountUpgrade, SetInitialCountUpgrade, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeter, IDS_ENGINE_PROP_INITIALCOUNTUPGRADE, IDS_ENGINE_PPG_METER, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuMeter::CIuMeter()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuMeter::CIuMeter(const CIuMeter& rMeter)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rMeter;
}

CIuMeter::~CIuMeter()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
	Close(true);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuMeter::ActionCreateMeterUpdate(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	CString sName = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME), 0);
	if (sName.IsEmpty())
		Error(IU_E_MEMBER_NAME_EXPECTED);

	int iCount = Collection.GetIntOrDefault(S(IDS_ENGINE_PROP_COUNT), 1, 1000);
	if (iCount <= 0)
		iCount = 1000;

	CIuMeterUpdatePtr pMeterUpdate = CreateMeterUpdate(iCount);
	pMeterUpdate->SetName(sName);
	Output.GetDictionary().AddObject(pMeterUpdate);

	CString sResult;
	sResult.Format("Created meter update instance as '%s'\n", LPCTSTR(sName));
	return sResult;
}

bool CIuMeter::AllowUpdate() const
{
	return m_fAllowUpdate;
}

bool CIuMeter::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	// A meter is treated as an auxiliary object so it can be updated
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

bool CIuMeter::CheckAcknowledge(CWnd* pParent)
{
	if (!OpenIfNeeded())
		return true;
	if ((GetFlags() & meterFlagNoAcknowledge) != 0)
		return true;
	if (!GetValue(meterNotification, 0))
	{
		if (CIuMeterAcknowledgeDlg::DoDialog(*this, pParent))
		{
			SetValue(meterNotification, 1);
		}
		else
		{
			return false;
		}
	}

	return true;
}

void CIuMeter::Close(bool fForce)
{
	if (!IsOpen())
	{
		// Make sure security open state is also closed!
		m_fInitSecurity = false;
		return ;
	}
	if (!fForce)
	{
		if (m_iOpen > 1)
		{
			--m_iOpen;
			return ;
		}
	}

	// Make sure we have init'ed it
	ASSERT(m_fInitSecurity);
	m_fInitSecurity = false;
	m_iOpen = 0;

	// File base meter is read-only. Don't touch it
	// Do finish with the registry meter though
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	if (m_iCachedCount > 0)
		m_pSecurity->Set(DWORD(meterCount), m_pSecurity->Get(meterCount, 0, true) + m_iCachedCount, true);
	m_iCachedCount = 0;
	if (m_pSecurity->IsDirty())
		m_pSecurity->Write();
}

void CIuMeter::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iOpen = 0;
	m_fInitSecurity = false;
	m_sKey = IU_COMPANY_STRING " meter key";
	m_iInitialCount = -1;
	m_iExpireDays = -1;
	m_guid1 = GUID_NULL;
	m_guid2 = GUID_NULL;
	m_iMaxOutput = 0;
	m_fAllowUpdate = false;
	m_sWebSite = "";
	m_sPhone = szDefaultPhone;
	m_pObjectRepository = 0;
	m_iWarningDays = -1;
	m_iCachedCount = 0;
	m_dtReleaseDate = GetCurrentDay();
	m_sFilename = "";
	SetVersion(versionMeterMax);
	m_sWarningText = "";
	m_iFlags = 0;
	m_iInitialRev = 0;
	m_sSpecialAccess = "";
	// By default, we create a CDROM based security provider
	m_iMode = meterModeUnknown;
	m_iUpgradeCount = 0;
	m_iUpgradeLevel = 0;
	m_monikerPrevious.Clear();
	m_iInitialCountUpgrade = -1;
	//}}Initialize
}

void CIuMeter::Copy(const CIuObject& object)
{
	CIuMeter_super::Copy(object);

	const CIuMeter* pMeter = dynamic_cast<const CIuMeter*>(&object);
	if (pMeter == 0 || pMeter == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuMeter)));
	Close(true);
	m_pObjectRepository = pMeter->m_pObjectRepository;
	SetMode(pMeter->GetMode());
	m_sKey = pMeter->m_sKey;
	m_iInitialCount = pMeter->m_iInitialCount;
	m_iInitialCountUpgrade = pMeter->m_iInitialCountUpgrade;
	m_iExpireDays = pMeter->m_iExpireDays;
	m_iWarningDays = pMeter->m_iWarningDays;
	m_sWarningText = pMeter->m_sWarningText;
	m_guid1 = pMeter->m_guid1;
	m_guid2 = pMeter->m_guid2;
	m_iMaxOutput = pMeter->m_iMaxOutput;
	m_fAllowUpdate = pMeter->m_fAllowUpdate;
	m_sWebSite = pMeter->m_sWebSite;
	m_sPhone = pMeter->m_sPhone;
	m_dtReleaseDate = pMeter->m_dtReleaseDate;
	m_sFilename = pMeter->m_sFilename;
	m_iFlags = pMeter->m_iFlags;
	m_iInitialRev = pMeter->m_iInitialRev;
	m_sSpecialAccess = pMeter->m_sSpecialAccess;
	m_iUpgradeCount = pMeter->m_iUpgradeCount;
	m_iUpgradeLevel = pMeter->m_iUpgradeLevel;
	m_monikerPrevious = pMeter->m_monikerPrevious;
}

void CIuMeter::Corrupt()
{
	if (!OpenIfNeeded())
		return ;
	// Testing feature to "corrupt" meter
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	m_pSecurity->SetCorrupt(true);
	m_pSecurity->Write();
}

CIuMeterUpdatePtr CIuMeter::CreateMeterUpdate(int iCount) const
{
	CIuMeterUpdatePtr pMeterUpdate;
	pMeterUpdate.Create();
	pMeterUpdate->SetMeter(const_cast<CIuMeter*>(this));
	pMeterUpdate->SetCount(iCount);
	return pMeterUpdate;
}

bool CIuMeter::Decrement(int iDec)
{
	if (!OpenIfNeeded())
		return false;
	if (IsCorrupt())
		return false;

	if (iDec == 0)
		return true;

	if (iDec < 0)
	{
		SetValue(meterCount, GetValue(meterCount, 0) + (-iDec));
		SetTotal(GetTotal() + (-iDec));
		return true;
	}
	ASSERT(m_iCachedCount >= 0);
	if (iDec > m_iCachedCount)
	{
		int iNeeded = iDec - m_iCachedCount;
		int iCount = GetValue(meterCount, 0);
		if (DWORD(iCount) < DWORD(iNeeded))
		{

			m_iCachedCount = 0;
			SetValue(meterCount, 0);
			return false;
		}

		int iRequested = int(min(DWORD(iCount), DWORD(iNeeded + meterMaxCache)));

		SetValue(meterCount, GetValue(meterCount, 0) - iRequested);
		m_iCachedCount += iRequested;
	}
	ASSERT(iDec <= m_iCachedCount);
	m_iCachedCount -= iDec;
	return true;
}

bool CIuMeter::Delete() 
{
	Close(true);
	// Do not delete file based meter here
	// Not necessarily open in order to delete
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	InitSecurity();
	m_pSecurity->SetGuid(m_guid1, m_guid2);
	m_pSecurity->Delete();
	return true;
}

bool CIuMeter::Exists() const
{
	// Must be able to check existence without actually opening the meter

	// Doesn't matter whether the file based meter exists or not.
	// It is readonly anyway.
	InitSecurity();
	return m_pSecurity->Exists();
}

void CIuMeter::Flush() 
{
	if (!IsOpen())
		return ;
	// File based meter is read-only
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	if (m_pSecurity->IsDirty())
		m_pSecurity->Write();
}

int CIuMeter::GetBoughtCount() const
{
	// Get the number of records which have a non-zero bought count
	// This is not really useful at the metering level. It just tells how
	// many records have ever been bought...
	if (!OpenIfNeeded())
		return 0;
#pragma __TODO("CIuMeter::GetBoughtCount()")
	return 0;
}

int CIuMeter::GetBoughtLevel(DWORD /* dwSourceNo */, DWORD /* dwRecordNo */) const
{
	// Get the bought level for a persistently bought record 
	if (!OpenIfNeeded())
		return 0;
#pragma __TODO("CIuMeter::GetBoughtLevel(DWORD dwSourceNo, DWORD dwRecordNo)")
	return 0;
}

int CIuMeter::GetCount() const
{
	if (!OpenIfNeeded())
		return 0;
	return GetValue(meterCount, 0) + m_iCachedCount;
}

COleDateTime CIuMeter::GetCurrentDay() 
{
	COleDateTime dtCurrent = COleDateTime::GetCurrentTime();
	int iYear  = dtCurrent.GetYear();
	int iMonth = dtCurrent.GetMonth();
	int iDay	  = dtCurrent.GetDay();
	return COleDateTime(iYear, iMonth, iDay, 0, 0, 0);
}

COleDateTime CIuMeter::GetExpireDate() const
{
	return GetValue(meterExpireDate, COleDateTime());
}

COleDateTime CIuMeter::GetInstallDate() const
{
	return GetValue(meterInstallDate, GetCurrentDay());
}

COleDateTime CIuMeter::GetLastDate() const
{
	return GetValue(meterLastDate, COleDateTime());
}

COleDateTime CIuMeter::GetLastNotifyDate() const
{
	return GetValue(meterLastNotifyDate, COleDateTime());
}

CIuMeters& CIuMeter::GetMeters() const
{
	CIuMeters* pParent = dynamic_cast<CIuMeters*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CString CIuMeter::GetPhone() const
{
	return m_sPhone.IsEmpty() ? CString(szDefaultPhone): m_sPhone;
}

bool CIuMeter::GetRegistered() const
{
	return GetValue(meterRegistered, false);
}

int CIuMeter::GetRev() const
{
	return GetValue(meterRev, 0);
}

int CIuMeter::GetRemainingRuns(int iRemainingRunsDft) const
{
	return GetValue(meterRemainingRuns, iRemainingRunsDft);
}

void CIuMeter::GetStatus(CTreeCtrl& Tree) const
{
	Tree.DeleteAllItems();

	CString sTemp;
	static const TCHAR szDateFormat[] = "%B %d, %Y";

	/////////////////////////////////////////////////////////////////////////////
	// Root
	HTREEITEM hRoot = Tree.InsertItem(GetTitle(), TVI_ROOT);

	if (IsCorrupt())
		Tree.InsertItem(_T("!!! CORRUPT !!!"), hRoot);

	/////////////////////////////////////////////////////////////////////////////
	// Basic
	HTREEITEM hBasic = Tree.InsertItem("Basic", hRoot);

	sTemp.Format(_T("Name: %s"), LPCTSTR(GetName()));
	Tree.InsertItem(sTemp, hBasic);

	sTemp.Format(_T("Version: %ld"), GetVersionNo());
	Tree.InsertItem(sTemp, hBasic);

	if (GetLastDate().GetStatus() == COleDateTime::valid)
	{
		sTemp.Format(_T("Last Usage Date: %s"), LPCTSTR(GetLastDate().Format(szDateFormat)));
		Tree.InsertItem(sTemp, hBasic);
	}

	sTemp.Format(_T("Flags: %08lX"), GetFlags());
	Tree.InsertItem(sTemp, hBasic);
	sTemp.Format(_T("Special Access: %s"), GetSpecialAccess());
	Tree.InsertItem(sTemp, hBasic);
	sTemp.Format(_T("Current Revision: %d"), GetRev());
	Tree.InsertItem(sTemp, hBasic);
	sTemp.Format(_T("Initial Revision: %d"), GetInitialRev());
	Tree.InsertItem(sTemp, hBasic);

	/////////////////////////////////////////////////////////////////////////////
	// Secuity
	HTREEITEM hSecurity = Tree.InsertItem("Security", hRoot);

	CIuGuid guid1, guid2;
	GetGuid(guid1, guid2);
	sTemp.Format(_T("GUID1: %s"), LPCTSTR(guid1.AsString(guidCLSID)));
	Tree.InsertItem(sTemp, hSecurity);
	sTemp.Format(_T("GUID2: %s"), LPCTSTR(guid2.AsString(guidCLSID)));
	Tree.InsertItem(sTemp, hSecurity);

	if (!GetFilename().IsEmpty())
	{
		sTemp.Format(_T("Network filename: %s"), LPCTSTR(GetFilename()));
		Tree.InsertItem(sTemp, hSecurity);
	}

	sTemp.Format(_T("Key: %s"), LPCTSTR(GetKey()));
	Tree.InsertItem(sTemp, hSecurity);

	/////////////////////////////////////////////////////////////////////////////
	// Meter
	HTREEITEM hMeter = Tree.InsertItem("Meter", hRoot);

	if (IsMetered())
	{
		sTemp.Format(_T("Profiles: %ld"), GetCount());
		Tree.InsertItem(sTemp, hMeter);
		sTemp.Format(_T("Initial Profiles: %ld"), GetInitialCount());
		Tree.InsertItem(sTemp, hMeter);
		sTemp.Format(_T("Initial Profiles (Upgrade): %ld"), GetInitialCountUpgrade());
		Tree.InsertItem(sTemp, hMeter);
		sTemp.Format(_T("Total profiles: %ld"), GetTotal());
		Tree.InsertItem(sTemp, hMeter);
	}
	if (HasSpeedBump())
	{
		sTemp.Format(_T("Maximum Export/Report: %ld profiles"), GetMaxOutput());
		Tree.InsertItem(sTemp, hMeter);
	}

	/////////////////////////////////////////////////////////////////////////////
	// Updates
	HTREEITEM hUpdates = Tree.InsertItem("Updates", hRoot);
	if (AllowUpdate())
	{
		Tree.InsertItem(_T("Updates are allowed"), hUpdates);
		if (!GetPhone().IsEmpty())
		{
			sTemp.Format(_T("Access Code Phone: %s"), LPCTSTR(GetPhone()));
			Tree.InsertItem(sTemp, hUpdates);
		}

		if (!GetWebSite().IsEmpty())
		{
			sTemp.Format(_T("Access Code Site: %s"), LPCTSTR(GetWebSite()));
			Tree.InsertItem(sTemp, hUpdates);
		}
	}
	else
		Tree.InsertItem(_T("Updates are NOT allowed"), hUpdates);

	/////////////////////////////////////////////////////////////////////////////
	// Dates
	HTREEITEM hDates = Tree.InsertItem("Dates", hRoot);

	sTemp.Format(_T("Installed: %s"), LPCTSTR(GetInstallDate().Format(szDateFormat)));
	Tree.InsertItem(sTemp, hDates);
	if (GetReleaseDate().GetStatus() == COleDateTime::valid)
	{
		sTemp.Format(_T("Released: %s"), LPCTSTR(GetReleaseDate().Format(szDateFormat)));
		Tree.InsertItem(sTemp, hDates);
		if (GetWarningDate().GetStatus() == COleDateTime::valid)
		{
			sTemp.Format(_T("Warnings After: %s"), LPCTSTR(GetWarningDate().Format(szDateFormat)));
			Tree.InsertItem(sTemp, hDates);
			if (IsWarning())
				Tree.InsertItem(_T("\tWarnings active!"), hDates);
			CString sWarningText = GetWarningText();
			if (!sWarningText.IsEmpty())
			{
				sTemp += _T("Warning Text:");
				sWarningText.Replace(_T("\n"), _T("|"));
				sTemp += sWarningText;
				Tree.InsertItem(sTemp, hDates);
			}
		}
		if (GetExpireDate().GetStatus() == COleDateTime::valid)
		{
			sTemp.Format(_T("Expires: %s"), LPCTSTR(GetExpireDate().Format(szDateFormat)));
			Tree.InsertItem(sTemp, hDates);
			if (IsExpired())
				Tree.InsertItem(_T("\tProduct expired!"), hDates);
		}
		if (GetLastNotifyDate().GetStatus() == COleDateTime::valid)
		{
			sTemp.Format(_T("Last Notification Date: %s"), LPCTSTR(GetLastNotifyDate().Format(szDateFormat)));
			Tree.InsertItem(sTemp, hDates);
		}
	}

	/////////////////////////////////////////////////////////////////////////////
	// Registration
	HTREEITEM hRegistration = Tree.InsertItem("Registration", hRoot);

	if (GetRegistered())
		Tree.InsertItem(_T("Application is registered"), hRegistration);
	else
		Tree.InsertItem(_T("Application is not registered"), hRegistration);

	sTemp.Format(_T("Remaining Runs: %d"), GetRemainingRuns(-1));
	Tree.InsertItem(sTemp, hRegistration);

	/////////////////////////////////////////////////////////////////////////////
	// Upgrade
	HTREEITEM hUpgrade = Tree.InsertItem("Upgrade", hRoot);

	sTemp.Format(_T("Upgrade Count: %d"), GetUpgradeCount());
	Tree.InsertItem(sTemp, hUpgrade);
	sTemp.Format(_T("Upgrade Level: %d"), GetUpgradeLevel());
	Tree.InsertItem(sTemp, hUpgrade);
	sTemp.Format(_T("Upgrade Current Level: %d"), GetUpgradeCurrent());
	Tree.InsertItem(sTemp, hUpgrade);

	/////////////////////////////////////////////////////////////////////////////
	// Status
	HTREEITEM hStatus = Tree.InsertItem("Status", hRoot);

	if (GetValue(meterNetworkEnable, 0) != 0)
		Tree.InsertItem(_T("Network access is allowed"), hStatus);

	if (GetValue(meterAccessCodeEnable, 0) != 0)
		Tree.InsertItem(_T("Access code is enabled"), hStatus);

	Tree.Expand(hRoot, TVE_EXPAND);
}

int CIuMeter::GetTotal() const
{
	return GetValue(meterTotal, 0);
}

int CIuMeter::GetUpgradeCurrent() const
{
	return GetValue(meterUpgradeCurrent, GetUpgradeLevel());
}

int CIuMeter::GetUserRights() const
{
	if (!HasCollection())
		return engineRightsNone;
	return GetMeters().GetUserRights();
}

DWORD CIuMeter::GetValue(CIuMeterID id, DWORD dwDefault) const
{
	if (!OpenIfNeeded())
		return dwDefault;

	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	return m_pSecurity->Get(DWORD(id), dwDefault, true);
}

COleDateTime CIuMeter::GetValue(CIuMeterID id, COleDateTime dtDefault) const
{
	int iYear  = dtDefault.GetYear();
	int iMonth = dtDefault.GetMonth();
	int iDay	  = dtDefault.GetDay();
	DWORD dwDefault;
	if (dtDefault.GetStatus() != COleDateTime::valid || iYear < 0 || iMonth < 0 || iDay < 0 || (iYear == 1899 && iMonth == 12 && iDay == 30))
		dwDefault = 0xFFFFFFFF;
	else
		dwDefault = (DWORD(iYear) << 16) | (DWORD(iMonth) << 8) | DWORD(iDay);

	COleDateTime dt;

	DWORD dw = GetValue(id, dwDefault);
	if (dw == 0xFFFFFFFF)
		dt.SetStatus(COleDateTime::null);
	else
	{
		iYear = int(dw >> 16);
		iMonth = int((dw >> 8) & 0xff);
		iDay = int(dw & 0xff);

		if (iYear < 0 || iMonth < 0 || iDay < 0 || (iYear == 1899 && iMonth == 12 && iDay == 30))
			dt.SetStatus(COleDateTime::null);
		else
			dt = COleDateTime(iYear, iMonth, iDay, 0, 0, 0);
	}
	return dt;
}

CIuVersionNumber CIuMeter::GetVersionMax() const
{
	return versionMeterMax;
}

CIuVersionNumber CIuMeter::GetVersionMaxStatic()
{
	return versionMeterMax;
}

CIuVersionNumber CIuMeter::GetVersionMin() const
{
	return versionMeterMin;
}

CIuVersionNumber CIuMeter::GetVersionMinStatic()
{
	return versionMeterMin;
}

int CIuMeter::GetVersionNo() const
{
	return GetValue(meterVersion, 0);
}

inline COleDateTime CIuMeter::GetWarningDate() const
{
	return GetValue(meterWarningDate, COleDateTime());
}

inline int CIuMeter::GetWarningDays() const
{
	return m_iWarningDays;
}

CString CIuMeter::GetWebSite() const
{
	return m_sWebSite;
}

void CIuMeter::Hack(bool fNew) 
{
	// The ugly hack code is maintained in a separate module
	MeterHack(*this, fNew);
}

bool CIuMeter::HasSpeedBump() const
{
	return GetMaxOutput() > 0;
}

void CIuMeter::InitSecurity() const
{
	// Security file can be opened independently of the meter.
	// We might not want to set initial counts, expire data, etc...
	if (m_fInitSecurity)
		return ;

	m_fInitSecurity = true;

	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	m_pSecurity->Clear();
	m_pSecurity->SetMoniker(GetMoniker());
	m_pSecurity->SetGuid(m_guid1, m_guid2);
	m_pSecurity->SetFilename(GetFilename());
	m_pSecurity->SetTitle(GetTitle());
	m_pSecurity->SetKey(GetKey());
}

bool CIuMeter::IsCorrupt() const
{
	if (!OpenIfNeeded())
		return true;
	// Ignore file base meter status.
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	return m_pSecurity->IsCorrupt();
}

bool CIuMeter::IsExpired() const
{
	if (IsCorrupt())
		return true;

	COleDateTime dtExpired = GetExpireDate();  
	if (dtExpired.GetStatus() != COleDateTime::valid)
		return false;

	COleDateTime dtLast = GetValue(meterLastDate, COleDateTime());
	if (dtLast.GetStatus() != COleDateTime::valid)
		return true;

	COleDateTime dtCurrent = GetCurrentDay();
	if (dtLast > dtCurrent)
		dtCurrent = dtLast;
	else
		const_cast<CIuMeter*>(this)->SetValue(meterLastDate, dtCurrent);

	return dtCurrent > dtExpired;
}

bool CIuMeter::IsMetered() const
{
	return GetInitialCount() > 0;
}

bool CIuMeter::IsWarning() const
{
	if (IsCorrupt())
		return true;

	COleDateTime dt = GetWarningDate();
	if (dt.GetStatus() != COleDateTime::valid)
		return false;

	COleDateTime dtLast = GetValue(meterLastDate, COleDateTime());
	if (dtLast.GetStatus() != COleDateTime::valid)
		return true;

	COleDateTime dtCurrent = GetCurrentDay();
	if (dtLast > dtCurrent)
		dtCurrent = dtLast;
	else
		const_cast<CIuMeter*>(this)->SetValue(meterLastDate, dtCurrent);

	return dtCurrent > dt;
}

void CIuMeter::Migrate()
{
	ASSERT(IsOpen());
	CIuID idPrevious = GetPrevious().GetID();
	if (idPrevious.IsInvalid())
		return ;
	int iMeter = GetMeters().Find(idPrevious);
	if (iMeter < 0)
		return ;
	// Be careful, do not cause the meter to initialize...
	// If the user did not actually have the old product, that would
	//	 give him a full set of credits which would then be migrated.
	CIuMeter& Previous = GetMeters().Get(iMeter);
	if (!Previous.Exists())
		return ;
	int iCurrent = GetCount();
	int iPreviousCount = Previous.GetCount();
	SetCount(iCurrent + iPreviousCount);
	Previous.SetCount(0, true);

	if (Previous.GetValue(meterNetworkEnable, 0) != 0)
		SetValue(meterNetworkEnable, Previous.GetValue(meterNetworkEnable, 0));

	if (Previous.GetValue(meterAccessCodeEnable, 0) != 0)
		SetValue(meterAccessCodeEnable, Previous.GetValue(meterAccessCodeEnable, 0));

	Previous.Flush();
	Flush();
}


void CIuMeter::Open()
{
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}

	bool fNew = false;

	m_iOpen = 1;

	InitSecurity();

	COleDateTime dtNull;
	dtNull.SetStatus(COleDateTime::null);	  
	COleDateTime dtCurrent = GetCurrentDay();

	if (m_pSecurity->Exists())
	{
		// Probably a corrupt meter... get out of dodge
		if (!m_pSecurity->Read())
			return ;

		// Sometimes a meter changes during the year
		// In that case, we may need to update it to the new settings.
		if (GetExpireDays() > 0)
		{
			COleDateTime dtExpire = GetExpireDate();
			if (dtExpire.m_status != COleDateTime::valid)
				SetExpireDate(dtCurrent + COleDateTimeSpan(GetExpireDays(), 0, 0, 0));
		}
		else
			SetExpireDate(dtNull);

		if (GetWarningDays() > 0)
		{
			COleDateTime dtWarning = GetWarningDate();
			if (dtWarning.m_status != COleDateTime::valid)
				SetWarningDate(dtCurrent + COleDateTimeSpan(GetWarningDays(), 0, 0, 0));
		}
		else
			SetWarningDate(dtNull);
	}
	else
	{
		fNew = true;

		// New meter, set it up
		SetVersionNo(iCurrentVersionNo);
		SetRev(GetInitialRev());

		if (GetInitialCount() > 0)
		{
			if (PreviousExists() && GetInitialCountUpgrade() > 0)
			{
				SetValue(meterTotal,	GetInitialCountUpgrade());
				SetValue(meterCount,	GetInitialCountUpgrade());
			}
			else
			{
				SetValue(meterTotal,	GetInitialCount());
				SetValue(meterCount,	GetInitialCount());
			}
		}
		else
		{
			SetValue(meterTotal,	0);
			SetValue(meterCount,	0);
		}

		SetInstallDate(dtCurrent);
		SetValue(meterLastNotifyDate, dtNull);

		COleDateTime dtStart = dtCurrent;
		if (GetReleaseDate().GetStatus() == COleDateTime::valid)
			dtStart = GetReleaseDate();

		if (GetExpireDays() > 0)
			SetExpireDate(dtStart + COleDateTimeSpan(GetExpireDays(), 0, 0, 0));
		else
			SetExpireDate(dtNull);

		if (GetWarningDays() > 0)
			SetWarningDate(dtStart + COleDateTimeSpan(GetWarningDays(), 0, 0, 0));
		else
			SetWarningDate(dtNull);
	}
	
	// Always check for a newer release date
	if (GetReleaseDate().GetStatus() == COleDateTime::valid)
	{
		if (GetExpireDays() > 0)
		{
			COleDateTime dtExpire = GetReleaseDate() + COleDateTimeSpan(GetExpireDays(), 0, 0, 0);
			if (GetExpireDate().GetStatus() != COleDateTime::valid || dtExpire > GetExpireDate())
				SetExpireDate(dtExpire);
		}
		if (GetWarningDays() > 0)
		{
			COleDateTime dtWarning = GetReleaseDate() + COleDateTimeSpan(GetWarningDays(), 0, 0, 0);
			if (GetWarningDate().GetStatus() != COleDateTime::valid || dtWarning > GetWarningDate())
				SetWarningDate(dtWarning);
		}
	}

	COleDateTime dtLast = GetValue(meterLastDate, dtCurrent);
	if (dtLast.GetStatus() != COleDateTime::valid || GetCurrentDay() > dtLast)
		SetValue(meterLastDate, dtCurrent);

	// Migrate if a new meter
	if (fNew)
		Migrate();

	// Upgrade if new level
	Upgrade();

	// Deal with the hacks...  propogating legacy meters, etc
	Hack(fNew);
}

bool CIuMeter::OpenIfNeeded() const
{
	if (m_iOpen > 0)
		return true;
	const_cast<CIuMeter*>(this)->Open();
	return IsOpen();
}

bool CIuMeter::PreviousExists() const
{
	ASSERT(IsOpen());
	CIuID idPrevious = GetPrevious().GetID();
	if (idPrevious.IsInvalid())
		return false;
	int iMeter = GetMeters().Find(idPrevious);
	if (iMeter < 0)
		return false;
	// Be careful, do not cause the meter to initialize...
	// If the user did not actually have the old product, that would
	//	 give him a full set of credits which would then be migrated.
	CIuMeter& Previous = GetMeters().Get(iMeter);
	return Previous.Exists();
}

CIuMeter& CIuMeter::operator=(const CIuMeter& rMeter)
{
	Copy(rMeter);
	return *this;
}

void CIuMeter::Refresh()
{
	if (m_iOpen > 0)
	{
		// ONLY yf open, attempt to re-read the network based meter file
		ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
		m_pSecurity->Refresh();
	}
}

bool CIuMeter::Reset()
{
	Close(true);
	// Do _not_ touch the file meter, it is read only
	// Clear a corrupt meter
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	InitSecurity();
	m_pSecurity->Reset();
	// Leave closed... it will open automatically when needed
	return true;
}

void CIuMeter::SetAllowUpdate(bool f)
{
	m_fAllowUpdate = f;
}

bool CIuMeter::SetBoughtLevel(DWORD /* dwSourceNo */, DWORD /* dwRecordNo */, int /* iBoughtLevel */, bool /* fDecrement */, bool* /* pfNewBuy */)
{
	// Set the bought level for a persistently bought record
	// Return true if able to purchase record
	// Return false if unable to buy record
	if (!OpenIfNeeded())
		return false;
#pragma __TODO("CIuMeter::SetBoughtLevel(DWORD dwSourceNo, DWORD dwRecordNo, int iBoughtLevel, bool fDecrement, bool* pfNewBuy)")
#if 0
	int iPreviousLevel = GetBoughtLevel(dwSourceNo, dwRecordNo);
	if (lPreviousLevel < iBoughtLevel)
	{
		// If we are importing an already bought record, we might not decrement the count
		if (fDecrement && !Decrement(iBoughtLevel - lPreviousLevel))
			return false;
		SetBoughtLevel(dwSourceNo, dwRecordNo, iBoughtLevel);
	}
	if (pfNewBuy)
		*pfNewBuy = iBoughtLevel > 0 && lPreviousLevel == 0;
#endif
	return true;
}

void CIuMeter::SetCount(int iCount, bool fClearCache)
{
	if (fClearCache)
		m_iCachedCount = 0;
	SetValue(meterCount, iCount);
}

void CIuMeter::SetExpireDate(const COleDateTime& dt)
{
	SetValue(meterExpireDate, dt);
}

void CIuMeter::SetExpireDate(int iAdditionalDays)
{
	ASSERT(iAdditionalDays >= 1);

	COleDateTime dtCurrent = COleDateTime::GetCurrentTime();
	int iYear  = dtCurrent.GetYear();
	int iMonth = dtCurrent.GetMonth();
	int iDay	  = dtCurrent.GetDay();

	COleDateTime dtAdditional = COleDateTime(iYear, iMonth, iDay, 0, 0, 0) + COleDateTimeSpan(iAdditionalDays, 0, 0, 0);
	SetExpireDate(dtAdditional);
}

void CIuMeter::SetExpireDays(int iExpireDays)
{
	m_iExpireDays = iExpireDays;
}

void CIuMeter::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuMeter::SetFlags(int iFlags)
{
	m_iFlags = iFlags;
}

void CIuMeter::SetGuid1(const CIuGuid& guid)
{
	m_guid1 = guid;	
}

void CIuMeter::SetGuid2(const CIuGuid& guid)
{
	m_guid2 = guid;	
}

void CIuMeter::SetInitialCount(int iInitialCount)
{
	m_iInitialCount = iInitialCount;
}

void CIuMeter::SetInitialCountUpgrade(int iInitialCountUpgrade)
{
	m_iInitialCountUpgrade = iInitialCountUpgrade;
}

void CIuMeter::SetInitialRev(int iInitialRev)
{
	m_iInitialRev = iInitialRev;
}

void CIuMeter::SetInstallDate(const COleDateTime& dt)
{
	SetValue(meterInstallDate, dt);
}

void CIuMeter::SetKey(LPCTSTR pcszKey)
{
	ASSERT(AfxIsValidString(pcszKey));
	ASSERT(!_tcsisempty(pcszKey));
	m_sKey = pcszKey;
}

void CIuMeter::SetLastDate(const COleDateTime& dt)
{
	SetValue(meterLastDate, dt);
}

void CIuMeter::SetLastNotifyDate()
{
	COleDateTime dt = GetCurrentDay();
	SetLastNotifyDate(dt);
}

void CIuMeter::SetLastNotifyDate(const COleDateTime& dt)
{
	SetValue(meterLastNotifyDate, dt);
}

void CIuMeter::SetMaxOutput(int iMaxOutput)
{
	m_iMaxOutput = iMaxOutput;
}

void CIuMeter::SetMode(int iMode)
{
	m_iMode = iMode;
	switch (m_iMode)
	{
		default:
			// Create a dummy meter just so things keep working
			m_pSecurity.Create();
			break;
		case meterModeCdrom:
		{
			CIuSecurityCdromPtr pSecurityCdrom;
			pSecurityCdrom.Create();
			m_pSecurity = pSecurityCdrom;
			break;
		}
		case meterModeMemory:
		{
			m_pSecurity.Create();
			break;
		}
	}
}

void CIuMeter::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuMeter::SetPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPhone = pcsz;
}

void CIuMeter::SetPrevious(const CIuMoniker& moniker)
{
	m_monikerPrevious = moniker;
}

void CIuMeter::SetRegistered(bool fRegistered)
{
	SetValue(meterRegistered, fRegistered);
}

void CIuMeter::SetReleaseDate(const COleDateTime& dt)
{
	m_dtReleaseDate = dt;
}

void CIuMeter::SetRev(int iRev)
{
	SetValue(meterRev, iRev);
}

void CIuMeter::SetRemainingRuns(int iRemainingRuns)
{
	SetValue(meterRemainingRuns, iRemainingRuns);
}

void CIuMeter::SetSpec(CIuMeterSpec& MeterSpec)
{
	SetName(MeterSpec.GetName());
	SetID(MeterSpec.GetID());
	SetTitle(MeterSpec.GetTitle());

	SetGuid1(MeterSpec.GetGuid1());
	SetGuid2(MeterSpec.GetGuid2());
	SetAllowUpdate(MeterSpec.AllowUpdate());
	SetInitialCount(MeterSpec.GetInitialCount());
	SetInitialCountUpgrade(MeterSpec.GetInitialCountUpgrade());
	SetMaxOutput(MeterSpec.GetMaxOutput());
	SetExpireDays(MeterSpec.GetExpireDays());
	SetWarningDays(MeterSpec.GetWarningDays());
	SetWarningText(MeterSpec.GetWarningText());
	SetReleaseDate(MeterSpec.GetReleaseDate());
	SetPhone(MeterSpec.GetPhone());
	SetWebSite(MeterSpec.GetWebSite());
	SetKey(MeterSpec.GetKey());
	SetTitle(MeterSpec.GetTitle());
	SetFilename(MeterSpec.GetFilename());
	SetFlags(MeterSpec.GetFlags());
	SetInitialRev(MeterSpec.GetInitialRev());
	SetSpecialAccess(MeterSpec.GetSpecialAccess());
	SetUpgradeLevel(MeterSpec.GetUpgradeLevel());
	SetUpgradeCount(MeterSpec.GetUpgradeCount());
	SetPrevious(MeterSpec.GetPrevious());
}

void CIuMeter::SetSpecialAccess(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSpecialAccess = pcsz;
}

void CIuMeter::SetTotal(int iTotal)
{
	SetValue(meterTotal, iTotal);
}

void CIuMeter::SetUpgradeCount(int iUpgradeCount)
{
	m_iUpgradeCount = iUpgradeCount;
}

void CIuMeter::SetUpgradeCurrent(int iUpgradeCurrent)
{
	SetValue(meterUpgradeCurrent, iUpgradeCurrent);
}

void CIuMeter::SetUpgradeLevel(int iUpgradeLevel)
{
	m_iUpgradeLevel = iUpgradeLevel;
}

void CIuMeter::SetValue(CIuMeterID id, DWORD dwValue)
{
	if (!OpenIfNeeded())
		return ;

	// Can't set file based meter here. Only in NetAdmin utility
	ASSERT(GetMode() != meterModeUnknown && m_pSecurity.NotNull());
	m_pSecurity->Set(DWORD(id), dwValue, true);
}

void CIuMeter::SetValue(CIuMeterID id, const COleDateTime& dt)
{
	int iYear  = dt.GetYear();
	int iMonth = dt.GetMonth();
	int iDay	  = dt.GetDay();
	DWORD dwValue;
	if (dt.GetStatus() != COleDateTime::valid || iYear < 0 || iMonth < 0 || iDay < 0 || (iYear == 1899 && iMonth == 12 && iDay == 30))
		dwValue = 0xFFFFFFFF;
	else
		dwValue = (DWORD(iYear) << 16) | (DWORD(iMonth) << 8) | DWORD(iDay);
	
	SetValue(id, dwValue);
}

void CIuMeter::SetVersionNo(int iVersionNo)
{
	SetValue(meterVersion, iVersionNo);
}

void CIuMeter::SetWarningDate(const COleDateTime& dt)
{
	SetValue(meterWarningDate, dt);
}

void CIuMeter::SetWarningDays(int iWarningDays)
{
	m_iWarningDays = iWarningDays;
}

void CIuMeter::SetWarningText(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sWarningText = pcsz;
}

void CIuMeter::SetWebSite(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sWebSite = pcsz;
}

bool CIuMeter::ShouldNotify() const
{
	COleDateTime dtLast = GetLastNotifyDate();
	if (dtLast.GetStatus() != COleDateTime::valid)
		return true;
	if ((GetFlags() & meterFlagNotifyAlways) != 0)
		return true;
	COleDateTime dtToday = GetCurrentDay();
	return dtToday > GetLastNotifyDate();
}

void CIuMeter::Upgrade()
{
	ASSERT(IsOpen());
	if (GetUpgradeLevel() <= GetUpgradeCurrent())
		return ;
	SetCount(GetCount() + GetUpgradeCount());
	SetUpgradeCurrent(GetUpgradeLevel());
	Flush();
}
