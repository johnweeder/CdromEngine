#ifndef _ENGINE_EXPRESSIONELEMENT_H_
#define _ENGINE_EXPRESSIONELEMENT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_SMARTPTR_H_
#	include "Common\SmartPtr.h"
#endif	// _COMMON_SMARTPTR_H_
#ifndef 	_COMMON_OPTIONS_H_
#	include "Common\Options.h"
#endif	// _COMMON_OPTIONS_H_
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
#ifndef 	_ENGINE_RESOLVESPEC_H_
#	include "Engine\ResolveSpec.h"
#endif	// _ENGINE_RESOLVESPEC_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

class CIuExpressionElement;
typedef CIuSmartPtr<CIuExpressionElement> CIuExpressionElementPtr;
typedef CList<CIuExpressionElement*, CIuExpressionElement*> CIuExpressionList;
typedef CArray<CIuExpressionElement*, CIuExpressionElement*> CIuExpressionArray;

enum CIuExpressionFormat
{
	// The default format for an expression. This controls both evaluation
	// and affects the performance. By default, the expression format is a string.
	exprFormatString,
	exprFormatBool,
	exprFormatInt,
};

enum CIuExpressionType
{
	// Start with a very large negative number so that values always go up but are less than 0.
	// *** NOTE ***
	// The array "atypes", in the source module, must match this enumeration
	exprUnknown = -20000,

	exprFieldLiteral = -19000,
		exprOption,	// Resolved from option value
		// These are special fields which are synthesized for each record
		exprFieldFirst,
		exprKey = exprFieldFirst,	// Resolved from key value
		exprAlt,
		exprSeeAlso,
		exprRecordNo,
		exprSourceNo,
		exprExpandNo,
		exprCount,
		exprLatitude,
		exprLongitude,
		exprTagged,
		exprBought,
		exprNoMail,
		exprNoPhone,
		exprResidence,
		exprBusiness,
		exprBusResFlag,
		exprFieldLast,

	exprStringLiteral = -18000,

	exprUnary = -17000,
		exprNot,

	exprBinary = -16000,
		exprConcatenation,
		exprDivide,
		exprMultiply,
		exprMinus,
		exprPlus,

	exprBool = -15000,
		exprAnd,
		exprOr,

	exprCompare = -14000,
		exprEqual,
		exprNotEqual,
		exprGreaterThan,
		exprGreaterThanOrEqual,
		exprLessThan,
		exprLessThanOrEqual,

	exprFunction = -13000,
		// NOTE: These function should match up with the array in ExpressionFunction.cpp
		exprFirstFunction,
		exprAdSizeName = exprFirstFunction,
		exprBuildAcPhone,
		exprBuildPriNo,
		exprBuildSecNo,
		exprBuildStreet,
		exprCompareFunction, // using exprCompareFunction, exprCompare already used
		exprCompareNoCase,
		exprCRLF,
		exprDefVal,
		exprEmployeeSizeName,
		exprExtractNamePart,
		exprFirstName,
		exprFlipName,
		exprHyphenatePhone,
		exprHyphenateZIP,
		exprIff,
		exprLastName,
		exprLatLongDistance,
		exprLeft,
		exprLen,
		exprLookup,
		exprMakeAddress,
		exprMakeCityState,
		exprMakeLastLine,
		exprMakeLower,
		exprMakeName,
		exprMakeNameInitials,
		exprMakePhone,
		exprMakeStreet,
		exprMakeUpper,
		exprMakeZip,
		exprMid,
		exprNewline,
		exprNewlineDelimited,
		exprPaste,
		exprPasteSpace,
		exprRepeat,
		exprRight,
		exprSalesVolumeName,
		exprSortZIP9First,
		exprSpace,
		exprStateAbbr2Code,
		exprStateCode2Abbr,
		exprSurround,
		exprTab,
		exprTabDelimited,
		exprTAPIPhone,
		exprThousands,
		exprTrim,
		exprTrimLeft,
		exprTrimRight,

		exprMaxFunction,

	exprLike = -12000,

	exprMatches = -11000,
		exprMatchesFirst,
		exprMatchesFirstInitial,
		exprMatchesLast,
		exprMatchesCity,

	exprSoundsLike = -10000,

	exprContains = -9000,
		exprContainsWord,

	// Special compiler intermediate tokens.
	exprSpecial = -1000,
		exprArg,
		exprArgList,
		exprCloseParen,
		exprComma,
		exprExpression, // An evaluated expression....
		exprOpenParen,

	exprMax
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionElement }}
class CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionElement(CIuExpressionType Type = exprUnknown);
	CIuExpressionElement(const CIuExpressionElement& rExpressionElement);
	virtual ~CIuExpressionElement();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetBoughtLevel() const;
	int GetCaseConvert() const;
	CIuExpressionFormat GetFormat() const;
	static void GetOperatorNames(CStringArray& as);
	virtual int GetMaxLength() const;
	CIuObjectRepository& GetRepository() const;
	CIuExpressionType GetType() const;
	virtual LPCTSTR GetTypeName() const;
	bool HasRepository() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual void Dump(int iLevel = 0, bool fDeep = true) const;
	virtual LPCTSTR Evaluate(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	static CIuExpressionElement* Parse(LPCTSTR pcsz);
	virtual void Resolve(CIuResolveSpec& Spec);
	void SetCaseConvert(int iCaseConvert);
	void SetFormat(CIuExpressionFormat Format);
	void SetType(CIuExpressionType iType);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionElement& operator=(const CIuExpressionElement& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	int BooiMaxLength() const;
	int NumericMaxLength() const;
protected:
	friend class CIuExpression;

	CIuExpressionElement* DetachChild(int iChild);
	LPCTSTR EvaluateChild(int iChild, const CIuRecord*) const;
	int EvaluateChildInt(int iChild, const CIuRecord*) const;
	bool EvaluateChildBool(int iChild, const CIuRecord*) const;
	CIuExpressionElement& GetChild(int iChild) const;
	int GetChildCount() const;
	CIuExpressionFormat GetChildFormat(int iChild) const;
	int GetChildMaxLength(int iChild) const;
	int GetChildMaxLength(int iChild0, int iChild1) const;
	bool IsChildConst(int iChild) const;
	virtual CIuExpressionElement* Optimize();

private:
	void AddChild(CIuExpressionElement* pExpressionElement);
	void CommonConstruct();
	static void ConvertToExpression(CIuExpressionArray& Array, int iToken);
	static bool IsA(CIuExpressionArray& Array, int i, CIuExpressionType Type);
	void InsertChild(int iIndex, CIuExpressionElement* pExpressionElement);
	static void MakeChild(CIuExpressionArray& Array, int iParent, int iChild1, int iChild2 = -1);
	static CIuExpressionElement* ParseField(LPCTSTR& pcsz);
	static CIuExpressionElement* ParseIdentifier(LPCTSTR& pcsz);
	static CIuExpressionElement* ParseNumeric(LPCTSTR& pcsz);
	static CIuExpressionElement* ParseOperator(LPCTSTR& pcsz);
	static CIuExpressionElement* ParseStringLiteral(LPCTSTR& pcsz);
	static void ParseTokens(LPCTSTR pcsz, CIuExpressionArray& list);
	static CIuExpressionElement* Reduce(LPCTSTR pcsz, CIuExpressionArray& Array);
	static bool ReduceArg(CIuExpressionArray& Array);
	static bool ReduceArgList(CIuExpressionArray& Array);
	static bool ReduceBool(CIuExpressionArray& Array);
	static CIuExpressionElement* ReduceCommutative(CIuExpressionElement* pExpression);
	static bool ReduceCompare(CIuExpressionArray& Array);
	static bool ReduceConcat(CIuExpressionArray& Array);
	static CIuExpressionElement* ReduceExpressions(CIuExpressionElement* pExpression);
	static bool ReduceFunction(CIuExpressionArray& Array);
	static bool ReduceLiteral(CIuExpressionArray& Array);
	static bool ReduceParen(CIuExpressionArray& Array);
	static bool ReduceMultDiv(CIuExpressionArray& Array);
	static bool ReducePlusMinus(CIuExpressionArray& Array);
	static bool ReduceSpecial(CIuExpressionArray& Array);
	static bool ReduceUnary(CIuExpressionArray& Array);
	void RemoveAllChildren();
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	// A buffer for use in storing a string-type return value
	mutable CString m_sBuffer;
private:
	CIuExpressionArray m_array;
	CIuExpressionType m_Type;
	CIuExpressionFormat m_Format;
	int m_iCaseConvert;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
//}}Data
};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuExpressionElement::GetCaseConvert() const
{
	return m_iCaseConvert;
}

inline CIuExpressionElement& CIuExpressionElement::GetChild(int iChild) const
{
	ASSERT(iChild >= 0 && iChild < GetChildCount());
	// Don't use the m_array[] syntax because it actually performs a copy.
	// This method directly accesses the elements in the array.
	return *const_cast<CIuExpressionElement*>(m_array[iChild]);
}

inline int CIuExpressionElement::GetChildCount() const
{
	return m_array.GetSize();
}

inline CIuExpressionFormat CIuExpressionElement::GetFormat() const
{
	return m_Format;
}

inline CIuObjectRepository& CIuExpressionElement::GetRepository() const
{
	ASSERT(HasRepository());
	return *m_pObjectRepository;
}

inline CIuExpressionType CIuExpressionElement::GetType() const
{
	return m_Type;
}

inline bool CIuExpressionElement::HasRepository() const
{
	return m_pObjectRepository != 0;
}

#endif // _ENGINE_EXPRESSIONELEMENT_H_
