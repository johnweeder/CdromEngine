#ifndef _ENGINE_BTREES_H_
#define _ENGINE_BTREES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_BTREE_H_
#	include "Engine\BTree.h"
#endif	// _ENGINE_BTREE_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTrees)
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTrees, CIuCollection }}
#define CIuBTrees_super CIuCollection

class CIuBTrees : public CIuBTrees_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTrees)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTrees();
	virtual ~CIuBTrees();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuBTree& Get(LPCTSTR s) const;
	CIuBTree& Get(int iIndex) const;
	CIuBTree& Get(CIuID id) const;
	CIuPackRepository& GetRepository() const;
	bool HasRepository() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void CreateBTree(CIuBTreeSpec& BTreeSpec);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuBTree& CIuBTrees::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuBTree*>(&CIuCollection::Get(s));
}

inline CIuBTree& CIuBTrees::Get(int iIndex) const
{
	return *dynamic_cast<CIuBTree*>(&CIuCollection::Get(iIndex));
}

inline CIuBTree& CIuBTrees::Get(CIuID id) const
{
	return *dynamic_cast<CIuBTree*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_BTREES_H_
