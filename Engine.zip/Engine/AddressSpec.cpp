#include "StdAfx.h"
//{{Include
#include "AddressSpec.h"
#include "AddressSpecDft.h"
#include "resource.h"
#include "Address.h"
#include "FieldMap.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddressSpec, CIuAddressSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddressSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESSSPEC, CIuAddressSpec, CIuAddressSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddressSpec, IDS_ENGINE_PPG_ADDRESSSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_PRINO, GetPriNo, SetPriNo, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_PRINO, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_PREDIR, GetPreDir, SetPreDir, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_PREDIR, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_STREETNAME, GetStreetName, SetStreetName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_STREETNAME, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_SUFFIX, GetSuffix, SetSuffix, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_SUFFIX, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_POSTDIR, GetPostDir, SetPostDir, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_POSTDIR, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_SECNO, GetSecNo, SetSecNo, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_SECNO, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_HIGHRISE, GetHighRise, SetHighRise, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_HIGHRISE, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddressSpec, IDS_ENGINE_PROP_NOSOLICITATION, GetNoSolicitation, SetNoSolicitation, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAddressSpec, IDS_ENGINE_PROP_NOSOLICITATION, IDS_ENGINE_PPG_ADDRESSSPEC, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAddressSpec::CIuAddressSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddressSpec::~CIuAddressSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuAddressSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_iAddressNo = addressNone;
	SetVersion(IU_VERSION);
	m_sPriNo = "PriNo";
	m_sPreDir = "PreDir";
	m_sStreetName = "StreetName";
	m_sSuffix = "Suffix";
	m_sPostDir = "PostDir";
	m_sSecNo = "SecNo";
	m_sHighRise = "HighRise";
	m_sNoSolicitation = "NoSolicitation";
	//}}Initialize
}

void CIuAddressSpec::FromIndex(CIuCdromSpec* pCdrom, int iAddressSpec)
{
	ASSERT(iAddressSpec >= 0);

	const CIuAddressSpecDft* pAddressSpec = CIuAddressSpecDft::Get(iAddressSpec);
	ASSERT(pAddressSpec);

	FromSpec(pCdrom, pAddressSpec);
}

void CIuAddressSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszAddress)
{
	FromIndex(pCdrom, CIuAddressSpecDft::Find(pcszAddress));
}

void CIuAddressSpec::FromNo(CIuCdromSpec* pCdrom, int iAddressNo)
{
	FromIndex(pCdrom, CIuAddressSpecDft::Find(iAddressNo));
}

void CIuAddressSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuAddressSpecDft* pAddressSpec)
{
	SetCdrom(pCdrom);

	SetName(pAddressSpec->m_pcszName);
	SetID(CIuID::Create());

	SetAddressNo(pAddressSpec->m_iAddress);
	SetHighRise(pAddressSpec->m_pcszHighRise);
	SetNoSolicitation(pAddressSpec->m_pcszNoSolicitation);
	SetPostDir(pAddressSpec->m_pcszPostDir);
	SetPreDir(pAddressSpec->m_pcszPreDir);
	SetPriNo(pAddressSpec->m_pcszPriNo);
	SetSecNo(pAddressSpec->m_pcszSecNo);
	SetStreetName(pAddressSpec->m_pcszStreetName);
	SetSuffix(pAddressSpec->m_pcszSuffix);
}

int CIuAddressSpec::GetCount()
{
	return CIuAddressSpecDft::GetCount();
}

void CIuAddressSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuAddressSpec::SetHighRise(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sHighRise = pcsz;
}

void CIuAddressSpec::SetAddressNo(int iAddressNo)
{
	m_iAddressNo = iAddressNo;
}

void CIuAddressSpec::SetNoSolicitation(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sNoSolicitation = pcsz;
}

void CIuAddressSpec::SetPostDir(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPostDir = pcsz;
}

void CIuAddressSpec::SetPreDir(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPreDir = pcsz;
}

void CIuAddressSpec::SetPriNo(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPriNo = pcsz;
}

void CIuAddressSpec::SetSecNo(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSecNo = pcsz;
}

void CIuAddressSpec::SetStreetName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sStreetName = pcsz;
}

void CIuAddressSpec::SetSuffix(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSuffix = pcsz;
}
