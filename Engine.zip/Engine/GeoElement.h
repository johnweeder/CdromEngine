#ifndef _ENGINE_GEOELEMENT_H_
#define _ENGINE_GEOELEMENT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
//}}Uses

//{{Predefines
class CIuGeoList;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoElement }}
// A geo element is the expanded copy of a some geography item.
// It consists of a number of zero terminated strings representing the 
// the data, plus some amount (>= 0) of fixed length binary data.
// This (and any derived classes) should be packed and are usually
// variable length.
// For performance, avoid virtual functions 
#pragma pack(1)
class CIuGeoElement
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	LPCTSTR GetName() const;
	LPCTSTR GetString(int iString) const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoElementCollection;
	// The basic layout of the data is:
		// The offset of the strings from the start of the structure.
		// And the total length of the string data. This is used to quickly build a 
		// raw record.
		int m_iStringStart;
		int m_iStringLength;
		//	Fixed length data defined by derived class.
		//	0 or more bytes of variable data (starts at offset sizeof(this)
		//		This might include a list of associated ZIP codes or 
		//		phone prefixes.
		//	1 or more null terminated strings (starts at offset m_iStringStart).
		//		The first string is the name and it is a required field.
	// NOTE: This structure is considered const once created and is generated
	//			by the GeoElementCollection class as part of decompression.
//}}Data
};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline LPCTSTR CIuGeoElement::GetName() const
{
	return reinterpret_cast<LPCTSTR>(this) + m_iStringStart;
}

#endif // _ENGINE_GEOELEMENT_H_
