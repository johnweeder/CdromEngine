#ifndef _ENGINE_GEOCODEC_H_
#define _ENGINE_GEOCODEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOINSTANCE_H_
#	include "Engine\GeoInstance.h"
#endif	// _ENGINE_GEOINSTANCE_H_
#ifndef 	_ENGINE_ZIP_H_
#	include "Engine\Zip.h"
#endif	// _ENGINE_ZIP_H_
#ifndef 	_ENGINE_MSA_H_
#	include "Engine\Msa.h"
#endif	// _ENGINE_MSA_H_
#ifndef 	_ENGINE_CITY_H_
#	include "Engine\City.h"
#endif	// _ENGINE_CITY_H_
#ifndef 	_ENGINE_STATE_H_
#	include "Engine\State.h"
#endif	// _ENGINE_STATE_H_
#ifndef 	_ENGINE_COUNTY_H_
#	include "Engine\County.h"
#endif	// _ENGINE_COUNTY_H_
#ifndef 	_ENGINE_AREACODE_H_
#	include "Engine\AreaCode.h"
#endif	// _ENGINE_AREACODE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoCodec)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoCodec, CIuGeoInstance }}
#define CIuGeoCodec_super CIuGeoInstance

class CIuGeoCodec : public CIuGeoCodec_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoCodec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoCodec();
	virtual ~CIuGeoCodec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAreaCode() const;
	int GetCityDelta() const;
	int GetCountyDelta() const;
	int GetLatitudeDelta() const;
	int GetLatLongPrecision() const;
	int GetLongitudeDelta() const;
	int GetMsaDelta() const;
	int GetPrefix(int) const;
	int GetPrefixCount() const;
	void GetPrefixes(CIntArray& al) const;
	int GetZipNo() const;
	bool HasNoCity() const;
	bool HasNoCounty() const;
	bool HasNoLatLong() const;
	bool HasNoMsa() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int AddPrefix(int i, int iBefore);
	virtual void Clear();
	int FindPrefix(int iPrefix) const;
	void RemoveAllPrefixes();
	void RemovePrefix(int);
	void SetAreaCode(int);
	void SetCityDelta(int);
	void SetCountyDelta(int);
	void SetLatitudeDelta(int);
	void SetLatLongPrecision(int);
	void SetLongitudeDelta(int);
	void SetMsaDelta(int);
	void SetNoCity(bool = true);
	void SetNoCounty(bool = true);
	void SetNoLatLong(bool = true);
	void SetNoMsa(bool = true);
	void SetPrefix(int, int);
	void SetPrefixes(const CIntArray&);
	void SetZipNo(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
private:
	// Variables accessed directly for performance.
	friend class CIuGeo;
	int m_iZipNo;
	int m_iLatitudeDelta;
	int m_iLongitudeDelta;
	// See notes in BTreeCodec concerning lat/int precision
	int m_iLatLongPrecision;
	bool m_fNoLatLong;
	int m_iCityDelta;
	int m_iMsaDelta;
	int m_iCountyDelta;
	bool m_fNoMsa;
	bool m_fNoCounty;
	bool m_fNoCity;
	int m_iAreaCode;
	// Be careful with this array. If you remove all the elements, the memory
	// is free'd. Then you have to turn right around and allocate it on the 
	// next use. That really stinks
	CIntArray m_aiPrefixes;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuGeoCodec::GetAreaCode() const
{
	return m_iAreaCode;
}

inline int CIuGeoCodec::GetCityDelta() const
{
	return m_iCityDelta;
}

inline int CIuGeoCodec::GetCountyDelta() const
{
	return m_iCountyDelta;
}

inline int CIuGeoCodec::GetLatitudeDelta() const
{
	return m_iLatitudeDelta;
}

inline int CIuGeoCodec::GetLatLongPrecision() const
{
	return m_iLatLongPrecision;
}

inline int CIuGeoCodec::GetLongitudeDelta() const
{
	return m_iLongitudeDelta;
}

inline int CIuGeoCodec::GetMsaDelta() const
{
	return m_iMsaDelta;
}

inline int CIuGeoCodec::GetPrefix(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetPrefixCount());
	return m_aiPrefixes[iWhich];
}

inline int CIuGeoCodec::GetPrefixCount() const
{
	return m_aiPrefixes.GetSize();
}

inline int CIuGeoCodec::GetZipNo() const
{
	return m_iZipNo;
}

inline bool CIuGeoCodec::HasNoCity() const
{
	return m_fNoCity;
}

inline bool CIuGeoCodec::HasNoCounty() const
{
	return m_fNoCounty;
}

inline bool CIuGeoCodec::HasNoLatLong() const
{
	return m_fNoLatLong;
}

inline bool CIuGeoCodec::HasNoMsa() const
{
	return m_fNoMsa;
}

#endif // _ENGINE_GEOCODEC_H_
