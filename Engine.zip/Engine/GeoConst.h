#ifndef _ENGINE_GEOCONST_H_
#define _ENGINE_GEOCONST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

// Fixed point number in DDD.ddddd format. 
// In other words, divide by dwDegreeMultiplier (100,000) to get DDD.
//	NOTE: Our 5 decimals of precision is good to about +/- 3 feet.

const int dwLatLongDecimalDegreePrecision = 5;
const DWORD dwLatLongDegreeMultiplier = 100000; // ie  10 ^ dwDecimalDegreePrecision
const DWORD dwLatLongSignFlag = 0x80000000;
const DWORD dwLatLongSignMask = ~dwLatLongSignFlag;


#endif // _ENGINE_GEOCONST_H_
