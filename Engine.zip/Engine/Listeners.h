#ifndef _ENGINE_LISTENERS_H_
#define _ENGINE_LISTENERS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuListeners)
//}}Predefines


#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuListeners, CIuObjectNamed }}
// This class is basically a wrapper for a global (to this engine instance)
//	progress broadcast object.

#define CIuListeners_super CIuObjectNamed

class IU_CLASS_EXPORT CIuListeners : public CIuListeners_super
{
//{{Declare
	DECLARE_SERIAL(CIuListeners)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuListeners();           
	virtual ~CIuListeners();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuEngine& GetEngine() const;
	CIuProgressBroadcast& GetBroadcast() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Fire(CIuEvent EventID, int iHandle = -1);
	bool Fire(CIuEvent EventID, int iHandle, LPCTSTR pcszMessage, LPCTSTR pcszOutput = 0);
	bool Fire(CIuEvent EventID, int iHandle, LPCTSTR pcszMessage, LPCTSTR pcszOutput, int iPosition, int iRange, COleDateTime dtStart = COleDateTime::GetCurrentTime(), void* pv = 0);
	void SetEngine(CIuEngine& Engine);
	void Subscribe(CWnd* pWnd, UINT msg = wmProgressEvent);
	void UnSubscribe(CWnd* pWnd);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	bool Fire(const CIuProgressEvent& Event);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
	CIuProgressBroadcastPtr m_pBroadcast;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuProgressBroadcast& CIuListeners::GetBroadcast() const
{
	return m_pBroadcast.Ref();
}

#endif // !defined(AFX_LISTENERS_H__1E046F04_437A_11D2_930F_00104B885529__INCLUDED_)
