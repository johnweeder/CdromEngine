#include "StdAfx.h"
//{{Include
#include "ComparePhonetic.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuComparePhonetic::CIuComparePhonetic() 
{
	CommonConstruct();
}

CIuComparePhonetic::CIuComparePhonetic(const CIuComparePhonetic& rComparePhonetic)
{
	CommonConstruct();
	*this = rComparePhonetic;
}

CIuComparePhonetic::~CIuComparePhonetic()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuComparePhonetic::Compare(LPCTSTR pcsz) const
{
	UNUSED(pcsz);
	ASSERT(AfxIsValidString(pcsz));
	ASSERT(false);
	return 0;
}

void CIuComparePhonetic::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

CIuComparePhonetic& CIuComparePhonetic::operator=(const CIuComparePhonetic& rComparePhonetic)
{
	if (this == &rComparePhonetic)
		return *this;
	return *this;
}

void CIuComparePhonetic::SetExpression(LPCTSTR)
{
}
