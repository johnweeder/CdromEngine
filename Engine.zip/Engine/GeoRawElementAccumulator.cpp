#include "StdAfx.h"
//{{Include
#include "GeoRawElementAccumulator.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Common\NybbleInt.h"
#include "Common\NybbleString.h"
#include "GeoRawElementMap.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// This structure is variable length. The name is always stored as a full 
// ascii-z string
#pragma pack(1)
struct CIuGeoRawElementAccumulatorTuple
{
	DWORD m_dwCount;
	WORD m_wNameLength;
	TCHAR m_szName[1];
};
#pragma pack()

static int __cdecl sort_elements_by_count_decreasing(const void *elem1, const void *elem2)
{
	const CIuGeoRawElementAccumulatorTuple* pElement1 = *(const CIuGeoRawElementAccumulatorTuple**)elem1;
	const CIuGeoRawElementAccumulatorTuple* pElement2 = *(const CIuGeoRawElementAccumulatorTuple**)elem2;
	return int(pElement2->m_dwCount) - int(pElement1->m_dwCount);
}

static int __cdecl sort_elements_by_name(const void *elem1, const void *elem2)
{
	const CIuGeoRawElementAccumulatorTuple* pElement1 = *(const CIuGeoRawElementAccumulatorTuple**)elem1;
	const CIuGeoRawElementAccumulatorTuple* pElement2 = *(const CIuGeoRawElementAccumulatorTuple**)elem2;
	return _tcsicmp(pElement1->m_szName, pElement2->m_szName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawElementAccumulator, CIuGeoRawElementAccumulator_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawElementAccumulator)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWELEMENTACCUMULATOR, CIuGeoRawElementAccumulator, CIuGeoRawElementAccumulator_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoRawElementAccumulator, IDS_ENGINE_PPG_GEORAWELEMENTACCUMULATOR, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuGeoRawElementAccumulator, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuGeoRawElementAccumulator, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_GEORAWELEMENTACCUMULATOR, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawElementAccumulator::CIuGeoRawElementAccumulator() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoRawElementAccumulator::~CIuGeoRawElementAccumulator()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawElementAccumulator::Add(__int64 l, int iPad)
{
	TCHAR sz[Int64MaxStringLength];
	if (iPad > 0)
		Int64AsStringEx(sz, sizeof(sz), l, 10, iPad, iPad, true);
	else
		Int64AsStringEx(sz, sizeof(sz), l);
	Add(sz);
}

void CIuGeoRawElementAccumulator::Add(LPCTSTR pcszName, int iActualCount)
{
	if (pcszName == 0 || *pcszName == 0)
		return ;

	int iLength = _tcslen(pcszName);

	// Check if already in buffer
	int cb = m_Buffer.GetSize();
	BYTE* pb = cb > 0 ? m_Buffer.GetPtr(): 0;

	while (cb > 0)
	{
		CIuGeoRawElementAccumulatorTuple* pElement = (CIuGeoRawElementAccumulatorTuple*)pb;
		if (pElement->m_wNameLength == iLength && memicmp(pcszName, pElement->m_szName, iLength) == 0)
		{
			if (iActualCount > 0)
				pElement->m_dwCount = iActualCount;
			else
				++pElement->m_dwCount;
			return ;
		}
		pb += sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		cb -= sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		ASSERT(cb >= 0);
	}

	// Append to buffer
	cb = m_Buffer.GetSize();

	int iExtra = sizeof(CIuGeoRawElementAccumulatorTuple) + iLength;
	m_Buffer.SetSize(m_Buffer.GetSize() + iExtra, 32);

	pb = m_Buffer.GetPtr(cb);
	CIuGeoRawElementAccumulatorTuple* pElement = (CIuGeoRawElementAccumulatorTuple*)pb;

	if (iActualCount > 0)
		pElement->m_dwCount = iActualCount;
	else
		pElement->m_dwCount = 1;
	pElement->m_wNameLength = WORD(iLength);
	_tcscpy(pElement->m_szName, pcszName);
}

void CIuGeoRawElementAccumulator::Clear()
{
	m_Buffer.SetSize(0);
}

void CIuGeoRawElementAccumulator::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	// Minimize memory usage by accumulator. A _lot_ of this class is created. We need to limit
	// memory usage.
	m_Buffer.SetGrowBy(64);
	//}}Initialize
}

int CIuGeoRawElementAccumulator::CompressPreferred(CIuGeoRaw&, CIuNybbleBuffer& buffer, int iMax, bool fNumeric)
{
	SortByCountDecreasing();
	int iCount = GetAccumulated();
	iCount = min(iCount, iMax);
	CIuNybbleInt::AppendUIntCompressed(iCount, buffer);
	for (int i = 0; i < iCount; ++i)
	{
		CString sName = GetName(i);
		if (fNumeric)
		{
			CIuNybbleInt::AppendUIntCompressed(StringAsInt(sName), buffer);
		}
		else
		{
			CIuNybbleString::Append(sName, -1, NS_ALPHA, buffer);
		}
	}
	return i;
}

void CIuGeoRawElementAccumulator::CompressPreferred(CIuGeoRaw&, CIuNybbleBuffer& buffer, CIuGeoRawElementMap& map)
{
	// NOTE: We write the index+1. A value of zero indicates that the field is not present.
	SortByCountDecreasing();
	if (GetAccumulated() <= 0)
	{
		CIuNybbleInt::AppendUIntCompressed(0, buffer);
	}
	else
	{
		__int32 iIndex;
		CString sName = GetName(0);
		if (map.Lookup(sName, iIndex))
		{
			ASSERT(iIndex >= 0);
			CIuNybbleInt::AppendUIntCompressed(iIndex + 1, buffer);
		}
		else
		{
			ASSERT(false);
		}
	}
}

void CIuGeoRawElementAccumulator::CompressPreferred(CIuGeoRaw&, CIuNybbleBuffer& buffer, LPCTSTR pcszDefault)
{
	SortByCountDecreasing();
	if (GetAccumulated() <= 0)
	{
		if (pcszDefault)
			CIuNybbleString::Append(pcszDefault, -1, NS_ALPHA, buffer);
		else
			CIuNybbleString::Append("", -1, NS_ALPHA, buffer);
	}
	else
	{
		CString sName = GetName(0);
		if (sName.IsEmpty() && pcszDefault)
			sName = pcszDefault;
		CIuNybbleString::Append(sName, -1, NS_ALPHA, buffer);
	}
}

const CIuGeoRawElementAccumulatorTuple* CIuGeoRawElementAccumulator::Find(int iWhich) const
{
	// Check if already in buffer
	int cb = m_Buffer.GetSize();
	if (cb == 0)
	{
		ASSERT(false);		
		return 0;
	}

	const BYTE* pb = m_Buffer.GetPtr();
	for (int iAccumulated = 0; cb > 0; iAccumulated++)
	{
		const CIuGeoRawElementAccumulatorTuple* pElement = (const CIuGeoRawElementAccumulatorTuple*)pb;
		if (iAccumulated == iWhich)
			return pElement;
		pb += sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		cb -= sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		ASSERT(cb >= 0);
	}
	ASSERT(false);
	return 0;	
}

int CIuGeoRawElementAccumulator::GetAccumulated() const
{
	// Check if already in buffer
	int cb = m_Buffer.GetSize();
	if (cb == 0)
		return 0;
	const BYTE* pb = m_Buffer.GetPtr();
	for (int iAccumulated = 0; cb > 0; iAccumulated++)
	{
		CIuGeoRawElementAccumulatorTuple* pElement = (CIuGeoRawElementAccumulatorTuple*)pb;
		pb += sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		cb -= sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		ASSERT(cb >= 0);
	}
	return iAccumulated;	
}

int CIuGeoRawElementAccumulator::GetCount(int iWhich) const
{
	const CIuGeoRawElementAccumulatorTuple* pElement = Find(iWhich);
	return pElement->m_dwCount;
}

bool CIuGeoRawElementAccumulator::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			SortByName();

			static TCHAR szName[] = _T("CIuGeoRawElementAccumulatorGrid");
			rq.SetName(szName);
			rq.Load();
			rq.SetSize(CSize(2, GetAccumulated()));
			rq.SetColumn(0, "Name", 500, gridWidthOptional);
			rq.SetColumn(1, "Count", 100, gridWidthOptional);
			return true;
		}
		case gridRqTerminate:
			rq.Save();
			return true;
		case gridRqDblClickRow:
			// rq.GetRow()
			return true;
		case gridRqDblClickCell:
			// rq.GetRow(), rq.GetColumn()
			return true;
		case gridRqGet:
		{
			if (rq.GetRow() < 0 || rq.GetRow() >= GetAccumulated())
				return false;

			switch (rq.GetColumn())
			{
				case 0:
					rq.SetValue(GetName(rq.GetRow()));
					return true;
				case 1:
					CString sResult;
					rq.SetValue(Int32AsString(sResult, GetCount(rq.GetRow())));
					return true;
			}

			return false;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

CString CIuGeoRawElementAccumulator::GetName(int iWhich) const
{
	const CIuGeoRawElementAccumulatorTuple* pElement = Find(iWhich);
	return CString(pElement->m_szName);
}

void CIuGeoRawElementAccumulator::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		DWORD dwCount = GetAccumulated();
		ar << dwCount;

		DWORD dwSize = m_Buffer.GetSize();
		ar << dwSize;

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			CString sName = GetName(dw);
			__int32 iCount = GetCount(dw);
			ar << sName;
			ar << iCount;
		}
	}
	else
	{
		Clear();

		DWORD dwCount;
		ar >> dwCount;

		DWORD dwSize;
		ar >> dwSize;
		m_Buffer.PreAllocate(dwSize);

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			CString sName;
			ar >> sName;

			int iCount;
			ar >> iCount;

			Add(sName, iCount);
		}
	}
}

void CIuGeoRawElementAccumulator::SortByCountDecreasing()
{
	CIuGeoRawElementAccumulatorTupleArray array;
	if (SortPre(array) > 0)
	{
		qsort(array.GetData(), array.GetSize(), sizeof(CIuGeoRawElementAccumulatorTuple*), sort_elements_by_count_decreasing);
		SortPost(array);
	}
}

void CIuGeoRawElementAccumulator::SortByName()
{
	CIuGeoRawElementAccumulatorTupleArray array;
	if (SortPre(array) > 0)
	{
		qsort(array.GetData(), array.GetSize(), sizeof(CIuGeoRawElementAccumulatorTuple*), sort_elements_by_name);
		SortPost(array);
	}
}

void CIuGeoRawElementAccumulator::SortPost(CIuGeoRawElementAccumulatorTupleArray& array)
{
	ASSERT(m_Buffer.GetSize() > 0);
	CIuBuffer Buffer;
	Buffer.SetSize(m_Buffer.GetSize());
	
	const BYTE* pb = Buffer.GetPtr();

	for (int i = 0; i < array.GetSize(); i++)
	{
		const CIuGeoRawElementAccumulatorTuple* pElement = array[i];

		int iSize = sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;

		memcpy((void*)pb, pElement, iSize);

		pb += iSize;
	}

	m_Buffer = Buffer;
}

int CIuGeoRawElementAccumulator::SortPre(CIuGeoRawElementAccumulatorTupleArray& array)
{
	int iAccumulated = GetAccumulated();
	array.SetSize(iAccumulated);
	if (iAccumulated == 0)
		return 0;

	const BYTE* pb = m_Buffer.GetPtr();
	int cb = m_Buffer.GetSize();
	for (int i = 0; i < iAccumulated; i++)
	{
		CIuGeoRawElementAccumulatorTuple* pElement = (CIuGeoRawElementAccumulatorTuple*)pb;
		array.SetAt(i, pElement);

		pb += sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		cb -= sizeof(CIuGeoRawElementAccumulatorTuple) + pElement->m_wNameLength;
		ASSERT(cb >= 0);
	}
	return iAccumulated;
}
