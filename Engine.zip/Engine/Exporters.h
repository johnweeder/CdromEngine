#ifndef _ENGINE_EXPORTERS_H_ 
#define _ENGINE_EXPORTERS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPORTER_H_
#	include "Engine\Exporter.h"
#endif	// _ENGINE_EXPORTER_H_
//}}Uses

//{{Predefines
class CIuEngine;
IU_DEFINE_OBJECT_PTR(CIuExporters)
//}}Predefines


#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExporters, CIuExporters_super }}

#define CIuExporters_super CIuCollection

class IU_CLASS_EXPORT CIuExporters : public CIuExporters_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuExporters)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExporters();           
	virtual ~CIuExporters();
//}}Constructor/Destuctor
 
/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuExporter& Get(LPCTSTR s) const;
	CIuExporter& Get(int iIndex) const;
	CIuExporter& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetEngine(CIuEngine& Engine);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuExporter& CIuExporters::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuExporter*>(&CIuCollection::Get(s));
}

inline CIuExporter& CIuExporters::Get(int iIndex) const
{
	return *dynamic_cast<CIuExporter*>(&CIuCollection::Get(iIndex));
}

inline CIuExporter& CIuExporters::Get(CIuID id) const
{
	return *dynamic_cast<CIuExporter*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_EXPORTERS_H_
