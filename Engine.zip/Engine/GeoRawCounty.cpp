#include "StdAfx.h"
//{{Include
#include "GeoRawCounty.h"
#include "GeoRawInstance.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawCounty)
IMPLEMENT_SERIAL(CIuGeoRawCounty, CIuGeoRawCounty_super,0)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWCOUNTY, CIuGeoRawCounty, CIuGeoRawCounty_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawCounty, IDS_ENGINE_PROP_ZIPS, GetZips_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawCounty, IDS_ENGINE_PROP_ZIPS, editorUsePropName)

	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawCounty, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawCounty, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_GEORAWELEMENT, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawCounty::CIuGeoRawCounty() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoRawCounty::~CIuGeoRawCounty()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawCounty::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput&)
{
	GetZips().Add(Instance.GetZip());
	CIuGeoRawCounty_super::Another();
}

CIuObject* CIuGeoRawCounty::GetZips_() const
{
	return &m_Zips;
}

void CIuGeoRawCounty::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_sTitle;
	}
	else
	{
		ar >> m_sTitle;
	}
	GetZips().Serialize(ar);
	CIuGeoRawCounty_super::Serialize(ar);
}

void CIuGeoRawCounty::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}
