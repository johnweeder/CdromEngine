#ifndef _ENGINE_BUILD_H_ 
#define _ENGINE_BUILD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_BUILDTHREAD_H_
#	include "Engine\BuildThread.h"
#endif	// _ENGINE_BUILDTHREAD_H_
#ifndef _ENGINE_ENGINE_H_
#	include "Engine.h"
#endif
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBuild)
//}}Predefines


#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBuild, CIuBuild_super }}

#define CIuBuild_super CIuCollectable

class IU_CLASS_EXPORT CIuBuild : public CIuBuild_super
{
//{{Declare
	DECLARE_SERIAL(CIuBuild)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBuild();           
	virtual ~CIuBuild();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool GetAbort();
	CIuBuilds& GetBuilds() const;
	int GetHandle();
	bool IsRunning();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Command(LPCTSTR CommandString, int hWnd);
	void SetAbort(bool fCancel);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBuildThread* m_pThread;
	CIuOutputPtr m_pOutput;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

#endif 
