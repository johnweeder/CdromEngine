#ifndef _ENGINE_EXPORTFIELDDEFSPEC_H_
#define _ENGINE_EXPORTFIELDDEFSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_FIELDDEFSPEC_H_
#	include "Engine\FieldDefSpec.h"
#endif	// _ENGINE_FIELDDEFSPEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportFieldDefSpec)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportFieldDefSpec, CIuFieldDefSpec }}
#define CIuExportFieldDefSpec_super CIuFieldDefSpec

class CIuExportFieldDefSpec : public CIuExportFieldDefSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportFieldDefSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportFieldDefSpec();
	CIuExportFieldDefSpec(LPCTSTR pcsz, bool fAssumeIsSpec = false);
	CIuExportFieldDefSpec(const CIuExportFieldDefSpec&);
	virtual ~CIuExportFieldDefSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExportFieldDefSpec& operator=(const CIuExportFieldDefSpec&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	void ParseParms(LPCTSTR pcsz, bool fAppend);
private:
	void CommonConstruct();
//}}Implementation

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_EXPORTFIELDDEFSPEC_H_
