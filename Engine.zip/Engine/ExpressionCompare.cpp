#include "StdAfx.h"
//{{Include
#include "ExpressionCompare.h"
#include "Common\String.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionCompare::CIuExpressionCompare(CIuExpressionType Type) : CIuExpressionElement(Type)
{
	SetFormat(exprFormatBool);
}

CIuExpressionCompare::CIuExpressionCompare(const CIuExpressionCompare& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionCompare::~CIuExpressionCompare()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionCompare::Clone() const
{
	CIuExpressionCompare* pElement = new CIuExpressionCompare(*this);
	ASSERT(pElement);
	return pElement;
} 

bool CIuExpressionCompare::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 2);

	bool fResult = false;

	CIuExpressionFormat Format0 = GetChildFormat(0);
	CIuExpressionFormat Format1 = GetChildFormat(1);
	if (Format0 != exprFormatString && Format1 != exprFormatString)
	{
		int i1 = EvaluateChildInt(0, pRecord);
		int i2 = EvaluateChildInt(1, pRecord);
		switch (GetType())
		{
			case exprEqual:
				fResult = (i1 == i2);
				break;
			case exprNotEqual:
				fResult = (i1 != i2);
				break;
			case exprGreaterThan:
				fResult = (i1 > i2);
				break;
			case exprGreaterThanOrEqual:
				fResult = (i1 >= i2);
				break;
			case exprLessThan:
				fResult = (i1 < i2);
				break;
			case exprLessThanOrEqual:
				fResult = (i1 <= i2);
				break;
			default:
				ASSERT(false);
		}
	}
	else
	{
		LPCTSTR pcsz1 = EvaluateChild(0, pRecord);
		LPCTSTR pcsz2 = EvaluateChild(1, pRecord);
		if (IsNumeric(pcsz1, true) && IsNumeric(pcsz2, true))
		{
			int i1 = StringAsInt(pcsz1);
			int i2 = StringAsInt(pcsz2);
			switch (GetType())
			{
				case exprEqual:
					fResult = (i1 == i2);
					break;
				case exprNotEqual:
					fResult = (i1 != i2);
					break;
				case exprGreaterThan:
					fResult = (i1 > i2);
					break;
				case exprGreaterThanOrEqual:
					fResult = (i1 >= i2);
					break;
				case exprLessThan:
					fResult = (i1 < i2);
					break;
				case exprLessThanOrEqual:
					fResult = (i1 <= i2);
					break;
				default:
					ASSERT(false);
			}
		}
		else
		{
			int iResult = _tcsicmp(pcsz1, pcsz2);
			switch (GetType())
			{
				case exprEqual:
					fResult = (iResult == 0);
					break;
				case exprNotEqual:
					fResult = (iResult != 0);
					break;
				case exprGreaterThan:
					fResult = (iResult > 0);
					break;
				case exprGreaterThanOrEqual:
					fResult = (iResult >= 0);
					break;
				case exprLessThan:
					fResult = (iResult < 0);
					break;
				case exprLessThanOrEqual:
					fResult = (iResult <= 0);
					break;
				default:
					ASSERT(false);
			}
		}
	}
	return fResult;
}

int CIuExpressionCompare::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionCompare::GetMaxLength() const
{
	return BooiMaxLength();
}

LPCTSTR CIuExpressionCompare::GetTypeName() const
{
	switch (GetType())
	{
		case exprCompare:
			return "#Comparison Operator#";
		case exprEqual:
			return "==";
		case exprNotEqual:
			return "!=";
		case exprGreaterThan:
			return ">";
		case exprGreaterThanOrEqual:
			return ">=";
		case exprLessThan:
			return "<";
		case exprLessThanOrEqual:
			return "<=";
	}
	return CIuExpressionCompare_super::GetTypeName();
}

bool CIuExpressionCompare::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprCompare || CIuExpressionCompare_super::IsKindOf(Type);
}

CIuExpressionCompare& CIuExpressionCompare::operator=(const CIuExpressionCompare& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionCompare_super::operator=(rExpressionElement);
	return *this;
}
