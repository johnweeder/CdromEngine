#ifndef _ENGINE_METERENABLEDLG_H_
#define _ENGINE_METERENABLEDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
#ifndef 	_COMMON_QUERYRESPONSESESSION_H_
#	include "Common\QueryResponseSession.h"
#endif	// _COMMON_QUERYRESPONSESESSION_H_
//}}Uses

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Enable mode
enum CIuMeterEnableMode
{
	meterEnableUnknown = 0,

	// Enable network access
	meterEnableNetworkAccess_SingleUser,
	meterEnableNetworkAccess_MultiUser,
	// Access code
	meterEnableAccessCode_SingleUser,
	meterEnableAccessCode_MultiUser,
	// Product expired
	meterEnableExpired,
	// Reset a corrupt meter
	meterEnableCorrupt,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterEnableDlg, CDialog }}
#define CIuMeterEnableDlg_super CDialog

class IU_CLASS_EXPORT CIuMeterEnableDlg : public CIuMeterEnableDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuMeterEnableDlg(CWnd* pParent = NULL);   
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool DoDialog(CIuMeter& Meter, int iMode, CWnd* pParent, bool fAutoEnable);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void SetUserCode();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
	bool m_fCorrupt;
	bool m_fUpdated;
	int m_iMaxAttempts;
	CFont m_fontLarge;
	bool m_fAutoEnable;
	int m_iMode;
	CIuQueryResponseSession m_Session;
//}}Data

public:
	//{{AFX_DATA(CIuMeterEnableDlg)
	enum { IDD = IDD_ENGINE_METER_ENABLE };
	CButton	m_btnWebSite;
	CEdit	m_editPhone;
	CEdit	m_editUserCode;
	CEdit	m_editResponse;
	CButton	m_btnCancel;
	CButton	m_btnEnable;
	CString	m_sUserCode;
	CString	m_sResponse;
	CString	m_sStatus;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterEnableDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterEnableDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnEnable();
	afx_msg void OnChange();
	afx_msg void OnWebsite();
	virtual void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERENABLEDLG_H_
