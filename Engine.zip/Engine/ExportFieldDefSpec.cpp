#include "StdAfx.h"
//{{Include
#include "ExportFieldDefSpec.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportFieldDefSpec, CIuExportFieldDefSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportFieldDefSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTFIELDDEFSPEC, CIuExportFieldDefSpec, CIuExportFieldDefSpec_super)
//{{AttributeMap
//	IU_ATTRIBUTE_PAGE(CIuExportFieldDefSpec, IDS_ENGINE_PPG_EXPORTFIELDDEFSPEC, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

	
CIuExportFieldDefSpec::CIuExportFieldDefSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportFieldDefSpec::CIuExportFieldDefSpec(const CIuExportFieldDefSpec& rExportFieldDefSpec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rExportFieldDefSpec;
}

CIuExportFieldDefSpec::CIuExportFieldDefSpec(LPCTSTR pcsz, bool fAssumeIsSpec) : CIuExportFieldDefSpec_super(pcsz, fAssumeIsSpec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportFieldDefSpec::~CIuExportFieldDefSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExportFieldDefSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuExportFieldDefSpec::Copy(const CIuObject& object)
{
	CIuExportFieldDefSpec_super::Copy(object);

	const CIuExportFieldDefSpec* pExportFieldDefSpec = dynamic_cast<const CIuExportFieldDefSpec*>(&object);
	if (pExportFieldDefSpec == 0 || pExportFieldDefSpec == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuExportFieldDefSpec)));
}

CIuExportFieldDefSpec& CIuExportFieldDefSpec::operator=(const CIuExportFieldDefSpec& rExportFieldDefSpec)
{
	Copy(rExportFieldDefSpec);
	return *this;
}

void CIuExportFieldDefSpec::ParseParms(LPCTSTR pcsz, bool fAppend)
{
	CIuExportFieldDefSpec_super::ParseParms(pcsz, fAppend);
	// __TODO("JerryL: Parse anything left in m_sOptions")
}
