#include "StdAfx.h"
//{{Include
#include "ExpressionContains.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionContains::CIuExpressionContains() : CIuExpressionElement(exprContains)
{
	SetFormat(exprFormatBool);
	CommonConstruct();
}

CIuExpressionContains::CIuExpressionContains(const CIuExpressionContains& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionContains::~CIuExpressionContains()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionContains::Clone() const
{
	CIuExpressionContains* pElement = new CIuExpressionContains(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionContains::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fPatternConst = false;
	//}}Initialize
}

bool CIuExpressionContains::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetType() == exprContains);
	ASSERT(GetChildCount() == 2);
	if (!m_fPatternConst)
		m_Comparator.SetExpression(EvaluateChild(1, pRecord));

	bool fContains = m_Comparator.Compare(EvaluateChild(0, pRecord));
	return fContains;
}

int CIuExpressionContains::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionContains::GetMaxLength() const
{
	// Always returns boolean "0" or "1"
	return BooiMaxLength();
}

LPCTSTR CIuExpressionContains::GetTypeName() const
{
	switch (GetType())
	{
		case exprContains:
			return "CONTAINS";
	}
	return CIuExpressionContains_super::GetTypeName();
}

CIuExpressionContains& CIuExpressionContains::operator=(const CIuExpressionContains& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionContains_super::operator=(rExpressionElement);
	m_Comparator = rExpressionElement.m_Comparator;
	m_fPatternConst = rExpressionElement.m_fPatternConst;
	return *this;
}

void CIuExpressionContains::Resolve(CIuResolveSpec& Spec)
{
	CIuExpressionContains_super::Resolve(Spec);
	ASSERT(GetType() == exprContains);
	ASSERT(GetChildCount() == 2);

	m_fPatternConst = GetChild(1).IsConst();
	if (m_fPatternConst)
		m_Comparator.SetExpression(EvaluateChild(1, 0));
}
