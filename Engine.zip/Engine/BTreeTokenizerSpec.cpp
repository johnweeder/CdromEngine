#include "StdAfx.h"
//{{Include
#include "BTreeTokenizerSpec.h"
#include "BTreeTokenizerSpecDft.h"
#include "BTreeSpec.h"
#include "Token.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeTokenizerSpec, CIuBTreeTokenizerSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeTokenizerSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREETOKENIZERSPEC, CIuBTreeTokenizerSpec, CIuBTreeTokenizerSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTreeTokenizerSpec, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_BTREETOKENIZERNO, GetBTreeTokenizerNo, SetBTreeTokenizerNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_BTREETOKENIZERNO, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_TOKENNO, GetTokenNo, SetTokenNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_TOKENNO, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_OPTIONAL, IsOptional, SetOptional, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_OPTIONAL, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_EXCEPTIONAL, IsExceptional, SetExceptional, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeTokenizerSpec, IDS_ENGINE_PROP_EXCEPTIONAL, IDS_ENGINE_PPG_BTREETOKENIZERSPEC, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeTokenizerSpec::CIuBTreeTokenizerSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTreeTokenizerSpec::~CIuBTreeTokenizerSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeTokenizerSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pBTree = 0;
	m_iBTreeTokenizerNo = 0;
	m_iTokenNo = tokenNone;
	m_sFilename = "Filename";
	m_fOptional = false;
	m_fExceptional = false;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuBTreeTokenizerSpec::FromIndex(CIuBTreeSpec* pBTree, int iBTreeTokenizerSpec)
{
	ASSERT(iBTreeTokenizerSpec >= 0);

	const CIuBTreeTokenizerSpecDft* pBTreeTokenizerSpec = CIuBTreeTokenizerSpecDft::Get(iBTreeTokenizerSpec);
	ASSERT(pBTreeTokenizerSpec);

	FromSpec(pBTree, pBTreeTokenizerSpec);
}

void CIuBTreeTokenizerSpec::FromName(CIuBTreeSpec* pBTree, LPCTSTR pcszBTreeTokenizer)
{
	FromIndex(pBTree, CIuBTreeTokenizerSpecDft::Find(pcszBTreeTokenizer));
}

void CIuBTreeTokenizerSpec::FromNo(CIuBTreeSpec* pBTree, int iBTreeTokenizerNo)
{
	FromIndex(pBTree, CIuBTreeTokenizerSpecDft::Find(iBTreeTokenizerNo));
}

void CIuBTreeTokenizerSpec::FromSpec(CIuBTreeSpec* pBTree, const CIuBTreeTokenizerSpecDft* pBTreeTokenizerSpec)
{
	SetBTree(pBTree);

	SetName(pBTreeTokenizerSpec->m_pcszBTreeTokenizer);
	SetID(CIuID::Create());

	SetBTreeTokenizerNo(pBTreeTokenizerSpec->m_iBTreeTokenizer);

	SetFilename(pBTreeTokenizerSpec->m_pcszFilename);
	SetTokenNo(pBTreeTokenizerSpec->m_iTokenNo);
	SetOptional(pBTreeTokenizerSpec->m_fOptional);
	SetExceptional(pBTreeTokenizerSpec->m_fExceptional);
}

CIuCdromSpec& CIuBTreeTokenizerSpec::GetCdrom() const
{
	ASSERT(HasBTree());
	ASSERT(GetBTree().HasCdrom());
	return GetBTree().GetCdrom();
}

int CIuBTreeTokenizerSpec::GetCount()
{
	return CIuBTreeTokenizerSpecDft::GetCount();
}

void CIuBTreeTokenizerSpec::SetBTree(CIuBTreeSpec* pBTree)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pBTree != 0);
	m_pBTree = pBTree;
}


void CIuBTreeTokenizerSpec::SetBTreeTokenizerNo(int iBTreeTokenizerNo)
{
	m_iBTreeTokenizerNo = iBTreeTokenizerNo;
}

void CIuBTreeTokenizerSpec::SetExceptional(bool f)
{
	m_fExceptional = f;
}

void CIuBTreeTokenizerSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuBTreeTokenizerSpec::SetTokenNo(int iTokenNo)
{
	m_iTokenNo = iTokenNo;
}

void CIuBTreeTokenizerSpec::SetOptional(bool f)
{
	m_fOptional = f;
}
