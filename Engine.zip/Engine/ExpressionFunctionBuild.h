#ifndef _ENGINE_EXPRESSIONFUNCTIONBUILD_H_
#define _ENGINE_EXPRESSIONFUNCTIONBUILD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONFUNCTION_H_
#	include "Engine\ExpressionFunction.h"
#endif	// _ENGINE_EXPRESSIONFUNCTION_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionFunctionBuild, CIuExpressionFunction }}
#define CIuExpressionFunctionBuild_super CIuExpressionFunction

class CIuExpressionFunctionBuild : public CIuExpressionFunction
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionFunctionBuild(CIuExpressionType Type = exprFunction);
	CIuExpressionFunctionBuild(const CIuExpressionFunctionBuild& rExpressionElement);
	virtual ~CIuExpressionFunctionBuild();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static const CIuExpressionFunctionDef* GetFunctionDefs();
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	static CIuExpressionFunction* Create();
	virtual CIuExpressionElement* Optimize();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionFunctionBuild& operator=(const CIuExpressionFunctionBuild& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	LPCTSTR BuildAddress(int iType, const CIuRecord* pRecord) const;
	LPCTSTR BuildAcPhone(const CIuRecord * pRecord) const;
	int BuildAcPhoneMaxLength() const;
	LPCTSTR BuildPriNo(const CIuRecord * pRecord) const;
	int BuildPriNoMaxLength() const;
	LPCTSTR BuildSecNo(const CIuRecord * pRecord) const;
	int BuildSecNoMaxLength() const;
	LPCTSTR BuildStreet(const CIuRecord * pRecord) const;
	int BuildStreetMaxLength() const;
	int Compare(const CIuRecord* pRecord) const;
	int CompareNoCase(const CIuRecord* pRecord) const;
	LPCTSTR CRLF(const CIuRecord * pRecord) const;
	int CRLFMaxLength() const;
	LPCTSTR DefVal(const CIuRecord* pRecord) const;
	int DefVaiMaxLength() const;
	LPCTSTR ExtractNamePart(const CIuRecord * pRecord) const;
	int ExtractNamePartMaxLength() const;
	LPCTSTR FirstName(const CIuRecord* pRecord) const;
	int FirstNameMaxLength() const;
	LPCTSTR FlipName(const CIuRecord* pRecord) const;
	int FlipNameMaxLength() const;
	LPCTSTR HyphenatePhone(const CIuRecord* pRecord) const;
	int HyphenatePhoneMaxLength() const;
	LPCTSTR HyphenateZIP(const CIuRecord* pRecord) const;
	int HyphenateZIPMaxLength() const;
	LPCTSTR Iff(const CIuRecord* pRecord) const;
	int IffMaxLength() const;
	LPCTSTR LatLongDistance(const CIuRecord* pRecord) const;
	int LatLongDistanceMaxLength() const;
	LPCTSTR LastName(const CIuRecord* pRecord) const;
	int LastNameMaxLength() const;
	LPCTSTR Left(const CIuRecord* pRecord) const;
	int LeftMaxLength() const;
	int Len(const CIuRecord* pRecord) const;
	LPCTSTR Lookup(const CIuRecord * pRecord) const;
	int LookupMaxLength() const;
	LPCTSTR MakeAddress(const CIuRecord* pRecord) const;
	int MakeAddressMaxLength() const;
	LPCTSTR MakeCityState(const CIuRecord* pRecord) const;
	int MakeCityStateMaxLength() const;
	LPCTSTR MakeLastLine(const CIuRecord* pRecord) const;
	int MakeLastLineMaxLength() const;
	LPCTSTR MakeLower(const CIuRecord* pRecord) const;
	int MakeLowerMaxLength() const;
	LPCTSTR MakeName(const CIuRecord* pRecord) const;
	int MakeNameMaxLength() const;
	LPCTSTR MakeNameInitials(const CIuRecord* pRecord) const;
	int MakeNameInitialsMaxLength() const;
	LPCTSTR MakePhone(const CIuRecord* pRecord) const;
	int MakePhoneMaxLength() const;
	LPCTSTR MakeStreet(const CIuRecord* pRecord) const;
	int MakeStreetMaxLength() const;
	LPCTSTR MakeUpper(const CIuRecord* pRecord) const;
	int MakeUpperMaxLength() const;
	LPCTSTR MakeZIP(const CIuRecord* pRecord) const;
	int MakeZIPMaxLength() const;
	LPCTSTR Mid(const CIuRecord* pRecord) const;
	int MidMaxLength() const;
	LPCTSTR Newline(const CIuRecord * pRecord) const;
	int NewlineMaxLength() const;
	LPCTSTR Paste(const CIuRecord* pRecord) const;
	LPCTSTR PasteSpace(const CIuRecord* pRecord) const;
	int PasteSpaceMaxLength() const;
	LPCTSTR Repeat(const CIuRecord* pRecord) const;
	int RepeatMaxLength() const;
	LPCTSTR Right(const CIuRecord* pRecord) const;
	int RightMaxLength() const;
	LPCTSTR SortZIP9First(const CIuRecord* pRecord) const;
	int SortZIP9FirstMaxLength() const;
	LPCTSTR Space(const CIuRecord* pRecord) const;
	int SpaceMaxLength() const;
	LPCTSTR StateAbbr2Code(const CIuRecord * pRecord) const;
	int StateAbbr2CodeMaxLength() const;
	LPCTSTR StateCode2Abbr(const CIuRecord * pRecord) const;
	int StateCode2AbbrMaxLength() const;
	LPCTSTR Surround(const CIuRecord * pRecord) const;
	LPCTSTR Tab(const CIuRecord* pRecord) const;
	int TabMaxLength() const;
	LPCTSTR TAPIPhone(const CIuRecord* pRecord) const;
	int TAPIPhoneMaxLength() const;
	LPCTSTR Thousands(const CIuRecord* pRecord) const;
	int ThousandsMaxLength() const;
	LPCTSTR Trim(const CIuRecord * pRecord) const;
	LPCTSTR TrimLeft(const CIuRecord * pRecord) const;
	int TrimMaxLength() const;
	LPCTSTR TrimRight(const CIuRecord * pRecord) const;
	int VarArgConcatenationMaxLength() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONFUNCTIONBUILD_H_
