#ifndef _ENGINE_METERACKNOWLEDGEDLG_H_
#define _ENGINE_METERACKNOWLEDGEDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
//}}Uses

//{{Includes
#include "UI\StaticEx.h"
#ifndef 	_UI_BITMAP_H_
#	include "Ui\Bitmap.h"
#endif	// _UI_BITMAP_H_
//}}Includes

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterAcknowledgeDlg, CDialog }}
#define CIuMeterAcknowledgeDlg_super CDialog

class CIuMeterAcknowledgeDlg : public CIuMeterAcknowledgeDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
protected:
	CIuMeterAcknowledgeDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool DoDialog(CIuMeter& Meter, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;

	CIuBitmap m_AttentionBitmap;
//}}Data

public:
	//{{AFX_DATA(CIuMeterAcknowledgeDlg)
	enum { IDD = IDD_ENGINE_METER_ACKNOWLEDGE };
	CButton	m_btnOK;
	CButton	m_btnCancel;
	CEdit	m_editYes;
	CIuStaticEx m_stReceipt;
	CString	m_sPhone;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterAcknowledgeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterAcknowledgeDlg)
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeYesEdit();
	afx_msg void OnPaint();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERACKNOWLEDGEDLG_H_
