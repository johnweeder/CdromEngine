#ifndef _ENGINE_EXPRESSIONFUNCTION_H_
#define _ENGINE_EXPRESSIONFUNCTION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

class CIuExpressionFunction;

typedef LPCTSTR (CIuExpressionFunction::*PFNFUNCTION)(const CIuRecord* pRecord) const;
typedef int (CIuExpressionFunction::*PFNFUNCTIONINT)(const CIuRecord* pRecord) const;
typedef bool (CIuExpressionFunction::*PFNFUNCTIONBOOL)(const CIuRecord* pRecord) const;
typedef int (CIuExpressionFunction::*PFNFUNCTIONMAXLENGTH)() const;
typedef CIuExpressionFunction* (*PFNFUNCTIONCREATE)();


struct CIuExpressionFunctionDef
{
	CIuExpressionType m_Type;
	LPCTSTR m_pcsz;
	PFNFUNCTION m_pfn;
	PFNFUNCTIONBOOL m_pfnBool;
	PFNFUNCTIONINT m_pfnInt;
	PFNFUNCTIONMAXLENGTH m_pfnMaxLength;
	PFNFUNCTIONCREATE m_pfnCreate;
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionFunction, CIuExpressionElement }} 
#define CIuExpressionFunction_super CIuExpressionElement

class CIuExpressionFunction : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionFunction(CIuExpressionType Type = exprFunction);
	CIuExpressionFunction(const CIuExpressionFunction& rExpressionElement);
	virtual ~CIuExpressionFunction();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static void GetFunctionNames(CStringArray& as, bool fSyntax = false);
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	static CIuExpressionFunction* CreateFunction(LPCTSTR pcsz);
	virtual LPCTSTR Evaluate(const CIuRecord*) const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionFunction& operator=(const CIuExpressionFunction& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
private:
	static const CIuExpressionFunctionDef* FindFunctionDef(LPCTSTR pcsz);
	static const CIuExpressionFunctionDef* FindFunctionDef(LPCTSTR pcsz, const CIuExpressionFunctionDef*);
	static void GetFunctionNames(CStringArray& as, bool fSyntax, const CIuExpressionFunctionDef*);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	const CIuExpressionFunctionDef* m_pFunctionDef;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONFUNCTION_H_
