#include "StdAfx.h"
//{{Include
#include "CaseConversion.h"
#include "Common\String.h"
#include "FieldDefConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

// First byte is length. The remainder of the string is a properly capitalized exception.
// This buffer is sorted and is auto-generated using code at the bottom of the file.
static LPCTSTR apcszExceptions[] =
{
	"\x03"	"0DC",
	"\x03"	"2nd",
	"\x03"	"3rd",
	"\x02"	"CA",
	"\x03"	"CPA",
	"\x03"	"DDS",
	"\x02"	"DO",
	"\x03"	"DPM",
	"\x02"	"Dr",
	"\x03"	"Dr.",
	"\x03"	"DVM",
	"\x02"	"Jr",
	"\x03"	"Jr.",
	"\x02"	"MD",
	"\x02"	"Mr",
	"\x03"	"Mr.",
	"\x03"	"Mrs",
	"\x04"	"Mrs.",
	"\x02"	"Ms",
	"\x03"	"Ms.",
	"\x02"	"NE",
	"\x02"	"NW",
	"\x02"	"OD",
	"\x02"	"PE",
	"\x03"	"PhD",
	"\x02"	"PO",
	"\x02"	"QC",
	"\x03"	"Rev",
	"\x04"	"Rev.",
	"\x02"	"RR",
	"\x02"	"SE",
	"\x02"	"Sr",
	"\x03"	"Sr.",
	"\x02"	"SW",
	0
};

static const int iExceptions = 34;

static LPCTSTR FindException(LPCTSTR pcszFind, int cbFind)
{
	int iLo = 0;
	int iHi = iExceptions - 1;
	while (iLo <= iHi)
	{
		int iTry = iLo + (iHi - iLo) / 2;

		LPCTSTR pcszTry = apcszExceptions[iTry];
		int cbTry = int(pcszTry[0]);

		int iCompare = min(cbFind, cbTry);
		int iResult = memicmp(pcszFind, pcszTry + 1, iCompare);
		if (iResult < 0)
			iHi = iTry - 1;
		else if (iResult > 0)
			iLo = iTry + 1;
		else // if (iResult == 0)
		{
			if (cbFind < cbTry)
				iHi = iTry - 1;
			else if (cbFind > cbTry)
				iLo = iTry + 1;
			else // if (cbFind == cbTry)
				return pcszTry + 1;
		}
	}
	return 0;
}

static void SynthesizeWord(LPTSTR pszWord, int cbWord)
{
	// The first alpha in any sequence of alpha within the word is capitalized
	bool fFirstAlpha = true;
	bool fLastWasDigit = false;
	for (int i = 0; i < cbWord; )
	{
		if (_istalpha(pszWord[i]))
		{
			if (fFirstAlpha)
			{
				if (fLastWasDigit)
				{
					// Watch for ordinals 1st, 2nd, 3rd, 4th, etc
					fLastWasDigit = false;
					if (((_totupper(pszWord[i]) == 'S' && _totupper(pszWord[i+1]) == 'T') ||
						  (_totupper(pszWord[i]) == 'N' && _totupper(pszWord[i+1]) == 'D') ||
						  (_totupper(pszWord[i]) == 'R' && _totupper(pszWord[i+1]) == 'D') ||
						  (_totupper(pszWord[i]) == 'T' && _totupper(pszWord[i+1]) == 'H'))  && 
						 !_istalpha(pszWord[i+2]))
					{
						pszWord[i+0] = TCHAR(_totlower(pszWord[i+0]));
						pszWord[i+1] = TCHAR(_totlower(pszWord[i+1]));
						i += 2;
					}
					else
					{
						pszWord[i] = TCHAR(_totupper(pszWord[i]));
						++i;
					}
				}
				else
				{
					pszWord[i] = TCHAR(_totupper(pszWord[i]));
					++i;
				}
				fFirstAlpha = false;
			}
			else
			{
				pszWord[i] = TCHAR(_totlower(pszWord[i]));
				++i;
			}
		}
		else if (_istdigit(pszWord[i]))
		{
			fFirstAlpha = true;
			fLastWasDigit = true;
			++i;
		}
		else
		{
			fFirstAlpha = true;
			++i;
		}
	}

	// Apostrophe followed by single alpha at the end of word is not capitalized
	if (cbWord >= 2 && pszWord[cbWord - 2] == '\'' && _istalpha(pszWord[cbWord - 1]))
		pszWord[cbWord - 1] = TCHAR(_totlower(pszWord[cbWord - 1]));
}

IU_API_EXPORT CString CaseConvert(LPCTSTR pcsz, CIuCaseConversionMode mode, int iFlags)
{
	CString s = pcsz;
	CaseConvertInPlace(s, mode, iFlags);
	return s;
}

IU_API_EXPORT void CaseConvertInPlace(CString& s, CIuCaseConversionMode mode, int iFlags)
{
	int cbBuffer = s.GetLength();
	LPTSTR pszBuffer = s.GetBuffer(cbBuffer);
	CaseConvertInPlace(pszBuffer, cbBuffer, mode, iFlags);
	s.ReleaseBuffer(cbBuffer);
}

IU_API_EXPORT void CaseConvertInPlace(LPTSTR pszBuffer, int cbBuffer, CIuCaseConversionMode mode, int iFlags)
{
#pragma __TODO("CaseConvertInPlace()")	
	// TODO: Examine iFlags for other flags, such as 'use a prefix list', or 
	// 'use an exception list'.  All such lists should be local to this file.
	// For example, in last names, do the normal case conversion, but look for
	// certain prefixes as well (Mac, Mc, et cetera).  Also. there may be a
	// list of words which should not be converted, such as professional
	// titles, et cetera.
	//
	if (pszBuffer == 0 || mode == caseNoConvert || BTEST(iFlags, fieldNoConvertCase))
		return;

	if (cbBuffer < 0)
		cbBuffer = _tcslen(pszBuffer);

	if (cbBuffer == 0)
		return ;

	if (mode == caseUpper)
	{
		for (int iOffset = 0; iOffset < cbBuffer; ++iOffset)
			pszBuffer[iOffset] = TCHAR(_totupper(pszBuffer[iOffset]));
		return;
	}
	else if (mode == caseLower)
	{
		for (int iOffset = 0; iOffset < cbBuffer; ++iOffset)
			pszBuffer[iOffset] = TCHAR(_totlower(pszBuffer[iOffset]));
		return;
	}

	ASSERT(mode == caseMixed);
	ASSERT(cbBuffer > 0);

	// Break the string into words (delimited by spaces)
	// Handle capitalization on a word-by-word basis
	// A word must start with an alpha or a digit.
	for (int iOffset = 0; iOffset < cbBuffer;)
	{
		// Skip to first al/num
		for (; iOffset < cbBuffer && !_istalnum(pszBuffer[iOffset]); ++iOffset)
			/* null */ ;

		if (pszBuffer[iOffset] == 0 || iOffset >= cbBuffer)
			break;

		// Save the start of the word
		int iStart = iOffset;

		// Skip to first space
		for (; iOffset < cbBuffer && pszBuffer[iOffset] && !_istspace(pszBuffer[iOffset]); ++iOffset)
			/* null */ ;

		// OK, we've got a word...
		// Check for exception
		int iLength = iOffset - iStart;
		LPCTSTR pcszException = FindException(pszBuffer + iStart, iLength);
		if (pcszException)
		{
			memcpy(pszBuffer + iStart, pcszException, iLength);
			continue;
		}
		// Synthesize the case for the word
		SynthesizeWord(pszBuffer + iStart, iLength);
	}
	return ;
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(CaseConversion, pv) 
{
	// To run this test, execute "test CaseConversion" in the console.
	// NOTE: You need to select your own name if you copy this code.
	UNUSED_ALWAYS(pv);

	for (int i = 0; apcszExceptions[i]; ++i)
	{
		LPCTSTR pcszException = apcszExceptions[i] + 1;
		CString s = pcszException;
		s.MakeUpper();
		CaseConvertInPlace(s, caseMixed, 0);
		ASSERT(s.Compare(pcszException) == 0);
	}

	static LPCTSTR apcszTest[] =
	{
		"TEST'D" "\0" "Test'd",
		"HELLO, HOW'S Y'ALL DOIN' MR D'AMATO JR PHD" "\0" "Hello, How's Y'All Doin' Mr D'Amato Jr PhD",
		"1ST" "\0" "1st",
		"2ND" "\0" "2nd",
		"3RD" "\0" "3rd",
		"4THA" "\0" "4Tha",
		0
	};

	for (i = 0; apcszTest[i]; ++i)
	{ 
		LPCTSTR pcsz = apcszTest[i];
		CString sResult = CaseConvert(pcsz, caseMixed, 0);
		LPCTSTR pcszExpected = _tcschr(pcsz, '\0') + 1;
		ASSERT(sResult.Compare(pcszExpected) == 0);
	}
	return 0;
}
IU_TEST_END()
#endif

#ifdef _DEBUG
#include "Interop\Test.h"
#include "Common\SortedStringArray.h"

IU_TEST_BEGIN(CaseConversionTables, pv) 
{
	// This code builds the tables for this file and writes them to the debug window
	// To run this , execute "test CaseConversionTables" in the console.
	UNUSED_ALWAYS(pv);

	// This is a list of "words" which are handled exceptionally
	static LPCTSTR apcszExceptions[] =
	{
		"SE", "NE", "SW", "NW",
		"PO", "RR", 
		"Mrs", "Mr", "Ms", "Dr", "Rev",
		"Mrs.", "Mr.", "Ms.", "Dr.", "Rev.",
		"Jr", "Sr", "2nd", "3rd",  
		"Jr.", "Sr.",
		"MD", "CPA", "PhD", "DDS", "DO", "DVM", "0DC", "PE", "OD", "DPM", "CA", "QC",
		0
	};

	CIuSortedStringArray as;
	as.SetDedup(true);
	as.SetNoCase(true);

	for (int i = 0; apcszExceptions[i]; ++i)
		as.Add(apcszExceptions[i]);

	TRACE("\n");
	TRACE("static LPCTSTR apcszExceptions[] =\n");
	TRACE("{\n");
	for (i = 0; i < as.GetSize(); ++i)
	{
		CString s = as[i];
		ASSERT(s.GetLength() <= 255);
		TRACE("\t\"\\x%02X\"\t\"%s\",\n", s.GetLength(), LPCTSTR(s));
	}
	TRACE("\t0\n");
	TRACE("};\n");
	TRACE("\n");
	TRACE("static const int iExceptions = %d;\n", as.GetSize());
	TRACE("\n");

	return 0;
}
IU_TEST_END()
#endif
