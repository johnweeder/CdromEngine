#include "StdAfx.h"
//{{Include
#include "InputAreaCode.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputAreaCode, CIuInputAreaCode_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputAreaCode)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTAREACODE, CIuInputAreaCode, CIuInputAreaCode_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputAreaCode, IDS_ENGINE_PPG_INPUTAREACODE, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputAreaCode::CIuInputAreaCode() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputAreaCode::~CIuInputAreaCode()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputAreaCode::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input AreaCode"));
	SetInputFilename("AreaCode");
	SetOutputFilename("AreaCode");
	SetFormat(inputAreaCode);
	//}}Initialize
}

bool CIuInputAreaCode::OnProcess()
{
	LPCTSTR pcszAreaCode			= GetInput(0);
	LPCTSTR pcszAreaCodeName	= GetInput(1);
	SetField(inputFieldAreaCode, pcszAreaCode);
	SetField(inputFieldAreaCodeName,	pcszAreaCodeName);
	return Output();
}
