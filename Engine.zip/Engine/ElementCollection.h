#ifndef _ENGINE_ELEMENTCOLLECTION_H_
#define _ENGINE_ELEMENTCOLLECTION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_STRINGHEAP_H_
#	include "Common\StringHeap.h"
#endif	// _COMMON_STRINGHEAP_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuElementCollection)
class CIuElement;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuElementCollection, CIuObjectNamed }}
#define CIuElementCollection_super CIuObjectNamed

class CIuElementCollection : public CIuElementCollection_super
{
//{{Declare
	DECLARE_SERIAL(CIuElementCollection)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuElementCollection();
	virtual ~CIuElementCollection();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	int GetHashSize() const;
	CIuStringHeap& GetHeap() const;
	CIuElement* GetSorted(int iWhich) const;
	int GetSortedCount() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuElement* Add(LPCTSTR pcszName);
	virtual CIuElement* AddBlank(int iCount = 1);
	virtual void Clear();
	bool Compress(CIuBuffer& Buffer, int& iCount, CIuOutput& Output);
	virtual CIuElement* Create(LPCTSTR pcszName = 0);
	static int DeCompress(const BYTE* pb, int cb, CArray<LPCTSTR, LPCTSTR>& aStrings, int iStrings);
	void Dump(CIuOutput& Output);
	virtual void Empty();
	int FindSorted(LPCTSTR pcszName) const;
	void SetCount(int);
	void SetHashSize(int);
	void SortByCountDecreasing();
	void SortByName();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	bool GetGridInfo(int iRq, CIuGridRq& rq);
private:
	void AllocateMap(int iHashSize);
	void CommonConstruct();
	CString GetGridElement(int iRow, int iCol) const;
	void Sort();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	CArray<CIuElement*, CIuElement*> m_ElementMap;
private:
	CArray<CIuElement*, CIuElement*> m_ElementArray;
	int m_iHashSize;
	int m_iCount;
	mutable CIuStringHeap m_Heap;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuElementCollection::GetCount() const
{
	return m_iCount;
}

inline int CIuElementCollection::GetHashSize() const
{
	return m_iHashSize;
}

inline CIuStringHeap& CIuElementCollection::GetHeap() const
{
	return m_Heap;
}

#endif // _ENGINE_ELEMENTCOLLECTION_H_
