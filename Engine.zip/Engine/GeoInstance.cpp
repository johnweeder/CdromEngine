#include "StdAfx.h"
//{{Include
#include "GeoInstance.h"
#include "Common\Clean.h"
#include "Interop\Conversions.h"
#include "Common\Buffer.h"
#include "resource.h"
#include "GeoMap.h"
#include "RecordDef.h"
#include "FieldDefConst.h"
#include "Common\StaticBuffer.h"
#include "StatesRaw.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoInstance, CIuGeoInstance_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoInstance)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOINSTANCE, CIuGeoInstance, CIuGeoInstance_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoInstance, IDS_ENGINE_PPG_GEOINSTANCE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIP, GetZip, SetZip, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIP, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIPADDON, GetZipAddon, SetZipAddon, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIPADDON, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIPDPBC, GetZipDpbc, SetZipDpbc, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_ZIPDPBC, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_STATEABBR, GetStateAbbr, SetStateAbbr, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_STATEABBR, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_STATECODE, GetStateCode, SetStateCode, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_STATECODE, IDS_ENGINE_PPG_GEOINSTANCE, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_STATENAME, GetStateName, SetStateName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_STATENAME, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_CITY, GetCity, SetCity, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_CITY, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_MSACODE, GetMsaCode, SetMsaCode, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_MSACODE, IDS_ENGINE_PPG_GEOINSTANCE, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_MSANAME, GetMsaName, SetMsaName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_MSANAME, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_COUNTYCODE, GetCountyCode, SetCountyCode, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_COUNTYCODE, IDS_ENGINE_PPG_GEOINSTANCE, 0, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_COUNTYNAME, GetCountyName, SetCountyName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_COUNTYNAME, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_LATITUDE, GetLatitudeAsString, SetLatitudeAsString, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_LATITUDE, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoInstance, IDS_ENGINE_PROP_LONGITUDE, GetLongitudeAsString, SetLongitudeAsString, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoInstance, IDS_ENGINE_PROP_LONGITUDE, IDS_ENGINE_PPG_GEOINSTANCE, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_MATCHLEVEL, GetMatchLevel, SetMatchLevel, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_MATCHLEVEL, IDS_ENGINE_PPG_GEOINSTANCE, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_MEDIANHOMEVALUE, GetMedianHomeValue, SetMedianHomeValue, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_MEDIANHOMEVALUE, IDS_ENGINE_PPG_GEOINSTANCE, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoInstance, IDS_ENGINE_PROP_MEDIANINCOME, GetMedianIncome, SetMedianIncome, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoInstance, IDS_ENGINE_PROP_MEDIANINCOME, IDS_ENGINE_PPG_GEOINSTANCE, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoInstance::CIuGeoInstance() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoInstance::~CIuGeoInstance()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoInstance::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sZip = "00000";
	m_sCity = "";
	m_sStateAbbr = "";
	m_sStateName = "";
	m_sMsaName = "";
	m_sCountyName = "";
	m_iStateCode = 0;
	m_iCountyCode = 0;
	m_iMsaCode = 0;
	m_sZipAddon = "";
	m_sZipDpbc = "";
	m_iMedianHomeValue = 0;
	m_iMedianIncome = 0;
	m_iMatchLevel = latlongUnknown;
	//}}Initialize
}


void CIuGeoInstance::Get(CIuBuffer& output) const
{
	// For performance reasons, we access variables directly
	TCHAR szZip[12+1];
	_tcscpy(szZip, m_sZip);
	if (_tcscmp(m_sZipAddon, "0000") != 0)
	{
		_tcscat(szZip, m_sZipAddon);
		if (_tcscmp(m_sZipDpbc, "000") != 0)
			_tcscat(szZip, m_sZipDpbc);
	}

	TCHAR sz[50];

	ASSERT(_tcslen(szZip) < sizeof(szZip));
	output.Append((const BYTE*)szZip);
	output.Append(m_sCity);
	output.Append(m_sStateAbbr);
	GetStateCodeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	output.Append(m_sStateName);
	GetMsaCodeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	output.Append(m_sMsaName);
	GetCountyCodeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	output.Append(m_sCountyName);
	GetLatitudeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	GetLongitudeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	GetMedianHomeValueAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
	GetMedianIncomeAsString(sz, sizeof(sz));
	output.Append((const BYTE*)sz);
}

void CIuGeoInstance::GetCountyCodeAsString(LPTSTR psz, int cb) const
{
	ASSERT(psz && cb > 0);
	if (GetCountyCode() == 0)
		psz[0] = '\0';
	else 
		IntAsStringEx(psz, cb, GetCountyCode(), 10, 5, 5, true);
}

CString CIuGeoInstance::GetCountyCodeAsString() const
{
	TCHAR sz[50];
	GetCountyCodeAsString(sz, sizeof(sz));
	return CString(sz);
}

void CIuGeoInstance::GetLatitudeAsString(LPTSTR psz, int cb) const
{
	GetLatitude().AsString(psz, cb);
}

CString CIuGeoInstance::GetLatitudeAsString() const
{
	return GetLatitude().AsString();
}

void CIuGeoInstance::GetLongitudeAsString(LPTSTR psz, int cb) const
{
	GetLongitude().AsString(psz, cb);
}

CString CIuGeoInstance::GetLongitudeAsString() const
{
	return GetLongitude().AsString();
}

void CIuGeoInstance::GetMedianHomeValueAsString(LPTSTR psz, int cb) const
{
	ASSERT(psz && cb > 0);
	if (GetMedianHomeValue() == 0)
		psz[0] = '\0';
	else
		IntAsStringEx(psz, cb, GetMedianHomeValue(), 10, -1, -1, false);
}

CString CIuGeoInstance::GetMedianHomeValueAsString() const
{
	TCHAR sz[50];
	GetMedianHomeValueAsString(sz, sizeof(sz));
	return CString(sz);
}

void CIuGeoInstance::GetMedianIncomeAsString(LPTSTR psz, int cb) const
{
	ASSERT(psz && cb > 0);
	if (GetMedianIncome() == 0)
		psz[0] = '\0';
	else
		IntAsStringEx(psz, cb, GetMedianIncome(), 10, -1, -1, false);
}

CString CIuGeoInstance::GetMedianIncomeAsString() const
{
	TCHAR sz[50];
	GetMedianIncomeAsString(sz, sizeof(sz));
	return CString(sz);
}

void CIuGeoInstance::GetMsaCodeAsString(LPTSTR psz, int cb) const
{
	ASSERT(psz && cb > 0);
	if (GetMsaCode() == 0)
		psz[0] = '\0';
	else
		IntAsStringEx(psz, cb, GetMsaCode(), 10, 4, 4, true);
}

CString CIuGeoInstance::GetMsaCodeAsString() const
{
	TCHAR sz[50];
	GetMsaCodeAsString(sz, sizeof(sz));
	return CString(sz);
}

CString CIuGeoInstance::GetStateCity() const
{
	return m_sStateCity;
}

void CIuGeoInstance::GetStateCodeAsString(LPTSTR psz, int cb) const
{
	ASSERT(psz && cb > 0);
	if (GetStateCode() == 0)
		psz[0] = '\0';
	else
		IntAsStringEx(psz, cb, GetStateCode(), 10, 2, 2, true);
}

CString CIuGeoInstance::GetStateCodeAsString() const
{
	TCHAR sz[50];
	GetStateCodeAsString(sz, sizeof(sz));
	return CString(sz);
}

void CIuGeoInstance::MakeRecordDef(CIuRecordDef& RecordDef)
{
	RecordDef.AddFieldDef(_T("=ZIP"));
	RecordDef.AddFieldDef(_T("=City"));
	RecordDef.AddFieldDef(_T("=StateAbbr"));
	RecordDef.AddFieldDef(_T("=StateCode"));
	RecordDef.AddFieldDef(_T("=StateName"));
	RecordDef.AddFieldDef(_T("=MsaCode"));
	RecordDef.AddFieldDef(_T("=MsaName"));
	RecordDef.AddFieldDef(_T("=CountyCode"));
	RecordDef.AddFieldDef(_T("=CountyName"));
	RecordDef.AddFieldDef(_T("=Latitude"));
	RecordDef.AddFieldDef(_T("=Longitude"));
	RecordDef.AddFieldDef(_T("=MedianHV"));
	RecordDef.AddFieldDef(_T("=MedianIncome"));
}

void CIuGeoInstance::Set(const CIuRecord& Record, const CIuGeoMap& Map)
{
	Map.Set(m_pRecord, Record);

	Clear();

	CIuStaticBuffer256 Buffer;

	Clean(Buffer, m_pRecord->GetField(Map.m_iZip), cleanNumeric|cleanTrim|cleanAllowEmpty|cleanRightJustify|cleanPadZero, 5);
	SetZip4(Buffer);

	Clean(Buffer, m_pRecord->GetField(Map.m_iCity), cleanTrim|cleanTruncateLeft, fieldDftLength);
	SetCity(Buffer);

	Clean(Buffer, m_pRecord->GetField(Map.m_iState), cleanTrim|cleanTruncateLeft, 2);
	const CIuStatesRaw* pState = CIuStatesRaw::FindMaster(Buffer);
	if (pState)
	{
		SetStateAbbr(pState->m_pcszAbbr);
		SetStateCode(pState->m_iCode);
		SetStateName(pState->m_pcszName);
	}
	else
	{
		TRACE("WARNING: Unknown state [%s]\n", m_pRecord->GetField(Map.m_iState));
		ASSERT(false);
		SetStateAbbr("");
		SetStateCode(0);
		SetStateName("");
	}

	SetMsaCodeAsString(m_pRecord->GetField(Map.m_iMsaCode));
	SetCountyCodeAsString(m_pRecord->GetField(Map.m_iCountyCode));
	SetLatitudeAsString(m_pRecord->GetField(Map.m_iLatitude));
	SetLongitudeAsString(m_pRecord->GetField(Map.m_iLongitude));
	LPCTSTR pcszMatchLevel = m_pRecord->GetField(Map.m_iMatchLevel);
	switch (*pcszMatchLevel)
	{
		case '0':
			SetMatchLevel(latlongStreet);
			break;
		case '4':
			SetMatchLevel(latlongZip4);
			break;
		case '2':		
			SetMatchLevel(latlongZip2);
			break;
		case 'X':
			SetMatchLevel(latlongZip);
			break;
		case '\0':
			SetMatchLevel(latlongNone);
			break;
		default:
#ifdef _DEBUG
			TRACE("WARNING: Unrecognized match level 0x%02X\n", *pcszMatchLevel);
#endif
			SetMatchLevel(latlongUnknown);
			break;
	}

	m_sStateCity = GetStateAbbr();
	if (m_sStateCity.IsEmpty())
		m_sStateCity = _T("  ");
	m_sStateCity += GetCity();
	if (m_iCountyCode != 0 && m_iCountyCode < 1000)
		m_iCountyCode += m_iStateCode * 1000;
}

void CIuGeoInstance::SetCity(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCity = pcsz;
}

void CIuGeoInstance::SetCountyCode(int iCountyCode)
{
	m_iCountyCode = iCountyCode;
}

void CIuGeoInstance::SetCountyCodeAsString(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_iCountyCode = StringAsInt(pcsz);
}

void CIuGeoInstance::SetCountyName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCountyName = pcsz;
}

void CIuGeoInstance::SetLatitude(CIuLatLongUnit latitude)
{
	m_Latitude = latitude;
}

void CIuGeoInstance::SetLatitudeAsString(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_Latitude = pcsz;
}

void CIuGeoInstance::SetLongitude(CIuLatLongUnit longitude)
{
	m_Longitude = longitude;
}

void CIuGeoInstance::SetLongitudeAsString(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_Longitude = pcsz;
}

void CIuGeoInstance::SetMatchLevel(int iMatchLevel)
{
	m_iMatchLevel = iMatchLevel;
}

void CIuGeoInstance::SetMedianHomeValue(int iMedianHomeValue)
{
	m_iMedianHomeValue = iMedianHomeValue;
}

void CIuGeoInstance::SetMedianIncome(int iMedianIncome)
{
	m_iMedianIncome = iMedianIncome;
}

void CIuGeoInstance::SetMsaCode(int iMsaCode)
{
	m_iMsaCode = iMsaCode;
}

void CIuGeoInstance::SetMsaCodeAsString(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_iMsaCode = StringAsInt(pcsz);
}

void CIuGeoInstance::SetMsaName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMsaName = pcsz;
}

void CIuGeoInstance::SetStateAbbr(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sStateAbbr = pcsz;
}

void CIuGeoInstance::SetStateCode(int iStateCode)
{
	m_iStateCode = iStateCode;
}

void CIuGeoInstance::SetStateName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sStateName = pcsz;
}

void CIuGeoInstance::SetZip(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sZip = pcsz;
}

void CIuGeoInstance::SetZip4(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));

	TCHAR szZip[12+1];
	_tcsncpy(szZip, pcsz, 12);
	szZip[12] = '\0';

	int iLength = _tcslen(szZip);
	if (iLength > 9)
	{
		m_sZipDpbc = szZip + 9;
		szZip[9] = '\0';
	}
	else
		m_sZipDpbc = "";

	if (iLength > 5)
	{
		m_sZipAddon = szZip + 5;
		szZip[5] = '\0';
	}
	else
		m_sZipAddon = "";
	m_sZip = szZip;
}

void CIuGeoInstance::SetZipAddon(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sZipAddon = pcsz;
}

void CIuGeoInstance::SetZipDpbc(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sZipDpbc = pcsz;
}
