#ifndef _ENGINE_FIELDLIST_H_
#define _ENGINE_FIELDLIST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
#ifndef 	_ENGINE_EXPRESSION_H_
#	include "Engine\Expression.h"
#endif	// _ENGINE_EXPRESSION_H_
#ifndef 	_ENGINE_RECORDSPEC_H_
#	include "Engine\RecordSpec.h"
#endif	// _ENGINE_RECORDSPEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldList)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldList, CIuFieldMap }}
#define CIuFieldList_super CIuFieldMap

class IU_CLASS_EXPORT CIuFieldList : public CIuFieldList_super
{
//{{Declare
	DECLARE_SERIAL(CIuFieldList)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldList();           // protected constructor used by dynamic creation
	virtual ~CIuFieldList();
	CIuFieldList(const CIuFieldList&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetBegin() const;
	CString GetEnd() const;
	CString GetSeparator() const;
	CString GetTerminator() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	LPCTSTR Evaluate(CIuRecord* pRecord);
	virtual void Copy(const CIuObject& object);
	void SetBegin(LPCTSTR);
	void SetEnd(LPCTSTR);
	void SetSeparator(LPCTSTR);
	void SetTerminator(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldList& operator=(const CIuFieldList&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// This buffer is used to contain the result from evaluate().
	// It is part of the class so that we don't keep re-evaluating it.
	CIuRecordSpec m_Spec;
	CIuBuffer m_Buffer;
	// Other information for building the field list
	CString m_sTerminator;
	CString m_sSeparator;
	CString m_sBegin;
	CString m_sEnd;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuFieldList::GetBegin() const
{
	return m_sBegin;
}

inline CString CIuFieldList::GetEnd() const
{
	return m_sEnd;
}

inline CString CIuFieldList::GetSeparator() const
{
	return m_sSeparator;
}

inline CString CIuFieldList::GetTerminator() const
{
	return m_sTerminator;
}

#endif // _ENGINE_FIELDLIST_H_
