#ifndef _ENGINESUPPORT_DATABASELISTEDITOR_H_
#define _ENGINESUPPORT_DATABASELISTEDITOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_UI_LISTBOXEDITOR_H_
#	include "Ui\ListBoxEditor.h"
#endif	// _UI_LISTBOXEDITOR_H_
#ifndef 	_ENGINE_DATABASELIST_H_
#	include "Engine\DatabaseList.h"
#endif	// _ENGINE_DATABASELIST_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDatabaseListEditor, CIuListBoxEditor }}
#define CIuDatabaseListEditor_super CIuListBoxEditor

class IU_CLASS_EXPORT CIuDatabaseListEditor : public CIuDatabaseListEditor_super
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDatabaseListEditor();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Initialize(UINT uiID, CWnd* pwndParent, CIuDatabaseList& DatabaseList);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
protected:
	virtual bool OnAdd(int iIndex, CString& sValue);
	virtual bool OnBrowse(int iIndex, CString& s, DWORD& dw);
	virtual bool OnDelete(int iIndex);
	virtual bool OnDrag(int iDst, int iSrc);
public:
	virtual void OnLoad();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuDatabaseListPtr m_pDatabaseList;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINESUPPORT_DATABASELISTEDITOR_H_
