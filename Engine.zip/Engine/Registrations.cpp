#include "StdAfx.h"
//{{Include
#include "Registrations.h"
#include "Registration.h"
#include "resource.h"
#include "CdromSpecConst.h"
#include "Engine.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRegistrations, CIuRegistrations_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRegistrations)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REGISTRATIONS, CIuRegistrations, CIuRegistrations_super)
//{{AttributeMap
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuRegistrations, IDS_ENGINE_PPG_REGISTRATIONS, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PAGE(CIuRegistrations, IDS_ENGINE_PPG_REGISTRATIONS, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRegistrations::CIuRegistrations() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRegistrations::~CIuRegistrations()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRegistrations::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuRegistrations::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuRegistrationPtr pRegistration = dynamic_cast<CIuRegistration*>(pCollectable.Ptr());
	GetEngine().QueryObject(collectionRegistrations, Descriptor, *pRegistration);
}

CIuCollectablePtr CIuRegistrations::OnNew(CWnd*) const
{
	CIuRegistrationPtr pRegistration;
	pRegistration.Create();
	ASSERT(m_pEngine != 0);
	pRegistration->SetEngine(GetEngine());
	return pRegistration;
}

void CIuRegistrations::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuRegistrations::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	for (int iRegistration = 0; iRegistration < GetCount(); ++iRegistration)
		Get(iRegistration).SetObjectRepository(pObjectRepository);
}
