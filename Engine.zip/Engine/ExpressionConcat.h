#ifndef _ENGINE_EXPRESSIONCONCAT_H_
#define _ENGINE_EXPRESSIONCONCAT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionConcat, CIuExpressionElement }} 
#define CIuExpressionConcat_super CIuExpressionElement

class CIuExpressionConcat : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionConcat();
	CIuExpressionConcat(const CIuExpressionConcat& rExpressionElement);
	virtual ~CIuExpressionConcat();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual LPCTSTR Evaluate(const CIuRecord*) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionConcat& operator=(const CIuExpressionConcat& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONCONCAT_H_
