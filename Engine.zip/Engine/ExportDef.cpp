#include "stdafx.h" 
//{{Include
#include "Engine.h"
#include "CdromSpecConst.h"
#include "ExportDef.h"
#include "ExportDefSpec.h"
#include "ExportDefs.h"
#include "Exporters.h"
#include "resource.h"
#include "Error\Error.h"
#include "Cdrom.h"
#include "..\Data\resource.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportDef, CIuExportDef_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportDef)
const	CIuVersionNumber versionExportDefMax(2000,1,5,304);
const	CIuVersionNumber versionExportDefMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTDEF, CIuExportDef, CIuExportDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuExportDef, IDS_ENGINE_PROP_FIELDDEFS, GetFieldDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuExportDef, IDS_ENGINE_PROP_FIELDDEFS, 0)

	IU_ATTRIBUTE_LIST_BEGIN(CIuExportDef, IDS_ENGINE_ENUM_EXPORTDEFTYPE)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_ENUM_FIXED,		exportDefTypeFixed)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_ENUM_CUSTOM,		exportDefTypeCustom)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_ENUM_ALL,			exportDefTypeAll)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_ENUM_DEFAULT,	exportDefTypeDefault)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_ENUM_USER,		exportDefTypeUser)
	IU_ATTRIBUTE_LIST_END()

	IU_ATTRIBUTE_PAGE(CIuExportDef, IDS_ENGINE_PPG_EXPORTDEF, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportDef, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportDef, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_EXPORTDEF, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportDef, IDS_ENGINE_PROP_DESCRIPTION, GetDescription, SetDescription, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportDef, IDS_ENGINE_PROP_DESCRIPTION, IDS_ENGINE_PPG_EXPORTDEF, 5, editorMultiLine)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportDef, IDS_ENGINE_PROP_EXTENSION, GetExtension, SetExtension, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportDef, IDS_ENGINE_PROP_EXTENSION, IDS_ENGINE_PPG_EXPORTDEF, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportDef, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExportDef, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_EXPORTDEF, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExportDef, IDS_ENGINE_PROP_EXPORTER, GetExporter, SetExporter, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuExportDef, IDS_ENGINE_PROP_EXPORTER, IDS_ENGINE_PPG_EXPORTDEF, 0)
	IU_ATTRIBUTE_EDITOR_ALLOWED_VALUES(CIuExportDef, IDS_ENGINE_PROP_EXPORTER, GetExporterAllowed, 0)
	IU_ATTRIBUTE_PROPERTY_ENUM(CIuExportDef, IDS_ENGINE_PROP_TYPE, IDS_ENGINE_ENUM_EXPORTDEFTYPE, GetType, SetType, 0)
	IU_ATTRIBUTE_EDITOR_ENUM_COMBO(CIuExportDef, IDS_ENGINE_PROP_TYPE, IDS_ENGINE_PPG_EXPORTDEF, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExportDef, IDS_ENGINE_PROP_RECORDLENGTH, GetRecordLength, SetRecordLength, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExportDef, IDS_ENGINE_PROP_RECORDLENGTH, IDS_ENGINE_PPG_EXPORTDEF, -1, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuExportDef, IDS_ENGINE_PROP_CUSTOM, IsCustom, SetCustom, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuExportDef, IDS_ENGINE_PROP_CUSTOM, IDS_ENGINE_PPG_EXPORTDEF, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP() 


CIuExportDef::CIuExportDef()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportDef::CIuExportDef(const CIuExportDef& rExportDef)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rExportDef;
}

CIuExportDef::~CIuExportDef()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuExportDef::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

void CIuExportDef::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pFieldDefs.IsNull())
	{
		m_pFieldDefs.Create();
		m_pFieldDefs->SetExportDef(const_cast<CIuExportDef*>(this));
	}
	m_enumType = exportDefTypeFixed;
	m_sExtension.Empty();
	m_sExporter.Empty();
	m_sOptions = "";
	m_iRecordLength = -1;
	m_fCustom = false;
	m_pObjectRepository = 0;
	SetVersion(versionExportDefMax);
	//}}Initialize
}

void CIuExportDef::Copy(const CIuObject& object)
{
	CIuExportDef_super::Copy(object);

	const CIuExportDef* pExportDef = dynamic_cast<const CIuExportDef*>(&object);
	if (pExportDef == 0 || pExportDef == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuExportDef)));
	
	GetFieldDefs().Copy(pExportDef->GetFieldDefs());
	SetExporter(pExportDef->GetExporter());
	SetDescription(pExportDef->GetDescription());
	SetExtension(pExportDef->GetExtension());
	SetType(pExportDef->GetType());
	SetOptions(pExportDef->GetOptions());
	SetTitle(pExportDef->GetTitle());
}

int CIuExportDef::CreateFieldDef(LPCTSTR pcszDef)
{
	return GetFieldDefs().CreateFieldDef(pcszDef);
}

int CIuExportDef::CreateFieldDef(CIuExportFieldDefSpec& spec)
{
	return GetFieldDefs().CreateFieldDef(spec);
}

CIuExportDefs& CIuExportDef::GetExportDefs() const
{
	CIuExportDefs* pParent = dynamic_cast<CIuExportDefs*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CString CIuExportDef::GetExporter() const
{
	return m_sExporter;
}

void CIuExportDef::GetExporterAllowed(CStringArray& as) const
{
	if (HasExportDefs() && GetExportDefs().HasEngine())
		GetExportDefs().GetEngine().GetExporters().GetCollectionNames(as);
}

CIuExportFieldDefs& CIuExportDef::GetFieldDefs() const
{
	return m_pFieldDefs.Ref();
}

CIuObject* CIuExportDef::GetFieldDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pFieldDefs.Ptr()));
}

CString CIuExportDef::GetExtension() const
{
	return m_sExtension;
}

int CIuExportDef::GetType() const
{
	return m_enumType;
}

CIuVersionNumber CIuExportDef::GetVersionMax() const
{
	return versionExportDefMax;
}

CIuVersionNumber CIuExportDef::GetVersionMaxStatic()
{
	return versionExportDefMax;
}

CIuVersionNumber CIuExportDef::GetVersionMin() const
{
	return versionExportDefMin;
}

CIuVersionNumber CIuExportDef::GetVersionMin() 
{
	return versionExportDefMin;
}

CIuVersionNumber CIuExportDef::GetVersionMinStatic()
{
	return versionExportDefMin;
}

bool CIuExportDef::IsRefreshable() const
{
	// Don't refresh custom formats. 
	return !IsCustom();
}

CIuExportDef& CIuExportDef::operator=(const CIuExportDef& rExportDef)
{
	Copy(rExportDef);
	return *this;
}

void CIuExportDef::SetCustom(bool f)
{
	m_fCustom = f;
}

void CIuExportDef::SetExporter(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExporter = pcsz;
}

void CIuExportDef::SetExtension(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExtension = pcsz;
}

void CIuExportDef::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuExportDef::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuExportDef::SetSpec(CIuExportDefSpec& ExportDefSpec)
{
	Clear();

	SetMoniker(ExportDefSpec.GetMoniker());
	SetTitle(ExportDefSpec.GetTitle());
	SetDescription(ExportDefSpec.GetDescription());
	SetExporter(ExportDefSpec.GetExporter());
	SetExtension(ExportDefSpec.GetExtension());
	SetOptions(ExportDefSpec.GetOptions());
	SetType(ExportDefSpec.GetType());
	SetRecordLength(ExportDefSpec.GetRecordLength());

	GetFieldDefs().SetSpec(ExportDefSpec);
}

void CIuExportDef::SetRecordLength(int iRecordLength)
{
	m_iRecordLength = iRecordLength;
}

void CIuExportDef::SetType(int enm)
{
	m_enumType = enm;
}
