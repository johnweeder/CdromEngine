#ifndef _ENGINE_CHARACTERFREQUENCYSTATISTICS_H_
#define _ENGINE_CHARACTERFREQUENCYSTATISTICS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_COMMAND_H_
#	include "Data\Command.h"
#endif	// _DATA_COMMAND_H_
#ifndef 	_COMMON_FILENAME_H_
#	include "Common\Filename.h"
#endif	// _COMMON_FILENAME_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCharacterFrequencyStatistics, CIuCharacterFrequencyStatistics_super }}

#define CIuCharacterFrequencyStatistics_super CIuCommand

class CIuCharacterFrequencyStatistics : public CIuCharacterFrequencyStatistics_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuCharacterFrequencyStatistics)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCharacterFrequencyStatistics();
	CIuCharacterFrequencyStatistics(const CIuCharacterFrequencyStatistics&);
	virtual ~CIuCharacterFrequencyStatistics();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetFilename() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	void SetFilename(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnRun();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void PartialClear(int iSize = 10 * 1024 * 1024);
	void UpdateMap(unsigned __int32 uiWord);
	void UpdateMap2(unsigned __int32 uiWord);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	CIuFilename m_sFilename;
	CIuMapInt32ToInt32 m_map;
//}}Data
};

IU_DEFINE_OBJECT_PTR(CIuCharacterFrequencyStatistics)

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_CHARACTERFREQUENCYSTATISTICS_H_
