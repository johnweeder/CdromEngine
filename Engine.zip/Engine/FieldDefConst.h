#ifndef _ENGINE_FIELDDEFCONST_H_
#define _ENGINE_FIELDDEFCONST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Predefined fields names
extern const TCHAR szFieldKey[];
extern const TCHAR szFieldAlt[];
extern const TCHAR szFieldSeeAlso[];
extern const TCHAR szFieldRecordNo[];
extern const TCHAR szFieldSourceNo[];
extern const TCHAR szFieldExpandNo[];
extern const TCHAR szFieldCount[];
extern const TCHAR szFieldLatitude[];
extern const TCHAR szFieldLongitude[];
extern const TCHAR szFieldTagged[];
extern const TCHAR szFieldBought[];
extern const TCHAR szFieldNoMail[];
extern const TCHAR szFieldNoPhone[];
extern const TCHAR szFieldSicName[];
extern const TCHAR szFieldFranchiseName[];
extern const TCHAR szFieldYearsInDb[];
extern const TCHAR szFieldBusiness[];
extern const TCHAR szFieldResidence[];
extern const TCHAR szFieldBusResFlag[];

/////////////////////////////////////////////////////////////////////////////
// Predefined fields
enum CIuFieldDefNo
{
	fieldAcPhone,
	fieldAddOn,
	fieldAddress,
	fieldAdSizeCode,
	fieldAdSizeCode2,
	fieldAdSizeCode3,
	fieldAdSizeCode4,
	fieldAdSizeCode5,
	fieldAdSizeCode6,
	fieldAlt,
	fieldAlternates,
	fieldAreaCode,
	fieldAreaCodeName,
	fieldBlockGroup,
	fieldBought,
	fieldBusiness,
	fieldBusResFlag,
	fieldCarrierRoute,
	fieldCensusTract,
	fieldCity,
	fieldCityState,
	fieldCompany,
	fieldContact,
	fieldContactFirst,
	fieldContactLast,
	fieldCount,
	fieldCountMatched,
	fieldCountNotMatched,
	fieldCountTotal,
	fieldCountyCode,
	fieldCountyName,
	fieldCrLf,
	fieldDPBC,
	fieldEmployeeSizeCode,
	fieldExchange,
	fieldExchangeName,
	fieldExpandNo,
	fieldFaxAcPhone,
	fieldFaxAreaCode,
	fieldFaxPhone,
	fieldFirst,
	fieldFirstYear,
	fieldFirstYear2,
	fieldFirstYear3,
	fieldFirstYear4,
	fieldFirstYear5,
	fieldFirstYear6,
	fieldFranchiseCode,
	fieldFranchiseCode2,
	fieldFranchiseCode3,
	fieldFranchiseCode4,
	fieldFranchiseCode5,
	fieldFranchiseCode6,
	fieldFranchiseName,
	fieldFranchiseName2,
	fieldFranchiseName3,
	fieldFranchiseName4,
	fieldFranchiseName5,
	fieldFranchiseName6,
	fieldFranchises,
	fieldGen,
	fieldGender,
	fieldHighRise,
	fieldKey,
	fieldLast,
	fieldLatitude,
	fieldLf,
	fieldLongitude,
	fieldMatchLevel,
	fieldMedianHV,
	fieldMedianIncome,
	fieldMiddleName,
	fieldMsaCode,
	fieldMsaName,
	fieldName,
	fieldNickName,
	fieldNoMail,
	fieldNoPhone,
	fieldNoSolicitation,
	fieldPhone,
	fieldPhoneType,
	fieldPostDir,
	fieldPreDir,
	fieldPrefix,
	fieldPriNo,
	fieldProSuffix,
	fieldPubDate,
	fieldRecordID,
	fieldRecordNo,
	fieldResidence,
	fieldSalesVolumeCode,
	fieldSecNo,
	fieldSeeAlso,
	fieldSicCode,
	fieldSicCode2,
	fieldSicCode3,
	fieldSicCode4,
	fieldSicCode5,
	fieldSicCode6,
	fieldSicCount,
	fieldSicFranchiseCode,
	fieldSicName,
	fieldSicName2,
	fieldSicName3,
	fieldSicName4,
	fieldSicName5,
	fieldSicName6,
	fieldSicPreferred,
	fieldSourceNo,
	fieldSpouseFirst,
	fieldSpouseGen,
	fieldSpouseLast,
	fieldSpouseMiddleName,
	fieldSpouseNickName,
	fieldSpouseProSuffix,
	fieldSpouseTitle,
	fieldStateAbbr,
	fieldStateCity,
	fieldStateCode,
	fieldStateName,
	fieldStreet,
	fieldStreetName,
	fieldSubUrbanCity,
	fieldSuffix,
	fieldTagged,
	fieldTitle,
	fieldTollFreeAcPhone,
	fieldTollFreeAreaCode,
	fieldTollFreePhone,
	fieldToken,
	fieldUnknown1,
	fieldUnknown2,
	fieldWebSite,
	fieldYearsInDb,
	fieldYearsInDb2,
	fieldYearsInDb3,
	fieldYearsInDb4,
	fieldYearsInDb5,
	fieldYearsInDb6,
	fieldYPPANO,
	fieldZip,
	fieldZip5,
};

/////////////////////////////////////////////////////////////////////////////
// Some flags
// When adding a flag, you must update the attributes in FieldDefSpec.cpp
//	and in FieldDef.cpp
const __int32 fieldSortNumeric			= 0x00000001;
const __int32 fieldNumeric					= 0x00000002;	// Used as an indicator to
																		// the compressor that field
																		// is primarily numeric	 (consists of digits)
const __int32 fieldNoConvertCase			= 0x00000004;	// Don't perform case conversion on field

/////////////////////////////////////////////////////////////////////////////
// Special id's representing the field number in the input
// record set
const int specFieldNoDiscard		= -1;		// Field is discarded
const int specFieldNoUnknown		= -2;		// Field is unknown
const int specFieldNoLiteral		= -3;		// Field is a literal
const int specFieldNoExpression	= -4;		// Field is an expression

const int specFieldNoSpecial		= -100;
const int specFieldNoKey			= -101;		// Field is the "key" field
const int specFieldNoAlt			= -102;
const int specFieldNoSeeAlso		= -103;
const int specFieldNoRecordNo		= -104;
const int specFieldNoSourceNo		= -105;
const int specFieldNoExpandNo		= -106;
const int specFieldNoCount			= -107;
const int specFieldNoLatitude		= -108;
const int specFieldNoLongitude	= -109;
const int specFieldNoTagged		= -110;
const int specFieldNoBought		= -111;
const int specFieldNoNoMail		= -112;
const int specFieldNoNoPhone		= -113;
const int specFieldNoBusiness		= -114;
const int specFieldNoResidence	= -115;
const int specFieldNoBusResFlag	= -116;

// The engine sometimes uses static internal buffers as a performance 
// enhancement. This constant controls the size of those buffers. You 
// can increase this if needed.
const int fieldDftLength = 255;

// This controls the maximum bought level for a record. The size is primarily
// limited by the number of bits allocated to a bought level in a raw record.
const int boughtMaxLevel = 15;

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_FIELDDEFCONST_H_
