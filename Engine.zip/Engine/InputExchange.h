#ifndef _ENGINE_INPUTEXCHANGE_H_
#define _ENGINE_INPUTEXCHANGE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTDELIMITED_H_
#	include "Engine\InputDelimited.h"
#endif	// _ENGINE_INPUTDELIMITED_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputExchange)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputExchange, CIuInputDelimited }}
#define CIuInputExchange_super CIuInputDelimited

class CIuInputExchange : public CIuInputExchange_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputExchange)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputExchange();
	virtual ~CIuInputExchange();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	bool OnProcess();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_INPUTEXCHANGE_H_
