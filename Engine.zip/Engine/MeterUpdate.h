#ifndef _ENGINE_METERUPDATE_H_
#define _ENGINE_METERUPDATE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_MAPIS_H_
#	include "Common\MapIS.h"
#endif	// _COMMON_MAPIS_H_
#ifndef 	_COMMON_QUERYRESPONSESESSION_H_
#	include "Common\QueryResponseSession.h"
#endif	// _COMMON_QUERYRESPONSESESSION_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuMeterUpdate)
class CIuMeter;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterUpdate, CIuMeterUpdate_super }}
#define CIuMeterUpdate_super CIuObject

class IU_CLASS_EXPORT CIuMeterUpdate : public CIuMeterUpdate_super
{
//{{Declare
	DECLARE_SERIAL(CIuMeterUpdate)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterUpdate();           
	virtual ~CIuMeterUpdate();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	CString GetKey() const;
	CIuMeter& GetMeter() const;
	CString GetQueryCode() const;
	CString GetResponseCode() const;
	bool IsCorrupt();
	bool IsValid();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool PromptDlg(CWnd* pWnd = 0);
	void SetCount(int); 
	void SetMeter(CIuMeter* Meter);
	void SetResponseCode(LPCTSTR pcsz);
	bool Update();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionPromptDlg(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionUpdate(const CIuPropertyCollection& Collection, CIuOutput& Output);
private:
	void SetQueryCode(LPCTSTR);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
	int m_iCount;
	CString m_sQueryCode;
	CString m_sResponseCode;
	int m_iMaxAttempts;
	bool m_fUpdatedFlag;
	// A mapping of count to query code. This way you always
	// get the same code each time you query the same count.
	CIuQueryResponseSession m_Session;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline int CIuMeterUpdate::GetCount() const
{
	return m_iCount;
}

#endif 
