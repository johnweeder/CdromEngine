#ifndef _ENGINE_MSA_H_
#define _ENGINE_MSA_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENT_H_
#	include "Engine\GeoElement.h"
#endif	// _ENGINE_GEOELEMENT_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMsa, CIuGeoElement }}
#define CIuMsa_super CIuGeoElement
#pragma pack(1)
class CIuMsa : public CIuMsa_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetMsaCode() const;
	LPCTSTR GetMsaCodeAsString() const;
	LPCTSTR GetMsaName() const;
	int GetStateNo() const;
	void GetZipList(CIuGeoList&) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoMsa;
	// Fixed Data:
		int m_iMsaCode;
		int m_iStateNo;
	// Variable Data:
		// List of associated ZIP's	
	// Strings:
		//	0) MSA Code 
		//	1) MSA Name
//}}Data

};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuMsa::GetMsaCode() const
{
	return m_iMsaCode;
}

inline LPCTSTR CIuMsa::GetMsaCodeAsString() const
{
	return GetName();
}

inline LPCTSTR CIuMsa::GetMsaName() const
{
	return GetString(1);
}

inline int CIuMsa::GetStateNo() const
{
	return m_iStateNo;
}

#endif // _ENGINE_MSA_H_
