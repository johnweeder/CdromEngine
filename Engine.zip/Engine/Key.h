#ifndef _ENGINE_KEY_H_
#define _ENGINE_KEY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_STATICBUFFER_H_
#	include "Common\StaticBuffer.h"
#endif	// _COMMON_STATICBUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuKey)
class CIuKeyDef;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// The separator for key values. Internally, we generally use a null as the 
//	separator, however, this is not easily passed around. So it is, instead,
//	converted to an ascii character. 
//	A character like \n or \t might seem like a reasonable choice, but this
// character is not easily entered or represented in most UI's. We also need
//	to make sure that the select character does not appear in any data fields.
//	Finally, the character must be lower than any other character so that the
// keys sort correctly. 
// Anyway... taking all this into consideration dictates that the only possible
// choice is a control character (like '\n' or '\t') even though it is difficult
// to represent in a UI.
// Tab is the choice because linefeed causes goofy looking textual queries.
const char keySeparatorChar = '\t';

const int keyInvalid = 0;
const int keyValue	= 1;
const int keyLoVal	= 2;
const int keyHiVal	= 3;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuKey, CIuObject }}
#define CIuKey_super CIuObject

class CIuKey : public CIuKey_super
{
//{{Declare
	DECLARE_SERIAL(CIuKey)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuKey();
	CIuKey(const CIuKey&);
	CIuKey(LPCTSTR pcsz, const CIuKeyDef& keyDef);
	virtual ~CIuKey();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int Compare(const CIuKey& key, bool* pfPartial = 0) const;
	int GetExpandCount() const;
	int GetExpandNo() const;
	const BYTE* GetKeyPtr() const;
	int GetKeySize() const;
	int GetType() const;
	bool IsHiVal() const;
	bool IsInvalid() const;
	bool IsLoVal() const;
	bool IsValue() const;
	bool IsWildCard() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(LPCTSTR, const CIuKeyDef& keyDef, bool fWildcard = false);
	void Append(const TCHAR* pch, int cch, const CIuKeyDef& KeyDef, bool fWildcard = false);
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void CopyFast(const CIuKey& Key);
	void Set(const BYTE* pb, int cb);
	void Set(LPCTSTR, const CIuKeyDef& keyDef);
	void SetExpandCount(int);
	void SetExpandNo(int);
	void SetHiVal();
	void SetLoVal();
	void SetType(int iType);
	void SetWildCard(bool = true);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuKey& operator=(const CIuKey&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	void Append(const BYTE* pb, int cb);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Integer to indicate special key values
	int m_iType;
	// This flag is set to indicate that partial matches should be 
	// allowed in a comparison. The flag only applies to the object
	// performing the comparison. For example, comparing ABC to AB* is not
	// allowed.
	bool m_fWildCard;
	// If this key is attached to a btree index, this variables indicate the
	// expanded record no/count for the index
	int m_iExpandNo;
	int m_iExpandCount;
	// This is the next field which is being appended as part of the key
	int m_iNext;
	// The key is stored as a series of null terminated string
	//	For performance, we use a static buffer. It can grow if needed.
	CIuStaticBuffer256 m_Key;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline void CIuKey::Append(LPCTSTR pcsz, const CIuKeyDef& KeyDef, bool fWildcard)
{
	Append(pcsz, _tcslen(pcsz), KeyDef, fWildcard);
}

inline int CIuKey::GetExpandCount() const
{
	return m_iExpandCount;
}

inline int CIuKey::GetExpandNo() const
{
	return m_iExpandNo;
}

inline const BYTE* CIuKey::GetKeyPtr() const
{
	return m_Key;
}

inline int CIuKey::GetKeySize() const
{
	return m_Key.GetSize();
}

inline int CIuKey::GetType() const
{
	return m_iType;
}

inline bool CIuKey::IsHiVal() const
{
	return m_iType == keyHiVal;
}

inline bool CIuKey::IsInvalid() const
{
	return m_iType == keyInvalid;
}

inline bool CIuKey::IsLoVal() const
{
	return m_iType == keyLoVal;
}

inline bool CIuKey::IsValue() const
{
	return m_iType == keyValue;
}

inline bool CIuKey::IsWildCard() const
{
	return m_fWildCard;
}

#endif // _ENGINE_KEY_H_
