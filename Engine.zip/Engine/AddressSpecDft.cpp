#include "StdAfx.h"
//{{Include
#include "AddressSpecDft.h"
#include "Address.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Addressernate specifications

static const CIuAddressSpecDft aAddress[] =
{
	{
		_T("Standard"), addressStandard,
		_T("Address"),
		"PriNo",						
		"PreDir",						 
		"StreetName",						
		"Suffix",						 
		"PostDir",					 
		"SecNo",							
		"HighRise",
		"NoSolicitation",
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuAddressSpecDft

int CIuAddressSpecDft::Find(LPCTSTR pcszAddress)
{
	ASSERT(AfxIsValidString(pcszAddress));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszAddress, pcszAddress) == 0)
			return i;
	}
	return -1;
}

int CIuAddressSpecDft::Find(int iAddress)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iAddress == iAddress)
			return i;
	}
	return -1;
}

const CIuAddressSpecDft* CIuAddressSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aAddress + iWhich;
}

int CIuAddressSpecDft::GetCount()
{
	return sizeof(aAddress) / sizeof(aAddress[0]);
}
