#ifndef _ENGINE_BTREESPECDFT_H_
#define _ENGINE_BTREESPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Indexes describe the various B-Trees which are included on a CD-ROM
struct CIuBTreeSpecDft
{
public:
	static int Find(LPCTSTR pcszIndex);
	static int Find(int iIndex);
	static const CIuBTreeSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszBTree;
	int m_iBTree;
	// Name (also used as filename)
	LPCTSTR m_pcszName;
	// Is this the default data source (implies that the input filename is the
	// same as the database filename)
	bool m_fDefaultSource;
	// A list of tokenizers
	const int* m_pBTreeTokenizers;
	// Info used by BTree
		// Name of the BTree for expanded records
		LPCTSTR m_pcszBTreeExpand;
		// Data/Pointers
		bool m_fHasData;
		bool m_fHasPointers;
		// Translations
		bool m_fCreateTranslation;
		bool m_fUseTranslation;
		// Alternates used by try-harder
		LPCTSTR m_pcszTryHarder;
		bool m_fTryHarderComma;
	// Info used by codec
		// Geo compressed
		bool m_fHasGeo;
		bool m_fNoMsaCorrection;
		bool m_fNoCountyCorrection;
		bool m_fNoCityStateCorrection;
		bool m_fNoZipAddOn;
		bool m_fNoLatLongCorrection;
		int m_iLatLongPrecision;
		// Address felds?
		bool m_fHasAddress;
		// String array of key fields
		LPCTSTR m_pcszKeys;
		// String array of phone fields
		LPCTSTR m_pcszPhones;
		// String array of miscellaneous fields
		LPCTSTR m_pcszMiscellaneous;
		// Non-solicitation
		LPCTSTR m_pcszNoSolicit;
		bool m_fNoSolicitMail;
		bool m_fNoSolicitPhone;
		// Bus/res flag
		LPCTSTR m_pcszBusResFlag;
		bool m_fBusOnly;
		bool m_fResOnly;
		// SIC information
		int m_iSicCount;
		LPCTSTR m_pcszSicCode;
		LPCTSTR m_pcszFranchiseCode;
		LPCTSTR m_pcszAdSizeCode;
		LPCTSTR m_pcszFirstYear;
		LPCTSTR m_pcszEmployeeSizeCode;
		LPCTSTR m_pcszSalesVolumeCode;
		// Gender flag/field
		LPCTSTR m_pcszGender;
		// Alternate file
		LPCTSTR m_pcszAlt;
		bool m_fAltCity;
		bool m_fAltPhone;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_BTREESPECDFT_H_
