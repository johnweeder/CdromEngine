#include "StdAfx.h"
//{{Include
#include "GeoRawInstance.h"
#include "GeoRawMap.h"
#include "Common\Clean.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawInstance, CIuGeoRawInstance_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawInstance)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWINSTANCE, CIuGeoRawInstance, CIuGeoRawInstance_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoRawInstance, IDS_ENGINE_PPG_GEORAWINSTANCE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY64(CIuGeoRawInstance, IDS_ENGINE_PROP_PHONES, GetPhones, SetPhones, 0)
	IU_ATTRIBUTE_EDITOR_INT_ARRAY64(CIuGeoRawInstance, IDS_ENGINE_PROP_PHONES, IDS_ENGINE_PPG_GEORAWINSTANCE, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawInstance::CIuGeoRawInstance() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoRawInstance::~CIuGeoRawInstance()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuGeoRawInstance::AddPhone(__int64 l, int iBefore) 
{
	int iCount = GetPhoneCount();
	if (iBefore < 0 || iBefore >= iCount)
		return m_aiPhones.Add(l);

	m_aiPhones.InsertAt(iBefore, l);
	return iBefore;
}

void CIuGeoRawInstance::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_aiPhones.RemoveAll();
	m_ZipCentroid.Clear();
	//}}Initialize
}

void CIuGeoRawInstance::GetPhones(CIntArray64& al) const
{
	al.Copy(m_aiPhones);
}

void CIuGeoRawInstance::RemoveAllPhones()
{
	m_aiPhones.RemoveAll();
}

void CIuGeoRawInstance::RemovePhone(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetPhoneCount());
	m_aiPhones.RemoveAt(iWhich);
}

void CIuGeoRawInstance::Set(const CIuRecord& Record, const CIuGeoRawMap& Map)
{
	CIuGeoRawInstance_super::Set(Record, Map);

	int iPhones = Map.m_aiPhone.GetSize();
	m_aiPhones.SetSize(iPhones);
	for (int iPhone = 0; iPhone < iPhones; ++iPhone)
	{
		CIuStaticBuffer256 Phone;
		Clean(Phone, m_pRecord->GetField(Map.m_aiPhone[iPhone]), cleanNumeric|cleanTrim|cleanTruncate|cleanAllowEmpty, 10);
		__int64 iPhoneNo = StringAsInt64(Phone);
		m_aiPhones.SetAt(iPhone, iPhoneNo);
	}
}

void CIuGeoRawInstance::SetPhone(int iWhich, __int64 l)
{
	ASSERT(iWhich >= 0);
	m_aiPhones.SetAtGrow(iWhich, l);
}

void CIuGeoRawInstance::SetPhones(const CIntArray64& al)
{
	m_aiPhones.Copy(al);
}

