#include "StdAfx.h"
//{{Include
#include "GeoElementCollection.h"
#include "GeoElement.h"
#include "Geo.h"
#include "GeoList.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "Data\PackRepository.h"
#include "resource.h"
#include "Error\Error.h"
#include "Common\NybbleInt.h"
#include "Common\NybbleString.h"
#include "Common\BigNybbleBuffer.h"
#include "GeoRawElementCollection.h"
#include "GeoRawElement.h"
#include "Common\Miscellaneous.h"
#include "Interop\Conversions.h"
#include "Cdrom.h"
#include "CdromSpec.h"
#include "SourceDescriptorSpec.h"
#include "Miscellaneous.h"
#include "SourceDescriptor.h"
#include "Key.h"
#include "FieldDefConst.h"
#include "RegExCompare.h"
#include "RegEx.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoElementCollection, CIuGeoElementCollection_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoElementCollection)
// NOTE: Version is controlled at the base class level. Do _not_ assign separate
// versions to the derived classes. The derived classes should base their behavior
// off of the base class version.
const	CIuVersionNumber CIuGeoElementCollection::versionGeo1(1999,0,8,600);
const	CIuVersionNumber CIuGeoElementCollection::versionGeo2(2000,1,3,700);
const	CIuVersionNumber versionGeoElementCollectionMax(2000,1,5,304);
const	CIuVersionNumber versionGeoElementCollectionMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOELEMENTCOLLECTION, CIuGeoElementCollection, CIuGeoElementCollection_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoElementCollection, IDS_ENGINE_PPG_GEOELEMENTCOLLECTION, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_COUNT, GetCount, SetCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_GEOELEMENTCOLLECTION, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_SIZE, GetSize, SetSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_SIZE, IDS_ENGINE_PPG_GEOELEMENTCOLLECTION, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_EXPANDEDSIZE, GetExpandedSize, SetExpandedSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoElementCollection, IDS_ENGINE_PROP_EXPANDEDSIZE, IDS_ENGINE_PPG_GEOELEMENTCOLLECTION, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuGeoElementCollection, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuGeoElementCollection, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_GEOELEMENTCOLLECTION, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoElementCollection::CIuGeoElementCollection() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoElementCollection::CIuGeoElementCollection(const CIuGeoElementCollection& rGeoElementCollection)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rGeoElementCollection;
}

CIuGeoElementCollection::~CIuGeoElementCollection()
{
	Close(true);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuGeoElement* CIuGeoElementCollection::AddElement(int iFixedSize)
{
	ASSERT(iFixedSize >= sizeof(CIuGeoElement));
	int iSize = m_Buffer.GetSize();
	m_Buffer.SetSize(iSize + iFixedSize);

	ASSERT(m_iCurrentElement >= 0 && m_iCurrentElement < m_aiOffsets.GetSize());
	m_aiOffsets.SetAtGrow(m_iCurrentElement, iSize);

	return reinterpret_cast<CIuGeoElement*>(m_Buffer.GetPtr(iSize));
}

int CIuGeoElementCollection::AddElementData(const BYTE* pbSrc, int cbSrc)
{
	int iElement = m_aiOffsets[m_iCurrentElement];
	int iSize = m_Buffer.GetSize();
	ASSERT(iSize > iElement);
	// If null parms, return the current offset!
	if (pbSrc == 0 || cbSrc <= 0)
		return iSize - iElement;

	m_Buffer.SetSize(iSize + cbSrc);

	BYTE* pbDst = reinterpret_cast<BYTE*>(m_Buffer.GetPtr(iSize));
	memcpy(pbDst, pbSrc, cbSrc);

	return iSize - iElement;
}

int CIuGeoElementCollection::AddElementName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	int iName = AddElementData((const BYTE*)pcsz, _tcslen(pcsz) + 1);

	ASSERT(m_iCurrentElement >= 0 && m_iCurrentElement < m_aiOffsets.GetSize());
	int iElement = m_aiOffsets[m_iCurrentElement];
	CIuGeoElement& Element = *reinterpret_cast<CIuGeoElement*>(m_Buffer.GetPtr(iElement));

	Element.m_iStringStart = iName;

	return iName;
}

int CIuGeoElementCollection::AddElementString(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	int iString = AddElementData((const BYTE*)pcsz, _tcslen(pcsz) + 1);
	return iString;
}

CIuGeoElement* CIuGeoElementCollection::AddElementStringTerm()
{
	ASSERT(m_iCurrentElement >= 0 && m_iCurrentElement < m_aiOffsets.GetSize());
	int iElement = m_aiOffsets[m_iCurrentElement];
	CIuGeoElement& Element = *reinterpret_cast<CIuGeoElement*>(m_Buffer.GetPtr(iElement));
	ASSERT(Element.m_iStringStart >= 0 && Element.m_iStringStart < m_Buffer.GetSize());
	Element.m_iStringLength =  m_Buffer.GetSize() - (Element.m_iStringStart + iElement);

	return reinterpret_cast<CIuGeoElement*>(m_Buffer.GetPtr(iElement));
}

bool CIuGeoElementCollection::BuildCompress(CIuGeoRaw& geo, CIuGeoRawElementCollection& collection, CIuCdrom&, CIuOutput& Output)
{
	CIuOutputStateInstance instance(Output);
	Output.OutputF("Processing geography: '%s'\n", LPCTSTR(GetIndex()));
	Output.SetPosition(0);
	Output.SetRange(1);
	if (!Output.Fire())
		return false;

	// Force file to be closed
	Close(true);

	// Force, to be marked as closed
	m_iOpen = 0;

	Output.SetMessageF("Sorting");
	if (!Output.Fire())
		return false;

	// Sort raw elements by name
	collection.SortByName();

	// Get element count and store at start of buffer
	SetCount(collection.GetCount());

	// Make sure buffer and element list is empty
	CIuBigNybbleBuffer Buffer;
	Buffer.SetSize(3 * 1024 * 1024);
	Buffer.Empty();

	int iRange = GetCount();
	Output.SetRange(iRange);
	Output.SetMessageF("Compressing");
	if (!Output.Fire())
		return false;

	// Compress each of the elements
#ifdef _DEBUG
	CString sPreviousName;
#endif
	int iExpandedSize = 0;
	for (int iPosition = 0; iPosition < iRange; ++iPosition)
	{
		if ((iPosition % ((iRange + 99) / 100)) == 0)
		{
			if (iPosition > iRange)
			{
				iRange = iPosition;
				Output.SetRange(iRange);
			}
			Output.SetPosition(iPosition);
			if (!Output.Fire())
				return false;
		}

		CIuGeoRawElement* pElement = collection.Get(iPosition);

#ifdef _DEBUG
		// Double check sort order... must be strictly increasing...
		if (iPosition > 0)
		{
			ASSERT(sPreviousName.Compare(pElement->GetName()) < 0);
		}
		sPreviousName = pElement->GetName();
#endif

		// Then, do element type specific compression
		iExpandedSize += OnCompressElement(Buffer, geo, *pElement, collection, Output);
	}

	// Store the size of the nybble buffer
	SetSize(Buffer.GetNybbles());
	SetExpandedSize(iExpandedSize);

	// Write the data to an external file
	{
		CIuPrefixFile file;
		ASSERT(m_pObjectRepository);
		CIuFilename filename = GetObjectRepository().GetFullFilename(GetGeo(), GetFilename());
		file.Create(filename, 16 * 1024, CIuFile::openCreate);
		file.SetData(*this);

		CIuFileVirtualPtr pVFile = file.Use();
		pVFile->Seek(0);
		if (Buffer.GetBytes() > 0)
			pVFile->Write(Buffer.GetData(), Buffer.GetBytes());

		// We need the braces to insure the file objects go out of
		// scope and close the file before we run the consistency checks.
	}

	instance.Pop(true);

	return Output.Fire();
}

bool CIuGeoElementCollection::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseFiles))
		GetObjectRepository().PackFile(GetGeo(), Cdrom.GetPack(), &Output, GetFilename());
	return true;
}

void CIuGeoElementCollection::CheckField(CString& s)
{
	if (s.GetLength() <= fieldDftLength)
		return ;

	Error(IU_E_FIELD_TOO_BIG, LPCTSTR(s));
}

void CIuGeoElementCollection::Close(bool fForce)
{
	if (m_iOpen <= 0)
		return ;
	if (fForce)
		m_iOpen = 0;
	else 
		--m_iOpen;
	if (m_iOpen > 0)
		return ;
	Empty();
}

void CIuGeoElementCollection::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iOpen = 0;
	m_iCount = 0;
	m_iSize = 0;
	m_pObjectRepository = 0;
	SetVersion(versionGeo2);
	m_pObjectRepository = 0;
	SetID(CIuID::Create());
	m_iExpandedSize = 0;
	SetVersion(versionGeoElementCollectionMax);
	//}}Initialize
}

void CIuGeoElementCollection::Copy(const CIuObject& object)
{
	CIuGeoElementCollection_super::Copy(object);

	const CIuGeoElementCollection* pGeoElementCollection = dynamic_cast<const CIuGeoElementCollection*>(&object);
	if (pGeoElementCollection == 0 || pGeoElementCollection == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuGeoElementCollection)));
	m_iCount = pGeoElementCollection->m_iCount;
	m_iSize = pGeoElementCollection->m_iSize;
	m_iExpandedSize = pGeoElementCollection->m_iExpandedSize;
}

void CIuGeoElementCollection::Delete(CIuOutput* pOutput)
{
	ASSERT(!IsOpen());
	CdromDelete(GetFullFilename(), pOutput);
	Empty();
}

void CIuGeoElementCollection::Empty()
{
	ASSERT(!IsOpen());
	m_Buffer.Destroy();
	m_aiOffsets.RemoveAll();
}

int CIuGeoElementCollection::Find(int iValue, int iPad)
{
	TCHAR sz[IntMaxStringLength];
	if (iPad > 0)
		IntAsStringEx(sz, sizeof(sz), iValue, 10, iPad, iPad, true);
	else
		IntAsStringEx(sz, sizeof(sz), iValue);
	return Find(sz);
}

int CIuGeoElementCollection::Find(LPCTSTR pcszName) 
{
	ASSERT(IsOpen());
	ASSERT(AfxIsValidString(pcszName));
	int iHi = GetCount() - 1;
	if (iHi < 0)
		return -1;
	int iLo = 0;

	// NOTE: In order for this loop to exit, we must insure 
	// that if Lo + 1 == Hi, then we will test the Lo value.
	while (iLo <= iHi)
	{
		int iTest = iLo + (iHi - iLo) / 2;
		ASSERT(iTest >= iLo && iTest <= iHi);

		const CIuGeoElement& Element = Get(iTest);
		int iResult = _tcsicmp(Element.GetName(), pcszName);
		if (iResult == 0)
			return iTest;
		else if (iResult > 0)
			iHi = iTest - 1;			
		else //  if (iResult < 0)
			iLo = iTest + 1;
	}
	return -1;
}

bool CIuGeoElementCollection::FindLo(const CIuRegExCompare& Compare, int& iMatch) const
{
	// Finds the first key GE to the comparator
	int iKeys = GetCount();
	if (iKeys == 0)
		return false;

	int iLo = 0;
	int iHi = iKeys - 1;
	int iTest = iLo + (iHi - iLo) / 2;
	LPCTSTR pcsz;
	int iResult;

	while (iLo < iHi)
	{
		// NOTE: In order for this loop to exit, we must insure 
		// that if Lo + 1 == Hi, then we will test the Lo value.
		ASSERT(iTest >= iLo && iTest <= iHi);

		pcsz = GetElementName(iTest);
		iResult = Compare.Compare(pcsz);
		if (REGEX_EQ(iResult))
		{
			ASSERT(iTest != iHi);
			iHi = iTest;
		}
		else if (REGEX_LT(iResult))
			iLo = iTest + 1;			
		else // if (REGEX_GT(iResult))
			iHi = iTest - 1;

		iTest = iLo + (iHi - iLo) / 2;
	}

	ASSERT(iLo >= 0);
	if (iLo >= iKeys)
	{
		// No match, past end of file
#ifdef _DEBUG
		pcsz = GetElementName(iKeys - 1);
		ASSERT(REGEX_LT(Compare.Compare(pcsz)));
#endif
		return false;
	}

	// At this point, we are either before or on the desired record
	pcsz = GetElementName(iTest);
	iResult = Compare.Compare(pcsz);
	while (iResult < 0)
	{
		++iLo;
		if (iLo >= iKeys)
		{
#ifdef _DEBUG
			pcsz = GetElementName(iKeys - 1);
			ASSERT(REGEX_LT(Compare.Compare(pcsz)));
#endif
			return false;
		}
		pcsz = GetElementName(iTest);
		iResult = Compare.Compare(pcsz);
	}

	if (!REGEX_EQ(iResult))
	{
#ifdef _DEBUG
		ASSERT(iLo < iKeys);
		pcsz = GetElementName(iLo);
		ASSERT(REGEX_GT(Compare.Compare(pcsz)));
		if (iLo > 0)
		{
			pcsz = GetElementName(iLo - 1);
			ASSERT(REGEX_LT(Compare.Compare(pcsz)));
		}
#endif
		return false;
	}

#ifdef _DEBUG
	if (iLo > 0)
	{
		pcsz = GetElementName(iLo - 1);
		ASSERT(REGEX_LT(Compare.Compare(pcsz)));
	}
	pcsz = GetElementName(iLo);
	ASSERT(REGEX_EQ(Compare.Compare(pcsz)));
#endif

	iMatch = iLo;
	return true;
}

bool CIuGeoElementCollection::FindHi(const CIuRegExCompare& Compare, int& iMatch) const
{
	// Finds the last key LE to the comparator
	int iKeys = GetCount();
	if (iKeys == 0)
		return false;

	int iLo = 0;
	int iHi = iKeys - 1;
	int iTest = iLo + (iHi - iLo + 1) / 2;
	LPCTSTR pcsz;
	int iResult;

	while (iLo < iHi)
	{
		// NOTE: In order for this loop to exit, we must insure 
		// that if Lo + 1 == Hi, then we will test the Hi value.
		ASSERT(iTest >= iLo && iTest <= iHi);

		pcsz = GetElementName(iTest);
		int iResult = Compare.Compare(pcsz);
		if (REGEX_EQ(iResult))
		{
			ASSERT(iTest != iLo);
			iLo = iTest;
		}
		else if (REGEX_LT(iResult))
			iLo = iTest + 1;			
		else // if (REGEX_GT(iResult))
			iHi = iTest - 1;

		iTest = iLo + (iHi - iLo + 1) / 2;
	}

	ASSERT(iLo == iHi);
	ASSERT(iLo >= 0);

	if (iLo >= iKeys)
	{
#ifdef _DEBUG
		pcsz = GetElementName(iKeys - 1);
		ASSERT(REGEX_LT(Compare.Compare(pcsz)));
#endif
		return false;
	}

	// At this point, we are either 1-before or on the desired record
	pcsz = GetElementName(iTest);
	iResult = Compare.Compare(pcsz);
	while (iResult < 0)
	{
		++iLo;
		if (iLo >= iKeys)
		{
#ifdef _DEBUG
			pcsz = GetElementName(iKeys - 1);
			ASSERT(REGEX_LT(Compare.Compare(pcsz)));
#endif
			return false;
		}
		pcsz = GetElementName(iTest);
		iResult = Compare.Compare(pcsz);
	}

	if (!REGEX_EQ(iResult))
	{
#ifdef _DEBUG
		ASSERT(iLo < iKeys);
		pcsz = GetElementName(iLo);
		ASSERT(REGEX_GT(Compare.Compare(pcsz)));
		if (iLo > 0)
		{
			pcsz = GetElementName(iLo - 1);
			ASSERT(REGEX_LT(Compare.Compare(pcsz)));
		}
#endif
		return false;
	}

#ifdef _DEBUG
	pcsz = GetElementName(iLo);
	ASSERT(REGEX_EQ(Compare.Compare(pcsz)));

	if (iLo < iKeys - 1)
	{
		pcsz = GetElementName(iLo + 1);
		ASSERT(REGEX_GT(Compare.Compare(pcsz)));
	}
#endif

	iMatch = iLo;
	return true;
}

void CIuGeoElementCollection::FindScan(CIuGeoList& GeoList, const CIuRegExCompare& RegExCompare) const
{
	int iElements = GetCount();
	for (int iElement = 0; iElement < iElements; ++iElement)
	{
		LPCTSTR pcsz = GetElementName(iElement);
		int iResult = RegExCompare.Compare(pcsz);
		if (!REGEX_EQ(iResult))
			continue;
		GeoList.Add(iElement, iElement);
	}
}

int CIuGeoElementCollection::GetBitsRequired() const
{
	return BitsRequired(GetCount());
}

void CIuGeoElementCollection::GetElementKey(int iElement, CIuKey& key) const
{
	// Each element starts with a nybble encoded string. That is the name, get it...
	const CIuGeoElement& Element = Get(iElement);
	LPCTSTR pcszName = Element.GetName();
	key.Set((BYTE*)pcszName, _tcslen(pcszName) + 1);
}

LPCTSTR CIuGeoElementCollection::GetElementName(int iElement) const
{
	// Each element starts with a nybble encoded string. That is the name, get it...
	const CIuGeoElement& Element = Get(iElement);
	LPCTSTR pcszName = Element.GetName();
	return pcszName;
}

CString CIuGeoElementCollection::GetFilename() const
{
	CString sName;
	sName += GetGeo().GetFilename();
	sName += _T(" ");
	sName += GetIndex();
	return sName;
}

CString CIuGeoElementCollection::GetFullFilename() const
{
	CString filename = GetObjectRepository().GetFullFilename(GetGeo(), GetFilename());
	return filename;
}

void CIuGeoElementCollection::GetGeoList(CIuGeoList& GeoList, const CIuRegEx& RegEx) const
{
	CIuGeoList GeoListLocal;
	int iTerms = RegEx.GetTerms();
	for (int iTerm = 0; iTerm < iTerms; ++iTerm)
	{
		CIuRegExCompare RegExCompare(RegEx, iTerm);
		if ((RegEx.GetFlags() & (regExHasTermNot|regExHasTermPhonetic|regExHasTermWithin|regExHasTermRegEx)) != 0)
		{
			// Special expressions require a scan
			FindScan(GeoListLocal, RegExCompare);
			continue;
		}
		else
		{
			int iLo;
			int iHi;
			if (!FindLo(RegExCompare, iLo))
			{
				// We tried to find the term but failed. 
				// It could be because we need to search on a secondary field
				// like county name instead of country code.
				// To implement this, we do a scanning search
				FindScan(GeoListLocal, RegExCompare);
				continue;
			}
			else if (!FindHi(RegExCompare, iHi))
				continue;

			ASSERT(iLo <= iHi);
			ASSERT(iLo >= 0);
			ASSERT(iHi < GetCount());
			GeoListLocal.Add(iLo, iHi);
		}
	}

	int iCount = GeoListLocal.GetCount();
	for (int iRange = 0; iRange < iCount; ++iRange)
	{
		int iLo, iHi;
		GeoListLocal.Get(iRange, iLo, iHi);
		ASSERT(iLo <= iHi);
		for (int iElement = iLo; iElement <= iHi; ++iElement)
		{
			GetZipList(iElement, GeoList);
		}
	}
}

void	CIuGeoElementCollection::GetGeoListFilter(const CIuRegEx&, CStringArray&) const
{
	// Each derived geography must implement this specific to their
	// object.
	// The preferred method is to add a criteria of the form:
	//		[name] LIKE 'value'
	ASSERT(false);
}

bool CIuGeoElementCollection::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			static TCHAR szName[] = _T("CIuGeoElementCollectionGrid");
			rq.SetName(szName);
			rq.Load();
			if (!IsOpen())
			{
				IU_TRY_ERROR
				{
					// Try to open file.
					if (m_pObjectRepository)
					{
						ASSERT(m_pObjectRepository);
						CIuFilename filename = GetObjectRepository().GetFullFilename(GetGeo(), GetFilename());
						if (filename.Exists())
						{
							Open();
							rq.SetOpen4Edit();
						}
					}
				}
				IU_CATCH_ERROR(e)
				{
					e->Delete();
				}
			}

			if (!IsOpen())
				rq.SetSize(CSize(1, 0));
			else
				rq.SetSize(CSize(1, GetCount()));
			rq.SetColumn(0, _T("Name"), 150, gridWidthOptional);
			return true;
		}
		case gridRqTerminate:
			if (rq.IsOpen4Edit())
				Close();
			rq.Save();
			return true;
		case gridRqDblClickRow:
		case gridRqDblClickCell:
			return false;
		case gridRqGet:
			ASSERT(rq.GetColumn() == 0);
			if (rq.GetRow() >= 0 && rq.GetRow() < GetCount())
			{
				CString sValue = GetElementName(rq.GetRow());
				rq.SetValue(sValue);
				return true;
			}
			return false;
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

LPCTSTR CIuGeoElementCollection::GetIndex() const
{
	return _T("<unknown geography type>");
}

void CIuGeoElementCollection::GetRecord(int iRecordNo, CIuRecordPtr& pRecord)
{
	const CIuGeoElement& Element = Get(iRecordNo);

	const BYTE* pb = reinterpret_cast<const BYTE*>(&Element) + Element.m_iStringStart;

	CIuRecordSpec Spec;
	Spec.Set(pb, Element.m_iStringLength);
	Spec.SetSourceNo(GetID());
	Spec.SetRecordNo(iRecordNo);
	Spec.SetKey(1);
	pRecord.Create(Spec);
}

void CIuGeoElementCollection::GetRecordDef(CIuRecordDef&) const
{
	// Derived classes must provide a record definition
	ASSERT(false);
}

int CIuGeoElementCollection::GetSourceType() const
{
	return sourceNone;
}

void CIuGeoElementCollection::GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const
{
	ASSERT(HasObjectRepository());

	Specs.RemoveAll();

	CIuRecordDef RecordDef;
	GetRecordDef(RecordDef);

	// NOTE: The source has index name matches the name of this object
	//			and the ID matches the ID of this object.
	// The database name will be set by the owning Geo object.
	CIuSourceDescriptorSpec Spec;
	Spec.SetID(GetID());
	Spec.SetIndex(GetName());
	Spec.SetSource(GetGeo().GetMoniker());
	Spec.SetSourceType(GetSourceType());
	Spec.SetRecordDef(&RecordDef);

	Specs.Add(Spec);
}

CIuVersionNumber CIuGeoElementCollection::GetVersionMax() const
{
	return versionGeoElementCollectionMax;
}

CIuVersionNumber CIuGeoElementCollection::GetVersionMaxStatic()
{
	return versionGeoElementCollectionMax;
}

CIuVersionNumber CIuGeoElementCollection::GetVersionMin() const
{
	return versionGeoElementCollectionMin;
}

CIuVersionNumber CIuGeoElementCollection::GetVersionMinStatic()
{
	return versionGeoElementCollectionMin;
}

void CIuGeoElementCollection::GetZipList(int, CIuGeoList&) const
{
	ASSERT(false);
}

bool CIuGeoElementCollection::IsOpen() const
{
	return m_iOpen > 0;
}

int CIuGeoElementCollection::OnCompressElement(CIuNybbleBuffer&, CIuGeoRaw&, CIuGeoRawElement&, CIuGeoRawElementCollection&, CIuOutput&)
{
	// Don't bother calling this... it isn't needed and justs wastes time.
	ASSERT(false);
	// Return the expanded size...
	return 0;
}

int CIuGeoElementCollection::OnDeCompressElement(CIuNybbleBuffer&, int iOffset)
{
	// Don't bother calling this... it isn't needed and justs wastes time.
	ASSERT(false);
	return iOffset;
}

void CIuGeoElementCollection::Open()
{
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}

#ifdef _DEBUG
	time_t timeStart = time(0);
#endif

	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	// Open the file and read in the tokens as one large block
	CIuPrefixFilePtr pFile;
	CIuFileVirtualPtr pVFile;
	CRC32 crc;
	GetObjectRepository().Use(GetGeo(), pFile, pVFile, GetFilename(), 0, &crc);
#ifdef _DEBUG
	__int64 iDebugFileLength = pVFile->GetLength();
	__int64 iDebugBufferSize = (GetSize() + 1) / 2;
	__int64 iDebugElementsSize = GetCount() * sizeof(int);
	if (GetVersion() < versionGeo2)
	{
		ASSERT(iDebugFileLength == iDebugBufferSize + iDebugElementsSize);
	}
	else
	{
		ASSERT(iDebugFileLength == iDebugBufferSize);
	}
#endif

	// Check the CRC when reading the data
	CRC32 crcActual = 0;

	// The actual compressed data
	CIuBigNybbleBuffer Buffer;
	Buffer.SetSize((GetSize() + 1) / 2);
	Buffer.SetNybbles(GetSize());

	// Read the compressed data
	pVFile->Seek(0);
	if (Buffer.GetBytes() > 0)
	{
		pVFile->Read(Buffer.GetData(), Buffer.GetBytes());
		crcActual = crc32(Buffer.GetData(), Buffer.GetBytes(), crcActual);
	}

	// For backwards compatibility, read in the record offsets in order to check 
	// the crc codes
	if (GetVersion() < versionGeo2)
	{
		CIntArray Elements;
		Elements.SetSize(GetCount());
		if (Elements.GetSize() > 0)
		{
			pVFile->Read(Elements.GetData(), Elements.GetSize() * sizeof(int));
			crcActual = crc32((const BYTE*)Elements.GetData(), Elements.GetSize() * sizeof(int), crcActual);
		}
	}

	if (crc != 0 && crc != crcActual)
		Error(IU_E_OBJECT_INVALID_OR_CORRUPT, GetName());

	// Expand the records
	m_Buffer.SetSize(0,0);
	if (GetVersion() >= versionGeo2)
		m_Buffer.PreAllocate(GetExpandedSize());
	m_Buffer.SetGrowBy(64 * 1024);
	m_aiOffsets.SetSize(GetCount());
	m_iCurrentElement = 0;
	int iOffset = 0;
	for (int iElement = 0; iElement < GetCount(); ++iElement)
	{
		iOffset = OnDeCompressElement(Buffer, iOffset);
		++m_iCurrentElement;
	}

	if (iOffset != GetSize())
		Error(IU_E_OBJECT_INVALID_OR_CORRUPT, GetName());

#ifdef _DEBUG
	time_t timeNow = time(0);
	int iElapsed = timeNow - timeStart;
	TRACE("OPEN: Geography '%s' expanded %d elements in %d bytes (%d / element) from %d compressed bytes in %d seconds.\n",
		LPCTSTR(GetName()), GetCount(), m_Buffer.GetSize(), m_Buffer.GetSize() / max(1, GetCount()), Buffer.GetBytes(), iElapsed);
#endif

	// OK, we are now open
	m_iOpen = 1;
}

CIuGeoElementCollection& CIuGeoElementCollection::operator=(const CIuGeoElementCollection& rGeoElementCollection)
{
	Copy(rGeoElementCollection);
	return *this;
}

bool CIuGeoElementCollection::SanityCheck(CIuGeoRawElementCollection& collection, CIuOutput& Output)
{
	Output.OutputF("Validating geography file '%s'\n", LPCTSTR(GetName()));
	if (!Output.Fire())
		return false;

	// Save current progress status
	CIuOutputStateInstance Progress(Output);

	Output.SetMessageF("Opening compressed alternate record image '%s'\n", LPCTSTR(GetName()));
	Output.Fire();

	CIuObjectPtr pObject = Clone();
	CIuGeoElementCollectionPtr pFile = dynamic_cast<CIuGeoElementCollection*>(pObject.Ptr());
	ASSERT(m_pObjectRepository);
	pFile->SetObjectRepository(m_pObjectRepository);
	pFile->SetGeo(&GetGeo());
	pFile->Open();

	if (pFile->GetCount() != collection.GetCount())
		Error(IU_E_GEO_INVALID, _T("Record counts does not match raw records."));
	if (pFile->GetCount() != GetCount())
		Error(IU_E_GEO_INVALID, _T("Record counts differ."));
	if (pFile->GetVersion() != GetVersion())
		Error(IU_E_GEO_INVALID, _T("Versions do not match."));
	if (pFile->GetSize() != GetSize())
		Error(IU_E_GEO_INVALID, _T("Compressed files sizes differ."));
	if (pFile->GetExpandedSize() != GetExpandedSize())
		Error(IU_E_GEO_INVALID, _T("Expanded files sizes differ."));
	if (pFile->m_Buffer.GetSize() != GetExpandedSize())
	{
		long lActual = pFile->m_Buffer.GetSize();
		long lExpected = GetExpandedSize();
		CString sError;
		sError.Format(_T("Expanded buffer size differs from computed size.\nActual is %d\nExpected %d"), lActual, lExpected);
		Error(IU_E_GEO_INVALID, LPCTSTR(sError));
	}

	Output.SetMessageF("Validating records in geography file '%s'\n", LPCTSTR(GetName()));
	int iCount = pFile->GetCount();
	Output.SetRange(iCount);
	Output.SetPosition(0);
	Output.Fire();

	CIuRecordPtr pRecord;

	CString sPreviousKey;

	for (int iGeo = 0; iGeo < iCount; ++iGeo)
	{
		if ((iGeo % ((iCount + 99) / 100)) == 0)
		{
			Output.SetPosition(iGeo);
			if (!Output.Fire())
				return false;
		}

		CIuGeoRawElement* pRaw = collection.Get(iGeo);
		ASSERT(pRaw);

		CString sKey;
		sKey = pRaw->GetName();
		if (sKey.GetLength() >= fieldDftLength)
		{
			CString sDebug;
			sDebug.Format(_T("Key is too int @ %ld '%s'.\n[%s]\n[%s]"), 
				iGeo, LPCTSTR(sKey));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}

		CString sKey2 = pFile->GetElementName(iGeo);
		if (sKey2.CompareNoCase(sKey) != 0)
		{
			CString sDebug;
			sDebug.Format(_T("Key does not match raw record @ %ld.\n[%s]\n[%s]"), 
				iGeo, LPCTSTR(sKey), LPCTSTR(sKey2));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}

		if (iGeo > 0)
		{
			CIuGeoRawElement* pRawPrev = collection.Get(iGeo - 1);
			ASSERT(pRawPrev->GetName().CompareNoCase(pRaw->GetName()) < 0);
		}

		int iResult = pRaw->GetName().CompareNoCase(sKey);
		if (iResult != 0)
		{
			CString sDebug;
			sDebug.Format(_T("Geography key did not match compressed image @ %ld\n[%s]\n[%s]"), 
				iGeo, LPCTSTR(pRaw->GetName()), LPCTSTR(sKey));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}

		int iFound = pFile->Find(sKey);
		if (iFound != iGeo)
		{
			CString sDebug;
			sDebug.Format(_T("Could not find record in geography @ %ld\n[%s]"), 
				iGeo, LPCTSTR(sKey));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}

		iResult = sPreviousKey.CompareNoCase(sKey);
		if (iResult == 0 && iGeo > 0)
		{
			CString sDebug;
			sDebug.Format(_T("Duplicate keys @ %ld\n[%s]\n[%s]"), 
				iGeo, LPCTSTR(sPreviousKey), LPCTSTR(sKey));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}
		if (iResult > 0)
		{
			CString sDebug;
			sDebug.Format(_T("Keys not sorted @ %ld\n[%s]\n[%s]"), 
				iGeo, LPCTSTR(sPreviousKey), LPCTSTR(sKey));
			Error(IU_E_GEO_INVALID, LPCTSTR(sDebug));
		}

		sPreviousKey = sKey;

		// Just expand the record to test for any serious errors
		pFile->GetRecord(iGeo, pRecord);
	}
	return Output.Fire();
}

bool CIuGeoElementCollection::Request(CString& sResult, const CStringArray& as)
{
	return GetGeo().RequestGeo(sResult, as);
}

void CIuGeoElementCollection::SetCount(int iCount)
{
	m_iCount = iCount;
}

void CIuGeoElementCollection::SetExpandedSize(int iExpandedSize)
{
	m_iExpandedSize = iExpandedSize;
}

void CIuGeoElementCollection::SetGeo(CIuGeo* pGeo)
{ 
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	ASSERT(pGeo!=0);
	m_pGeo = pGeo;
}

void CIuGeoElementCollection::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuGeoElementCollection::SetSpec(CIuGeoSpec&)
{
	ASSERT(GetSourceType() != sourceNone);
}

void CIuGeoElementCollection::SetSize(int iSize)
{
	m_iSize = iSize;
}
