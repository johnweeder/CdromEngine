#include "stdafx.h" 
//{{Include
#include "Engine.h"
#include "Queries.h"
#include "Query.h"
#include "resource.h"
#include "SourceProvider.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuQueries, CIuQueries_super)
IU_IMPLEMENT_OBJECT_PTR(CIuQueries)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_QUERIES, CIuQueries, CIuQueries_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuQueries, IDS_ENGINE_PPG_QUERIES, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuQueries, IDS_ENGINE_PPG_QUERIES, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuQueries::CIuQueries()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);

	m_pEngine = 0;
	CommonConstruct();
}

CIuQueries::~CIuQueries()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuQueries::CancelAll() 
{
	int iQueries = GetCount();
	for (int iQuery = 0; iQuery < iQueries; ++iQuery)
		Get(iQuery).Cancel();
}

void CIuQueries::Clear()
{
	CIuQueries_super::Clear();
	CIuQueries::CommonConstruct();
}

void CIuQueries::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuQueries::OnAdd(int)
{
	GetEngine().GetSourceProvider().SetRefreshQueries();	
}

CIuCollectablePtr CIuQueries::OnNew(CWnd*) const
{
	CIuQueryPtr pQuery;
	pQuery.Create();
	pQuery->SetEngine(*m_pEngine);
	return pQuery;
}

void CIuQueries::OnRemove(int)
{
	GetEngine().GetSourceProvider().SetRefreshQueries();	
}

void CIuQueries::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}


