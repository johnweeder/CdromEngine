#include "StdAfx.h"
//{{Include
#include "MeterSpec.h"
#include "MeterSpecDft.h"
#include "CdromSpecConst.h"
#include "resource.h"
#include "Common\String.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuMeterSpec, CIuMeterSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuMeterSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_METERSPEC, CIuMeterSpec, CIuMeterSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuMeterSpec, IDS_ENGINE_PPG_METERSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GUID(CIuMeterSpec, IDS_ENGINE_PROP_GUID1, GetGuid1, SetGuid1, 0)
	IU_ATTRIBUTE_EDITOR_GUID(CIuMeterSpec, IDS_ENGINE_PROP_GUID1, IDS_ENGINE_PPG_METERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_GUID(CIuMeterSpec, IDS_ENGINE_PROP_GUID2, GetGuid2, SetGuid2, 0)
	IU_ATTRIBUTE_EDITOR_GUID(CIuMeterSpec, IDS_ENGINE_PROP_GUID2, IDS_ENGINE_PPG_METERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuMeterSpec, IDS_ENGINE_PROP_ALLOWUPDATE, AllowUpdate, SetAllowUpdate, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuMeterSpec, IDS_ENGINE_PROP_ALLOWUPDATE, IDS_ENGINE_PPG_METERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALCOUNT, GetInitialCount, SetInitialCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALCOUNT, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_EXPIREDAYS, GetExpireDays, SetExpireDays, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_EXPIREDAYS, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_MAXOUTPUT, GetMaxOutput, SetMaxOutput, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_MAXOUTPUT, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_PHONE, GetPhone, SetPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_PHONE, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_WEBSITE, GetWebSite, SetWebSite, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_WEBSITE, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_KEY, GetKey, SetKey, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_KEY, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_METERNO, GetMeterNo, SetMeterNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_METERNO, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_WARNINGDAYS, GetWarningDays, SetWarningDays, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_WARNINGDAYS, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_DT(CIuMeterSpec, IDS_ENGINE_PROP_RELEASEDATE, GetReleaseDate, SetReleaseDate, 0)
	IU_ATTRIBUTE_EDITOR_DT(CIuMeterSpec, IDS_ENGINE_PROP_RELEASEDATE, IDS_ENGINE_PPG_METERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_WARNINGTEXT, GetWarningText, SetWarningText, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_WARNINGTEXT, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_FLAGS, GetFlags, SetFlags, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_FLAGS, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALREV, GetInitialRev, SetInitialRev, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALREV, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterSpec, IDS_ENGINE_PROP_SPECIALACCESS, GetSpecialAccess, SetSpecialAccess, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterSpec, IDS_ENGINE_PROP_SPECIALACCESS, IDS_ENGINE_PPG_METERSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_UPGRADELEVEL, GetUpgradeLevel, SetUpgradeLevel, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_UPGRADELEVEL, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_UPGRADECOUNT, GetUpgradeCount, SetUpgradeCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_UPGRADECOUNT, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuMeterSpec, IDS_ENGINE_PROP_PREVIOUS, GetPrevious, SetPrevious, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuMeterSpec, IDS_ENGINE_PROP_PREVIOUS, IDS_ENGINE_PPG_METERSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALCOUNTUPGRADE, GetInitialCountUpgrade, SetInitialCountUpgrade, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterSpec, IDS_ENGINE_PROP_INITIALCOUNTUPGRADE, IDS_ENGINE_PPG_METERSPEC, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuMeterSpec::CIuMeterSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuMeterSpec::~CIuMeterSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}


void CIuMeterSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	SetGuid1(GUID_NULL);
	SetGuid2(GUID_NULL);
	m_fAllowUpdate = false;
	m_iInitialCount = -1;
	m_iExpireDays = 0;
	m_iMaxOutput = 0;
	m_sPhone = "";
	m_sWebSite = "";
	m_sKey = "";
	m_iMeterNo = 0;
	m_sTitle = "";
	m_iWarningDays = 0;
	m_sFilename = "Filename";
	m_dtReleaseDate = COleDateTime::GetCurrentTime();
	SetVersion(IU_VERSION);
	m_sWarningText = "";
	m_iFlags = 0;
	m_iInitialRev = 0;
	m_sSpecialAccess = "";
	m_iUpgradeLevel = 0;
	m_iUpgradeCount = 0;
	m_monikerPrevious.Clear();
	m_iInitialCountUpgrade = -1;
	//}}Initialize
}

int CIuMeterSpec::GetCount()
{
	return CIuMeterSpecDft::GetCount();
}

void CIuMeterSpec::FromIndex(CIuCdromSpec* pCdrom, int iMeterSpec)
{
	ASSERT(iMeterSpec >= 0);
	const CIuMeterSpecDft* pMeterSpec = CIuMeterSpecDft::Get(iMeterSpec);
	ASSERT(pMeterSpec);

	FromSpec(pCdrom, pMeterSpec);
}

void CIuMeterSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszMeter)
{
	FromIndex(pCdrom, CIuMeterSpecDft::Find(pcszMeter));
}

void CIuMeterSpec::FromNo(CIuCdromSpec* pCdrom, int iMeterNo)
{
	int iMeterSpec = CIuMeterSpecDft::Find(iMeterNo);
	ASSERT(iMeterSpec >= 0);
	const CIuMeterSpecDft* pMeterSpec = CIuMeterSpecDft::Get(iMeterSpec);
	ASSERT(pMeterSpec);

	FromSpec(pCdrom, pMeterSpec);
}

void CIuMeterSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuMeterSpecDft* pMeterSpec)
{
	SetCdrom(pCdrom);

	SetName(pMeterSpec->m_pcszMeter);
	SetID(*pMeterSpec->m_pidMeter);

	SetMeterNo(pMeterSpec->m_iMeter);

	SetAllowUpdate(pMeterSpec->m_fAllowUpdate);
	SetExpireDays(pMeterSpec->m_iExpireDays);
	SetWarningDays(pMeterSpec->m_iWarningDays);
	SetWarningText(pMeterSpec->m_pcszWarningText);
	SetFlags(pMeterSpec->m_iFlags);
	SetGuid1(pMeterSpec->m_guid1);
	SetGuid2(pMeterSpec->m_guid2);
	SetInitialCount(pMeterSpec->m_iInitialCount);
	SetInitialCountUpgrade(pMeterSpec->m_iInitialCountUpgrade);
	SetSpecialAccess(pMeterSpec->m_pcszSpecialAccess);
	SetKey(pMeterSpec->m_pcszKey);
	SetMaxOutput(pMeterSpec->m_iMaxOutput);
	SetPhone(pMeterSpec->m_pcszPhone);
	SetWebSite(pMeterSpec->m_pcszWebSite);
	SetTitle(pMeterSpec->m_pcszTitle);
	SetFilename(pMeterSpec->m_pcszFilename);
	SetInitialRev(pMeterSpec->m_iInitialRev);
	SetUpgradeLevel(pMeterSpec->m_iUpgradeLevel);
	SetUpgradeCount(pMeterSpec->m_iUpgradeCount);
	if (pMeterSpec->m_pidMeterPrevious)
	{
		CIuMoniker Previous(0, CIuID(*pMeterSpec->m_pidMeterPrevious));
		SetPrevious(Previous);
	}
	else
		m_monikerPrevious.Clear();

	COleDateTime dtRelease;
	if (!_tcsisempty(pMeterSpec->m_pcszReleaseDate))
		dtRelease.ParseDateTime(pMeterSpec->m_pcszReleaseDate, VAR_DATEVALUEONLY);
	else
		dtRelease.SetStatus(COleDateTime::null);
	SetReleaseDate(dtRelease);
}

void CIuMeterSpec::SetAllowUpdate(bool f)
{
	m_fAllowUpdate = f;
}

void CIuMeterSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuMeterSpec::SetExpireDays(int iExpireDays)
{
	m_iExpireDays = iExpireDays;
}

void CIuMeterSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuMeterSpec::SetFlags(int iFlags)
{
	m_iFlags = iFlags;
}

void CIuMeterSpec::SetGuid1(const CIuGuid& guid)
{
	m_guidGuid1 = guid;	
}

void CIuMeterSpec::SetGuid2(const CIuGuid& guid)
{
	m_guidGuid2 = guid;	
}

void CIuMeterSpec::SetInitialCount(int iInitialCount)
{
	m_iInitialCount = iInitialCount;
}

void CIuMeterSpec::SetInitialCountUpgrade(int iInitialCountUpgrade)
{
	m_iInitialCountUpgrade = iInitialCountUpgrade;
}

void CIuMeterSpec::SetInitialRev(int iInitialRev)
{
	m_iInitialRev = iInitialRev;
}

void CIuMeterSpec::SetKey(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sKey = pcsz;
}

void CIuMeterSpec::SetMaxOutput(int iMaxOutput)
{
	m_iMaxOutput = iMaxOutput;
}

void CIuMeterSpec::SetMeterNo(int iMeterNo)
{
	m_iMeterNo = iMeterNo;
}

void CIuMeterSpec::SetPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sPhone = pcsz;
}

void CIuMeterSpec::SetPrevious(const CIuMoniker& moniker)
{
	m_monikerPrevious = moniker;
}

void CIuMeterSpec::SetReleaseDate(const COleDateTime& dt)
{
	m_dtReleaseDate = dt;
}

void CIuMeterSpec::SetSpecialAccess(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSpecialAccess = pcsz;
}

void CIuMeterSpec::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}

void CIuMeterSpec::SetUpgradeCount(int iUpgradeCount)
{
	m_iUpgradeCount = iUpgradeCount;
}

void CIuMeterSpec::SetUpgradeLevel(int iUpgradeLevel)
{
	m_iUpgradeLevel = iUpgradeLevel;
}

void CIuMeterSpec::SetWarningDays(int iWarningDays)
{
	m_iWarningDays = iWarningDays;
}

void CIuMeterSpec::SetWarningText(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sWarningText = pcsz;
}

void CIuMeterSpec::SetWebSite(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sWebSite = pcsz;
}
