#include "StdAfx.h"
//{{Include
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IU_API_EXPORT bool CdromDelete(LPCTSTR pcszFilename, CIuOutput* pOutput)
{
	ASSERT(pcszFilename);
	// Raw alternate files are only intermediates...
	CIuFilename Filename = pcszFilename;
	if (!Filename.Exists())
		return false;
	Filename.Delete();
	if (pOutput)
		pOutput->OutputF("Deleted file '%s'\n", LPCTSTR(Filename.GetFullFilename()));
	return true;
}
