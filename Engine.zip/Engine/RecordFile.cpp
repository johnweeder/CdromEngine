#include "StdAfx.h" 
//{{Include
#include "RecordFile.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Error\Error.h"
#include "RecordDef.h"								  
#include "Data\DataFilename.h"
#include "Common\String.h"
#include "Miscellaneous.h"
#include "OpenSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRecordFile, CIuRecordFile_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordFile)
const	CIuVersionNumber versionRecordFileMax(2000,1,5,304);
const	CIuVersionNumber versionRecordFileMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDFILE, CIuRecordFile, CIuRecordFile_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuRecordFile, IDS_ENGINE_PPG_RECORDFILE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordFile, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuRecordFile, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_RECORDFILE, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordFile, IDS_ENGINE_PROP_BLOCKSIZE, GetBlockSize, SetBlockSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordFile, IDS_ENGINE_PROP_BLOCKSIZE, IDS_ENGINE_PPG_RECORDFILE, 8 * 1024, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordFile, IDS_ENGINE_PROP_RECORDS, GetRecords, SetRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordFile, IDS_ENGINE_PROP_RECORDS, IDS_ENGINE_PPG_RECORDFILE, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordFile, IDS_ENGINE_PROP_BLOCKS, GetBlocks, SetBlocks, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordFile, IDS_ENGINE_PROP_BLOCKS, IDS_ENGINE_PPG_RECORDFILE, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordFile, IDS_ENGINE_PROP_MAXRECORDNO, GetMaxRecordNo, SetMaxRecordNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordFile, IDS_ENGINE_PROP_MAXRECORDNO, IDS_ENGINE_PPG_RECORDFILE, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuRecordFile, IDS_ENGINE_PROP_APPEND, ShouldAppend, SetAppend, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuRecordFile, IDS_ENGINE_PROP_APPEND, IDS_ENGINE_PPG_RECORDFILE, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuRecordFile, IDS_ENGINE_PROP_TEMPORARY, IsTemporary, SetTemporary, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuRecordFile, IDS_ENGINE_PROP_TEMPORARY, IDS_ENGINE_PPG_RECORDFILE, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordFile, IDS_ENGINE_PROP_RECORDDEF, GetRecordDef_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuRecordFile, IDS_ENGINE_PROP_RECORDDEF, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuRecordFile, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID_POPUP(CIuRecordFile, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_RECORDFILE, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRecordFile::CIuRecordFile() 
{
	//{{Initialize													  
	m_iRecord = -1;
	m_iRecords = 0;
	m_iBlocks = 0;
	m_iBlock = -1;
	m_iBlockSize = 256 * 1024;
	m_pbRecord = 0;
	m_sFilename.Empty();
	m_iMaxRecordNo = 0;
	m_iOpen = 0;
	m_fAppend = false;
	m_fTemporary = false;
	m_iNextRecord = 0;
	if (m_pRecordDef.IsNull())
	{
		m_pRecordDef.Create();
	}
	m_iGridRecord = -1;
	SetVersion(versionRecordFileMax);
	//}}Initialize
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuRecordFile::~CIuRecordFile()
{
	while (m_iOpen > 0)
		Close();
	DeleteTemporary();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuRecordFile::Append(const CIuRecord& Record)
{
	ASSERT(IsOpen() && ShouldAppend());

	// Must actually contain data
	Record.GetBuffer(m_AppendBuffer);
	int iSize = m_AppendBuffer.GetSize();
	ASSERT(iSize > 0);
	if (iSize <= 0)
		return false;
	ASSERT(iSize < 0x3FFF);
	ASSERT(iSize < GetBlockSize());

	// If this record won't fit in the block, write the block
	int iRemaining = GetBlockSize() - m_block.GetSize();
	if (iRemaining <= 0 || iRemaining < int(iSize + sizeof(CIuUInt16)))
		AppendBlock();

	// If this is the first record in the block, set up the record no index
	if (m_block.GetSize() == 0)
	{
		m_iBlock = m_iBlocks;
		ASSERT(m_iRecords >= 0);
		m_aiFirstRecordInBlock.Add(m_iRecords);
		ASSERT(m_aiFirstRecordInBlock.GetSize() == m_iBlock + 1);
	}

	// The upper two bits of the size are used as flags for the record no and source no
	WORD wSize = static_cast<WORD>(iSize);

	// Keep tracked of the largest record no
	SetMaxRecordNo(max(GetMaxRecordNo(), int(Record.GetRecordNo())));

	// Write the size followed by the data
	CIuUInt16 size = wSize;
	m_block.Append(reinterpret_cast<const BYTE*>(&size), sizeof(size));
	m_block.Append(m_AppendBuffer.GetPtr(), iSize);

	// Increment record count
	++m_iRecords;

	return true;
}

void CIuRecordFile::AppendBlock()
{
	ASSERT(IsOpen() && ShouldAppend());

	// Don't bother if no data waiting
	if (m_block.GetSize() == 0)
		return ;

	// Pad out to block size with nulls
	ASSERT(m_block.GetSize() <= GetBlockSize());
	if (m_block.GetSize() < GetBlockSize())
	{
		int iOffset = m_block.GetSize();
		int iClear = GetBlockSize() - m_block.GetSize();
		m_block.SetSize(GetBlockSize());
		m_block.Set(0, iClear, iOffset);
	}

	ValidateBlock();

	// Write the data
	ASSERT(m_block.GetSize() == GetBlockSize());
	CIuFilePosition pos = CIuFilePosition(GetBlocks()) * GetBlockSize();
	m_pVFile->Seek(pos);
	m_pVFile->Write(m_block.GetPtr(), m_block.GetSize());


	// Set up for next pass
	++m_iBlocks;
	m_iBlock = -1;
	m_block.Empty();
}

void CIuRecordFile::ClearTemporary()
{
	SetTemporary(false);
}

void CIuRecordFile::Close()
{
	if (m_iOpen <= 0)
		return ;
	if (m_iOpen > 1)
	{
		--m_iOpen;
		return ;
	}

	if (ShouldAppend() && m_file.IsOpen() && m_pVFile.NotNull())
	{
		// Write any partial blocks
		if (m_block.GetSize() > 0)
			AppendBlock();

		// Write "block begin" array
		if (GetBlocks())
		{
			m_pVFile->Seek(CIuFilePosition(GetBlocks()) * GetBlockSize());
			m_pVFile->Write(m_aiFirstRecordInBlock.GetData(), m_aiFirstRecordInBlock.GetSize() * sizeof(int));
		}

		// Update header
		m_file.SetData(*this);
	}

	// Free everything
	m_pVFile.Release();
	m_file.Close();
	m_aiFirstRecordInBlock.SetSize(0);
	m_block.Destroy();

	// BUT, don't reset variables unless needed. They may be useful even
	// though the file is closed!
	m_iBlock = -1;
	m_iRecord = -1;
	m_pbRecord = 0;
	m_iNextRecord = 0;

	m_iOpen = 0;
}

void CIuRecordFile::Create(CIuOpenSpec&)
{
	// Force to close!
	while (m_iOpen > 0)
		Close();

	// Create the record source
	m_iOpen = 1;
	m_iGridRecord = -1;

	SetAppend(true);

	if (IsTemporary())
	{
		m_file.Create(0, GetBlockSize(), CIuFile::openCreate|CIuFile::modeTemporary);
		// Clear the temporary flag, we will handle the deletion within this object
		m_file.ClearTemporary();
		SetFilename(m_file.GetFilename());
	}
	else
	{
		CIuFilename filename = GetFullFilename();
		m_file.Create(filename, GetBlockSize());
	}

	m_pVFile = m_file.Use();
	m_block.SetSize(GetBlockSize());
	m_block.Empty();
	m_aiFirstRecordInBlock.SetSize(0);
	m_iBlock = -1;
	m_iBlocks = 0;
	m_iRecord = -1;
	m_iRecords = 0;
	m_iMaxRecordNo = 0;
	m_pbRecord = 0;
	m_block.Empty();
	m_iNextRecord = 0;
}

void CIuRecordFile::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
}

void CIuRecordFile::DeleteTemporary(CIuOutput* pOutput)
{
	// If file was temporary, delete it
	if (IsTemporary())
		CdromDelete(GetFullFilename(), pOutput);
}

bool CIuRecordFile::Exists() const
{
	CIuFilename Filename = GetFullFilename();
	return Filename.Exists();
}

int CIuRecordFile::FindBlock(int iRecord)
{
	for (int iBlock = 0; iBlock < GetBlocks(); ++iBlock)
		if (IsRecordInBlock(iRecord, iBlock))
			return iBlock;
	return -1;
}

bool CIuRecordFile::Get(int iRecord, CIuRecordPtr& pRecord) const
{
	ASSERT(IsOpen());
	ASSERT(iRecord >= 0 && iRecord < GetRecords());
	if (iRecord < 0 || iRecord >= GetRecords())
		return false;

	// Check that we have the proper block loaded in memory
	if (!IsRecordInBlock(iRecord, m_iBlock))
	{
		int iBlock = const_cast<CIuRecordFile*>(this)->FindBlock(iRecord);
		if (iBlock < 0)
			Error(IU_E_RECORD_FILE_IO);
		
		const_cast<CIuRecordFile*>(this)->ReadBlock(iBlock);
	}

	if (m_iRecord > iRecord)
	{
		// Reset to first record in block if we've gone too far already
		const_cast<CIuRecordFile*>(this)->m_iRecord = m_aiFirstRecordInBlock[m_iBlock];
		const_cast<CIuRecordFile*>(this)->m_pbRecord = const_cast<CIuRecordFile*>(this)->m_block.GetPtr();
	}

	for (; m_iRecord < iRecord; ++const_cast<CIuRecordFile*>(this)->m_iRecord)
	{
		// Get size of record
		CIuUInt16* puiSize = reinterpret_cast<CIuUInt16*>(m_pbRecord);

		// Convert to word 
		WORD wSize = *puiSize;

		// Move to start of next record
		const_cast<CIuRecordFile*>(this)->m_pbRecord += sizeof(CIuUInt16) + wSize;
	}

	CIuUInt16* puiSize = reinterpret_cast<CIuUInt16*>(m_pbRecord);
	WORD wSize = *puiSize;

	pRecord.SetBuffer(m_pbRecord + sizeof(CIuUInt16), wSize);

	// After reading the last record in a block, automatically begin a read of the next
	// block using async I/O.
	if (m_iBlock < GetBlocks() - 1 && m_iRecord + 1 >= m_aiFirstRecordInBlock[m_iBlock + 1])
		const_cast<CIuRecordFile*>(this)->ReadBlock(m_iBlock + 1);

	return true;
}

void CIuRecordFile::GetFields(LPCTSTR pcsz, CStringArray& as) 
{
	IU_TRY_ERROR
	{
		CIuRecordDef recordDef;
		ASSERT(AfxIsValidString(pcsz));
		recordDef.LoadFromRecordFile(pcsz);
		recordDef.GetFields(as);
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
		as.RemoveAll();
	}
}

CString CIuRecordFile::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CString CIuRecordFile::GetFullFilename() const
{
	CString sFile = GetFilename();
	if (sFile.IsEmpty())
		return sFile;
	return IuDataFilenameSearch(sFile, extDataPrefix, this);
}

CIuObject* CIuRecordFile::GetRecordDef_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRecordDef.Ptr()));
}

bool CIuRecordFile::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			static TCHAR szName[] = _T("CIuRecordFileGrid");
			rq.SetName(szName);
			rq.Load();
			if (!IsOpen() && Exists())
			{
				SetAppend(false);
				CIuOpenSpec Spec;
				Open(Spec);
				rq.SetOpen4Edit();
			}
			if (IsOpen())
			{
				rq.SetSize(CSize(GetRecordDef().GetFieldDefs().GetCount() + 2, GetRecords()));
				for (int iColumn = 0; iColumn < GetRecordDef().GetFieldDefs().GetCount() + 2; ++iColumn)
				{
					if (iColumn == 0)
						rq.SetColumn(iColumn, "RecordNo", 100, gridWidthOptional);
					else if (iColumn == 1)
						rq.SetColumn(iColumn, "Key", 100, gridWidthOptional);
					else
						rq.SetColumn(iColumn, GetRecordDef().GetFieldDefs().Get(iColumn - 2).GetName(), 100, gridWidthOptional);
				}
			}
			m_iGridRecord = -1;
			return true;
		}
		case gridRqTerminate:
			m_pGridRecord.Release();
			m_iGridRecord = -1;
			if (rq.IsOpen4Edit())
				Close();
			rq.Save();
			return true;
		case gridRqDblClickRow:
			// rq.GetRow()
			return true;
		case gridRqDblClickCell:
			// , 
			return true;
		case gridRqGet:
		{
			if (!IsOpen())
				return false;

			if (rq.GetRow() != m_iGridRecord)
			{
				CIuRecordFile* pRecordFile = const_cast<CIuRecordFile*>(this);
				pRecordFile->Get(rq.GetRow(), pRecordFile->m_pGridRecord);
				pRecordFile->m_iGridRecord = rq.GetRow();
			}

			if (rq.GetColumn() == 0)
			{
				CString s;
				IntAsString(s, rq.GetRow());
				if (m_pGridRecord->HasRecordNo())
				{
					s += _T(" (");
					if (m_pGridRecord->HasSourceNo())
					{
						CString sSourceNo;
						s += Int32AsString(sSourceNo, m_pGridRecord->GetSourceNo());
						s += _T("/");
					}
					CString sRecordNo;
					s += Int32AsString(sRecordNo, m_pGridRecord->GetRecordNo());
					s += _T(")");
				}
				rq.SetValue(s);
			}
			else if (rq.GetColumn() == 1)
			{
				if (m_pGridRecord->HasKey())
				{
					CString s;
					int iKeySize = m_pGridRecord->GetKeySize();
					LPCTSTR pcsz = LPCTSTR(m_pGridRecord->GetKeyPtr());
					for (int iKey = 0; iKey < iKeySize - 1; ++iKey)
					{
						if (_istprint(pcsz[iKey]))
							s += pcsz[iKey];
						else
							s += _T("^");
					}
					rq.SetValue(s);
				}
				else
					rq.SetValue(_T(""));
			}
			else
				rq.SetValue(m_pGridRecord->GetField(rq.GetColumn() - 2));
			return true;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

CIuVersionNumber CIuRecordFile::GetVersionMax() const
{
	return versionRecordFileMax;
}

CIuVersionNumber CIuRecordFile::GetVersionMaxStatic()
{
	return versionRecordFileMax;
}

CIuVersionNumber CIuRecordFile::GetVersionMin() const
{
	return versionRecordFileMin;
}

CIuVersionNumber CIuRecordFile::GetVersionMinStatic()
{
	return versionRecordFileMin;
}

bool CIuRecordFile::IsEof() const
{
	return m_iNextRecord >= GetRecords();
}

bool CIuRecordFile::IsOpen() const
{
	ASSERT(m_iOpen <= 0 || m_file.IsOpen());
	return m_iOpen > 0;
}

bool CIuRecordFile::IsRecordInBlock(int iRecord, int iBlock) const
{
	if (iBlock < 0 || iBlock >= GetBlocks())
		return false;
	if (iRecord < 0 || iRecord >= GetRecords())
		return false;
	int iFirstRecord = m_aiFirstRecordInBlock[iBlock];
	ASSERT(iFirstRecord >= 0 && iFirstRecord < GetRecords());
	if (iBlock == GetBlocks() - 1)
	{
		if (iRecord >= iFirstRecord)
			return true;
	}
	else
	{
		if (iRecord >= iFirstRecord && iRecord < m_aiFirstRecordInBlock[iBlock + 1])
			return true;
	}
	return false;
}

void CIuRecordFile::LoadFromRecordFile(LPCTSTR pcsz)
{
	CString sOriginalFilename = GetFilename();
	if (pcsz == 0)
		GetRecordDef().LoadFromRecordFile(GetFullFilename());
	else
		GetRecordDef().LoadFromRecordFile(pcsz);
	// We must update the filename after we have opened the file.
	SetFilename(sOriginalFilename);
}

void CIuRecordFile::MoveFirst()
{
	m_iNextRecord = 0;
}

bool CIuRecordFile::MoveNext(CIuRecordPtr& pRecord)
{
	if (m_iNextRecord >= GetRecords())
		return false;

	if (!Get(m_iNextRecord, pRecord))
		return false;
	++m_iNextRecord;
	return true;
}

void CIuRecordFile::Open(CIuOpenSpec&)
{
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}
	m_iOpen = 1;
	m_iGridRecord = -1;
	m_iNextRecord = 0;

	CString sOriginalFilename = GetFilename();
	if (ShouldAppend())
		OpenAppend();
	else
	{
		OpenReadOnly();
		SetAppend(false);
	}
	// We must update the filename after we have opened the file.
	SetFilename(sOriginalFilename);
}

void CIuRecordFile::OpenAppend()
{
	CIuFilename filename = GetFullFilename();
	if (filename.Exists())
	{
		m_file.Open(filename, GetBlockSize(), CIuFilePhysical::openAppend|CIuFilePhysical::modeSequential);
		m_file.GetData(this);
	}
	else
		m_file.Create(filename, GetBlockSize(), CIuFilePhysical::modeSequential);


	m_pVFile = m_file.Use();

	m_iBlock = -1;
	m_iRecord = -1;
	m_pbRecord = 0;
	ReadBlockStarts();
	m_block.Empty();
}

void CIuRecordFile::OpenReadOnly()
{
	ASSERT(!ShouldAppend());

	CIuFilename filename = GetFullFilename();
	m_file.Open(filename, GetBlockSize());

	m_file.GetData(this);

	m_pVFile = m_file.Use();

	m_iBlock = -1;
	m_iRecord = -1;
	m_pbRecord = 0;

	ReadBlockStarts();

	if (GetBlocks())
		ReadBlock(0);
}

void CIuRecordFile::ReadBlock(int iBlock)
{
	ASSERT(IsOpen());

	ASSERT(iBlock >= 0 && iBlock < m_iBlocks);
	if (iBlock == m_iBlocks)
		return ;

	m_iBlock = -1;

	CIuFilePosition pos = CIuFilePosition(iBlock) * GetBlockSize();
	m_pVFile->Seek(pos);
	m_block.SetSize(GetBlockSize());
	m_pVFile->Read(m_block.GetPtr(), m_block.GetSize());

	m_iBlock = iBlock;
	m_iRecord = m_aiFirstRecordInBlock[m_iBlock];
	m_pbRecord = m_block;

	ValidateBlock();
}

void CIuRecordFile::ReadBlockStarts()
{
	// Read in block start array
	m_aiFirstRecordInBlock.SetSize(GetBlocks());
	if (GetBlocks() > 0)
	{
		m_pVFile->Seek(CIuFilePosition(GetBlocks()) * GetBlockSize());
		m_pVFile->Read(m_aiFirstRecordInBlock.GetData(), m_aiFirstRecordInBlock.GetSize() * sizeof(int));
	}
	m_block.SetSize(GetBlockSize());
}

void CIuRecordFile::SetAppend(bool f)
{
	m_fAppend = f;
}

void CIuRecordFile::SetBlocks(int iBlocks)
{
	m_iBlocks = iBlocks;
}

void CIuRecordFile::SetBlockSize(int iBlockSize)
{
	// Make sure the block can hold at least one record of the largest size.
	m_iBlockSize = max(iBlockSize, rawRecordFileBlockSize);
	m_iBlockSize /= 512;
	m_iBlockSize *= 512;
	ASSERT(m_iBlockSize == GetBlockSize());
}

void CIuRecordFile::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuRecordFile::SetMaxRecordNo(int iMaxRecordNo)
{
	m_iMaxRecordNo = iMaxRecordNo;
}

void CIuRecordFile::SetRecords(int i)
{
	m_iRecords = i;
}

void CIuRecordFile::SetSpec(int iRecordDefSpec, LPCTSTR pcszFilename)
{
	if (!_tcsisempty(pcszFilename))
		SetFilename(pcszFilename);
	GetRecordDef().SetSpec(iRecordDefSpec);
}

void CIuRecordFile::SetTemporary(bool f)
{
	m_fTemporary = f;
}

void CIuRecordFile::ValidateBlock() const
{
#ifdef _DEBUG

	const BYTE* pb = m_block;
	int cb = m_block.GetSize();
	ASSERT(m_iBlock >= 0);
	int iRecords;
	if (m_iBlock >= GetBlocks() - 1)
		iRecords = m_iRecords - m_aiFirstRecordInBlock[m_iBlock];
	else
		iRecords = m_aiFirstRecordInBlock[m_iBlock + 1] - m_aiFirstRecordInBlock[m_iBlock];

	// TRACE("Block %05d CRC = %08lX\n", m_iBlock, crc32(pb, cb));

	for (int iRecord = 0; iRecord < iRecords; ++iRecord)
	{
		// Get size of record
		const CIuUInt16* puiSize = reinterpret_cast<const CIuUInt16*>(pb);

		// Convert to word 
		WORD wSize = *puiSize;
		ASSERT(wSize != 0);

		// Move to start of next record
		pb += sizeof(CIuUInt16) + wSize;
		cb -= sizeof(CIuUInt16) + wSize;
		ASSERT(cb >= 0);
	}
	ASSERT(cb >= 0);
	for (; cb > 0; --cb, ++pb)
	{
		ASSERT(*pb == 0);
	}
#endif
}
