#ifndef _ENGINE_GEORAWELEMENT_H_
#define _ENGINE_GEORAWELEMENT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENTACCUMULATOR_H_
#	include "Engine\GeoRawElementAccumulator.h"
#endif	// _ENGINE_GEORAWELEMENTACCUMULATOR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawElement)
class CIuGeoRawElementCollection;
class CIuGeoRawInstance;
class CIuGeoRawElementAccumulator;
class CIuRegEx;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawElement, CIuObject }}
#define CIuGeoRawElement_super CIuObject

class CIuGeoRawElement : public CIuGeoRawElement_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawElement)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawElement();
	virtual ~CIuGeoRawElement();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	CString GetName() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
	void SetCount(int);
	void SetName(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
protected:
	void Another();
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iCount;
	CString m_sName;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuGeoRawElement::GetCount() const
{
	return m_iCount;
}

inline CString CIuGeoRawElement::GetName() const
{
	return m_sName;
}

#endif // _ENGINE_GEORAWELEMENT_H_
