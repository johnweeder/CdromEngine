#include "stdafx.h"
#include "RecordDlg.h"
#include "RecordDef.h"
#include "LatLongUnit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuRecordDlg, CIuRecordDlg_super)
	//{{AFX_MSG_MAP(CIuRecordDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuRecordDlg::CIuRecordDlg(const CIuRecord* pRecord, const CIuRecordDef* pRecordDef, CWnd* pParent) : CIuRecordDlg_super(CIuRecordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuRecordDlg)
	m_sSize = _T("");
	m_sRefCount = _T("");
	m_sFields = _T("");
	m_sFlags = _T("");
	m_sAlt = _T("");
	m_sBoughtLevel = _T("");
	m_sCount = _T("");
	m_sExpandNo = _T("");
	m_sKey = _T("");
	m_sRecordNo = _T("");
	m_sSourceNo = _T("");
	m_sKeyInfo = _T("");
	m_sLatLong = _T("");
	//}}AFX_DATA_INIT
	m_pRecord = pRecord;
	m_pRecordDef = pRecordDef;
}

/////////////////////////////////////////////////////////////////////////////
// CIuRecordDlg message handlers

void CIuRecordDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuRecordDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuRecordDlg)
	DDX_Control(pDX, IDC_ENGINE_GRID, m_Grid);
	DDX_Text(pDX, IDC_ENGINE_SIZE, m_sSize);
	DDX_Text(pDX, IDC_ENGINE_REFCOUNT, m_sRefCount);
	DDX_Text(pDX, IDC_ENGINE_FIELDS, m_sFields);
	DDX_Text(pDX, IDC_ENGINE_FLAGS, m_sFlags);
	DDX_Text(pDX, IDC_ENGINE_ALT, m_sAlt);
	DDX_Text(pDX, IDC_ENGINE_BOUGHTLEVEL, m_sBoughtLevel);
	DDX_Text(pDX, IDC_ENGINE_COUNT, m_sCount);
	DDX_Text(pDX, IDC_ENGINE_EXPANDNO, m_sExpandNo);
	DDX_Text(pDX, IDC_ENGINE_KEY, m_sKey);
	DDX_Text(pDX, IDC_ENGINE_RECORDNO, m_sRecordNo);
	DDX_Text(pDX, IDC_ENGINE_SOURCENO, m_sSourceNo);
	DDX_Text(pDX, IDC_ENGINE_KEYINFO, m_sKeyInfo);
	DDX_Text(pDX, IDC_ENGINE_LATLONG, m_sLatLong);
	//}}AFX_DATA_MAP
}

BOOL CIuRecordDlg::OnInitDialog() 
{
	CIuRecordDlg_super::OnInitDialog();

	ASSERT(m_pRecord);

	CString sTitle;
	sTitle.Format(_T("Record 0x%08lX"), m_pRecord);
	SetWindowText(sTitle);

	m_sSize.Format(_T("%d of %d bytes used"), int(m_pRecord->m_wUsedSize), int(m_pRecord->m_wTotalSize));
	m_sRefCount.Format(_T("%d"), int(m_pRecord->m_wRef));

	m_sFlags.Format("%08lX\n", int(m_pRecord->m_wFlags));
	if (m_pRecord->IsNoPhone())
		m_sFlags += _T("NoPhone  ");
	if (m_pRecord->IsNoMail())
		m_sFlags += _T("NoMail  ");
	if (m_pRecord->IsTagged())
		m_sFlags += _T("Tagged  ");

	if (m_pRecord->HasLatLong())
	{
		m_sFlags += _T("LatLong  ");
		DWORD dwLat, dwLong;
		m_pRecord->GetLatLong(dwLat, dwLong);
		CIuLatLongUnit latitude(dwLat);
		CIuLatLongUnit longitude(dwLong);
		m_sLatLong.Format("%s, %s OR %d, %d", LPCTSTR(latitude.AsString()), LPCTSTR(longitude.AsString()), dwLat, dwLong);
	}
	if (m_pRecord->HasSourceNo())
	{
		m_sFlags += _T("SourceNo  ");
		if (m_pRecord->GetSourceNo() == recordSourceNoInvalid)
			m_sSourceNo = _T("invalid");
		else
			m_sSourceNo.Format("%08X", m_pRecord->GetSourceNo());
	}
	if (m_pRecord->HasRecordNo())
	{
		m_sFlags += _T("RecordNo  ");
		if (m_pRecord->GetRecordNo() == recordRecordNoInvalid)
			m_sRecordNo = _T("invalid");
		else
			m_sRecordNo.Format("%d", m_pRecord->GetRecordNo());
	}
	if (m_pRecord->HasExpandNo())
	{
		m_sFlags += _T("ExpandNo  Count  ");
		DWORD dwExpandNo, dwExpandCount;
		m_pRecord->GetExpandNo(dwExpandNo, dwExpandCount);
		if (dwExpandNo == recordExpandNoInvalid)
			m_sExpandNo = _T("invalid");
		else
			m_sExpandNo.Format("%d", dwExpandNo);
		m_sCount.Format("%d", dwExpandCount);
	}
	else if (m_pRecord->HasExpandCount())
	{
		m_sFlags += _T("Count  ");
		m_sCount.Format("%d", m_pRecord->GetExpandCount());
	}

	m_sBoughtLevel.Format("%d", int(m_pRecord->GetBoughtLevel()));

	// Set up the grid
	m_Grid.SetExtendedStyle(m_Grid.GetExtendedStyle()|LVS_EX_GRIDLINES|LVS_EX_INFOTIP);
	ASSERT((m_Grid.GetExtendedStyle() & (LVS_EX_GRIDLINES|LVS_EX_INFOTIP)) == (LVS_EX_GRIDLINES|LVS_EX_INFOTIP));
	ASSERT((m_Grid.GetStyle() & (LVS_REPORT|LVS_SHOWSELALWAYS|LVS_SINGLESEL)) == (LVS_REPORT|LVS_SHOWSELALWAYS|LVS_SINGLESEL));

	// Insert the columns
	m_Grid.InsertColumn(0, _T("#"),			LVCFMT_RIGHT,	30);
	m_Grid.InsertColumn(1, _T("Field"),		LVCFMT_LEFT,	100);
	m_Grid.InsertColumn(2, _T("Value"),		LVCFMT_LEFT,	200);
	m_Grid.InsertColumn(3, _T("Length"),	LVCFMT_RIGHT,	75);
	m_Grid.InsertColumn(4, _T("MaxLen"),	LVCFMT_RIGHT,	75);
	m_Grid.InsertColumn(5, _T("Offset"),	LVCFMT_RIGHT,	75);

	// Load the field information
	if (m_pRecord->IsLoVal())
		m_sFields = _T("LO VAL");
	else if (m_pRecord->IsHiVal())
		m_sFields = _T("HI VAL");
	else if (m_pRecord->IsAlternate())
		m_sFields = _T("ALTERNATE (2 pseudo-fields)");
	else
	{
		m_sFields.Format(_T("%d fields"), int(m_pRecord->m_wFields));
		
		for (int iRow = 0; iRow < int(m_pRecord->m_wFields); ++iRow)
		{
			CString sID;
			sID.Format("%d", iRow);
			int iIndex = m_Grid.InsertItem(iRow, sID);
			VERIFY(iIndex >= 0);

			if (m_pRecordDef)
				m_Grid.SetItemText(iIndex, 1, m_pRecordDef->GetFieldDefs().Get(iIndex).GetName());
			else
				m_Grid.SetItemText(iIndex, 1, _T("<unknown>"));

			m_Grid.SetItemText(iIndex, 2, m_pRecord->GetField(iRow));

			CString sLength;
			sLength.Format("%d", m_pRecord->GetFieldSize(iRow));
			m_Grid.SetItemText(iIndex, 3, sLength);

			CString sMaxLength;
			if (m_pRecordDef)
				sMaxLength.Format("%d", m_pRecordDef->GetFieldDefs().Get(iRow).GetLength());
			else
				sMaxLength = "?";
			m_Grid.SetItemText(iIndex, 4, sMaxLength);

			CString sOffset;
			sOffset.Format("%d", m_pRecord->m_awFieldOffset[iRow]);
			m_Grid.SetItemText(iIndex, 5, sOffset);
		}
	}

	if ((m_pRecord->HasKey()))
	{
		m_sFlags += _T("Key  ");

		int iKeySize = m_pRecord->GetKeySize();
		if (m_pRecord->m_wKeyOffset <= recordMaxKeyOffset)
			m_sKeyInfo.Format("Size is %d, Offset is %d", iKeySize, int(m_pRecord->m_wKeyOffset));
		else
		{
			WORD wFields = WORD(m_pRecord->m_wKeyOffset - recordMaxKeyOffset);
			m_sKeyInfo.Format("Size is %d, %d key field(s)", iKeySize, int(wFields));
		}

		CString sText;
		CString sHex;

		LPCTSTR pcszKey = LPCTSTR(m_pRecord->GetKeyPtr());
		for (int i = 0; i < iKeySize; ++i)
		{
			if (_istprint(pcszKey[i]))
				sText += pcszKey[i];
			else
				sText += _T("^");
			CString sChar;
			sChar.Format("%02X ", pcszKey[i]);
			sHex += sChar;
		}

		m_sKey = sText;
		m_sKey += _T("\r\n");
		m_sKey += sHex;
	}
	else
		m_sKeyInfo = _T("No Key");

	if ((m_pRecord->IsAlternate()))
	{
		m_sFlags += _T("Alt  ");
		LPCTSTR pcszKey = m_pRecord->GetAltKey();
		LPCTSTR pcszValue = m_pRecord->GetAltValue();
		m_sAlt = pcszKey;
		m_sAlt += _T("\r\n");
		m_sAlt += pcszValue;
	}

	UpdateData(false);
	CenterWindow();

	return true;  
}
