#ifndef _ENGINE_AREACODE_H_
#define _ENGINE_AREACODE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENT_H_
#	include "Engine\GeoElement.h"
#endif	// _ENGINE_GEOELEMENT_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAreaCode, CIuGeoElement }}
#define CIuAreaCode_super CIuGeoElement
#pragma pack(1)
class CIuAreaCode : public CIuAreaCode_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAreaCode() const;
	LPCTSTR GetAreaCodeAsString() const;
	LPCTSTR GetAreaCodeName() const;
	int GetStateNo() const;
	void GetZipList(CIuGeoList&) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoAreaCode;
	// Fixed Data:
		// Area code as an integer
		int m_iAreaCode;
		// State no as an offset into the states collection
		int m_iStateNo;
	// Variable Data:
		// List of associated ZIP's	
	// Strings:
		//	0) Area code as a string
		//	1) Descriptive name of area code
//}}Data

};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAreaCode::GetAreaCode() const
{
	return m_iAreaCode;
}

inline LPCTSTR CIuAreaCode::GetAreaCodeAsString() const
{
	return GetName();	
}

inline LPCTSTR CIuAreaCode::GetAreaCodeName() const
{
	return GetString(1);
}

inline int CIuAreaCode::GetStateNo() const
{
	return m_iStateNo;
}

#endif // _ENGINE_AREACODE_H_
