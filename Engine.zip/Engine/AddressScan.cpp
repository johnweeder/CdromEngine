#include "StdAfx.h"
//{{Include
#include "AddressScan.h"
#include "AddressCodec.h"
#include "resource.h"
#include "RecordFile.h"
#include "FieldMap.h"
#include "CdromSpec.h"
#include "AddressRaw.h"
#include "AddressSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddressScan, CIuAddressScan_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddressScan)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESSSCAN, CIuAddressScan, CIuAddressScan_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddressScan, IDS_ENGINE_PPG_ADDRESSSCAN, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressScan, IDS_ENGINE_PROP_RAW, GetRaw_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuAddressScan, IDS_ENGINE_PROP_RAW, IDS_ENGINE_PPG_ADDRESSSCAN, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressScan, IDS_ENGINE_PROP_INPUT, GetInput_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuAddressScan, IDS_ENGINE_PROP_INPUT, IDS_ENGINE_PPG_ADDRESSSCAN, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuAddressScan, IDS_ENGINE_PROP_CODEC, GetCodec_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuAddressScan, IDS_ENGINE_PROP_CODEC, IDS_ENGINE_PPG_ADDRESSSCAN, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuAddressScan, IDS_ENGINE_PROP_APPEND, ShouldAppend, SetAppend, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuAddressScan, IDS_ENGINE_PROP_APPEND, IDS_ENGINE_PPG_ADDRESSSCAN, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()																		

CIuAddressScan::CIuAddressScan() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddressScan::~CIuAddressScan()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuAddressScan::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("AddressScan"));
	if (m_pRaw.IsNull())
	{
		m_pRaw.Create();
	}
	if (m_pCodec.IsNull())
	{
		m_pCodec.Create();
	}
	m_fAppend = false;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuAddressScan::Delete(CIuOutput* pOutput)
{
	GetRaw().Delete(pOutput);
}

CIuObject* CIuAddressScan::GetCodec_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pCodec.Ptr()));
}

CIuObject* CIuAddressScan::GetRaw_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRaw.Ptr()));
}

void CIuAddressScan::OnClose(CIuOutput& Output)
{
	Output.OutputF("Address scan complete\n");
	CIuAddressScan_super::OnClose(Output);

	Output.SetMessage("Writing addresses");
	Output.Fire();
	GetRaw().GetSuffixes().AddBlank(0x7FFFFFFF);
	GetRaw().Write();

	GetRaw().Dump(Output);

	// Having completed the scan and written the output, we now clear the
	// output. Otherwise, the output will be a huge drag on memory resources.
	Output.SetMessage("Clearing addresses");
	Output.Fire();
	GetRaw().Empty();
}


bool CIuAddressScan::OnOpen(CIuOpenSpec& OpenSpec)
{
	ASSERT(OpenSpec.m_pOutput);
	if (!CIuAddressScan_super::OnOpen(OpenSpec))
		return false;

	CIuResolveSpec ResolveSpec = OpenSpec;
	ResolveSpec.m_pRecordDefSrc = &GetInput().GetRecordDef();
	GetCodec().Resolve(ResolveSpec);
	if (ShouldAppend())
		GetRaw().Read();
	else
	{
		GetRaw().Empty();
	}

	OpenSpec.m_pOutput->SetMessageF("Address scan %s from '%s'", LPCTSTR(GetName()), LPCTSTR(GetInput().GetFilename()));
	return OpenSpec.m_pOutput->Fire();
}

bool CIuAddressScan::OnProcess(const CIuRecord& Record, CIuOutput& Output)
{
	if (!GetCodec().Process(Record))
		return false;
	if (!GetRaw().Add(GetCodec(), Output))
		return true;
	return true;
}

void CIuAddressScan::SetAppend(bool f)
{
	m_fAppend = f;
}

void CIuAddressScan::SetSpec(CIuAddressSpec& Spec)
{
	SetMoniker(Spec.GetCdrom().GetMoniker());
	SetFilename(Spec.GetCdrom().GetFilename());
	CIuAddressScan_super::SetSpec(Spec.GetCdrom());
	GetCodec().SetSpec(Spec);
	GetRaw().SetSpec(Spec);
}
