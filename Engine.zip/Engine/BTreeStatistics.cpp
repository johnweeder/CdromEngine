#include "StdAfx.h"
//{{Include
#include "BTreeStatistics.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuBTreeStatistics::CIuBTreeStatistics() 
{
	Clear();
}

CIuBTreeStatistics::~CIuBTreeStatistics()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeStatistics::Clear()
{
	CIuBTreeStatistics_super::Clear();
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iTotalKeyNybbles = 0;
	m_iTotalFixedBits = 0;
	m_iTotalVariableBits = 0;
	m_iTotalVariableNybbles = 0;
	m_iTotalCountyCorrections = 0;
	m_iTotalMsaCorrections = 0;
	m_iTotalCityCorrections = 0;
	m_iTotalZip4 = 0;
	m_iTotalAlternates = 0;
	m_iTotalLatLongCentroidCorrections = 0;
	m_iTotalLatCentroidDelta = 0;
	m_iTotalLongCentroidDelta = 0;
	m_iTotalLatLongMinMaxCorrections = 0;
	m_iTotalLatMinMaxDelta = 0;
	m_iTotalLongMinMaxDelta = 0;
	m_iTotalGeoBits = 0;
	m_iTotalGeoNybbles = 0;
	m_iTotalPhoneBits = 0;
	m_iTotalPhoneNybbles = 0;
	m_iTotalTokenVariableBits = 0;
	m_iTotalTokenFixedBits = 0;
	m_iTotalTokenNybbles = 0;
	m_iTotalBusBits = 0;
	m_iTotalBusNybbles = 0;
	m_iTotalMiscBits = 0;
	m_iTotalMiscNybbles = 0;
	m_iTotalOptionalBits = 0;
	m_iTotalOptionalNybbles = 0;
	m_iTotalBus = 0;
	m_iTotalRes = 0;
	m_iTotalAddressFixedBits = 0;
	m_iTotalAddressVariableBits = 0;
	m_iTotalAddressNybbles = 0;

	memset(m_aiTotalPhoneFormat, 0, sizeof(m_aiTotalPhoneFormat));
	//}}Initialize
}

void CIuBTreeStatistics::Output(CIuOutput& Output)
{
	__int64 iDataRecords = m_iRecords - m_iTotalAlternates;
	ASSERT(iDataRecords >= 0);

	Output.OutputF(_T("%I64d total records in %I64d blocks of %I64d bytes each\n"), m_iRecords, m_iBlocks, m_iBytesPerBlocks);
	if (m_iBlocks > 0)
		Output.OutputF(_T("\t%I64d records per block\n"), m_iRecords / m_iBlocks);
	if (m_iRecords > 0)
		Output.OutputF(_T("\t%I64d bytes / record\n"),  (m_iBlocks * m_iBytesPerBlocks) / m_iRecords);
	if (m_iTotalAlternates > 0 && m_iRecords > 0)
		Output.OutputF(_T("\t%I64d alternate records, %s\n"),  m_iTotalAlternates, LPCTSTR(Percentage(m_iTotalAlternates, m_iRecords)));
	__int64 iNybbles = (m_iBlocks * m_iBytesPerBlocks * 2);
	Output.OutputF(_T("\t%I64d total nybbles output\n"),  m_iTotalNybbles);
	if (m_iRecords > 0)
		Output.OutputF(_T("\t\t%I64d nybbles / record, %I64d nybble min record size, %I64d max\n"),  m_iTotalNybbles /  m_iRecords, m_iMinRecordsNybbles,  m_iMaxRecordNybbles);
	__int64 iSlackNybbles = iNybbles - m_iTotalNybbles;
	if (iSlackNybbles > 0)
	{
		Output.OutputF(_T("\t\t%I64d slack nybbles output, %s\n"),  
			iSlackNybbles,  LPCTSTR(Percentage(iSlackNybbles, iNybbles)));
	}
	if (m_iTotalPrefixNybbles > 0)
	{
		Output.OutputF(_T("\t\t%I64d prefix nybbles, %I64d / record, %s\n"),  
			m_iTotalPrefixNybbles,  m_iTotalPrefixNybbles /  m_iRecords, LPCTSTR(Percentage(m_iTotalPrefixNybbles, m_iTotalRecordNybbles)));
	}
	if (m_iTotalOverheadNybbles > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t\t%I64d overhead nybbles, %I64d / record, %s\n"),
			m_iTotalOverheadNybbles,  m_iTotalOverheadNybbles / m_iRecords,  LPCTSTR(Percentage(m_iTotalOverheadNybbles, m_iTotalNybbles)));
	}
	if (m_iTotalRecordNybbles > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t%I64d raw record nybbles, %I64d / record\n"),
			m_iTotalRecordNybbles,  m_iTotalRecordNybbles /  m_iRecords);
	}
	if (m_iTotalCount > 0)
	{
		Output.OutputF(_T("\t%I64d index pointers\n"),  m_iTotalCount);
		if (m_iRecords > 0)
			Output.OutputF(_T("\t\t%I64d / record\n"),  (m_iTotalCount + m_iRecords - 1) /  m_iRecords);
	}
	if (m_iTotalFixedBits > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t%I64d fixed bits, %I64d / record\n"),  m_iTotalFixedBits,  m_iTotalFixedBits /  m_iRecords);
	}
	if (m_iTotalVariableBits > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t%I64d variable bits, %I64d / record\n"),  
			m_iTotalVariableBits,  m_iTotalVariableBits /  m_iRecords);
	}
	if (m_iTotalVariableNybbles > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t%I64d variable nybbles, %I64d / record\n"),  
			m_iTotalVariableNybbles,  m_iTotalVariableNybbles /  m_iRecords);
	}
	if (m_iTotalKeyNybbles > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t%I64d key nybbles, %I64d / record\n"),
			m_iTotalKeyNybbles,  m_iTotalKeyNybbles /  m_iRecords);
	}
	if (m_iTotalGeoBits > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Geo bits, %I64d / record\n"),	m_iTotalGeoBits, m_iTotalGeoBits /  m_iRecords);
	}
	if (m_iTotalGeoNybbles > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Geo nybbles, %I64d / record\n"),	m_iTotalGeoNybbles, m_iTotalGeoNybbles /  m_iRecords);
	}
	if (m_iTotalZip4 > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t\t%I64d records w/ ZIP+4, %s\n"),  
			m_iTotalZip4, LPCTSTR(Percentage(m_iTotalZip4, m_iRecords)));
	}
	if (m_iTotalCityCorrections > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t\t%I64d city/state corrections, %s\n"),  
			m_iTotalCityCorrections, LPCTSTR(Percentage(m_iTotalCityCorrections, m_iRecords)));
	}
	if (m_iTotalMsaCorrections > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t\t%I64d MSA corrections, %s\n"),  
			m_iTotalMsaCorrections, LPCTSTR(Percentage(m_iTotalMsaCorrections, m_iRecords)));
	}
	if (m_iTotalCountyCorrections > 0 && m_iRecords > 0)
	{
		Output.OutputF(_T("\t\t%I64d county corrections, %s\n"),  
			m_iTotalCountyCorrections, LPCTSTR(Percentage(m_iTotalCountyCorrections, m_iRecords)));
	}
	if (m_iTotalLatLongCentroidCorrections > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t\t%I64d lat/lon -> centroid corrections, %s, %I64d/%I64d avg lat/lon delta\n"),
			m_iTotalLatLongCentroidCorrections, LPCTSTR(Percentage(m_iTotalLatLongCentroidCorrections, m_iRecords)),  
			m_iTotalLatCentroidDelta /  m_iTotalLatLongCentroidCorrections,  m_iTotalLongCentroidDelta /  m_iTotalLatLongCentroidCorrections);
	}
	if (m_iTotalLatLongMinMaxCorrections > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t\t%I64d lat/lon -> min/max corrections, %s, %I64d/%I64d avg lat/lon delta\n"),
			m_iTotalLatLongMinMaxCorrections, LPCTSTR(Percentage(m_iTotalLatLongMinMaxCorrections, m_iRecords)),  
			m_iTotalLatMinMaxDelta /  m_iTotalLatLongMinMaxCorrections,  m_iTotalLongMinMaxDelta /  m_iTotalLatLongMinMaxCorrections);
	}
	if ((m_iTotalAddressFixedBits > 0 || m_iTotalAddressVariableBits > 0 || m_iTotalAddressNybbles > 0) && m_iRecords)
	{
		Output.OutputF(_T("\tAddress information:\n"));
		Output.OutputF(_T("\t\t%I64d fixed bits, %I64d / record\n"),	m_iTotalAddressFixedBits, m_iTotalAddressFixedBits /  m_iRecords);
		Output.OutputF(_T("\t\t%I64d variable bits, %I64d / record\n"),	m_iTotalAddressVariableBits, m_iTotalAddressVariableBits /  m_iRecords);
		Output.OutputF(_T("\t\t%I64d nybbles, %I64d / record\n"),	m_iTotalAddressNybbles, m_iTotalAddressNybbles /  m_iRecords);
		__int64 iTotalTokenBits = m_iTotalAddressFixedBits + m_iTotalAddressVariableBits + m_iTotalAddressNybbles * 4;
		Output.OutputF(_T("\t\t%I64d total bits, %I64d / record\n"),	iTotalTokenBits, iTotalTokenBits /  m_iRecords);
	}
	if (m_iTotalPhoneBits > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Phone bits, %I64d / record\n"),	m_iTotalPhoneBits, m_iTotalPhoneBits /  m_iRecords);
	}
	if (m_iTotalPhoneNybbles > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Phone nybbles, %I64d / record\n"),	m_iTotalPhoneNybbles, m_iTotalPhoneNybbles /  m_iRecords);
	}
	if (m_iRecords > 0)
	{
		Output.OutputF(_T("\tPhone counts by format: %I64d, %I64d, %I64d, %I64d, %I64d\n"),	
			m_aiTotalPhoneFormat[0], m_aiTotalPhoneFormat[1], m_aiTotalPhoneFormat[2], m_aiTotalPhoneFormat[3], m_aiTotalPhoneFormat[4]);
	}
	if ((m_iTotalTokenFixedBits > 0 || m_iTotalTokenVariableBits > 0 || m_iTotalTokenNybbles > 0) && m_iRecords)
	{
		Output.OutputF(_T("\tToken information:\n"));
		Output.OutputF(_T("\t\t%I64d fixed bits, %I64d / record\n"),	m_iTotalTokenFixedBits, m_iTotalTokenFixedBits /  m_iRecords);
		Output.OutputF(_T("\t\t%I64d variable bits, %I64d / record\n"),	m_iTotalTokenVariableBits, m_iTotalTokenVariableBits /  m_iRecords);
		Output.OutputF(_T("\t\t%I64d nybbles, %I64d / record\n"),	m_iTotalTokenNybbles, m_iTotalTokenNybbles /  m_iRecords);
		__int64 iTotalTokenBits = m_iTotalTokenFixedBits + m_iTotalTokenVariableBits + m_iTotalTokenNybbles * 4;
		Output.OutputF(_T("\t\t%I64d total bits, %I64d / record\n"),	iTotalTokenBits, iTotalTokenBits /  m_iRecords);
	}
	if (m_iTotalBusBits > 0 && m_iTotalBus)
	{
		Output.OutputF(_T("\t%I64d Bus bits, %I64d / record\n"),	m_iTotalBusBits, m_iTotalBusBits /  m_iTotalBus);
	}
	if (m_iTotalBusNybbles > 0 && m_iTotalBus)
	{
		Output.OutputF(_T("\t%I64d Bus nybbles, %I64d / record\n"),	m_iTotalBusNybbles, m_iTotalBusNybbles /  m_iTotalBus);
	}
	if (m_iTotalMiscBits > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Misc bits, %I64d / record\n"),	m_iTotalMiscBits, m_iTotalMiscBits /  m_iRecords);
	}
	if (m_iTotalMiscNybbles > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Misc nybbles, %I64d / record\n"),	m_iTotalMiscNybbles, m_iTotalMiscNybbles /  m_iRecords);
	}
	if (m_iTotalOptionalBits > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Optional bits, %I64d / record\n"),	m_iTotalOptionalBits, m_iTotalOptionalBits /  m_iRecords);
	}
	if (m_iTotalOptionalNybbles > 0 && m_iRecords)
	{
		Output.OutputF(_T("\t%I64d Optional nybbles, %I64d / record\n"),	m_iTotalOptionalNybbles, m_iTotalGeoNybbles /  m_iRecords);
	}
	Output.Fire();
}

CString CIuBTreeStatistics::Percentage(__int64 iNum, __int64 iDen)
{
	if (iDen == 0)
		return CString("0 %%");

	__int64 iPercent = (iNum * 1000) / iDen;
	CString sPercent;
	sPercent.Format(_T("%d.%d %%"), int(iPercent / 10), int(iPercent % 10));
	return sPercent;
}
