#ifndef _ENGINE_RECORDPTR_H_
#define _ENGINE_RECORDPTR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
#ifndef 	_ENGINE_RECORDSPEC_H_
#	include "Engine\RecordSpec.h"
#endif	// _ENGINE_RECORDSPEC_H_
class CIuFieldMap;
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordPtr}}
//	Records are almost always accessed through a record ptr. The pointer 
//		allows the record to grow dynamically instead of needing to be resized.

class IU_CLASS_EXPORT CIuRecordPtr
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordPtr();
	CIuRecordPtr(const CIuRecordPtr& pRecord);
	CIuRecordPtr(const CIuRecord& Record);
	CIuRecordPtr(const CIuRecord& Record, const CIuFieldMap& Map);
	CIuRecordPtr(CIuRecordSpec& RecordSpec);
	~CIuRecordPtr();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool IsNull() const;
	bool NotNull() const;
	CIuRecord* Ptr();
	CIuRecord* Ptr() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Attach(const CIuRecord* pRecord, bool fInitial);
	void Clear(bool fHiVal = false);
	void Create(CIuRecordSpec& RecordSpec);
	void Map(const CIuRecord& Record, const CIuFieldMap& Map);
	void Release();
	void Set(const CIuRecord& Record);
	void SetBuffer(const BYTE* pb, int cb);
	void SetExpandCount(DWORD dwExpandCount);
	void SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount);
	void SetKey(const BYTE* pbKey, int cbKey);
	void SetKey(int iFields);
	void SetLatLong(DWORD dwLat, DWORD dwLong);
	void SetRecordNo(DWORD dwRecordNo);
	void SetSourceNo(DWORD dwSourceNo);
	void SetSubSet(const CIuRecord& Record, int iFirst, int iCount);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	const CIuRecord& operator*() const;
	CIuRecord& operator*();
	const CIuRecord* operator->() const;
	CIuRecord* operator->();
	CIuRecordPtr& operator=(const CIuRecordPtr& pRecord);
	CIuRecordPtr& operator=(const CIuRecord& Record);
	operator CIuRecord*();
	operator const CIuRecord*() const;
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	bool ResizeFlags(WORD wFlags);
	bool ResizeKey(int cbKey);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuRecord* m_p;
//}}Data
};

typedef CArray<CIuRecordPtr,CIuRecordPtr> CIuRecordPtrArray;

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuRecordPtr::IsNull() const
{
	return m_p == 0;
}

inline bool CIuRecordPtr::NotNull() const
{
	return m_p != 0;
}

inline const CIuRecord& CIuRecordPtr::operator*() const
{
	ASSERT(m_p != 0); 
	return *m_p; 
}

inline CIuRecord& CIuRecordPtr::operator*() 
{
	ASSERT(m_p != 0); 
	return *m_p; 
}

inline const CIuRecord* CIuRecordPtr::operator->() const
{ 
	ASSERT(m_p != 0); 
	return m_p; 
}

inline CIuRecord* CIuRecordPtr::operator->() 
{ 
	ASSERT(m_p != 0);
	return m_p; 
}

inline CIuRecordPtr& CIuRecordPtr::operator=(const CIuRecord& Record)
{
	Set(Record);
	return *this;	
}

inline CIuRecordPtr& CIuRecordPtr::operator=(const CIuRecordPtr& pRecord)
{
	if (this == &pRecord)
		return *this;
	Release();
	m_p = pRecord.m_p;
	if (m_p)
		m_p->AddRef();
	return *this;	
}

inline CIuRecordPtr::operator CIuRecord*() 
{
	return m_p;
}

inline CIuRecordPtr::operator const CIuRecord*() const
{
	return m_p;
}

inline CIuRecord* CIuRecordPtr::Ptr()
{
	return m_p;
}

inline CIuRecord* CIuRecordPtr::Ptr() const
{
	return m_p;
}

#endif // _ENGINE_RECORDPTR_H_
