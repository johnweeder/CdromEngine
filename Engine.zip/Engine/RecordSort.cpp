#include "StdAfx.h"
//{{Include
#include "RecordSort.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\DataFilename.h"
#include "Error\Error.h"
#include "Data\resource.h"
#include "Common\String.h"
#include "Miscellaneous.h"
#include "CdromSpecConst.h"
#include "..\Version.h"
#include "ResolveSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRecordSort, CIuRecordSort_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordSort)
//}}Implement						 

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDSORT, CIuRecordSort, CIuRecordSort_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordSort, IDS_ENGINE_PROP_BUFFERSIZE, GetBufferSize, SetBufferSize, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordSort, IDS_ENGINE_PROP_MERGESIZE, GetMergeSize, SetMergeSize, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuRecordSort, IDS_ENGINE_PROP_DEDUP, GetDeDup, SetDeDup, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordSort, IDS_ENGINE_PROP_FULLOUTPUT, GetFullOutput, SetStringNotSupported, propertyNoSerialize)

	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordSort, IDS_ENGINE_PROP_INPUTFILE, GetInputFile_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordSort, IDS_ENGINE_PROP_KEYMAP, GetKeyMap_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_ACTION(CIuRecordSort, IDS_ENGINE_ACTION_SORT, ActionSort, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuRecordSort, IDS_ENGINE_PROP_KEYMAP, 0)

	IU_ATTRIBUTE_PAGE(CIuRecordSort, IDS_ENGINE_PPG_RECORDSORT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordSort, IDS_ENGINE_PROP_INPUT, GetInput, SetInput, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuRecordSort, IDS_ENGINE_PROP_INPUT, IDS_ENGINE_PPG_RECORDSORT, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordSort, IDS_ENGINE_PROP_OUTPUT, GetOutput, SetOutput, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuRecordSort, IDS_ENGINE_PROP_OUTPUT, IDS_ENGINE_PPG_RECORDSORT, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordSort, IDS_ENGINE_PROP_BUFFERSIZE, IDS_ENGINE_PPG_RECORDSORT, 100, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordSort, IDS_ENGINE_PROP_MERGESIZE, IDS_ENGINE_PPG_RECORDSORT, 2, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuRecordSort, IDS_ENGINE_PROP_DEDUP, IDS_ENGINE_PPG_RECORDSORT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuRecordSort, IDS_ENGINE_PROP_REORDER, ShouldReOrder, SetReOrder, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuRecordSort, IDS_ENGINE_PROP_REORDER, IDS_ENGINE_PPG_RECORDSORT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuRecordSort, IDS_ENGINE_PROP_STOREKEYS, StoreKeys, SetStoreKeys, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuRecordSort, IDS_ENGINE_PROP_STOREKEYS, IDS_ENGINE_PPG_RECORDSORT, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRecordSort, IDS_ENGINE_PROP_FULLOUTPUT, IDS_ENGINE_PPG_RECORDSORT, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuRecordSort, IDS_ENGINE_PROP_INPUTFILE, IDS_ENGINE_PPG_RECORDSORT, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRecordSort::CIuRecordSort() 
{
	//{{Initialize
	m_iSortFlags = 0;
	m_sOutput.Empty();
	m_iBufferSize = 250000;
	m_iMergeSize = 8;
	m_pOutput = 0;
	m_fDeDup = false;
	m_sFullOutput.Empty();
	SetName(_T("sort"));
	m_pInputFile.Create();
	m_pKeyMap.Create();
	m_fReOrder = false;
	m_fStoreKeys = false;
	m_sInput = "Input";
	SetVersion(IU_VERSION);
	//}}Initialize
}

CIuRecordSort::~CIuRecordSort()
{
	Close();
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuRecordSort::ActionSort(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	SetDeDup(Collection.GetBool(S(IDS_ENGINE_PROP_DEDUP), GetDeDup()));
	SetReOrder(Collection.GetBool(S(IDS_ENGINE_PROP_REORDER), ShouldReOrder()));
	if (!Build(Output, cdromsBuildProcess))
		return CString("Aborted!");
	return CString();
}

bool CIuRecordSort::Build(CIuOutput& Output, CIuFlags Flags)
{
	m_pOutput = &Output;

	// Output description, set range, etc
	if (!Output.Fire())
		return false;

	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);

	if (!Flags.Test(cdromsBuildProcess))
		return true;

	if (!OpenInput())
		return false;

	if (!CreateHeap())
		return false;

	CIuOutputStateInstance instance(*m_pOutput);
	if (!CreateRuns())
		return false;

	m_pInputFile->Close();

	if (m_apOutputFile.GetSize() == 1)
	{
		m_apOutputFile[0]->ClearTemporary();

		if (m_sOutput.IsEmpty())
			m_mirror.Mirror(m_pInputFile->GetFullFilename(), m_apOutputFile[0]->GetFullFilename());
		else
			m_mirror.Mirror(IuDataFilenameSearch(m_sOutput, extDataPrefix, m_pInputFile), m_apOutputFile[0]->GetFullFilename());

		m_iOutput = m_apOutputFile[0]->GetRecords();

		CIuFilename filename = m_mirror.GetMirrorFilename();

		m_pOutput->SetMessageF("Copying '%s' to output file '%s'\n", LPCTSTR(filename), LPCTSTR(m_mirror.GetOriginalFilename()));
		m_pOutput->Fire();

		filename.CopyTo(m_mirror.GetOriginalFilename());

		m_sFullOutput = m_mirror.Complete();
	}
	else if (m_apOutputFile.GetSize() > 1)
	{
		if (!Merge())
			return false;
	}

	ASSERT(m_iOutput + m_iDeDuped == m_iInput);
	if (m_iOutput + m_iDeDuped != m_iInput)
		Error(IU_E_SORT_FATAL, _T("Output record count does not match input."));

	CIuFilename filename = GetFullOutput();
	if (filename.IsEmpty())
		filename = GetInputFile().GetFullFilename();

	m_pOutput->OutputF("%ld records sorted into %s\n", m_iOutput, LPCTSTR(filename));
	if (m_iDeDuped > 0)
		m_pOutput->OutputF("%ld records deduped\n", m_iDeDuped);

	Close();

	// Pop progress instance and return abort code
	instance.Pop(true);
	return m_pOutput->Fire();
}

void CIuRecordSort::Close()
{
	m_pInputFile->Close();
	m_apOutputFile.RemoveAll();
	m_mirror.Rollback();
}

bool CIuRecordSort::CreateHeap()
{
	m_pOutput->SetMessageF("Initializing");
	m_pOutput->Fire();

	m_iSortFlags = recordSortRecordNo;

	if (ShouldReOrder())
		m_iSortFlags &= ~recordSortRecordNo;

	// Don't do record no sorting if deduping... it won't work
	if (m_fDeDup)
		m_iSortFlags &= ~recordSortRecordNo;

	// If no fields, create a default mapping of _all_ the fields
	int iFields = GetKeyMap().GetFieldCount();
	if (iFields == 0)
	{
		iFields = m_pInputFile->GetRecordDef().GetFieldDefs().GetCount();
		for (int iField = 0; iField < iFields; ++iField)
		{
			GetKeyMap().AddField(m_pInputFile->GetRecordDef().GetFieldDefs().Get(iField).GetName());
		}
	}

	CIuResolveSpec Spec;
	Spec.m_pRecordDefSrc = &m_pInputFile->GetRecordDef();
	GetKeyMap().Resolve(Spec);

	m_hs.SetSize(GetBufferSize());
	m_hs.SetSortFlags(m_iSortFlags);

	m_pOutput->Output("Sorting By: ");
	int iKeys = GetKeyMap().GetKeyCount();
	for (int iKey = 0; iKey < iKeys; ++iKey)
	{
		CString sKey = GetKeyMap().GetKey(iKey);
		m_pOutput->OutputF("%s%s", (iKey ? ", ": ""), LPCTSTR(sKey));
	}

	m_pOutput->Output(_T("\n"));
	m_pOutput->Fire();

	return m_pOutput->Fire();
}

CIuRecordFilePtr CIuRecordSort::CreateRun(bool fFinal)
{
	m_pRecordPrev.Clear();

	CIuRecordFilePtr pOutputFile;
	pOutputFile.Create();

	// Copy the field defs
	pOutputFile->GetRecordDef() = m_pInputFile->GetRecordDef();

	if (fFinal)
	{
		if (m_sOutput.IsEmpty())
			m_mirror.Mirror(m_pInputFile->GetFullFilename());
		else
			m_mirror.Mirror(IuDataFilenameSearch(m_sOutput, extDataPrefix, m_pInputFile));

		pOutputFile->SetFilename(m_mirror.GetMirrorFilename());
		CIuOpenSpec OpenSpec;
		pOutputFile->Create(OpenSpec);
	}
	else
	{
		pOutputFile->SetTemporary(true);
		CIuOpenSpec OpenSpec;
		pOutputFile->Create(OpenSpec);
	}

	m_apOutputFile.Add(pOutputFile);

	return pOutputFile;
}

bool CIuRecordSort::CreateRuns()
{
	int iRecords = m_pInputFile->GetRecords();
	if (iRecords == 0)
		return true;

	CIuOutputStateInstance instance(*m_pOutput);

	m_pOutput->SetMessageF("Creating runs, preloading heap");
	m_pOutput->SetPosition(0);
	m_pOutput->SetRange(iRecords);
	m_pOutput->Fire();

	// Preload the primary heap
	for (int iRecord = 0; iRecord < min(iRecords, GetBufferSize()); ++iRecord)
	{
		if ((iRecord % ((iRecords + 99) / 100)) == 0)
		{
			m_pOutput->SetPosition(iRecord);
			if (!m_pOutput->Fire())
				return false;
		}
		m_pInputFile->Get(iRecord, m_pRecord);
		m_pRecordMapped.Map(*m_pRecord, *m_pKeyMap);
		m_hs.Insert(*m_pRecordMapped);
	}

	// Create the first output file (and possibly the only output file
	bool fFinal = iRecord >= iRecords;
	CIuRecordFilePtr pOutputFile = CreateRun();

	// While records remain, keep creating runs
	bool fFirstPass = true;
	while (iRecord < iRecords)
	{
		if (fFirstPass || (iRecord % ((iRecords + 99) / 100)) == 0)
		{
			m_pOutput->SetMessageF("Creating run %d", m_apOutputFile.GetSize());
			m_pOutput->SetPosition(iRecord);
			if (!m_pOutput->Fire())
				return false;
			fFirstPass = false;
		}

		// Read the next record
		m_pInputFile->Get(iRecord, m_pRecord);
		m_pRecordMapped.Map(*m_pRecord, *m_pKeyMap);

		// Compare to last record output
		int iCmp = m_pRecordMapped->Compare(*m_pRecordPrev, m_iSortFlags);

		// Check if record being output is a duplicate
		if (iCmp == 0 && m_fDeDup)
		{
			++m_iDeDuped;
			++iRecord;
			continue;
		}

		// Check if it is GE the last output record and smaller than the lowest
		// element on the heap
		if (iCmp >= 0)
		{
			// If heap is empty, keep outputting as int as we can
			if (m_hs.IsEmpty())
			{
				m_pRecordPrev.Set(*m_pRecordMapped);
				if (ShouldReOrder())
					m_pRecordMapped->SetRecordNo(pOutputFile->GetRecords());
				pOutputFile->Append(*m_pRecordMapped);
				++iRecord;
				continue;
			}
			// If LE smallest on heap, output it
			CIuRecord* pRecordNext = m_hs.Peek();
			ASSERT(pRecordNext);
			if (m_pRecordMapped->Compare(*pRecordNext, m_iSortFlags) <= 0)
			{
				m_pRecordPrev.Set(*m_pRecordMapped);
				if (ShouldReOrder())
					m_pRecordMapped->SetRecordNo(pOutputFile->GetRecords());
				pOutputFile->Append(*m_pRecordMapped);
				++iRecord;
				continue;
			}
		}

		// If the heap is empty, we need to restart it
		if (m_hs.IsEmpty())
		{
			pOutputFile->Close();
			pOutputFile = CreateRun();
			m_hs.StoreSort();
			continue;
		}

		// Remove the lowest from the heap
		CIuRecordPtr pRecordNext = m_hs.Remove();

		// Check if record being output is a duplicate
		iCmp = pRecordNext->Compare(*m_pRecordPrev, m_iSortFlags);
		ASSERT(iCmp >= 0);
		if (iCmp < 0)
			Error(IU_E_SORT_FATAL, _T("Out of order creating runs (1)."));
		if (iCmp > 0 || !m_fDeDup)
		{
			m_pRecordPrev.Set(*pRecordNext);
			// Write it
			if (ShouldReOrder())
				pRecordNext.SetRecordNo(pOutputFile->GetRecords());
			pOutputFile->Append(*pRecordNext);
		}
		else
		{
			++m_iDeDuped;
		}

		// If the new record is larger than what was output, insert it into the heap.
		// Otherwise, store it for the next pass
		if (m_pRecordMapped->Compare(*m_pRecordPrev, m_iSortFlags) >= 0)
			m_hs.Insert(*m_pRecordMapped);
		else
			m_hs.Store(*m_pRecordMapped);
		++iRecord;
	}

	// Output anything left in the primary heap
	if (!m_hs.IsEmpty())
	{
		CIuOutputStateInstance instance(*m_pOutput);
		m_pOutput->SetMessageF("Creating run %d, clearing heap", m_apOutputFile.GetSize());
		m_pOutput->SetPosition(0);
		m_pOutput->SetRange(m_hs.GetNumElements());
		if (!m_pOutput->Fire())
			return false;

		int iRecords = m_hs.GetNumElements();
		for (iRecord = 0; m_hs.GetNumElements() > 0; ++iRecord)
		{
			if ((iRecord % ((iRecords + 99) / 100)) == 0)
			{
				m_pOutput->SetMessageF("Creating run %d, clearing heap", m_apOutputFile.GetSize());
				m_pOutput->SetPosition(iRecord);
				if (!m_pOutput->Fire())
					return false;
			}

			CIuRecordPtr pRemoved = m_hs.Remove();
			// Check if record being output is a duplicate
			int iCmp = pRemoved->Compare(*m_pRecordPrev, m_iSortFlags);
			if (iCmp == 0 && m_fDeDup)
			{
				++m_iDeDuped;
				continue;
			}
			ASSERT(iCmp >= 0);
			if (iCmp < 0)
			{
				pRemoved->Dump();
				m_pRecordPrev->Dump();
				Error(IU_E_SORT_FATAL, _T("Out of order creating runs (2)."));
			}
			m_pRecordPrev.Set(*pRemoved);
			if (ShouldReOrder())
				pRemoved.SetRecordNo(pOutputFile->GetRecords());
			if (fFinal && !StoreKeys())
				pRemoved->SetKey();
			pOutputFile->Append(*pRemoved);
		}
	}

	// Close current output file
	m_pOutput->SetMessageF("Close output");
	pOutputFile->Close();

	// If anything is left in storage, sort it and dump it
	m_hs.StoreSort();
	if (!m_hs.IsEmpty())
	{
		ASSERT(!fFinal);

		CIuOutputStateInstance instance(*m_pOutput);
		m_pOutput->SetMessageF("Creating run %d, clearing heap", m_apOutputFile.GetSize());
		m_pOutput->SetPosition(0);
		m_pOutput->SetRange(m_hs.GetNumElements());
		m_pOutput->Fire();

		pOutputFile = CreateRun();
		int iRecords = m_hs.GetNumElements();
		for (iRecord = 0; m_hs.GetNumElements() > 0; ++iRecord)
		{
			if ((iRecord % ((iRecords + 99) / 100)) == 0)
			{
				m_pOutput->SetMessageF("Creating run %d, clearing heap", m_apOutputFile.GetSize());
				m_pOutput->SetPosition(iRecord);
				if (!m_pOutput->Fire())
					return false;
			}

			CIuRecordPtr pRemoved = m_hs.Remove();
			// Check if record being output is a duplicate
			int iCmp = pRemoved->Compare(*m_pRecordPrev, m_iSortFlags);
			if (iCmp == 0 && m_fDeDup)
			{
				++m_iDeDuped;
				continue;
			}
			m_pRecordPrev.Set(*pRemoved);
			if (ShouldReOrder())
				pRemoved.SetRecordNo(pOutputFile->GetRecords());
			pOutputFile->Append(*pRemoved);
		}
		pOutputFile->Close();
	}

	m_pOutput->SetMessageF("Created %d run(s)", m_apOutputFile.GetSize());
	return m_pOutput->Fire();
}

void CIuRecordSort::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullOutput(), pOutput);
}

int CIuRecordSort::GetBufferSize() const
{
	return m_iBufferSize;
}

bool CIuRecordSort::GetDeDup() const
{
	return m_fDeDup;
}

CString CIuRecordSort::GetFullOutput() const
{
	return m_sFullOutput;
}

CIuRecordFile& CIuRecordSort::GetInputFile() const
{
	return m_pInputFile.Ref();
}

CIuObject* CIuRecordSort::GetInputFile_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInputFile.Ptr()));
}

CIuFieldMap& CIuRecordSort::GetKeyMap() const
{
	return m_pKeyMap.Ref();
}

CIuObject* CIuRecordSort::GetKeyMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pKeyMap.Ptr()));
}

int CIuRecordSort::GetMergeSize() const
{
	return m_iMergeSize;
}

CString CIuRecordSort::GetOutput() const
{
	return m_sOutput;
}

bool CIuRecordSort::Merge()
{
	if (m_apOutputFile.GetSize() <= 1)
		return true;

	// Get merge size
	int iMergeSize = min(m_iMergeSize, m_apOutputFile.GetSize());
	ASSERT(iMergeSize > 1);

	m_pOutput->SetMessageF("Merging files");
	m_pOutput->Fire();

	// Construct records out of the buffer
	CIuRecordPtrArray array;
	for (int i = 0; i < iMergeSize; ++i)
	{
		CIuRecordPtr pRecord;
		array.Add(pRecord);
	}

	// Keep merging until one is left
	while (m_apOutputFile.GetSize() > 1)
	{
		int iInputs = min(iMergeSize, m_apOutputFile.GetSize());
		if (!Merge(iInputs, array))
			return false;
	}

	ASSERT(m_apOutputFile.GetSize() == 1);
	if (m_apOutputFile.GetSize() != 1)
		Error(IU_E_SORT_FATAL, _T("Merge failed."));

	m_pOutput->SetMessageF("Cleaing up merge files");
	m_pOutput->Fire();

	m_apOutputFile[0]->ClearTemporary();
	m_apOutputFile[0]->Close();
	m_iOutput = m_apOutputFile[0]->GetRecords();
	m_apOutputFile.RemoveAll();

	// The last merge run was set to be the output file
	// Update the output filename if necessary
	m_sFullOutput = m_mirror.Complete();

	return m_pOutput->Fire();
}

bool CIuRecordSort::Merge(int iMerge, CIuRecordPtrArray& array)
{
	ASSERT(iMerge > 1);

	CIuOutputStateInstance instance(*m_pOutput);

	m_pOutput->SetMessageF("Merging %d files", iMerge);
	if (!m_pOutput->Fire())
		return false;

	// Open the inputs and preload
	int iRecords = 0;
	CArray<CIuRecordFilePtr, CIuRecordFile*> apInputFile;
	for (int i = 0; i < iMerge; ++i)
	{
		CIuRecordFilePtr pInput = m_apOutputFile[i];
		CIuOpenSpec OpenSpec;
		pInput->Open(OpenSpec);
		pInput->MoveFirst();
		pInput->MoveNext(array[i]);

		apInputFile.Add(pInput);

		iRecords += pInput->GetRecords();
	}

	m_pOutput->SetPosition(0);
	m_pOutput->SetRange(iRecords);
	m_pOutput->Fire();

	// Create the output file. If this is the final merge, create it in the correct
	// output location.
	bool fFinal = iMerge == m_apOutputFile.GetSize();
	CIuRecordFilePtr pOutputFile = CreateRun(fFinal);

	for (int iRecord = 0; iRecord < iRecords; ++iRecord)
	{
		if ((iRecord % ((iRecords + 99) / 100)) == 0)
		{
			m_pOutput->SetPosition(iRecord);
			if (!m_pOutput->Fire())
				break;
		}

		// Find the lowest record
		int iLowest = 0;
		for (i = 1; i < iMerge; ++i)
		{
			if (array[i]->Compare(*array[iLowest], m_iSortFlags) < 0)
				iLowest = i;
		}

		ASSERT(!array[iLowest]->IsHiVal());

		// Check if record being output is a duplicate
		int iCmp = array[iLowest]->Compare(*m_pRecordPrev, m_iSortFlags);
		ASSERT(iCmp >= 0);
		if (iCmp < 0)
			Error(IU_E_SORT_FATAL, _T("Merge out of order."));
		if (iCmp != 0 || !m_fDeDup)
		{
			// Save the value (before changing record no or clearing key
			m_pRecordPrev.Set(*array[iLowest]);
			if (ShouldReOrder())
				array[iLowest]->SetRecordNo(pOutputFile->GetRecords());
			if (fFinal && !StoreKeys())
				array[iLowest]->SetKey();
			pOutputFile->Append(*array[iLowest]);
		}
		else
			++m_iDeDuped;

		if (apInputFile[iLowest]->IsEof())
		{
			// Clear to hi-vals so input is never selected again.			
			array[iLowest]->Clear(true);
		}
		else
		{
			if (!apInputFile[iLowest]->MoveNext(array[iLowest]))
				array[iLowest]->Clear(true);
		}
	}

	// Close files
	for (i = 0; i < iMerge; ++i)
	{
		CIuRecordFile* pFile = apInputFile[0];

		// Check all inputs are at eof
		if (!pFile->IsEof())
		{
			// We may need to do a read to force a move to eof
			CIuRecordPtr pRecord;
			if (pFile->MoveNext(pRecord) || !pFile->IsEof())
				Error(IU_E_SORT_FATAL, _T("Merge did not use all records."));
		}

		// Close file and remove 
		// File is marked as temporary so it will automatically delete
		pFile->Close();

		apInputFile.RemoveAt(0);

		// Also, remove the original output file
		m_apOutputFile.RemoveAt(0);
	}

	pOutputFile->Close();
	return m_pOutput->Fire();
}

void CIuRecordSort::OnEditBegin()
{
	// Load the actual record definition if possible
	IU_TRY_ERROR
	{
		if (GetInputFile().Exists())
			GetInputFile().LoadFromRecordFile(GetInputFile().GetFullFilename());
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
	}
}

bool CIuRecordSort::OpenInput()
{
	m_pOutput->SetMessageF(_T("Opening input"));
	m_pOutput->Fire();
	CIuOpenSpec OpenSpec;
	m_pInputFile->Open(OpenSpec);
	m_iInput = m_pInputFile->GetRecords();
	m_iDeDuped = 0;
	m_iOutput = 0;
	m_pOutput->OutputF("Sorting %ld records in '%s'\n", m_iInput, LPCTSTR(m_pInputFile->GetFullFilename()));
	return m_pOutput->Fire();
}

void CIuRecordSort::SetBufferSize(int i)
{
	m_iBufferSize = i;
}

void CIuRecordSort::SetDeDup(bool f)
{
	m_fDeDup = f;
}

void CIuRecordSort::SetInput(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sInput = pcsz;
	GetInputFile().SetFilename(pcsz);
}

void CIuRecordSort::SetMergeSize(int i)
{
	m_iMergeSize = i;
}

void CIuRecordSort::SetOutput(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOutput = pcsz;
}

void CIuRecordSort::SetSpec(int iSpec, LPCTSTR pcszInput, LPCTSTR pcszOutput)
{
	if (!_tcsisempty(pcszInput))
		SetInput(pcszInput);
	if (!_tcsisempty(pcszOutput))
		SetOutput(pcszOutput);
	switch (iSpec)
	{
		default:
			ASSERT(false);
		case sortStandardByName:
			GetKeyMap().SetSpec(mapNameKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortAddress:
			GetKeyMap().SetSpec(mapAddressKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortBusiness:
			GetKeyMap().SetSpec(mapBusinessKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortBusinessFranchise:
			GetKeyMap().SetSpec(mapBusinessFranchiseKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortPhone:
			GetKeyMap().SetSpec(mapPhoneKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortZip:
			GetKeyMap().SetSpec(mapZipKey);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortZip4:
			GetKeyMap().SetSpec(mapZip4Key);
			GetInputFile().SetFilename(pcszInput);
			break;
		case sortZip5:
			GetKeyMap().SetSpec(mapZip5Key);
			GetInputFile().SetFilename(pcszInput);
			break;
	}
}

void CIuRecordSort::SetReOrder(bool f)
{
	m_fReOrder = f;
}

void CIuRecordSort::SetStoreKeys(bool f)
{
	m_fStoreKeys = f;
}

