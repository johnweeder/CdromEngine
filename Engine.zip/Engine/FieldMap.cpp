#include "StdAfx.h"
//{{Include
#include "FieldMap.h"
#include "FieldMapSpec.h"
#include "Record.h"
#include "RecordDef.h"
#include "EngineApp.h"
#include "FieldDefs.h"
#include "Common\String.h"
#include "resource.h"
#include "Data\Output.h"
#include "Expression.h"
#include "Interop\Conversions.h"
#include "Error\Error.h"
#include "Common\Options.h"
#include "Data\resource.h"
#include "LatLongUnit.h"
#include "FieldDefSpec.h"
#include "FieldDefConst.h"
#include "..\Version.h"
#include "RecordSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuFieldMap, CIuFieldMap_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldMap)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_MAP, CIuFieldMap, CIuFieldMap_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuFieldMap, IDS_ENGINE_PPG_MAP, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuFieldMap, IDS_ENGINE_PROP_FIELDS, GetFields, SetFields, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuFieldMap, IDS_ENGINE_PROP_FIELDS, IDS_ENGINE_PPG_MAP, 5, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuFieldMap, IDS_ENGINE_PROP_KEYS, GetKeys, SetKeys, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuFieldMap, IDS_ENGINE_PROP_KEYS, IDS_ENGINE_PPG_MAP, 5, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuFieldMap, IDS_ENGINE_PROP_TRUNCATE, Truncate, SetTruncate, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuFieldMap, IDS_ENGINE_PROP_TRUNCATE, IDS_ENGINE_PPG_MAP, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldMap::CIuFieldMap() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuFieldMap::CIuFieldMap(const CIuFieldMap& rFieldMap)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rFieldMap;
}

CIuFieldMap::~CIuFieldMap()
{
	// Make sure all expressions are ultimately released....
	for (int i = 0; i < m_aFieldExpression.GetSize(); ++i)
		if (m_aFieldExpression[i] != 0)
			delete m_aFieldExpression[i];
	m_aFieldExpression.RemoveAll();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuFieldMap::AddField(LPCTSTR pcsz)
{
	SetResolved(false);
	ASSERT(AfxIsValidString(pcsz));
	if (_tcsisempty(pcsz))
		return -1;
	return m_asFields.Add(pcsz);
}

int CIuFieldMap::AddKey(LPCTSTR pcsz)
{
	SetResolved(false);
	ASSERT(AfxIsValidString(pcsz));
	if (_tcsisempty(pcsz))
		return -1;
	return m_asKeys.Add(pcsz);
}

int CIuFieldMap::AppendFields(const CIuFieldMap& Map, int* pCount)
{
	SetResolved(false);
	int iAppend = Map.m_asFields.GetSize();
	int iFirst = m_asFields.GetSize();
	for (int i = 0; i < iAppend; ++i)
		m_asFields.Add(Map.m_asFields[i]);
	if (pCount)
		*pCount = iAppend;
	return iFirst;
}

int CIuFieldMap::AppendKeys(const CIuFieldMap& Map, int* pCount)
{
	SetResolved(false);
	int iAppend = Map.m_asKeys.GetSize();
	int iFirst = m_asKeys.GetSize();
	for (int i = 0; i < iAppend; ++i)
		m_asKeys.Add(Map.m_asKeys[i]);
	if (pCount)
		*pCount = iAppend;
	return iFirst;
}

void CIuFieldMap::Clear()
{
	CIuFieldMap_super::Clear();
	CIuFieldMap::CommonConstruct();
}

void CIuFieldMap::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pRecordDef = 0;
	m_iBoughtLevel = 0;
	m_CaseConvert = caseNoConvert;
	m_asFields.RemoveAll();
	m_asKeys.RemoveAll();
	m_fResolved = false;
	m_iCount = 0;
	m_iFields = 0;
	m_iKeys = 0;
	m_aFieldNo.RemoveAll();
	m_aFieldFlags.RemoveAll();
	m_aFieldLength.RemoveAll();
	m_aFieldLiteral.RemoveAll();
	for (int i = 0; i < m_aFieldExpression.GetSize(); ++i)
		if (m_aFieldExpression[i] != 0)
			delete m_aFieldExpression[i];
	m_aFieldExpression.RemoveAll();
	SetName("FieldMap");
	SetVersion(IU_VERSION);
	m_fTruncate = false;
	//}}Initialize
}

void CIuFieldMap::Copy(const CIuObject& object)
{
	CIuFieldMap_super::Copy(object);

	const CIuFieldMap* pFieldMap = dynamic_cast<const CIuFieldMap*>(&object);
	if (pFieldMap == 0 || pFieldMap == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuFieldMap)));
	
	m_pRecordDef = pFieldMap->m_pRecordDef;
	m_asFields.Copy(pFieldMap->m_asFields);
	m_asKeys.Copy(pFieldMap->m_asKeys);
	m_KeyDef = pFieldMap->m_KeyDef;
	m_CaseConvert = pFieldMap->m_CaseConvert;
	m_iCount = pFieldMap->m_iCount;
	m_iFields = pFieldMap->m_iFields;
	m_iKeys = pFieldMap->m_iKeys;
	m_fResolved = pFieldMap->m_fResolved;
	m_iBoughtLevel = pFieldMap->m_iBoughtLevel;
	m_aFieldNo.Copy(pFieldMap->m_aFieldNo);
	m_aFieldFlags.Copy(pFieldMap->m_aFieldFlags);
	m_aFieldLength.Copy(pFieldMap->m_aFieldLength);
	m_aFieldLiteral.Copy(pFieldMap->m_aFieldLiteral);
	m_fTruncate = pFieldMap->m_fTruncate;
	for (int i = 0; i < m_aFieldExpression.GetSize(); ++i)
		if (m_aFieldExpression[i] != 0)
			delete m_aFieldExpression[i];
	m_aFieldExpression.RemoveAll();
	for (i = 0; i < pFieldMap->m_aFieldExpression.GetSize(); ++i)
	{
		if (pFieldMap->m_aFieldExpression[i])
			m_aFieldExpression.SetAtGrow(i, new CIuExpression(*pFieldMap->m_aFieldExpression[i]));
	}
}

void CIuFieldMap::CreateMap(const CIuRecordDef& RecordDef)
{
	SetResolved(false);
	RemoveAll();
	int iFields = RecordDef.GetFieldDefs().GetCount();
	for (int iField = 0; iField < iFields; ++iField)
	{
		CIuFieldDefSpec Spec(RecordDef.GetFieldDefs().Get(iField));
		CString sSpec = Spec.GetSpecification();
		AddField(sSpec);
	}
}

CString CIuFieldMap::GetExpression(int iWhich) const
{
	if (iWhich >= 0 && iWhich < m_asFields.GetSize())
		return m_asFields[iWhich];

	iWhich -= m_asFields.GetSize();

	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	return m_asKeys[iWhich];
}

int CIuFieldMap::GetExpressionCount() const
{
	return m_asFields.GetSize() + m_asKeys.GetSize();
}

CString CIuFieldMap::GetField(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < m_asFields.GetSize());
	return m_asFields[iWhich];
}


int CIuFieldMap::GetFieldCount() const
{
	return m_asFields.GetSize();
}

void CIuFieldMap::GetFields(CStringArray& as) const
{
	as.Copy(m_asFields);
}

CString CIuFieldMap::GetKey(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	return m_asKeys[iWhich];
}

int CIuFieldMap::GetKeyCount() const
{
	return m_asKeys.GetSize();
}

void CIuFieldMap::GetKeys(CStringArray& as) const
{
	as.Copy(m_asKeys);
}

void CIuFieldMap::Map(CIuRecordSpec& Spec, const CIuRecord& Record) const
{
	ASSERT(IsResolved());

	// Clear the new record spec
	Spec.Clear();

	// Resolve everything...
	ASSERT(m_iCount <= recordMaxFields);
	for (int iField = 0; iField < m_iCount; ++iField)
	{
		// Limit the number of fields
		// Maybe at a future date this could be dynamic....
		if (iField >= recordMaxFields)
			break;

		BYTE* pbConvert = 0;

		int iFieldNo = m_aFieldNo[iField];
		int iFieldFlags = m_aFieldFlags[iField];
		// Copy a raw field
		if (iFieldNo >= 0)
		{
			int iSize;
			LPCTSTR pcsz = Record.GetField(iFieldNo, iSize);
			if (iSize == 0)
				Spec.AddBlank();
			else
			{
				ASSERT(pcsz[iSize - 1] == '\0');
				if (m_CaseConvert != caseNoConvert)
					pbConvert = Spec.AddStore(reinterpret_cast<const BYTE*>(pcsz), iSize - 1);
				else
					Spec.Add(reinterpret_cast<const BYTE*>(pcsz), iSize - 1);
			}
		}
		else if (iFieldNo == specFieldNoKey)
		{
			// Use the key, note that it can contain embedded nulls. Convert them to linefeeds.
			// It is assumed that the key contains a trailing null.
			const BYTE* pbKey = Record.GetKeyPtr();
			ASSERT(pbKey > 0);
			int cbKey = Record.GetKeySize();
			ASSERT(cbKey > 0);
			--cbKey;

			pbConvert = Spec.AddStore(pbKey, cbKey);
			for (int i = 0; i < cbKey - 1; ++i)
			{
				if (pbConvert[i] == '\0')
					pbConvert[i] = keySeparatorChar;
			}
		}
		else if (iFieldNo == specFieldNoAlt)
		{
			LPCTSTR pcsz = Record.GetAltKey();
			if (m_CaseConvert != caseNoConvert)
				pbConvert = Spec.AddStore(pcsz);
			else
				Spec.Add(pcsz);
		}
		else if (iFieldNo == specFieldNoSeeAlso)
		{
			LPCTSTR pcsz = Record.GetAltValue();
			if (m_CaseConvert != caseNoConvert)
				pbConvert = Spec.AddStore(pcsz);
			else
				Spec.Add(pcsz);
		}
		else if (iFieldNo == specFieldNoRecordNo)
		{
			TCHAR sz[20];
			IntAsStringEx(sz, sizeof(sz), Record.GetRecordNo(), 10, -1, -1, false);
			Spec.AddStore(sz);
		}
		else if (iFieldNo == specFieldNoSourceNo)
		{
			TCHAR sz[20];
			IntAsStringEx(sz, sizeof(sz), Record.GetSourceNo(), 10, -1, -1, false);
			Spec.AddStore(sz);
		}
		else if (iFieldNo == specFieldNoExpandNo)
		{
			TCHAR sz[20];
			IntAsStringEx(sz, sizeof(sz), Record.GetExpandNo(), 10, -1, -1, false);
			Spec.AddStore(sz);
		}
		else if (iFieldNo == specFieldNoCount)
		{
			TCHAR sz[20];
			IntAsStringEx(sz, sizeof(sz), Record.GetExpandCount(), 10, -1, -1, false);
			Spec.AddStore(sz);
		}
		else if (iFieldNo == specFieldNoLatitude)
		{
			DWORD dwLat, dwLong;
			Record.GetLatLong(dwLat, dwLong);
			CIuLatLongUnit latitude(dwLat);
			Spec.AddStore(LPCTSTR(latitude.AsString()));
		}
		else if (iFieldNo == specFieldNoLongitude)
		{
			DWORD dwLat, dwLong;
			Record.GetLatLong(dwLat, dwLong);
			CIuLatLongUnit longitude(dwLong);
			Spec.AddStore(LPCTSTR(longitude.AsString()));
		}
		else if (iFieldNo == specFieldNoTagged)
		{
			Spec.AddStore(Record.IsTagged() ? "1": "0");
		}
		else if (iFieldNo == specFieldNoBought)
		{
			TCHAR sz[20];
			IntAsStringEx(sz, sizeof(sz), Record.GetBoughtLevel(), 10, -1, -1, false);
			Spec.AddStore(sz);
		}
		else if (iFieldNo == specFieldNoNoMail)
		{
			Spec.AddStore(Record.IsNoMail() ? "1": "0");
		}
		else if (iFieldNo == specFieldNoNoPhone)
		{
			Spec.AddStore(Record.IsNoPhone() ? "1": "0");
		}
		else if (iFieldNo == specFieldNoLiteral || iFieldNo == specFieldNoExpression)
		{
			LPCTSTR pcszValue;
			if (iFieldNo == specFieldNoLiteral)
				pcszValue = m_aFieldLiteral[iField];
			else
			{
				ASSERT(m_aFieldExpression[iField]);
				pcszValue = m_aFieldExpression[iField]->Evaluate(&Record);
			}
			Spec.AddStore(pcszValue);
			// NOTE: Case conversion for expression is handled by the expression
			//			evaluator because we don't want to shot-gun the conversion at
			//			this level.
		}
		else if (iFieldNo == specFieldNoBusiness)
		{
			Spec.AddStore(Record.IsBusiness() ? "1": "0");
		}
		else if (iFieldNo == specFieldNoResidence)
		{
			Spec.AddStore(Record.IsResidence() ? "1": "0");
		}
		else if (iFieldNo == specFieldNoBusResFlag)
		{
			Spec.AddStore(Record.IsResidence() ? "R": "B");
		}
		else /* if (iFieldNo == specFieldNoUnknown) */
		{
			ASSERT(iFieldNo == specFieldNoUnknown);
			Spec.AddBlank();
		}

		if (m_CaseConvert != caseNoConvert && pbConvert)
		{
			int iSize = Spec.GetFieldSize(iField);
			if (pbConvert && iSize > 0)
				CaseConvertInPlace(LPTSTR(pbConvert), iSize, m_CaseConvert, iFieldFlags);
		}

		// Enforce max field length
		if (Truncate())
		{
			int iFieldSize = Spec.GetFieldSize(iField);
			if (iFieldSize > m_aFieldLength[iField])
				Spec.GetFieldSize(m_aFieldLength[iField]);
		}
	}

	// There may be more fields than add than we need because the key fields are at the end
	// Therefore, set the actual number of "fields"
	Spec.SetRecordFields(m_iFields);

	// If a key was processed, create the raw key object
	if (m_iKeys > 0)
	{
		Spec.SetKey();
		CIuKey& Key = Spec.GetKey();
		Key.Clear();
		int iKeys = m_iFields + m_iKeys;
		for (int iKey = m_iFields; iKey < iKeys; ++iKey)
		{
			const BYTE* pbField = Spec.GetField(iKey);
			int cbField = Spec.GetFieldSize(iKey);
		
			Key.Append((const char*)pbField, cbField, m_KeyDef, false);
		}
	}
}

CIuFieldMap& CIuFieldMap::operator=(const CIuFieldMap& rFieldMap)
{
	Copy(rFieldMap);
	return *this;
}

void CIuFieldMap::RemoveAll()
{
	RemoveAllFields();
	RemoveAllKeys();
}

void CIuFieldMap::RemoveAllFields()
{
	SetResolved(false);
	m_asFields.RemoveAll();
}

void CIuFieldMap::RemoveAllKeys()
{
	SetResolved(false);
	m_asKeys.RemoveAll();
}

void CIuFieldMap::RemoveField(int iWhich)
{
	SetResolved(false);
	ASSERT(iWhich >= 0 && iWhich < m_asFields.GetSize());
	m_asFields.RemoveAt(iWhich);
}

void CIuFieldMap::RemoveKey(int iWhich)
{
	SetResolved(false);
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	m_asKeys.RemoveAt(iWhich);
}

void CIuFieldMap::Resolve(CIuResolveSpec& ResolveSpec)
{
	// Used if no source record def passed in.
	// Sometimes this is done just to generate the output record def.
	CIuRecordDef RecordDefSrc;
	const CIuRecordDef* pRecordDefSrc;

	if (ResolveSpec.m_pRecordDefSrc)
	{
		pRecordDefSrc = ResolveSpec.m_pRecordDefSrc;
		m_pRecordDef = ResolveSpec.m_pRecordDefSrc;
	}
	else
	{
		pRecordDefSrc = &RecordDefSrc;
		m_pRecordDef = 0;
	}
	ASSERT(pRecordDefSrc != 0);

	SetResolved(false);

	CIuRecordDef RecordDefDst;
	CIuRecordDef* pRecordDefDst;
	if (ResolveSpec.m_pRecordDefDst)
		pRecordDefDst = ResolveSpec.m_pRecordDefDst;
	else
		pRecordDefDst = &RecordDefDst;
	ASSERT(pRecordDefDst != 0);

	// Check case conversion mode
	if (ResolveSpec.m_pOptions)
	{
		if (ResolveSpec.m_pOptions->Find(IDS_ENGINE_CASE_MIXED) >= 0)
			m_CaseConvert = caseMixed;
		else if (ResolveSpec.m_pOptions->Find(IDS_ENGINE_CASE_UPPER) >= 0)
			m_CaseConvert = caseUpper;
		else if (ResolveSpec.m_pOptions->Find(IDS_ENGINE_CASE_LOWER) >= 0)
			m_CaseConvert = caseLower;
		else if (ResolveSpec.m_pOptions->Find(IDS_ENGINE_CASE_NONE) >= 0)
			m_CaseConvert = caseNoConvert;
	}

	// Clear everything related to resolution
	m_iBoughtLevel = 0;
	m_iCount = 0;
	m_iFields = 0;
	m_iKeys = 0;
	m_aFieldNo.RemoveAll();
	m_aFieldFlags.RemoveAll();
	m_aFieldLength.RemoveAll();
	m_aFieldLiteral.RemoveAll();
	for (int i = 0; i < m_aFieldExpression.GetSize(); ++i)
		if (m_aFieldExpression[i] != 0)
			delete m_aFieldExpression[i];
	m_aFieldExpression.RemoveAll();

	// Record defs for keys and fields
	pRecordDefDst->Clear();

	// Go through each of the mapped fields and process them
	int iExpressions = GetExpressionCount();
	ASSERT(iExpressions < recordMaxFields);
	CIuRecordDef RecordDefKeys;
	for (int iExpression = 0; iExpression < iExpressions; ++iExpression)
	{
		// The "field" being mapped an expression of the following format.
		//		newname(max_length, flag[,flag,...]):expression
		//
		// NOTES: 
		//		The "new name" is optional and specifies an output field name.
		//			If not specified, the input field name is used.
		//		The "max length" is optional and specifies the maximum size of the output field.
		//			If not specified, the input field size is used.
		//		Flags are also optional.
		//			If not specified, the input field flags is used.
		//		The expression is required, it can be either a field name, a literal or an actual expression.
		//		Field names can be enclosed in square brackets.
		// 	Literals must be quoted to be recognized
		CString sExpression = GetExpression(iExpression);

		// Parse the info out of the specification
		CIuFieldDefSpec Spec;
		Spec.SetCaseConvert(GetCaseConvert());
		Spec.Parse(sExpression);

		int iIndex = -1;
		int iLength = 0;
		int iFlags = 0;
		int iBoughtLevel = 0;
		if (iExpression < GetFieldCount())
		{
			CIuResolveSpec SpecTemp = ResolveSpec;
			SpecTemp.m_pRecordDefSrc = pRecordDefSrc;
			SpecTemp.m_pRecordDefDst = pRecordDefDst;
			iIndex = Spec.Resolve(SpecTemp);
			if (iIndex >= 0)
			{
				iFlags = pRecordDefDst->GetFieldDefs().Get(iIndex).GetFlags();
				iLength = pRecordDefDst->GetFieldDefs().Get(iIndex).GetLength();
				iBoughtLevel = pRecordDefDst->GetFieldDefs().Get(iIndex).GetBoughtLevel();
				// We should be appending to the end
				ASSERT(iIndex == m_iFields);
			}
		}
		else
		{
			CIuResolveSpec SpecTemp = ResolveSpec;
			SpecTemp.m_pRecordDefSrc = pRecordDefSrc;
			SpecTemp.m_pRecordDefDst = &RecordDefKeys;
			iIndex = Spec.Resolve(SpecTemp);
			if (iIndex >= 0)
			{
				iFlags = RecordDefKeys.GetFieldDefs().Get(iIndex).GetFlags();
				iLength = RecordDefKeys.GetFieldDefs().Get(iIndex).GetLength();
				// We should be appending to the end
				ASSERT(iIndex == m_iKeys);
			}
		}

		if (iIndex < 0 || Spec.GetFieldNo() == specFieldNoDiscard)
		{
			TRACE("WARNING: Field '%s' was discard by record map.\n", LPCTSTR(sExpression));
			continue;
		}

		m_iCount++;
		m_aFieldNo.Add(Spec.GetFieldNo());
		m_aFieldLiteral.Add(Spec.GetLiteral());
		m_aFieldExpression.Add(Spec.DetachExpressionPtr());
		m_aFieldFlags.Add(iFlags);
		m_aFieldLength.Add(iLength);

		// Bought and max length only apply to fields
		if (iExpression < GetFieldCount())
		{
			m_iFields++;
			m_iBoughtLevel = max(m_iBoughtLevel, iBoughtLevel);
		}
		else
		{
			// What remains must be part of the key
			m_iKeys++;
		}
	}

	// Auto-adjust... does basic validation. Also assigns non-duplicate names
	pRecordDefDst->Adjust();

	// Set the resolved flag 
	SetResolved(true);

	// Create a nice key definition (note: can't create the key def until
	// resolved flag is set).
	if (m_iKeys > 0)
		m_KeyDef.CreateFromMap(*this);
	else
		m_KeyDef = pRecordDefSrc->GetKeyDef();

	pRecordDefDst->GetKeyDef() = m_KeyDef;

	// This is a double check to make sure all fields were resolved.
	// It is possible that you simply wanted to discard unresolved fields
	// ASSERT(GetExpressionCount() == GetResolvedCount());
}

void CIuFieldMap::SetCaseConvert(int iCaseConvert)
{
	ASSERT(iCaseConvert == caseMixed || iCaseConvert == caseUpper || iCaseConvert == caseLower || iCaseConvert == caseNoConvert);
	m_CaseConvert = CIuCaseConversionMode(iCaseConvert);
}

void CIuFieldMap::SetField(int iWhich, LPCTSTR pcsz)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcsz));
	m_asFields.SetAtGrow(iWhich, pcsz);
	SetResolved(false);
}

void CIuFieldMap::SetFields(const CStringArray& as)
{
	m_asFields.Copy(as);
	SetResolved(false);
}

void CIuFieldMap::SetKey(int iWhich, LPCTSTR pcsz)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcsz));
	m_asKeys.SetAtGrow(iWhich, pcsz);
	SetResolved(false);
}

void CIuFieldMap::SetKeys(const CStringArray& as)
{
	m_asKeys.Copy(as);
	SetResolved(false);
}

void CIuFieldMap::SetResolved(bool f)
{
	m_fResolved = f;
}

void CIuFieldMap::SetSpec(int iSpec)
{
	CIuFieldMapSpec FieldMapSpec;
	if (FieldMapSpec.FromNo(iSpec))
	{
		SetSpec(FieldMapSpec);
	}
}

void CIuFieldMap::SetSpec(CIuFieldMapSpec& FieldMapSpec)
{
	RemoveAll();

	int iFields = FieldMapSpec.GetFieldCount();
	for (int iField = 0; iField < iFields; ++iField)
		AddField(FieldMapSpec.GetField(iField));

	int iKeys = FieldMapSpec.GetKeyCount();
	for (int iKey = 0; iKey < iKeys; ++iKey)
		AddKey(FieldMapSpec.GetKey(iKey));
}


void CIuFieldMap::SetTruncate(bool f)
{
	m_fTruncate = f;
}
