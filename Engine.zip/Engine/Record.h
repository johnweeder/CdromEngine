#ifndef _ENGINE_RECORD_H_
#define _ENGINE_RECORD_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_LATLONGCOORDINATE_H_
#	include "Engine\LatLongCoordinate.h"
#endif	// _ENGINE_LATLONGCOORDINATE_H_
#ifndef 	_ENGINE_MISCELLANEOUS_H_
#	include "Engine\Miscellaneous.h"
#endif	// _ENGINE_MISCELLANEOUS_H_
//}}Uses

//{{Predefines
class CIuFieldMap;
class CIuRecordDef;
class CIuKey;
class CIuBuffer;
class CIuRecordSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Constants

// Source/Record/Expand No invalid identifiers
const DWORD recordRecordNoInvalid	= 0xFFFFFFFF;
const DWORD recordSourceNoInvalid	= 0xFFFFFFFF;
const DWORD recordExpandNoInvalid	= 0xFFFFFFFF;

// The upper bit flags cause an allocation of additional memory
// These _must_ be the top bits
const int recordDwordBitCount			= 5;
const WORD recordRecordNo				= 0x8000;
const WORD recordSourceNo				= 0x4000;
const WORD recordLatLong				= 0x2000;
const WORD recordExpandNo				= 0x1000;
const WORD recordExpandCount			= 0x0800;

// These 5 are just flags (although key can cause an additional field to be included)
const WORD recordKey						= 0x0400;
const WORD recordAlternate				= 0x0200;
const WORD recordTagged					= 0x0100;
const WORD recordNoMail					= 0x0080;
const WORD recordNoPhone				= 0x0040;
const WORD recordResidence				= 0x0020;
const WORD recordUnused					= 0x0010;

// The lower 4 bits are the bought level
const WORD recordBoughtMask			= 0x000F;

const WORD recordHiVal					= 0xFFFF;
const WORD recordLoVal					= 0xFFFE;

// Sorting flags
const int recordSortCaseSensitive	= 0x0001;
const int recordSortRecordNo			= 0x0002; // Use record no when sorting

// Sizing information
const WORD recordMaxSize				= 0x7FF8; // NOTE: MOD 10 must == 0
const WORD recordMaxKeyOffset			= 0x7FF8;

// This max field array is primarily used internal. You can grow it if you like. The only
// constraint is that you will use more stack space. 
const int recordMaxFields = 512;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordPtr}}
//	This is a high performance, low-overhead class for managing record data
#pragma pack(1)
struct IU_CLASS_EXPORT CIuRecord
{
/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int Compare(const CIuRecord& rawRecord, int iFlags) const;
	int Compare(const CIuRecord& rawRecord, const CIuFieldMap& compare, int iFlags) const;
	int Compare(const CIuKey& key, bool* pfPartial = 0) const;
	void Get(CStringArray& as) const;
	const char* GetAltKey() const;
	const char* GetAltValue() const;
	int GetBoughtLevel() const;
	DWORD GetExpandCount() const;
	DWORD GetExpandNo() const;
	void GetExpandNo(DWORD& dwExpandNo, DWORD& dwExpandCount) const;
	const char* GetField(int iField) const;
	const char* GetField(int iField, int& iSize) const;
	int GetFields() const;
	int GetFieldSize(int iField) const;
	WORD GetFlags() const;
	void GetKey(CIuKey&) const;
	const BYTE* GetKeyPtr() const;
	int GetKeySize() const;
	void GetLatLong(CIuLatLongCoordinate& Coord) const;
	void GetLatLong(DWORD& dwLat, DWORD& dwLong) const;
	DWORD GetRecordNo() const;
	DWORD GetSourceNo() const;
	UINT64 GetSrcRecNo() const;
	bool HasExpandCount() const;
	bool HasExpandNo() const;
	bool HasLatLong() const;
	bool HasKey() const;
	bool HasRecordNo() const;
	bool HasSourceNo() const;
	bool IsAlternate() const;
	bool IsBlank() const;
	bool IsBusiness() const;
	bool IsHiVal() const;
	bool IsLoVal() const;
	bool IsNoMail() const;
	bool IsNoPhone() const;
	bool IsResidence() const;
	bool IsTagged() const;
	bool IsValid() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void CaseConvert(int iCaseConvert);
	void CaseConvert(int iCaseConvert, CIuRecordDef&);
	void Clear(bool fHiVal = false);
	void Dump() const;
	CString DumpAsString() const;
	void SetAlt(bool fAlt);
	void SetBoughtLevel(int iBoughtLevel);
	void SetBus();
	void SetExpandCount(DWORD dwExpandCount);
	void SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount);
	void SetKey();
	void SetKey(int iFields);
	void SetKey(const char* pbKey, int cbKey);
	void SetLatLong(DWORD dwLat, DWORD dwLong);
	void SetNoMail(bool fNoMail);
	void SetNoPhone(bool fNoPhone);
	void SetRecordNo(DWORD dwRecordNo);
	void SetRes();
	void SetSourceNo(DWORD dwSrcNo);
	void SetTagged(bool fTagged);
	void View(CWnd* pParent = 0) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	static WORD GetDwordSize(WORD wFlags);

private:
	friend class CIuRecordPtr;
	friend class CIuRecordHeapSort;
	friend class CIuRecordHeap;
	friend class CIuRecordDlg;
	friend class CIuRecordFile;

	// Delete a raw record which was allocated from the heap.
	static void Delete(CIuRecord*);

	// Create raw record of a given size (allocated from heap).
	// Optionally, initialize from raw record
	static CIuRecord* New(int cb, const CIuRecord* pRecord = 0, WORD wFlags = 0, int cbKey = 0);
	// Create from an existing raw record (allocated from heap).
	static CIuRecord* New(const CIuRecord& rawRecord, WORD wFlags = 0, int cbKey = 0);
	// Create from a record spec
	static CIuRecord* New(CIuRecordSpec& Spec);
	// Create from a persistent buffer
	static CIuRecord* NewBuffer(const BYTE* pb, int cb);

	// Members
	void AddRef();
	void Construct(WORD wSize);
	void GetBuffer(CIuBuffer& buffer) const;
	const BYTE* GetData() const;
	BYTE* GetData();
	int GetDataSize() const;
	void GrowDword(WORD wFlags);
	DWORD GetDword(int = 0) const;
	DWORD* GetDwordPtr() const;
	WORD GetDwordSize() const;
	int GetUsedSize() const;
	WORD Release();
	CIuRecord& operator=(const CIuRecord& rawRecord);
	void Set(const CIuRecord& Record);
	void Set(CIuRecordSpec& RecordSpec);
	void SetBuffer(const BYTE* pb, int cb);
	void SetDword(int iWhich, DWORD dw);
	bool WillFitBuffer(const BYTE* pb, int cb) const;
	bool WillFitFlags(WORD wFlags) const;
	bool WillFitKey(int cbKey) const;
	bool WillFitRecord(const CIuRecord& rawRecord) const;
	bool WillFitSpec(CIuRecordSpec& RecordSpec) const;
//}}Implementation



/////////////////////////////////////////////////////////////////////////////
//{{Data
//		BIT	 15:	Set if the record has a record no 
//		BIT	 14:	Set if the record has a source no 
//		BIT	 13	Set Latitude/longitude are available
//		BIT	 12:	Set if record contains a expanded record no
//		BIT	 11:	Set if record contains a "count".
//						Normally the count is the number of expanded records.
//		BIT	 10:	Set if the record contains an embedded "key".
//						The "key" functions as a special field in each record.
//						Every record (except hi/lo val) has a key. By default,
//						the key is the first field in the record.
//						If necessary, a key can be appended to the end of the record.
//						The key may contain one or more null terminated string. The
//						offset to the key is stored in "m_wKeyOffset"
//						The key can also be set to be the first "n" fields in a record.
//						This is indicated by a m_wKeyOffset > than recordMaxKeyOffset
//						NOTE: If the first "n" fields are used, there is no easy way
//						to specify the justification of the fields (for correct
//						numeric sorting).
//		BIT	  9:	Set if this is a "see also" records
//						See also records are generally "display only"
//		BIT	  8:	Tagged bit
//		BIT	  7:	No Mail flag
//		BIT	  6:	No Phone flag
//	
//		BITS	0-5 Bought level for record (0-63)
//	
// NOTES:
//		This is a variable length data structure
//		Do not add virtual functions!
//		This class is designed for performance at all costs. We could use fewer bytes... but we don't!
//		This persistent data is platform dependent. There are byte ordering dependencies in the data
//		For performance reasons, you should create the raw record specifying which optional
//			data fields will be used (record no/source no/expand no/lat/int) and the eventual size of the key.
//		Operator overloading for the new/delete caused problems on some platforms. Therefore,
//			this struct does not used constructors or destructors. You _must_ allocate 
//			using one of the static "new" functions. There is no need to destruct, although a Delete
//			function is provided for structure which were dynamically allocated.
//		The key can be changed "on the fly" providing that it will fit within the allocated space.
//		The various "dword" data fields (record/source/expand/lat/int) can be changed also...
//			providing they fit
//		For optimum efficiency, first store the data. Then any of the dword values. Then the key.
//	
// This is housekeeping information (this information goes along with the instance of the data structure)
#define recordOverhead (3 * sizeof(WORD))
private:
										// *** Do NOT Change these elements without also changing rawrecordheap ***
	WORD m_wRef;					// Reference count
										// NOTE: The value of 0xFFFF is reserved. The record heap uses this to
										// indicate a free node.
	WORD m_wTotalSize;			// Total allocated size of this structure
										// NOTE: The size is effectively limited to 0xFFFF but programatically 
										// limited to recordMaxSize
										// NOTE: In the raw record heap, this element is expanded to 4 bytes
										//			for freed blocks. This allows very large free blocks.
	WORD m_wUsedSize;				// Amount of space used by data
										// NOTE: In the raw record heap, this element is expanded to 4 bytes
										//			for freed blocks.
										//			The value is the offset of the next free block or 0xFFFFFFFF.
										// *** Do NOT Change these elements without also changing rawrecordheap ***

// Everything after here is considered "data" (this information describes the record)
		WORD m_wFields;				// Number of fields, OR hival/loval.
											// Field first in the data because if is hi/lo val... flags, etc
											// aren't even needed
		WORD m_wFlags;					// Special flags & other values for the record (see above)
		WORD m_wKeyOffset;			// Offset of the first key value (only valid if rawKey flag is set).
#pragma warning(disable:4200)
	WORD m_awFieldOffset[0];	// Offsets to start of fields from beginning of structure (for performance)
										// These values are not persistent. They are rebuilt as needed (when record is loaded).
										// One extra offset is stored. It is the offset of the byte following the last
										//	field. This also means it is the offset of the first dword value.
										// In other words:
										//		m_wDwordOffset = m_awFieldOffset[m_wFields]
#pragma warning(default:4200)
//	BYTE m_abFields[];			//	A series of null terminated strings representing the data	

// These "dword" fields are optional. Any or all or none of them may be present.
//	DWORD m_dwRecordNo;			// The ID number of this record. This may be a pointer to a record in the master database
										// or the physical ID# of the record within this database. This value is distinct from the
										// option array of ID's which is also stored.
//	DWORD m_dwSourceNo;			// This is the "source" identifier for the record. Normally this value is used to identify
										// the database from which this record originated.
//	DWORD m_dwLatitude;			// Latitude/longitude in fixed 5 decimal precision.
//	DWORD m_dwLongitude;
//	DWORD m_dwExpandNo;			// Expanded record key
//	DWORD m_dwExpandCount;		// Expanded record count
//										// NOTE: As an optimization, count must immediately follow expand no.
										//	Also, an having an expand no. implies having a count!
//	BYTE m_abKey[];				//	A series of null terminated strings representing the key
										// Key size is always m_wUsedSize - m_wKeyOffset
//}}Data
};

#pragma pack()


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline void CIuRecord::AddRef()
{
	// Ref of 0xFFFF is reserved as a special case
	ASSERT(m_wRef < 0xFFFE);
	++m_wRef;
}

inline const BYTE* CIuRecord::GetData() const
{
	return reinterpret_cast<const BYTE*>(this) + recordOverhead;
}

inline BYTE* CIuRecord::GetData()
{
	return reinterpret_cast<BYTE*>(this) + recordOverhead;
}

inline int CIuRecord::GetDataSize() const
{
	return m_wUsedSize - recordOverhead;
}

inline WORD CIuRecord::GetDwordSize() const
{
	return GetDwordSize(m_wFlags);
}

inline int CIuRecord::GetFields() const
{
	return m_wFields;
}

inline WORD CIuRecord::GetFlags() const
{
	return m_wFlags;
}

inline UINT64 CIuRecord::GetSrcRecNo() const
{
	return MAKE_SRCRECNO(GetSourceNo(), GetRecordNo());
}

inline int CIuRecord::GetUsedSize() const
{
	return m_wUsedSize;
}

inline bool CIuRecord::HasExpandCount() const
{
	return (m_wFlags & recordExpandCount) != 0;
}

inline bool CIuRecord::HasExpandNo() const
{
	return (m_wFlags & recordExpandNo) != 0;
}

inline bool CIuRecord::HasKey() const
{
	return (m_wFlags & recordKey) != 0;
}

inline bool CIuRecord::HasLatLong() const
{
	return (m_wFlags & recordLatLong) != 0;
}

inline bool CIuRecord::HasRecordNo() const
{
	return (m_wFlags & recordRecordNo) != 0;
}

inline bool CIuRecord::HasSourceNo() const
{
	return (m_wFlags & recordSourceNo) != 0;
}

inline bool CIuRecord::IsAlternate() const
{
	return (m_wFlags & recordAlternate) != 0;
}

inline bool CIuRecord::IsBusiness() const
{
	return (m_wFlags & recordResidence) == 0;
}

inline bool CIuRecord::IsHiVal() const
{
	return m_wFields == recordHiVal;
}

inline bool CIuRecord::IsLoVal() const
{
	return m_wFields == recordLoVal;
}

inline bool CIuRecord::IsNoMail() const
{
	return (m_wFlags & recordNoMail) != 0;
}

inline bool CIuRecord::IsNoPhone() const
{
	return (m_wFlags & recordNoPhone) != 0;
}

inline bool CIuRecord::IsResidence() const
{
	return (m_wFlags & recordResidence) != 0;
}

inline bool CIuRecord::IsTagged() const
{
	return (m_wFlags & recordTagged) != 0;
}

inline bool CIuRecord::IsValid() const
{
	return m_wFields != recordLoVal && m_wFields != recordHiVal;
}

inline CIuRecord& CIuRecord::operator=(const CIuRecord& Record)
{
	Set(Record);
	return *this;	
}

inline WORD CIuRecord::Release()
{
	ASSERT(m_wRef > 0);
	--m_wRef;
	return m_wRef;
}

#endif // _ENGINE_RECORD_H_

