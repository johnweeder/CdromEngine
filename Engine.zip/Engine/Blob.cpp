#include "StdAfx.h"
//{{Include
#include "Blob.h"
#include "Blobs.h"
#include "BlobSpec.h"
#include "CdromSpecConst.h"
#include "resource.h"
#include "Data\SerializeEx.h"
#include "Error\Error.h"
#include "Data\Pack.h"
#include "Data\Output.h"
#include "Miscellaneous.h"
#include "Data\DataFilename.h"
#include "Cdrom.h"
#include "Common\Buffer.h"
#include "Ui\ViewFileDlg.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif
//{{Implement
IMPLEMENT_SERIAL(CIuBlob, CIuBlob_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBlob)
const	CIuVersionNumber versionBlobMax(2000,1,5,304);
const	CIuVersionNumber versionBlobMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BLOB, CIuBlob, CIuBlob_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuBlob, IDS_ENGINE_PPG_BLOB, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBlob, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuBlob, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_BLOB, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBlob, IDS_ENGINE_PROP_BLOBNO, GetBlobNo, SetBlobNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBlob, IDS_ENGINE_PROP_BLOBNO, IDS_ENGINE_PPG_BLOB, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBlob::CIuBlob() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBlob::~CIuBlob()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBlob::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	if (Flags.Test(cdromsBuildPackAuxiliaryFiles))
	{
		CIuBuffer Buffer;

		{
			CIuFilename  Filename = GetFullFilename();

			CIuFilePhysical fileSrc;
			fileSrc.Open(Filename, CIuFile::openReadOnly);

			CIuFilePosition Length = fileSrc.GetLength();

			Buffer.SetSize(int(Length));

			fileSrc.SeekToBegin();
			fileSrc.Read(Buffer.GetPtr(), int(Length));
		}

		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output, GetName(), Buffer);
	}
	return true;
}

void CIuBlob::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sFilename.Empty();
	m_pObjectRepository = 0;
	m_iBlobNo = 0;
	SetVersion(versionBlobMax);
	//}}Initialize
}

CString CIuBlob::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CString CIuBlob::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

CIuVersionNumber CIuBlob::GetVersionMax() const
{
	return versionBlobMax;
}

CIuVersionNumber CIuBlob::GetVersionMaxStatic()
{
	return versionBlobMax;
}

CIuVersionNumber CIuBlob::GetVersionMin() const
{
	return versionBlobMin;
}

CIuVersionNumber CIuBlob::GetVersionMinStatic()
{
	return versionBlobMin;
}

void CIuBlob::SetBlobNo(int iBlobNo)
{
	m_iBlobNo = iBlobNo;
}

void CIuBlob::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuBlob::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuBlob::SetSpec(CIuBlobSpec& BlobSpec)
{
	SetMoniker(BlobSpec.GetMoniker());
	SetFilename(BlobSpec.GetFilename());
	SetBlobNo(BlobSpec.GetBlobNo());
}	

bool CIuBlob::ViewAsText(LPCTSTR pcszTitle, CWnd* pParent)
{
	CIuBuffer Buffer;
	GetObjectRepository().UnPack(*this, Buffer, GetName());

	static const TCHAR chNull = '\0';
	Buffer.Append((const BYTE*)&chNull, sizeof(chNull));

	CString sValue = Buffer.GetPtr();

	return CIuViewFileDlg::ViewString(pcszTitle, sValue, pParent, false);

}
