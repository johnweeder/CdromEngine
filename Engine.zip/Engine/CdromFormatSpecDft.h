#ifndef _ENGINE_CDROMFORMATSPECDFT_H_
#define _ENGINE_CDROMFORMATSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Some products are a multi-cdrom set. A format describes the common 
//	information for all CD's in that set
struct CIuCdromFormatSpecDft
{
public:
	static int Find(LPCTSTR pcszName);
	static int Find(int iIndex);
	static const CIuCdromFormatSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszFormat;
	int m_iFormat;
	// The application name of this product
	LPCTSTR m_pcszApplication;
	// The user interface used by this cd-rom
	int m_iUserInterfaceNo;
	// A list of options for this product. Various components are free to interpret these
	// options. Some important options:
	//		cdonly:					Product needs authorization to run on a network
	//		business:				Business records are included
	//		resdidential:			Residential records are included
	//		samples:					Sample records are included
	// Also, combined with product options!
	LPCTSTR m_pcszOptions;
	// Has a database object?
	bool m_fHasDatabase;
	// Geo format
	int m_iGeoNo;
	// SIC format
	int m_iSicNo;
	// Address format
	int m_iAddressNo;
	// A list of strips for this format (by number)
	const int* m_piStrips;
	// A list of attached alternate files
	const int* m_piAlts;
	// A list of token files needed
	const int* m_piTokens;
	// A list of BTree files needed
	const int* m_piBTrees;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMFORMATSPECDFT_H_
