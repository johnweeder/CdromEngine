#include "StdAfx.h"
//{{Include
#include "CdromFormatSpecDft.h"
#include "CdromSpecConst.h"
#include "FieldMap.h"
#include "CdromStrip.h"
#include "Alt.h"
#include "Token.h"
#include "BTree.h"
#include "Address.h"
#include "UserInterface.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Index strips and BTrees's
// NOTE: The primary index (i.e. name) must be first so that other indexes
// can used it as their expand target.
static int aiStrips104m_2001[]	=  { cdromStripName, 		cdromStripAddress,											cdromStripPhone,							cdromStripNone };
static int aiBTree104m_2001[]		=  { btreeName104m_2001,	btreeAddress,													btreePhone,									btreeNone };
static int aiStrips88md_2001[]	=  { cdromStripName,			cdromStripAddress,											cdromStripPhone,	cdromStripZip5,	cdromStripNone };
static int aiBTree88md_2001[]		=  { btreeName88md_2001,	btreeAddress,													btreePhone,			btreeZip5,			btreeNone };
static int aiStripsAc_V1[]			=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness1,				cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreeAc_V1[]			=  { btreeNameAc_V1,			btreeAddress,			btreeBusiness,						btreePhone,			btreeZip4,			btreeNone };
static int aiStripsBml1_2000[]	=  { cdromStripName,										cdromStripBusiness1,										cdromStripZip4,	cdromStripNone };
static int aiBTreeBml1_2000[]		=  { btreeNameBml_2000,									btreeBusiness,												btreeZip4,			btreeNone };
static int aiStripsBml2_2000[]	=  { cdromStripName,			cdromStripAddress,											cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreeBml2_2000[]		=  { btreeNameBml_2000,		btreeAddress,													btreePhone,			btreeZip4,			btreeNone };
static int aiStripsCi_V1[]			=  { cdromStripName, 																			cdromStripPhone,							cdromStripNone };
static int aiBTreeCi_V1[]			=  { btreeNameCi_V1,																				btreePhone,									btreeNone };
static int aiStripsOam_V1[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness1,				cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreeOam_V1[]			=  { btreeNameOam_V1,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip4,			btreeNone };
static int aiStripsPb_2001[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusinessFranchise6,	cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreePb_2001[]		=  { btreeNamePb_2001,		btreeAddress,			btreeBusinessFranchise,			btreePhone,			btreeZip4,			btreeNone };
static int aiStripsPbm_V1[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness6,				cdromStripPhone,	cdromStripZip5,	cdromStripNone };
static int aiBTreePbm_V1[]			=  { btreeNamePbm_V1,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip5,			btreeNone };
static int aiStripsPf_2001[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness6,				cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreePf_2001[]		=  { btreeNamePf_2001,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip4,			btreeNone };
static int aiStripsPg_2000[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness6,				cdromStripPhone,							cdromStripNone };
static int aiBTreePg_2000[]		=  { btreeNamePg_2000,		btreeAddress,			btreeBusiness,						btreePhone,									btreeNone };
static int aiStripsPu_2001[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusinessFranchise6, cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreePu_2001[]		=  { btreeNamePu_2001,		btreeAddress,			btreeBusinessFranchise,			btreePhone,			btreeZip4,			btreeNone };
static int aiStripsRboc_2000[]	=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness6,				cdromStripPhone,							cdromStripNone };
static int aiBTreeRboc_2000[]		=  { btreeNameRboc_2000,	btreeAddress,			btreeBusiness,						btreePhone,									btreeNone };
static int aiStripsRp_2001[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness1,				cdromStripPhone,	cdromStripZip5,	cdromStripNone };
static int aiBTreeRp_2001[]		=  { btreeNameRp_2001,		btreeAddress,			btreeBusiness,												btreeZip5,			btreeNone };
static int aiStripsSample[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness1,				cdromStripPhone,	cdromStripZip4,	cdromStripNone };
static int aiBTreeSample[]			=  { btreeNameSample,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip4,			btreeNone };
static int aiStripsSlu_2000[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness6,				cdromStripPhone,	cdromStripZip5,	cdromStripNone };
static int aiBTreeSlu_2000[]		=  { btreeNameSlu_2000,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip5,			btreeNone };
static int aiStripsYpu_2001[]		=  { cdromStripName,			cdromStripAddress,	cdromStripBusiness1,				cdromStripPhone,	cdromStripZip5,	cdromStripNone };
static int aiBTreeYpu_2001[]		=  { btreeNameYpu_2001,		btreeAddress,			btreeBusiness,						btreePhone,			btreeZip5,			btreeNone };
static int aiStripsNone[]			=  {																																					cdromStripNone };
static int aiBTreeNone[]			=  {																																					btreeNone };

/////////////////////////////////////////////////////////////////////////////
// Some alt collections
static const int aiAltsAll[]		= { altFirst, altLast, altCity, altPhone, altSic, altNone };
static const int aiAltsNone[]		= { altNone };

/////////////////////////////////////////////////////////////////////////////
// A list of tokenizers attached to this index
// Some token collections
static int aiTokensNone[]			=  { tokenNone };
//static int aiTokensName[]		=  { tokenPrino, tokenSecno, tokenStreet, tokenNone };

/////////////////////////////////////////////////////////////////////////////
// Format specifications

static const CIuCdromFormatSpecDft aFormat[] =
{
	{
		szFormat104m_2001, cdromFormat104m_2001, 
		szAppCdu,
		ui104m_2001,
		_T("cdonly,residential,business"),
		true,
		geoStandard,
		sicNone,
		addressStandard,
		aiStrips104m_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTree104m_2001,
	},{
		szFormat88md_2001, cdromFormat88md_2001, 
		szAppCdu,
		ui88md_2001,
		_T("cdonly,residential"),
		true,
		geoStandard,
		sicNone,
		addressStandard,
		aiStrips88md_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTree88md_2001,
	},{
		szFormatAc_V1, cdromFormatAc_V1,
		szAppAc,
		uiAc_V1,
		_T("cdonly,business,residential"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsAc_V1,
		aiAltsAll,
		aiTokensNone,
		aiBTreeAc_V1,
	},{
		szFormatBml1_2000, cdromFormatBml1_2000, 
		szAppPd,
		uiBml1_2000,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsBml1_2000,
		aiAltsAll,
		aiTokensNone,
		aiBTreeBml1_2000,
	},{
		szFormatBml2_2000, cdromFormatBml2_2000, 
		szAppPd,
		uiBml2_2000,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsBml2_2000,
		aiAltsAll,
		aiTokensNone,
		aiBTreeBml2_2000,
	},{
		szFormatCi_V1, cdromFormatCi_V1,
		szAppCi,
		uiCi_V1,
		_T("cdonly,business,residential,nospouse,nonosolict"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsCi_V1,
		aiAltsAll,
		aiTokensNone,
		aiBTreeCi_V1,
	},{
		szFormatConsole, cdromFormatConsole,
		szAppConsole,
		uiConsole,
		_T(""),
		false,
		geoNone,
		sicNone,
		addressNone,
		aiStripsNone,
		aiAltsNone,
		aiTokensNone,
		aiBTreeNone,
	},{
		szFormatPb_2001, cdromFormatPb_2001,
		szAppPd,
		uiPb_2001,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsPb_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTreePb_2001,
	},{
		szFormatPbm_V1, cdromFormatPbm_V1,
		szAppCdu,
		uiPbm_V1,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsPbm_V1,
		aiAltsAll,
		aiTokensNone,
		aiBTreePbm_V1,
	},{
		szFormatPf_2001, cdromFormatPf_2001,
		szAppPd,
		uiPf_2001,
		_T("cdonly,business,residential"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsPf_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTreePf_2001,
	},{
		szFormatPg_2000, cdromFormatPg_2000,
		szAppPd,
		uiPg_2000,
		_T("cdonly,business,residential"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsPg_2000,
		aiAltsAll,
		aiTokensNone,
		aiBTreePg_2000,
	},{
		szFormatPu_2001, cdromFormatPu_2001,
		szAppPd,
		uiPu_2001,
		_T("business,residential"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsPu_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTreePu_2001,
	},{
		szFormatMeterAdmin, cdromFormatMeterAdmin,
		szAppMeterAdmin,
		uiMeterAdmin,
		_T(""),
		false,
		geoNone,
		sicNone,
		addressNone,
		aiStripsNone,
		aiAltsNone,
		aiTokensNone,
		aiBTreeNone,
	},{
		szFormatNetAdmin, cdromFormatNetAdmin,
		szAppNetAdmin,
		uiNetAdmin,
		_T(""),
		false,
		geoNone,
		sicNone,
		addressNone,
		aiStripsNone,
		aiAltsNone,
		aiTokensNone,
		aiBTreeNone,
	},{
		szFormatOam_V1, cdromFormatOam_V1,
		szAppPd,
		uiNone,
		_T("cdonly,business,residential"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsOam_V1,
		aiAltsAll,
		aiTokensNone,
		aiBTreeOam_V1,
	},{
		szFormatPowerCheck, cdromFormatPowerCheck,
		szAppPowerCheck,
		uiPowerCheck,
		_T(""),
		false,
		geoNone,
		sicNone,
		addressNone,
		aiStripsNone,
		aiAltsNone,
		aiTokensNone,
		aiBTreeNone,
	},{
		szFormatRboc_2000, cdromFormatRboc_2000,
		szAppPd,
		uiRboc_2000,
		_T("accesscode,business,residential"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsRboc_2000,
		aiAltsAll,
		aiTokensNone,
		aiBTreeRboc_2000,
	},{
		szFormatRp_2001, cdromFormatRp_2001,
		szAppRp,
		uiRp_2001,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsRp_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTreeRp_2001,
	},{
		szFormatReleaseNotes, cdromFormatReleaseNotes,
		szAppReleaseNotes,
		uiNone,
		_T(""),
		false,
		geoNone,
		sicNone,
		addressNone,
		aiStripsNone,
		aiAltsNone,
		aiTokensNone,
		aiBTreeNone,
	},{
		szFormatSample, cdromFormatSample, 
		szAppPd,
		uiSample,
		_T("cdonly,business,residential"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsSample,
		aiAltsAll,
		aiTokensNone,
		aiBTreeSample,
	},{
		szFormatSlu_2000, cdromFormatSlu_2000,
		szAppSlu,
		uiSlu_2000,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard6,
		addressStandard,
		aiStripsSlu_2000,
		aiAltsAll,
		aiTokensNone,
		aiBTreeSlu_2000,
	},{
		szFormatYpu_2001, cdromFormatYpu_2001,
		szAppCdu,
		uiYpu_2001,
		_T("cdonly,business"),
		true,
		geoStandard,
		sicStandard1,
		addressStandard,
		aiStripsYpu_2001,
		aiAltsAll,
		aiTokensNone,
		aiBTreeYpu_2001,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuCdromFormatSpecDft

int CIuCdromFormatSpecDft::Find(LPCTSTR pcszFormat)
{
	ASSERT(AfxIsValidString(pcszFormat));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszFormat, pcszFormat) == 0)
			return i;
	}
	return -1;
}

int CIuCdromFormatSpecDft::Find(int iFormat)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iFormat == iFormat)
			return i;
	}
	return -1;
}

const CIuCdromFormatSpecDft* CIuCdromFormatSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aFormat + iWhich;
}

int CIuCdromFormatSpecDft::GetCount()
{
	return sizeof(aFormat) / sizeof(aFormat[0]);
}

