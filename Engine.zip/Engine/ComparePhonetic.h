#ifndef _ENGINE_COMPAREPHONETIC_H_
#define _ENGINE_COMPAREPHONETIC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuComparePhonetic }}

class CIuComparePhonetic 
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuComparePhonetic();
	CIuComparePhonetic(const CIuComparePhonetic& rComparePhonetic);
	virtual ~CIuComparePhonetic();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int Compare(LPCTSTR pcsz) const;
	void SetExpression(LPCTSTR pcsz);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuComparePhonetic& operator=(const CIuComparePhonetic& rComparePhonetic);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_COMPAREPHONETIC_H_
