#if !defined(AFX_EXPORTDEFAULTADVANCEDDLG_H__58520254_E2E9_11D2_BC33_005004062565__INCLUDED_)
#define AFX_EXPORTDEFAULTADVANCEDDLG_H__58520254_E2E9_11D2_BC33_005004062565__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExportDefaultAdvancedDlg.h : header file
//

#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1
/////////////////////////////////////////////////////////////////////////////
// CIuExportDefaultAdvancedDlg dialog

class CIuExportDefaultAdvancedDlg : public CDialog
{
// Construction
public:
	void SetDistinctArray(const CStringArray& asDistinct);
	void SetOrderByArray(const CStringArray& asOrderBy);
	void SetBought(CString sBought);
	CString GetBought();
	const CStringArray& GetOrderByArray()const;
	const CStringArray& GetDistinctArray()const;
	CIuExportDefaultAdvancedDlg(CWnd* pParent = NULL);   // standard constructor

	void SetDefaultArray(const CStringArray &asDefault);
	void SetSelectedArray(const CStringArray& asSelected);
	void SetUniversalArray(const CStringArray& asUniversal);

// Dialog Data
	//{{AFX_DATA(CIuExportDefaultAdvancedDlg)
	enum { IDD = IDD_ENGINE_EXPORT_DEFAULT_ADVANCED };
	CButton	m_Distinct;
	CButton	m_OrderBy;
	CString	m_sBought;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIuExportDefaultAdvancedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIuExportDefaultAdvancedDlg)
	afx_msg void OnDistinct();
	afx_msg void OnOrderby();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CStringArray m_asOrderBy;
	CStringArray m_asDistinct;
	void DoFieldModal(CStringArray& asSelection);
	CStringArray m_asUniversal;
	CStringArray m_asSelected;
	CStringArray m_asDefault;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPORTDEFAULTADVANCEDDLG_H__58520254_E2E9_11D2_BC33_005004062565__INCLUDED_)
