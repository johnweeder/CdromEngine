#include "stdafx.h"
//{{Include
#include "FieldDef.h"
#include "FieldDefs.h"
#include "FieldDefSpec.h"
#include "FieldDef.h"
#include "FieldDefConst.h"
#include "Data\Archive.h"
#include "Interop\Conversions.h"
#include "resource.h"
#include "Error\Error.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuFieldDef, CIuFieldDef_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldDef)
const	CIuVersionNumber versionFieldDefMax(2000,1,5,304);
const	CIuVersionNumber versionFieldDefMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_FIELDDEF, CIuFieldDef, CIuFieldDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDef, IDS_ENGINE_PROP_OFFSET, GetOffset, SetOffset, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDef, IDS_ENGINE_PROP_LENGTH, GetLength, SetLength, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDef, IDS_ENGINE_PROP_SHORTNAME, GetShortName, SetShortName, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDef, IDS_ENGINE_PROP_LONGNAME, GetLongName, SetLongName, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDef, IDS_ENGINE_PROP_DESCRIPTION, GetDescription, SetDescription, 0)
	IU_ATTRIBUTE_PROPERTY_FLAGS(CIuFieldDef, IDS_ENGINE_PROP_FLAGS, IDS_ENGINE_FLAGS_FIELDDEFFLAGS, GetFlags, SetFlags, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDef, IDS_ENGINE_PROP_BOUGHTLEVEL, GetBoughtLevel, SetBoughtLevel, 0)

	IU_ATTRIBUTE_LIST_BEGIN(CIuFieldDef, IDS_ENGINE_FLAGS_FIELDDEFFLAGS)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_SORTNUMERIC, fieldSortNumeric)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_NUMERIC, fieldNumeric)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_NOCONVERTCASE, fieldNoConvertCase)
	IU_ATTRIBUTE_LIST_END()


	IU_ATTRIBUTE_PAGE(CIuFieldDef, IDS_ENGINE_PPG_FIELDDEF, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDef, IDS_ENGINE_PROP_LONGNAME, IDS_ENGINE_PPG_FIELDDEF, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDef, IDS_ENGINE_PROP_SHORTNAME, IDS_ENGINE_PPG_FIELDDEF, 1, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDef, IDS_ENGINE_PROP_OFFSET, IDS_ENGINE_PPG_FIELDDEF, 0, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDef, IDS_ENGINE_PROP_LENGTH, IDS_ENGINE_PPG_FIELDDEF, 1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDef, IDS_ENGINE_PROP_DESCRIPTION, IDS_ENGINE_PPG_FIELDDEF, 4, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDef, IDS_ENGINE_PROP_BOUGHTLEVEL, IDS_ENGINE_PPG_FIELDDEF, 0, 0xff, 0)
	IU_ATTRIBUTE_EDITOR_FLAGS(CIuFieldDef, IDS_ENGINE_PROP_FLAGS, IDS_ENGINE_PPG_FIELDDEF, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldDef::CIuFieldDef()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuFieldDef::CIuFieldDef(const CIuFieldDef& rFieldDef)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rFieldDef;
}

CIuFieldDef::~CIuFieldDef()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuFieldDef::Clear()
{
	CIuFieldDef_super::Clear();
	CIuFieldDef::CommonConstruct();
}

void CIuFieldDef::CommonConstruct()
{
	//{{Initialize
	SetName(_T("fielddef"));
	m_iLength = 1;
	m_iOffset = 0;
	m_sShortName.Empty();
	m_sLongName.Empty();
	m_sDescription.Empty();
	m_flagsFlags = 0;
	m_iBoughtLevel = 0;
	SetVersion(versionFieldDefMax);
	//}}Initialize
}

bool CIuFieldDef::Compare(const CIuFieldDef& FieldDef, bool fError) const
{
	// Right now, we only check that field lengths match.
	// Basically this check is done when mapping one field to another
	// The only real concern is that the field fit.
	// We currently check for an exact length match...
	if (GetLength() != FieldDef.GetLength())
	{
		CString sLen1, sLen2;
		if (fError)
			Error(IU_E_RECDEF_INV_FLD_LEN, LPCTSTR(GetName()), IntAsString(sLen1, GetLength()), IntAsString(sLen2, FieldDef.GetLength()));
		return false;
	}
	// We also check for a name match. The CIuSourceSource relies on this to determine if
	// multiple sources have the same format.
	if (GetName().CompareNoCase(FieldDef.GetName()) != 0)
	{
		if (fError)
			Error(IU_E_RECDEF_INV_FLD_NAME, LPCTSTR(GetName()), LPCTSTR(FieldDef.GetName()));
		return false;
	}
	return true;
}

void CIuFieldDef::Copy(const CIuObject& object)
{
	CIuFieldDef_super::Copy(object);

	const CIuFieldDef* pFieldDef = dynamic_cast<const CIuFieldDef*>(&object);
	if (pFieldDef == 0 || pFieldDef == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuFieldDef)));
	
	m_iLength = pFieldDef->m_iLength;
	m_iOffset = pFieldDef->m_iOffset;
	m_sShortName = pFieldDef->m_sShortName;
	m_sLongName = pFieldDef->m_sLongName;
	m_sDescription = pFieldDef->m_sDescription;
	m_flagsFlags = pFieldDef->m_flagsFlags;
	m_iBoughtLevel = pFieldDef->m_iBoughtLevel;
}

CString CIuFieldDef::GetDescription() const
{
	return m_sDescription;
}

CIuFieldDefs& CIuFieldDef::GetFieldDefs() const
{
	CIuFieldDefs* pParent = dynamic_cast<CIuFieldDefs*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CString CIuFieldDef::GetFlagsAsString() const
{
	const CIuAttribute* pAttribute = GetAttribute(IDS_ENGINE_FLAGS_FIELDDEFFLAGS, attributeList);
	ASSERT(pAttribute);
	const CIuAttributeList* pList = dynamic_cast<const CIuAttributeList*>(const_cast<CIuAttribute*>(pAttribute));
	ASSERT(pList);

	return pList->FlagsAsString(GetFlags());
}

CIuVersionNumber CIuFieldDef::GetVersionMax() const
{
	return versionFieldDefMax;
}

CIuVersionNumber CIuFieldDef::GetVersionMaxStatic()
{
	return versionFieldDefMax;
}

CIuVersionNumber CIuFieldDef::GetVersionMin() const
{
	return versionFieldDefMin;
}

CIuVersionNumber CIuFieldDef::GetVersionMinStatic()
{
	return versionFieldDefMin;
}

CIuFieldDef& CIuFieldDef::operator=(const CIuFieldDef& rFieldDef)
{
	Copy(rFieldDef);
	return *this;
}

void CIuFieldDef::SetBoughtLevel(int iBoughtLevel)
{
	m_iBoughtLevel = max(0, min(boughtMaxLevel, iBoughtLevel));
}

void CIuFieldDef::SetDescription(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDescription = pcsz;
}

void CIuFieldDef::SetFlags(CIuFlags flags)
{
	m_flagsFlags = flags;
}

void CIuFieldDef::SetFlagsAsString(LPCTSTR pcsz)
{
	const CIuAttribute* pAttribute = GetAttribute(IDS_ENGINE_FLAGS_FIELDDEFFLAGS, attributeList);
	ASSERT(pAttribute);
	const CIuAttributeList* pList = dynamic_cast<const CIuAttributeList*>(const_cast<CIuAttribute*>(pAttribute));
	ASSERT(pList);

	SetFlags(pList->StringAsFlags(pcsz));
}

void CIuFieldDef::SetLength(int iLength)
{
	ASSERT(iLength >= 0);
	m_iLength = iLength;
}

void CIuFieldDef::SetLongName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongName = pcsz;
}

void CIuFieldDef::SetOffset(int iOffset)
{
	ASSERT(iOffset >= 0);
	m_iOffset = iOffset;
}

void CIuFieldDef::SetSpec(LPCTSTR pcszDef)
{
	ASSERT(AfxIsValidString(pcszDef));
	CIuFieldDefSpec spec(pcszDef, true);
	SetSpec(spec);
}

void CIuFieldDef::SetSpec(CIuFieldDefSpec& Spec)
{
	// Update the field information
	// NOTE: This is more of an "update" than a "create".
	// To perform a true create, do a clear first.
	SetName(Spec.GetName());
	int iLength = Spec.GetLength();
	if (iLength < 0)
		iLength = fieldDftLength;
	if (iLength > 0)
		SetLength(iLength);
	if (GetLength() <= 0)
		SetLength(fieldDftLength);
	if (Spec.GetOffset() >= 0)
		SetOffset(Spec.GetOffset());
	if (Spec.GetFlags() != 0)
	{
		// OR in the new flags...
		__int32 iFlags = GetFlags();
		SetFlags(iFlags|Spec.GetFlags());
	}
	if (!Spec.GetLongName().IsEmpty())
		SetLongName(Spec.GetLongName());
	if (!Spec.GetShortName().IsEmpty())
		SetShortName(Spec.GetShortName());
	if (!Spec.GetDescription().IsEmpty())
		SetDescription(Spec.GetDescription());
	if (Spec.GetBoughtLevel() != -1)
		SetBoughtLevel(Spec.GetBoughtLevel());
}

void CIuFieldDef::SetShortName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sShortName = pcsz;
}
