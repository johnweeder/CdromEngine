#include "StdAfx.h"
//{{Include
#include "KeyList.h"
#include "Key.h"
#include "Common\String.h"
#include "resource.h"
#include "Error\Error.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuKeyList, CIuKeyList_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuKeyList)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_KEYLIST, CIuKeyList, CIuKeyList_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuKeyList, IDS_ENGINE_PROP_KEYS, GetKeys, SetKeys, 0)

	IU_ATTRIBUTE_PAGE(CIuKeyList, IDS_ENGINE_PPG_KEYLIST, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuKeyList, IDS_ENGINE_PROP_KEYS, IDS_ENGINE_PPG_KEYLIST, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuKeyList::CIuKeyList() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuKeyList::CIuKeyList(const CIuKeyList& rKeyList)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rKeyList;
}

CIuKeyList::~CIuKeyList()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuKeyList::AddKey(LPCTSTR pcsz) 
{
	ASSERT(AfxIsValidString(pcsz));
	return m_asKeys.Add(pcsz);
}

void CIuKeyList::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_asKeys.RemoveAll();
	//}}Initialize
}

void CIuKeyList::Copy(const CIuObject& object)
{
	CIuKeyList_super::Copy(object);

	const CIuKeyList* pKeyList = dynamic_cast<const CIuKeyList*>(&object);
	if (pKeyList == 0 || pKeyList == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuKeyList)));
	
	m_asKeys.Copy(pKeyList->m_asKeys);
}

void CIuKeyList::Extract(int iKey, CString& sIndex, CString& sValue) const
{
	// Extracts a string of the form  "x=y" or "x"
	// Note the a single value "x" could imply either an index name or
	// a value which is attached to the primary index.
	// By default, it is assumed to be a value. To specify an index with no
	// value, you must enclose the index in square brackets.
	CString sIndexValue = GetKey(iKey);

	LPCTSTR pcsz = _tcsskipws(sIndexValue);

	bool fExplicitIndex = false;

	// Extract the Index name
	if (IsIdentifier(*pcsz))
	{
		// Index name is a simple identifier
		pcsz = ExtractIdentifier(pcsz, sIndex);
	}
	else if (*pcsz == _T('['))
	{
		// This is a Index name enclosed in square brackets
		pcsz = ExtractBracket(pcsz, sIndex, _T("["), _T("]"));
		sIndex = UnBracket(sIndex, _T("["), _T("]"));
		fExplicitIndex = true;
	}

	sIndex.TrimLeft();
	sIndex.TrimRight();

	// Next, look for an equal sign
	pcsz = _tcsskipws(pcsz);
	if (*pcsz == _T('='))
	{
		++pcsz;
		pcsz = _tcsskipws(pcsz);
		
		// Extract the key
		if (IsQuote(*pcsz))
		{
			pcsz = ExtractQuote(pcsz, sValue);
			sValue = UnQuote(sValue);
		}
		else if (IsIdentifier(*pcsz))
		{
			pcsz = ExtractIdentifier(pcsz, sValue);
		}
	}
	else if (fExplicitIndex)
	{
		sValue = "";			
	}
	else if (!sIndex.IsEmpty())
	{
		// Assume this was a value with no index specified.
		sValue = sIndex;
		sIndex.Empty();
	}
	else if (IsQuote(*pcsz))
	{
		pcsz = ExtractQuote(pcsz, sValue);
		sValue = UnQuote(sValue);
	}
}

CString CIuKeyList::GetIndex(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	CString sIndex;
	CString sValue;
	Extract(iWhich, sIndex, sValue);
	return sIndex;
}

CString CIuKeyList::GetKey(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	return m_asKeys[iWhich];
}

void CIuKeyList::GetKeys(CStringArray& as) const
{
	as.Copy(m_asKeys);
}

CString CIuKeyList::GetValue(int iWhich) const
{
	// Get text to be parsed
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	CString sIndex;
	CString sValue;
	Extract(iWhich, sIndex, sValue);
	return sValue;
}

CIuKeyList& CIuKeyList::operator=(const CIuKeyList& rKeyList)
{
	Copy(rKeyList);
	return *this;
}

void CIuKeyList::RemoveAllKeys()
{
	m_asKeys.RemoveAll();
}

void CIuKeyList::RemoveKey(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	m_asKeys.RemoveAt(iWhich);
}

void CIuKeyList::SetKey(int iWhich, LPCTSTR pcsz)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcsz));
	m_asKeys.SetAtGrow(iWhich, pcsz);
}

void CIuKeyList::SetKeys(const CStringArray& as)
{
	m_asKeys.Copy(as);
}
