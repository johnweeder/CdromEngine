#include "StdAfx.h"
//{{Include
#include "GeoCodec.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoCodec, CIuGeoCodec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoCodec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOCODEC, CIuGeoCodec, CIuGeoCodec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_ZIPNO, GetZipNo, SetZipNo, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOCITY, HasNoCity, SetNoCity, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_CITYDELTA, GetCityDelta, SetCityDelta, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOMSA, HasNoMsa, SetNoMsa, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_MSADELTA, GetMsaDelta, SetMsaDelta, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOCOUNTY, HasNoCounty, SetNoCounty, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_COUNTYDELTA, GetCountyDelta, SetCountyDelta, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOLATLONG, HasNoLatLong, SetNoLatLong, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_LATITUDEDELTA, GetLatitudeDelta, SetLatitudeDelta, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_LONGITUDEDELTA, GetLongitudeDelta, SetLongitudeDelta, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_AREACODE, GetAreaCode, SetAreaCode, 0)
	IU_ATTRIBUTE_PROPERTY_INT_ARRAY(CIuGeoCodec, IDS_ENGINE_PROP_PREFIXES, GetPrefixes, SetPrefixes, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoCodec, IDS_ENGINE_PROP_LATLONGPRECISION, GetLatLongPrecision, SetLatLongPrecision, 0)


	IU_ATTRIBUTE_PAGE(CIuGeoCodec, IDS_ENGINE_PPG_GEOCODEC, 50, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_ZIPNO, IDS_ENGINE_PPG_GEOCODEC, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_LATITUDEDELTA, IDS_ENGINE_PPG_GEOCODEC, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_LONGITUDEDELTA, IDS_ENGINE_PPG_GEOCODEC, -1, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_LATLONGPRECISION, IDS_ENGINE_PPG_GEOCODEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOLATLONG, IDS_ENGINE_PPG_GEOCODEC, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_CITYDELTA, IDS_ENGINE_PPG_GEOCODEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_MSADELTA, IDS_ENGINE_PPG_GEOCODEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_COUNTYDELTA, IDS_ENGINE_PPG_GEOCODEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOMSA, IDS_ENGINE_PPG_GEOCODEC, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOCOUNTY, IDS_ENGINE_PPG_GEOCODEC, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuGeoCodec, IDS_ENGINE_PROP_NOCITY, IDS_ENGINE_PPG_GEOCODEC, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoCodec, IDS_ENGINE_PROP_AREACODE, IDS_ENGINE_PPG_GEOCODEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT_ARRAY(CIuGeoCodec, IDS_ENGINE_PROP_PREFIXES, IDS_ENGINE_PPG_GEOCODEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoCodec::CIuGeoCodec() 
{
	// This value is persistent... set it here but do not clear it
	m_iLatLongPrecision = 0;
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoCodec::~CIuGeoCodec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuGeoCodec::AddPrefix(int i, int iBefore) 
{
	int iCount = GetPrefixCount();
	if (iBefore < 0 || iBefore >= iCount)
		return m_aiPrefixes.Add(i);
	m_aiPrefixes.InsertAt(iBefore, i);
	return iBefore;
}

void CIuGeoCodec::Clear()
{
	CIuGeoCodec_super::Clear();
	CIuGeoCodec::CommonConstruct();
}

void CIuGeoCodec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iZipNo = -1;
	m_iLatitudeDelta = 0;
	m_iLongitudeDelta = 0;
	m_fNoLatLong = false;
	m_iCityDelta = 0;
	m_iMsaDelta = 0;
	m_iCountyDelta = 0;
	m_fNoMsa = false;
	m_fNoCounty = false;
	m_fNoCity = false;
	m_iAreaCode = 0;
	m_aiPrefixes.RemoveAll();
	// This value is persistent... it is initialized in the constructor
	// m_iLatLongPrecision = 0;
	//}}Initialize
}

int CIuGeoCodec::FindPrefix(int iPrefix) const
{
	for (int i = 0; i < m_aiPrefixes.GetSize(); ++i)
	{
		if (m_aiPrefixes[i] == iPrefix)
			return i;
	}
	return -1;
}

void CIuGeoCodec::GetPrefixes(CIntArray& al) const
{
	al.Copy(m_aiPrefixes);
}

void CIuGeoCodec::RemoveAllPrefixes()
{
	m_aiPrefixes.RemoveAll();
}

void CIuGeoCodec::RemovePrefix(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetPrefixCount());
	m_aiPrefixes.RemoveAt(iWhich);
}

void CIuGeoCodec::SetAreaCode(int iAreaCode)
{
	m_iAreaCode = iAreaCode;
}

void CIuGeoCodec::SetCityDelta(int iCityDelta)
{
	m_iCityDelta = iCityDelta;
}

void CIuGeoCodec::SetCountyDelta(int iCountyDelta)
{
	m_iCountyDelta = iCountyDelta;
}

void CIuGeoCodec::SetLatitudeDelta(int iLatitudeDelta)
{
	m_iLatitudeDelta = iLatitudeDelta;
}

void CIuGeoCodec::SetLatLongPrecision(int iLatLongPrecision)
{
	m_iLatLongPrecision = iLatLongPrecision;
}

void CIuGeoCodec::SetLongitudeDelta(int iLongitudeDelta)
{
	m_iLongitudeDelta = iLongitudeDelta;
}

void CIuGeoCodec::SetMsaDelta(int iMsaDelta)
{
	m_iMsaDelta = iMsaDelta;
}

void CIuGeoCodec::SetNoCity(bool f)
{
	m_fNoCity = f;
	if (m_fNoCity)
		SetCityDelta(0);
}

void CIuGeoCodec::SetNoCounty(bool f)
{
	m_fNoCounty = f;
	if (m_fNoCounty)
		SetCountyDelta(0);
}

void CIuGeoCodec::SetNoLatLong(bool f)
{
	m_fNoLatLong = f;
}

void CIuGeoCodec::SetNoMsa(bool f)
{
	m_fNoMsa = f;
	if (m_fNoMsa)
		SetMsaDelta(0);
}

void CIuGeoCodec::SetPrefix(int iWhich, int i)
{
	ASSERT(iWhich >= 0);
	m_aiPrefixes.SetAtGrow(iWhich, i);
}

void CIuGeoCodec::SetPrefixes(const CIntArray& al)
{
	m_aiPrefixes.Copy(al);
}

void CIuGeoCodec::SetZipNo(int iZipNo)
{
	m_iZipNo = iZipNo;
}
