#include "StdAfx.h"
//{{Include
#include "BTreeSpec.h"
#include "BTreeSpecDft.h"
#include "BTreeTokenizer.h"
#include "BTreeTokenizerSpec.h"
#include "resource.h"
#include "CdromSpec.h"
#include "AltSpec.h"
#include "Interop\Conversions.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeSpec, CIuBTreeSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREESPEC, CIuBTreeSpec, CIuBTreeSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTreeSpec, IDS_ENGINE_PPG_BTREESPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeSpec, IDS_ENGINE_PROP_BTREENO, GetBTreeNo, SetBTreeNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeSpec, IDS_ENGINE_PROP_BTREENO, IDS_ENGINE_PPG_BTREESPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_EXPANDMONIKER, GetExpandMoniker, SetExpandMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_EXPANDMONIKER, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_USETRANSLATION, UseTranslation, SetUseTranslation, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_USETRANSLATION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_CREATETRANSLATION, CreateTranslation, SetCreateTranslation, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_CREATETRANSLATION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASDATA, HasData, SetHasData, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASDATA, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASPOINTERS, HasPointers, SetHasPointers, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASPOINTERS, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_TRYHARDERCOMMA, IsTryHarderComma, SetTryHarderComma, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_TRYHARDERCOMMA, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_TRYHARDERMONIKER, GetTryHarderMoniker, SetTryHarderMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_TRYHARDERMONIKER, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASGEO, HasGeo, SetHasGeo, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASGEO, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_KEYS, GetKeys, SetKeys, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_KEYS, IDS_ENGINE_PPG_BTREESPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_ALTCITY, AltCity, SetAltCity, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_ALTCITY, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_ALTPHONE, AltPhone, SetAltPhone, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_ALTPHONE, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_ALTMONIKER, GetAltMoniker, SetAltMoniker, 0)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeSpec, IDS_ENGINE_PROP_ALTMONIKER, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_PHONES, GetPhones, SetPhones, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_PHONES, IDS_ENGINE_PPG_BTREESPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOMSACORRECTION, NoMsaCorrection, SetNoMsaCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOMSACORRECTION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOCOUNTYCORRECTION, NoCountyCorrection, SetNoCountyCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOCOUNTYCORRECTION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOLATLONGCORRECTION, NoLatLongCorrection, SetNoLatLongCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOLATLONGCORRECTION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeSpec, IDS_ENGINE_PROP_LATLONGPRECISION, GetLatLongPrecision, SetLatLongPrecision, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeSpec, IDS_ENGINE_PROP_LATLONGPRECISION, IDS_ENGINE_PPG_BTREESPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICITMAIL, NoSolicitMail, SetNoSolicitMail, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICITMAIL, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICITPHONE, NoSolicitPhone, SetNoSolicitPhone, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICITPHONE, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICIT, GetNoSolicit, SetNoSolicit, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_NOSOLICIT, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_BUSRESFLAG, GetBusResFlag, SetBusResFlag, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_BUSRESFLAG, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_BUSONLY, IsBusOnly, SetBusOnly, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_BUSONLY, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_RESONLY, IsResOnly, SetResOnly, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_RESONLY, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_MISCELLANEOUS, GetMiscellaneous, SetMiscellaneous, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuBTreeSpec, IDS_ENGINE_PROP_MISCELLANEOUS, IDS_ENGINE_PPG_BTREESPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_GENDER, GetGender, SetGender, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_GENDER, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBTreeSpec, IDS_ENGINE_PROP_SICCOUNT, GetSicCount, SetSicCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBTreeSpec, IDS_ENGINE_PROP_SICCOUNT, IDS_ENGINE_PPG_BTREESPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_SICCODE, GetSicCode, SetSicCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_SICCODE, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FRANCHISECODE, GetFranchiseCode, SetFranchiseCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FRANCHISECODE, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_ADSIZECODE, GetAdSizeCode, SetAdSizeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_ADSIZECODE, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FIRSTYEAR, GetFirstYear, SetFirstYear, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_FIRSTYEAR, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_EMPLOYEESIZECODE, GetEmployeeSizeCode, SetEmployeeSizeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_EMPLOYEESIZECODE, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_SALESVOLUMECODE, GetSalesVolumeCode, SetSalesVolumeCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBTreeSpec, IDS_ENGINE_PROP_SALESVOLUMECODE, IDS_ENGINE_PPG_BTREESPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_DEFAULTSOURCE, IsDefaultSource, SetDefaultSource, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_DEFAULTSOURCE, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOCITYSTATECORRECTION, NoCityStateCorrection, SetNoCityStateCorrection, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOCITYSTATECORRECTION, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOZIPADDON, NoZipAddOn, SetNoZipAddOn, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_NOZIPADDON, IDS_ENGINE_PPG_BTREESPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASADDRESS, HasAddress, SetHasAddress, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeSpec, IDS_ENGINE_PROP_HASADDRESS, IDS_ENGINE_PPG_BTREESPEC, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeSpec::CIuBTreeSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTreeSpec::~CIuBTreeSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_sFilename = "";
	m_iBTreeNo = 0;
	m_monikerExpandMoniker.Clear();
	m_fUseTranslation = false;
	m_fCreateTranslation = false;
	m_fHasData = false;
	m_fHasPointers = false;
	m_fTryHarderComma = false;
	m_monikerTryHarderMoniker.Clear();
	m_fHasGeo = false;
	m_asKeys.RemoveAll();
	m_fAltCity = false;
	m_fAltPhone = false;
	m_monikerAltMoniker.Clear();
	m_asPhones.RemoveAll();
	m_fNoMsaCorrection = false;
	m_fNoCountyCorrection = false;
	m_fNoCountyCorrection = false;
	m_fNoLatLongCorrection = false;
	m_iLatLongPrecision = 0;
	m_fNoSolicitMail = false;
	m_fNoSolicitPhone = false;
	m_sNoSolicit = "";
	m_sBusResFlag = "";
	m_fBusOnly = false;
	m_fResOnly = false;
	m_asMiscellaneous.RemoveAll();
	m_sGender = "";
	m_iSicCount = 0;
	m_sSicCode = "";
	m_sFranchiseCode = "";
	m_sAdSizeCode = "";
	m_sFirstYear = "";
	m_sEmployeeSizeCode = "";
	m_sSalesVolumeCode = "";
	m_fDefaultSource = false;
	m_fNoCityStateCorrection = false;
	m_fNoZipAddOn = false;
	SetVersion(IU_VERSION);
	m_fHasAddress = false;
	//}}Initialize
}

void CIuBTreeSpec::FromIndex(CIuCdromSpec* pCdrom, int iBTreeSpec)
{
	ASSERT(iBTreeSpec >= 0);

	const CIuBTreeSpecDft* pBTreeSpec = CIuBTreeSpecDft::Get(iBTreeSpec);
	ASSERT(pBTreeSpec);

	FromSpec(pCdrom, pBTreeSpec);
}

void CIuBTreeSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszIndex)
{
	FromIndex(pCdrom, CIuBTreeSpecDft::Find(pcszIndex));
}

void CIuBTreeSpec::FromNo(CIuCdromSpec* pCdrom, int iIndexNo)
{
	FromIndex(pCdrom, CIuBTreeSpecDft::Find(iIndexNo));
}

void CIuBTreeSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuBTreeSpecDft* pBTreeSpec)
{
	SetCdrom(pCdrom);

	ASSERT(AfxIsValidString(pBTreeSpec->m_pcszName));

	SetName(pBTreeSpec->m_pcszName);
	SetID(CIuID::Create());

	SetBTreeNo(pBTreeSpec->m_iBTree);
	SetDefaultSource(pBTreeSpec->m_fDefaultSource);

	SetHasData(pBTreeSpec->m_fHasData);
	SetHasPointers(pBTreeSpec->m_fHasPointers);
	SetCreateTranslation(pBTreeSpec->m_fCreateTranslation);
	SetUseTranslation(pBTreeSpec->m_fUseTranslation);
	SetTryHarderComma(pBTreeSpec->m_fTryHarderComma);
	SetHasGeo(pBTreeSpec->m_fHasGeo);
	SetAltPhone(pBTreeSpec->m_fAltPhone);
	SetAltCity(pBTreeSpec->m_fAltCity);
	SetGender(pBTreeSpec->m_pcszGender);

	SetNoMsaCorrection(pBTreeSpec->m_fNoMsaCorrection);
	SetNoCountyCorrection(pBTreeSpec->m_fNoCountyCorrection);
	SetNoLatLongCorrection(pBTreeSpec->m_fNoLatLongCorrection);
	SetNoZipAddOn(pBTreeSpec->m_fNoZipAddOn);
	SetNoCityStateCorrection(pBTreeSpec->m_fNoCityStateCorrection);
	SetLatLongPrecision(pBTreeSpec->m_iLatLongPrecision);

	SetHasAddress(pBTreeSpec->m_fHasAddress);
	ASSERT(pBTreeSpec->m_pcszNoSolicit != 0 || (!pBTreeSpec->m_fNoSolicitMail && !pBTreeSpec->m_fNoSolicitPhone));
	SetNoSolicit(pBTreeSpec->m_pcszNoSolicit);
	SetNoSolicitMail(pBTreeSpec->m_fNoSolicitMail);
	SetNoSolicitPhone(pBTreeSpec->m_fNoSolicitPhone);

	SetBusResFlag(pBTreeSpec->m_pcszBusResFlag);
	SetBusOnly(pBTreeSpec->m_fBusOnly);
	SetResOnly(pBTreeSpec->m_fResOnly);

	SetSicCount(pBTreeSpec->m_iSicCount);
	SetSicCode(pBTreeSpec->m_pcszSicCode);
	SetFranchiseCode(pBTreeSpec->m_pcszFranchiseCode);
	SetAdSizeCode(pBTreeSpec->m_pcszAdSizeCode);
	SetFirstYear(pBTreeSpec->m_pcszFirstYear);
	SetEmployeeSizeCode(pBTreeSpec->m_pcszEmployeeSizeCode);
	SetSalesVolumeCode(pBTreeSpec->m_pcszSalesVolumeCode);

	CStringArray as;

	StringAsStringArray(pBTreeSpec->m_pcszKeys, as);
	SetKeys(as);

	StringAsStringArray(pBTreeSpec->m_pcszPhones, as);
	SetPhones(as);

	StringAsStringArray(pBTreeSpec->m_pcszMiscellaneous, as);
	SetMiscellaneous(as);

	if (pBTreeSpec->m_pcszTryHarder)
	{
		int iIndex = GetCdrom().FindAlt(pBTreeSpec->m_pcszTryHarder);
		ASSERT(iIndex >= 0);
		SetTryHarderMoniker(GetCdrom().GetAlt(iIndex).GetMoniker());
	}
	else
		SetTryHarderMoniker(CIuMoniker());

	if (pBTreeSpec->m_pcszAlt)
	{
		int iIndex = GetCdrom().FindAlt(pBTreeSpec->m_pcszAlt);
		ASSERT(iIndex >= 0);
		SetAltMoniker(GetCdrom().GetAlt(iIndex).GetMoniker());
	}
	else
		SetAltMoniker(CIuMoniker());

	CString sFilename = GetCdrom().GetFilename();
	sFilename += _T(" ");
	sFilename += pBTreeSpec->m_pcszName;
	SetFilename(sFilename);

	if (pBTreeSpec->m_pcszBTreeExpand)
	{
		int iIndex = GetCdrom().FindBTree(pBTreeSpec->m_pcszBTreeExpand);
		ASSERT(iIndex >= 0);
		SetExpandMoniker(GetCdrom().GetBTree(iIndex).GetMoniker());
	}
	else
		SetExpandMoniker(CIuMoniker());
	
	// Add tokens
	RemoveAllTokenizers();
	const int* pBTreeTokenizers = pBTreeSpec->m_pBTreeTokenizers;
	for (; *pBTreeTokenizers != btreeTokenizerNone; ++pBTreeTokenizers)
	{	
		CIuBTreeTokenizerSpecPtr pTokenizer;
		pTokenizer.Create();
		pTokenizer->FromNo(this, *pBTreeTokenizers);
		m_apTokenizers.Add(pTokenizer);
	}
}

int CIuBTreeSpec::GetCount()
{
	return CIuBTreeSpecDft::GetCount();
}

void CIuBTreeSpec::GetKeys(CStringArray& as) const
{
	as.Copy(m_asKeys);
}

void CIuBTreeSpec::GetMiscellaneous(CStringArray& as) const
{
	as.Copy(m_asMiscellaneous);
}

void CIuBTreeSpec::GetPhones(CStringArray& as) const
{
	as.Copy(m_asPhones);
}

CIuBTreeTokenizerSpec& CIuBTreeSpec::GetTokenizer(int iTokenizer) const
{
	ASSERT(iTokenizer >= 0 && iTokenizer < GetTokenizerCount());
	return *m_apTokenizers[iTokenizer];
}

int CIuBTreeSpec::GetTokenizerCount() const
{
	return m_apTokenizers.GetSize();	
}

void CIuBTreeSpec::RemoveAllTokenizers() 
{
	m_apTokenizers.RemoveAll();
}

void CIuBTreeSpec::SetAdSizeCode(LPCTSTR pcsz)
{
	m_sAdSizeCode = pcsz;
}

void CIuBTreeSpec::SetAltCity(bool f)
{
	m_fAltCity = f;
}

void CIuBTreeSpec::SetAltMoniker(const CIuMoniker& moniker)
{
	m_monikerAltMoniker = moniker;
}

void CIuBTreeSpec::SetAltPhone(bool f)
{
	m_fAltPhone = f;
}

void CIuBTreeSpec::SetBTreeNo(int iBTreeNo)
{
	m_iBTreeNo = iBTreeNo;
}

void CIuBTreeSpec::SetBusOnly(bool f)
{
	m_fBusOnly = f;
}

void CIuBTreeSpec::SetBusResFlag(LPCTSTR pcsz)
{
	m_sBusResFlag = pcsz;
}

void CIuBTreeSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuBTreeSpec::SetCreateTranslation(bool f)
{
	m_fCreateTranslation = f;
}

void CIuBTreeSpec::SetDefaultSource(bool f)
{
	m_fDefaultSource = f;
}

void CIuBTreeSpec::SetEmployeeSizeCode(LPCTSTR pcsz)
{
	m_sEmployeeSizeCode = pcsz;
}

void CIuBTreeSpec::SetExpandMoniker(const CIuMoniker& moniker)
{
	m_monikerExpandMoniker = moniker;
}

void CIuBTreeSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuBTreeSpec::SetFirstYear(LPCTSTR pcsz)
{
	m_sFirstYear = pcsz;
}

void CIuBTreeSpec::SetFranchiseCode(LPCTSTR pcsz)
{
	m_sFranchiseCode = pcsz;
}

void CIuBTreeSpec::SetGender(LPCTSTR pcsz)
{
	m_sGender = pcsz;
}

void CIuBTreeSpec::SetHasAddress(bool f)
{
	m_fHasAddress = f;
}

void CIuBTreeSpec::SetHasData(bool f)
{
	m_fHasData = f;
}

void CIuBTreeSpec::SetHasGeo(bool f)
{
	m_fHasGeo = f;
}

void CIuBTreeSpec::SetHasPointers(bool f)
{
	m_fHasPointers = f;
}

void CIuBTreeSpec::SetKeys(const CStringArray& as)
{
	m_asKeys.Copy(as);
}

void CIuBTreeSpec::SetLatLongPrecision(int iLatLongPrecision)
{
	m_iLatLongPrecision = iLatLongPrecision;
}

void CIuBTreeSpec::SetMiscellaneous(const CStringArray& as)
{
	m_asMiscellaneous.Copy(as);
}

void CIuBTreeSpec::SetNoCityStateCorrection(bool f)
{
	m_fNoCityStateCorrection = f;
}

void CIuBTreeSpec::SetNoCountyCorrection(bool f)
{
	m_fNoCountyCorrection = f;
}

void CIuBTreeSpec::SetNoLatLongCorrection(bool f)
{
	m_fNoLatLongCorrection = f;
}

void CIuBTreeSpec::SetNoMsaCorrection(bool f)
{
	m_fNoMsaCorrection = f;
}

void CIuBTreeSpec::SetNoSolicit(LPCTSTR pcsz)
{
	m_sNoSolicit = pcsz;
}

void CIuBTreeSpec::SetNoSolicitMail(bool f)
{
	m_fNoSolicitMail = f;
}

void CIuBTreeSpec::SetNoSolicitPhone(bool f)
{
	m_fNoSolicitPhone = f;
}

void CIuBTreeSpec::SetNoZipAddOn(bool f)
{
	m_fNoZipAddOn = f;
}

void CIuBTreeSpec::SetPhones(const CStringArray& as)
{
	m_asPhones.Copy(as);
}

void CIuBTreeSpec::SetResOnly(bool f)
{
	m_fResOnly = f;
}

void CIuBTreeSpec::SetSalesVolumeCode(LPCTSTR pcsz)
{
	m_sSalesVolumeCode = pcsz;
}

void CIuBTreeSpec::SetSicCode(LPCTSTR pcsz)
{
	m_sSicCode = pcsz;
}

void CIuBTreeSpec::SetSicCount(int iSicCount)
{
	m_iSicCount = iSicCount;
}

void CIuBTreeSpec::SetTryHarderComma(bool f)
{
	m_fTryHarderComma = f;
}

void CIuBTreeSpec::SetTryHarderMoniker(const CIuMoniker& moniker)
{
	m_monikerTryHarderMoniker = moniker;
}

void CIuBTreeSpec::SetUseTranslation(bool f)
{
	m_fUseTranslation = f;
}
