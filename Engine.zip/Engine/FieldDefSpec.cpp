#include "StdAfx.h"
//{{Include
#include "FieldDefSpec.h"
#include "FieldDefSpecDft.h"
#include "FieldDefConst.h"
#include "Expression.h"
#include "FieldName.h"
#include "Common\String.h"
#include "Interop\Conversions.h"
#include "Error\Error.h"
#include "Common\Options.h"
#include "resource.h"
#include "RecordDef.h"
#include "Expression.h"
#include "FieldDefConst.h"
#include "CaseConversion.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif


//{{Implement
IMPLEMENT_SERIAL(CIuFieldDefSpec, CIuFieldDefSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldDefSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_FIELDDEFSPEC, CIuFieldDefSpec, CIuFieldDefSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_LONGNAME, GetLongName, SetLongName, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_SHORTNAME, GetShortName, SetShortName, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_BOUGHTLEVEL, GetBoughtLevel, SetBoughtLevel, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_FLAGS, GetFlagsAsString, SetFlagsAsString, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_DESCRIPTION, GetDescription, SetDescription, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_LITERAL, GetLiteral, SetLiteral, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_FIELDNO, GetFieldNo, SetFieldNo, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_LENGTH, GetLength, SetLength, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuFieldDefSpec, IDS_ENGINE_PROP_DEFAULTS, AreDefaults, SetDefaults, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_EXPRESSION, GetExpression, SetExpression, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_OFFSET, GetOffset, SetOffset, 0)

	IU_ATTRIBUTE_LIST_BEGIN(CIuFieldDefSpec, IDS_ENGINE_FLAGS_FIELDDEFSPECFLAGS)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_SORTNUMERIC, fieldSortNumeric)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_NUMERIC, fieldNumeric)
		IU_ATTRIBUTE_ELEMENT(IDS_ENGINE_FLAG_NOCONVERTCASE, fieldNoConvertCase)
	IU_ATTRIBUTE_LIST_END()


	IU_ATTRIBUTE_PAGE(CIuFieldDefSpec, IDS_ENGINE_PPG_FIELDDEFSPEC, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_EXPRESSION, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)

	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_LONGNAME, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_SHORTNAME, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_DESCRIPTION, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_LENGTH, IDS_ENGINE_PPG_FIELDDEFSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_OFFSET, IDS_ENGINE_PPG_FIELDDEFSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_FLAGS, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_BOUGHTLEVEL, IDS_ENGINE_PPG_FIELDDEFSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuFieldDefSpec, IDS_ENGINE_PROP_DEFAULTS, IDS_ENGINE_PPG_FIELDDEFSPEC, 0)

	IU_ATTRIBUTE_EDITOR_INT(CIuFieldDefSpec, IDS_ENGINE_PROP_FIELDNO, IDS_ENGINE_PPG_FIELDDEFSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldDefSpec, IDS_ENGINE_PROP_LITERAL, IDS_ENGINE_PPG_FIELDDEFSPEC, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldDefSpec::CIuFieldDefSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuFieldDefSpec::CIuFieldDefSpec(const CIuFieldDefSpec& rFieldDefSpec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rFieldDefSpec;
}

CIuFieldDefSpec::CIuFieldDefSpec(const CIuFieldDef& rFieldDef)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	FromFieldDef(rFieldDef);
}

CIuFieldDefSpec::CIuFieldDefSpec(LPCTSTR pcsz, bool fAssumeIsSpec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	ASSERT(AfxIsValidString(pcsz));
	Set(pcsz, fAssumeIsSpec);
}

CIuFieldDefSpec::~CIuFieldDefSpec()
{
	SetExpressionPtr(0);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuFieldDefSpec::Clear()
{
	CIuFieldDefSpec_super::Clear();
	SetExpressionPtr(0);

	m_sLongName.Empty();
	m_sShortName.Empty();
	m_sExpression.Empty();
	m_sDescription.Empty();
	m_iLength = -1;
	m_iBoughtLevel = -1;
	m_sLiteral.Empty();
	m_iFieldNo = specFieldNoDiscard;
	m_fDefaults = false;
	m_iOffset = -1;
	m_sOptions = "";
	m_flagsFlags = DWORD(0);
}

void CIuFieldDefSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sLongName.Empty();
	m_sShortName.Empty();
	m_sExpression.Empty();
	m_sDescription.Empty();
	m_iLength = -1;
	m_iBoughtLevel = -1;
	m_sLiteral.Empty();
	m_iFieldNo = specFieldNoDiscard;
	m_pExpression = 0;
	m_fDefaults = false;
	m_iOffset = -1;
	m_sOptions = "";
	m_flagsFlags = DWORD(0);
	m_iCaseConvert = caseNoConvert;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuFieldDefSpec::Copy(const CIuObject& object)
{
	CIuFieldDefSpec_super::Copy(object);

	const CIuFieldDefSpec* pFieldDefSpec = dynamic_cast<const CIuFieldDefSpec*>(&object);
	if (pFieldDefSpec == 0 || pFieldDefSpec == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuFieldDefSpec)));
	
	m_sExpression = pFieldDefSpec->m_sExpression;
	m_sLongName = pFieldDefSpec->m_sLongName;
	m_sShortName = pFieldDefSpec->m_sShortName;
	m_iLength = pFieldDefSpec->m_iLength;
	m_iBoughtLevel = pFieldDefSpec->m_iBoughtLevel;
	m_flagsFlags = pFieldDefSpec->m_flagsFlags;
	m_sDescription = pFieldDefSpec->m_sDescription;
	m_iOffset = pFieldDefSpec->m_iOffset;
	m_fDefaults = pFieldDefSpec->m_fDefaults;
	m_iFieldNo = pFieldDefSpec->m_iFieldNo;
	m_sLiteral = pFieldDefSpec->m_sLiteral;
	m_sOptions = pFieldDefSpec->m_sOptions;
	m_iCaseConvert = pFieldDefSpec->m_iCaseConvert;
	if (pFieldDefSpec->m_pExpression)
		m_pExpression = new CIuExpression(*pFieldDefSpec->m_pExpression);
}

CIuExpression* CIuFieldDefSpec::DetachExpressionPtr()
{
	CIuExpression* pExpression = m_pExpression;
	m_pExpression = 0;
	return pExpression;
}

bool CIuFieldDefSpec::FromExpression(LPCTSTR pcsz, LPCTSTR pcszParms, LPCTSTR pcszExpr)
{
	CString sName;
	CString sParms;
	CString sExpr;
	bool fRelative;
	Parse(pcsz, true, sName, sParms, sExpr, fRelative);

	if (pcszParms && *pcszParms)
	{
		if (!sParms.IsEmpty())
			sParms += ",";
		sParms += pcszParms;
	}

	if (pcszExpr && *pcszExpr)
		sExpr = pcszExpr;

	int iFieldSpec = CIuFieldDefSpecDft::Find(sName);
	if (iFieldSpec >= 0)
		return FromIndex(iFieldSpec, sParms, sExpr);

	Clear();
	return false;
}

void CIuFieldDefSpec::FromFieldDef(const CIuFieldDef& FieldDef)
{
	SetName(FieldDef.GetName());
	SetExpression(FieldDef.GetName());
	SetLongName(FieldDef.GetLongName());
	SetShortName(FieldDef.GetShortName());
	SetDescription(FieldDef.GetDescription());
	SetFlags(FieldDef.GetFlags());
	SetLength(FieldDef.GetLength());
	SetOffset(FieldDef.GetOffset());
	SetBoughtLevel(FieldDef.GetBoughtLevel());
}

bool CIuFieldDefSpec::FromIndex(int iSpec, LPCTSTR pcszParms, LPCTSTR pcszExpr)
{
	// Make sure index is valid
	if (iSpec < 0 || iSpec >= GetCount())
		return false;

	// Clear current specification
	Clear();

	CIuFieldDefSpecDft FieldDefSpecDft = *CIuFieldDefSpecDft::Get(iSpec);
	CString sName = CIuFieldDefSpecDft::Resolve(FieldDefSpecDft);

	SetName(sName);
	SetID(CIuID::Create());

	CString sLongName;
	if (FieldDefSpecDft.m_pcszLongName != 0)
		sLongName = FieldDefSpecDft.m_pcszLongName;
	else
		sLongName = sName;
	SetLongName(sLongName);

	CString sShortName;
	if (FieldDefSpecDft.m_pcszShortName != 0)
		sShortName = FieldDefSpecDft.m_pcszShortName;
	else
		sShortName = sName;
	SetShortName(sShortName);

	if (pcszExpr && *pcszExpr)
		SetExpression(pcszExpr);
	else if (FieldDefSpecDft.m_pcszExpression != 0)
		SetExpression(FieldDefSpecDft.m_pcszExpression);
	else
		SetExpression("");

	if (FieldDefSpecDft.m_pcszDescription != 0)
		SetDescription(FieldDefSpecDft.m_pcszDescription);
	else
		SetDescription("");

	if (FieldDefSpecDft.m_iLength > 0)
		SetLength(FieldDefSpecDft.m_iLength);
	else
		SetLength(-1);

	// Parse any special parms which were passed in to us.
	// First do the options in the field spec, the the one passed in
	m_iBoughtLevel = 0;
	m_iOffset = 0;
	m_flagsFlags = 0;
	m_sOptions = "";
	m_fDefaults = false;

	if (FieldDefSpecDft.m_pcszOptions != 0)
		ParseParms(FieldDefSpecDft.m_pcszOptions);
	if (pcszParms != 0)
		ParseParms(pcszParms, true);

	return true;
}

bool CIuFieldDefSpec::FromName(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	int iFieldSpec = CIuFieldDefSpecDft::Find(pcszName);
	if (iFieldSpec >= 0)
		return FromIndex(iFieldSpec, 0, 0);

	Clear();
	return false;
}

bool CIuFieldDefSpec::FromNo(int iFieldDefNo, LPCTSTR pcszParms, LPCTSTR pcszExpr)
{
	int iFieldSpec = CIuFieldDefSpecDft::Find(iFieldDefNo);
	if (iFieldSpec >= 0)
		return FromIndex(iFieldSpec, pcszParms, pcszExpr);

	Clear();
	return false;
}

int CIuFieldDefSpec::GetCount()
{
	return CIuFieldDefSpecDft::GetCount();
}

CIuFlags CIuFieldDefSpec::GetFlags() const
{
	return m_flagsFlags;
}

CString CIuFieldDefSpec::GetFlagsAsString() const
{
	const CIuAttribute* pAttribute = GetAttribute(IDS_ENGINE_FLAGS_FIELDDEFSPECFLAGS, attributeList);
	ASSERT(pAttribute);
	const CIuAttributeList* pList = dynamic_cast<const CIuAttributeList*>(const_cast<CIuAttribute*>(pAttribute));
	ASSERT(pList);

	return pList->FlagsAsString(GetFlags());
}

void CIuFieldDefSpec::GetNames(CStringArray& as)
{
	as.RemoveAll();
	for (int i = 0; i < CIuFieldDefSpecDft::GetCount(); ++i)
		as.Add(CIuFieldDefSpecDft::Get(i)->m_pcszFieldDef);
}

CString CIuFieldDefSpec::GetSpecification() const
{
	CString sSpec;
	sSpec += GetName();
	CString sParms;
	if (AreDefaults())
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_DEFAULTS);
	}
	if (GetLength() > 0)
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_LENGTH);
		sParms += _T("=");
		CString sLength;
		sParms += IntAsString(sLength, GetLength());
	}
	if (GetOffset() >= 0)
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_OFFSET);
		sParms += _T("=");
		CString sOffset;
		sParms += IntAsString(sOffset, GetOffset());
	}
	if (!GetShortName().IsEmpty())
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_SHORTNAME);
		sParms += _T("=");
		sParms += GetShortName();
	}
	if (!GetLongName().IsEmpty())
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_LONGNAME);
		sParms += _T("='");
		sParms += GetLongName();
		sParms += _T("'");
	}
	if (!GetDescription().IsEmpty())
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_DESCRIPTION);
		sParms += _T("='");
		sParms += GetDescription();
		sParms += _T("'");
	}
	if (GetBoughtLevel() > 0)
	{
		sParms += _T(",");
		sParms += S(IDS_ENGINE_PROP_BUY);
		sParms += _T("=");
		CString sBuy;
		sParms += IntAsString(sBuy, GetBoughtLevel());
	}
	CString sFlags = GetFlagsAsString();
	if (!sFlags.IsEmpty())
	{
		sParms += _T(",");
		sParms += sFlags;
	}
	if (!GetOptions().IsEmpty())
	{
		sParms += _T(",");
		sParms += GetOptions();
	}

	while (!sParms.IsEmpty())
	{
		if (sParms.GetAt(0) == ',')
			sParms = sParms.Mid(1);
		else
			break;
	}
	if (!sParms.IsEmpty())
	{
		sSpec += _T("(");
		sSpec += sParms;
		sSpec += _T(")");
	}

	if (!sSpec.IsEmpty())
		sSpec += _T(":");

	if (!GetExpression().IsEmpty())
		sSpec += GetExpression();
	else
		sSpec += GetName();

	return sSpec;
}

CIuFieldDefSpec& CIuFieldDefSpec::operator=(const CIuFieldDefSpec& rFieldDefSpec)
{
	Copy(rFieldDefSpec);
	return *this;
}


void CIuFieldDefSpec::Parse(LPCTSTR pcsz, bool fAssumeIsSpec, CString& sName, CString& sParms, CString& sExpr, bool& fRelative)
{
	// The general form of the specifier is:
	//		=name(parms):expr
	// Note that input of the form "name(parms)" can
	//	be interpreted as either an expression or as 
	// a simple field specifier. By default, it is assumed to
	//	be an expression. You can over-ride this behaving by specifying a
	//	terminating colon, as in: "name(parms):", or you can pass in
	// the fAssumeIsSpec flag.

	ASSERT(AfxIsValidString(pcsz));

	sName = "";
	sParms = "";
	sExpr = "";

	// Look for the relative field specifier
	pcsz = _tcsskipws(pcsz);
	if (*pcsz == '=')
	{
		fRelative = true;
		pcsz = _tcsskipws(pcsz + 1);
	}
	else
		fRelative = false;

	LPCTSTR pcszOriginal = pcsz;

	// Check for a field name specifier
	pcsz = _tcsskipws(pcsz);
	if (*pcsz == '[')
	{
		CString sName;
		pcsz = ExtractBracket(pcsz, sName, "[", "]");
		sName = UnBracket(sName, "[", "]");
	}
	else if (IsIdentifier(pcsz))
	{
		pcsz = ExtractIdentifier(pcsz, sName);
	}

	// Check for parameters (length, flags, etc)
	pcsz = _tcsskipws(pcsz);
	if (*pcsz == '(')
	{
		// Extract parms
		pcsz = ExtractBracket(pcsz, sParms, "(", ")");
		sParms = UnBracket(sParms, "(", ")");
	}

	// Now, look for an expression
	pcsz = _tcsskipws(pcsz);

	// If a colon is found, use everything after the colon.
	if (*pcsz == ':')
	{
		++pcsz;
		pcsz = _tcsskipws(pcsz);
		sExpr = pcsz;
	}
	// Otherwise, the original statement was the expression
	else if (!fAssumeIsSpec)
	{
		sName = _T("");
		sParms = _T("");
		sExpr = pcszOriginal;
	}
}

void CIuFieldDefSpec::Parse(LPCTSTR pcsz, bool fAssumeIsSpec)
{
	CString sName;
	CString sParms;
	CString sExpr;
	bool fRelative;
	Parse(pcsz, fAssumeIsSpec, sName, sParms, sExpr, fRelative);

	Clear();
	SetName(sName);
	SetExpression(sExpr);
	ParseParms(sParms);
}

void CIuFieldDefSpec::ParseParms(LPCTSTR pcsz, bool fAppend)
{
	// If not appending, clear the current values...
	if (!fAppend)
	{
		m_iBoughtLevel = 0;
		m_iOffset = 0;
		m_flagsFlags = 0;
		m_sOptions = "";
		m_fDefaults = false;
	}
	// Parse out the parts of the parameters
	ASSERT(AfxIsValidString(pcsz));
	CIuOptions options(pcsz);
	int iCount = options.GetCount();
	for (int i = 0; i < iCount; ++i)
	{
		if (!options.HasName(i))
		{
			// Assume numeric specifier is length
			if (options.IsNumeric(i))
				SetLength(max(1, options.GetValueAsInt(i)));
		}
		else
		{
			CString sName = options.GetName(i);
			if (sName.CompareNoCase(S(IDS_ENGINE_PROP_LENGTH)) == 0)
				SetLength(max(1, options.GetValueAsInt(i)));
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_OFFSET)) == 0)
				SetOffset(max(0, options.GetValueAsInt(i)));
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_DEFAULT)) == 0)
				SetDefaults(true);
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_SHORTNAME)) == 0)
				SetShortName(options.GetValue(i));
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_LONGNAME)) == 0)
				SetLongName(options.GetValue(i));
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_DESCRIPTION)) == 0)
				SetDescription(options.GetValue(i));
			else if (sName.CompareNoCase(S(IDS_ENGINE_PROP_BUY)) == 0)
			{
				// NOTE: This is potentially a security problem.
				// An end user could potentially create a query when the bought
				// level on all fields is set to 0.
#pragma __TODO("Filter out 'buy=n' parameters on input from Query object")
				SetBoughtLevel(max(1, options.GetValueAsInt(i)));
			}
			else
			{
				// Everything else is not recognized so it falls through to here.
				// It will either be a flag or dumped into the "options"
				const CIuAttribute* pAttribute = GetAttribute(IDS_ENGINE_FLAGS_FIELDDEFSPECFLAGS, attributeList);
				ASSERT(pAttribute);
				const CIuAttributeList* pList = dynamic_cast<const CIuAttributeList*>(const_cast<CIuAttribute*>(pAttribute));
				ASSERT(pList);

				// Try to make a flag out of it.
				CIuFlags flags = pList->StringAsFlags(sName);
				// If it wasn't a flag, keep it as an option.
				if (!flags)
				{
					if (!m_sOptions.IsEmpty())
							m_sOptions += ",";
					m_sOptions += options.Get(i);

				}
				// Otherwise, add it to the existing flags
				else
				{
					m_flagsFlags.Set(flags);
				}
			}
		}
	}
}

int CIuFieldDefSpec::Resolve(CIuResolveSpec& Spec)
{
	// recordDef is the definition against which the fields are resolved.
	//	Spec.m_pRecordDefDst is where the resulting field def is stored.
	// NOTE: Spec.m_pRecordDefDedup is simply used to de-dup against. For example, the codec uses it to
	// make sure that all fields in the master record set are unique.

	// Resolve and then be sure to add the field def into the destination record definition	
	ResolveField(Spec); 

	// If field is discarded, do not add it in.
	if (GetFieldNo() == specFieldNoDiscard)
		return -1;

	if (Spec.m_pRecordDefDst == 0)
	{
		TRACE("WARNING: CIuFieldDefSpec::Resolve() no destination record def.\n");
		return 0;
	}

	// Try to create a field name
	CString sName = GetName();
	if (sName.IsEmpty())
		sName = GetExpression();
	CString sNewName = sName;
	if (sName.IsEmpty() || !IsIdentifier(sName))
		VERIFY(MakeFieldName(sNewName, sName, 32));

	// If needed, make sure name is unique in destination & dedup list
	// Check all names
	bool fDuplicate = true;
	for (int iTry = 1; fDuplicate; ++iTry)
	{
		fDuplicate = false;

		int iFields = Spec.m_pRecordDefDst->GetFieldDefs().GetCount();
		for (int iField = 0; iField < iFields; ++iField)
		{
			CIuFieldDef& fieldDef = Spec.m_pRecordDefDst->GetFieldDefs().Get(iField);
			if (fieldDef.GetName().CompareNoCase(sNewName) == 0)
			{
				fDuplicate = true;
				break;
			}
		}
		if (Spec.m_pRecordDefDedup && !fDuplicate)
		{
			iFields = Spec.m_pRecordDefDedup->GetFieldDefs().GetCount();
			for (iField = 0; iField < iFields; ++iField)
			{
				CIuFieldDef& fieldDef = Spec.m_pRecordDefDedup->GetFieldDefs().Get(iField);
				if (fieldDef.GetName().CompareNoCase(sNewName) == 0)
				{
					fDuplicate = true;
					break;
				}
			}
		}

		if (fDuplicate)
		{
			if (!MakeFieldName(sNewName, sName, 32, iTry))
				Error(IU_E_DUPLICATE_FIELD_NAME, LPCTSTR(sName));
		}
	}

	// See if the field already exists
	sName = sNewName;

	// NOTE: The name is updated so that it will be preserved for later
	// passes.
	SetName(sName);

	// Update the field information
	int iIndex = Spec.m_pRecordDefDst->GetFieldDefs().Add();
	CIuFieldDef& fieldDef = Spec.m_pRecordDefDst->GetFieldDefs().Get(iIndex);
	fieldDef.SetSpec(*this);
	return iIndex;
}

void CIuFieldDefSpec::ResolveField(CIuResolveSpec& Spec)
{
	// Initially, mark field as discarded
	SetFieldNo(specFieldNoDiscard);
	SetLiteral("");
	SetExpressionPtr(0);

	// Now, parse out the expression
	LPCTSTR pcsz = GetExpression();

	// If it is quoted, the expression is a literal
	if (IsQuote(*pcsz))
	{
		// Literal
		// Make sure the literal is the only thing on the line!
		CString sQuoted;
		pcsz = ExtractQuote(pcsz, sQuoted);
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == '\0')
		{
			sQuoted = UnQuote(sQuoted);
			SetLiteral(sQuoted);
			SetLength(max(GetLength(), sQuoted.GetLength()));
			SetFieldNo(specFieldNoLiteral);
			return ;
		}
		pcsz = GetExpression();
	}

	// Handle a field with an empty expression
	// This would be a simple placeholder... probably not useful, but allowed
	if (*pcsz == '\0')
	{
		SetFieldNo(specFieldNoUnknown);
		return ;
	}

	// Perform some checks to see if the expression is a simple field specifier
	CString sFieldDefSpecifier;
	if (*pcsz == '[')
	{
		pcsz = ExtractBracket(pcsz, sFieldDefSpecifier, "[", "]");
		sFieldDefSpecifier = UnBracket(sFieldDefSpecifier, "[", "]");
		pcsz = _tcsskipws(pcsz);
		if (*pcsz != '\0')
			sFieldDefSpecifier.Empty();
	}
	else if (IsIdentifier(pcsz))
	{
		pcsz = ExtractIdentifier(pcsz, sFieldDefSpecifier);
		pcsz = _tcsskipws(pcsz);
		if (*pcsz != '\0')
			sFieldDefSpecifier.Empty();
	}

	// If it was a simple field specifier, process it
	if (!sFieldDefSpecifier.IsEmpty())
	{
		int iSourceIndex = -1;
		if (Spec.m_pRecordDefSrc)
			iSourceIndex = Spec.m_pRecordDefSrc->GetFieldDefs().Find(sFieldDefSpecifier);
		if (iSourceIndex >= 0)
		{
			ASSERT(Spec.m_pRecordDefSrc);
			CIuFieldDef& fieldDef = Spec.m_pRecordDefSrc->GetFieldDefs().Get(iSourceIndex);

			// When a simple field specifier is found, we can either:
			// 1) Force the various attributes to match those of the input field.
			// 2) Only use those attributes of the input field which were not
			//		specified in the parameter list.
			// The choice of which option to use is determined by whether the special
			//	"defaults" keyword has been specified. If "defaults" was specified, the
			// input field always over-rides.
			if (AreDefaults())
			{
				if (!fieldDef.GetLongName().IsEmpty())
					SetLongName(fieldDef.GetLongName());
				if (!fieldDef.GetShortName().IsEmpty())
					SetShortName(fieldDef.GetShortName());
				if (!fieldDef.GetDescription().IsEmpty())
					SetDescription(fieldDef.GetDescription());
				SetLength(fieldDef.GetLength());
				SetOffset(fieldDef.GetOffset());
				SetBoughtLevel(fieldDef.GetBoughtLevel());
				SetFlags(fieldDef.GetFlags());
			}
			else
			{
				if (GetLongName().IsEmpty())
					SetLongName(fieldDef.GetLongName());
				if (GetShortName().IsEmpty())
					SetShortName(fieldDef.GetShortName());
				if (GetDescription().IsEmpty())
					SetDescription(fieldDef.GetDescription());
				if (!GetFlags())
					SetFlags(fieldDef.GetFlags());
				if (GetLength() < 0)
					SetLength(fieldDef.GetLength());
				if (GetOffset() < 0)
					SetOffset(fieldDef.GetOffset());
				if (GetBoughtLevel() < 0)
					SetBoughtLevel(fieldDef.GetBoughtLevel());
			}
			SetFieldNo(iSourceIndex);
			return ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldKey) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoKey);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldAlt) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoAlt);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldSeeAlso) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoSeeAlso);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldRecordNo) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoRecordNo);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldSourceNo) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoSourceNo);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldExpandNo) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoExpandNo);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldCount) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoCount);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldLatitude) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoLatitude);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldLongitude) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoLongitude);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldTagged) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoTagged);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldBought) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoBought);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldNoMail) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoNoMail);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldNoPhone) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoNoPhone);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldBusiness) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoBusiness);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldResidence) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoResidence);
			return  ;
		}
		else if (sFieldDefSpecifier.CompareNoCase(szFieldBusResFlag) == 0)
		{
			VERIFY(FromName(sFieldDefSpecifier));
			SetFieldNo(specFieldNoBusResFlag);
			return  ;
		}

		if (GetName().IsEmpty())
		{
			// Here is a case where we simply want to look up the 
			//	default fields specifiers and use them. This happens 
			// when we just specify the name of a field but nothing 
			//	else... and then attempt to resolve it
			int iFieldSpec = CIuFieldDefSpecDft::Find(sFieldDefSpecifier);
			if (iFieldSpec >= 0)
			{
				FromIndex(iFieldSpec, 0, 0);
			}
		}

		// Field was not found, replace it with an "unknown"
		SetFieldNo(specFieldNoUnknown);

#ifdef _DEBUG
		{
			// This is not necessarily a problem.
			// Fields which do not exist are created as empty fields.
			// Sometimes the engine relies on this behaviour.
			TRACE("WARNING: Field '%s' was not found in source record def.\n", LPCTSTR(sFieldDefSpecifier));
#if 0
			// Enable this code to get a list of fields in the actual record def.
			TRACE("\tRecordDef contained %d fields:\n", recordDef.GetFieldDefs().GetCount());
			for (int iField = 0; iField < recordDef.GetFieldDefs().GetCount(); ++iField)
			{
				TRACE("\t\t%03d: %s\n", iField, LPCTSTR(recordDef.GetFieldDefs().Get(iField).GetName()));
			}
#endif
		}
#endif
		return ;
	}

	// At this point, it must be an expression.
	CIuExpression* pExpression = new CIuExpression;
	ASSERT(pExpression);

	IU_TRY_ERROR
	{
		// Parse the expression
		pExpression->Parse(GetExpression());
		pExpression->SetCaseConvert(GetCaseConvert());
		pExpression->Resolve(Spec);

		// If it is constant, store it as a literal
		if (pExpression->IsConst())
		{
			CString sLiteral = pExpression->Evaluate();
			SetExpression(sLiteral);
			SetLength(max(GetLength(), sLiteral.GetLength()));
			SetFieldNo(specFieldNoLiteral);
			SetLiteral(sLiteral);
			delete pExpression;
			return ;
		}
		// Otherwise, resolve it and store it as an expression
		else
		{
			SetBoughtLevel(pExpression->GetBoughtLevel());
			SetLength(max(GetLength(), pExpression->GetMaxLength()));
			SetFieldNo(specFieldNoExpression);
			SetExpressionPtr(pExpression);
			return ;
		}
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
		delete pExpression;
	}
}

void CIuFieldDefSpec::Set(LPCTSTR pcsz, bool fAssumeIsSpec)
{
	// The expression can be of two basic forms:
	// The first, is your basic field specifier:
	//		name(parms):expr
	// The second is a reference to a default field specifier.
	//		=name(parms)
	// The second format takes a default field specification and
	// modifies it using the parms.
	// parms and expr are optional.
	ASSERT(AfxIsValidString(pcsz));
	CString sExpr = pcsz;
	if (!sExpr.IsEmpty() && sExpr[0] == '=')
	{
		// If it starts with a equal sign, lookup a default.
		sExpr = sExpr.Mid(1);
		FromExpression(sExpr);
	}
	else
	{
		// Otherwise, parse the expression
		Parse(sExpr, fAssumeIsSpec);
	}
}

void CIuFieldDefSpec::SetBoughtLevel(int iBoughtLevel)
{
	m_iBoughtLevel = iBoughtLevel;
}

void CIuFieldDefSpec::SetCaseConvert(int iCaseConvert)
{
	m_iCaseConvert = iCaseConvert;
}

void CIuFieldDefSpec::SetDefaults(bool f)
{
	m_fDefaults = f;
}

void CIuFieldDefSpec::SetDescription(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDescription = pcsz;
	m_sDescription.TrimLeft();
	m_sDescription.TrimRight();
}

void CIuFieldDefSpec::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
	m_sExpression.TrimLeft();
	m_sExpression.TrimRight();
}

void CIuFieldDefSpec::SetExpressionPtr(CIuExpression* pExpression)
{
	// Keep a pointer to the object.
	// Be very careful that this does not create a circular reference.
	if (m_pExpression)
		delete m_pExpression;
	m_pExpression = pExpression;
}

void CIuFieldDefSpec::SetFieldNo(int iFieldNo)
{
	m_iFieldNo = iFieldNo;
}

void CIuFieldDefSpec::SetFlags(CIuFlags Flags)
{
	m_flagsFlags = Flags;
}

void CIuFieldDefSpec::SetFlagsAsString(LPCTSTR pcsz)
{
	const CIuAttribute* pAttribute = GetAttribute(IDS_ENGINE_FLAGS_FIELDDEFFLAGS, attributeList);
	ASSERT(pAttribute);
	const CIuAttributeList* pList = dynamic_cast<const CIuAttributeList*>(const_cast<CIuAttribute*>(pAttribute));
	ASSERT(pList);

	SetFlags(pList->StringAsFlags(pcsz));
}

void CIuFieldDefSpec::SetLength(int iLength)
{
	m_iLength = max(1, iLength);
}

void CIuFieldDefSpec::SetLiteral(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLiteral = pcsz;
	m_sLiteral.TrimLeft();
	m_sLiteral.TrimRight();
}

void CIuFieldDefSpec::SetLongName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongName = pcsz;
	m_sLongName.TrimLeft();
	m_sLongName.TrimRight();
}

void CIuFieldDefSpec::SetName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	CString sName = pcsz;
	sName.TrimLeft();
	sName.TrimRight();
	CIuFieldDefSpec_super::SetName(sName);
}

void CIuFieldDefSpec::SetOffset(int iOffset)
{
	m_iOffset = max(0, iOffset);
}

void CIuFieldDefSpec::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
	m_sOptions.TrimLeft();
	m_sOptions.TrimRight();
}

void CIuFieldDefSpec::SetShortName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sShortName = pcsz;
	m_sShortName.TrimLeft();
	m_sShortName.TrimRight();
}

