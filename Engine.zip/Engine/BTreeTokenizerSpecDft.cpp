#include "StdAfx.h"
//{{Include
#include "BTreeTokenizerSpecDft.h"
#include "BTreeTokenizer.h"
#include "Token.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BTreeTokenizerernate specifications

static const CIuBTreeTokenizerSpecDft aBTreeTokenizer[] =
{
	{
		_T("PriNo"), btreeTokenizerPriNo,
		_T("PriNo"),
		tokenPrino,
		false,
		false,
	},{
		_T("SecNo"), btreeTokenizerSecNo,
		_T("SecNo"),
		tokenSecno,
		true,
		false,
	},{
		_T("Street"), btreeTokenizerStreet,
		_T("Street"),
		tokenStreet,
		false,
		true,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuBTreeTokenizerSpecDft

int CIuBTreeTokenizerSpecDft::Find(LPCTSTR pcszBTreeTokenizer)
{
	ASSERT(AfxIsValidString(pcszBTreeTokenizer));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszBTreeTokenizer, pcszBTreeTokenizer) == 0)
			return i;
	}
	return -1;
}

int CIuBTreeTokenizerSpecDft::Find(int iBTreeTokenizer)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iBTreeTokenizer == iBTreeTokenizer)
			return i;
	}
	return -1;
}

const CIuBTreeTokenizerSpecDft* CIuBTreeTokenizerSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aBTreeTokenizer + iWhich;
}

int CIuBTreeTokenizerSpecDft::GetCount()
{
	return sizeof(aBTreeTokenizer) / sizeof(aBTreeTokenizer[0]);
}
