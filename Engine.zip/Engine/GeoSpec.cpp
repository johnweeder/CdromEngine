#include "StdAfx.h"
//{{Include
#include "GeoSpec.h"
#include "GeoSpecDft.h"
#include "resource.h"
#include "..\Version.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoSpec, CIuGeoSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOSPEC, CIuGeoSpec, CIuGeoSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoSpec, IDS_ENGINE_PPG_GEOSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoSpec, IDS_ENGINE_PROP_GEONO, GetGeoNo, SetGeoNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoSpec, IDS_ENGINE_PROP_GEONO, IDS_ENGINE_PPG_GEOSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_ZIP, GetZip, SetZip, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_ZIP, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_CITY, GetCity, SetCity, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_CITY, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_STATE, GetState, SetState, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_STATE, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_MSACODE, GetMsaCode, SetMsaCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_MSACODE, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_COUNTYCODE, GetCountyCode, SetCountyCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_COUNTYCODE, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_LATITUDE, GetLatitude, SetLatitude, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_LATITUDE, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_LONGITUDE, GetLongitude, SetLongitude, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_LONGITUDE, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoSpec, IDS_ENGINE_PROP_MATCHLEVEL, GetMatchLevel, SetMatchLevel, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoSpec, IDS_ENGINE_PROP_MATCHLEVEL, IDS_ENGINE_PPG_GEOSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuGeoSpec, IDS_ENGINE_PROP_PHONES, GetPhones, SetPhones, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuGeoSpec, IDS_ENGINE_PROP_PHONES, IDS_ENGINE_PPG_GEOSPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoSpec::CIuGeoSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoSpec::~CIuGeoSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_iGeoNo = 0;
	SetVersion(IU_VERSION);
	m_sZip = "Zip";
	m_sCity = "City";
	m_sState = "StateCode"; // NOTE: Accepts any of State Name/Code/Abbr
	m_sMsaCode = "MsaCode";
	m_sCountyCode = "CountyCode";
	m_sLatitude = "Latitude";
	m_sLongitude = "Longitude";
	m_sMatchLevel = "MatchLevel";
	m_asPhones.RemoveAll();
	//}}Initialize
}

void CIuGeoSpec::FromIndex(CIuCdromSpec* pCdrom, int iGeoSpec)
{
	ASSERT(iGeoSpec >= 0);

	const CIuGeoSpecDft* pGeoSpec = CIuGeoSpecDft::Get(iGeoSpec);
	ASSERT(pGeoSpec);

	FromSpec(pCdrom, pGeoSpec);
}

void CIuGeoSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszGeo)
{
	FromIndex(pCdrom, CIuGeoSpecDft::Find(pcszGeo));
}

void CIuGeoSpec::FromNo(CIuCdromSpec* pCdrom, int iGeoNo)
{
	FromIndex(pCdrom, CIuGeoSpecDft::Find(iGeoNo));
}

void CIuGeoSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuGeoSpecDft* pGeoSpec)
{
	SetCdrom(pCdrom);

	SetName(pGeoSpec->m_pcszGeo);
	SetID(CIuID::Create());

	SetGeoNo(pGeoSpec->m_iGeo);

	SetCity(pGeoSpec->m_pcszCity);
	SetCountyCode(pGeoSpec->m_pcszCountyCode);
	SetLatitude(pGeoSpec->m_pcszLatitude);
	SetLongitude(pGeoSpec->m_pcszLongitude);
	SetMatchLevel(pGeoSpec->m_pcszMatchLevel);
	SetMsaCode(pGeoSpec->m_pcszMsaCode);
	SetState(pGeoSpec->m_pcszState);
	SetZip(pGeoSpec->m_pcszZip);

	ASSERT(AfxIsValidString(pGeoSpec->m_pcszPhones));
	CStringArray asPhones;
	StringAsStringArray(pGeoSpec->m_pcszPhones, asPhones);
	SetPhones(asPhones);
}

int CIuGeoSpec::GetCount()
{
	return CIuGeoSpecDft::GetCount();
}

void CIuGeoSpec::GetPhones(CStringArray& as) const
{
	as.Copy(m_asPhones);
}

void CIuGeoSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuGeoSpec::SetCity(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCity = pcsz;
}

void CIuGeoSpec::SetCountyCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCountyCode = pcsz;
}

void CIuGeoSpec::SetGeoNo(int iGeoNo)
{
	m_iGeoNo = iGeoNo;
}

void CIuGeoSpec::SetLatitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLatitude = pcsz;
}

void CIuGeoSpec::SetLongitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongitude = pcsz;
}

void CIuGeoSpec::SetMatchLevel(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMatchLevel = pcsz;
}

void CIuGeoSpec::SetMsaCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMsaCode = pcsz;
}

void CIuGeoSpec::SetPhones(const CStringArray& as)
{
	m_asPhones.Copy(as);
}

void CIuGeoSpec::SetState(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sState = pcsz;
}

void CIuGeoSpec::SetZip(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sZip = pcsz;
}
