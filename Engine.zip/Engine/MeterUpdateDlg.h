#ifndef _ENGINE_METERUPDATEDLG_H_ 
#define _ENGINE_METERUPDATEDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
//}}Uses

//{{Predefines
class CIuMeterUpdate;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterUpdateDlg, CDialog }}
#define CIuMeterUpdateDlg_super CDialog

class CIuMeterUpdateDlg : public CIuMeterUpdateDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeterUpdateDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetMeterUpdatePtr(CIuMeterUpdate* pMeterUpdate);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void UpdateProfiles(bool fUpdate);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CFont m_fontLarge;
	bool m_fUpdated;
	CString m_sKey;
	CIuMeterUpdate* m_pMeterUpdate;
//}}Data

private:
	//{{AFX_DATA(CIuMeterUpdateDlg)
	enum { IDD = IDD_ENGINE_METER_UPDATE };
	CEdit	m_editUserCode;
	CEdit	m_editPhone;
	CEdit	m_editAdd;
	CButton	m_btnCancel;
	CEdit	m_editResponse;		// Edit Controls
	CButton	m_btnWeb;		// Button Controls
	CButton	m_btnAdd;
	CString	m_sRemaining;
	CString	m_sAdd;
	CString	m_sResponse;
	CString	m_sUserCode;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterUpdateDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuMeterUpdateDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnChange();
	afx_msg void OnAddProfiles();
	afx_msg void OnWebsite();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERUPDATEDLG_H_
