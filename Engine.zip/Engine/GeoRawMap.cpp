#include "StdAfx.h"
//{{Include
#include "GeoRawMap.h"
#include "GeoSpec.h"
#include "FieldDefConst.h"
#include "resource.h"
#include "Data\Output.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawMap, CIuGeoRawMap_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawMap)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWMAP, CIuGeoRawMap, CIuGeoRawMap_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoRawMap, IDS_ENGINE_PPG_GEORAWMAP, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuGeoRawMap, IDS_ENGINE_PROP_PHONES, GetPhones, SetPhones, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuGeoRawMap, IDS_ENGINE_PROP_PHONES, IDS_ENGINE_PPG_GEORAWMAP, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawMap::CIuGeoRawMap() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoRawMap::~CIuGeoRawMap()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuGeoRawMap::AddPhone(LPCTSTR pcsz, int iBefore) 
{
	ASSERT(AfxIsValidString(pcsz));
	int iCount = GetPhoneCount();
	if (iBefore < 0 || iBefore >= iCount)
		return m_asPhones.Add(pcsz);

	m_asPhones.InsertAt(iBefore, pcsz);
	return iBefore;
}

void CIuGeoRawMap::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_asPhones.RemoveAll();
	//}}Initialize
}

void CIuGeoRawMap::CreateMap(CIuFieldMap& map)
{
	CIuGeoRawMap_super::CreateMap(map);
	m_aiPhone.RemoveAll();
	int iPhones = GetPhoneCount();
	for (int iPhone = 0; iPhone < iPhones; ++iPhone)
	{
		int iField = map.AddField(GetPhone(iPhone));
		if (iField >= 0)
			m_aiPhone.Add(iField);
	}
}

void CIuGeoRawMap::GetPhones(CStringArray& as) const
{
	as.Copy(m_asPhones);
}

void CIuGeoRawMap::RemoveAllPhones()
{
	m_asPhones.RemoveAll();
}

void CIuGeoRawMap::RemovePhone(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetPhoneCount());
	m_asPhones.RemoveAt(iWhich);
}

void CIuGeoRawMap::SetPhone(int iWhich, LPCTSTR pcsz)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcsz));
	m_asPhones.SetAtGrow(iWhich, pcsz);
}

void CIuGeoRawMap::SetPhones(const CStringArray& as)
{
	m_asPhones.Copy(as);
}

void CIuGeoRawMap::SetSpec(CIuGeoSpec& Spec)
{
	CIuGeoRawMap_super::SetSpec(Spec);

	CStringArray asPhones;
	Spec.GetPhones(asPhones);
	SetPhones(asPhones);
}
