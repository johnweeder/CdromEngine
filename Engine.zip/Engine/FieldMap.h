#ifndef _ENGINE_FIELDMAP_H_
#define _ENGINE_FIELDMAP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_FLAGS_H_
#	include "Interop\Flags.h"
#endif	// _INTEROP_FLAGS_H_
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
#ifndef 	_COMMON_OPTIONS_H_
#	include "Common\Options.h"
#endif	// _COMMON_OPTIONS_H_
#ifndef 	_ENGINE_CASECONVERSION_H_
#	include "Engine\CaseConversion.h"
#endif	// _ENGINE_CASECONVERSION_H_
#ifndef 	_ENGINE_KEY_H_
#	include "Engine\Key.h"
#endif	// _ENGINE_KEY_H_
#ifndef 	_ENGINE_KEYDEF_H_
#	include "Engine\KeyDef.h"
#endif	// _ENGINE_KEYDEF_H_
#ifndef 	_ENGINE_RESOLVESPEC_H_
#	include "Engine\ResolveSpec.h"
#endif	// _ENGINE_RESOLVESPEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldMap)
class CIuExpression;
class CIuFieldMapSpec;
class CIuRecordSpec;
class CIuRecordDef;
struct CIuRecord;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Predefined mappings
enum CIuFieldMapNo
{
	mapNone = 0,	// Terminator

	mapAddressKey,
	mapAddressStrip,
	mapBusinessKey,
	mapBusinessFranchiseKey,
	mapBusiness1Strip,
	mapBusiness6Strip,
	mapNameKey,
	mapPhoneKey,
	mapPhoneStrip,
	mapPriNoToken,
	mapSecNoToken,
	mapSic6,
	mapSicSingle,
	mapStreetToken,
	mapZipKey,
	mapZip4Key,
	mapZip5Key,
	mapZip4Strip,
	mapZip5Strip,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldMap, CIuObjectNamed }}
#define CIuFieldMap_super CIuObjectNamed

class IU_CLASS_EXPORT CIuFieldMap : public CIuFieldMap_super
{
//{{Declare
	DECLARE_SERIAL(CIuFieldMap)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldMap();
	CIuFieldMap(const CIuFieldMap&);
	virtual ~CIuFieldMap();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBoughtLevel() const;
	int GetCaseConvert() const;
	CString GetField(int) const;
	int GetFieldCount() const;
	void GetFields(CStringArray& as) const;
	CString GetKey(int) const;
	int GetKeyCount() const;
	CIuKeyDef& GetKeyDef() const;
	void GetKeys(CStringArray& as) const;
	const CIuRecordDef* GetRecordDef() const;
	bool IsResolved() const;
	bool Truncate() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int AddField(LPCTSTR);
	int AddKey(LPCTSTR);
	int AppendFields(const CIuFieldMap& Map, int* pCount = 0);
	int AppendKeys(const CIuFieldMap& Map, int* pCount = 0);
	void Clear();
	virtual void Copy(const CIuObject& object);
	void CreateMap(const CIuRecordDef& RecordDef);
	void Map(CIuRecordSpec& RecordSpec, const CIuRecord& rawRecord) const;
	void RemoveAll();
	void RemoveAllFields();
	void RemoveAllKeys();
	void RemoveField(int);
	void RemoveKey(int);
	void Resolve(CIuResolveSpec& Spec);
	void SetCaseConvert(int iCaseConvert);
	void SetField(int, LPCTSTR);
	void SetFields(const CStringArray&);
	void SetKey(int, LPCTSTR);
	void SetKeys(const CStringArray&);
	void SetResolved(bool);
	void SetSpec(int iSpec);
	void SetSpec(CIuFieldMapSpec& spec);
	void SetTruncate(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldMap& operator=(const CIuFieldMap&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
protected:
	// These are high performance functions reserved for access 
	// By only a select handful of classes
	friend class CIuBTreeCodec;
	friend class CIuTokenInstance;
	friend class CIuKeyDef;
	friend struct CIuRecord;

private:
	void CommonConstruct();
	CString GetExpression(int iWhich) const;
	int GetExpressionCount() const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:

	// Non-persistent information
protected:
		// These data elements are filled in when the map is resolved.
		// Most of this members represent a "caching" of frequently used information.
		bool m_fResolved;
		// Total number of elements (fields/keys) in mapping
		int m_iCount;
		// Number of fields (this in independent of the record def
		// and reflects the field count at the time of resolution)
		int m_iFields;
		// Number of key fields (this in independent of the record def
		// and reflects the field count at the time of resolution)
		int m_iKeys;
private:
		// Offset of field in source record def (can be < 0 for non-existing fields)
		CIntArray m_aFieldNo;
		// Flags which were associated with this field (0 for non-existing fields)
		CArray<CIuFlags, CIuFlags> m_aFieldFlags;
		// Maximum field length
		CIntArray m_aFieldLength;
		// Field literals
		CStringArray m_aFieldLiteral;
		// Field expressions
		CArray<CIuExpression*, CIuExpression*> m_aFieldExpression;
		// Maximum bought level
		int m_iBoughtLevel;
		// Case conversion mode
		CIuCaseConversionMode m_CaseConvert;
		// A key definition from the resolved record
		CIuKeyDef m_KeyDef;

private:
	// A record def which this structure is a mapping upon
	// Do _not_ use a smart pointer. We only use this as a back pointer
	// and as a means to check whether the record def we have resolved against has 
	// changed. Using a smart pointer causes assertions when the record def is deleted
	// by the process which owns it.
	const CIuRecordDef* m_pRecordDef;

	// This is the persistent information
private:
		// Field names
		CStringArray m_asFields;
		// Key names
		CStringArray m_asKeys;
		// Should field be truncated?
		bool m_fTruncate;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuFieldMap::GetBoughtLevel() const
{
	return m_iBoughtLevel;
}

inline int CIuFieldMap::GetCaseConvert() const
{
	return m_CaseConvert;
}

inline CIuKeyDef& CIuFieldMap::GetKeyDef() const
{
	ASSERT(IsResolved());
	return *const_cast<CIuKeyDef*>(&m_KeyDef);
}

inline const CIuRecordDef* CIuFieldMap::GetRecordDef() const
{
	return m_pRecordDef;
}

inline bool CIuFieldMap::IsResolved() const
{
	return m_fResolved;
}

inline bool CIuFieldMap::Truncate() const
{
	return m_fTruncate;
}

#endif // _ENGINE_FIELDMAP_H_
