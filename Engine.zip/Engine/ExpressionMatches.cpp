#include "StdAfx.h"
//{{Include
#include "ExpressionMatches.h"
#include "AltSpec.h"
#include "CdromSpecConst.h"
#include "resource.h"
#include "Error\Error.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionMatches::CIuExpressionMatches(CIuExpressionType Type) : CIuExpressionElement(Type)
{
	SetFormat(exprFormatBool);
	CommonConstruct();
}

CIuExpressionMatches::CIuExpressionMatches(const CIuExpressionMatches& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionMatches::~CIuExpressionMatches()
{
	if (m_pAlt.NotNull())
	{
		m_pAlt->Close();
		m_pAlt.Release();
	}
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionMatches::Clone() const
{
	CIuExpressionMatches* pElement = new CIuExpressionMatches(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionMatches::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fPatternConst = false;
	m_sPattern = "";
	if (m_pAlt.NotNull())
	{
		m_pAlt->Close();
		m_pAlt.Release();
	}
	m_fPatternExists = false;
	m_Instance.Clear();
	//}}Initialize
}

bool CIuExpressionMatches::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 2);

	if (!m_fPatternConst)
	{
		m_sPattern = EvaluateChild(1, pRecord);
		ResolvePattern();
	}

	if (m_fPatternExists)
	{
		m_sBuffer = EvaluateChild(0, pRecord);
		if (GetType() == exprMatchesFirst)
		{
#pragma __TODO("Optimize this to not use a CString")
			// Deal with full names of the form "Last, First"
			int iComma = m_sBuffer.Find(',');
			if (iComma >= 0)
				m_sBuffer = m_sBuffer.Mid(iComma+1);
			// Only take the first word (everything up to the first space or period)
			// This handles things like "Last, First MI" or "Last, First PhD"
			int iSpace = m_sBuffer.Find(' ');
			if (iSpace >= 0)
				m_sBuffer = m_sBuffer.Mid(iSpace+1);
			int iPeriod = m_sBuffer.Find('.');
			if (iPeriod >= 0)
				m_sBuffer = m_sBuffer.Mid(iPeriod+1);
		}
		m_sBuffer.TrimLeft();
		m_sBuffer.TrimRight();
		bool fMatches = m_Instance.Matches(m_sBuffer);
		return fMatches;
	}
	return false;
}

int CIuExpressionMatches::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionMatches::GetMaxLength() const
{
	// Always returns boolean "0" or "1"
	return BooiMaxLength();
}

LPCTSTR CIuExpressionMatches::GetTypeName() const
{
	switch (GetType())
	{
		case exprMatches:
			return "#Matches#";
		case exprMatchesCity:
			return "MatchesCity";
		case exprMatchesLast:
			return "MatchesLast";
		case exprMatchesFirst:
			return "MatchesFirst";
		case exprMatchesFirstInitial:
			return "MatchesFirstInitial";
	}
	return CIuExpressionMatches_super::GetTypeName();
}

CIuExpressionMatches& CIuExpressionMatches::operator=(const CIuExpressionMatches& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionMatches_super::operator=(rExpressionElement);
	m_fPatternConst = rExpressionElement.m_fPatternConst;
	m_sPattern = rExpressionElement.m_sPattern;
	m_pAlt.Release(); // must re-resolve this....
	m_fPatternExists = false;
	m_Instance.Clear();
	return *this;
}

void CIuExpressionMatches::Resolve(CIuResolveSpec& Spec)
{
	CIuExpressionMatches_super::Resolve(Spec);

	ASSERT(GetChildCount() == 2);

	ResolveFile();

	m_sPattern = "";
	m_fPatternConst = GetChild(1).IsConst();
	if (m_fPatternConst)
	{
		m_sPattern = EvaluateChild(1, 0);
		ResolvePattern();
	}
}

void CIuExpressionMatches::ResolveFile()
{
	if (m_pAlt.NotNull())
	{
		m_pAlt->Close();
		m_pAlt.Release();
	}

	if (!HasRepository())
		Error(IU_E_NO_REPOSITORY);

	CIuAltSpec AltSpec;
	switch (GetType())
	{
		default:
			ASSERT(false);
			return ;
		case exprMatchesCity:
			AltSpec.FromNo(0, altCity);
			break;
		case exprMatchesLast:
			AltSpec.FromNo(0, altLast);
			break;
		case exprMatchesFirst:
			AltSpec.FromNo(0, altFirst);
			break;
		case exprMatchesFirstInitial:
			return ;
	}

	CString sFilename = AltSpec.GetFilename();

	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_ALT);
	int iAlt = GetRepository().Find(CIuMoniker(sFilename), sType);
	if (iAlt < 0)
		Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(sFilename));

	CIuObjectPtr pObject = GetRepository().UnPack(iAlt).Ptr();
	if (pObject.IsNull())
		Error(IU_E_ALT_FILE_NOT_FOUND, LPCTSTR(sFilename));

	m_pAlt = dynamic_cast<CIuAlt*>(pObject.Ptr());
	ASSERT(m_pAlt.NotNull());
	m_pAlt->SetObjectRepository(&GetRepository());

	if (!m_pAlt->IsOpen())
		m_pAlt->Open();
}

void CIuExpressionMatches::ResolvePattern() const
{
	m_fPatternExists = false;

	if (GetType() == exprMatchesFirstInitial)
	{
		m_fPatternExists = true;
		return ;
	}

	if (m_pAlt.IsNull())
		return ;

	ASSERT(m_pAlt.NotNull());
	int iAlt = m_pAlt->Find(m_sPattern);
	if (iAlt < 0)
		return ;

	m_pAlt->Get(iAlt, m_Instance);
	m_fPatternExists = true;
}
