#include "StdAfx.h"
//{{Include
#include "InputDelimited.h"
#include "resource.h"
#include "Data\DataFilename.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInputDelimited, CIuInputDelimited_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputDelimited)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTDELIMITED, CIuInputDelimited, CIuInputDelimited_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputDelimited::CIuInputDelimited() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputDelimited::~CIuInputDelimited()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputDelimited::AddInput(LPCTSTR pcsz, int cb)
{
	if (m_iFields >= recordMaxFields)
	{
		TRACE("WARNING: CIuInputDelimited::Add() exceeded maximum number of fields");
		ASSERT(false);
		return ;
	}

	while (cb > 0 && _istspace(pcsz[0]))
	{
		++pcsz;
		--cb;
	}

	while (cb > 0 && _istspace(pcsz[cb - 1]))
		--cb;

	m_aiOffset[m_iFields] = m_Buffer.GetSize();
	if (cb > 0)
		m_Buffer.Append((const BYTE*)pcsz, cb);
	m_Buffer.Append((BYTE)0);
	++m_iFields;
}

void CIuInputDelimited::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputDelimited"));
	m_Buffer.PreAllocate(4096);
	//}}Initialize
}

CIuFilename CIuInputDelimited::GetFullInputFilename() const
{
	CIuFilename Filename = IuDataFilenameSearch(GetInputFilename(), ".txt");
	return Filename;
}

void CIuInputDelimited::OnClose()
{
	m_Buffer.Destroy();
	CIuInputDelimited_super::OnClose();
}

bool CIuInputDelimited::OnMoveNext()
{
	if (!GetMore())
		return false;

	// Always pull at least one record from the buffer
	int iReps = m_iLf ? m_iLf: 1;
	for (int i = 0; i < iReps; ++i)
	{
		m_Buffer.Empty();
		m_iFields = 0;

		while (*m_psz)
		{
			while (*m_psz && *m_psz != '\"' && *m_psz != '\'' && *m_psz != ',' && *m_psz != '\r' && *m_psz != '\n' && _istspace(*m_psz))
				++m_psz;

			if (*m_psz == '\"' || *m_psz == '\'')
			{
				// Quoted field
				TCHAR chQuote = *m_psz;
				++m_psz;
				LPCTSTR pcszStart = m_psz;

				while (*m_psz && *m_psz != chQuote && *m_psz != '\r' && *m_psz != '\n')
				{
					if (!_istascii(*m_psz) || !_istprint(*m_psz))
						*m_psz = ' ';
					++m_psz;
				}

				int cb = int(m_psz - pcszStart);
				AddInput(pcszStart, cb);

				if (*m_psz == chQuote)
					++m_psz;
				while (*m_psz && *m_psz != ',' && *m_psz != '\r' && *m_psz != '\n')
				{
					++m_psz;
				}
			}
			else if (*m_psz == '\r')
			{
				// cr/lf
				++m_psz;
				if (*m_psz == '\n')
					++m_psz;
				break;
			}
			else if (*m_psz == '\n')
			{
				// lf
				++m_psz;
				break;
			}
			else
			{
				// A regular field
				LPCTSTR pcszStart = m_psz;

				while (*m_psz && *m_psz != ',' && *m_psz != '\r' && *m_psz != '\n')
				{
					if (!_istascii(*m_psz) || !_istprint(*m_psz))
						*m_psz = ' ';
					++m_psz;
				}

				int cb = int(m_psz - pcszStart);

				AddInput(pcszStart, cb);
			}

			// Skip field separator
			if (*m_psz == ',')
				++m_psz;
		}
		if (!Process())
			return false;
	}

	return true;
}

void CIuInputDelimited::SetSpec(CIuCdromSpec& Spec)
{
	CIuInputDelimited_super::SetSpec(Spec);
}

