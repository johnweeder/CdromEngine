#ifndef _ENGINE_METERADMINISTRATORDLG_H_
#define _ENGINE_METERADMINISTRATORDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses											  
#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
#include "Meters.h"	// Added by ClassView
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterAdministratorDlg, CDialog }}
#define CIuMeterAdministratorDlg_super CDialog

class CIuMeterAdministratorDlg : public CIuMeterAdministratorDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP() 
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuMeterAdministratorDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuMeters& GetMeters() const;
	bool HasMeters() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool DoDialog(CIuMeters& Meters, CWnd* pParent = 0, CIuID idMeter = CIuID(), LPCTSTR pcszQueryCode = 0, CString* pResponseCode = 0);
	void SetMeters(CIuMeters* pMeters);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Some display stuff
	HICON m_hIcon;
	CFont m_fontLarge;
	// The meters collection
	CIuMeters* m_pMeters;
	// Initial meter and query code (if specified)
	CIuID m_idMeter;
//}}Data

	//{{AFX_DATA(CIuMeterAdministratorDlg)
	enum { IDD = IDD_ENGINE_METER_ADMINISTRATOR };
	CButton	m_btnTestMeter;
	CButton	m_btnSpecial;
	CEdit	m_editResponseCheckSum;
	CEdit	m_editResponse;
	CButton	m_btnResetMeter;
	CComboBox	m_cbMeters;
	CEdit	m_editUserCode;
	CString	m_sUserCode;
	CString	m_sCount;
	CString	m_sResponse; 
	CString	m_sCurrent;
	CString	m_sNotes;
	CString	m_sResponseCheckSum;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIuMeterAdministratorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuMeterAdministratorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	afx_msg void OnSearch();
	afx_msg void OnRefresh();
	afx_msg void OnResetMeter();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPaint();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	virtual void OnOK();
	afx_msg void OnSpecial();
	afx_msg void OnSelectPhone();
	afx_msg void OnTestMeter();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuMeters& CIuMeterAdministratorDlg::GetMeters() const
{
	ASSERT(HasMeters());
	return *m_pMeters;
}

inline bool CIuMeterAdministratorDlg::HasMeters() const
{
	return m_pMeters != 0;
}

#endif // _ENGINE_METERADMINISTRATORDLG_H_ 
