#include "StdAfx.h"
//{{Include
#include "CdromStripSpecDft.h"
#include "CdromSpecConst.h"
#include "CdromStrip.h"
#include "Strip.h"
#include "Token.h"
#include "RecordDef.h"
#include "RecordSort.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Strip specifications

static const CIuCdromStripSpecDft aStrip[] =
{
	{
		_T("Address"), cdromStripAddress,
		_T("Address"),
		stripAddress,
		sortAddress,
	},{
		_T("Business1"), cdromStripBusiness1,
		_T("Business"),
		stripBusiness1,
		sortBusiness,
	},{
		_T("Business6"), cdromStripBusiness6,
		_T("Business"),
		stripBusiness6,
		sortBusiness,
	},{
		_T("BusinessFranchise1"), cdromStripBusinessFranchise1,
		_T("BusinessFranchise"),
		stripBusinessFranchise1,
		sortBusinessFranchise,
	},{
		_T("BusinessFranchise6"), cdromStripBusinessFranchise6,
		_T("BusinessFranchise"),
		stripBusinessFranchise6,
		sortBusinessFranchise,
	},{
		_T("Name"), cdromStripName,
		_T("Name"),
		stripNone,
		sortNone,
	},{
		_T("Phone"), cdromStripPhone,
		_T("Phone"),
		stripPhone,
		sortPhone,
	},{
		_T("Zip4"), cdromStripZip4,
		_T("Zip4"),
		stripZip4,
		sortZip4,
	},{
		_T("Zip5"), cdromStripZip5,
		_T("Zip5"),
		stripZip5,
		sortZip5,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuCdromStripSpecDft

int CIuCdromStripSpecDft::Find(LPCTSTR pcszStrip)
{
	ASSERT(AfxIsValidString(pcszStrip));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszStrip, pcszStrip) == 0)
			return i;
	}
	return -1;
}

int CIuCdromStripSpecDft::Find(int iStrip)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iStrip == iStrip)
			return i;
	}
	return -1;
}

const CIuCdromStripSpecDft* CIuCdromStripSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aStrip + iWhich;
}

int CIuCdromStripSpecDft::GetCount()
{
	return sizeof(aStrip) / sizeof(aStrip[0]);
}


