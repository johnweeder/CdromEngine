#include "stdafx.h"
#include "MeterCodesDlg.h"
#include "Engine.h"
#include "Common\QueryResponseSession.h"
#include "Common\QueryResponseCode.h"
#include "Ui\ComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CIuMeterCodesDlg::CIuMeterCodesDlg(CWnd* pParent /*=NULL*/) : CIuMeterCodesDlg_super(CIuMeterCodesDlg::IDD, pParent)
{
	//{{Initialize
	m_pMeters = 0;
	//}}Initialize													 
																			   
	//{{AFX_DATA_INIT(CIuMeterCodesDlg)
	m_sSuper0 = _T("");
	m_sSuper07 = _T("");
	m_sSuper1 = _T("");
	m_sSuper2 = _T("");
	m_sSuperCheck0 = _T("");
	m_sSuperCheck07 = _T("");
	m_sSuperCheck2 = _T("");
	m_sSuperCheck1 = _T("");
	m_sDate = _T("");											   
	m_sDateCheck = _T("");
	//}}AFX_DATA_INIT
	m_pMeters = NULL;
}

void CIuMeterCodesDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterCodesDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterCodesDlg)
	DDX_Control(pDX, IDC_ENGINE_STARTDATE, m_StartDate);
	DDX_Control(pDX, IDC_ENGINE_RANGE, m_cbRange);
	DDX_Control(pDX, IDC_ENGINE_ACCESS, m_cbAccess);
	DDX_Control(pDX, IDC_ENGINE_DATE_CHECK, m_editDateCheck);
	DDX_Control(pDX, IDC_ENGINE_DATE, m_editDate);
	DDX_Control(pDX, IDC_ENGINE_SUPER_CHECK1, m_editSuperCheck1);
	DDX_Control(pDX, IDC_ENGINE_SUPER_CHECK2, m_editSuperCheck2);
	DDX_Control(pDX, IDC_ENGINE_SUPER_CHECK0, m_editSuperCheck0);
	DDX_Control(pDX, IDC_ENGINE_SUPER_CHECK07, m_editSuperCheck07);
	DDX_Control(pDX, IDC_ENGINE_SUPER2, m_editSuper2);
	DDX_Control(pDX, IDC_ENGINE_SUPER1, m_editSuper1);
	DDX_Control(pDX, IDC_ENGINE_SUPER0, m_editSuper0);
	DDX_Control(pDX, IDC_ENGINE_SUPER07, m_editSuper07);
	DDX_Text(pDX, IDC_ENGINE_SUPER0, m_sSuper0);
	DDX_Text(pDX, IDC_ENGINE_SUPER07, m_sSuper07);
	DDX_Text(pDX, IDC_ENGINE_SUPER1, m_sSuper1);
	DDX_Text(pDX, IDC_ENGINE_SUPER2, m_sSuper2);
	DDX_Text(pDX, IDC_ENGINE_SUPER_CHECK0, m_sSuperCheck0);
	DDX_Text(pDX, IDC_ENGINE_SUPER_CHECK07, m_sSuperCheck07);
	DDX_Text(pDX, IDC_ENGINE_SUPER_CHECK2, m_sSuperCheck2);
	DDX_Text(pDX, IDC_ENGINE_SUPER_CHECK1, m_sSuperCheck1);
	DDX_Text(pDX, IDC_ENGINE_DATE, m_sDate);
	DDX_Text(pDX, IDC_ENGINE_DATE_CHECK, m_sDateCheck);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIuMeterCodesDlg, CIuMeterCodesDlg_super)
	//{{AFX_MSG_MAP(CIuMeterCodesDlg)
	ON_CBN_EDITCHANGE(IDC_ENGINE_ACCESS, OnChange)
	ON_CBN_SELCHANGE(IDC_ENGINE_ACCESS, OnChange)
	ON_CBN_EDITCHANGE(IDC_ENGINE_RANGE, OnChange)
	ON_CBN_SELCHANGE(IDC_ENGINE_RANGE, OnChange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_ENGINE_STARTDATE, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuMeterCodesDlg::DoDialog(CIuMeters& Meters, CIuMeter* pMeter, UINT uiUserValue, CWnd* pParent)
{
	CIuMeterCodesDlg Dlg(pParent);
	Dlg.m_pMeters = &Meters;
	Dlg.m_pMeter = pMeter;
	Dlg.m_uiUserValue = uiUserValue;
	if (Dlg.DoModal() != IDOK)
		return false;
	return true;
}

void CIuMeterCodesDlg::OnChange()
{
	m_sSuper0 = _T("");
	m_sSuper07 = _T("");
	m_sSuperCheck0 = _T("");
	m_sSuperCheck07 = _T("");
	m_sSuper1 = _T("");
	m_sSuper2 = _T("");
	m_sSuperCheck0 = _T("");
	m_sSuperCheck07 = _T("");
	m_sSuperCheck2 = _T("");
	m_sSuperCheck1 = _T("");
	m_sDate = _T("");
	m_sDateCheck = _T("");

	ASSERT(m_pMeters);
	if ((m_pMeters->GetUserRights() & engineRightsSuper) != 0)
	{
		CString sSuper0 = CIuQueryResponseSession::GetResponseSuper0();
		m_sSuper0 = CIuQueryResponseCode::Reformat(sSuper0, queryFormatCode);
		m_sSuperCheck0 = CIuQueryResponseCode::Reformat(sSuper0, queryFormatCheckSum);

		CString sSuper07 = CIuQueryResponseSession::GetResponseSuper07();
		m_sSuper07 = CIuQueryResponseCode::Reformat(sSuper07, queryFormatCode);
		m_sSuperCheck07 = CIuQueryResponseCode::Reformat(sSuper07, queryFormatCheckSum);
	}

	if (m_pMeter)
	{
		CString sKey = m_pMeter->GetKey();
		CIuQueryResponseSession Session(sKey);
		if ((m_pMeters->GetUserRights() & engineRightsSuper) != 0)
		{
			CString sSuper1 = Session.GetResponseSuper1();
			m_sSuper1 = CIuQueryResponseCode::Reformat(sSuper1, queryFormatCode);
			m_sSuperCheck1 = CIuQueryResponseCode::Reformat(sSuper1, queryFormatCheckSum);
		}

		int iAccess = m_cbAccess.GetCurSel();
		if (iAccess != CB_ERR)
		{
			DWORD dwAccess = m_cbAccess.GetItemData(iAccess);
			if ((m_pMeters->GetUserRights() & engineRightsSuper) != 0)
			{
				CString sSuper2 = Session.GetResponseSuper2(dwAccess);
				m_sSuper2 = CIuQueryResponseCode::Reformat(sSuper2, queryFormatCode);
				m_sSuperCheck2 = CIuQueryResponseCode::Reformat(sSuper2, queryFormatCheckSum);
			}
			if ((m_pMeters->GetUserRights() & engineRightsDateRange) != 0)
			{
				int iRange = m_cbRange.GetCurSel();
				if (iRange != CB_ERR)
				{
					DWORD dwRange = m_cbRange.GetItemData(iRange);
					COleDateTime dtStart;
					m_StartDate.GetTime(dtStart);
					CString sDate = Session.GetResponseRange(dwAccess, dtStart, UINT16(dwRange));
					m_sDate = CIuQueryResponseCode::Reformat(sDate, queryFormatCode);
					m_sDateCheck = CIuQueryResponseCode::Reformat(sDate, queryFormatCheckSum);
				}
			}
		}
	}
	UpdateData(false);
}

BOOL CIuMeterCodesDlg::OnInitDialog() 
{
	CIuMeterCodesDlg_super::OnInitDialog();
	
	CFont* pFont = m_editSuper0.GetFont();
	ASSERT(pFont);
	CIuFont Font(*pFont);
	if (Font.GetSize() < 18)
		Font.SetSize(18);

	Font.CreateFont(m_fontLarge);

	m_editSuper0.SetFont(&m_fontLarge);
	m_editSuperCheck0.SetFont(&m_fontLarge);
	m_editSuper07.SetFont(&m_fontLarge);
	m_editSuperCheck07.SetFont(&m_fontLarge);
	m_editSuper1.SetFont(&m_fontLarge);
	m_editSuperCheck1.SetFont(&m_fontLarge);
	m_editSuper2.SetFont(&m_fontLarge);
	m_editSuperCheck2.SetFont(&m_fontLarge);
	m_editDate.SetFont(&m_fontLarge);
	m_editDateCheck.SetFont(&m_fontLarge);

	if (m_pMeter)
	{
		CBLoad(m_cbRange, _T("1 Day"), nQueryResponse1Day);
		CBLoad(m_cbRange, _T("7 Days"), nQueryResponse7Days);
		CBLoad(m_cbRange, _T("30 Days"), nQueryResponse30Days);
		CBLoad(m_cbRange, _T("90 Days"), nQueryResponse90Days);
		m_cbRange.SetCurSel(0);

		if (m_uiUserValue != meterMagicInvalid)
		{
			CString sUserValue;
			sUserValue.Format(_T("Current Access: 0x%08X"), m_uiUserValue);
			CBLoad(m_cbAccess, sUserValue, m_uiUserValue);
		}
		CBLoad(m_cbAccess, _T("Reset Meter"), meterMagicMeterReset);
		CBLoad(m_cbAccess, _T("Clear Corrupt Meter"), meterMagicMeterCorrupt);
		CBLoad(m_cbAccess, _T("Expiration Over-ride"), meterMagicExpireOverRide);
		CBLoad(m_cbAccess, _T("Set Meter Revision 0"), meterMagicRev0);
		CBLoad(m_cbAccess, _T("Single-User Network Enable"), meterMagicNetworkEnable_SingleUser);
		CBLoad(m_cbAccess, _T("Multi-User Network Enable"), meterMagicNetworkEnable_MultiUser);
		CBLoad(m_cbAccess, _T("Single-User Enable"), meterMagicAccessCodeEnable_SingleUser);
		CBLoad(m_cbAccess, _T("Multi-User Enable"), meterMagicAccessCodeEnable_MultiUser);
		m_cbAccess.SetCurSel(0);
	}
	else
	{
		m_StartDate.EnableWindow(false);
		m_cbRange.EnableWindow(false);
		m_cbAccess.EnableWindow(false);
	}

	OnChange();

	CenterWindow();

	return true;  
}
