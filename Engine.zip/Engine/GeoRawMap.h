#ifndef _ENGINE_GEORAWMAP_H_
#define _ENGINE_GEORAWMAP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOMAP_H_
#	include "Engine\GeoMap.h"
#endif	// _ENGINE_GEOMap_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawMap)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawMap, CIuGeoMap }}
#define CIuGeoRawMap_super CIuGeoMap

class CIuGeoRawMap : public CIuGeoRawMap_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawMap)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawMap();
	virtual ~CIuGeoRawMap();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddPhone(LPCTSTR, int iBefore = -1);
	CString GetPhone(int) const;
	int GetPhoneCount() const;
	void GetPhones(CStringArray& as) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void RemoveAllPhones();
	void RemovePhone(int);
	void SetPhone(int, LPCTSTR);
	void SetPhones(const CStringArray&);
	void SetSpec(CIuGeoSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	virtual void CreateMap(CIuFieldMap& map);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoRawInstance;
	// A list of fields containing phone numbers
	CStringArray m_asPhones;
	// The resolved field offsets for the phone number fields
	CIntArray m_aiPhone;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuGeoRawMap::GetPhone(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetPhoneCount());
	return m_asPhones[iWhich];
}

inline int CIuGeoRawMap::GetPhoneCount() const
{
	return m_asPhones.GetSize();
}

#endif // _ENGINE_GEORAWMAP_H_
