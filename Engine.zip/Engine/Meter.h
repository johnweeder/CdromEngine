#ifndef _ENGINE_METER_H_ 
#define _ENGINE_METER_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_GUID_H_
#	include "Interop\Guid.h"
#endif	// _INTEROP_GUID_H_
#ifndef 	_ENGINE_METERUPDATE_H_
#	include "Engine\MeterUpdate.h"
#endif	// _ENGINE_METERUPDATE_H_
#ifndef 	_ENGINE_SECURITY_H_
#	include "Engine\Security.h"
#endif	// _ENGINE_SECURITY_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuMeter)
class CIuMeters;
class CIuMeterSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Meter types
enum CIuMeterNo
{
	meterAll = -1,

	meterNone = 0,

	meterFirst,
		meter104m_2001 = meterFirst,
		meter88md_2001,
		meterAc_V1,
		meterBml_2000,
		meterCi_V1,
		meterOam_V1,
		meterPb_2001,
		meterPbm_V1,
		meterPf_2000,
		meterPf_2001,
		meterPg_2000,
		meterPu_2000,
		meterPu_2001,
		meterRbocGreatLakes_2000,
		meterRbocSeAtlantic1_2000,
		meterRbocSeAtlantic2_2000,
		meterRbocNeAtlantic1_2000,
		meterRbocNeAtlantic2_2000,
		meterRbocPacific_2000,
		meterRbocSouthWest_2000,
		meterRbocMidWest_2000,
		meterRbocTest_2000,
		meterRp_2001,
		meterSample,
		meterSlu_2000,
		meterYpu_2001,
	meterLast,
};

/////////////////////////////////////////////////////////////////////////////
// Meter Modes

const int meterModeUnknown = 0;
// The standard cd-rom based meter
const int meterModeCdrom = 1;
// A memory based meter (sort of a "dummy" meter)
// Used by workbooks and other things
const int meterModeMemory = 2;

/////////////////////////////////////////////////////////////////////////////
// Meter constants

// Flags
// Meter warns on every pass, not just once per day
const int meterFlagNotifyAlways		= 0x00000001;

// Disable display of the large STOP sign graphic
// on the warning dialog.
const int meterFlagNotifyNoWarning	= 0x00000002;

// User does not need to acknowledge meter
const int meterFlagNoAcknowledge		= 0x00000004;

// These are the id's for DWORD values which are stored in the meter.
// The id's need not be sequential... but you _MUST_ preserve the value of
// existing ids.
enum CIuMeterID
{
	// This are the base things stored in a meter
	// Basically, these values are only stored in the meter
	meterCount,
	meterExpireDateObsolete,	// Obsolete... there was a bug in the initial implementation
	meterInitialCount,			// Obsolete... not used in meter, always stored in CIuMeter object
	meterInstallDate,
	meterLastNotifyDate,
	meterMaxOutput,				// Obsolete... not used in meter, always stored in CIuMeter object
	meterTotal,
	meterVersion,
	meterWarningDate,
	meterExpireDate,
	meterLastDate,					// The last date seen....
	meterRev,						// Meter revision
	meterNotification,			// Stored if notifcation was displayed and accepted
	// Related to registration
	meterRegistered,
	meterRemainingRuns,
	// Current upgrade level (often incremented for each release)
	meterUpgradeCurrent,

	// These are specialty meter items
	meterSpecial = 1000,
	// Allow access from a network
	meterNetworkEnable,
	// Access code enable (some apps must be enabled to work at all)
	meterAccessCodeEnable,
};

// The high word of the meter value returned in a query/response code is
// the current value of the meter. The low word is the number of records
// being request.
// If the high word is > meterMagicMeterCurrentMax, then the meter is 
// carrying a special query. The low word is available to be used
// to carry an arbitrary 16-bit value.

// Other values in the high word indicate other "magic" values.
// This represents the maximum current record count which can be returned.
const DWORD meterMagicMeterCurrentMax						= 0xC350; // 50,000

// The maximum amount which can be added in one update is this value.
const DWORD meterMagicMeterUpdateMax						= 0xC350; // 50,000

// This code is sent power the power check utility when the 
// user is requesting a reset of the meter.
// The lower 16-bits is the meter count for the product (<= meterMagicMeterCurrentMax)
const DWORD meterMagicMeterReset								= 0xFFFE0000;

// Indication that meter is corrupt. A correct code will reset the meter to its initial state.
const DWORD meterMagicMeterCorrupt							= 0xFFFF0002;

// 30 day over-ride for meter expiration
const DWORD meterMagicExpireOverRide						= 0xFFFF0003;

// Reset meter to revision 0
const DWORD meterMagicRev0										= 0xFFFF0007;

// An invalid code which should never happen
const DWORD meterMagicInvalid									= 0xFFFFFFFF;

// When updating via the query/response, a user value is passed around. Special user
// values are passed for things like network enabling (cd-only flag).
// These should be _very_ large number so that they are not confused with meter count
// update values.
// Single User / Network 
const DWORD meterMagicNetworkEnable_SingleUser			= 0xFFFF0001;
const DWORD meterMagicNetworkEnable_MultiUser			= 0xFFFF0005;

// Requesting product access
const DWORD meterMagicAccessCodeEnable_SingleUser		= 0xFFFF0004;
const DWORD meterMagicAccessCodeEnable_MultiUser  		= 0xFFFF0006;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeter, CIuCollectable }}
#define CIuMeter_super CIuCollectable

class IU_CLASS_EXPORT CIuMeter : public CIuMeter_super
{
//{{Declare
	DECLARE_SERIAL(CIuMeter)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeter();           
	virtual ~CIuMeter();
	CIuMeter(const CIuMeter&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool AllowUpdate() const;
	void Close(bool fForce = false);
	bool Exists() const;
	int GetBoughtCount() const;
	int GetBoughtLevel(DWORD /* dwSourceNo */, DWORD /* dwRecordNo */) const;
	int GetCount() const;
	COleDateTime GetExpireDate() const;
	int GetExpireDays() const;
	CString GetFilename() const;
	int GetFlags() const;
	void GetGuid(CIuGuid& guid1, CIuGuid& guid2) const;
	CIuGuid GetGuid1() const;
	CIuGuid GetGuid2() const;
	int GetInitialCount() const;
	int GetInitialCountUpgrade() const;
	int GetInitialRev() const;
	COleDateTime GetInstallDate() const;
	CString GetKey() const;
	COleDateTime GetLastDate() const;
	COleDateTime GetLastNotifyDate() const;
	int GetMaxOutput() const;
	CIuMeters& GetMeters() const;
	int GetMode() const;
	CIuObjectRepository& GetObjectRepository() const;
	CString GetPhone() const;
	CIuMoniker GetPrevious() const;
	COleDateTime GetReleaseDate() const;
	int GetRemainingRuns(int iRemainingRunsDft) const;
	bool GetRegistered() const;
	int GetRev() const;
	CString GetSpecialAccess() const;
	void GetStatus(CTreeCtrl& Tree) const;
	int GetTotal() const;
	int GetUpgradeCount() const;
	int GetUpgradeCurrent() const;
	int GetUpgradeLevel() const;
	int GetUserRights() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	int GetVersionNo() const;
	COleDateTime GetWarningDate() const;
	int GetWarningDays() const;
	CString GetWarningText() const;
	CString GetWebSite() const;
	bool HasObjectRepository() const;
	bool HasSpeedBump() const;
	bool IsCorrupt() const;
	bool IsOpen() const;
	bool IsExpired() const;
	bool IsMetered() const;
	bool IsWarning() const;
	bool ShouldNotify() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	bool CheckAcknowledge(CWnd* pParent);
	void Copy(const CIuObject& object);
	void Corrupt();
	CIuMeterUpdatePtr CreateMeterUpdate(int Count) const;
	bool Decrement(int iCount);
	bool Delete();
	void Hack(bool fNew = false);
	void Open();
	void Refresh();
	bool Reset();
	void SetAllowUpdate(bool);
	bool SetBoughtLevel(DWORD /* dwSourceNo */, DWORD /* dwRecordNo */, int /* iBoughtLevel */, bool /* fDecrement */, bool* /* pfNewBuy */);
	void SetCount(int iCount, bool fClearCache = false);
	void SetExpireDate(const COleDateTime&);
	void SetExpireDate(int iAdditionalDays = 30);
	void SetExpireDays(int);
	void SetFilename(LPCTSTR);
	void SetFlags(int iFlags);
	void SetGuid1(const CIuGuid& guid);
	void SetGuid2(const CIuGuid& guid);
	void SetInitialCount(int);
	void SetInitialCountUpgrade(int iInitialCountUpgrade);
	void SetInitialRev(int iInitialRev);
	void SetInstallDate(const COleDateTime&);
	void SetKey(LPCTSTR);
	void SetLastDate(const COleDateTime& dt);
	void SetLastNotifyDate();
	void SetLastNotifyDate(const COleDateTime&);
	void SetMaxOutput(int);
	void SetMode(int iMode);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetPhone(LPCTSTR);
	void SetPrevious(const CIuMoniker&);
	void SetRegistered(bool fRegistered);
	void SetReleaseDate(const COleDateTime&);
	void SetRemainingRuns(int iRemainingRuns);
	void SetRev(int iRev);
	void SetSpec(CIuMeterSpec& MeterSpec);
	void SetSpecialAccess(LPCTSTR);
	void SetTotal(int iTotal);
	void SetUpgradeCount(int iUpgradeCount);
	void SetUpgradeCurrent(int iUpgradeCurrent);
	void SetUpgradeLevel(int iUpgradeLevel);
	void SetVersionNo(int);
	void SetWarningDate(const COleDateTime&);
	void SetWarningDays(int);
	void SetWarningText(LPCTSTR);
	void SetWebSite(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuMeter& operator=(const CIuMeter&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionCreateMeterUpdate(const CIuPropertyCollection& Collection, CIuOutput& Output);

public:
	// Low level meter access
	static COleDateTime GetCurrentDay();
	void Flush();
	DWORD GetValue(CIuMeterID, DWORD dwDefault) const;
	COleDateTime GetValue(CIuMeterID id, COleDateTime dtDefault) const;
	void SetValue(CIuMeterID id, DWORD dwValue);
	void SetValue(CIuMeterID id, const COleDateTime& dtValue);

private:
	friend class CIuMeterSpecialAccessDlg;

	void CommonConstruct();
	void InitSecurity() const;
	void Migrate();
	bool OpenIfNeeded() const;
	bool PreviousExists() const;
	void Upgrade();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The object repository.
	CIuObjectRepository* m_pObjectRepository;

	// Open count 
	// Close automatically at destruction, or you can flush
	int m_iOpen;

	// Persistent data... see MeterSpecDft.h for descriptions.
		CString m_sKey;
		CIuGuid m_guid1;
		CIuGuid m_guid2;
		CString m_sFilename;
		bool m_fAllowUpdate;
		int m_iInitialCount;
		int m_iMaxOutput;
		int m_iWarningDays;
		int m_iExpireDays;
		COleDateTime m_dtReleaseDate;
		CString m_sPhone;
		CString m_sWebSite;
		int m_iFlags;
		int m_iInitialRev;
		CString m_sWarningText;
		CString m_sSpecialAccess;
		int m_iUpgradeCount;
		int m_iUpgradeLevel;
		// Moniker of previous meter (if an upgrade is to be performed)
		CIuMoniker m_monikerPrevious;

	// Non-persistent data
		// The meter "mode". Effect the type of security apparatus
		int m_iMode;
		// The actual security apparatus itself
		mutable CIuSecurityPtr m_pSecurity;
		mutable bool m_fInitSecurity;
		// A "cache" of ticks extracted from the meter
		int m_iCachedCount;
	int m_iInitialCountUpgrade;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline int CIuMeter::GetExpireDays() const
{
	return m_iExpireDays;
}

inline CString CIuMeter::GetFilename() const
{
	return m_sFilename;
}

inline int CIuMeter::GetFlags() const
{
	return m_iFlags;
}

inline void CIuMeter::GetGuid(CIuGuid& guid1, CIuGuid& guid2) const
{
	guid1 = m_guid1;
	guid2 = m_guid2;
}

inline CIuGuid CIuMeter::GetGuid1() const
{
	return m_guid1;
}

inline CIuGuid CIuMeter::GetGuid2() const
{
	return m_guid2;
}

inline int CIuMeter::GetInitialCount() const
{
	return m_iInitialCount;
}

inline int CIuMeter::GetInitialCountUpgrade() const
{
	return m_iInitialCountUpgrade;
}

inline int CIuMeter::GetInitialRev() const
{
	return m_iInitialRev;
}

inline CString CIuMeter::GetKey() const
{
	return m_sKey;
}

inline int CIuMeter::GetMode() const
{
	return m_iMode;
}

inline int CIuMeter::GetMaxOutput() const
{
	return m_iMaxOutput;
}

inline CIuObjectRepository& CIuMeter::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuMoniker CIuMeter::GetPrevious() const
{
	return m_monikerPrevious;
}

inline COleDateTime CIuMeter::GetReleaseDate() const
{
	return m_dtReleaseDate;
}

inline CString CIuMeter::GetSpecialAccess() const
{
	return m_sSpecialAccess;
}

inline int CIuMeter::GetUpgradeCount() const
{
	return m_iUpgradeCount;
}

inline int CIuMeter::GetUpgradeLevel() const
{
	return m_iUpgradeLevel;
}

inline CString CIuMeter::GetWarningText() const
{
	return m_sWarningText;
}

inline bool CIuMeter::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuMeter::IsOpen() const
{
	return m_iOpen > 0;
}

#endif
