#ifndef _ENGINE_GEORAWCITY_H_
#define _ENGINE_GEORAWCITY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENT_H_
#	include "Engine\GeoRawElement.h"
#endif	// _ENGINE_GEORAWELEMENT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawCity)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawCity, CIuGeoRawElement }}
#define CIuGeoRawCity_super CIuGeoRawElement
class CIuGeoRawCity : public CIuGeoRawCity_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawCity)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawCity();
	virtual ~CIuGeoRawCity();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetCity() const;
	CIuGeoRawElementAccumulator& GetMsa() const;
	CString GetStateAbbr() const;
	CIuGeoRawElementAccumulator& GetZips() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetMsa_() const;
	CIuObject* GetZips_() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	mutable CIuGeoRawElementAccumulator m_Msa;
	mutable CIuGeoRawElementAccumulator m_Zips;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoRawElementAccumulator& CIuGeoRawCity::GetMsa() const
{
	return m_Msa;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawCity::GetZips() const
{
	return m_Zips;
}

#endif // _ENGINE_GEORAWCITY_H_
