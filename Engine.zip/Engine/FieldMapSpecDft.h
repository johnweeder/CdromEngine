#ifndef _ENGINE_FIELDMAPSPECDFT_H_
#define _ENGINE_FIELDMAPSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Default maps

// Disable "zero-sized array in struct/enum" warning
#pragma warning(disable:4200)
struct CIuFieldMapSpecDft
{
public:
	static int Find(LPCTSTR pcszFieldMap);
	static int Find(int iFieldMap);
	static const CIuFieldMapSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// ID 
	int m_iFieldMap;
	// Name
	LPCTSTR m_pcszFieldMap;
	// First the fields:
	//		0 or more strings followed by a null string
	// Then the key:
	//		0 or more strings followed by another null string
	LPCTSTR m_apcszFields[];
};
#pragma warning(default:4200)

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_FIELDMAPSPECDFT_H_
