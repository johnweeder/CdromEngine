#ifndef _ENGINE_INPUTRECORDFILE_H_
#define _ENGINE_INPUTRECORDFILE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDFILE_H_
#	include "Engine\RecordFile.h"
#endif	// _ENGINE_RECORDFILE_H_
#ifndef 	_ENGINE_INPUT_H_
#	include "Engine\Input.h"
#endif	// _ENGINE_INPUT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputRecordFile)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

#if _MSC_VER > 1000
#	pragma once
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputRecordFile, CIuInput }}
#define CIuInputRecordFile_super CIuInput

class CIuInputRecordFile : public CIuInputRecordFile_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputRecordFile)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputRecordFile();
	virtual ~CIuInputRecordFile();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuFilename GetFullOutputFilename() const;
	CIuRecordFile& GetRecordFile() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetOutputFilename(LPCTSTR pcsz);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnOutput();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The output file
	CIuRecordFilePtr m_pRecordFile;
	// A record 
	CIuRecordPtr m_pRecord;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuRecordFile& CIuInputRecordFile::GetRecordFile() const
{
	return m_pRecordFile.Ref();
}

#endif // _ENGINE_INPUTRECORDFILE_H_
