#include "StdAfx.h"
//{{Include
#include "RegistrationSpec.h"
#include "RegistrationSpecDft.h"
#include "CdromSpec.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRegistrationSpec, CIuRegistrationSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRegistrationSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REGISTRATIONSPEC, CIuRegistrationSpec, CIuRegistrationSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuRegistrationSpec, IDS_ENGINE_PPG_REGISTRATIONSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRegistrationSpec, IDS_ENGINE_PROP_REGISTRATIONNO, GetRegistrationNo, SetRegistrationNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRegistrationSpec, IDS_ENGINE_PROP_REGISTRATIONNO, IDS_ENGINE_PPG_REGISTRATIONSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_PRODUCTNAME, GetProductName, SetProductName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_PRODUCTNAME, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_PRODUCTID, GetProductID, SetProductID, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_PRODUCTID, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRegistrationSpec, IDS_ENGINE_PROP_MAXRUNS, GetMaxRuns, SetMaxRuns, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRegistrationSpec, IDS_ENGINE_PROP_MAXRUNS, IDS_ENGINE_PPG_REGISTRATIONSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_FAXPHONE, GetFaxPhone, SetFaxPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_FAXPHONE, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MAILADDRESS, GetMailAddress, SetMailAddress, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MAILADDRESS, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_URL, GetURL, SetURL, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_URL, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_VOICEPHONE, GetVoicePhone, SetVoicePhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_VOICEPHONE, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONEAREACODE, GetModemPhoneAreaCode, SetModemPhoneAreaCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONEAREACODE, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONECOUNTRYCODE, GetModemPhoneCountryCode, SetModemPhoneCountryCode, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONECOUNTRYCODE, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONE, GetModemPhone, SetModemPhone, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRegistrationSpec, IDS_ENGINE_PROP_MODEMPHONE, IDS_ENGINE_PPG_REGISTRATIONSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuRegistrationSpec, IDS_ENGINE_PROP_VALIDRESPONSES, GetValidResponses, SetValidResponses, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuRegistrationSpec, IDS_ENGINE_PROP_VALIDRESPONSES, IDS_ENGINE_PPG_REGISTRATIONSPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRegistrationSpec::CIuRegistrationSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRegistrationSpec::~CIuRegistrationSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRegistrationSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_iRegistrationNo = 0;
	m_iMaxRuns = -1;
	SetVersion(IU_VERSION);
	m_sURL = "";
	m_sVoicePhone = "";
	m_sModemPhoneAreaCode = "";
	m_sModemPhoneCountryCode = "";
	m_sModemPhone = "";
	//}}Initialize
}

void CIuRegistrationSpec::FromIndex(CIuCdromSpec* pCdrom, int iRegistrationSpec)
{
	ASSERT(iRegistrationSpec >= 0);

	const CIuRegistrationSpecDft* pRegistrationSpec = CIuRegistrationSpecDft::Get(iRegistrationSpec);
	ASSERT(pRegistrationSpec);

	FromSpec(pCdrom, pRegistrationSpec);
}

void CIuRegistrationSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszRegistration)
{
	FromIndex(pCdrom, CIuRegistrationSpecDft::Find(pcszRegistration));
}

void CIuRegistrationSpec::FromNo(CIuCdromSpec* pCdrom, int iRegistrationNo)
{
	FromIndex(pCdrom, CIuRegistrationSpecDft::Find(iRegistrationNo));
}

void CIuRegistrationSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuRegistrationSpecDft* pRegistrationSpec)
{
	SetCdrom(pCdrom);

	if (HasCdrom())
		SetID(GetCdrom().GetID());
	else
		SetID(CIuID::Create());

	// Always use the name of the registration def....
	SetName(pRegistrationSpec->m_pcszRegistration);

	SetRegistrationNo(pRegistrationSpec->m_iRegistration);

	SetProductName(pRegistrationSpec->m_pcszName);
	SetProductID(pRegistrationSpec->m_pcszID);
	SetMaxRuns(pRegistrationSpec->m_iMaxRuns);
	SetFaxPhone(pRegistrationSpec->m_pcszFaxPhone);
	SetMailAddress(pRegistrationSpec->m_pcszMailAddress);
	SetURL(pRegistrationSpec->m_pcszURL);
	SetVoicePhone(pRegistrationSpec->m_pcszVoicePhone);
	SetModemPhoneAreaCode(pRegistrationSpec->m_pcszModemPhoneAreaCode);
	SetModemPhoneCountryCode(pRegistrationSpec->m_pcszModemPhoneCountryCode);
	SetModemPhone(pRegistrationSpec->m_pcszModemPhone);
	ASSERT(pRegistrationSpec->m_pidMeter);
	SetMeter(*pRegistrationSpec->m_pidMeter);

	// A list of valid responses
	CStringArray as;
	StringAsStringArray(pRegistrationSpec->m_pcszValidResponses, as);
	SetValidResponses(as);
}

int CIuRegistrationSpec::GetCount()
{
	return CIuRegistrationSpecDft::GetCount();
}

void CIuRegistrationSpec::GetValidResponses(CStringArray& as) const
{
	as.Copy(m_asValidResponses);
}

void CIuRegistrationSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuRegistrationSpec::SetFaxPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFaxPhone = pcsz;
}

void CIuRegistrationSpec::SetMailAddress(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMailAddress = pcsz;
}

void CIuRegistrationSpec::SetMaxRuns(int iMaxRuns)
{
	m_iMaxRuns = iMaxRuns;
}

void CIuRegistrationSpec::SetMeter(const CIuID& idMeter)
{
	m_idMeter = idMeter;	
}

void CIuRegistrationSpec::SetModemPhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhone = pcsz;
}

void CIuRegistrationSpec::SetModemPhoneAreaCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhoneAreaCode = pcsz;
}

void CIuRegistrationSpec::SetModemPhoneCountryCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sModemPhoneCountryCode = pcsz;
}

void CIuRegistrationSpec::SetProductID(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sProductID = pcsz;
}

void CIuRegistrationSpec::SetProductName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sProductName = pcsz;
}

void CIuRegistrationSpec::SetRegistrationNo(int iRegistrationNo)
{
	m_iRegistrationNo = iRegistrationNo;
}


void CIuRegistrationSpec::SetURL(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sURL = pcsz;
}

void CIuRegistrationSpec::SetValidResponses(const CStringArray& as)
{
	m_asValidResponses.Copy(as);
}

void CIuRegistrationSpec::SetVoicePhone(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sVoicePhone = pcsz;
}
