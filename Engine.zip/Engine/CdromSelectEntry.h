#ifndef _ENGINE_CDROMSELECTENTRY_H_
#define _ENGINE_CDROMSELECTENTRY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromSelectEntry }}

class CIuCdromSelectEntry 
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromSelectEntry();
	CIuCdromSelectEntry(HTREEITEM Item, LPCTSTR pcszApplication = 0, LPCTSTR pcszRelease = 0, LPCTSTR pcszGroup = 0, LPCTSTR pcszProduct = 0, int iSpec = -1);
	CIuCdromSelectEntry(const CIuCdromSelectEntry&);
	virtual ~CIuCdromSelectEntry();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetApplication() const;
	CString GetGroup() const;
	HTREEITEM GetItem() const;
	CString GetProduct() const;
	CString GetRelease() const;
	int GetSpecNo() const;
	bool IsChecked() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetApplication(LPCTSTR);
	void SetChecked(bool);
	void SetGroup(LPCTSTR);
	void SetItem(HTREEITEM Item);
	void SetProduct(LPCTSTR);
	void SetRelease(LPCTSTR);
	void SetSpecNo(int iSpecNo);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuCdromSelectEntry& operator=(const CIuCdromSelectEntry&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sApplication;
	CString m_sRelease;
	CString m_sGroup;
	CString m_sProduct;
	int m_iSpecNo;
	HTREEITEM m_Item;
	bool m_fChecked;
//}}Data

};

typedef CArray<CIuCdromSelectEntry, CIuCdromSelectEntry&> CIuCdromSelectEntryArray;

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuCdromSelectEntry::GetApplication() const
{
	return m_sApplication;
}

inline CString CIuCdromSelectEntry::GetGroup() const
{
	return m_sGroup;
}

inline HTREEITEM CIuCdromSelectEntry::GetItem() const
{
	return m_Item;
}

inline CString CIuCdromSelectEntry::GetProduct() const
{
	return m_sProduct;
}

inline CString CIuCdromSelectEntry::GetRelease() const
{
	return m_sRelease;
}

inline int CIuCdromSelectEntry::GetSpecNo() const
{
	return m_iSpecNo;
}

inline bool CIuCdromSelectEntry::IsChecked() const
{
	return m_fChecked;
}

#endif // _ENGINE_CDROMSELECTENTRY_H_
