#ifndef _ENGINE_DATABASE_H_ 
#define _ENGINE_DATABASE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_FONT_H_
#	include "Interop\Font.h"
#endif	// _INTEROP_FONT_H_
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuDatabase)
IU_DEFINE_OBJECT_PTR(CIuIndexes)
IU_DEFINE_OBJECT_PTR(CIuUserInterface)
IU_DEFINE_OBJECT_PTR(CIuSplash)
class CIuMeter;
class CIuDatabases;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuDatabase, CIuCollectable }}
#define CIuDatabase_super CIuCollectable

class IU_CLASS_EXPORT CIuDatabase : public CIuDatabase_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuDatabase)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuDatabase();           
	virtual ~CIuDatabase();
	CIuDatabase(const CIuDatabase&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetApplication() const;
	CString GetCopyright() const;
	COleDateTime GetCreated() const;
	CIuDatabases& GetDatabases() const;
	CString GetFilename() const;
	CString GetFormat() const;
	int GetGroupCount() const;
	int GetGroupNo() const;
	CIuIndexes& GetIndexes() const;
	CIuMeter& GetMeter() const;
	CIuMoniker GetMeterMoniker() const;
	CIuMoniker GetSplash() const;
	CIuObjectRepository& GetObjectRepository() const;
	CString GetOptions() const;
	CString GetRelease() const;
	CIuSplashPtr GetSplashPtr() const;
	void GetStates(CStringArray& as) const;
	CString GetUserInterface() const;
	CIuUserInterfacePtr GetUserInterfacePtr() const;
	CIuVersionNumber GetVersionCurrent() const;
	static CIuVersionNumber GetVersionCurrentStatic();
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasDatabases() const;
	bool HasMeter() const;
	bool HasObjectRepository() const;
	bool IsCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	bool CheckAccessCode(CWnd* pParent = 0);
	bool CheckAcknowledge(CWnd* pParent = 0);
	bool CheckCdOnly(CWnd* pParent = 0);
	bool CheckCorrupt(CWnd* pParent = 0);
	bool CheckExpired(CWnd* pParent = 0);
	bool CheckVersion(CIuVersionNumber version, bool fShowDlg = true, CWnd* pParent = 0);
	bool CheckWarning(CWnd* pParent = 0);
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void Delete(CIuOutput* pOutput = 0);
	void SetApplication(LPCTSTR);
	void SetCopyright(LPCTSTR pcsz);
	void SetCreated(const COleDateTime&);
	void SetFilename(LPCTSTR);
	void SetFormat(LPCTSTR);
	void SetGroupCount(int iGroupCount);
	void SetGroupNo(int iGroupNo);
	void SetMeterMoniker(const CIuMoniker&);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetOptions(LPCTSTR);
	void SetRelease(LPCTSTR);
	void SetSpec(CIuCdromSpec& Spec);
	void SetSplash(const CIuMoniker&);
	void SetStates(const CStringArray&);
	void SetUserInterface(LPCTSTR);
	void SetVersionCurrent(CIuVersionNumber);
	void ShowStates(CWnd* pParent);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuDatabase& operator=(const CIuDatabase&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetIndexes_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	CIuIndexesPtr m_pIndexes;
private:
	CString m_sCopyright;
	CString m_sRelease;
	CString m_sUserInterface;
	CString m_sApplication;
	CString m_sOptions;
	CString m_sFormat;
	CIuMoniker m_monikerMeterMoniker;
	CIuMoniker m_monikerSplash;
	COleDateTime m_dtCreated;
	// Store the perferred filename in case network admin wants to copy the file.
	CString m_sFilename;
	// If a database belongs to a group of related databases (for instance,
	//	a six cd set covering the US) then this variable indicate the size and
	// position of this database within the group.
	int m_iGroupNo;
	int m_iGroupCount;
	CIuVersionNumber m_verVersionCurrent;
	// A list of state names in this database
	CStringArray m_asStates;
	// Owning object repository
	CIuObjectRepository* m_pObjectRepository;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CString CIuDatabase::GetApplication() const
{
	return m_sApplication;
}

inline CString CIuDatabase::GetCopyright() const
{
	return m_sCopyright;
}

inline COleDateTime CIuDatabase::GetCreated() const
{
	return m_dtCreated;
}

inline CString CIuDatabase::GetFilename() const
{
	return m_sFilename;
}

inline CString CIuDatabase::GetFormat() const
{
	return m_sFormat;
}

inline CIuMoniker CIuDatabase::GetMeterMoniker() const
{
	return m_monikerMeterMoniker;
}

inline CIuObjectRepository& CIuDatabase::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CString CIuDatabase::GetOptions() const
{
	return m_sOptions;
}

inline CString CIuDatabase::GetRelease() const
{
	return m_sRelease;
}

inline CIuMoniker CIuDatabase::GetSplash() const
{
	return m_monikerSplash;
}

inline CIuVersionNumber CIuDatabase::GetVersionCurrent() const
{
	return m_verVersionCurrent;
}

inline bool CIuDatabase::HasDatabases() const
{
	return HasCollection();
}

inline bool CIuDatabase::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

#endif
