#include "StdAfx.h"
//{{Include
#include "GeoRawMsa.h"
#include "GeoRawInstance.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawMsa, CIuGeoRawMsa_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawMsa)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWMSA, CIuGeoRawMsa, CIuGeoRawMsa_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawMsa, IDS_ENGINE_PROP_STATE, GetState_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawMsa, IDS_ENGINE_PROP_STATE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawMsa, IDS_ENGINE_PROP_ZIPS, GetZips_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawMsa, IDS_ENGINE_PROP_ZIPS, editorUsePropName)

	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawMsa, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawMsa, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_GEORAWELEMENT, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawMsa::CIuGeoRawMsa() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoRawMsa::~CIuGeoRawMsa()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawMsa::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput&)
{
	GetState().Add(Instance.GetStateAbbr());
	GetZips().Add(Instance.GetZip());
	CIuGeoRawMsa_super::Another();
}

CIuObject* CIuGeoRawMsa::GetState_() const
{
	return &m_State;
}

CIuObject* CIuGeoRawMsa::GetZips_() const
{
	return &m_Zips;
}

void CIuGeoRawMsa::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_sTitle;
	}
	else
	{
		ar >> m_sTitle;
	}
	GetState().Serialize(ar);
	GetZips().Serialize(ar);
	CIuGeoRawMsa_super::Serialize(ar);
}

void CIuGeoRawMsa::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}
