#ifndef _ENGINE_INPUTRESIDENTIAL_H_
#define _ENGINE_INPUTRESIDENTIAL_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTFIXED_H_
#	include "Engine\InputFixed.h"
#endif	// _ENGINE_INPUTFIXED_H_
#ifndef 	_ENGINE_ADDRESSCODEC_H_
#	include "Engine\AddressCodec.h"
#endif	// _ENGINE_ADDRESSCODEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputResidential)
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputResidential, CIuInputFixed }}
#define CIuInputResidential_super CIuInputFixed

class CIuInputResidential : public CIuInputResidential_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputResidential)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputResidential();
	virtual ~CIuInputResidential();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool NoNoSolicit() const;
	bool NoSpouse() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetNoNoSolicit(bool);
	void SetNoSpouse(bool);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	bool OnOpen(CIuOpenSpec& OpenSpec);
	bool OnProcess();
	bool OnProcessNoSolicit();
	bool OnProcessPrimary();
	bool OnProcessSpouse();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Should spouse records be discarded?
	bool m_fNoSpouse;
	// Exclude non-solicit records
	bool m_fNoNoSolicit;
	// A temporary string accumulator
	CString m_sTemp;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuInputResidential::NoNoSolicit() const
{
	return m_fNoNoSolicit;
}

inline bool CIuInputResidential::NoSpouse() const
{
	return m_fNoSpouse;
}

#endif // _ENGINE_INPUTRESIDENTIAL_H_
