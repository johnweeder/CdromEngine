#ifndef _ENGINE_EXPRESSIONFUNCTIONDEMOGRAPHICS_H_
#define _ENGINE_EXPRESSIONFUNCTIONDEMOGRAPHICS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONFUNCTION_H_
#	include "Engine\ExpressionFunction.h"
#endif	// _ENGINE_EXPRESSIONFUNCTION_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionFunctionDemographics, CIuExpressionFunction }}
#define CIuExpressionFunctionDemographics_super CIuExpressionFunction

class CIuExpressionFunctionDemographics : public CIuExpressionFunction
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionFunctionDemographics(CIuExpressionType Type = exprFunction);
	CIuExpressionFunctionDemographics(const CIuExpressionFunctionDemographics& rExpressionElement);
	virtual ~CIuExpressionFunctionDemographics();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static const CIuExpressionFunctionDef* GetFunctionDefs();
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	static CIuExpressionFunction* Create();
	virtual CIuExpressionElement* Optimize();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionFunctionDemographics& operator=(const CIuExpressionFunctionDemographics& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	LPCTSTR AdSizeName(const CIuRecord* pRecord) const;
	int AdSizeNameMaxLength() const;
	LPCTSTR EmployeeSizeName(const CIuRecord* pRecord) const;
	int EmployeeSizeNameMaxLength() const;
	LPCTSTR SalesVolumeName(const CIuRecord* pRecord) const;
	int SalesVolumeNameMaxLength() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONFUNCTIONDEMOGRAPHICS_H_
