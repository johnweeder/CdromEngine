#include "StdAfx.h"
//{{Include
#include "Input.h"
#include "resource.h"
#include "CdromSpec.h"
#include "OpenSpec.h"
#include "Data\DataFilename.h"
#include "Error\Error.h"
#include "Miscellaneous.h"
#include "..\Version.h"
#include "RecordPtr.h"
#include "StatesRaw.h"
#include "ParseName.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuInput, CIuInput_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInput)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUT, CIuInput, CIuInput_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInput, IDS_ENGINE_PPG_INPUT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuInput, IDS_ENGINE_PROP_APPEND, ShouldAppend, SetAppend, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuInput, IDS_ENGINE_PROP_APPEND, IDS_ENGINE_PPG_INPUT, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuInput, IDS_ENGINE_PROP_MAXRECORDS, GetMaxRecords, SetMaxRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuInput, IDS_ENGINE_PROP_MAXRECORDS, IDS_ENGINE_PPG_INPUT, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuInput, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuInput, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_INPUT, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuInput, IDS_ENGINE_PROP_INPUTFILENAME, GetInputFilename, SetInputFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuInput, IDS_ENGINE_PROP_INPUTFILENAME, IDS_ENGINE_PPG_INPUT, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuInput, IDS_ENGINE_PROP_OUTPUTFILENAME, GetOutputFilename, SetOutputFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuInput, IDS_ENGINE_PROP_OUTPUTFILENAME, IDS_ENGINE_PPG_INPUT, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuInput, IDS_ENGINE_PROP_FORMAT, GetFormat, SetFormat, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuInput, IDS_ENGINE_PROP_FORMAT, IDS_ENGINE_PPG_INPUT, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Fields

struct CIuInputFieldDef
{
	CIuInputField m_Field;
	LPCTSTR m_pcszField;
};

static const CIuInputFieldDef aInputFieldDefs[] =
{
	{ inputFieldAcPhone,					"AcPhone"				},
   { inputFieldAdSizeCode,				"AdSizeCode"			},
   { inputFieldAreaCode,				"AreaCode"				},
   { inputFieldAreaCodeName,        "AreaCodeName"			},
   { inputFieldAlt,						"Alt"						},
   { inputFieldBusResFlag,				"BusResFlag"			},
   { inputFieldCity,						"City"					},
   { inputFieldContact,					"Contact"				},
   { inputFieldCountyCode,				"CountyCode"			},
   { inputFieldCountyName,				"CountyName"			},
   { inputFieldEmployeeSizeCode,		"EmployeeSizeCode"	},
   { inputFieldExchange,				"Exchange"				},
   { inputFieldExchangeName,			"ExchangeName"			},
   { inputFieldFaxAcPhone,				"FaxAcPhone"			},
   { inputFieldFirstYear,				"FirstYear"				},
   { inputFieldFranchiseCode,			"FranchiseCode"		},
   { inputFieldFranchiseName,			"FranchiseName"		},
   { inputFieldGender,					"Gender"					},
   { inputFieldLatitude,				"Latitude"				},
   { inputFieldLongitude,				"Longitude"				},
   { inputFieldMatchLevel,				"MatchLevel"			},
   { inputFieldMedianHomeValue,		"MedianHomeValue"		},
   { inputFieldMedianIncome,			"MedianIncome"			},
   { inputFieldMsaCode,					"MsaCode"				},
   { inputFieldMsaName,					"MsaName"				},
   { inputFieldName,						"Name"					},
   { inputFieldNoSolicitation,		"NoSolicitation"		},
   { inputFieldPostDir,					"PostDir"				},
   { inputFieldPreDir,					"PreDir"					},
   { inputFieldPriNo,					"PriNo"					},
   { inputFieldPubDate,					"PubDate"				},
   { inputFieldSalesVolumeCode,		"SalesVolumeCode"		},
   { inputFieldSeeAlso,					"SeeAlso"				},
   { inputFieldSicCode,					"SicCode"				},
   { inputFieldSicName,					"SicName"				},
   { inputFieldSicPreferred,			"SicPreferred"			},
   { inputFieldSecNo,					"SecNo"					},
   { inputFieldStateCode,				"StateCode"				},
   { inputFieldStreet,					"Street"					},
   { inputFieldStreetName,				"StreetName"			},
   { inputFieldSuffix,					"Suffix"					},
   { inputFieldTollFreeAcPhone,		"TollFreeAcPhone"		},
   { inputFieldToken,					"Token"					},
   { inputFieldZIP,						"ZIP"						},
	/* End of List */
   { inputFieldNone }
};

/////////////////////////////////////////////////////////////////////////////
// Formats

#pragma warning(disable: 4200)
struct CIuInputFormatDef
{
	LPCTSTR m_pcszFormat;
	CIuInputFormat m_Format;
	CIuInputField m_aFields[];
};
#pragma warning(default: 4200)

static const CIuInputFormatDef InputFormatAreaCode =
{
	_T("AreaCode"), inputAreaCode,
	{
		inputFieldAreaCode,
		inputFieldAreaCodeName,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatAlt =
{
	_T("Alt"), inputAlt,
	{
		inputFieldAlt,
		inputFieldSeeAlso,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatCensus =
{
	_T("Census"), inputCensus,
	{
		inputFieldZIP,
		inputFieldMedianIncome,
		inputFieldMedianHomeValue,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatCounty =
{
	_T("County"), inputCounty,
	{
		inputFieldCountyCode,
		inputFieldCountyName,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatExchange =
{
	_T("Exchange"), inputExchange,
	{
		inputFieldExchange,
		inputFieldExchangeName,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatFranchise =
{
	_T("Franchise"), inputFranchise,
	{
		inputFieldSicCode,
		inputFieldFranchiseCode,
		inputFieldFranchiseName,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatMsa =
{
	_T("Msa"), inputMsa,
	{
		inputFieldMsaCode,
		inputFieldMsaName,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatSic =
{
	_T("Sic"), inputSic,
	{
		inputFieldSicCode,
		inputFieldSicName,
		inputFieldSicPreferred,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatSicSeeAlso =
{
	_T("SicSeeAlso"), inputSicSeeAlso,
	{
		inputFieldSicCode,
		inputFieldSeeAlso,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatStandard =
{
	_T("Standard"), inputStandard,
	{
		inputFieldName,
		inputFieldCity,
		inputFieldStateCode,
		inputFieldZIP,
		inputFieldAcPhone,
		inputFieldPriNo,                 
		inputFieldPreDir,                  
		inputFieldStreetName,                  
		inputFieldSuffix,                  
		inputFieldPostDir,
		inputFieldSecNo,                    
		inputFieldAdSizeCode,
		inputFieldBusResFlag,        
		inputFieldContact,
		inputFieldCountyCode,           
		inputFieldEmployeeSizeCode,        
		inputFieldFaxAcPhone,
		inputFieldFirstYear,
		inputFieldFranchiseCode,
		inputFieldGender,
		inputFieldLatitude,
		inputFieldLongitude,
		inputFieldMatchLevel,
		inputFieldMsaCode,
		inputFieldNoSolicitation,
		inputFieldPubDate,
		inputFieldSalesVolumeCode,         
		inputFieldSicCode,
		inputFieldStreet,
		inputFieldTollFreeAcPhone,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatToken =
{
	_T("Token"), inputToken,
	{
		inputFieldToken,
		inputFieldSeeAlso,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef InputFormatZipCentroid =
{
	_T("ZipCentroid"), inputZipCentroid,
	{
		inputFieldZIP,
		inputFieldLatitude, 
		inputFieldLongitude,
		/* End of List */
		inputFieldNone
	}
};

static const CIuInputFormatDef* apInputFormatDefs[] =
{
	&InputFormatAreaCode,
	&InputFormatAlt,
	&InputFormatCensus,
	&InputFormatCounty,
	&InputFormatExchange,
	&InputFormatFranchise,
	&InputFormatMsa,
	&InputFormatSic,
	&InputFormatSicSeeAlso,
	&InputFormatStandard,
	&InputFormatToken,
	&InputFormatZipCentroid,
	/* End of List */
	0
};

/////////////////////////////////////////////////////////////////////////////
// Constructor/Destructor

CIuInput::CIuInput() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInput::~CIuInput()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuInput::Build(CIuOutput& Output, CIuFlags Flags)
{
	SetOutput(&Output);

	ASSERT(!GetName().IsEmpty());

	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);

	// Output description, set range, etc
	if (!GetOutput().Fire())
		return false;

	// Display a title
	GetOutput().OutputF("%s %s\n", LPCTSTR(GetName()), LPCTSTR(GetFullInputFilename()));
	if (!GetOutput().Fire())
		return false;

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	// Process the input
	IU_TRY_ERROR
	{
		// Open the target
		GetOutput().SetMessageF("Opening");
		GetOutput().Fire();
		CIuOpenSpec OpenSpec;
		OpenSpec.m_pOutput = &GetOutput();
		CIuOptions Options =  GetOptions();
		OpenSpec.m_pOptions = &Options;
		if (!OnOpen(OpenSpec))
			return false;

		bool fResult = Input(Flags);

		// Done (always close)
		GetOutput().SetMessageF("Closing");
		GetOutput().Fire();
		OnClose();

		if (!fResult)
			return false;

		GetOutput().OutputF("Input %ld records\n", GetRecords());
	}
	IU_CATCH_ERROR(e)
	{
		OnClose();
		throw e;	
	}

	// Display elapsed time
	instance.Pop(true);

	return true;
}

void CIuInput::ClearFields()
{
	// Empty buffer. First byte is always a null and all of the fields
	//	 initially point to this!
	m_FieldBuffer.SetSize(1);
	ASSERT(*m_FieldBuffer.GetPtr(0) == 0);
	// Clear the field pointers
	memset(m_aiFieldOffset, 0, sizeof(m_aiFieldOffset));
	memset(m_aiFieldLength, 0, sizeof(m_aiFieldLength));
}

void CIuInput::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("InputRaw"));
	m_fAppend = false;
	m_iMaxRecords = -1;
	m_sOptions = "";
	m_sInputFilename = "";
	m_sOutputFilename = "";
	m_pOutput = 0;
	SetVersion(IU_VERSION);
	m_FieldBuffer.SetGrowBy(4096);
	m_FieldBuffer.Append((BYTE)0);
	ClearFields();
	m_iFormat = inputNone;
	m_iRecords = 0;
	//}}Initialize

#ifdef _DEBUG
	{
		// Just to make internal access fast, we make sure the offsets within the tables
		// match the enumerations.
		for (int i = 0; aInputFieldDefs[i].m_Field != inputFieldNone; ++i)
		{
			ASSERT(aInputFieldDefs[i].m_Field == CIuInputField(i));
		}
		for (i = 0; apInputFormatDefs[i]; ++i)
		{
			ASSERT(apInputFormatDefs[i]->m_Format == CIuInputFormat(i));
		}
	}
#endif
}

void CIuInput::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullOutputFilename(), pOutput);
}

LPCTSTR CIuInput::GetField(int iField) const
{
	ASSERT(iField >= inputFieldFirst && iField < inputFieldMax);
	LPCTSTR pcsz = LPCTSTR(m_FieldBuffer.GetPtr(m_aiFieldOffset[iField]));
	ASSERT(pcsz);
	ASSERT(pcsz[m_aiFieldLength[iField]] == 0);
	return pcsz;
}

CIuFilename CIuInput::GetFullInputFilename() const
{
	CIuFilename Filename = IuDataFilenameSearch(GetInputFilename(), "");
	return Filename;
}

CIuFilename CIuInput::GetFullOutputFilename() const
{
	CIuFilename Filename = IuDataFilenameSearch(GetOutputFilename(), "");
	return Filename;
}

void CIuInput::GetRecord(CIuRecordPtr& pRecord) const
{
	GetRecordSpec(m_RecordSpec);
	pRecord.Create(m_RecordSpec);
}

CIuRecordDefPtr CIuInput::GetRecordDef(int iFormat)
{
	CIuRecordDefPtr pRecordDef;
	pRecordDef.Create();

	ASSERT(iFormat >= inputFirst && iFormat < inputMax);
	const CIuInputFormatDef*  pInputFormatDef = apInputFormatDefs[iFormat];
	ASSERT(pInputFormatDef);
	ASSERT(pInputFormatDef->m_Format == iFormat);
	for (int i = 0; pInputFormatDef->m_aFields[i] != inputFieldNone; ++i)
	{
		int iField = pInputFormatDef->m_aFields[i];
		ASSERT(aInputFieldDefs[iField].m_Field == iField);
		LPCTSTR pcszField = aInputFieldDefs[iField].m_pcszField;
		pRecordDef->AddFieldDef(pcszField);
	}
	return pRecordDef;
}

CIuRecordDefPtr CIuInput::GetRecordDef() const
{
	return GetRecordDef(GetFormat());
}

void CIuInput::GetRecordSpec(CIuRecordSpec& RecordSpec) const
{
	RecordSpec.Clear();

	ASSERT(m_iFormat >= inputFirst && m_iFormat < inputMax);
	const CIuInputFormatDef*  pInputFormatDef = apInputFormatDefs[m_iFormat];
	ASSERT(pInputFormatDef);
	ASSERT(pInputFormatDef->m_Format == m_iFormat);

	for (int i = 0; pInputFormatDef->m_aFields[i] != inputFieldNone; ++i)
	{
		int iField = pInputFormatDef->m_aFields[i];
		ASSERT(aInputFieldDefs[iField].m_Field == iField);

		int iOffset = m_aiFieldOffset[iField];
		const BYTE* pb = m_FieldBuffer.GetPtr(iOffset);
		int iLength = m_aiFieldLength[iField];

		RecordSpec.Add(pb, iLength);
	}

	RecordSpec.SetRecordNo(GetRecords());
}

int CIuInput::GetRecords() const
{
	return m_iRecords;
}

bool CIuInput::Input(CIuFlags Flags)
{
	// NOTE: A common side effect of the open command is to set the
	// message line that should be used for the remainder of the processing.
	int iRange = OnGetRange();

	int iMaxRecords = GetMaxRecords() < 0 ? 0x7FFFFFFF: GetMaxRecords();

	int iNoise = (min(iMaxRecords, iRange) + 99) / 100;
	iNoise = min(iNoise, 1000000);
	if (iNoise == 0)
		iNoise = 10000;

	// Get a record count and start
	GetOutput().SetPosition(0);
	GetOutput().SetRange(min(iMaxRecords, iRange));
	GetOutput().Fire();

	// Reset the initial output record count
	m_iRecords = 0;
	if (!OnMoveFirst())
		return false;
	// Process the records
	// NOTE: MoveNext does not always advance a single record. Therefore,
	//			we play some games to keep the progress bar moving.
	int iPreviousRecords = 0;
	int iCurrentNoise = 0;
	int iNextNoise = 0;
	for (; OnMoveNext(); )
	{
		int iRecords = GetRecords();
		if (iRecords >= iMaxRecords)
			break;
		if (iRecords > iPreviousRecords)
		{
			iCurrentNoise += iRecords - iPreviousRecords;
			iPreviousRecords = iRecords;
		}
		else
			++iCurrentNoise;
		if (iCurrentNoise >= iNextNoise)
		{
			iNextNoise = iCurrentNoise + iNoise;
			GetOutput().SetPosition(GetRecords());
			GetOutput().SetRange(min(iMaxRecords, iRange));
			if (!GetOutput().Fire(iRange <= 0 ? IU_EVENT_OPERATION_CONTINUE: IU_EVENT_OPERATION_PROGRESS))
				return false;
		}
	}
	return true;
}

void CIuInput::MakeAddress(LPCTSTR pcszPriNo, LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir, LPCTSTR pcszSecNo, LPCTSTR pcszHighRise, LPCTSTR pcszNoSolicitation)
{
	if (!m_Codec.Process(pcszPriNo, pcszPreDir, pcszStreetName, pcszSuffix, pcszPostDir, pcszSecNo, pcszHighRise, pcszNoSolicitation))
		Error(IU_E_INPUT_FAILURE, _T("Address parsing failed."));

	SetField(inputFieldPriNo,			m_Codec.GetPriNo());
	SetField(inputFieldPreDir,			m_Codec.GetPreDir());
	SetField(inputFieldStreetName,	m_Codec.GetStreetName());
	SetField(inputFieldSuffix,			m_Codec.GetSuffix());
	SetField(inputFieldPostDir,		m_Codec.GetPostDir());
	SetField(inputFieldSecNo,			m_Codec.GetSecNo());
	SetField(inputFieldStreet,			m_Codec.GetStreet());
}

void CIuInput::MakeName(int iField, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMI, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle)
{
	::MakeName(m_sTemp, makeNameLastFirst, pcszLast, pcszFirst, pcszMI, pcszGen, pcszProSuffix, pcszTitle);
	SetField(iField, m_sTemp);
	// Do not allow comma at end... it screws up the PF see-also logic
	ASSERT(m_sTemp.IsEmpty() || m_sTemp.GetAt(m_sTemp.GetLength() - 1) != ',');
}

void CIuInput::MakeNameInitials(int iField, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMI, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle)
{
	::MakeName(m_sTemp, makeNameLastFirst, pcszLast, pcszFirst, pcszMI, pcszGen, pcszProSuffix, pcszTitle, makeNameInitialsOnly);
	SetField(iField, m_sTemp);
	// Do not allow comma at end... it screws up the PF see-also logic
	ASSERT(m_sTemp.IsEmpty() || m_sTemp.GetAt(m_sTemp.GetLength() - 1) != ',');
}

void CIuInput::MakePhone(int iField, LPCTSTR pcszAreaCode, LPCTSTR pcszPhone)
{
	// Only sets valid phones. Otherwise, ignores input
	if (*pcszPhone == 0)
		return ;
	if (_tcsicmp(pcszPhone, "0001111") == 0)
		return ;
	m_sTemp = pcszAreaCode;
	m_sTemp += pcszPhone;
	if (m_sTemp.GetLength() != 10)
		return ;
	if (m_sTemp.Compare(_T("0000000000")) == 0)
		return ;
	SetField(iField, m_sTemp);
}

void CIuInput::MakeState(LPCTSTR pcszState)
{
	const CIuStatesRaw* pState = CIuStatesRaw::FindMaster(pcszState);
	ASSERT(pState);
	if (pState)
		SetField(inputFieldStateCode, pState->m_pcszCode);
}

void CIuInput::MakeZip(LPCTSTR pcszZip5, LPCTSTR pcszAddon, LPCTSTR pcszDPBC)
{
	ASSERT(pcszZip5);
	m_sTemp = pcszZip5;
	ASSERT(m_sTemp.GetLength() == 5 || m_sTemp.GetLength() == 9 || m_sTemp.GetLength() == 11 || m_sTemp.GetLength() == 12);
	if (pcszAddon && *pcszAddon)
	{
		m_sTemp += pcszAddon;
		ASSERT(m_sTemp.GetLength() == 9);
		if (pcszDPBC && *pcszDPBC)
		{
			m_sTemp += pcszDPBC;
			ASSERT(m_sTemp.GetLength() == 11 || m_sTemp.GetLength() == 12);
		}
	}
	SetField(inputFieldZIP, m_sTemp);
}

void CIuInput::OnClose()
{
	ClearFields();
	m_FieldBuffer.Destroy();
}

int CIuInput::OnGetRange()
{
	// Return -1 to indicate range is not known
	// Used to indicate position of status bar....
	return -1;
}

bool CIuInput::OnMoveFirst()
{
	return true;
}

bool CIuInput::OnMoveNext()
{
	ASSERT(false);
	return false;
}

bool CIuInput::OnOpen(CIuOpenSpec&)
{
	return true;
}

bool CIuInput::OnProcess()
{
	// OnProcess() is usually called from within OnMoveNext().
	// Sometime, it is called multiple time (for example, if a record
	//	 has a primary and spouse component).
	// The default processing is to output the record
	return Output();
}

bool CIuInput::OnOutput()
{
	++m_iRecords;
	return true;
}

bool CIuInput::Output()
{
	int iMaxRecords = GetMaxRecords() < 0 ? 0x7FFFFFFF: GetMaxRecords();
	if (GetRecords() >= iMaxRecords)
		return true;

	return OnOutput();
}

bool CIuInput::Process()
{
	ClearFields();
	return OnProcess();
}

void CIuInput::SetAppend(bool f)
{
	m_fAppend = f;
}

void CIuInput::SetField(int iField, LPCTSTR pcsz)
{
	ASSERT(iField >= inputFieldFirst && iField < inputFieldMax);
	if (pcsz == 0)
	{
		m_aiFieldOffset[iField] = 0;
		m_aiFieldLength[iField] = 0;
	}
	else
	{
		int iLength = _tcslen(pcsz);
		m_aiFieldOffset[iField] = m_FieldBuffer.GetSize();
		m_aiFieldLength[iField] = iLength;
		m_FieldBuffer.Append((const BYTE*)pcsz, iLength + 1);
	}
}

void CIuInput::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	SetInputFilename(pcsz);
	SetOutputFilename(pcsz);
}

void CIuInput::SetFormat(int iFormat)
{
	m_iFormat = iFormat;
}

void CIuInput::SetInputFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sInputFilename = pcsz;
}

void CIuInput::SetMaxRecords(int iMaxRecords)
{
	m_iMaxRecords = iMaxRecords;
}

void CIuInput::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuInput::SetOutput(CIuOutput* pOutput)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pOutput != 0);
	m_pOutput = pOutput;
}

void CIuInput::SetOutputFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOutputFilename = pcsz;
}

void CIuInput::SetSpec(CIuCdromSpec& Spec)
{
	SetName(Spec.GetName());
	SetFormat(inputStandard);
	SetMaxRecords(Spec.GetMaxRecords());
	SetOutputFilename(Spec.GetFilename());
	SetOptions(Spec.GetOptions());
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(Input, pv) 
{
	// To run this test, execute "test Input" in the console.
	// NOTE: You need to select your own name if you copy this code.
	UNUSED_ALWAYS(pv);
	// This code auto-generates the enumerations in the header files
	// Run this test and then cut/copy/paste the results from the output
	//	 window into the header file.

	static TCHAR szSeparator[] = _T("/////////////////////////////////////////////////////////////////////////////\n");
	static TCHAR szAutoGenerate[] = _T("// *** Auto-Generated ***\n");

	TRACE("\n\n");

	TRACE(szSeparator);
	TRACE("// Input Field Specifiers\n");
	TRACE(szAutoGenerate);
	TRACE("enum CIuInputField\n");
	TRACE("{\n");
	TRACE("\tinputFieldNone = -1,\n");
	TRACE("\tinputFieldFirst = 0,\n");
	for (int i = 0; aInputFieldDefs[i].m_Field != inputFieldNone; ++i)
	{
		ASSERT(aInputFieldDefs[i].m_Field == i);
		TRACE("\t\tinputField%s", aInputFieldDefs[i].m_pcszField);
		if (i == 0)
			TRACE(" = inputFieldFirst");
		TRACE(",\n");
	}
	TRACE("\tinputFieldMax,\n");
	TRACE("};\n");
	TRACE(szAutoGenerate);
	TRACE("\n");

	TRACE(szSeparator);
	TRACE("// Input Formats\n");
	TRACE(szAutoGenerate);
	TRACE("enum CIuInputFormat\n");
	TRACE("{\n");
	TRACE("\tinputNone = -1,\n");
	TRACE("\tinputFirst = 0,\n");
	for (i = 0; apInputFormatDefs[i]; ++i)
	{
		const CIuInputFormatDef* pFormat = apInputFormatDefs[i];
		ASSERT(pFormat);
		ASSERT(pFormat->m_Format == i);
		TRACE("\t\tinput%s", pFormat->m_pcszFormat);
		if (i == 0)
			TRACE(" = inputFirst");
		TRACE(",\n");
	}
	TRACE("\tinputMax,\n");
	TRACE("};\n");
	TRACE(szAutoGenerate);
	TRACE("\n");

	for (i = 0; apInputFormatDefs[i]; ++i)
	{
		const CIuInputFormatDef* pFormat = apInputFormatDefs[i];

		TRACE(szSeparator);
		TRACE("// %s Input Format\n", pFormat->m_pcszFormat);
		TRACE(szAutoGenerate);
		TRACE("enum CIuInputFormat%s\n", pFormat->m_pcszFormat);
		TRACE("{\n");
		TRACE("\tinput%sFirst = 0,\n", pFormat->m_pcszFormat);

		for (int j = 0; pFormat->m_aFields[j] != inputFieldNone; ++j)
		{
			int iField = pFormat->m_aFields[j];
			ASSERT(aInputFieldDefs[iField].m_Field == iField);
			LPCTSTR pcszField = aInputFieldDefs[iField].m_pcszField;
			TRACE("\t\tinput%s%s", pFormat->m_pcszFormat, pcszField);
			if (j == 0)
				TRACE(" = input%sFirst", pFormat->m_pcszFormat);
			TRACE(",\n");
		}

		TRACE("\tinput%sMax,\n", pFormat->m_pcszFormat);
		TRACE("};\n");
		TRACE(szAutoGenerate);
		TRACE("\n");
	}

	TRACE("\n\n");

	return 0;
}
IU_TEST_END()
#endif
