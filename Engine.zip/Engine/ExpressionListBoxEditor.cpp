#include "StdAfx.h"
//{{Include
#include "ExpressionListBoxEditor.h"
#include "ExpressionBuilderDlg.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////////////
// CIuListBoxFileEditor implementation

bool CIuExpressionListBoxEditor::Initialize(UINT uiID, CWnd* pwndParent, int iFlags)
{
	if (!CIuExpressionListBoxEditor_super::Initialize(uiID, pwndParent, iFlags))
		return false;
	return true;
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuExpressionListBoxEditor::OnAdd(int, CString& sValue)
{
	return CIuExpressionBuilderDlg::Edit(sValue, m_asAllowableValues, this);
}

bool CIuExpressionListBoxEditor::OnBrowse(int, CString& sValue, DWORD&)
{
	return CIuExpressionBuilderDlg::Edit(sValue, m_asAllowableValues, this);
}
