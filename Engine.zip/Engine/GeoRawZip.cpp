#include "StdAfx.h"
//{{Include
#include "GeoRawZip.h"
#include "GeoRawInstance.h"
#include "LatLongUnit.h"
#include "resource.h"
#include "Interop\Serialize.h"
#include "GeoConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawZip, CIuGeoRawZip_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawZip)
//#define SHOW_ZIP_WARNINGS
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWZIP, CIuGeoRawZip, CIuGeoRawZip_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_CITY, GetCity_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_STATE, GetState_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_MSA, GetMsa_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_AREACODE, GetAreaCode_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_PREFIX, GetPrefix_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDE, GetLatitudeAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDE, GetLongitudeAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_COUNTY, GetCounty_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID0, GetLatitudeCentroid0AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID1, GetLatitudeCentroid1AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID2, GetLatitudeCentroid2AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID0, GetLongitudeCentroid0AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID1, GetLongitudeCentroid1AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID2, GetLongitudeCentroid2AsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEAVERAGE, GetLongitudeAverageAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEAVERAGE, GetLatitudeAverageAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEMAX, GetLatitudeMaxAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEMIN, GetLatitudeMinAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEMIN, GetLongitudeMinAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEMAX, GetLongitudeMaxAsString, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoRawZip, IDS_ENGINE_PROP_MEDIANINCOME, GetMedianIncome, SetMedianIncome, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoRawZip, IDS_ENGINE_PROP_MEDIANHOMEVALUE, GetMedianHomeValue, SetMedianHomeValue, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_CITY, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_STATE, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_MSA, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_AREACODE, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_PREFIX, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawZip, IDS_ENGINE_PROP_COUNTY, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuGeoRawZip, IDS_ENGINE_PPG_GEORAWZIP, 50, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEMIN, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDE, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID0, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID1, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDECENTROID2, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEAVERAGE, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LATITUDEMAX, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEMIN, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDE, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID0, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID1, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDECENTROID2, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEAVERAGE, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawZip, IDS_ENGINE_PROP_LONGITUDEMAX, IDS_ENGINE_PPG_GEORAWZIP, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoRawZip, IDS_ENGINE_PROP_MEDIANINCOME, IDS_ENGINE_PPG_GEORAWZIP, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoRawZip, IDS_ENGINE_PROP_MEDIANHOMEVALUE, IDS_ENGINE_PPG_GEORAWZIP, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawZip::CIuGeoRawZip() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	//{{Initialize
	m_iLatitudeAccumulator = 0;
	m_iLatLongs = 0;
	m_iLongitudeAccumulator = 0;
	m_iMedianIncome = 0;
	m_iMedianHomeValue = 0;
	m_LatLongCentroid1Count = 0;
	m_LatLongCentroid2Count = 0;
	m_fNoCentroidMessage = true;
	m_fCentroidMisMatchMessage = true;
	m_fTooManyCentroidsMessage = true;
	//}}Initialize
}

CIuGeoRawZip::~CIuGeoRawZip()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawZip::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput& Output)
{
#ifndef SHOW_ZIP_WARNINGS
	UNUSED_ALWAYS(Output);
#endif
	GetCity().Add(Instance.GetStateCity());
	GetState().Add(Instance.GetStateAbbr());
	if (Instance.GetMsaCode() != 0)
		GetMsa().Add(Instance.GetMsaCode(), 4);
	if (Instance.GetCountyCode() != 0)
		GetCounty().Add(Instance.GetCountyCode(), 5);
	int iPhoneCount = Instance.GetPhoneCount();
	for (int iPhone = 0; iPhone < iPhoneCount; ++iPhone)
	{
		__int64 lAreaCode = Instance.GetAreaCode(iPhone);
		if (lAreaCode != 0)
			GetAreaCode().Add(lAreaCode, 3);
		__int64 lPrefix = Instance.GetPrefix(iPhone);
		if (lPrefix != 0)
			GetPrefix().Add(lPrefix, 3);
	}

	// Check for an actual centroid
	if (Instance.GetZipCentroid().IsValid() && !Instance.GetZipCentroid().IsZero())
	{
		if (!m_LatitudeCentroid0.IsValid() || !m_LongitudeCentroid0.IsValid())
		{

			m_LatitudeCentroid0 = Instance.GetZipCentroid().GetLatitude();
			m_LongitudeCentroid0 = Instance.GetZipCentroid().GetLongitude();
			if (!m_LatitudeMax.IsValid())
				m_LatitudeMax = m_LatitudeCentroid0;
			if (!m_LatitudeMin.IsValid())
				m_LatitudeMin = m_LatitudeCentroid0;
			if (!m_LongitudeMin.IsValid())
				m_LongitudeMin = m_LongitudeCentroid0;
			if (!m_LongitudeMax.IsValid())
				m_LongitudeMax = m_LongitudeCentroid0;
		}
		else
		{
			// NOTE: The centroid should not change from call to call.
			ASSERT(m_LatitudeCentroid0 == Instance.GetZipCentroid().GetLatitude());
			ASSERT(m_LongitudeCentroid0 == Instance.GetZipCentroid().GetLongitude());
		}
	}
	else if (m_fNoCentroidMessage)
	{
#ifdef SHOW_ZIP_WARNINGS
		Output.OutputF(_T("\nWARNING: No ZIP5 centroid is available for %s.\n\n"), LPCTSTR(Instance.GetZip()));
#endif
		m_fNoCentroidMessage = false;
	}

	// Get lat/int and check for validity
	CIuLatLongUnit latitude(Instance.GetLatitude());
	CIuLatLongUnit longitude(Instance.GetLongitude());
	if (!latitude.IsValid() || latitude.IsZero() || !longitude.IsValid() || longitude.IsZero())
	{
		CIuGeoRawZip_super::Another();
		return ;	
	}

	// See if this record was centroid matched. If so, keep that information so that we have a valid centroid
	if (Instance.GetMatchLevel() == latlongZip)
	{
		if (m_LatitudeCentroid1 == latitude && m_LongitudeCentroid1 == longitude)
			++m_LatLongCentroid1Count;
		else if (m_LatitudeCentroid2 == latitude && m_LongitudeCentroid2 == longitude)
			++m_LatLongCentroid2Count;
		else if (m_LatLongCentroid1Count == 0)
		{
			m_LatitudeCentroid1 = latitude;
			m_LongitudeCentroid1 = longitude;
			m_LatLongCentroid1Count = 1;

			if (m_fCentroidMisMatchMessage && m_LatitudeCentroid0.IsValid() && (m_LatitudeCentroid0 != m_LatitudeCentroid1 || m_LongitudeCentroid0 != m_LongitudeCentroid1))
			{
				m_fCentroidMisMatchMessage = false;
#ifdef SHOW_ZIP_WARNINGS
				Output.OutputF("\nWARNING: ZIP5 centroid is not consistent in %s. Encoding does not match centroid file (1).\n%s/%s vs %s/%s\n\n",
					LPCTSTR(GetName()),
					LPCTSTR(m_LatitudeCentroid0.AsString()),
					LPCTSTR(m_LongitudeCentroid0.AsString()),
					LPCTSTR(m_LatitudeCentroid1.AsString()),
					LPCTSTR(m_LongitudeCentroid1.AsString()));
#endif
			}
		}
		else if (m_LatLongCentroid2Count == 0)
		{
			m_LatitudeCentroid2 = latitude;
			m_LongitudeCentroid2 = longitude;
			m_LatLongCentroid2Count = 1;
			if (m_fCentroidMisMatchMessage && m_LatitudeCentroid0.IsValid() && (m_LatitudeCentroid0 != m_LatitudeCentroid2 || m_LongitudeCentroid0 != m_LongitudeCentroid2))
			{
				m_fCentroidMisMatchMessage = false;
#ifdef SHOW_ZIP_WARNINGS
				Output.OutputF("\nWARNING: ZIP5 centroid is not consistent in %s. Encoding does not match centroid file (2).\n%s/%s vs %s/%s\n\n",
					LPCTSTR(GetName()),
					LPCTSTR(m_LatitudeCentroid0.AsString()),
					LPCTSTR(m_LongitudeCentroid0.AsString()),
					LPCTSTR(m_LatitudeCentroid2.AsString()),
					LPCTSTR(m_LongitudeCentroid2.AsString()));
#endif
			}
		}
		else if (m_fTooManyCentroidsMessage)
		{
			m_fTooManyCentroidsMessage = false;
#ifdef SHOW_ZIP_WARNINGS
			Output.OutputF("\nWARNING: ZIP5 centroid is not consistent in %s. Too many centroids located.\n%s/%s\n%s/%s\n%s/%s (%ld)\n%s/%s (%ld)\n\n",
					LPCTSTR(GetName()),
					LPCTSTR(latitude.AsString()),
					LPCTSTR(longitude.AsString()),
					LPCTSTR(m_LatitudeCentroid0.AsString()),
					LPCTSTR(m_LongitudeCentroid0.AsString()),
					LPCTSTR(m_LatitudeCentroid1.AsString()),
					LPCTSTR(m_LongitudeCentroid1.AsString()),
					int(m_LatLongCentroid1Count),
					LPCTSTR(m_LatitudeCentroid2.AsString()),
					LPCTSTR(m_LongitudeCentroid2.AsString()),
					int(m_LatLongCentroid2Count));
#endif
		}
	}

	// Updated the weighted geo centroid
	DWORD dwLatitude = DWORD(DWORD(latitude) & dwLatLongSignMask);
	DWORD dwLongitude = DWORD(DWORD(longitude) & dwLatLongSignMask);
	m_iLatitudeAccumulator += dwLatitude;
	m_iLongitudeAccumulator += dwLongitude;
	++m_iLatLongs;

	// Next, check if the record is _way_ out of range. If so, truncate to +/- one degree of the centroid.
	CIuLatLongUnit LatitudeCentroid = GetLatitude();
	bool fConstrained = latitude.Constrain(LatitudeCentroid);
	CIuLatLongUnit LongitudeCentroid = GetLongitude();
	fConstrained =  longitude.Constrain(LongitudeCentroid) || fConstrained;

	if (fConstrained)
	{
#ifdef SHOW_ZIP_WARNINGS
		Output.OutputF("\nWARNING: Record in ZIP5 %s was constrained to within one degree of the centroid.\n%s/%s vs %s/%s",
			LPCTSTR(GetName()),
			LPCTSTR(latitude.AsString()),
			LPCTSTR(longitude.AsString()),
			LPCTSTR(LatitudeCentroid.AsString()),
			LPCTSTR(LongitudeCentroid.AsString()));
#endif
	}
	else
	{
		// If the ZIP lat/int was reasonable, use it to compute the min/max coords.
		if (m_LatitudeMax.IsValid())
			m_LatitudeMax = max(m_LatitudeMax, latitude);
		else
			m_LatitudeMax = latitude;

		if (m_LatitudeMin.IsValid())
			m_LatitudeMin = min(m_LatitudeMin, latitude);
		else
			m_LatitudeMin = latitude;

		if (m_LongitudeMin.IsValid())
			m_LongitudeMin = min(m_LongitudeMin, longitude);
		else
			m_LongitudeMin = longitude;

		if (m_LongitudeMax.IsValid())
			m_LongitudeMax = max(m_LongitudeMax, longitude);
		else
			m_LongitudeMax = longitude;
	}

	CIuGeoRawZip_super::Another();
}

bool CIuGeoRawZip::CheckLatLongConstraint(CIuOutput& Output)
{
#ifndef SHOW_ZIP_WARNINGS
	UNUSED_ALWAYS(Output);
#endif

	bool fContrained = false;

	CIuLatLongUnit LatitudeMin = m_LatitudeMin;
	fContrained = LatitudeMin.Constrain(GetLatitude()) || fContrained;
	CIuLatLongUnit LatitudeMax = m_LatitudeMax;
	fContrained = LatitudeMax.Constrain(GetLatitude()) || fContrained;
	CIuLatLongUnit LongitudeMin = m_LongitudeMin;
	fContrained = LongitudeMin.Constrain(GetLongitude()) || fContrained;
	CIuLatLongUnit LongitudeMax = m_LongitudeMax;
	fContrained = LongitudeMax.Constrain(GetLongitude()) || fContrained;

	if (fContrained)
	{
#ifdef SHOW_ZIP_WARNINGS
      Output.OutputF("WARNING:\n");
      Output.OutputF("\n");
      Output.OutputF("ZIP Code %s Lat/Long contraints changed:\n", LPCTSTR(GetName()));
      Output.OutputF("                       Min     Centroid          Max\n");
      Output.OutputF("               -----------  -----------  -----------\n");
      Output.OutputF(" Initial Lat:  %11.11s  %11.11s  %11.11s\n", 
			LPCTSTR(m_LatitudeMin.AsString()), LPCTSTR(GetLatitude().AsString()), LPCTSTR(m_LatitudeMax.AsString()));
      Output.OutputF(" Updated Lat:  %11.11s  %11.11s  %11.11s\n", 
			LPCTSTR(LatitudeMin.AsString()), LPCTSTR(GetLatitude().AsString()), LPCTSTR(LatitudeMax.AsString()));
      Output.OutputF(" Initial Lng:  %11.11s  %11.11s  %11.11s\n", 
			LPCTSTR(m_LongitudeMin.AsString()), LPCTSTR(GetLongitude().AsString()), LPCTSTR(m_LongitudeMax.AsString()));
      Output.OutputF(" Updated Lng:  %11.11s  %11.11s  %11.11s\n", 
			LPCTSTR(LongitudeMin.AsString()), LPCTSTR(GetLongitude().AsString()), LPCTSTR(LongitudeMax.AsString()));
      Output.OutputF("\n");
		Output.Fire();
#endif
	}

	return fContrained;
}

CIuObject* CIuGeoRawZip::GetAreaCode_() const
{
	return &m_AreaCode;
}

CIuObject* CIuGeoRawZip::GetCity_() const
{
	return &m_City;
}

CIuObject* CIuGeoRawZip::GetCounty_() const
{
	return &m_County;
}

CIuLatLongUnit CIuGeoRawZip::GetLatitude() const
{
	if (m_LatitudeCentroid0.IsValid())
		return m_LatitudeCentroid0;

	if (m_LatLongCentroid1Count > 0 && m_LatLongCentroid1Count >= m_LatLongCentroid2Count)
		return m_LatitudeCentroid1;
	if (m_LatLongCentroid2Count > 0 && m_LatLongCentroid2Count >= m_LatLongCentroid1Count)
		return m_LatitudeCentroid2;

	CIuLatLongUnit Latitude;
	if (m_iLatLongs == 0)
		return Latitude;
	Latitude = DWORD(m_iLatitudeAccumulator / m_iLatLongs);
	return Latitude;
}

CString CIuGeoRawZip::GetLatitudeAverageAsString() const
{
	CIuLatLongUnit Latitude;
	if (m_iLatLongs != 0)
		Latitude = DWORD(m_iLatitudeAccumulator / m_iLatLongs);
	return Latitude.AsString();
}

CString CIuGeoRawZip::GetLatitudeAsString() const
{
	return GetLatitude().AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLatitudeCentroid0() const
{
	return m_LatitudeCentroid0;
}

CIuLatLongUnit CIuGeoRawZip::GetLatitudeCentroid1() const
{
	return m_LatitudeCentroid1;
}

CIuLatLongUnit CIuGeoRawZip::GetLatitudeCentroid2() const
{
	return m_LatitudeCentroid1;
}

CString CIuGeoRawZip::GetLatitudeCentroid0AsString() const
{
	return GetLatitudeCentroid0().AsString();
}

CString CIuGeoRawZip::GetLatitudeCentroid1AsString() const
{
	return GetLatitudeCentroid1().AsString();
}

CString CIuGeoRawZip::GetLatitudeCentroid2AsString() const
{
	return GetLatitudeCentroid2().AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLatitudeMax() const
{
	CIuLatLongUnit LatitudeMax = m_LatitudeMax;
	LatitudeMax.Constrain(GetLatitude());
	return LatitudeMax;
}

CString CIuGeoRawZip::GetLatitudeMaxAsString() const
{
	return m_LatitudeMax.AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLatitudeMin() const
{
	CIuLatLongUnit LatitudeMin = m_LatitudeMin;
	LatitudeMin.Constrain(GetLatitude());
	return LatitudeMin;
}

CString CIuGeoRawZip::GetLatitudeMinAsString() const
{
	return m_LatitudeMin.AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLongitude() const
{
	if (m_LongitudeCentroid0.IsValid())
		return m_LongitudeCentroid0;

	if (m_LatLongCentroid1Count > 0 && m_LatLongCentroid1Count >= m_LatLongCentroid2Count)
		return m_LongitudeCentroid1;
	if (m_LatLongCentroid2Count > 0 && m_LatLongCentroid2Count >= m_LatLongCentroid1Count)
		return m_LongitudeCentroid2;

	CIuLatLongUnit Longitude;
	if (m_iLatLongs == 0)
		return Longitude;
	Longitude = DWORD(m_iLongitudeAccumulator / m_iLatLongs);
	return Longitude;
}

CString CIuGeoRawZip::GetLongitudeAverageAsString() const
{
	CIuLatLongUnit Longitude;
	if (m_iLatLongs != 0)
		Longitude = DWORD(m_iLongitudeAccumulator / m_iLatLongs);
	return Longitude.AsString();
}

CString CIuGeoRawZip::GetLongitudeAsString() const
{
	return GetLongitude().AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLongitudeCentroid0() const
{
	return m_LongitudeCentroid0;
}

CIuLatLongUnit CIuGeoRawZip::GetLongitudeCentroid1() const
{
	return m_LongitudeCentroid1;
}

CIuLatLongUnit CIuGeoRawZip::GetLongitudeCentroid2() const
{
	return m_LongitudeCentroid2;
}

CString CIuGeoRawZip::GetLongitudeCentroid0AsString() const
{
	return GetLongitudeCentroid0().AsString();
}

CString CIuGeoRawZip::GetLongitudeCentroid1AsString() const
{
	return GetLongitudeCentroid1().AsString();
}

CString CIuGeoRawZip::GetLongitudeCentroid2AsString() const
{
	return GetLongitudeCentroid2().AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLongitudeMax() const
{
	CIuLatLongUnit LongitudeMax = m_LongitudeMax;
	LongitudeMax.Constrain(GetLongitude());
	return LongitudeMax;
}

CString CIuGeoRawZip::GetLongitudeMaxAsString() const
{
	return m_LongitudeMax.AsString();
}

CIuLatLongUnit CIuGeoRawZip::GetLongitudeMin() const
{
	CIuLatLongUnit LongitudeMin = m_LongitudeMin;
	LongitudeMin.Constrain(GetLongitude());
	return LongitudeMin;
}

CString CIuGeoRawZip::GetLongitudeMinAsString() const
{
	return m_LongitudeMin.AsString();
}

CIuObject* CIuGeoRawZip::GetMsa_() const
{
	return &m_Msa;
}

CIuObject* CIuGeoRawZip::GetPrefix_() const
{
	return &m_Prefix;
}

CIuObject* CIuGeoRawZip::GetState_() const
{
	return &m_State;
}

void CIuGeoRawZip::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_iLatitudeAccumulator;
		ar << m_iLongitudeAccumulator;
		ar << m_iLatLongs;
		ar << m_LatitudeMax;
		ar << m_LatitudeMin;
		ar << m_LatitudeCentroid0;
		ar << m_LatitudeCentroid1;
		ar << m_LatitudeCentroid2;
		ar << m_LatLongCentroid1Count;
		ar << m_LatLongCentroid2Count;
		ar << m_LongitudeMin;
		ar << m_LongitudeMax;
		ar << m_LongitudeCentroid0;
		ar << m_LongitudeCentroid1;
		ar << m_LongitudeCentroid2;
		ar << m_iMedianIncome;
		ar << m_iMedianHomeValue;
	}
	else
	{
		ar >> m_iLatitudeAccumulator;
		ar >> m_iLongitudeAccumulator;
		ar >> m_iLatLongs;
		ar >> m_LatitudeMax;
		ar >> m_LatitudeMin;
		ar >> m_LatitudeCentroid0;
		ar >> m_LatitudeCentroid1;
		ar >> m_LatitudeCentroid2;
		ar >> m_LatLongCentroid1Count;
		ar >> m_LatLongCentroid2Count;
		ar >> m_LongitudeMin;
		ar >> m_LongitudeMax;
		ar >> m_LongitudeCentroid0;
		ar >> m_LongitudeCentroid1;
		ar >> m_LongitudeCentroid2;
		ar >> m_iMedianIncome;
		ar >> m_iMedianHomeValue;
	}
	GetCity().Serialize(ar);
	GetState().Serialize(ar);
	GetMsa().Serialize(ar);
	GetAreaCode().Serialize(ar);
	GetPrefix().Serialize(ar);
	GetCounty().Serialize(ar);
	CIuGeoRawZip_super::Serialize(ar);
}

void CIuGeoRawZip::SetMedianHomeValue(int iMedianHomeValue)
{
	m_iMedianHomeValue = iMedianHomeValue;
}

void CIuGeoRawZip::SetMedianIncome(int iMedianIncome)
{
	m_iMedianIncome = iMedianIncome;
}
