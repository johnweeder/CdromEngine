#ifndef _ENGINE_CDROMPARTITIONDLG_H_
#define _ENGINE_CDROMPARTITIONDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
#ifndef 	_UI_FILLREGIONS_H_
#	include "Ui\FillRegions.h"
#endif	// _UI_FILLREGIONS_H_
#ifndef 	_UI_LAYOUTMANAGER_H_
#	include "Ui\LayoutManager.h"
#endif	// _UI_LAYOUTMANAGER_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// State Information
struct CIuStateInfo
{
	TCHAR m_szName[2+1];
	int m_iRegion;
	int m_iBusinesses;
	int m_iResidences;
	int m_iSelected;
};

/////////////////////////////////////////////////////////////////////////////
// Region Information
struct CIuRegionInfo
{
	TCHAR m_szName[256+1];
	int m_iStates;
	int m_iRecords;
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromPartitionDlg, CDialog }}
#define CIuCdromPartitionDlg_super CDialog

class IU_CLASS_EXPORT CIuCdromPartitionDlg : public CIuCdromPartitionDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuCdromPartitionDlg(CWnd* pParent = 0);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static void DoDialog(CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	CIuStateInfo* FindStateInfo(LPCTSTR pcszAbbr);
	CString Save();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The USA bitmap stuff...
	UINT m_uiBitmap;
	CSize m_cs;
	CBitmap m_Bitmap;
	CIuFillRegions m_FillRegions;
	// Images for the grid control
	CImageList m_Images;
	// Information about the current partition
	CArray<CIuStateInfo,const CIuStateInfo&> m_aStates;
	CArray<CIuRegionInfo,const CIuRegionInfo&> m_aRegions;
	// Previous region name
	CString m_sPrevious;
	// Dialog auto-sizer item
	CIuLayoutManager m_LayoutManager;
//}}Data

public:
	//{{AFX_DATA(CIuCdromPartitionDlg)
	enum { IDD = IDD_ENGINE_CDROM_PARTITION };
	CComboBox	m_lbProducts;
	CListCtrl	m_listStates;
	CListCtrl	m_listRegions;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuCdromPartitionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuCdromPartitionDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnChange();
	afx_msg void OnRclickStates(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClipboard();
	afx_msg void OnLoad();
	afx_msg void OnSave();
	afx_msg void OnDblClickRegions(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMPARTITIONDLG_H_
