#include "StdAfx.h"
//{{Include
#include "AltSpecDft.h"
#include "Alt.h"
#include "IDs.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Alternate specifications

static const CIuAltSpecDft aAlt[] =
{
	{
		_T("AltCity"), altCity,
		&idAltCity,
		_T("AltCity"),
		false, false,
	},{
		_T("AltFirst"), altFirst,
		&idAltFirst,
		_T("AltFirst"),
		false, false,
	},{
		_T("AltLast"), altLast,
		&idAltLast,
		_T("AltLast"),
		false, false,
	},{
		_T("AltPhone"), altPhone,
		&idAltPhone,
		_T("AltPhone"),
		true, true,
	},{
		_T("AltSic"), altSic,
		&idAltSic,
		_T("AltSic"),
		true, false,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuAltSpecDft

int CIuAltSpecDft::Find(LPCTSTR pcszAlt)
{
	ASSERT(AfxIsValidString(pcszAlt));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszAlt, pcszAlt) == 0)
			return i;
	}
	return -1;
}

int CIuAltSpecDft::Find(int iAlt)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iAlt == iAlt)
			return i;
	}
	return -1;
}

const CIuAltSpecDft* CIuAltSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aAlt + iWhich;
}

int CIuAltSpecDft::GetCount()
{
	return sizeof(aAlt) / sizeof(aAlt[0]);
}


