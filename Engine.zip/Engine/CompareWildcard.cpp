#include "StdAfx.h"
//{{Include
#include "CompareWildcard.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuCompareWildcard::CIuCompareWildcard() 
{
	CommonConstruct();
}

CIuCompareWildcard::CIuCompareWildcard(const CIuCompareWildcard& rCompareWildcard)
{
	CommonConstruct();
	*this = rCompareWildcard;
}

CIuCompareWildcard::~CIuCompareWildcard()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuCompareWildcard::Compare(LPCTSTR pcsz2, bool* pfPartial) const
{
	ASSERT(AfxIsValidString(pcsz2));

	if (pfPartial)
		*pfPartial = false;

	int iLength = _tcslen(pcsz2);
	int iCmp = min(m_iLength, iLength);

	LPCTSTR pcsz1 = m_sExpression;

	int iResult = _tcsnicmp(pcsz1, pcsz2, iCmp);
	if (iResult < 0)
		return -1;
	else if (iResult > 0)
		return 1;
	else if (m_iLength < iLength)
	{
		if (m_fWildcard)
		{
			if (pfPartial)
				*pfPartial = true;
			return 0;
		}
		else
			return -1;
	}
	else if (m_iLength > iLength)
		return 1;
	return 0;
}

void CIuCompareWildcard::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sExpression = "";
	m_iLength = 0;
	m_fWildcard = false;
	//}}Initialize
}

CIuCompareWildcard& CIuCompareWildcard::operator=(const CIuCompareWildcard& rCompareWildcard)
{
	if (this == &rCompareWildcard)
		return *this;
	m_sExpression = rCompareWildcard.m_sExpression;
	m_iLength = rCompareWildcard.m_iLength;
	m_fWildcard = rCompareWildcard.m_fWildcard;
	return *this;
}

void CIuCompareWildcard::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
	int iWildcard = m_sExpression.Find('*');
	if (iWildcard >= 0)
	{
		m_sExpression = m_sExpression.Left(iWildcard);
		m_fWildcard = true;
	}
	else
		m_fWildcard = false;
	m_iLength = m_sExpression.GetLength();
}

