#ifndef _ENGINE_INPUTCOUNTY_H_
#define _ENGINE_INPUTCOUNTY_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTRECORDFILE_H_
#	include "Engine\InputRecordFile.h"
#endif	// _ENGINE_INPUTRECORDFILE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputCounty)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputCounty, CIuInputRecordFile }}
#define CIuInputCounty_super CIuInputRecordFile

class CIuInputCounty : public CIuInputCounty_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputCounty)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputCounty();
	virtual ~CIuInputCounty();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Delete(CIuOutput* pOutput);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnMoveNext();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnOutput();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Input file
	CStdioFile m_FileInput;
	CStdioFile m_FileOutput;
	// Temporary strings to process input
	CString m_sInput;
	CString m_sOutput;
	CString m_sCountyCode;
	CString m_sCountyName;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_INPUTCOUNTY_H_
