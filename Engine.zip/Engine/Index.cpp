#include "stdafx.h" 
//{{Include
#include "Index.h"
#include "RecordDef.h"
#include "resource.h"
#include "Data\Output.h"
#include "Error\Error.h"
#include "Database.h"
#include "CdromSpecConst.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuIndex, CIuIndex_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuIndex)
const	CIuVersionNumber versionIndexMax(2000,1,5,304);
const	CIuVersionNumber versionIndexMin(1999,0,1,100);
//}}Implement


IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INDEX, CIuIndex, CIuIndex_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuIndex, IDS_ENGINE_PROP_RECORDDEF, GetRecordDef_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuIndex, IDS_ENGINE_PROP_RECORDDEF, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuIndex, IDS_ENGINE_PPG_INDEX, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuIndex::CIuIndex()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuIndex::CIuIndex(const CIuIndex& rIndex)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rIndex;
}

CIuIndex::~CIuIndex()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuIndex::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pRecordDef.IsNull())
	{
		m_pRecordDef.Create();
	}
	SetVersion(versionIndexMax);
	//}}Initialize
}

void CIuIndex::Copy(const CIuObject& object)
{
	CIuIndex_super::Copy(object);

	const CIuIndex* pIndex = dynamic_cast<const CIuIndex*>(&object);
	if (pIndex == 0 || pIndex == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuIndex)));
	
	*m_pRecordDef = *pIndex->m_pRecordDef;
}

CIuObject* CIuIndex::GetRecordDef_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRecordDef.Ptr()));
}

CIuVersionNumber CIuIndex::GetVersionMax() const
{
	return versionIndexMax;
}

CIuVersionNumber CIuIndex::GetVersionMaxStatic()
{
	return versionIndexMax;
}

CIuVersionNumber CIuIndex::GetVersionMin() const
{
	return versionIndexMin;
}

CIuVersionNumber CIuIndex::GetVersionMinStatic()
{
	return versionIndexMin;
}

CIuIndex& CIuIndex::operator=(const CIuIndex& rIndex)
{
	Copy(rIndex);
	return *this;
}
