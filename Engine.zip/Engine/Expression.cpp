#include "StdAfx.h"
//{{Include
#include "Expression.h"
#include "RecordDef.h"
#include "RecordPtr.h"
#include "ExpressionElement.h"
#include "CaseConversion.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExpression, CIuExpression_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuExpression)
//}}Implement

CIuExpression::CIuExpression() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExpression::CIuExpression(const CIuExpression& rExpression)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rExpression;
}

CIuExpression::~CIuExpression()
{
	if (m_pElement)
		delete m_pElement;
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExpression::Clear()
{
	CIuExpression_super::Clear();
	if (m_pElement)
		delete m_pElement;
	m_pElement = 0;
	m_iMaxLength = -1;
	m_pRecordDef = 0;
}

void CIuExpression::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pElement = 0;
	m_iMaxLength = -1;
	m_pRecordDef = 0;
	m_iCaseConvert = caseNoConvert;
	//}}Initialize
}

void CIuExpression::Copy(const CIuObject& object)
{
	CIuExpression_super::Copy(object);

	const CIuExpression* pExpression = dynamic_cast<const CIuExpression*>(&object);
	if (pExpression == 0 || pExpression == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuExpression)));
	
	m_pRecordDef = pExpression->m_pRecordDef;
	m_iMaxLength = pExpression->m_iMaxLength;
	m_iCaseConvert = pExpression->m_iCaseConvert;
	if (m_pElement)
		delete m_pElement;
	m_pElement = 0;
	if (pExpression->m_pElement)
		m_pElement = pExpression->m_pElement->Clone();
}

void CIuExpression::Dump(int iLevel) const
{
	if (m_pElement == 0)
		return ;
	m_pElement->Dump(iLevel);
}

LPCTSTR CIuExpression::Evaluate(const CIuRecord* pRecord) const
{
	if (m_pElement == 0)
		return _T("");
	// Internally, field length is carried to an arbitrary precision.
	// However, before returning, we limit the string to the maximum
	// length we advertised.
	LPCTSTR pcsz =  m_pElement->Evaluate(pRecord);
#ifdef _DEBUG
	int iLength = int(_tcslen(pcsz));
	if (m_iMaxLength >= 0 && iLength > m_iMaxLength)
	{
		TRACE("WARNING: Expression result exceeds maximum length. String truncated.\n");
		TRACE("\tMaximum size = %d, actual size = %d\n", m_iMaxLength, iLength);
		TRACE("\tValue='%s'\n", pcsz);
		TRACE("\tExpression dump follows:\n");
		Dump();
	}
#endif
	return pcsz;
}

int CIuExpression::EvaluateInt(const CIuRecord* pRecord) const
{
	if (m_pElement == 0)
		return 0;
	return m_pElement->EvaluateInt(pRecord);
}

bool CIuExpression::EvaluateBool(const CIuRecord* pRecord) const
{
	if (m_pElement == 0)
		return false;
	return m_pElement->EvaluateBool(pRecord);
}

int CIuExpression::GetBoughtLevel() const
{
	if (m_pElement == 0)
		return 0;
	return m_pElement->GetBoughtLevel();
}

int CIuExpression::GetMaxLength() const
{
	if (m_pElement == 0)
		return 0;
	return m_pElement->GetMaxLength();
}

bool CIuExpression::IsConst() const
{
	if (m_pElement == 0)
		return true;
	return m_pElement->IsConst();
}

CIuExpression& CIuExpression::operator=(const CIuExpression& rExpression)
{
	Copy(rExpression);
	return *this;
}

void CIuExpression::Parse(LPCTSTR pcsz)
{
	if (m_pElement)
		delete m_pElement;
	m_pElement = 0;
	m_pElement = CIuExpressionElement::Parse(pcsz);
	m_pRecordDef = 0;
	m_iMaxLength = -1;
#ifdef _DEBUG
	m_sExpression = pcsz;
#endif
}

void CIuExpression::Resolve(CIuResolveSpec& Spec)
{
	if (m_pElement == 0)
		return ;

	m_pRecordDef = Spec.m_pRecordDefSrc;

	CIuResolveSpec& SpecTemp = Spec;
	SpecTemp.m_iCaseConvert = GetCaseConvert();

	m_pElement->Resolve(SpecTemp);

	// Then optimize it...
	// Note: Resolving unreversibly alters the parse tree.
	// This happen when constant expressions are removed (often
	//	because a field could not be resolved).
	m_pElement = m_pElement->Optimize();
	if (m_pElement)
	{
		m_iMaxLength = m_pElement->GetMaxLength();
		ASSERT(m_iMaxLength >= 0);
	}
	else
		m_iMaxLength = -1;
}

void CIuExpression::SetCaseConvert(int iCaseConvert)
{
	m_iCaseConvert = iCaseConvert;
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(Expression, pv)
{
	UNUSED_ALWAYS(pv);

	// Create a record definition
	CIuRecordDef RecordDef;
	RecordDef.AddFieldDef("=Name");
	RecordDef.AddFieldDef("=Address");
	RecordDef.AddFieldDef("=City");
	RecordDef.AddFieldDef("=StateAbbr");
	RecordDef.AddFieldDef("=ZIP");
	RecordDef.AddFieldDef("=AcPhone");
	RecordDef.AddFieldDef("=MSAName");
	RecordDef.AddFieldDef("=SICCode");

	// Use some dummy values to create a record
	CIuRecordSpec Spec;
	Spec.Add("Weeder, John");
	Spec.Add("Decatur St");
	Spec.Add("Omaha");
	Spec.Add("NE");
	Spec.Add("68118");
	Spec.Add("4024935672");
	Spec.Add("Omaha NE");
	Spec.Add("123456");
	CIuRecordPtr pRecord(Spec);

	// Create some dummy options
	CIuOptions Options;
	Options.Add("Option1");
	Options.Add("Option2", "value");

	// These are test expressions and values.
	static LPCTSTR apcsz[] = 
	{
		"" "\0" "",
		"TabDelimited(\"ABC\tDEF\tGHI\", 0)" "\0" "ABC",
		"TabDelimited(\"ABC\tDEF\tGHI\", 1)" "\0" "DEF",
		"TabDelimited(\"ABC\tDEF\tGHI\", 2)" "\0" "GHI",
		"NewlineDelimited(\"ABC\nDEF\nGHI\", 0)" "\0" "ABC",
		"NewlineDelimited(\"ABC\nDEF\nGHI\", 1)" "\0" "DEF",
		"NewlineDelimited(\"ABC\nDEF\nGHI\", 2)" "\0" "GHI",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINESS'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'AMERICAN'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'INFORMATION'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'INFO*'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'INFOUSA'" "\0" "0",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINES'" "\0" "0",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINES*'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINESS AMERICAN'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINESS INFORMATION AMERICAN'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUSINESS FRENCH'" "\0" "0",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD ' BUS* INFO* '" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUS INFO'" "\0" "0",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD '{*} BUS INFO'" "\0" "1",
		"'AMERICAN BUSINESS INFORMATION' CONTAINSWORD 'BUS* FREN*'" "\0" "0",
		"'JOHN' CONTAINS 'OH'" "\0" "1",
		"'JON' CONTAINS 'OH'" "\0" "0",
		"Option1" "\0" "1",
		"Option2" "\0" "value",
		"[Option1]" "\0" "1",
		"[Option2]" "\0" "value",
		"'LITERAL'" "\0" "LITERAL",
		"NOT 'LITERAL'" "\0" "1",
		"! 'LITERAL'" "\0" "1",
		"[Name]" "\0" "Weeder, John",
		"1 > 2" "\0" "0",
		"2 > 1" "\0" "1",
		"2 < 3" "\0" "1",
		"1 >= 2" "\0" "0",
		"1 == 2" "\0" "0",
		"1 != 2" "\0" "1",
		"2 <= 3" "\0" "1",
		"1 AND 2" "\0" "1",
		"0 AND 1" "\0" "0",
		"0 OR 1" "\0" "1",
		"0 OR 0" "\0" "0",
		"1 AND 2 AND 0" "\0" "0",
		"0 OR 0 OR 1" "\0" "1",
		"0 OR 0 AND 1" "\0" "0",
		"1 * 2" "\0" "2",
		"2 / 0" "\0" "0",
		"6 / 2" "\0" "3",
		"2 + 3 + 4" "\0" "9",
		"6 - 3 - 2" "\0" "1",
		"'TEST' & 'CONCAT' & 'ENATION'" "\0" "TESTCONCATENATION",
		"'JOHN' LIKE '*OH*'" "\0" "1",
		"'JON' LIKE '*OH*'" "\0" "0",
		"Left(AcPhone, 3)" "\0" "402",
		"Left([AcPhone], 3)" "\0" "402",
		"MakeUpper('xyz')" "\0" "XYZ",
		"MakeLower('x7X')" "\0" "x7x",
		"Compare('abc', 'abc')" "\0" "0",
		"CompareNoCase('abc','ABC')" "\0" "0",
		"Tab()" "\0" "\t" ,
		"Tab(17)" "\0" "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" ,
		"Newline()" "\0" "\n",
		"Newline(3)" "\0" "\n\n\n",
		"CRLF()" "\0" "\r\n",
		"CRLF(2)" "\0" "\r\n\r\n",
		"Space(0)" "\0" "",
		"Space(3)" "\0" "   ",
		"Repeat('x',5)" "\0" "xxxxx",
		"Repeat('(XYZ)')" "\0" "(XYZ)",
		"Repeat('(XYZ)',0)" "\0" "",
		"Repeat('(XYZ)',1)" "\0" "(XYZ)",
		"Repeat('(XYZ)',2)" "\0" "(XYZ)(XYZ)",
		"Repeat('(XYZ)',3)" "\0" "(XYZ)(XYZ)(XYZ)",
		"Repeat('(XYZ)',4)" "\0" "(XYZ)(XYZ)(XYZ)(XYZ)",
		"Repeat('(XYZ)',5)" "\0" "(XYZ)(XYZ)(XYZ)(XYZ)(XYZ)",
		"LatLongDistance('0','0','0','0')" "\0" "0 miles",
		0,
		// Some expressions which aren't working yet
		// Some expression we have tested in the past... primarily that they compile...
		"[Name]&'\t'&Paste([Address],' ',[PostalCity],', ',[StateAbbr],'  ',Paste(ZIP,'-',Iff([AddOn]=='0000','',[AddOn])),' ',Surround('[',[CountyName],']'),' ',Surround('(',[MSAName],' Area)'))&'\t'&Paste(Mid([Phone],0,3),'-',Mid([Phone],3,3),'-',Mid([Phone],6,4))" "\0" "",
		"Paste([Name],'\n',[Address],'\n',[City],', ',[StateAbbr],' ',[ZIP],' ',Surround('(',[MSAName],' Area)'),'\n',Paste(Mid([ACPhone],0,3),'-',Mid([ACPhone],3,3),'-',Mid([ACPhone],6,4)),'\n', Iff([SICCode],'Business','Residential'),' ',Iff([SICCode],'SIC:  '&[SICCode],''))" "\0" "",
		0,
	};

	for (int i = 0; apcsz[i]; ++i)
	{
		CString sExpr = apcsz[i];
		CString sExpected = _tcschr(apcsz[i], '\0') + 1;

		CIuExpression expr;
		expr.Parse(sExpr);
		expr.Dump();
		CIuResolveSpec Spec;
		Spec.m_pRecordDefSrc = &RecordDef;
		Spec.m_pOptions = &Options;
		expr.Resolve(Spec);
		expr.Dump();

		CString sResult = expr.Evaluate(pRecord);
		if (sResult.Compare(sExpected) != 0)
		{
			TRACE("Expression: '%s'\n", LPCTSTR(sExpr));
			TRACE("\tResult='%s'\n", LPCTSTR(sResult));
			TRACE("\tExpected='%s'\n", LPCTSTR(sExpected));
		}
		ASSERT(sResult.Compare(sExpected) == 0);
	}

	return 0;	
}
IU_TEST_END()
#endif


