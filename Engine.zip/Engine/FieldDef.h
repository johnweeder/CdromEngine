#ifndef _ENGINE_FIELDDEF_H_
#define _ENGINE_FIELDDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ENGINEAPP_H_
#	include "Engine\EngineApp.h"
#endif	// _ENGINE_ENGINEAPP_H_
#ifndef 	_INTEROP_FLAGS_H_
#	include "Interop\Flags.h"
#endif	// _INTEROP_FLAGS_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldDef)
class CIuFieldDefs;
class CIuFieldDefSpec;
//}}Predefines

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldDef, CIuCollectable }}
#define CIuFieldDef_super CIuCollectable

class IU_CLASS_EXPORT CIuFieldDef : public CIuFieldDef_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuFieldDef)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldDef();
	CIuFieldDef(const CIuFieldDef&);
	virtual ~CIuFieldDef();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBoughtLevel() const;
	CString GetDescription() const;
	CIuFieldDefs& GetFieldDefs() const;
	CIuFlags GetFlags() const;
	CString GetFlagsAsString() const;
	int GetLength() const;
	CString GetLongName() const;
	int GetOffset() const;
	CString GetShortName() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	bool Compare(const CIuFieldDef& FieldDef, bool fError = true) const;
	virtual void Copy(const CIuObject& object);
	void SetBoughtLevel(int);
	void SetDescription(LPCTSTR);
	void SetFlags(CIuFlags);
	void SetFlagsAsString(LPCTSTR pcsz);
	void SetLength(int iLength);
	void SetLongName(LPCTSTR);
	void SetOffset(int iOffset);
	void SetSpec(LPCTSTR pcszDef);
	void SetSpec(CIuFieldDefSpec& Spec);
	void SetShortName(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldDef& operator=(const CIuFieldDef&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	void CommonConstruct();
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iLength;
	int m_iOffset;
	CString m_sShortName;
	CString m_sLongName;
	CString m_sDescription;
	CIuFlags m_flagsFlags;
	int m_iBoughtLevel;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline int CIuFieldDef::GetBoughtLevel() const
{
	return m_iBoughtLevel;
}

inline CIuFlags CIuFieldDef::GetFlags() const
{
	return m_flagsFlags;
}

inline int CIuFieldDef::GetLength() const
{
	return m_iLength;
}

inline CString CIuFieldDef::GetLongName() const
{
	return m_sLongName;
}

inline int CIuFieldDef::GetOffset() const
{
	return m_iOffset;
}

inline CString CIuFieldDef::GetShortName() const
{
	return m_sShortName;
}

#endif // _ENGINE_FIELDDEF_H_
