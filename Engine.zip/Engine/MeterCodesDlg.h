#ifndef _ENGINE_METERCODESDLG_H_ 
#define _ENGINE_METERCODESDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses											  
#ifndef 	_RESOURCE_H_
#	include "resource.h"
#endif	// _RESOURCE_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
#include "Meters.h"	// Added by ClassView
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterCodesDlg, CDialog }}
#define CIuMeterCodesDlg_super CDialog

class CIuMeterCodesDlg : public CIuMeterCodesDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP() 
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuMeterCodesDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static bool DoDialog(CIuMeters& Meters, CIuMeter* pMeter, UINT uiUserValue, CWnd* pParent = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CFont m_fontLarge;
	// The meters collection
	CIuMeter* m_pMeter;
	CIuMeters* m_pMeters;
	// User value for meter
	UINT m_uiUserValue;
//}}Data

	//{{AFX_DATA(CIuMeterCodesDlg)
	enum { IDD = IDD_ENGINE_METER_CODES };
	CDateTimeCtrl	m_StartDate;
	CComboBox	m_cbRange;
	CComboBox	m_cbAccess;
	CEdit	m_editDateCheck;
	CEdit	m_editDate;
	CEdit	m_editSuperCheck1;
	CEdit	m_editSuperCheck2;
	CEdit	m_editSuperCheck0;
	CEdit	m_editSuperCheck07;
	CEdit	m_editSuper2;
	CEdit	m_editSuper1;
	CEdit	m_editSuper0;
	CEdit	m_editSuper07;
	CString	m_sSuper0;
	CString	m_sSuper07;
	CString	m_sSuper1;
	CString	m_sSuper2;
	CString	m_sSuperCheck0;
	CString	m_sSuperCheck07;
	CString	m_sSuperCheck2;
	CString	m_sSuperCheck1;
	CString	m_sDate;
	CString	m_sDateCheck;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIuMeterCodesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuMeterCodesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChange();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_METERCODESDLG_H_
