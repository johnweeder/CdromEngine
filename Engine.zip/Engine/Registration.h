#ifndef _ENGINE_REGISTRATION_H_
#define _ENGINE_REGISTRATION_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRegistration)
IU_DEFINE_OBJECT_PTR(CIuMeter)
class CIuRegistrationSpec;
class CIuCdrom;
class CIuEngine;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Registration Types
enum CIuRegistrationNo
{
	registrationNone = 0,

	registration104m_2001,
	registration88md_2001,
	registrationAc_V1,
	registrationBml_2000,
	registrationCi_V1,
	registrationPb_2001,
	registrationPbm_V1,
	registrationPf_2001,
	registrationPu_2001,
	registrationRp_2001,
	registrationSample,
	registrationSlu_2000,
	registrationYpu_2001,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegistration, CIuCollectable }}
#define CIuRegistration_super CIuCollectable

class IU_CLASS_EXPORT CIuRegistration : public CIuRegistration_super
{
//{{Declare
	DECLARE_SERIAL(CIuRegistration)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegistration();           // protected constructor used by dynamic creation
	virtual ~CIuRegistration();
	CIuRegistration(const CIuRegistration&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuEngine& GetEngine() const;
	CString GetFaxPhone() const;
	CString GetMailAddress() const;
	int GetMaxRuns() const;
	CIuMeterPtr GetMeter() const;
	CIuID GetMeterID() const;
	CString GetModemPhone() const;
	CString GetModemPhoneAreaCode() const;
	CString GetModemPhoneCountryCode() const;
	CIuObjectRepository& GetObjectRepository() const;
	CString GetProductID() const;
	CString GetProductName() const;
	int GetRemainingRuns() const;
	CString GetURL() const;
	void GetValidResponses(CStringArray& as) const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	CString GetVoicePhone() const;
	bool HasEngine() const;
	bool HasObjectRepository() const;
	bool IsDebug() const;
	bool IsRegistered() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	virtual void Copy(const CIuObject& object);
	bool Register(CWnd* pParent = 0, bool fAutoDecrement = true);
	void SetDebug(bool);
	void SetEngine(CIuEngine& Engine);
	void SetFaxPhone(LPCTSTR);
	void SetMailAddress(LPCTSTR);
	void SetMaxRuns(int iMaxRuns);
	void SetMeterID(CIuID ID);
	void SetModemPhone(LPCTSTR);
	void SetModemPhoneAreaCode(LPCTSTR);
	void SetModemPhoneCountryCode(LPCTSTR);
	void SetName(LPCTSTR pcszName);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetProductID(LPCTSTR);
	void SetProductName(LPCTSTR);
	void SetRegistered(bool);
	void SetRemainingRuns(int iRemainingRuns);
	void SetSpec(CIuRegistrationSpec& Spec);
	void SetURL(LPCTSTR);
	void SetValidResponses(const CStringArray&);
	void SetVoicePhone(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuRegistration& operator=(const CIuRegistration&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionRegister(const CIuPropertyCollection&, CIuOutput&);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Associated object repository
	CIuObjectRepository* m_pObjectRepository;
	// Product name and id
	CString m_sProductName;
	CString m_sProductID;
	// Maximum runs allowed (-1 == registration not required)
	int m_iMaxRuns;
	// Locations for registration information
	CString m_sFaxPhone;
	CString m_sMailAddress;
	CString m_sURL;
	// Phone info
	CString m_sVoicePhone;
	CString m_sModemPhoneCountryCode;
	CString m_sModemPhoneAreaCode;
	CString m_sModemPhone;
	// A list of valid responses
	CStringArray m_asValidResponses;
	// The meter which stores the persistent registration information
	CIuID m_idMeter;
	// Back pointer to engine
	CIuEngine* m_pEngine;
	// Debug mode... enables some nice access kind'a things
	bool m_fDebug;
//}}Data

};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuEngine& CIuRegistration::GetEngine() const
{
	ASSERT(HasEngine());
	return *m_pEngine;
}

inline CString CIuRegistration::GetFaxPhone() const
{
	return m_sFaxPhone;
}

inline CString CIuRegistration::GetMailAddress() const
{
	return m_sMailAddress;
}

inline int CIuRegistration::GetMaxRuns() const
{
	return m_iMaxRuns;
}

inline CIuID CIuRegistration::GetMeterID() const
{
	return m_idMeter;
}

inline CString CIuRegistration::GetModemPhone() const
{
	return m_sModemPhone;
}

inline CString CIuRegistration::GetModemPhoneAreaCode() const
{
	return m_sModemPhoneAreaCode;
}

inline CString CIuRegistration::GetModemPhoneCountryCode() const
{
	return m_sModemPhoneCountryCode;
}

inline CIuObjectRepository& CIuRegistration::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CString CIuRegistration::GetProductID() const
{
	return m_sProductID;
}
inline CString CIuRegistration::GetProductName() const
{
	return m_sProductName;
}

inline CString CIuRegistration::GetURL() const
{
	return m_sURL;
}

inline CString CIuRegistration::GetVoicePhone() const
{
	return m_sVoicePhone;
}

inline bool CIuRegistration::HasEngine() const
{
	return m_pEngine != 0;
}

inline bool CIuRegistration::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuRegistration::IsDebug() const
{
	return m_fDebug;
}

#endif // _ENGINE_REGISTRATION_H_
