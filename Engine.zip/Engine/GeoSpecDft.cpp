#include "StdAfx.h"
//{{Include
#include "GeoSpecDft.h"
#include "Geo.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Geoernate specifications

static const CIuGeoSpecDft aGeo[] =
{
	{
		_T("Standard"), geoStandard,
		_T(""),
		_T("Zip"),
		_T("City"),
		_T("StateCode"),
		_T("MsaCode"),
		_T("CountyCode"),
		_T("Latitude"),
		_T("Longitude"),
		_T("MatchLevel"),
		_T("AcPhone\nFaxAcPhone\nTollFreeAcPhone"),
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuGeoSpecDft

int CIuGeoSpecDft::Find(LPCTSTR pcszGeo)
{
	ASSERT(AfxIsValidString(pcszGeo));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszGeo, pcszGeo) == 0)
			return i;
	}
	return -1;
}

int CIuGeoSpecDft::Find(int iGeo)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iGeo == iGeo)
			return i;
	}
	return -1;
}

const CIuGeoSpecDft* CIuGeoSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aGeo + iWhich;
}

int CIuGeoSpecDft::GetCount()
{
	return sizeof(aGeo) / sizeof(aGeo[0]);
}
