#ifndef _ENGINE_BTREETOKENIZERSPEC_H_
#define _ENGINE_BTREETOKENIZERSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTreeTokenizerSpec)
struct CIuBTreeTokenizerSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTreeTokenizerSpec, CIuObjectNamed }}
#define CIuBTreeTokenizerSpec_super CIuObjectNamed

class CIuBTreeTokenizerSpec : public CIuBTreeTokenizerSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTreeTokenizerSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTreeTokenizerSpec();
	virtual ~CIuBTreeTokenizerSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuBTreeSpec& GetBTree() const;
	int GetBTreeTokenizerNo() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetFilename() const;
	int GetTokenNo() const;
	bool HasBTree() const;
	bool IsExceptional() const;
	bool IsOptional() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuBTreeSpec* pBTree, int iBTreeTokenizerSpec);
	void FromName(CIuBTreeSpec* pBTree, LPCTSTR pcszBTreeTokenizer);
	void FromNo(CIuBTreeSpec* pBTree, int iBTreeTokenizerNo);
	void FromSpec(CIuBTreeSpec* pBTree, const CIuBTreeTokenizerSpecDft* pBTreeTokenizerSpec);
	void SetBTree(CIuBTreeSpec* pBTree);
	void SetBTreeTokenizerNo(int);
	void SetExceptional(bool);
	void SetFilename(LPCTSTR);
	void SetTokenNo(int);
	void SetOptional(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuBTreeSpec* m_pBTree;
	int m_iBTreeTokenizerNo;
	int m_iTokenNo;
	CString m_sFilename;
	bool m_fOptional;
	bool m_fExceptional;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuBTreeSpec& CIuBTreeTokenizerSpec::GetBTree() const
{
	ASSERT(HasBTree());
	return *m_pBTree;
}

inline int CIuBTreeTokenizerSpec::GetBTreeTokenizerNo() const
{
	return m_iBTreeTokenizerNo;
}

inline CString CIuBTreeTokenizerSpec::GetFilename() const
{
	return m_sFilename;
}

inline int CIuBTreeTokenizerSpec::GetTokenNo() const
{
	return m_iTokenNo;
}

inline bool CIuBTreeTokenizerSpec::HasBTree() const
{
	return m_pBTree != 0;
}

inline bool CIuBTreeTokenizerSpec::IsExceptional() const
{
	return m_fExceptional;
}

inline bool CIuBTreeTokenizerSpec::IsOptional() const
{
	return m_fOptional;
}

#endif // _ENGINE_BTREETOKENIZERSPEC_H_
