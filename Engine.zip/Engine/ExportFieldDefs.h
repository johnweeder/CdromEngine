#ifndef _ENGINE_EXPORTFIELDDEFS_H_
#define _ENGINE_EXPORTFIELDDEFS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPORTFIELDDEF_H_
#	include "Engine\ExportFieldDef.h"
#endif	// _ENGINE_EXPORTFIELDDEF_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportFieldDefs)
class CIuExportDef;
//}}Predefines

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportFieldDefs, CIuExportFieldDefs_super }}
#define CIuExportFieldDefs_super CIuCollection

class IU_CLASS_EXPORT CIuExportFieldDefs : public CIuExportFieldDefs_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportFieldDefs)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportFieldDefs();           
	virtual ~CIuExportFieldDefs();
	CIuExportFieldDefs(const CIuExportFieldDefs&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuExportFieldDef& Get(LPCTSTR s) const;
	CIuExportFieldDef& Get(int iIndex) const;
	CIuExportFieldDef& Get(CIuID id) const;
	CIuExportDef& GetExportDef() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
	virtual int CreateFieldDef(LPCTSTR pcszDef);
	virtual int CreateFieldDef(CIuExportFieldDefSpec& spec);
	void SetSpec(CIuExportDefSpec& ExportDefSpec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExportFieldDefs& operator=(const CIuExportFieldDefs&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	void SetExportDef(CIuExportDef* pExportDef);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuExportDef* m_pExportDef;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuExportFieldDef& CIuExportFieldDefs::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuExportFieldDef*>(&CIuCollection::Get(s));
}

inline CIuExportFieldDef& CIuExportFieldDefs::Get(int iIndex) const
{
	return *dynamic_cast<CIuExportFieldDef*>(&CIuCollection::Get(iIndex));
}

inline CIuExportFieldDef& CIuExportFieldDefs::Get(CIuID id) const
{
	return *dynamic_cast<CIuExportFieldDef*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_EXPORTFIELDDEFS_H_
