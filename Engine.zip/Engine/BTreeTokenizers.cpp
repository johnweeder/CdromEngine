#include "StdAfx.h"
//{{Include
#include "BTreeTokenizers.h"
#include "BTreeTokenizer.h"
#include "BTreeCodec.h"
#include "BTreeSpec.h"
#include "resource.h"
#include "BTreeTokenizer.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeTokenizers, CIuBTreeTokenizers_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeTokenizers)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREETOKENIZERS, CIuBTreeTokenizers, CIuBTreeTokenizers_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBTreeTokenizers, IDS_ENGINE_PPG_BTREETOKENIZERS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuBTreeTokenizers, IDS_ENGINE_PPG_BTREETOKENIZERS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeTokenizers::CIuBTreeTokenizers() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTreeTokenizers::~CIuBTreeTokenizers()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}
 
void CIuBTreeTokenizers::Close(bool fForce)
{
	int iTokenizers = GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
		Get(iTokenizer).Close(fForce);
}

void CIuBTreeTokenizers::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuBTreeTokenizers::CreateBTreeTokenizer(CIuBTreeTokenizerSpec& BTreeTokenizerSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuBTreeTokenizer& BTreeTokenizer = Get(iIndex);
	BTreeTokenizer.SetSpec(BTreeTokenizerSpec);
}

CIuCollectablePtr CIuBTreeTokenizers::OnNew(CWnd*) const
{
	CIuBTreeTokenizerPtr pBTreeTokenizer;
	pBTreeTokenizer.Create();
	return pBTreeTokenizer;
}

void CIuBTreeTokenizers::MakeRecordDef(CIuRecordDef& RecordDef)
{
	int iTokenizers = GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
	{
		Get(iTokenizer).MakeRecordDef(RecordDef);
	}
}

void CIuBTreeTokenizers::Open()
{
	int iTokenizers = GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
		Get(iTokenizer).Open();
}

void CIuBTreeTokenizers::Resolve(CIuResolveSpec& Spec)
{
	int iTokenizers = GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
	{
		CIuResolveSpec SpecTemp = Spec;
		Get(iTokenizer).Resolve(SpecTemp);
	}
}

void CIuBTreeTokenizers::SetCodec(CIuBTreeCodec* pCodec)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	ASSERT(pCodec!=0);
	m_pCodec = pCodec;
}

void CIuBTreeTokenizers::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	int iTokenizers = GetCount();
	for (int iTokenizer = 0; iTokenizer < iTokenizers; ++iTokenizer)
		Get(iTokenizer).SetObjectRepository(pObjectRepository);
}

void CIuBTreeTokenizers::SetSpec(CIuBTreeSpec& Spec)
{
	RemoveAll();

	// Create the BTree Tokenizers
	for (int iBTreeTokenizer = 0; iBTreeTokenizer < Spec.GetTokenizerCount(); ++iBTreeTokenizer)
		CreateBTreeTokenizer(Spec.GetTokenizer(iBTreeTokenizer));
}

