#include "StdAfx.h"
//{{Include
#include "Element.h"
#include "ElementCollection.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuElement::CIuElement() 
{
	CommonConstruct();
}

CIuElement::CIuElement(CIuElementCollection* pCollection, LPCTSTR pcszName)
{
	CommonConstruct();
	SetCollection(pCollection);
	Create(pcszName);
}

CIuElement::~CIuElement()
{
	if (m_pNext)
		delete m_pNext;
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuElement::Another()
{
	++m_iCount;
}

void CIuElement::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pNext = 0;
	m_iCount = 0;
	m_pCollection = 0;
	m_pcszName = 0;
	//}}Initialize
}

void CIuElement::Create(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	ASSERT(m_pCollection);
	m_pcszName = m_pCollection->GetHeap().Add(pcszName);
	m_iCount = 1;
}

UINT CIuElement::HashKey()
{
	ASSERT(m_pcszName);
	return HashKey(m_pcszName);
}

UINT CIuElement::HashKey(LPCTSTR pcszName)
{
	// NOTE: This algorithm must be identical in both CIuAddressElement && CIuTokenInstance
	// Do not change one without updating the other!
	UINT nHash = 0;
	const BYTE* pb = (const BYTE*)pcszName;
	for (int i = 0; pb[i]; ++i)
		nHash = (nHash << 5) + nHash + pb[i];
	return nHash;
}

void CIuElement::Serialize(CArchive& ar)
{
	const int iMaxString = 1024;

	if (ar.IsStoring())
	{
		ASSERT(m_pcszName);
		DWORD dwSize = min(iMaxString, _tcslen(m_pcszName) + 1);
		ASSERT(dwSize <= iMaxString);
		ar << dwSize;

		ar.Write(m_pcszName, dwSize);

		ar << m_iCount;
	}
	else
	{
		DWORD dwSize;
		ar >> dwSize;

		TCHAR szName[iMaxString];
		ASSERT(dwSize <= iMaxString);

		ar.Read(szName, dwSize);

		szName[iMaxString - 1] = '\0';

		m_pcszName = m_pCollection->GetHeap().Add(szName);

		ar >> m_iCount;
	}
}

void CIuElement::SetCollection(CIuElementCollection* pCollection)
{
	ASSERT(pCollection);
	m_pCollection = pCollection;
}

void CIuElement::SetCount(int iCount)
{
	m_iCount = iCount;
}

void CIuElement::SetNext(CIuElement* pNext)
{
	m_pNext = pNext;
}

