#ifndef _ENGINE_RECORDHEAP_H_
#define _ENGINE_RECORDHEAP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
#ifndef 	_COMMON_MAPI64I_H_
#	include "Common\MapI64I.h"
#endif	// _COMMON_MAPI64I_H_
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
#ifndef 	_ENGINE_MISCELLANEOUS_H_
#	include "Engine\Miscellaneous.h"
#endif	// _ENGINE_MISCELLANEOUS_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordHeap)
struct CIuRecord;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// The heap modes
const int rawRecordHeapModeNone				= 0;
const int rawRecordHeapModeSimple			= 1;
const int rawRecordHeapModeCache				= 2;
const int rawRecordHeapModeFixed				= 3;
const int rawRecordHeapModeVariable			= 4;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordHeap, CIuObject }}
// This class is a space efficient means of storing a number of a rawrecords.
// It is reasonably efficient at add/deleting records. However it may become 
// somewhat fragmented over time.
// There are several ways this class is used:
//		rawRecordHeapModeSimple
//			It functions as a simple heap which accumulates records.
//			This mode is used by the raw record file class and by 
//			the query class in normal query mode.
//			Records can be add but can not be deleted.
//			The size of the heap is variable.
//			Do _not_ maintain pointers to the heap across calls which
//				may add records to the heap.
//			NOTE: In this mode records are referred to only by offset
//					with the heap.
//					Pointers would not be valid after a resize operation.
//			The following functions are used in this mode:
//				CIuRecord* Append(const CIuRecord* pRecord);
//				CIuRecord* Get(int iIndex) const;
//		rawRecordHeapModeCache
//			It functions as a cache which maps src/rec no to a raw record
//			This mode is used by the query class in direct mode.
//			The size of the heap is fixed. 
//			When the heap become full, we either clear the top or the bottom
//			half of the heap to make room. This methods helps to eliminate 
//			the fragmenting of the heap.
//			The following functions are used in this mode:
//				CIuRecord* Lookup(UINT32 uiSrcNo, UINT32 uiRecNo) const;
//				CIuRecord* Lookup(UINT64 uiSrcRecNo) const;
//				CIuRecord* Set(const CIuRecord* pRecord);
//		rawRecordHeapModeFixed
//			It functions as a complex heap which allows adding/deleting records.
//			Records are accessed by offset. The offset is not maintained internally.
//			This mode is used by the heap-sort.
//			The size of the heap is fixed.
//			The following functions are used in this mode:
//				int AppendAt(const CIuRecord* pRecord);
//				CIuRecord* GetAt(int iOffset) const;
//				void RemoveAt(int iOffset);
//		rawRecordHeapModeVariable
//			This is a combination of simple mode and a fixed heap.
//			Records can be added and deleted.
//			This mode is used by the recordset class.
//			The size of the heap is variable.
//			The following functions are used in this mode:
//				CIuRecord* Append(const CIuRecord* pRecord);
//				CIuRecord* Get(int iIndex) const;
//				void Remove(int iIndex);
#define CIuRecordHeap_super CIuObject

class CIuRecordHeap : public CIuRecordHeap_super
{
//{{Declare
	DECLARE_SERIAL(CIuRecordHeap)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordHeap();
	virtual ~CIuRecordHeap();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuRecord* Get(int iIndex) const;
	CIuRecord* GetAt(int iOffset) const;
	virtual void GetBuffer(CIuBuffer& Buffer) const;
	int GetCount() const;
	int GetMode() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool IsCache() const;
	bool IsFixed() const;
	bool IsSimple() const;
	bool IsVariable() const;
	CIuRecord* Lookup(UINT32 uiSrcNo, UINT32 uiRecNo) const;
	CIuRecord* Lookup(UINT64 uiSrcRecNo) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	CIuRecord* Append(const CIuRecord* pRecord);
	int AppendAt(const CIuRecord* pRecord);
	void Empty();
	void Remove(int iIndex);
	void RemoveAt(int iOffset);
	CIuRecord* Set(const CIuRecord* pRecord);
	virtual int SetBuffer(const CIuBuffer& Buffer, int iOffset);
	void SetMode(int iMode, int iSize = 64 * 1024);
	int Validate(int iOffset = -1) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	int Add(const CIuRecord* pRecord);
	void Combine();
	void CommonConstruct();
	void Delete(int iOffset);
	void Flush();
	void Grow(int iGrowBy);
	int Insert(const CIuRecord* pRecord);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The current heap mode. Changing the mode clear the heap
	int m_iMode;
	// This heap can conceivably grow quite large (especially when used as a 
	// sort buffer). So use a big buffer.
	// NOTE: Record always align on sizeof(CIuRecordHeader) byte boundaries. 
	// This gives sufficient size to always store the total/used size and reference 
	// count for each record. A reference count of 0xFFFF indicates a free block.
	CIuBigBuffer m_Buffer;
	// Offset of next free block.
	// 0xFFFFFFFF if no free blocks are available.
	DWORD m_dwFree;
	// When clearing up the cache, this flag controls whether to flush the top 
	// or bottom next. Because records are added from the end, we start by flushing
	// the top half.
	bool m_fFlushTopHalf;
	// A mapping which is used in caching mode
	CIuMapInt64ToInt32 m_Map;
	// An array which is used in simple mode to track the offset of each record
	CIntArray m_Array;
	// The actual number of records in collection.
	int m_iCount;
	// Debug mode flag
	// Turning this on can really impact performance.
	bool m_fDebug;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuRecordHeap::GetCount() const
{
	return m_iCount;
}

inline int CIuRecordHeap::GetMode() const
{
	return m_iMode;
}

inline bool CIuRecordHeap::IsCache() const
{
	return m_iMode == rawRecordHeapModeCache;
}

inline bool CIuRecordHeap::IsFixed() const
{
	return m_iMode == rawRecordHeapModeFixed;
}

inline bool CIuRecordHeap::IsSimple() const
{
	return m_iMode == rawRecordHeapModeSimple;
}

inline bool CIuRecordHeap::IsVariable() const
{
	return m_iMode == rawRecordHeapModeVariable;
}

inline CIuRecord* CIuRecordHeap::Lookup(UINT64 uiSrcRecNo) const
{
	return Lookup(GET_SRCNO(uiSrcRecNo), GET_RECNO(uiSrcRecNo));
}

#endif // _ENGINE_RECORDHEAP_H_
