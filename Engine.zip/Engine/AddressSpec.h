#ifndef _ENGINE_ADDRESSSPEC_H_
#define _ENGINE_ADDRESSSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddressSpec)
struct CIuAddressSpecDft;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddressSpec, CIuObjectNamed }}
#define CIuAddressSpec_super CIuObjectNamed
class CIuAddressSpec : public CIuAddressSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddressSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddressSpec();
	virtual ~CIuAddressSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAddressNo() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetHighRise() const;
	CString GetNoSolicitation() const;
	CString GetPostDir() const;
	CString GetPreDir() const;
	CString GetPriNo() const;
	int GetRecordDef() const;
	CString GetSecNo() const;
	CString GetStreetName() const;
	CString GetSuffix() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iAddressSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszAddress);
	void FromNo(CIuCdromSpec* pCdrom, int iAddressNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuAddressSpecDft* pAddressSpec);
	void SetAddressNo(int);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetHighRise(LPCTSTR);
	void SetNoSolicitation(LPCTSTR);
	void SetPostDir(LPCTSTR);
	void SetPreDir(LPCTSTR);
	void SetPriNo(LPCTSTR);
	void SetSecNo(LPCTSTR);
	void SetStreetName(LPCTSTR);
	void SetSuffix(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	int m_iAddressNo;
	CString m_sPriNo;
	CString m_sPreDir;
	CString m_sStreetName;
	CString m_sSuffix;
	CString m_sPostDir;
	CString m_sSecNo;
	CString m_sHighRise;
	CString m_sNoSolicitation;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuAddressSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuAddressSpec::GetHighRise() const
{
	return m_sHighRise;
}

inline int CIuAddressSpec::GetAddressNo() const
{
	return m_iAddressNo;
}

inline CString CIuAddressSpec::GetNoSolicitation() const
{
	return m_sNoSolicitation;
}

inline CString CIuAddressSpec::GetPostDir() const
{
	return m_sPostDir;
}

inline CString CIuAddressSpec::GetPreDir() const
{
	return m_sPreDir;
}

inline CString CIuAddressSpec::GetPriNo() const
{
	return m_sPriNo;
}

inline CString CIuAddressSpec::GetSecNo() const
{
	return m_sSecNo;
}

inline CString CIuAddressSpec::GetStreetName() const
{
	return m_sStreetName;
}

inline CString CIuAddressSpec::GetSuffix() const
{
	return m_sSuffix;
}

inline bool CIuAddressSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_ADDRESSSPEC_H_
