#ifndef _ENGINE_QUERY_H_
#define _ENGINE_QUERY_H_
#if _MSC_VER > 1000
#	pragma once
#endif
													   
//{{Uses
#ifndef 	_ENGINE_RECORDSET_H_
#	include "Engine\RecordSet.h"
#endif	// _ENGINE_RECORDSET_H_
#ifndef 	_ENGINE_SOURCE_H_
#	include "Engine\Source.h"
#endif	// _ENGINE_SOURCE_H_
#ifndef 	_ENGINE_QUERYTHREAD_H_
#	include "Engine\QueryThread.h"
#endif	// _ENGINE_QUERYTHREAD_H_
#ifndef 	_ENGINE_SOURCEDESCRIPTORSPEC_H_
#	include "Engine\SourceDescriptorSpec.h"
#endif	// _ENGINE_SOURCEDESCRIPTORSPEC_H_
#ifndef 	_ENGINE_QUERYEXECUTE_H_
#	include "Engine\QueryExecute.h"
#endif	// _ENGINE_QUERYEXECUTE_H_
#ifndef 	_ENGINE_SELECT_H_
#	include "Engine\Select.h"
#endif	// _ENGINE_SELECT_H_
#ifndef 	_ENGINE_WORKBOOK_H_
#	include "Engine\Workbook.h"
#endif	// _ENGINE_WORKBOOK_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuQuery)
IU_DEFINE_OBJECT_PTR(CIuCounts)
IU_DEFINE_OBJECT_PTR(CIuDatabase)
IU_DEFINE_OBJECT_PTR(CIuMeter)
IU_DEFINE_OBJECT_PTR(CIuUserInterface)
class CIuQueries;
class CIuQueryExecute;
class CIuWorkbookFile;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuQuery, CIuCollectable }}
//	A query is a container class for a recordset. The query contains the
// expression which generated the recordset.
#define CIuQuery_super CIuCollectable

class IU_CLASS_EXPORT CIuQuery : public CIuQuery_super
{
//{{Declare
	DECLARE_SERIAL(CIuQuery)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuQuery();           
	virtual ~CIuQuery();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuDatabasePtr GetDatabase() const;
	COleDateTime GetCreated() const;
	CIuEngine& GetEngine() const;
	CString GetExpression() const;
	int GetHandle() const;
	CIuMeter& GetMeter() const;
	CIuOptions& GetOptions() const;
	CIuQueries& GetQueries() const;
	CIuRecordSet& GetRecordSet() const;
	void GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const;
	CIuUserInterface& GetUserInterface() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	CIuWorkbook& GetWorkbook() const;
	bool HasDatabase() const;
	bool HasEngine() const;
	bool IsCompleted() const;
	bool IsRunning() const;
	bool IsStarted() const;
	bool IsSuccessful() const;
	bool IsThreading() const;
	bool IsWorkbookMode() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Cancel();
	void CancelWorkbookMode();
	void Clear();
	void Complete();
	CIuCountsPtr Count(LPCTSTR pcsz);
	CString Request(LPCTSTR pcszRq);
	CString Request(const CIuSelect& Select);
	void SetCreated(const COleDateTime&);
	void SetEngine(CIuEngine& Engine);
	void SetExpression(LPCTSTR pcsz);
	void SetExpression(const CIuSelect& Select);
	void SetID(CIuID ID);
	void SetName(LPCTSTR pcsz);
	void SetWorkbookMode(const CStringArray& asFields);
	void Start(const CIuSelect& Select);
	void Start(LPCTSTR pcsz = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
protected:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	// Output object
	CIuOutput& GetOutput() const;

	// Various child objects
	CIuObject* GetOptions_() const;
	CIuObject* GetRecordSet_() const;
	CIuObject* GetWorkbook_() const;

private:
	friend class CIuWorkbook;
	void GetBuffer(CIuWorkbookFile& WorkbookFile, CIuBuffer& Buffer) const;
	void SetBuffer(const CIuWorkbookFile&, const CIuBuffer& Buffer);

private:
	friend class CIuQueryThread;
	bool Run();

private:
	void CommonConstruct();
	bool Execute(LPCTSTR pcsz, bool fSingleThread = false);
	void SetCompleted(bool f = true);
	void SetOptions(const CIuOptions&);
	void SetStarted(bool = true);
	void SetThreading(bool f = true);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuQueryExecute;

	// The engine object
	CIuEngine* m_pEngine;

	// The expression... 
	// The expression can be empty if this is a "workbook" which just
	// stores arbitrary records from other sources
	CString m_sExpression;
	// The record set which actually contains the records
	CIuRecordSetPtr m_pRecordSet;
	// The date/time this query was created
	// Note that the base class already contains name/id/description.
	COleDateTime m_dtCreated;
	// An output object used during the query process
	mutable CIuOutputPtr m_pOutput;
	// This semaphore is used in derived classes to provide
	// mutual exclusion with respect to the pump
	mutable CMutex m_mutex;
	// This is the thread which actually pumps the records
	// NOTE: The pump is kept here instead of the sink
	//			because we don't want the thread being created
	//			and destroyed everytime a new sink is created
	//			as a result of a query.
	CIuQueryThread* m_pThread;
	// This flag is once the pumping has started.
	bool m_fStarted;
	// This flag is set when the currently pending operation is completed.
	bool m_fCompleted;
	// This flag is set if the instance is running the pump using a thread.
	bool m_fThreading;
	// When starting a query, we promise that a source and a record definition
	// will be established before returning from start. We use this event 
	// semaphore to signal when this has happened
	CEvent m_eventStarted;
	// Master options used in this query
	CIuOptions m_Options;
	// The query instance object which actually manages the query process
	CIuQueryExecutePtr m_pExecute;
	// Workbook mode is a special mode where there is no query. Instead, records
	// are added and removed from the recordset manually.
	// The workbook, itself, can be used independently of workbook "mode" to 
	// load and save records.
	CIuWorkbookPtr m_pWorkbook;
	// These are some local objects we maintain which are related to the query.
	// We guarantee that there will always be a meter and a user interface...
	//		even if we have to dummy one up.
	// A database is provided only if available. Basically, that mean that the 
	//		query can only have come from a single database.
	CIuDatabasePtr m_pDatabase;
	CIuMeterPtr m_pMeter;
	CIuUserInterfacePtr m_pUserInterface;
//}}Data
}; 

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline COleDateTime CIuQuery::GetCreated() const
{
	return m_dtCreated;
}

inline CIuEngine& CIuQuery::GetEngine() const
{
	ASSERT(HasEngine());
	return *m_pEngine;
}

inline CString CIuQuery::GetExpression() const
{
	return m_sExpression;
}

inline CIuOptions& CIuQuery::GetOptions() const
{
	return *const_cast<CIuOptions*>(&m_Options);
}

inline CIuRecordSet& CIuQuery::GetRecordSet() const
{
	return m_pRecordSet.Ref();
}

inline CIuWorkbook& CIuQuery::GetWorkbook() const
{
	return m_pWorkbook.Ref();
}

inline bool CIuQuery::HasEngine() const
{
	return m_pEngine != 0;
}

inline bool CIuQuery::IsStarted() const
{
	return m_fStarted;
}

inline bool CIuQuery::IsThreading() const
{
	return m_fThreading;
}

#endif // _ENGINE_QUERY_H_
 
