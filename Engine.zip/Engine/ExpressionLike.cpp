#include "StdAfx.h"
//{{Include
#include "ExpressionLike.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuExpressionLike::CIuExpressionLike() : CIuExpressionElement(exprLike)
{
	SetFormat(exprFormatBool);
	CommonConstruct();
}

CIuExpressionLike::CIuExpressionLike(const CIuExpressionLike& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionLike::~CIuExpressionLike()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionLike::Clone() const
{
	CIuExpressionLike* pElement = new CIuExpressionLike(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionLike::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fPatternConst = false;
	//}}Initialize
}

bool CIuExpressionLike::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetType() == exprLike);
	ASSERT(GetChildCount() == 2);

	if (!m_fPatternConst)
	{
		LPCTSTR pcszValue = EvaluateChild(1, pRecord);
		m_Comparator.SetExpression(pcszValue);
	}

	LPCTSTR pcszValue = EvaluateChild(0, pRecord);
	return m_Comparator.Compare(pcszValue);
}

int CIuExpressionLike::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionLike::GetMaxLength() const
{
	// Always returns boolean "0" or "1"
	return BooiMaxLength();
}

LPCTSTR CIuExpressionLike::GetTypeName() const
{
	switch (GetType())
	{
		case exprLike:
			return "LIKE";
	}
	return CIuExpressionLike_super::GetTypeName();
}

CIuExpressionLike& CIuExpressionLike::operator=(const CIuExpressionLike& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionLike_super::operator=(rExpressionElement);
	m_fPatternConst = rExpressionElement.m_fPatternConst;
	m_Comparator = rExpressionElement.m_Comparator;
	return *this;
}

void CIuExpressionLike::Resolve(CIuResolveSpec& Spec)
{
	CIuExpressionLike_super::Resolve(Spec);
	ASSERT(GetType() == exprLike);
	ASSERT(GetChildCount() == 2);

	m_fPatternConst = GetChild(1).IsConst();
	if (m_fPatternConst)
	{
		LPCTSTR pcszValue = EvaluateChild(1, 0);
		m_Comparator.SetExpression(pcszValue);
	}
}

