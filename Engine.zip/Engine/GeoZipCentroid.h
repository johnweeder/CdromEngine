#ifndef _ENGINE_GEOZIPCENTROID_H_
#define _ENGINE_GEOZIPCENTROID_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_LATLONGCOORDINATE_H_
#	include "Engine\LatLongCoordinate.h"
#endif	// _ENGINE_LATLONGCOORDINATE_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoZipCentroid }}
// Helper class used during encoding process for geographies.
struct CIuGeoZipCentroid
{
public:
	int m_iZip;
	CIuLatLongCoordinate m_Centroid;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_GEOZIPCENTROID_H_
