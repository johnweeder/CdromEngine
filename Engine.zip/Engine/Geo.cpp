#include "StdAfx.h"
//{{Include
#include "Geo.h"
#include "AreaCode.h"
#include "Exchange.h"
#include "Zip.h"
#include "City.h"
#include "County.h"
#include "Msa.h"
#include "State.h"
#include "LatLongUnit.h"
#include "GeoRaw.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Error\Error.h"
#include "GeoConst.h"
#include "BTreeStatistics.h"
#include "CdromSpec.h"
#include "GeoSpec.h"
#include "Cdrom.h"
#include "Miscellaneous.h"
#include "SourceDescriptorSpec.h"
#include "SourceDescriptor.h"
#include "GeoList.h"
#include "RegExList.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeo, CIuGeo_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeo)
const	CIuVersionNumber versionGeoMax(2000,1,5,304);
const	CIuVersionNumber versionGeoMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEO, CIuGeo, CIuGeo_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_STATE, GetState_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_COUNTY, GetCounty_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_ZIP, GetZip_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_MSA, GetMsa_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_CITY, GetCity_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_AREACODE, GetAreaCode_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeo, IDS_ENGINE_PROP_EXCHANGE, GetExchange_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_STATE, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_COUNTY, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_ZIP, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_MSA, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_CITY, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_AREACODE, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeo, IDS_ENGINE_PROP_EXCHANGE, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuGeo, IDS_ENGINE_PPG_GEO, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeo, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeo, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_GEO, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeo, IDS_ENGINE_PROP_DATABASE, GetDatabase, SetDatabase, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeo, IDS_ENGINE_PROP_DATABASE, IDS_ENGINE_PPG_GEO, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeo::CIuGeo() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeo::~CIuGeo()
{
	Close(geoAll, true);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuGeo::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (Flags.Test(cdromsBuildCompressGeo))
		if (!BuildCompress(Cdrom, Output))
			return false;
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPack))
		if (!BuildPack(Cdrom, Output, Flags))
			return false;
	return true;
}

bool CIuGeo::BuildCompress(CIuCdrom& Cdrom, CIuOutput& Output)
{
	// Load the raw geography information
	CIuGeoRaw raw;
	raw.SetFilename(GetFilename());
	raw.Read();
	raw.CreateMaps();

	// Compress
	if (!GetState().BuildCompress(raw, raw.GetState(), Cdrom, Output))
		return false;
	if (!GetCounty().BuildCompress(raw, raw.GetCounty(), Cdrom, Output))
		return false;
	if (!GetZip().BuildCompress(raw, raw.GetZip(), Cdrom, Output))
		return false;
	if (!GetMsa().BuildCompress(raw, raw.GetMsa(), Cdrom, Output))
		return false;
	if (!GetCity().BuildCompress(raw, raw.GetCity(), Cdrom, Output))
		return false;
	if (!GetAreaCode().BuildCompress(raw, raw.GetAreaCode(), Cdrom, Output))
		return false;
	if (!GetExchange().BuildCompress(raw, raw.GetExchange(), Cdrom, Output))
		return false;

	// Do a sanity check
	Open(geoAll);
	if (!GetState().SanityCheck(raw.GetState(), Output))
		return false;
	if (!GetCounty().SanityCheck(raw.GetCounty(), Output))
		return false;
	if (!GetZip().SanityCheck(raw.GetZip(), Output))
		return false;
	if (!GetMsa().SanityCheck(raw.GetMsa(), Output))
		return false;
	if (!GetCity().SanityCheck(raw.GetCity(), Output))
		return false;
	if (!GetAreaCode().SanityCheck(raw.GetAreaCode(), Output))
		return false;
	if (!GetExchange().SanityCheck(raw.GetExchange(), Output))
		return false;
	Close(geoAll, false);

	// Create the specification for the source and index
	CIuSourceDescriptorSpecArray Specs;
	GetSourceDescriptorSpecs(Specs);
	Cdrom.CreateIndexes(Specs);

	return Output.Fire();
}


bool CIuGeo::BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildPackDatabaseObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	if (!GetState().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetCounty().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetZip().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetCity().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetMsa().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetAreaCode().BuildPack(Cdrom, Output, Flags))
		return false;
	if (!GetExchange().BuildPack(Cdrom, Output, Flags))
		return false;
	return Output.Fire();
}

void CIuGeo::Close(int iFlags, bool fForce)
{
	if ((iFlags & geoState) != 0)
		GetState().Close(fForce);
	if ((iFlags & geoCounty) != 0)
		GetCounty().Close(fForce);
	if ((iFlags & geoZip) != 0)
		GetZip().Close(fForce);
	if ((iFlags & geoMsa) != 0)
		GetMsa().Close(fForce);
	if ((iFlags & geoCity) != 0)
		GetCity().Close(fForce);
	if ((iFlags & geoAreaCode) != 0)
		GetAreaCode().Close(fForce);
	if ((iFlags & geoExchange) != 0)
		GetExchange().Close(fForce);
}

void CIuGeo::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	GetState().SetGeo(this);
	GetCounty().SetGeo(this);
	GetZip().SetGeo(this);
	GetCity().SetGeo(this);
	GetMsa().SetGeo(this);
	GetAreaCode().SetGeo(this);
	GetExchange().SetGeo(this);
	m_sFilename = "Geo";
	m_pObjectRepository = 0;
	m_sDatabase = "Database";
	SetVersion(versionGeoMax);
	//}}Initialize
}

void CIuGeo::Decode(CIuGeoCodec& codec)
{
	int iZipNo = codec.GetZipNo();

	// NOTE: This function is extremely important to the
	// performance of the engine. It access many class variables
	// directly...

	const CIuZip& Zip = GetZip().Get(iZipNo);

	codec.SetZip(Zip.GetZip());
	codec.SetMedianIncome(Zip.GetMedianIncome());
	codec.SetMedianHomeValue(Zip.GetMedianHomeValue());

	int iStateNo = Zip.GetStateNo();

	if (codec.HasNoCity())
	{
		codec.SetCity(_T(""));
	}
	else
	{
		int iCityNo = Zip.GetCityNo() + codec.GetCityDelta();
		const CIuCity& City = GetCity().Get(iCityNo);

		codec.SetCity(City.GetCity());
		LPCTSTR pcszState = City.GetState();
		if (*pcszState)
			iStateNo = GetState().Find(pcszState);
	}

	const CIuState& State = GetState().Get(iStateNo);
	codec.SetStateAbbr(State.GetStateAbbr());
	codec.SetStateCode(State.GetStateCode());
	codec.SetStateName(State.GetStateName());

	if (codec.HasNoMsa() || Zip.GetMsaNo() < 0)
	{
		codec.SetMsaName(_T(""));
		codec.SetMsaCode(0);
	}
	else
	{
		int iMsaNo = Zip.GetMsaNo() + codec.GetMsaDelta();
		const CIuMsa& Msa = GetMsa().Get(iMsaNo);

		codec.SetMsaName(Msa.GetMsaName());
		codec.SetMsaCode(Msa.GetMsaCode());
	}

	if (codec.HasNoCounty() || Zip.GetCountyNo() < 0)
	{
		codec.SetCountyCode(0);
		codec.SetCountyName(_T(""));
	}
	else
	{
		int iCountyNo = Zip.GetCountyNo() + codec.GetCountyDelta();
		const CIuCounty& County = GetCounty().Get(iCountyNo);

		codec.SetCountyName(County.GetCountyName());
		codec.SetCountyCode(County.GetCountyCode());
	}

	DWORD dwLatitude = Zip.GetLatitude();
	dwLatitude &= dwLatLongSignMask;
	DWORD dwLongitude = Zip.GetLongitude();
	dwLongitude &= dwLatLongSignMask;
	if (codec.HasNoLatLong())
	{
		dwLatitude = dwLatLongInvalid;
		dwLongitude = dwLatLongInvalid;
	}
	else
	{
		int iLatitudeDelta = codec.GetLatitudeDelta();
		int iLongitudeDelta = codec.GetLongitudeDelta();
		if (codec.GetLatLongPrecision() > 0)
		{
			iLatitudeDelta <<= codec.GetLatLongPrecision();
			iLongitudeDelta <<= codec.GetLatLongPrecision();
		}
		if (iLatitudeDelta != 0)
			dwLatitude = DWORD(int(dwLatitude) + iLatitudeDelta);
		if (dwLatitude == 0)
			dwLatitude = dwLatLongInvalid;
		if (iLongitudeDelta != 0)
			dwLongitude = DWORD(int(dwLongitude) + iLongitudeDelta);
		if (dwLongitude == 0)
			dwLongitude = dwLatLongInvalid;
		else
		{
			// Our longitude is always negative...			
			dwLongitude |= dwLatLongSignFlag;
		}
	}

	CIuLatLongUnit latitude = dwLatitude;
	CIuLatLongUnit longitude = dwLongitude;

	codec.SetLatitude(latitude);
	codec.SetLongitude(longitude);

	if (Zip.GetAreaCodeNo() >= 0)
	{
		const CIuAreaCode& AreaCode = GetAreaCode().Get(Zip.GetAreaCodeNo());
		codec.SetAreaCode(AreaCode.GetAreaCode());
	}
	else
		codec.SetAreaCode(0);

	int iPrefixes = Zip.GetPrefixCount();
	codec.m_aiPrefixes.SetSize(iPrefixes);
	for (int iPrefix = 0; iPrefix < iPrefixes; ++iPrefix)
		codec.m_aiPrefixes.SetAt(iPrefix, Zip.GetPrefix(iPrefix));
}

void CIuGeo::Delete(CIuOutput* pOutput)
{
	SaveDelete(GetFilename(), pOutput);
	GetAreaCode().Delete(pOutput);
	GetCity().Delete(pOutput);
	GetCounty().Delete(pOutput);
	GetExchange().Delete(pOutput);
	GetState().Delete(pOutput);
	GetMsa().Delete(pOutput);
	GetZip().Delete(pOutput);
}

void CIuGeo::Encode(CIuGeoCodec& codec, CIuBTreeStatistics& Stats)
{
	CString sZip = codec.GetZip();
	int iZipNo = GetZip().Find(sZip);
	if (iZipNo < 0)
		Error(IU_E_GEO_NOT_FOUND, sZip);

	ASSERT(iZipNo >= 0);
	codec.SetZipNo(iZipNo);

	const CIuZip& Zip = GetZip().Get(iZipNo);

	CString sCity = codec.GetCity();

	if (sCity.IsEmpty())
		codec.SetNoCity(true);
	else
	{
		codec.SetNoCity(false);

		int iCityNo = GetCity().Find(codec.GetStateCity());
		int iCityDelta = iCityNo - Zip.GetCityNo();
		codec.SetCityDelta(iCityDelta);

		if (iCityNo < 0)
		{
			codec.SetNoCity(true);
			TRACE("WARNING: City not found [%s]\n", LPCTSTR(codec.GetStateCity()));
		}
	}

	int iMsaCode = codec.GetMsaCode();
	if (iMsaCode == 0)
	{
		if (Zip.GetMsaNo() >= 0)
			codec.SetNoMsa(true);
		else
		{
			codec.SetMsaDelta(0);
			codec.SetNoMsa(false);
		}
	}
	else
	{
		codec.SetNoMsa(false);

		int iMsaNo = GetMsa().Find(iMsaCode, 4);
		codec.SetMsaDelta(iMsaNo - Zip.GetMsaNo());
		if (iMsaNo < 0)
		{
			codec.SetNoMsa(true);
			TRACE("WARNING: MSA not found [%04d]\n", iMsaCode);
		}
	}

	int iCountyCode = codec.GetCountyCode();
	if (iCountyCode == 0)
	{
		if (Zip.GetCountyNo() >= 0)
			codec.SetNoCounty(true);
		else
		{
			codec.SetNoCounty(false);
			codec.SetCountyDelta(0);	
		}
	}
	else
	{
		codec.SetNoCounty(false);

		int iCountyNo = GetCounty().Find(iCountyCode, 5);
		codec.SetCountyDelta(iCountyNo - Zip.GetCountyNo());
		if (iCountyNo < 0)
		{
			codec.SetNoCounty(true);
			TRACE("WARNING: County not found [%d]\n", iCountyCode);
		}
	}

	CIuLatLongUnit latitude = codec.GetLatitude();
	CIuLatLongUnit longitude = codec.GetLongitude();

	// If a centroid match... correct to the actual centroid for the
	// record. This could change the position because sometimes different
	// data sources (business/residential) may have different centroids.
	// Also correct if no lat/int assigned
	if (codec.GetMatchLevel() == latlongZip ||
		!latitude.IsValid() || !longitude.IsValid() || latitude.IsZero() || longitude.IsZero())
	{
		latitude = Zip.GetLatitude();
		longitude = Zip.GetLongitude();
	}

	bool fLatLongCorrection = false;
	DWORD dwLatitude1 = latitude;
	ASSERT(dwLatitude1 != dwLatLongInvalid);
	dwLatitude1 &= dwLatLongSignMask;
	DWORD dwLatitude2 = Zip.GetLatitude();
	ASSERT(dwLatitude2 != dwLatLongInvalid);
	dwLatitude2 &= dwLatLongSignMask;
	DWORD dwLatitudeMin = Zip.GetLatitudeMin();
	ASSERT(dwLatitudeMin != dwLatLongInvalid);
	dwLatitudeMin &= dwLatLongSignMask;
	DWORD dwLatitudeMax = Zip.GetLatitudeMax();
	ASSERT(dwLatitudeMax != dwLatLongInvalid);
	dwLatitudeMax &= dwLatLongSignMask;
	if (dwLatitude1 != 0 && dwLatitude1 < dwLatitudeMin)
	{
		fLatLongCorrection = true;
		Stats.m_iTotalLatMinMaxDelta += dwLatitudeMin - dwLatitude1;
		dwLatitude1 = dwLatitudeMin;
	}
	if (dwLatitude1 != 0 && dwLatitude1 > dwLatitudeMax)
	{
		fLatLongCorrection = true;
		Stats.m_iTotalLatMinMaxDelta += dwLatitude1 - dwLatitudeMax;
		dwLatitude1 = dwLatitudeMax;
	}

	DWORD dwLongitude1 = longitude;
	ASSERT(dwLongitude1 != dwLatLongInvalid);
	dwLongitude1 &= dwLatLongSignMask;
	DWORD dwLongitude2 = Zip.GetLongitude();
	ASSERT(dwLongitude2 != dwLatLongInvalid);
	dwLongitude2 &= dwLatLongSignMask;
	DWORD dwLongitudeMin = Zip.GetLongitudeMin();
	ASSERT(dwLongitudeMin != dwLatLongInvalid);
	dwLongitudeMin &= dwLatLongSignMask;
	DWORD dwLongitudeMax = Zip.GetLongitudeMax();
	ASSERT(dwLongitudeMax != dwLatLongInvalid);
	dwLongitudeMax &= dwLatLongSignMask;
	if (dwLongitude1 != 0 && dwLongitude1 < dwLongitudeMin)
	{
		fLatLongCorrection = true;
		Stats.m_iTotalLongMinMaxDelta += dwLongitudeMin - dwLongitude1;
		dwLongitude1 = dwLongitudeMin;
	}
	if (dwLongitude1 != 0 && dwLongitude1 > dwLongitudeMax)
	{
		fLatLongCorrection = true;
		Stats.m_iTotalLongMinMaxDelta += dwLongitude1 - dwLongitudeMax;
		dwLongitude1 = dwLongitudeMax;
	}

	if (fLatLongCorrection)
		++Stats.m_iTotalLatLongMinMaxCorrections;

	if (dwLatitude1 == 0 || dwLongitude1 == 0)
		codec.SetNoLatLong(true);
	else
	{
		codec.SetNoLatLong(false);
		int iLatitudeDelta = int(dwLatitude1) - int(dwLatitude2);
		int iLongitudeDelta = int(dwLongitude1) - int(dwLongitude2);
		if (codec.GetLatLongPrecision() > 0)
		{
			iLatitudeDelta >>= codec.GetLatLongPrecision();
			iLongitudeDelta >>= codec.GetLatLongPrecision();
		}
		codec.SetLatitudeDelta(iLatitudeDelta);
		codec.SetLongitudeDelta(iLongitudeDelta);
	}

	if (Zip.GetAreaCodeNo() >= 0)
	{
		const CIuAreaCode& AreaCode = GetAreaCode().Get(Zip.GetAreaCodeNo());
		codec.SetAreaCode(AreaCode.GetAreaCode());
	}
	else
		codec.SetAreaCode(0);

	int iPrefixes = Zip.GetPrefixCount();
	codec.m_aiPrefixes.SetSize(iPrefixes);
	for (int iPrefix = 0; iPrefix < iPrefixes; ++iPrefix)
		codec.m_aiPrefixes.SetAt(iPrefix, Zip.GetPrefix(iPrefix));
}

CIuGeoElementCollection& CIuGeo::Get(int iGeoType) const
{
	switch (iGeoType)
	{
		case geoAreaCode:
			return GetAreaCode();
		case geoCity:
			return GetCity();
		case geoCounty:
			return GetCounty();
		case geoExchange:
			return GetExchange();
		case geoMsa:
			return GetMsa();
		case geoState:
			return GetState();
		case geoZip:
			return GetZip();
	}
	ASSERT(false);
	return *(CIuGeoElementCollection*)0;
}

CIuObject* CIuGeo::GetAreaCode_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_AreaCode));
}

int CIuGeo::GetBitsRequired() const
{
	return GetZip().GetBitsRequired();
}

CIuObject* CIuGeo::GetCity_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_City));
}

CIuObject* CIuGeo::GetCounty_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_County));
}
 
CIuObject* CIuGeo::GetExchange_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_Exchange));
}

bool CIuGeo::GetGeoList(const CIuRegExList& Criteria, CString& sCriteria) const
{
	sCriteria = "";

	int iCount = Criteria.GetCount();
	if (iCount == 0)
		return true;

	CIuGeoListPtr pGeoList;
	for (int i = 0; i < iCount; ++i)
	{
		const CIuRegEx& RegEx = Criteria.Get(i);
		CString sName = RegEx.GetName();
		CIuGeoElementCollectionPtr pGeoElementCollection;
		if (sName.CompareNoCase(CIuGeoAreaCode::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetAreaCode();
		else if (sName.CompareNoCase(CIuGeoCity::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetCity();
		else if (sName.CompareNoCase(CIuGeoCounty::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetCounty();
		else if (sName.CompareNoCase(CIuGeoExchange::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetExchange();
		else if (sName.CompareNoCase(CIuGeoMsa::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetMsa();
		else if (sName.CompareNoCase(CIuGeoState::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetState();
		else if (sName.CompareNoCase(CIuGeoZip::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetZip();
		else
			continue;
		ASSERT(pGeoElementCollection.NotNull());
		CIuGeoListPtr pGeoListSub;
		pGeoListSub.Create();
		pGeoElementCollection->GetGeoList(*pGeoListSub, RegEx);
		if (pGeoListSub->IsEmpty())
			return false;
		if (pGeoList.IsNull())
			pGeoList = pGeoListSub;
		else
		{
			CIuGeoListPtr pGeoListNew;
			pGeoListNew.Create();

			pGeoListNew->Intersection(*pGeoList, *pGeoListSub);
			pGeoList = pGeoListNew;
		}
		if (pGeoList->IsEmpty())
			return false;
	}

	if (pGeoList.IsNull())
		return true;

	iCount = pGeoList->GetCount();
	for (int iRange = 0; iRange < iCount; ++iRange)
	{
		int iLo, iHi;
		pGeoList->Get(iRange, iLo, iHi);
		ASSERT(iLo <= iHi);

		// NOTE: Place a wildcard on the ZIP codes so that
		//			we can also match against a ZIP+4 index
		if (!sCriteria.IsEmpty())
			sCriteria += _T(",");
		if (iLo == iHi)
		{
			sCriteria += GetZip().GetElementName(iLo);
			sCriteria += _T("*");
		}
		else
		{
			sCriteria += GetZip().GetElementName(iLo);
			sCriteria += _T("*");
			sCriteria += _T("~");
			sCriteria += GetZip().GetElementName(iHi);
			sCriteria += _T("*");
		}
	}
	return sCriteria;
}

void CIuGeo::GetGeoListFilter(CIuRegExList& Criteria, CStringArray& asFilter)	const
{
	int iCount = Criteria.GetCount();
	if (iCount == 0)
		return ;

	for (int i = iCount - 1; i >= 0; --i)
	{
		const CIuRegEx& RegEx = Criteria.Get(i);
		CString sName = RegEx.GetName();
		CIuGeoElementCollectionPtr pGeoElementCollection;
		if (sName.CompareNoCase(CIuGeoAreaCode::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetAreaCode();
		else if (sName.CompareNoCase(CIuGeoCity::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetCity();
		else if (sName.CompareNoCase(CIuGeoCounty::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetCounty();
		else if (sName.CompareNoCase(CIuGeoExchange::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetExchange();
		else if (sName.CompareNoCase(CIuGeoMsa::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetMsa();
		else if (sName.CompareNoCase(CIuGeoState::GetIndexStatic()) == 0)
			pGeoElementCollection = &GetState();
		else
			continue;

		pGeoElementCollection->GetGeoListFilter(RegEx, asFilter);
		Criteria.Remove(i);
	}
}

LPCTSTR CIuGeo::GetIndex()
{
	return _T("Geo");
}

CIuObject* CIuGeo::GetMsa_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_Msa));
}

void CIuGeo::GetSourceDescriptorCriteria(CIuSourceDescriptorSpec& Spec) const
{
	Spec.AddCriteria(CIuMoniker(CIuGeoAreaCode::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoCity::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoCounty::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoExchange::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoMsa::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoState::GetIndexStatic(), GetID()), sourceGeo);
	Spec.AddCriteria(CIuMoniker(CIuGeoZip::GetIndexStatic(), GetID()), sourceGeo);
}

void CIuGeo::GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const
{
	ASSERT(HasObjectRepository());

	Specs.RemoveAll();

	// This is the master geo source
	CIuSourceDescriptorSpec Spec;
	Spec.SetID(GetID());
	Spec.SetDatabase(GetDatabase());
	Spec.SetIndex(GetIndex());
	Spec.SetSource(GetMoniker());
	Spec.SetSourceType(sourceGeo);

	Specs.Add(Spec);

	CIuSourceDescriptorSpecArray SpecsSubObject;

	GetState().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetCounty().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetZip().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetMsa().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetCity().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetAreaCode().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);
	GetExchange().GetSourceDescriptorSpecs(SpecsSubObject);
	Specs.Append(SpecsSubObject);

	// Attach a database name to each of the source descriptors
	for (int iSpec = 0; iSpec < Specs.GetSize(); ++iSpec)
		Specs.ElementAt(iSpec).SetDatabase(GetDatabase());
}

CIuObject* CIuGeo::GetState_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_State));
}

CIuVersionNumber CIuGeo::GetVersionMax() const
{
	return versionGeoMax;
}

CIuVersionNumber CIuGeo::GetVersionMaxStatic()
{
	return versionGeoMax;
}

CIuVersionNumber CIuGeo::GetVersionMin() const
{
	return versionGeoMin;
}

CIuVersionNumber CIuGeo::GetVersionMinStatic()
{
	return versionGeoMin;
}

CIuObject* CIuGeo::GetZip_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(&m_Zip));
}

void CIuGeo::Open(int iFlags)
{
#ifdef _DEBUG
	time_t timeStart = time(0);
#endif
	if ((iFlags & geoState) != 0)
		GetState().Open();
	if ((iFlags & geoCounty) != 0)
		GetCounty().Open();
	if ((iFlags & geoZip) != 0)
		GetZip().Open();
	if ((iFlags & geoMsa) != 0)
		GetMsa().Open();
	if ((iFlags & geoCity) != 0)
		GetCity().Open();
	if ((iFlags & geoAreaCode) != 0)
		GetAreaCode().Open();
	if ((iFlags & geoExchange) != 0)
		GetExchange().Open();
#ifdef _DEBUG
	time_t timeNow = time(0);
	int iElapsed = timeNow - timeStart;
	TRACE("OPEN: Geographies opened in %d seconds.\n", iElapsed);
#endif
}

bool CIuGeo::Request(CString& sResult, const CStringArray& as)
{
	if (GetState().Request(sResult, as))
		return true;
	if (GetCounty().Request(sResult, as))
		return true;
	if (GetZip().Request(sResult, as))
		return true;
	if (GetMsa().Request(sResult, as))
		return true;
	if (GetCity().Request(sResult, as))
		return true;
	if (GetAreaCode().Request(sResult, as))
		return true;
	if (GetExchange().Request(sResult, as))
		return true;
	// Currently no requests are handled at the geo level
	return RequestGeo(sResult, as);
}

bool CIuGeo::RequestGeo(CString&, const CStringArray&)
{
	// NOTE: as[0] is the request type
	return false;
}

void CIuGeo::SetDatabase(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDatabase = pcsz;
}

void CIuGeo::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuGeo::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
	GetState().SetObjectRepository(pObjectRepository);
	GetCounty().SetObjectRepository(pObjectRepository);
	GetZip().SetObjectRepository(pObjectRepository);
	GetCity().SetObjectRepository(pObjectRepository);
	GetMsa().SetObjectRepository(pObjectRepository);
	GetAreaCode().SetObjectRepository(pObjectRepository);
	GetExchange().SetObjectRepository(pObjectRepository);
}

void CIuGeo::SetSpec(CIuGeoSpec& Spec)
{
	SetDatabase(Spec.GetCdrom().GetName());
	SetMoniker(Spec.GetMoniker());

	SetFilename(Spec.GetCdrom().GetFilename());

	GetAreaCode().SetSpec(Spec);
	GetCity().SetSpec(Spec);
	GetCounty().SetSpec(Spec);
	GetExchange().SetSpec(Spec);
	GetState().SetSpec(Spec);
	GetZip().SetSpec(Spec);
	GetMsa().SetSpec(Spec);
}

bool CIuGeo::Within(CString& sKeys, const CIuLatLongCoordinate& Coord1, const CIuLatLongCoordinate& Coord2) const
{
	GetZip().Open();
	bool fResult = GetZip().Within(sKeys, Coord1, Coord2);
	GetZip().Close();
	return fResult;
}

