#ifndef _ENGINE_CDROMSTRIPSPEC_H_
#define _ENGINE_CDROMSTRIPSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
struct CIuCdromStripSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromStripSpec, CIuObjectNamed }}
#define CIuCdromStripSpec_super CIuObjectNamed

class CIuCdromStripSpec : public CIuCdromStripSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromStripSpec)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromStripSpec();
	virtual ~CIuCdromStripSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetFilename() const;
	int GetSortNo() const;
	int GetStripNo() const;
	CIuTokenSpec& GetToken(int iToken) const;
	int GetTokenCount() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iCdromStripSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszIndex);
	void FromNo(CIuCdromSpec* pCdrom, int iIndexNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuCdromStripSpecDft* pCdromStripSpec);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetFilename(LPCTSTR);
	void SetSortNo(int iSortNo);
	void SetStripNo(int iStripNo);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iStripNo;
	int m_iSortNo;
	CString m_sFilename;
	CIuCdromSpec* m_pCdrom;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuCdromStripSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuCdromStripSpec::GetFilename() const
{
	return m_sFilename;
}

inline int CIuCdromStripSpec::GetSortNo() const
{
	return m_iSortNo;
}

inline int CIuCdromStripSpec::GetStripNo() const
{
	return m_iStripNo;
}

inline bool CIuCdromStripSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_CDROMSTRIPSPEC_H_
