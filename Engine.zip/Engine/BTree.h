#ifndef _ENGINE_BTREE_H_
#define _ENGINE_BTREE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_DATA_H_
#	include "Data\Data.h"
#endif	// _DATA_DATA_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_BTREEDATA_H_
#	include "Engine\BTreeData.h"
#endif	// _ENGINE_BTREEDATA_H_
#ifndef 	_ENGINE_BTREECODEC_H_
#	include "Engine\BTreeCodec.h"
#endif	// _ENGINE_BTREECODEC_H_
#ifndef 	_ENGINE_BTREESTATISTICS_H_
#	include "Engine\BTreeStatistics.h"
#endif	// _ENGINE_BTREESTATISTICS_H_
#ifndef 	_ENGINE_ALTTRANSLATE_H_
#	include "Engine\AltTranslate.h"
#endif	// _ENGINE_ALTTRANSLATE_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBTree)
IU_DEFINE_OBJECT_PTR(CIuBTreeCodec)
IU_DEFINE_OBJECT_PTR(CIuBTreeIndex)
IU_DEFINE_OBJECT_PTR(CIuBTreeData)
IU_DEFINE_OBJECT_PTR(CIuBTreePointers)
class CIuBTrees;
class CIuKeyRange;
class CIuCdromSpec;
class CIuCdrom;
class CIuSetList;
class CIuSetLists;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
// BTree file types
enum CIuBTreeNo
{
	btreeNone = 0,

	btreeAddress,
	btreeBusiness,
	btreeBusinessFranchise,
	btreeName104m_2001,
	btreeName88md_2001,
	btreeNameAc_V1,
	btreeNameBml_2000,
	btreeNameCi_V1,
	btreeNameOam_V1,
	btreeNamePbm_V1,
	btreeNamePb_2001,
	btreeNamePf_2001,
	btreeNamePg_2000,
	btreeNamePu_2001,
	btreeNameRboc_2000,
	btreeNameRp_2001,
	btreeNameSlu_2000,
	btreeNameSample,
	btreeNameYpu_2001,
	btreePhone,
	btreeZip4,
	btreeZip5,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBTree, CIuCollectable }}
#define CIuBTree_super CIuCollectable

class CIuBTree : public CIuBTree_super
{
//{{Declare
	DECLARE_SERIAL(CIuBTree)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBTree();
	virtual ~CIuBTree();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool CreateTranslation() const;
	bool Get(int iRecord, CIuRecordPtr& pRecord, bool fExpanded);
	bool Get(int iRecord, CIuKey& Key);
	CIuMoniker GetAltMoniker() const;
	int GetBlockSize() const;
	CIuMoniker GetBTreeExpand() const;
	CIuBTreePtr GetBTreeExpandPtr() const;
	CIuBTrees& GetBTrees() const;
	int GetCount(bool fExpanded) const;
	CString GetDatabase() const;
	CString GetFilename() const;
	CIuGeo& GetGeo() const;
	int GetKeyStart(const CIuKey& Key, int& iRange) const;
	int GetMinimumRecordSize() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuRecordDef& GetRecordDef(bool fExpanded = false) const;
	void GetSourceDescriptorSpecs(CIuSourceDescriptorSpecArray& Specs) const;
	CIuBTreeStatistics& GetStats();
	CString GetTranslationFilename() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasData() const;
	bool HasGeo() const;
	bool HasMultiPointers() const;
	bool HasObjectRepository() const;
	bool HasPointers() const;
	bool IsAltComma() const;
	bool IsDefaultSource() const;
	bool IsOpen() const;
	bool UseTranslation() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool AddSetList(CIuSetLists& SetList, CIuOutput* pOutput, CIuID& ID, UINT32 uiLo, UINT32 uiCount, UINT32 uiMin = 0, UINT32 uiMax = UINT32(-1));
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close();
	void Create(CIuOutput& Output);
	void Delete(CIuOutput* pOutput = 0);
	bool ExpandSetList(CIuSetLists& SetLists, CIuOutput* pOutput, CIuID& ID, UINT32 uiRecNo, UINT32 uiCount);
	void Open(bool fDebug);
	bool SanityCheck(CIuCdrom& Cdrom, CIuOutput& Output);
	void SetAltComma(bool);
	void SetAltMoniker(const CIuMoniker&);
	void SetBlockSize(int);
	void SetBTreeExpand(const CIuMoniker&);
	void SetCreateTranslation(bool);
	void SetDatabase(LPCTSTR);
	void SetDefaultSource(bool);
	void SetFilename(LPCTSTR);
	void SetHasData(bool = true);
	void SetHasMultiPointers(bool = true);
	void SetHasPointers(bool = true);
	void SetMinimumRecordSize(int);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuBTreeSpec& Spec);
	void SetTranslationFilename(LPCTSTR);
	void SetUseTranslation(bool);
	bool TryHarder(CIuKeyRange& Range);
	bool Within(CString& sKeys, const CIuLatLongCoordinate& Coord1, const CIuLatLongCoordinate& Coord2) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetCodec_() const;
	CIuObject* GetData_() const;
	CIuObject* GetIndex_() const;
	CIuObject* GetPointers_() const;

protected:
	friend class CIuBTreeData;
	friend class CIuBTreeCodec;
	friend class CIuBTreeIndex;
	friend class CIuBTreePointers;

	void AttachBTreeExpand() const;
	bool BuildCompress(CIuCdrom& Cdrom, CIuOutput& Output);
	bool BuildPack(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	CIuBTreeCodec& GetCodec() const;
	CIuBTreeData& GetData() const;
	CIuBTreeIndex& GetIndex() const;
	CIuBTreePointers& GetPointers() const;
private:
	bool Get(int iRecord, CIuRecordSpec& RecordSpec, bool fExpanded);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	CIuBTreeStatistics m_Stats;
protected:
	// A semaphore to control access by multiple threads. 
	// Many buffers are used internally for performance, however, the
	// use of these buffers causes re-entrancy problems.
	// At a future date, we may want to work on a re-entrant betree class.
	mutable CMutex m_cs;
private:
	// Number of pending open's against this file
	int m_iOpen;
	// Data related to the persistent storage location
	CIuObjectRepository* m_pObjectRepository;
	// Internal flag indicating debug mode (normally pulled from engine)
	bool m_fDebug;
	// Pointer to open btree which is used to expand 
	// records from pointers
	mutable CIuBTreePtr m_pBTreeExpand;
	// A temporary raw record used to retrieve keys for expanded records.
	// It's use is protected by the semaphore.
	mutable int m_lRecordNoKey;
	mutable CIuRecordSpec m_RecordSpecKey;
	// A temporary buffer used to create records!
	mutable CIuRecordSpec m_RecordSpec;
	// The record def for this BTree
	mutable CIuRecordDefPtr m_pRecordDef;
	mutable CIuRecordDefPtr m_pRecordDefExpand;
	// Persistent data
	int m_iBlockSize;
	CIuBTreeCodecPtr m_pCodec;
	CIuBTreeIndexPtr m_pIndex;
	CIuBTreeDataPtr m_pData;
	CIuBTreePointersPtr m_pPointers;
	bool m_fHasPointers;
	bool m_fHasData;
	bool m_fHasMultiPointers;
	CIuMoniker m_monikerBTreeExpand;
	CString m_sFilename;
	int m_iMinimumRecordSize;

	// These variables are used to manage a translation of record no's to
	// account for see also records which have been inserted
	bool m_fCreateTranslation;
	bool m_fUseTranslation;
	CString m_sTranslationFilename;
	CIuAltTranslate m_AltTranslate;

	// These control the "try harder" logic
	// This is the "alternates file" for the try harder.
	CIuMoniker m_monikerAltMoniker;
	// Alternate records file (try harder)
	CIuAltPtr m_pAlt;
	// This flag controls is for keys where we only use the text
	// up to the first comma (Used in "Last, First" indexes)
	bool m_fAltComma;
	bool m_fDefaultSource;
	// Owning database name
	CString m_sDatabase;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuBTree::CreateTranslation() const
{
	return m_fCreateTranslation;
}

inline CIuMoniker CIuBTree::GetAltMoniker() const
{
	return m_monikerAltMoniker;
}

inline CIuMoniker CIuBTree::GetBTreeExpand() const
{
	return m_monikerBTreeExpand;
}

inline CIuBTreePtr CIuBTree::GetBTreeExpandPtr() const
{
	return m_pBTreeExpand;
}

inline CIuBTreeCodec& CIuBTree::GetCodec() const
{
	return m_pCodec.Ref();
}

inline CIuBTreeData& CIuBTree::GetData() const
{
	return m_pData.Ref();
}

inline CString CIuBTree::GetDatabase() const
{
	return m_sDatabase;
}

inline CIuBTreeIndex& CIuBTree::GetIndex() const
{
	return m_pIndex.Ref();
}

inline int CIuBTree::GetMinimumRecordSize() const
{
	return m_iMinimumRecordSize;
}

inline CIuObjectRepository& CIuBTree::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CIuBTreePointers& CIuBTree::GetPointers() const
{
	return m_pPointers.Ref();
}

inline CIuBTreeStatistics& CIuBTree::GetStats()
{
	return m_Stats;	
}

inline CString CIuBTree::GetTranslationFilename() const
{
	return m_sTranslationFilename;
}

inline bool CIuBTree::HasData() const
{
	return m_fHasData;
}

inline bool CIuBTree::HasMultiPointers() const
{
	return m_fHasMultiPointers;
}

inline bool CIuBTree::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuBTree::HasPointers() const
{
	return m_fHasPointers || m_fHasMultiPointers;
}

inline bool CIuBTree::IsAltComma() const
{
	return m_fAltComma;
}

inline bool CIuBTree::IsDefaultSource() const
{
	return m_fDefaultSource;
}

inline bool CIuBTree::UseTranslation() const
{
	return m_fUseTranslation;
}

#endif // _ENGINE_BTREE_H_
