#include "stdafx.h" 
//{{Include
#include "engine.h"
#include "ExportDef.h"
#include "ExportDefSpec.h"
#include "ExportFieldDefs.h"
#include "ExportFieldDef.h"
#include "ExportFieldDefSpec.h"
#include "resource.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportFieldDefs, CIuExportFieldDefs_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportFieldDefs)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTFIELDDEFS, CIuExportFieldDefs, CIuExportFieldDefs_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuExportFieldDefs, IDS_ENGINE_PPG_EXPORTFIELDDEFS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuExportFieldDefs, IDS_ENGINE_PPG_EXPORTFIELDDEFS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuExportFieldDefs::CIuExportFieldDefs()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportFieldDefs::CIuExportFieldDefs(const CIuExportFieldDefs& rExportFieldDefs)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rExportFieldDefs;
}

CIuExportFieldDefs::~CIuExportFieldDefs()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}
												  
/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExportFieldDefs::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pExportDef = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuExportFieldDefs::Copy(const CIuObject& object)
{
	CIuExportFieldDefs_super::Copy(object);

	const CIuExportFieldDefs* pExportFieldDefs = dynamic_cast<const CIuExportFieldDefs*>(&object);
	if (pExportFieldDefs == 0 || pExportFieldDefs == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuExportFieldDefs)));
}

int CIuExportFieldDefs::CreateFieldDef(LPCTSTR pcszDef)
{
	CIuExportFieldDefSpec spec(pcszDef);
	return CreateFieldDef(spec);
}

int CIuExportFieldDefs::CreateFieldDef(CIuExportFieldDefSpec& spec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuExportFieldDef& FieldDef = Get(iIndex);
	FieldDef.SetSpec(spec);
	return iIndex;
}

CIuExportDef& CIuExportFieldDefs::GetExportDef() const
{
	ASSERT(m_pExportDef);
	return *m_pExportDef;
}

CIuCollectablePtr CIuExportFieldDefs::OnNew(CWnd*) const
{
	CIuExportFieldDefPtr pExportFieldDef;
	pExportFieldDef.Create();
	return CIuObjectPtr(pExportFieldDef);
}

CIuExportFieldDefs& CIuExportFieldDefs::operator=(const CIuExportFieldDefs& rExportFieldDefs)
{
	Copy(rExportFieldDefs);
	return *this;
}

void CIuExportFieldDefs::SetExportDef(CIuExportDef* pExportDef)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pExportDef = pExportDef;
}


void CIuExportFieldDefs::SetSpec(CIuExportDefSpec& ExportDefSpec)
{
	RemoveAll();

	for (int iField = 0; iField < ExportDefSpec.GetFieldDefCount(); ++iField)
		CreateFieldDef(ExportDefSpec.GetFieldDef(iField));
}
