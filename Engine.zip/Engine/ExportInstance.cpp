#include "StdAfx.h"
//{{Include
#include "ExportInstance.h"
#include "Export.h"
#include "ExportDefs.h"
#include "Engine.h"
#include "Exporter.h"
#include "Exporters.h"
#include "Queries.h"
#include "Query.h"
#include "RecordSet.h"
#include "RecordDef.h"
#include "Error\Error.h"
#include "XChgFile.h"
#include "FieldMap.h"
#include "resource.h"
#include "Common\FileFlipBits.h"
#include "Common\MessagePump.h"
#include "Common\Options.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportInstance, CIuExportInstance_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportInstance)
//}}Implement

CIuExportInstance::CIuExportInstance() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportInstance::~CIuExportInstance()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExportInstance::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	//}}Initialize
}

int CIuExportInstance::Export(CIuExport& Export)
{
	CIuOptions ExportOptions = Export.GetOptions();
	// This is the basic exporting logic.
	// It was inserted by JohnW... Herbie/Jerry needs to expand this to full functionality.

	// Get a reference to the engine
	CIuEngine& Engine = Export.GetEngine();

	// Locate the export definition
	CString sExportDef = Export.GetExportDef();
	int iExportDef = Engine.GetExportDefs().Find(sExportDef);
	if (iExportDef < 0)
		Error(IU_E_EXPORTDEF_NOT_FOUND, LPCTSTR(sExportDef));
	CIuExportDef& exportDef = Engine.GetExportDefs().Get(iExportDef);

	// Locate the exporter
	CString sExporter = exportDef.GetExporter();
	int iExporter = Engine.GetExporters().Find(sExporter);
	if (iExporter < 0)
		Error(IU_E_EXPORTER_NOT_FOUND, LPCTSTR(sExporter));
	CIuExporter& exporter = Engine.GetExporters().Get(iExporter);

	// Get options for the export def
	CIuOptions ExportDefOptions = exportDef.GetOptions();
	// Create an "exchange" file to export in to.
	// Pass export def options to CreateXChgFile.
	// The definitions (see ..\ExportDefSpec.cpp) sometime alter the default
	// begin/end/separator/terminator values for delimited file formats
	// via the NoXChgBegin,XChgBegin=value, NoXChgEnd,XChgEnd=value... options.
	CIuOpenSpec OpenSpec;
	OpenSpec.m_pOptions = &ExportDefOptions;
	CIuXChgFilePtr pFile = exporter.CreateXChgFile(OpenSpec);

	// If no query, create a query and run it
	if (!Export.HasQuery())
	{
		int iQuery = Engine.GetQueries().Add();
		CIuQuery& Query = Engine.GetQueries().Get(iQuery);
		CString sExpression = Export.GetExpression();
		if (!Export.GetOptions().IsEmpty())
		{
			sExpression += CString(" OPTIONS ");
			sExpression += Export.GetOptions();
		}
		Query.SetExpression(sExpression);
		Query.Start();
		Query.Complete();
		Export.SetQuery(&Query);
	}

	// Get shortcut to query
	ASSERT(Export.HasQuery());
	CIuQuery& Query = Export.GetQuery();

	// Resolve the mapping based on the record set in the query
	CIuRecordSet& recordSet= Query.GetRecordSet();

	// Create a "mapping" from the query to the export definition
	CIuFieldMap map;
	map.SetCaseConvert(recordSet.m_Convert.GetCaseConvert());

	int iFields = exportDef.GetFieldDefs().GetCount();
	ASSERT(iFields > 0);
	for (int iField = 0; iField < iFields; ++iField)
	{
		CString sExpression = exportDef.GetFieldDefs().Get(iField).GetSpecification();
		map.AddField(sExpression);
	}

	CIuResolveSpec Spec;
	Spec.m_pRecordDefSrc = recordSet.GetRecordDef();
	CIuRecordDef RecordDef;
	Spec.m_pRecordDefDst = &RecordDef;
	Spec.m_pObjectRepository = &Engine.GetObjectRepository();
	Spec.m_pOptions = &ExportOptions;
	map.Resolve(Spec);

	ASSERT(RecordDef.GetFieldDefs().GetCount() == exportDef.GetFieldDefs().GetCount());

	// Copy the record definition from the mapping to the output file
	pFile->GetRecordDef().Copy(RecordDef);

	ASSERT(pFile->GetRecordDef().GetFieldDefs().GetCount() == exportDef.GetFieldDefs().GetCount());

	// Perform the special checks... set the field offset and length if needed.
	// Calculate the maximum bought level.
	// Calculate the record length
	iFields = pFile->GetRecordDef().GetFieldDefs().GetCount();
	int iNextOffset = 0;
	int iBoughtLevel = 0;
	for (iField = 0; iField < iFields; ++iField)
	{
		CIuFieldDef& fieldDef = pFile->GetRecordDef().GetFieldDefs().Get(iField);
		CIuExportFieldDef& exportFieldDef = exportDef.GetFieldDefs().Get(iField);
		if (exportFieldDef.GetLength() >= 0)
			fieldDef.SetLength(exportFieldDef.GetLength());
		if (exportFieldDef.GetOffset() >= 0)
			fieldDef.SetOffset(exportFieldDef.GetOffset());
		else
			fieldDef.SetOffset(iNextOffset);

		iBoughtLevel = max(iBoughtLevel, fieldDef.GetBoughtLevel());

		iNextOffset = fieldDef.GetLength() + fieldDef.GetOffset();
	}
	pFile->GetRecordDef().SetRecordLength(exportDef.GetRecordLength());
	pFile->GetRecordDef().Adjust();

	// Open the output file (either as new or append)
	if (ExportOptions.FindValueAsBool(IDS_ENGINE_PROP_APPEND, false))
		pFile->Open(Export.GetFilename(), CIuFile::openReadWrite);
	else
		pFile->Open(Export.GetFilename(), CIuFile::openCreate);

	// Set up the output
	CIuOutput& Output = Export.GetOutput();

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	// Use the record source directly (for performance)
	CIuSource& Source = Query.GetRecordSet().GetSource();

	CIuRecordPtr pRecordIn;
	CIuRecordPtr pRecordOut;
	iFields = RecordDef.GetFieldDefs().GetCount();
	int iRecords = Source.GetCount(sourceModeDefault);
	if (Export.GetMaxRecords() > 0)
		iRecords = min(iRecords, Export.GetMaxRecords());

	// Output description, set range, etc
	Output.SetPosition(0);
	Output.SetRange(iRecords);
	Output.OutputF(_T("Exporting %ld records to %s\n"), iRecords, LPCTSTR(Export.GetFilename()));
	Output.SetMessageF(_T("Exporting %ld records to %s\n"), iRecords, LPCTSTR(Export.GetFilename()));
	Output.Fire();

	// Do the actual export
	// First, write the optional header record of int/short field names
	bool fHasHeader = false;
	int iWhich = ExportDefOptions.Find(_T("HasHeader"));
	if (iWhich >= 0)
	{
		fHasHeader = true;  // since option is present
		if (ExportDefOptions.HasValue(iWhich))
			fHasHeader = ExportDefOptions.GetValueAsBool(iWhich);  // use value specified
	}
	if (fHasHeader)
	{
		// Determine which type of field names to write to the header record
		enum EHeaderFieldNames { eLong, eShort, eDefault = eLong };
		int iWhich = ExportDefOptions.Find(_T("HeaderNames"));
		EHeaderFieldNames HeaderFieldNames = eDefault;
		if (iWhich >= 0 && ExportDefOptions.HasValue(iWhich))
		{
			CString sHeaderNames = ExportDefOptions.GetValue(iWhich);
			if (sHeaderNames.CompareNoCase(_T("Long")) == 0)
				HeaderFieldNames = eLong;
			else if (sHeaderNames.CompareNoCase(_T("Short")) == 0)
				HeaderFieldNames = eShort;
		}
		// Write the header record of int or short names
		pFile->AppendRecord();
		for (iField = 0; iField < iFields; ++iField)
		{
			CIuFieldDef& FieldDef = pFile->GetRecordDef().GetFieldDefs().Get(iField);
			CString sHeaderFieldName;
			switch (HeaderFieldNames)
			{
			case eLong:
				sHeaderFieldName = FieldDef.GetLongName();
				break;
			case eShort:
				sHeaderFieldName = FieldDef.GetShortName();
				break;
			}
			pFile->SetField(iField, sHeaderFieldName);
		}
	}
	// Write records to the exchange file.
	int iRecordsExported = 0;
	for (int iRecord = 0; iRecord < iRecords; ++iRecord)
	{
		// Send progress events every so often
		if ((iRecord % ((iRecords + 99) / 100)) == 0)
		{
			Output.SetPosition(iRecord);
			if (!Output.Fire(IU_EVENT_OPERATION_PROGRESS))
				break;
		}

		// When running single threaded, periodically pump messages
		// This call can be removed when threading support is added to exporting
		if ((iRecord % 100) == 0)
			PumpMessages();

		// Get the record. Buy it if needed
		Source.Get(iRecord, pRecordIn, sourceModeNormal);
#pragma __TODO("Handle buying records...")
		// Map the record to the output
		pRecordOut.Map(*pRecordIn, map);

		// Append a record to the file and then set each of the fields.
		pFile->AppendRecord();
		for (iField = 0; iField < iFields; ++iField)
			pFile->SetField(iField, pRecordOut->GetField(iField));
		// Update # of records exported
		++iRecordsExported;
	}

	// Release the file.
	pFile->Close();

	// Encrypt the file if necessary
	CString sEncryption = ExportDefOptions.FindValue(_T("Encryption"), _T(""));
	bool fFlipBits = sEncryption.CompareNoCase(_T("FlipBits")) == 0;
	if (fFlipBits)
	{
		CString sFilename = pFile->GetFilename();
		Output.SetMessageF("Encrypting exported file '%s'.", LPCTSTR(sFilename));
		Output.Fire(IU_EVENT_OPERATION_CONTINUE);
		FileFlipBits(sFilename);
	}

	// Release the file
	pFile.Release();

	// Display elapsed time
	instance.Pop(true);

	// Return # of records exported.
	return iRecordsExported;
}

