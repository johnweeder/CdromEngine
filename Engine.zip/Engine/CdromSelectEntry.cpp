#include "StdAfx.h"
//{{Include
#include "CdromSelectEntry.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuCdromSelectEntry::CIuCdromSelectEntry()
{
	CommonConstruct();
}

CIuCdromSelectEntry::CIuCdromSelectEntry(HTREEITEM Item, LPCTSTR pcszApplication, LPCTSTR pcszRelease, LPCTSTR pcszGroup, LPCTSTR pcszProduct, int iSpec)
{
	CommonConstruct();
	SetItem(Item);
	SetApplication(pcszApplication);
	SetGroup(pcszGroup);
	SetProduct(pcszProduct);
	SetRelease(pcszRelease);
	SetSpecNo(iSpec);
}

CIuCdromSelectEntry::CIuCdromSelectEntry(const CIuCdromSelectEntry& rCdromSelectEntry)
{
	CommonConstruct();
	*this = rCdromSelectEntry;
}
CIuCdromSelectEntry::~CIuCdromSelectEntry()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCdromSelectEntry::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sApplication = "";
	m_sRelease = "";
	m_sGroup = "";
	m_sProduct = "";
	m_iSpecNo = -1;
	m_Item = 0;
	m_fChecked = false;
	//}}Initialize
}

CIuCdromSelectEntry& CIuCdromSelectEntry::operator=(const CIuCdromSelectEntry& rCdromSelectEntry)
{
	if (this == &rCdromSelectEntry)
		return *this;
	m_sApplication = rCdromSelectEntry.m_sApplication;
	m_sRelease = rCdromSelectEntry.m_sRelease;
	m_sGroup = rCdromSelectEntry.m_sGroup;
	m_sProduct = rCdromSelectEntry.m_sProduct;
	m_iSpecNo = rCdromSelectEntry.m_iSpecNo;
	m_Item = rCdromSelectEntry.m_Item;
	m_fChecked = rCdromSelectEntry.m_fChecked;
	return *this;
}

void CIuCdromSelectEntry::SetApplication(LPCTSTR pcsz)
{
	m_sApplication = pcsz;
}

void CIuCdromSelectEntry::SetChecked(bool f)
{
	m_fChecked = f;
}

void CIuCdromSelectEntry::SetGroup(LPCTSTR pcsz)
{
	m_sGroup = pcsz;
}

void CIuCdromSelectEntry::SetItem(HTREEITEM Item)
{
	m_Item = Item;
}

void CIuCdromSelectEntry::SetProduct(LPCTSTR pcsz)
{
	m_sProduct = pcsz;
}

void CIuCdromSelectEntry::SetRelease(LPCTSTR pcsz)
{
	m_sRelease = pcsz;
}

void CIuCdromSelectEntry::SetSpecNo(int iSpecNo)
{
	m_iSpecNo = iSpecNo;
}

