#ifndef _ENGINE_INPUTMSA_H_
#define _ENGINE_INPUTMSA_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTRECORDFILE_H_
#	include "Engine\InputRecordFile.h"
#endif	// _ENGINE_INPUTRECORDFILE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInputMsa)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInputMsa, CIuInputRecordFile }}
#define CIuInputMsa_super CIuInputRecordFile

class CIuInputMsa : public CIuInputMsa_super
{
//{{Declare
	DECLARE_SERIAL(CIuInputMsa)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInputMsa();
	virtual ~CIuInputMsa();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Delete(CIuOutput* pOutput);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual bool OnMoveNext();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnOutput();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Input file
	CStdioFile m_FileInput;
	CStdioFile m_FileOutput;
	// Temporary strings to process input
	CString m_sInput;
	CString m_sOutput;
	CString m_sMsaCode;
	CString m_sMsaName;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_INPUTMSA_H_
