#ifndef _ENGINE_RELEASENOTES_H_ 
#define _ENGINE_RELEASENOTES_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RELEASENOTE_H_
#	include "Engine\ReleaseNote.h"
#endif	// _ENGINE_RELEASENOTE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReleaseNotes)
class CIuEngine;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReleaseNotes, CIuCollection }}
#define CIuReleaseNotes_super CIuCollection

class IU_CLASS_EXPORT CIuReleaseNotes : public CIuReleaseNotes_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuReleaseNotes)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReleaseNotes();           
	virtual ~CIuReleaseNotes();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuReleaseNote& Get(const CIuMoniker& moniker) const;
	CIuReleaseNote& Get(LPCTSTR s) const;
	CIuReleaseNote& Get(int iIndex) const;
	CIuReleaseNote& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	bool CheckVersion(LPCTSTR pcszName, CIuVersionNumber version, bool fShowDlg = true, CWnd* pParent = 0);
	void Create(CIuReleaseNoteSpec& ReleaseNoteSpec);
	void SetEngine(CIuEngine& Engine);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuReleaseNote& CIuReleaseNotes::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuReleaseNote*>(&CIuCollection::Get(moniker));
}

inline CIuReleaseNote& CIuReleaseNotes::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuReleaseNote*>(&CIuCollection::Get(s));
}

inline CIuReleaseNote& CIuReleaseNotes::Get(int iIndex) const
{
	return *dynamic_cast<CIuReleaseNote*>(&CIuCollection::Get(iIndex));
}

inline CIuReleaseNote& CIuReleaseNotes::Get(CIuID id) const
{
	return *dynamic_cast<CIuReleaseNote*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuReleaseNotes::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

inline bool CIuReleaseNotes::HasEngine() const
{
	return m_pEngine!=0;
}

#endif // _ENGINE_RELEASENOTES_H_
