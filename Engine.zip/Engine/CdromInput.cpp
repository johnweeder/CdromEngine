#include "StdAfx.h"
//{{Include
#include "CdromInput.h"
#include "CdromSpec.h"
#include "Cdrom.h"
#include "resource.h"
#include "InputBusiness.h"
#include "InputResidential.h"
#include "InputSample.h"
#include "GeoScan.h"
#include "CdromStrips.h"
#include "SicScan.h"
#include "AddressScan.h"
#include "TokenScans.h"
#include "RecordSort.h"
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromInput, CIuCdromInput_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromInput)
const	CIuVersionNumber versionCdromInputMax(2000,1,5,304);
const	CIuVersionNumber versionCdromInputMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMINPUT, CIuCdromInput, CIuCdromInput_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_TOKENS, GetTokenScans_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_TOKENS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_INDEXES, GetIndexes_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_INDEXES, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuCdromInput, IDS_ENGINE_PPG_CDROMINPUT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_INPUTBUSINESS, GetInputBusiness_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_INPUTBUSINESS, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_INPUTRESIDENTIAL, GetInputResidential_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_INPUTRESIDENTIAL, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_INPUTSAMPLE, GetInputSample_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_INPUTSAMPLE, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_SORT, GetSort_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_SORT, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_GEOSCAN, GetGeoScan_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_GEOSCAN, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_SIC, GetSicScan_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_SIC, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_ADDRESS, GetAddressScan_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_ADDRESS, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromInput, IDS_ENGINE_PROP_RECORDS, GetRecords_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromInput, IDS_ENGINE_PROP_RECORDS, IDS_ENGINE_PPG_CDROMINPUT, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASGEO, HasGeo, SetHasGeo, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASGEO, IDS_ENGINE_PPG_CDROMINPUT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASSIC, HasSic, SetHasSic, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASSIC, IDS_ENGINE_PPG_CDROMINPUT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASADDRESS, HasAddress, SetHasAddress, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_HASADDRESS, IDS_ENGINE_PPG_CDROMINPUT, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromInput, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromInput, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_CDROMINPUT, 1, 0)

	IU_ATTRIBUTE_PAGE(CIuCdromInput, IDS_ENGINE_PPG_CDROMINPUT_STATES, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuCdromInput, IDS_ENGINE_PROP_STATES, GetStates, SetStates, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuCdromInput, IDS_ENGINE_PROP_STATES, IDS_ENGINE_PPG_CDROMINPUT_STATES, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDEBUSINESS, IncludeBusiness, SetIncludeBusiness, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDEBUSINESS, IDS_ENGINE_PPG_CDROMINPUT_STATES, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDERESIDENTIAL, IncludeResidential, SetIncludeResidential, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDERESIDENTIAL, IDS_ENGINE_PPG_CDROMINPUT_STATES, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDESAMPLE, IncludeSample, SetIncludeSample, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromInput, IDS_ENGINE_PROP_INCLUDESAMPLE, IDS_ENGINE_PPG_CDROMINPUT_STATES, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdromInput::CIuCdromInput() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromInput::~CIuCdromInput()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCdromInput::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (IncludeBusiness() || IncludeResidential() || IncludeSample())
	{
		if (Flags.Test(cdromsBuildInputRaw))
		{
			if (!BuildInput(Cdrom, Output, Flags))
				return false;
		}
		if (Flags.Test(cdromsBuildInputSort))
		{
			if (!GetSort().Build(Output, cdromsBuildProcess|cdromsBuildInputSort))
				return false;
		}
		if (Flags.Test(cdromsBuildInputAddress) && HasAddress())
		{
			if (!GetAddressScan().Build(Output, cdromsBuildProcess|cdromsBuildInputAddress))
				return false;
		}
		if (Flags.Test(cdromsBuildInputGeo) && HasGeo())
		{
			if (!GetGeoScan().Build(Output, cdromsBuildProcess|cdromsBuildInputGeo))
				return false;
		}
		if (Flags.Test(cdromsBuildInputSic) && HasSic())
		{
			if (!GetSicScan().Build(Output, cdromsBuildProcess|cdromsBuildInputSic))
				return false;
		}
		if (Flags.Test(cdromsBuildInputTokens))
		{
			if (!GetTokenScans().Build(Output, cdromsBuildProcess|cdromsBuildInputTokens))
				return false;
		}
		if (Flags.Test(cdromsBuildInputIndexes))
		{
			if (!GetIndexes().Build(Output, cdromsBuildProcess|cdromsBuildInputIndexes))
				return false;
		}
	}
	return true;
}

bool CIuCdromInput::BuildInput(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	// NOTE: We use tabs and leading spaces simply to make it
	// easier to copy/paste into excel
	CString sOutput;
	CString sCpp;

	CString sTemp;
	sTemp.Format(_T("\t ST\t%10.10s\t%10.10s\t%10.10s\t%10.10s\n"), "Businesses", "Residences", "Sample", "Total");
	sOutput += sTemp;

	int iTotalBusiness = 0;
	int iTotalResidential = 0;
	int iTotalSample = 0;

	bool fFirst = true;
	for (int iState = 0; iState < GetStateCount(); ++iState)
	{
		CString sState = 	GetState(iState);

		int iTotal = 0;

		sCpp += _T("\t{ \"");
		sCpp += LPCTSTR(sState);
		sCpp += _T("\", ");

		CString sBusinesses;
		if (IncludeBusiness())
		{
			CString sStateBus = sState + _T("Bus");
			GetInputBusiness().SetAppend(!fFirst);
			GetInputBusiness().SetInputFilename(sStateBus);
			if (!GetInputBusiness().Build(Output, cdromsBuildInputRaw))
				return false;
			fFirst = false;

			iTotalBusiness += GetInputBusiness().GetRecords();
			iTotal += GetInputBusiness().GetRecords();
			sBusinesses.Format("\t%10ld", GetInputBusiness().GetRecords());

			sTemp.Format("%10ld, ", GetInputBusiness().GetRecords());
			sCpp += sTemp;
		}
		else
		{
			sCpp += _T("0, ");
			sBusinesses.Format("\t%10ld", 0);
		}

		CString sResidences;
		if (IncludeResidential())
		{
			CString sStateRes = sState + _T("Res");
			GetInputResidential().SetInputFilename(sStateRes);
			GetInputResidential().SetAppend(!fFirst);
			if (!GetInputResidential().Build(Output, cdromsBuildInputRaw))
				return false;
			fFirst = false;

			iTotalResidential += GetInputResidential().GetRecords();
			iTotal += GetInputResidential().GetRecords();
			sResidences.Format("\t%10ld", GetInputResidential().GetRecords());

			sTemp.Format("%10ld ", GetInputResidential().GetRecords());
			sCpp += sTemp;
		}
		else
		{
			sCpp += _T("0 ");
			sResidences.Format("\t%10ld", 0);
		}

		CString sSamples;
		if (IncludeSample())
		{
			CString sStateSmp = sState + _T("Smp");
			GetInputSample().SetInputFilename(sStateSmp);
			GetInputSample().SetAppend(!fFirst);
			if (!GetInputSample().Build(Output, cdromsBuildInputRaw))
				return false;
			fFirst = false;

			iTotalSample += GetInputSample().GetRecords();
			iTotal += GetInputSample().GetRecords();
			sSamples.Format("\t%10ld", GetInputSample().GetRecords());
		}
		else
			sSamples.Format("\t%10ld", 0);


		sCpp += _T(" }, \n");

		sTemp.Format("\t%3.3s", LPCTSTR(sState));
		sOutput += sTemp;
		sOutput += sBusinesses;
		sOutput += sResidences;
		sOutput += sSamples;
		sTemp.Format("\t%10ld\n", iTotal);
		sOutput += sTemp;
	}

	sTemp.Format("\t%3.3s\t%10ld\t%10ld\t%10ld\t%10ld\n\n\n", "", iTotalBusiness, iTotalResidential, iTotalSample, iTotalBusiness + iTotalResidential + iTotalSample);
	sOutput += sTemp;

	Cdrom.Log(_T("Raw Record Input Statistics"), sOutput);
	Output.Output(sOutput);

	Cdrom.Log(_T("C++ Paste-able State Counts"), sCpp);

	return Output.Fire();
}

void CIuCdromInput::Delete(CIuOutput* pOutput)
{
	if (IncludeBusiness() || IncludeResidential() || IncludeSample())
	{
		CdromDelete(GetRecords().GetFullFilename(), pOutput);

		GetInputBusiness().Delete(pOutput);
		GetInputResidential().Delete(pOutput);
		GetInputSample().Delete(pOutput);

		GetGeoScan().Delete(pOutput);
		GetSicScan().Delete(pOutput);
		GetAddressScan().Delete(pOutput);
		GetIndexes().Delete(pOutput);
		GetTokenScans().Delete(pOutput);
	}
}

void CIuCdromInput::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pInputResidential.IsNull())
	{
		m_pInputResidential.Create();
	}
	if (m_pInputSample.IsNull())
	{
		m_pInputSample.Create();
	}
	if (m_pInputBusiness.IsNull())
	{
		m_pInputBusiness.Create();
	}
	if (m_pGeoScan.IsNull())
	{
		m_pGeoScan.Create();
	}
	if (m_pRecords.IsNull())
	{
		m_pRecords.Create();
	}
	if (m_pSort.IsNull())
	{
		m_pSort.Create();
	}
	if (m_pTokenScans.IsNull())
	{
		m_pTokenScans.Create();
	}
	if (m_pSicScan.IsNull())
	{
		m_pSicScan.Create();
	}
	if (m_pAddressScan.IsNull())
	{
		m_pAddressScan.Create();
	}
	if (m_pIndexes.IsNull())
	{
		m_pIndexes.Create();
	}
	m_fIncludeBusiness = true;
	m_fIncludeResidential = true;
	m_fIncludeSample = true;
	m_asStates.RemoveAll();
	m_fHasGeo = false;
	m_fHasSic = false;
	m_fHasAddress = false;
	m_sFilename = "Filename";
	SetVersion(versionCdromInputMax);
	//}}Initialize
}

CIuObject* CIuCdromInput::GetAddressScan_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAddressScan.Ptr()));
}

CIuObject* CIuCdromInput::GetGeoScan_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pGeoScan.Ptr()));
}

CIuObject* CIuCdromInput::GetInputBusiness_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInputBusiness.Ptr()));
}

CIuObject* CIuCdromInput::GetIndexes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pIndexes.Ptr()));
}

CIuObject* CIuCdromInput::GetInputResidential_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInputResidential.Ptr()));
}

CIuObject* CIuCdromInput::GetInputSample_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInputSample.Ptr()));
}

CIuObject* CIuCdromInput::GetRecords_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRecords.Ptr()));
}

CIuObject* CIuCdromInput::GetSicScan_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSicScan.Ptr()));
}

CIuObject* CIuCdromInput::GetSort_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSort.Ptr()));
}

void CIuCdromInput::GetStates(CStringArray& as) const
{
	as.Copy(m_asStates);
}

CIuObject* CIuCdromInput::GetTokenScans_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pTokenScans.Ptr()));
}

CIuVersionNumber CIuCdromInput::GetVersionMax() const
{
	return versionCdromInputMax;
}

CIuVersionNumber CIuCdromInput::GetVersionMaxStatic()
{
	return versionCdromInputMax;
}

CIuVersionNumber CIuCdromInput::GetVersionMin() const
{
	return versionCdromInputMin;
}

CIuVersionNumber CIuCdromInput::GetVersionMinStatic()
{
	return versionCdromInputMin;
}

void CIuCdromInput::RemoveAllStates()
{
	m_asStates.RemoveAll();
}

void CIuCdromInput::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCdromInput::SetHasAddress(bool f)
{
	m_fHasAddress = f;
}

void CIuCdromInput::SetHasGeo(bool f)
{
	m_fHasGeo = f;
}

void CIuCdromInput::SetHasSic(bool f)
{
	m_fHasSic = f;
}

void CIuCdromInput::SetIncludeBusiness(bool f)
{
	m_fIncludeBusiness = f;
	GetInputSample().SetIncludeBusiness(f);
}

void CIuCdromInput::SetIncludeResidential(bool f)
{
	m_fIncludeResidential = f;
	GetInputSample().SetIncludeResidential(f);
}

void CIuCdromInput::SetIncludeSample(bool f)
{
	m_fIncludeSample = f;
}

void CIuCdromInput::SetSpec(CIuCdromSpec& Spec)
{
	SetName(Spec.GetName());

	SetIncludeBusiness(Spec.IncludeBusiness());
	SetIncludeResidential(Spec.IncludeResidential());
	SetIncludeSample(Spec.IncludeSample());
	SetHasAddress(Spec.HasAddress());
	SetHasSic(Spec.HasSic());
	SetHasGeo(Spec.HasGeo());

	SetFilename(Spec.GetFilename());

	CStringArray asStates;
	Spec.GetStates(asStates);
	SetStates(asStates);
	if (asStates.GetSize() == 0)
	{
		SetIncludeBusiness(false);
		SetIncludeResidential(false);
		SetIncludeSample(false);
		SetHasAddress(false);
		SetHasSic(false);
		SetHasGeo(false);
	}

	GetRecords().SetFilename(Spec.GetFilename());

	GetInputBusiness().SetSpec(Spec);
	GetInputResidential().SetSpec(Spec);
	GetInputSample().SetSpec(Spec);
	GetSort().SetSpec(sortStandardByName, Spec.GetFilename());
	GetSort().SetReOrder(true);
	if (HasAddress())
		GetAddressScan().SetSpec(Spec.GetAddress());
	if (HasGeo())
		GetGeoScan().SetSpec(Spec.GetGeo());
	if (HasSic())
		GetSicScan().SetSpec(Spec.GetSic());
	GetIndexes().SetSpec(Spec);
	GetTokenScans().SetSpec(Spec);
}

void CIuCdromInput::SetStates(const CStringArray& as)
{
	m_asStates.Copy(as);
}
