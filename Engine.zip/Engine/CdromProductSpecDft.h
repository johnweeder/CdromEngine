#ifndef _ENGINE_CDROMPRODUCTSPECDFT_H_
#define _ENGINE_CDROMPRODUCTSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// A description of a product excluding the release specific information
#pragma warning(disable: 4200)
struct CIuCdromProductSpecDft
{
public:
	static int Find(LPCTSTR pcszProduct);
	static int Find(int iProduct);
	static const CIuCdromProductSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The full name of this product
	LPCTSTR m_pcszProduct;
	int m_iProduct;
	// This is a description of the product. 
	// If this is null, the description is generated
	LPCTSTR m_pcszDescription;
	// Product grouping (only used by build ui)
	LPCTSTR m_pcszProductGroup;
	// The cdrom form name
	int m_iFormatNo;
	// A list of options for this product. Various components are free to interpret these
	// options. Some important options:
	//		cdonly:					Product needs authorization to run on a network
	//		business:				Business records are included
	//		resdidential:			Residential records are included
	//		samples:					Sample records are included
	// Also, combined with product options!
	LPCTSTR m_pcszOptions;
	// Registration
	int m_iRegistrationNo;
	// A list of release notes
	int m_iReleaseNoteNo;
	// Splash Screens
	int m_iSplashNo;
	// A list of blob
	const int* m_piBlobs;
	// A list of export defs
	const int* m_piExportDefs;
	// A list of report defs
	const int* m_piReportDefs;
	// Split size (-1 if file not split)
	int m_iSplitSize;
	// A list of states used by this product
	LPCTSTR m_pcszStates;
	// This is a variable sized struct. 
	// This contains a list of named attributes
	LPCTSTR m_apcszAttributes[];
};
#pragma warning(default: 4200)

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_CDROMPRODUCTSPECDFT_H_
