#include "stdafx.h"
#include "MeterDiagnosticDlg.h"
#include "Meter.h"
#include "Common\Clipboard.h"
#include "Interop\Conversions.h"
#include "Common\QueryResponseCode.h"
#include "Common\Crc32.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CIuMeterDiagnosticDlg::CIuMeterDiagnosticDlg(CWnd* pParent /*=NULL*/) : CIuMeterDiagnosticDlg_super(CIuMeterDiagnosticDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterDiagnosticDlg)
	m_sNotes = _T("");
	//}}AFX_DATA_INIT
}

void CIuMeterDiagnosticDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterDiagnosticDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterDiagnosticDlg)
	DDX_Text(pDX, IDC_ENGINE_NOTES, m_sNotes);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIuMeterDiagnosticDlg, CIuMeterDiagnosticDlg_super)
	//{{AFX_MSG_MAP(CIuMeterDiagnosticDlg)
	ON_BN_CLICKED(IDC_ENGINE_CLIPBOARD, OnClipboard)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuMeterDiagnosticDlg message handlers

void CIuMeterDiagnosticDlg::DoDialog(CIuMeter& Meter, LPCTSTR pcszCode, LPCTSTR pcszLocation, CWnd* pParent)
{
	CIuMeterDiagnosticDlg Dlg(pParent);

	Dlg.m_pMeter = &Meter;

	Dlg.m_sNotes = "";

	CIuQueryResponseCode Query;
	Query.SetKey(Meter.GetKey());
	Query = pcszCode;
	UINT32 uiUserValue = Query.GetUserValue();

	CString sUserValue;
	UIntAsStringEx(sUserValue, uiUserValue, 16);
	CString sCount;
	IntAsString(sCount, Meter.GetCount());

	Dlg.m_sNotes += CString("Code 1: [") + Meter.GetName()	+ CString("]\r\n");
	Dlg.m_sNotes += CString("Code 2: [") + Meter.GetKey()		+ CString("]\r\n");
	Dlg.m_sNotes += CString("Code 3: [") + pcszCode				+ CString("]\r\n");
	Dlg.m_sNotes += CString("Code 4: [") + sUserValue			+ CString("]\r\n");
	Dlg.m_sNotes += CString("Code 5: [") + sCount				+ CString("]\r\n");
	Dlg.m_sNotes += CString("Code 6: [") + pcszLocation		+ CString("]\r\n");

	if (!CIuQueryResponseCode::HasCheckSum(pcszCode))
		Dlg.m_sNotes += _T("Code has no check sum character.\r\n");
	if (CIuQueryResponseCode::HasCheckSum(pcszCode) && !CIuQueryResponseCode::IsValidCheckSum(pcszCode))
		Dlg.m_sNotes += _T("Code has invalid check sum character.\r\n");
	if (!Query.IsValid())
		Dlg.m_sNotes += _T("Code is not valid.\r\n");
	if (!Meter.IsExpired())
		Dlg.m_sNotes += _T("Meter is expired.\r\n");

	CString sCrc;
	UIntAsStringEx(sCrc, crc32((const BYTE*)(LPCTSTR)Dlg.m_sNotes, Dlg.m_sNotes.GetLength()), 16);

	Dlg.m_sNotes += sCrc + CString("\r\n");

	Dlg.DoModal();
}

void CIuMeterDiagnosticDlg::OnClipboard() 
{
	CopyToClipboard(m_sNotes, this);
}

BOOL CIuMeterDiagnosticDlg::OnInitDialog() 
{
	CIuMeterDiagnosticDlg_super::OnInitDialog();
	CenterWindow();
	return TRUE;  
}

