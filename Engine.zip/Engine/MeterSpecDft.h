#ifndef _ENGINE_METERSPECDFT_H_
#define _ENGINE_METERSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

struct CIuMeterSpecDft
{
public:
	static int Find(LPCTSTR pcszMeter);
	static int Find(int iMeter);
	static const CIuMeterSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The name and number
	LPCTSTR m_pcszMeter;
	int m_iMeter;
	// Title of the meter
	LPCTSTR m_pcszTitle;
	// The unique meter id
	const CIuID* m_pidMeter;
	const CIuID* m_pidMeterPrevious;
	// The encryption key for the meter
	LPCTSTR m_pcszKey;
	// A meter version number for supporting new meter logic
	// The guids for the registry based meter
	GUID m_guid1;
	GUID m_guid2;
	// Meter rev
	// The revision number is used if a meter changes during its lifetime
	// For example, the counts decrease or the speed bump is changed.
	// By identifying the revision, you can hard-code values (ugly hack)
	// in the code to support existing customers (i.e. not piss them off more)
	// Default is 0.
	int m_iInitialRev;
	// Meter flags
	int m_iFlags;
	// The filename for the file based network meter
	LPCTSTR m_pcszFilename;
	// Initial meter count.
	//	Upgrade count applies if a previous edition was installed.
	// -1 for no meter
	int m_iInitialCount;
	//	If 0 or -1, there is no special count for an upgrade.
	// Because this field was added, old product meters will report a value of 0.
	int m_iInitialCountUpgrade;
	// Speed bump
	// -1 for no speed bump
	int m_iMaxOutput;
	// Expiration logic
	// Number of days til warning message and number of days til expiration
	// -1 for no warning or expiration
	int m_iExpireDays;
	int m_iWarningDays;
	LPCTSTR m_pcszWarningText;
	// The release date (which is fixed as opposed to the install
	// date which is variable)
	// This is represent as a string. For example: "3/15/2000".
	// If blank, no release date is supplied.
	LPCTSTR m_pcszReleaseDate;
	// Meter options
	// Does meter allow record count updating?
	bool m_fAllowUpdate;
	// Upgrading information within current meter
	int m_iUpgradeLevel;
	int m_iUpgradeCount;
	// Special access options granted
	// A comma delimited list of options which are application dependent.
	// Current options:
	//		reset		(reset meter to initial state)
	//		rev0		(reset meter to rev0)
	LPCTSTR m_pcszSpecialAccess;
	// Display information used on the update screens.
	// A collection of phone numbers to be displayed. Up to three lines are supported.
	// You may columnize the data with a tab character if needed.
	LPCTSTR m_pcszPhone;
	// A full URL to contact for updates. If empty, no web support.
	LPCTSTR m_pcszWebSite;
};


//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_METERSPECDFT_H_
