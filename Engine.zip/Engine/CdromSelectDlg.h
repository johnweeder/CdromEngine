#ifndef _ENGINE_CDROMSELECTDLG_H_
#define _ENGINE_CDROMSELECTDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_UI_LAYOUTMANAGER_H_
#	include "Ui\LayoutManager.h"
#endif	// _UI_LAYOUTMANAGER_H_ 
#include "resource.h"
#ifndef 	_ENGINE_CDROMSELECTENTRY_H_
#	include "Engine\CdromSelectEntry.h"
#endif	// _ENGINE_CDROMSELECTENTRY_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromSelectDlg, CDialog }}
#define CIuCdromSelectDlg_super CDialog

class CIuCdromSelectDlg : public CIuCdromSelectDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare 

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromSelectDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	void GetEntries(CIuCdromSelectEntryArray& Entries) const;
	int GetMaxRecords() const;
	int GetSpec() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void SetMaxRecords(int);
	void SetSpec(int iSpec);
	void SetSpec(LPCTSTR pcszCurrent);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CreateApplications();
	void CreateProductGroups(LPCTSTR pcszApplication, LPCTSTR pcszRelease, HTREEITEM hRelease);
	void CreateProducts(LPCTSTR pcszApplication, LPCTSTR pcszRelease, LPCTSTR pcszProductGroup, HTREEITEM hRelease);
	void CreateReleases(LPCTSTR pcszApplication, HTREEITEM hApplication);
	void Update();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuLayoutManager m_LayoutManager;
	int m_iSpec;
	int m_iMaxRecords;
	CIuCdromSelectEntryArray m_Entries;
//}}Data

public:
	//{{AFX_DATA(CIuCdromSelectDlg)
	enum { IDD = IDD_ENGINE_CDROM_SELECT };
	CButton	m_btnEdit;
	CButton	m_btnOK;
	CTreeCtrl	m_Tree;
	int		m_MaxRecordNo;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuCdromSelectDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuCdromSelectDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnEdit();
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownTree(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	LRESULT OnCheckUpdate(WPARAM, LPARAM lpParam);
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuCdromSelectDlg::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline int CIuCdromSelectDlg::GetSpec() const
{
	return m_iSpec;
}

#endif // _ENGINE_CDROMSELECTDLG_H_
