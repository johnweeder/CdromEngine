#ifndef _ENGINE_RECORDITERATOR_H_
#define _ENGINE_RECORDITERATOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordIterator)
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
class CIuCdromSpec;
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordIterator, CIuCollectable }}
// Following is some sample code to use a record iterator
//	It is assumed that you have an output object to display the progress.
// Input: CIuOutput Output
/*
	// Save output state
	CIuOutputStateInstance instance(Output);

	// Create and open record file
	CIuRecordIterator Iterator;
	Iterator.SetFilename("filename");
	if (!Iterator.Open(Output))
		return false;

	// Process the records in the file
	Output.OutputF("Start\n");
	Output.SetMessageF("Start\n");
	CIuRecordPtr pRecord;
	while (Iterator.MoveNext(Output, pRecord))
	{
		// Do something
		LPCTSTR pcsz = pRecord->GetField(0);
	}
	Iterator.Close(Output);

	// Done
	Output.OutputF("Done\n");
	Output.Fire();

	// Display elapsed time
	instance.Pop(true);
	return true;
*/
#define CIuRecordIterator_super CIuCollectable

class CIuRecordIterator : public CIuRecordIterator_super
{
//{{Declare
	DECLARE_SERIAL(CIuRecordIterator)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordIterator();
	virtual ~CIuRecordIterator();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetFilename() const;
	int GetMaxRecords() const;
	CString GetOptions() const;
	CIuRecordFile& GetInput() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual bool Build(CIuOutput& Output, CIuFlags Flags);
	void Close(CIuOutput& Output);
	virtual void Delete(CIuOutput* pOutput = 0);
	bool MoveFirst(CIuOutput& Output);
	bool MoveNext(CIuOutput& Output, CIuRecordPtr& pRecord);
	bool Open(CIuOutput& Output);
	void SetFilename(LPCTSTR);
	void SetMaxRecords(int);
	void SetOptions(LPCTSTR);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose(CIuOutput& Output);
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnProcess(const CIuRecord& Record, CIuOutput& Output);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetInput_() const;
private:
	void Close();
	void CommonConstruct();
	bool Process(CIuOutput& Output, CIuFlags Flags);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Persistent information
		// Maximum records or -1
		int m_iMaxRecords;
		// Options to open with
		CString m_sOptions;
		// Filename to open
		CString m_sFilename;
	// Input object
	CIuRecordFilePtr m_pInput;
	// Variables used during the current iteration
	int m_iProcessRecord;
	int m_iProcessRecords;
	int m_iProcessMaxRecords;
	int m_iProcessNoise;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuRecordIterator::GetFilename() const
{
	return m_sFilename;
}

inline CIuRecordFile& CIuRecordIterator::GetInput() const
{
	return m_pInput.Ref();
}

inline int CIuRecordIterator::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline CString CIuRecordIterator::GetOptions() const
{
	return m_sOptions;
}

#endif // _ENGINE_RECORDITERATOR_H_
