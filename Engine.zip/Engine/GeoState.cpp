#include "StdAfx.h"
//{{Include
#include "GeoState.h"
#include "GeoRawState.h"
#include "State.h"
#include "States.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "RegEx.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoState, CIuGeoState_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoState)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOSTATE, CIuGeoState, CIuGeoState_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoState::CIuGeoState() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoState::~CIuGeoState()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}


void CIuGeoState::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoState"));
	//}}Initialize
}

void CIuGeoState::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter = RegEx.CreateLikeClause(_T("StateAbbr"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoState::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoState::GetIndexStatic() 
{
	return _T("State");
}

void CIuGeoState::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoState);
}

int CIuGeoState::GetSourceType() const
{
	return sourceGeoCollectionState;
}

void CIuGeoState::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoState::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawState& State = *dynamic_cast<CIuGeoRawState*>(&Element);
	ASSERT(&State);

	int iExpandedSize = sizeof(CIuState);
	ASSERT(iExpandedSize == 12);

	CString sName = State.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CIuStates states(statesAll);
	int iState = states.FindAbbr(sName);
	if (iState >= 0)
	{
		CIuNybbleString::Append(states.GetName(iState), -1, NS_ALPHA, Buffer);
		iExpandedSize += _tcslen(states.GetName(iState)) + 1;

		CIuNybbleInt::AppendUIntCompressed(states.GetCode(iState), Buffer);
		iExpandedSize += _tcslen(states.GetCodeAsString(iState)) + 1;
	}
	else
	{
		CIuNybbleString::Append("", -1, NS_ALPHA, Buffer);
		iExpandedSize += 1;

		CIuNybbleInt::AppendUIntCompressed(0, Buffer);
		iExpandedSize += 2 + 1; // "00"
	}

	iExpandedSize += CIuGeoList::Compress(State.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize;
}

int CIuGeoState::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuState* pState = (CIuState*)AddElement(sizeof(CIuState));

	// Decompress the various strings
	CIuStaticBuffer256 BufferStateAbbr;
	iOffset += CIuNybbleString::Get(BufferStateAbbr, -1, true, NS_ALPHA, Buffer, iOffset);

	CIuStaticBuffer256 BufferStateName;
	iOffset += CIuNybbleString::Get(BufferStateName, -1, true, NS_ALPHA, Buffer, iOffset);

	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pState->m_iStateCode = uiVal;
	TCHAR szStateCode[2+1];
	_stprintf(szStateCode, "%02d", pState->m_iStateCode);

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferStateAbbr.GetPtr()));
	AddElementString(LPCTSTR(BufferStateName.GetPtr()));
	AddElementString(szStateCode);
	AddElementStringTerm();

	return iOffset;
}

