#include "StdAfx.h"
//{{Include
#include "FieldDefSpecDft.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "FieldName.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Special intrinsic fields
const TCHAR szFieldKey[]				= "Key";
const TCHAR szFieldAlt[]				= "Alt";
const TCHAR szFieldSeeAlso[]			= "SeeAlso";
const TCHAR szFieldRecordNo[]			= "RecordNo";
const TCHAR szFieldSourceNo[]			= "SourceNo";
const TCHAR szFieldExpandNo[]			= "ExpandNo";
const TCHAR szFieldCount[]				= "Count";
const TCHAR szFieldLatitude[]			= "Latitude";
const TCHAR szFieldLongitude[]		= "Longitude";
const TCHAR szFieldTagged[]			= "Tagged";
const TCHAR szFieldBought[]			= "Bought";
const TCHAR szFieldNoMail[]			= "NoMail";
const TCHAR szFieldNoPhone[]			= "NoPhone";
const TCHAR szFieldSicName[]			= "SicName";
const TCHAR szFieldFranchiseName[]	= "FranchiseName";
const TCHAR szFieldYearsInDb[]		= "YearsInDb";
const TCHAR szFieldBusiness[]			= "Business";
const TCHAR szFieldResidence[]		= "Residence";
const TCHAR szFieldBusResFlag[]		= "BusResFlag";

/////////////////////////////////////////////////////////////////////////////
// NOTE:
//		Right justify has been replaced with the flag "sortnumeric"
//		This leaves printing and exporting free to use justification
//		for actual formatting issues.
//		Be careful when "numeric sorting" a field. Right justification
//		makes numeric fields sort properly, but it also breaks 
//		wildcard searching.
//		There is no need to "numeric sort" a field which is completely filled.
//		For example, phone and addon either contain a full number or
//		they are blank. Therefore, there is no need to justify those field
//		types.
//		The "numeric" flag is used as an indicator to compressors.

// This is a master list of basic field types.
const CIuFieldDefSpecDft apFieldDef[] =
{
	{
		"AcPhone", fieldAcPhone,
		0,					0,							"Phone #", 
		"Telephone number.",
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",  
		10
	},{
		"AddOn", fieldAddOn,
		0, "Addon", "ZIP+4",
		0,
		0,
		"numeric",
		4
	},{
		"Address", fieldAddress,
		0,								0,							0, 
		0,
		0,
		"ConvertCaseMixed",
		65
	},{
		"AdSizeCode", fieldAdSizeCode,
		0, "AdSizeCode", "Ad Size Code",
		0,
		0,
		"",
		1
	},{
		"AdSizeCode2", fieldAdSizeCode2,
		0, "AdSizeCd2", "Ad Size Code2",
		0,
		0,
		"",
		1
	},{
		"AdSizeCode3", fieldAdSizeCode3,
		0, "AdSizeCd3", "Ad Size Code3",
		0,
		0,
		"",
		1
	},{
		"AdSizeCode4", fieldAdSizeCode4,
		0, "AdSizeCd4", "Ad Size Code4",
		0,
		0,
		"",
		1
	},{
		"AdSizeCode5", fieldAdSizeCode5,
		0, "AdSizeCd5", "Ad Size Code5",
		0,
		0,
		"",
		1
	},{
		"AdSizeCode6", fieldAdSizeCode6,
		0, "AdSizeCd6", "Ad Size Code6",
		0,
		0,
		"",
		1
	},{
		szFieldAlt, fieldAlt,
		0, "Alt", "Alternate record",
		0,
		0,
		0,
		fieldDftLength
	},{
		"Alternates", fieldAlternates,
		0, "Alts", "Alternates",
		0,
		0,
		0,
		fieldDftLength
	},{
		"AreaCode", fieldAreaCode,
		0, "AreaCode", "Area code", 
		0,
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		3
	},{
		"AreaCodeName", fieldAreaCodeName,
		0, "ACName", "Area code name", 
		0,
		0,
		"",
		30
	},{
		"BlockGroup", fieldBlockGroup,
		0, 0, "Block Group",
		0,
		0,
		0,
		1
	},{
		szFieldBought, fieldBought,
		0,								0,							0,
		0,
		0,
		"numeric,sortnumeric",
		3
	},{
		szFieldBusiness, fieldBusiness,
		0,								0,							0,
		0,
		0,
		"",
		1
	},{
		szFieldBusResFlag, fieldBusResFlag,
		0,								0,							0,
		0,
		0,
		"",
		1
	},{
		"CarrierRoute", fieldCarrierRoute,
		0,	"CarrierRt", "Carrier Route",
		"Carrier route code",
		0,
		0,
		4
	},{
		"CensusTract", fieldCensusTract,
		0, "Census", "Census Tract",
		0,
		0,
		"numeric",
		6 
	},{
		"City", fieldCity,
		0,	0, "Postal City Name",
		"The Postal city will be placed in this field.", 
		0,
		"ConvertCaseMixed",
		28
	},{
		"CityState", fieldCityState,
		0,	0, "City Name",
		"City/State.", 
		0,
		"ConvertCaseMixed",
		28 + 2 + 2
	},{
		"Company", fieldCompany,
		0, "Company", "Company Name", 
		0,
		0,
		"ConvertCaseMixed",
		30
	},{
		"Contact", fieldContact,
		0,								0,							0,
		"Name of business contact",
		0,
		"ConvertCaseMixed",
		62
	},{
		"ContactFirst", fieldContactFirst,
		0, "ConFirst", "First Name",			
		"First name of business contact", 
		0,
		"ConvertCaseMixed",
		15
	},{
		"ContactLast", fieldContactLast,
		0,	"ConLast", "Last Name",
		"Last name of business contact",
		0,
		"ConvertCaseMixed",
		20
	},{
		szFieldCount, fieldCount,
		0, 0,	"Count", 
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"CountMatched", fieldCountMatched,
		0, "Matched",	"Count Matched", 
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"CountNotMatched", fieldCountNotMatched,
		0, "NotMatched", "Count Not Matched", 
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"CountTotal", fieldCountTotal,
		0, "Total",	"Count total candidate records",
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"CountyCode", fieldCountyCode,
		0, 0,	"County Code", 
		0,
		0,
		"numeric",
		5
	},{
		"CountyName", fieldCountyName,
		0,	0,	"County Name", 
		0,
		0,
		"ConvertCaseMixed",
		15
	},{
		"CrLf", fieldCrLf,
		0,								0,							0,
		0,
		0,
		0,
		2
	},{
		"DPBC", fieldDPBC,
		0, "DPBC", "Delivery Point Barcode", 
		0,
		0,
		"numeric",
		3
	},{
		"EmployeeSizeCode", fieldEmployeeSizeCode,
		0, "EmpSizeCd", "Employee Size Code",
		0,
		0,
		"",
		1
	},{
		"Exchange", fieldExchange,
		
		0, "Exchange", "Phone Exchange",
		0,
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		6
	},{
		"ExchangeName", fieldExchangeName,
		0, "ExchgName", "Phone Exchange Name",
		0,
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		40
	},{
		szFieldExpandNo, fieldExpandNo,
		0,								0,							0,
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"FaxAcPhone", fieldFaxAcPhone,
		0, "FaxAcPhone", "Fax Phone #",
		"FAX Telephone number.", 
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		10
	},{
		"FaxAreaCode", fieldFaxAreaCode,
		0, "FaxAc", "FAX Area Code",
		0,
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		3
	},{
		"FaxPhone", fieldFaxPhone,
		0, 0, 0,
		"FAX Telephone number.",
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		7
	},{
		"First", fieldFirst,
		0, 0, "First Name",			
		"First name of resident", 
		0,
		"ConvertCaseMixed",
		15
	},{
		"FirstYear", fieldFirstYear,
		0, 0, "First Year in Database",
		0,
		0,
		"",
		4
	},{
		"FirstYear2", fieldFirstYear2,
		0, 0, "First Year in Database2",
		0,
		0,
		"",
		4
	},{
		"FirstYear3", fieldFirstYear3,
		0, 0, "First Year in Database3",
		0,
		0,
		"",
		4
	},{
		"FirstYear4", fieldFirstYear4,
		0, 0, "First Year in Database4",
		0,
		0,
		"",
		4
	},{
		"FirstYear5", fieldFirstYear5,
		0, 0, "First Year in Database5",
		0,
		0,
		"",
		4
	},{
		"FirstYear6", fieldFirstYear6,
		0, 0, "First Year in Database6",
		0,
		0,
		"",
		4
	},{
		"FranchiseCode", fieldFranchiseCode,
		0,								"FranCode",				0,
		"Franchise Code",
		0,
		0,
		1
	},{
		"FranchiseCode2", fieldFranchiseCode2,
		0,								"FranCode2",				0,
		"Franchise Code2",
		0,
		0,
		1
	},{
		"FranchiseCode3", fieldFranchiseCode3,
		0,								"FranCode3",				0,
		"Franchise Code3",
		0,
		0,
		1
	},{
		"FranchiseCode4", fieldFranchiseCode4,
		0,								"FranCode4",				0,
		"Franchise Code4",
		0,
		0,
		1
	},{
		"FranchiseCode5", fieldFranchiseCode5,
		0,								"FranCode5",				0,
		"Franchise Code5",
		0,
		0,
		1
	},{
		"FranchiseCode6", fieldFranchiseCode6,
		0,								"FranCode6",				0,
		"Franchise Code6",
		0,
		0,
		1
	},{
		szFieldFranchiseName, fieldFranchiseName,
		0,								"FranName",				0,
		"Franchise Name",
		0,
		"ConvertCaseMixed",
		40
	},{
		"FranchiseName2", fieldFranchiseName2,
		0,								"FranName2",				0,
		"Franchise Name2",
		0,
		"ConvertCaseMixed",
		40
	},{
		"FranchiseName3", fieldFranchiseName3,
		0,								"FranName3",				0,
		"Franchise Name3",
		0,
		"ConvertCaseMixed",
		40
	},{
		"FranchiseName4", fieldFranchiseName4,
		0,								"FranName4",				0,
		"Franchise Name4",
		0,
		"ConvertCaseMixed",
		40
	},{
		"FranchiseName5", fieldFranchiseName5,
		0,								"FranName5",				0,
		"Franchise Name5",
		0,
		"ConvertCaseMixed",
		40
	},{
		"FranchiseName6", fieldFranchiseName6,
		0,								"FranName6",				0,
		"Franchise Name6",
		0,
		"ConvertCaseMixed",
		40
	},{
		"Franchises", fieldFranchises,
		0, "Frans", "Franchises",
		0,
		0,
		0,
		fieldDftLength
	},{
		"Gen", fieldGen,
		0, "Gen", "Generational",		
		"Generational of resident", 
		0,								
		0,								
		3
	},{
		"Gender", fieldGender,
		0, 0, 0,
		"Gender", 
		0,								
		0,								
		6
	},{
		"HighRise", fieldHighRise,
		0, 0, "High Rise",
		"High rise flag from Code 1",
		0,
		0,
		1
	},{
		// NOTE: This is a special field which every raw record
		// contains. It represents the "key" value for the record
		szFieldKey, fieldKey,
		0,	0, 0,			
		"Key field (special)",
		0,
		0,
		fieldDftLength
	},{
		"Last", fieldLast,
		0,	0, "Last Name",			
		"Last name of resident",
		0,
		"ConvertCaseMixed",
		20
	},{
		szFieldLatitude, fieldLatitude,
		0,								"Latt",					"Latitude",
		"Latitude(6 decimal places)",
		0,
		"numeric,sortnumeric",
		9
	},{
		"Lf", fieldLf,
		0,								0,							0,
		0,
		0,
		0,
		1
	},{
		szFieldLongitude, fieldLongitude,
		0,								"Long",					"Longitude",
		"Longitude(6 decimal places)", 
		0,
		"numeric,sortnumeric",
		9
	},{
		"MatchLevel", fieldMatchLevel,
		0,								"Mtchl",					"Match Level", 
		0,
		0,
		"numeric,sortnumeric",
		1
	},{
		"MedianHV", fieldMedianHV,
		0, "MedianHV", "Median Home Value",
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"MedianIncome", fieldMedianIncome,
		0, "MedianInc", "Median Income",
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"MiddleName", fieldMiddleName,
		0, 0, "Middle Name",			
		"Name Middle name of resident", 
		0,
		"ConvertCaseMixed",
		15
	},{
		"MsaCode", fieldMsaCode,
		0, 0,"MSA Code",				
		"Metropolitan Statistical Area Code", 
		0,
		"numeric",
		4
	},{
		"MsaName", fieldMsaName,
		0, 0, "MSA Name",
		"Metropolitan Statistical Area Code", 
		0,
		"ConvertCaseMixed",
		50
	},{
		"Name", fieldName,
		0,								0,							"Name", 
		"Name of person or business",
		0,
		"ConvertCaseMixed",
		62
	},{
		"NickName", fieldNickName,
		0,								0,							0,
		"Nickname of resident",
		0,
		"ConvertCaseMixed",
		15
	},{
		szFieldNoMail, fieldNoMail,
		0, "NoMail", "No mail",
		"Records that are flagged as 'No Mail'", 
		0,
		"numeric",
		1
	},{
		szFieldNoPhone, fieldNoPhone,
		0, "NoPhone", "No phone",
		"Records that are flagged as 'No Phone'",
		0,
		"numeric",
		1
	},{
		"NoSolicitation", fieldNoSolicitation,
		0, "NoSolicit", "No solicitation",
		"Records that are flagged as 'No solicitation'", 
		0,
		"numeric",
		1
	},{
		"Phone", fieldPhone,
		0,0, "Phone #",
		"Telephone number.",
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		7
	},{
		"PhoneType", fieldPhoneType,
		0, "PhoneType", "Phone Type Flag",
		"Flag indicating presence of teenline, fax, modem", 
		0,
		0,
		4
	},{
		"PostDir", fieldPostDir,
		0, 0, "Post Directional",
		"Street post directional", 
		0,
		"ConvertCaseMixed",
		2
	},{
		"PreDir", fieldPreDir,
		0,	0, "Pre Directional",
		"Street predirectional", 
		0,
		"ConvertCaseMixed",
		2
	},{
		"Prefix", fieldPrefix,
		0, "Prefix", "Phone Number Prefix",
		0,
		0,
		"",
		3
	},{
		"PriNo", fieldPriNo,
		0,								0,							"House No",
		"The house number (right justified)", 
		0,
		"numeric,sortnumeric",
		10
	},{
		"ProSuffix", fieldProSuffix,
		0, 0, "Professional Suffix", 
		"Professional suffix of resident", 
		0,								
		"ConvertCaseMixed",
		4
	},{
		"PubDate",fieldPubDate,
		0,								"Pubdate",				0, 
		"Publication date of book, YYYYMM",
		0,
		"numeric",
		6
	},{
		"RecordID", fieldRecordID,
		0, 0, "Record ID  #",
		"Household ID #",
		0,
		0,
		10
	},{
		szFieldRecordNo, fieldRecordNo,
		0,								0,							0,
		0,
		0,
		"numeric,sortnumeric",
		11
	},{
		szFieldResidence, fieldResidence,
		0,								0,							0,
		0,
		0,
		"",
		1
	},{
		"SalesVolumeCode", fieldSalesVolumeCode,
		0, "SaleVolCd", "Sales Volume Size Code",
		0,
		0,
		"",
		1
	},{
		"SecNo", fieldSecNo,
		0,								0,							"Apartment No",
		"Apartment number, floor number, etc.",
		0,
		"ConvertCaseMixed;sortnumeric",
		10
	},{
		szFieldSeeAlso, fieldSeeAlso,
		0, "SeeAlso", "SeeAlso",
		0,
		0,
		0,
		fieldDftLength
	},{
		"SicCode", fieldSicCode,
		0,								0,							0,
		"SIC Code",
		0,
		0,
		6
	},{
		"SicCode2", fieldSicCode2,
		0,								0,							0,
		"SIC Code2",
		0,
		0,
		6
	},{
		"SicCode3", fieldSicCode3,
		0,								0,							0,
		"SIC Code3",
		0,
		0,
		6
	},{
		"SicCode4", fieldSicCode4,
		0,								0,							0,
		"SIC Code4",
		0,
		0,
		6
	},{
		"SicCode5", fieldSicCode5,
		0,								0,							0,
		"SIC Code5",
		0,
		0,
		6
	},{
		"SicCode6", fieldSicCode6,
		0,								0,							0,
		"SIC Code6",
		0,
		0,
		6
	},{
		"SicCount", fieldSicCount,
		0, 0,	"SicCount", 
		0,
		0,
		"numeric,sortnumeric",
		10
	},{
		"SicFranchiseCode", fieldSicFranchiseCode,
		0,								"SicFran",				0,
		"SIC/Franchise Code",
		0,
		0,
		7
	},{
		szFieldSicName, fieldSicName,
		0,								0,							0,
		"SIC Name",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicName2", fieldSicName2,
		0,								0,							0,
		"SIC Name2",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicName3", fieldSicName3,
		0,								0,							0,
		"SIC Name3",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicName4", fieldSicName4,
		0,								0,							0,
		"SIC Name4",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicName5", fieldSicName5,
		0,								0,							0,
		"SIC Name5",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicName6", fieldSicName6,
		0,								0,							0,
		"SIC Name6",
		0,
		"ConvertCaseMixed",
		40
	},{
		"SicPreferred", fieldSicPreferred,
		0,								"SicPref",				"SIC Preferred",
		"SIC Preferred",
		0,
		0,
		1
	},{
		szFieldSourceNo, fieldSourceNo,
		0,								0,							0,
		0,
		0,
		"numeric,sortnumeric",
		11
	},{
		"SpouseFirst", fieldSpouseFirst,
		0, "SFirst", "Spouse First Name", 
		"First name of spouse", 
		0,
		"ConvertCaseMixed",
		15
	},{
		"SpouseGen", fieldSpouseGen,
		0, "SGen", "Spouse Generational",
		"Generational of spouse", 
		0,
		0,
		3
	},{
		"SpouseLast", fieldSpouseLast,
		0, "SLast", "Spouse Last Name",
		"Last name of spouse if different from resident", 
		0,
		"ConvertCaseMixed",
		20
	},{
		"SpouseMiddleName", fieldSpouseMiddleName,
		0, "SMiddle", "Spouse Middle Name", 
		"Middle name of spouse",
		0,
		"ConvertCaseMixed",
		15
	},{
		"SpouseNickName", fieldSpouseNickName,
		0, "SNickname", "Spouse Nickname",	
		"Nickname of spouse", 
		0,
		"ConvertCaseMixed",
		15
	},{
		"SpouseProSuffix", fieldSpouseProSuffix,
		0, "SSuffix", "Spouse Prof. Suffix",
		"Professional suffix of spouse",
		0,
		"ConvertCaseMixed",
		4
	},{
		"SpouseTitle", fieldSpouseTitle,
		0, "STitle", "Title of Spouse",
		0,
		0,
		"ConvertCaseMixed",
		4
	},{
		"StateAbbr", fieldStateAbbr,
		0, 0, "State Abbreviation",
		"Alpha state abbreviation", 
		0,
		"NoConvertCase",
		2
	},{
		"StateCity", fieldStateCity,
		0,	0, "City Name",
		"State/City", 
		0,
		"ConvertCaseMixed",
		2 + 28
	},{
		"StateCode", fieldStateCode,
		0, 0, "State Code",
		0,
		0,
		0,
		2
	},{
		"StateName", fieldStateName,
		0, 0, "State Name",
		"Full state name", 
		0,
		"ConvertCaseMixed",
		25
	},{
		"Street", fieldStreet,
		0,								"Street",			0,
		"Address without primary number or secondary number", 
		0,
		"ConvertCaseMixed",
		40
	},{
		"StreetName", fieldStreetName,
		0, 0, "Street Name",
		"Street name without directionals or suffix", 
		0,
		"ConvertCaseMixed",
		25
	},{
		"SubUrbanCity", fieldSubUrbanCity,
		0,	"SuburbCity", "Suburban City Name",
		"City abbreviation from book", 
		0,
		"ConvertCaseMixed",
		28
	},{
		"Suffix", fieldSuffix,
		0,	0, "Street suffix",
		"Street name suffix",
		0,
		0,
		4
	},{
		szFieldTagged, fieldTagged,
		0,								0,							0,
		0,
		0,
		"numeric,sortnumeric",
		1
	},{
		"Title", fieldTitle,
		0,								0,							0,
		"Title of resident", 
		0,
		"ConvertCaseMixed",
		4
	},{
		"Token", fieldToken,
		0,								0,							0,
		0,
		0,
		0,
		fieldDftLength
	},{
		"TollFreeAcPhone", fieldTollFreeAcPhone,
		0, "TFAcPhone", "Toll Free Phone #",
		"Toll-Free Telephone number.", 
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		10
	},{
		"TollFreeAreaCode", fieldTollFreeAreaCode,
		0, "TollFreeAc", "Toll Free Area Code",
		0,
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		3
	},{
		"TollFreePhone", fieldTollFreePhone,
		0, "TFPhone", 0,
		"Toll Free Telephone number.",
		0,
		// NOTE: Do not right justify phone, it messes up wild card searching
		"numeric",
		7
	},{
		"Unknown1", fieldUnknown1,
		0,								0,							0,
		0,
		0,
		0,
		1
	},{
		"Unknown2", fieldUnknown2,
		0,								0,							0,
		0,
		0,
		0,
		2
	},{
		"WebSite", fieldWebSite,
		0,								0,							0,
		"web site url",
		0,
		0,
		40
	},{
		szFieldYearsInDb, fieldYearsInDb,
		0, 0, "Years in Database",
		0,
		0,
		"",
		4
	},{
		"YearsInDb2", fieldYearsInDb2,
		0, 0, "Years in Database2",
		0,
		0,
		"",
		4
	},{
		"YearsInDb3", fieldYearsInDb3,
		0, 0, "Years in Database3",
		0,
		0,
		"",
		4
	},{
		"YearsInDb4", fieldYearsInDb4,
		0, 0, "Years in Database4",
		0,
		0,
		"",
		4
	},{
		"YearsInDb5", fieldYearsInDb5,
		0, 0, "Years in Database5",
		0,
		0,
		"",
		4
	},{
		"YearsInDb6", fieldYearsInDb6,
		0, 0, "Years in Database6",
		0,
		0,
		"",
		4
	},{
		"YPPANO", fieldYPPANO,
		0, 0, "YPPA Book number.", 
		0,
		0,
		0,
		6
	},{
		"Zip", fieldZip,
		0,								0,							0,
		"ZIP+4 & DPBC", 
		0,
		0,
		12
	},{
		"Zip5", fieldZip5,
		0,	0, "ZIP Code",
		0,
		0,
		"numeric",
		5
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuFieldDefSpecDft

#ifdef _DEBUG
#include "FieldDefSpec.h"
static void VerifyFieldDefSpecDft()
{
	static bool fFirstPass = true;
	if (!fFirstPass)
		return ;
	fFirstPass = false;

	bool fInOrder = true;
	for (int i = 0; i < CIuFieldDefSpecDft::GetCount(); ++i)
	{
		if (i > 1)
		{
			CString s1 = apFieldDef[i].m_pcszFieldDef;
			CString s2 = apFieldDef[i-1].m_pcszFieldDef;
			if (_tcsicmp(s1, s2) <= 0)
			{
				TRACE("ERROR: Field Specs '%s' && '%s' are out of order.\n", LPCTSTR(s1), LPCTSTR(s2));
				fInOrder = false;
			}
		}
	}

	ASSERT(fInOrder);

	CIuFieldDefSpec Spec;
	for (i = 0; i < CIuFieldDefSpecDft::GetCount(); ++i)
	{
		Spec.FromIndex(i);
		// NOTE: These checks should mirror the checks in 
		//			CIuFieldDefs::OnAdjust()

		CString sName = Spec.GetName();
		ASSERT(!sName.IsEmpty());
		ASSERT(IsIdentifier(sName));

		CString sLongName = Spec.GetLongName();
		ASSERT(!sLongName.IsEmpty());

		CString sShortName = Spec.GetShortName();
		ASSERT(!sShortName.IsEmpty());
		ASSERT(IsIdentifier(sShortName) && sShortName.GetLength() <= MaxShortNameLength);
	}
}
#else
#	define VerifyFieldDefSpecDft()
#endif

int CIuFieldDefSpecDft::Find(LPCTSTR pcszFieldDef)
{
	VerifyFieldDefSpecDft();
	ASSERT(AfxIsValidString(pcszFieldDef));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszFieldDef, pcszFieldDef) == 0)
			return i;
	}
	return -1;
}

int CIuFieldDefSpecDft::Find(int iFieldDef)
{
	VerifyFieldDefSpecDft();
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iFieldDef == iFieldDef)
			return i;
	}
	return -1;
}

const CIuFieldDefSpecDft* CIuFieldDefSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return apFieldDef + iWhich;
}

int CIuFieldDefSpecDft::GetCount()
{
	return sizeof(apFieldDef) / sizeof(apFieldDef[0]);
}

CString CIuFieldDefSpecDft::Resolve(CIuFieldDefSpecDft& FieldDefSpecDft)
{
	// Get the name
	CString sName;
	if (FieldDefSpecDft.m_pcszName)
		sName = FieldDefSpecDft.m_pcszName;
	else
		sName = FieldDefSpecDft.m_pcszFieldDef;

	// If the name starts with an equal sign, we 
	// "attach" to a secondary definition.
	if (sName.IsEmpty() || sName[0] != '=')
		return sName;

	sName = sName.Mid(1);
	for (int iAttached = 0; iAttached < GetCount(); ++iAttached)
	{
		CString sNameAttached = apFieldDef[iAttached].m_pcszFieldDef;
		if (_tcsicmp(sName, sNameAttached) == 0)
		{
			// Replace any null values in the original with actual
			// values from the attached.
			CIuFieldDefSpecDft Attached = apFieldDef[iAttached];
			if (FieldDefSpecDft.m_pcszName == 0)
			{
				if (Attached.m_pcszName)
					sName = Attached.m_pcszName;
			}
			if (FieldDefSpecDft.m_pcszShortName == 0)
				FieldDefSpecDft.m_pcszShortName = Attached.m_pcszShortName;
			if (FieldDefSpecDft.m_pcszLongName == 0)
				FieldDefSpecDft.m_pcszLongName = Attached.m_pcszLongName;
			if (FieldDefSpecDft.m_pcszDescription == 0)
				FieldDefSpecDft.m_pcszDescription = Attached.m_pcszDescription;
			if (FieldDefSpecDft.m_pcszExpression == 0)
				FieldDefSpecDft.m_pcszExpression = Attached.m_pcszExpression;
			if (FieldDefSpecDft.m_pcszOptions == 0)
				FieldDefSpecDft.m_pcszOptions = Attached.m_pcszOptions;
			if (FieldDefSpecDft.m_iLength == 0)
				FieldDefSpecDft.m_iLength = Attached.m_iLength;
			break;
		}
	}
	return sName;
}


