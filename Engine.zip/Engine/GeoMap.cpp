#include "StdAfx.h"
//{{Include
#include "GeoMap.h"
#include "GeoSpec.h"
#include "FieldDefConst.h"
#include "resource.h"
#include "Data\Output.h"
#include "FieldDefSpec.h"
#include "CdromSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoMap, CIuGeoMap_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoMap)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOMAP, CIuGeoMap, CIuGeoMap_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoMap, IDS_ENGINE_PPG_GEOMAP, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_ZIP, GetZip, SetZip, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_ZIP, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_STATE, GetState, SetState, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_STATE, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_CITY, GetCity, SetCity, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_CITY, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_MSACODE, GetMsaCode, SetMsaCode, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_MSACODE, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_COUNTYCODE, GetCountyCode, SetCountyCode, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_COUNTYCODE, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_LATITUDE, GetLatitude, SetLatitude, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_LATITUDE, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_LONGITUDE, GetLongitude, SetLongitude, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_LONGITUDE, IDS_ENGINE_PPG_GEOMAP, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoMap, IDS_ENGINE_PROP_MATCHLEVEL, GetMatchLevel, SetMatchLevel, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuGeoMap, IDS_ENGINE_PROP_MATCHLEVEL, IDS_ENGINE_PPG_GEOMAP, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoMap::CIuGeoMap() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoMap::~CIuGeoMap()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoMap::Clear()
{
	CIuGeoMap_super::Clear();
	CIuGeoMap::CommonConstruct();
}

void CIuGeoMap::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sZip = "";
	m_sCity = "";
	m_sState = "";
	m_sMsaCode = "";
	m_sCountyCode = "";
	m_sLatitude = "";
	m_sLongitude = "";
	m_sMatchLevel = "";
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuGeoMap::CreateMap(CIuFieldMap& map)
{
	map.RemoveAll();

	m_iZip = map.AddField(GetZip());
	m_iState = map.AddField(GetState());

	// NOTE: Generally, we need a state and ZIP for this to work...
	ASSERT(m_iZip >= 0);
	ASSERT(m_iState >= 0);

	// City should be set after state
	m_iCity = map.AddField(GetCity());

	// NOTE: Be sure to set state before msa/county/area codes
	m_iMsaCode = map.AddField(GetMsaCode());
	m_iCountyCode = map.AddField(GetCountyCode());
	m_iLatitude = map.AddField(GetLatitude());
	m_iLongitude = map.AddField(GetLongitude());
	m_iMatchLevel = map.AddField(GetMatchLevel());
}

void CIuGeoMap::Resolve(CIuResolveSpec& Spec)
{
	CreateMap(m_Map);

	// Resolve the output
	m_Map.Resolve(Spec);
}

void CIuGeoMap::SetCity(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCity = pcsz;
}

void CIuGeoMap::SetCountyCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sCountyCode = pcsz;
}

void CIuGeoMap::SetLatitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLatitude = pcsz;
}

void CIuGeoMap::SetLongitude(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sLongitude = pcsz;
}

void CIuGeoMap::SetMatchLevel(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMatchLevel = pcsz;
}

void CIuGeoMap::SetMsaCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sMsaCode = pcsz;
}

void CIuGeoMap::SetSpec(CIuGeoSpec& Spec)
{
	SetName(Spec.GetCdrom().GetName());

	SetCity(Spec.GetCity());
	SetCountyCode(Spec.GetCountyCode());
	SetLatitude(Spec.GetLatitude());
	SetLongitude(Spec.GetLongitude());
	SetMatchLevel(Spec.GetMatchLevel());
	SetMsaCode(Spec.GetMsaCode());
	SetState(Spec.GetState());
	SetZip(Spec.GetZip());
}

void CIuGeoMap::SetState(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sState = pcsz;
}

void CIuGeoMap::SetZip(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sZip = pcsz;
}
