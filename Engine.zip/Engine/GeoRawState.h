#ifndef _ENGINE_GEORAWSTATE_H_
#define _ENGINE_GEORAWSTATE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENT_H_
#	include "Engine\GeoRawElement.h"
#endif	// _ENGINE_GEORAWELEMENT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawState)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawState, CIuGeoRawElement }}
#define CIuGeoRawState_super CIuGeoRawElement
class CIuGeoRawState : public CIuGeoRawState_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawState)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawState();
	virtual ~CIuGeoRawState();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoRawElementAccumulator& GetZips() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetZips_() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	mutable CIuGeoRawElementAccumulator m_Zips;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoRawElementAccumulator& CIuGeoRawState::GetZips() const
{
	return m_Zips;
}

#endif // _ENGINE_GEORAWSTATE_H_
