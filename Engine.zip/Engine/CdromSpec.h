#ifndef _ENGINE_CDROMSPEC_H_
#define _ENGINE_CDROMSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdromSpec)
struct CIuCdromSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromSpec, CIuObjectNamed }}
#define CIuCdromSpec_super CIuObjectNamed

class CIuCdromSpec : public CIuCdromSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromSpec();
	CIuCdromSpec(LPCTSTR pcszName, int iMaxRecords = -1);
	CIuCdromSpec(int iIndex, int iMaxRecords = -1);
	virtual ~CIuCdromSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddressSpec& GetAddress() const;
	CString GetApplication() const;
	static void GetApplications(CStringArray& as);
	CIuAltSpec& GetAlt(int iAlt) const;
	int GetAltCount() const;
	POSITION GetAttributeFirst() const;
	void GetAttributeNext(POSITION& pos, CString& sName, CString& sValue) const;
	CIuBlobSpec& GetBlob(int iBlob) const;
	int GetBlobCount() const;
	CIuBTreeSpec& GetBTree(int iBTree) const;
	int GetBTreeCount() const;
	static int GetCount();
	CString GetDescription() const;
	CIuExportDefSpec& GetExportDef(int iExportDef) const;
	int GetExportDefCount() const;
	CString GetFilename() const;
	CString GetFormat() const;
	int GetFormatNo() const;
	CIuGeoSpec& GetGeo() const;
	int GetGroupCount() const;
	int GetGroupNo() const;
	int GetMaxRecords() const;
	CIuMeterSpec& GetMeter(int iMeter) const;
	int GetMeterCount() const;
	CString GetOptions() const;
	CString GetProduct() const;
	static void GetProductGroups(LPCTSTR pcszApplication, LPCTSTR pcszRelease, CStringArray& as);
	static void GetProducts(LPCTSTR pcszApplication, LPCTSTR pcszRelease, LPCTSTR pcszProductGroup, CStringArray& as);
	int GetProductNo() const;
	CString GetRelease() const;
	CIuReleaseNoteSpec& GetReleaseNote(int iReleaseNote) const;
	int GetReleaseNoteCount() const;
	static void GetReleases(LPCTSTR pcszApplication, CStringArray& as);
	CIuRegistrationSpec& GetRegistration() const;
	CIuReportDefSpec& GetReportDef(int iReportDef) const;
	int GetReportDefCount() const;
	CIuSicSpec& GetSic() const;
	CIuSplashSpec& GetSplash() const;
	int GetSplitSize() const;
	CIuCdromStripSpec& GetStrip(int iStrip) const;
	int GetStripCount() const;
	void GetStates(CStringArray& as) const;
	CString GetTitle() const;
	CIuTokenSpec& GetToken(int iToken) const;
	int GetTokenCount() const;
	CIuUserInterfaceSpec& GetUserInterface() const;
	bool HasAddress() const;
	bool HasDatabase() const;
	bool HasGeo() const;
	bool HasRegistration() const;
	bool HasSic() const;
	bool HasSplash() const;
	bool HasUserInterface() const;
	bool IncludeBusiness() const;
	bool IncludeResidential() const;
	bool IncludeSample() const;
	bool NoNoSolicit() const;
	bool NoSpouse() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int FindAlt(LPCTSTR pcszAlt);
	int FindBTree(LPCTSTR pcszBTree);
	static int FindProductRelease(LPCTSTR pcszProduct, LPCTSTR pcszRelease);
	static int FindProductRelease(int iProductNo, LPCTSTR pcszRelease);
	int FindToken(LPCTSTR pcszToken);
	void FromIndex(int iWhich);
	int FromName(LPCTSTR pcszName);
	int FromProductRelease(LPCTSTR pcszProduct, LPCTSTR pcszRelease);
	int FromProductRelease(int iProductNo, LPCTSTR pcszRelease);
	void RemoveAllAlts();
	void RemoveAllBlobs();
	void RemoveAllBTrees();
	void RemoveAllExportDefs();
	void RemoveAllMeters();
	void RemoveAllReleaseNotes();
	void RemoveAllReportDefs();
	void RemoveAllStrips();
	void RemoveAllTokens();
	bool SelectDlg(CWnd* pParent);
	void SetApplication(LPCTSTR);
	void SetDescription(LPCTSTR);
	void SetFilename(LPCTSTR);
	void SetFormat(LPCTSTR);
	void SetFormatNo(int iFormatNo);
	void SetGroupCount(int iGroupCount);
	void SetGroupNo(int iGroupNo);
	void SetHasDatabase(bool);
	void SetMaxRecords(int);
	void SetNoNoSolicit(bool);
	void SetNoSpouse(bool);
	void SetOptions(LPCTSTR);
	void SetProduct(LPCTSTR);
	void SetProductNo(int);
	void SetRelease(LPCTSTR);
	void SetSplitSize(int);
	void SetStates(const CStringArray&);
	void SetTitle(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetAddress_() const;
	CIuObject* GetGeo_() const;
	CIuObject* GetRegistration_() const;
	CIuObject* GetSic_() const;
	CIuObject* GetSplash_() const;
	CIuObject* GetUserInterface_() const;
private:
	void CommonConstruct();
	void FromSpec(const CIuCdromSpecDft* pSpec);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sProduct;
	CString m_sRelease;
	CString m_sApplication;
	CString m_sFilename;
	CString m_sTitle;
	CString m_sDescription;
	CStringArray m_asStates;
	CString m_sOptions;
	CString m_sFormat;
	int m_iMaxRecords;
	int m_iFormatNo;
	int m_iSplitSize;
	CMap<CString, LPCTSTR, CString, LPCTSTR> m_Attributes;

	CIuMeterSpecArray m_apMeters;
	CIuCdromStripSpecArray m_apStrips;
	CIuTokenSpecArray m_apTokens;
	CIuExportDefSpecArray m_apExportDefs;
	CIuReportDefSpecArray m_apReportDefs;
	CIuBTreeSpecArray m_apBTrees;
	CIuAltSpecArray m_apAlts;
	CIuBlobSpecArray m_apBlobs;
	CIuReleaseNoteSpecArray m_apReleaseNotes;
	CIuRegistrationSpecPtr m_pRegistration;
	CIuSplashSpecPtr m_pSplash;
	CIuUserInterfaceSpecPtr m_pUserInterface;
	CIuGeoSpecPtr m_pGeo;
	CIuSicSpecPtr m_pSic;
	CIuAddressSpecPtr m_pAddress;
	int m_iProductNo;
	bool m_fHasDatabase;
	int m_iGroupCount;
	int m_iGroupNo;
	bool m_fNoSpouse;
	bool m_fNoNoSolicit;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddressSpec& CIuCdromSpec::GetAddress() const
{
	return m_pAddress.Ref();
}

inline CString CIuCdromSpec::GetApplication() const
{
	return m_sApplication;
}

inline CString CIuCdromSpec::GetDescription() const
{
	return m_sDescription;
}

inline CString CIuCdromSpec::GetFilename() const
{
	return m_sFilename;
}

inline CString CIuCdromSpec::GetFormat() const
{
	return m_sFormat;
}

inline int CIuCdromSpec::GetFormatNo() const
{
	return m_iFormatNo;
}

inline CIuGeoSpec& CIuCdromSpec::GetGeo() const
{
	return m_pGeo.Ref();
}

inline int CIuCdromSpec::GetGroupCount() const
{
	return m_iGroupCount;
}

inline int CIuCdromSpec::GetGroupNo() const
{
	return m_iGroupNo;
}

inline int CIuCdromSpec::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline CString CIuCdromSpec::GetOptions() const
{
	return m_sOptions;
}

inline CString CIuCdromSpec::GetProduct() const
{
	return m_sProduct;
}

inline int CIuCdromSpec::GetProductNo() const
{
	return m_iProductNo;
}

inline CString CIuCdromSpec::GetRelease() const
{
	return m_sRelease;
}

inline CIuRegistrationSpec& CIuCdromSpec::GetRegistration() const
{
	return m_pRegistration.Ref();
}

inline CIuSicSpec& CIuCdromSpec::GetSic() const
{
	return m_pSic.Ref();
}

inline CIuSplashSpec& CIuCdromSpec::GetSplash() const
{
	return m_pSplash.Ref();
}

inline int CIuCdromSpec::GetSplitSize() const
{
	return m_iSplitSize;
}

inline CString CIuCdromSpec::GetTitle() const
{
	return m_sTitle;
}

inline CIuUserInterfaceSpec& CIuCdromSpec::GetUserInterface() const
{
	return m_pUserInterface.Ref();
}

inline bool CIuCdromSpec::HasAddress() const
{
	return m_pAddress.NotNull();
}

inline bool CIuCdromSpec::HasDatabase() const
{
	return m_fHasDatabase;
}

inline bool CIuCdromSpec::HasGeo() const
{
	return m_pGeo.NotNull();
}	

inline bool CIuCdromSpec::HasRegistration() const
{
	return m_pRegistration.NotNull();
}

inline bool CIuCdromSpec::HasSic() const
{
	return m_pSic.NotNull();
}

inline bool CIuCdromSpec::HasSplash() const
{
	return m_pSplash.NotNull();
}

inline bool CIuCdromSpec::HasUserInterface() const
{
	return m_pUserInterface.NotNull();
}

inline bool CIuCdromSpec::NoNoSolicit() const
{
	return m_fNoNoSolicit;
}

inline bool CIuCdromSpec::NoSpouse() const
{
	return m_fNoSpouse;
}

#endif // _ENGINE_CDROMSPEC_H_
