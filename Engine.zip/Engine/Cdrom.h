#ifndef _ENGINE_CDROM_H_
#define _ENGINE_CDROM_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_PACK_H_
#	include "Data\Pack.h"
#endif	// _DATA_PACK_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
#ifndef 	_ENGINE_SOURCEDESCRIPTORSPEC_H_
#	include "Engine\SourceDescriptorSpec.h"
#endif	// _ENGINE_SOURCEDESCRIPTORSPEC_H_
#ifndef 	_INTEROP_PRODUCT_H_
#	include "Interop\Product.h"
#endif	// _INTEROP_PRODUCT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdrom)
IU_DEFINE_OBJECT_PTR(CIuBTrees)
IU_DEFINE_OBJECT_PTR(CIuGeo)
IU_DEFINE_OBJECT_PTR(CIuTokens)
IU_DEFINE_OBJECT_PTR(CIuSic)
IU_DEFINE_OBJECT_PTR(CIuAddress)
IU_DEFINE_OBJECT_PTR(CIuAlts)
IU_DEFINE_OBJECT_PTR(CIuDatabase)
IU_DEFINE_OBJECT_PTR(CIuExportDefs)
IU_DEFINE_OBJECT_PTR(CIuMeters)
IU_DEFINE_OBJECT_PTR(CIuReportDefs)
IU_DEFINE_OBJECT_PTR(CIuReleaseNotes)
IU_DEFINE_OBJECT_PTR(CIuUserInterface)
IU_DEFINE_OBJECT_PTR(CIuSplash)
IU_DEFINE_OBJECT_PTR(CIuBlobs)
IU_DEFINE_OBJECT_PTR(CIuRegistration)
IU_DEFINE_OBJECT_PTR(CIuCdromInput)
IU_DEFINE_OBJECT_PTR(CIuSourceDescriptors) 
class CIuEngine;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdrom, CIuCollectable }}
#define CIuCdrom_super CIuCollectable

class CIuCdrom : public CIuCdrom_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdrom)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdrom();
	virtual ~CIuCdrom();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddress& GetAddress() const;
	CIuAlts& GetAlts() const;
	CIuBlobs& GetBlobs() const;
	CIuDatabase& GetDatabase() const;
	CIuBTrees& GetBTrees() const;
	CIuEngine& GetEngine() const;
	CIuExportDefs& GetExportDefs() const;
	CString GetFilename() const;
	CIuGeo& GetGeo() const;
	CIuCdromInput& GetInput() const;
	CIuMeters& GetMeters() const;
	CIuObjectRepository& GetObjectRepository() const;
	CIuPack& GetPack() const;
	CIuReleaseNotes& GetReleaseNotes() const;
	CIuReportDefs& GetReportDefs() const;
	CIuRegistration& GetRegistration() const;
	CIuSic& GetSic() const;
	CIuSourceDescriptors& GetSources() const; 
	CIuSplash& GetSplash() const;
	int GetSplitSize() const;
	CIuTokens& GetTokens() const;
	CIuUserInterface& GetUserInterface() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasAddress() const;
	bool HasDatabase() const;
	bool HasGeo() const;
	bool HasEngine() const;
	bool HasPack() const;
	bool HasRegistration() const;
	bool HasSic() const;
	bool HasSplash() const;
	bool HasUserInterface() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags = 0);
	void CreateIndex(const CIuSourceDescriptorSpec& Spec);
	void CreateIndexes(CIuSourceDescriptorSpecArray& Specs);
	void Delete(CIuOutput* pOutput);
	void Log(LPCTSTR pcszTitle, LPCTSTR pcszText = 0) const;
	bool SelectDlg(CWnd* pParent);
	void SetFilename(LPCTSTR);
	void SetOwner(CIuObject* pOwner);
	void SetSpec(CIuCdromSpec& Spec);
	void SetSplitSize(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionViewPack(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CIuObject* GetAddress_() const;
	CIuObject* GetAlts_() const;
	CIuObject* GetBlobs_() const;
	CIuObject* GetBTrees_() const;
	CIuObject* GetDatabase_() const;
	CIuObject* GetExportDefs_() const;
	CIuObject* GetGeo_() const;
	CIuObject* GetInput_() const;
	CIuObject* GetMeters_() const;
	CIuObject* GetPack_() const;
	CIuObject* GetRegistration_() const;
	CIuObject* GetReleaseNotes_() const;
	CIuObject* GetReportDefs_() const;
	CIuObject* GetObjectRepository_() const;
	CIuObject* GetSic_() const;
	CIuObject* GetSources_() const;
	CIuObject* GetSplash_() const;
	CIuObject* GetTokens_() const;
	CIuObject* GetUserInterface_() const;

private:
	bool BuildChildren(CIuOutput& Output, CIuFlags Flags);
	bool BuildID(CIuOutput& Output);
	void CommonConstruct();
	void SetEngine(CIuEngine& Engine);
	void UpdateObjectRepository(CIuOutput& Output);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Persistent attributes
	CString m_sFilename;
	int m_iSplitSize;

	// The product object used to write the ID file
	CIuProduct m_Product;

	// Child objects
	CIuBTreesPtr m_pBTrees;
	CIuTokensPtr m_pTokens;
	CIuAltsPtr m_pAlts;
	CIuDatabasePtr m_pDatabase;
	CIuExportDefsPtr m_pExportDefs;
	CIuMetersPtr m_pMeters;
	CIuReportDefsPtr m_pReportDefs;
	CIuReleaseNotesPtr m_pReleaseNotes;
	CIuUserInterfacePtr m_pUserInterface;
	CIuSplashPtr m_pSplash;
	CIuBlobsPtr m_pBlobs;
	CIuRegistrationPtr m_pRegistration;
	CIuCdromInputPtr m_pInput;
	CIuSicPtr m_pSic;
	CIuAddressPtr m_pAddress;
	CIuGeoPtr m_pGeo;
	CIuSourceDescriptorsPtr m_pSources; 

	// The actual cd-rom data file
	CIuPackPtr m_pPack;

	// Miscellaneous local data
	CIuObjectRepositoryPtr m_pObjectRepository;

	// Back pointer to engine
	CIuEngine* m_pEngine;
//}}Data

};
 
//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddress& CIuCdrom::GetAddress() const
{
	return m_pAddress.Ref();
}

inline CIuAlts& CIuCdrom::GetAlts() const
{
	return m_pAlts.Ref();
}

inline CIuBlobs& CIuCdrom::GetBlobs() const
{
	return m_pBlobs.Ref();
}

inline CIuBTrees& CIuCdrom::GetBTrees() const
{
	return m_pBTrees.Ref();
}

inline CIuDatabase& CIuCdrom::GetDatabase() const
{
	return m_pDatabase.Ref();
}

inline CIuEngine& CIuCdrom::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

inline CIuExportDefs& CIuCdrom::GetExportDefs() const
{
	return m_pExportDefs.Ref();
}

inline CString CIuCdrom::GetFilename() const
{
	return m_sFilename;
}

inline CIuGeo& CIuCdrom::GetGeo() const
{
	return m_pGeo.Ref();
}

inline CIuCdromInput& CIuCdrom::GetInput() const
{
	return m_pInput.Ref();
}

inline CIuMeters& CIuCdrom::GetMeters() const
{
	return m_pMeters.Ref();
}

inline CIuObjectRepository& CIuCdrom::GetObjectRepository() const
{
	return m_pObjectRepository.Ref();
}

inline CIuPack& CIuCdrom::GetPack() const
{
	return m_pPack.Ref();
}

inline CIuRegistration& CIuCdrom::GetRegistration() const
{
	return m_pRegistration.Ref();
}

inline CIuReleaseNotes& CIuCdrom::GetReleaseNotes() const
{
	return m_pReleaseNotes.Ref();
}

inline CIuReportDefs& CIuCdrom::GetReportDefs() const
{
	return m_pReportDefs.Ref();
}

inline CIuSic& CIuCdrom::GetSic() const
{
	return m_pSic.Ref();
}

inline CIuSourceDescriptors& CIuCdrom::GetSources() const
{
	return m_pSources.Ref();
}

inline CIuSplash& CIuCdrom::GetSplash() const
{
	return m_pSplash.Ref();
}

inline int CIuCdrom::GetSplitSize() const
{
	return m_iSplitSize;
}

inline CIuTokens& CIuCdrom::GetTokens() const
{
	return m_pTokens.Ref();
}

inline CIuUserInterface& CIuCdrom::GetUserInterface() const
{
	return m_pUserInterface.Ref();
}

inline bool CIuCdrom::HasAddress() const
{
	return m_pAddress.NotNull();
}

inline bool CIuCdrom::HasDatabase() const
{
	return m_pDatabase.NotNull();
}

inline bool CIuCdrom::HasEngine() const
{
	return m_pEngine != 0;
}

inline bool CIuCdrom::HasGeo() const
{
	return m_pGeo.NotNull();
}

inline bool CIuCdrom::HasPack() const
{
	return m_pPack.NotNull();
}

inline bool CIuCdrom::HasRegistration() const
{
	return m_pRegistration.NotNull();
}

inline bool CIuCdrom::HasSic() const
{
	return m_pSic.NotNull();
}

inline bool CIuCdrom::HasSplash() const
{
	return m_pSplash.NotNull();
}

inline bool CIuCdrom::HasUserInterface() const
{
	return m_pUserInterface.NotNull();
}

#endif // _ENGINE_CDROM_H_
