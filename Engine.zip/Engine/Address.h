#ifndef _ENGINE_ADDRESS_H_
#define _ENGINE_ADDRESS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddress)
class CIuAddressSpec;
class CIuAddressRaw;
class CIuCdrom;
class CIuElementCollection;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Address Types
enum CIuAddressNo
{
	addressNone = 0,

	addressStandard,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddress, CIuObjectNamed }}
#define CIuAddress_super CIuObjectNamed

class CIuAddress : public CIuAddress_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddress)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddress();
	virtual ~CIuAddress();
	CIuAddress(const CIuAddress&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool Exists() const;
	int GetAddressSize() const;
	CString GetFilename() const;
	CString GetFullFilename() const;
	CIuObjectRepository& GetObjectRepository() const;
	LPCTSTR GetStreetName(int iStreetName) const;
	int GetStreetNameCount() const;
	int GetStreetNamePostDir(int iStreetName) const;
	int GetStreetNamePreDir(int iStreetName) const;
	int GetStreetNameSuffix(int iStreetName) const;
	LPCTSTR GetSuffix(int iSuffix) const;
	int GetSuffixCount() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasObjectRepository() const;
	bool IsOpen() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Close(bool fForce = false);
	virtual void Copy(const CIuObject& object);
	void Delete(CIuOutput* pOutput = 0);
	void Empty();
	int FindStreetName(LPCTSTR pcszStreetName, int iSuffix) const;
	int FindSuffix(LPCTSTR pcszSuffix) const;
	void Open();
	void SetAddressSize(int iAddressSize);
	void SetFilename(LPCTSTR);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetSpec(CIuAddressSpec& Spec);
	void SetStreetNameCount(int iStreetNameCount);
	void SetSuffixCount(int iSuffixCount);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuAddress& operator=(const CIuAddress&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
private:
	bool BuildCompress(CIuCdrom& Cdrom, CIuOutput& Output);
	void CommonConstruct();
	bool CompressStreetNames(CIuAddressRaw& Raw, CIuBuffer& Buffer, CIuOutput& Output);
	int DeCompressStreetNames(const BYTE* pb, int cb, CArray<LPCTSTR, LPCTSTR>& aStrings, int iStrings);
	void SanityCheck(CIuOutput& Output, CIuAddressRaw& Raw);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Non-persistent
		// Data related to the persistent storage location
		CIuObjectRepository* m_pObjectRepository;
		// Open flag
		int m_iOpen;
		// Buffer for data
		CIuBigBuffer m_Buffer;
		// Pointers to the data
		mutable CArray<LPCTSTR, LPCTSTR> m_aStreetNames;
		mutable CArray<LPCTSTR*, LPCTSTR*> m_aStreetNamesSorted;
		mutable CArray<LPCTSTR, LPCTSTR> m_aSuffixes;
		mutable CArray<LPCTSTR*, LPCTSTR*> m_aSuffixesSorted;
	// Persistent
		// Address filename
		CString m_sFilename;
		// Total buffer size needed
		int m_iAddressSize;
		// Number of street names and suffixes in data
		int m_iStreetNameCount;
		int m_iSuffixCount;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAddress::GetAddressSize() const
{
	return m_iAddressSize;
}

inline CIuObjectRepository& CIuAddress::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline LPCTSTR CIuAddress::GetStreetName(int iStreetName) const
{
	return m_aStreetNames[iStreetName];
}

inline int CIuAddress::GetStreetNameCount() const
{
	return m_iStreetNameCount;
}

inline LPCTSTR CIuAddress::GetSuffix(int iSuffix) const
{
	return m_aSuffixes[iSuffix];
}

inline int CIuAddress::GetSuffixCount() const
{
	return m_iSuffixCount;
}

inline bool CIuAddress::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuAddress::IsOpen() const
{
	return m_iOpen > 0;
}

#endif // _ENGINE_ADDRESS_H_
