#include "StdAfx.h"
//{{Include
#include "InputMsa.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputMsa, CIuInputMsa_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputMsa)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTMSA, CIuInputMsa, CIuInputMsa_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputMsa, IDS_ENGINE_PPG_INPUTMSA, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputMsa::CIuInputMsa() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputMsa::~CIuInputMsa()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputMsa::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input MSA"));
	SetInputFilename("PMsaD.");
	SetOutputFilename("Msa");
	SetFormat(inputMsa);
	//}}Initialize
}

void CIuInputMsa::Delete(CIuOutput* pOutput)
{
	CIuInputMsa_super::Delete(pOutput);
	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	CdromDelete(FilenameOutput, pOutput);
}

void CIuInputMsa::OnClose()
{
	m_FileInput.Close();
	m_FileOutput.Close();
	CIuInputMsa_super::OnClose();
}

bool CIuInputMsa::OnMoveNext()
{
	if (!m_FileInput.ReadString(m_sInput))
		return false;

	if (m_sInput.GetLength() < 4)
		return true;

	m_sMsaCode = m_sInput.Mid(0, 4);
	m_sMsaCode.TrimRight();
	m_sMsaCode.MakeUpper();
	if (m_sMsaCode.GetLength() != 4)
	{
		TRACE("WARNING: Invalid Msa code '%s'\n", LPCTSTR(m_sMsaCode));
		return true;
	}

	m_sMsaName = m_sInput.Mid(4);
	m_sMsaName.TrimRight();
	m_sMsaName.MakeUpper();
	if (m_sMsaName.IsEmpty())
		return true;

	ClearFields();
	SetField(inputFieldMsaCode, m_sMsaCode);
	SetField(inputFieldMsaName, m_sMsaName);

	return Output();
}

bool CIuInputMsa::OnOutput()
{
	// Just to be nice, we dump a text file version of the output
	m_sOutput = _T("\"");
	m_sOutput += GetField(inputFieldMsaCode);
	m_sOutput += _T("\",\"");
	m_sOutput += GetField(inputFieldMsaName);
	m_sOutput += _T("\"\n");

	m_FileOutput.WriteString(m_sOutput);

	return CIuInputMsa_super::OnOutput();
}

bool CIuInputMsa::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputMsa_super::OnOpen(OpenSpec))
		return false;

	CIuFilename FilenameInput = GetFullInputFilename();
	if (!FilenameInput.Exists())
	{
		GetOutput().OutputF(_T("*** WARNING: MSA master file, %s, not found\n"), LPCTSTR(FilenameInput));
		return false;
	}
	m_FileInput.Open(FilenameInput, CFile::modeRead|CFile::shareDenyNone|CFile::typeText);

	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	m_FileOutput.Open(FilenameOutput, CFile::modeCreate|CFile::modeReadWrite|CFile::shareExclusive|CFile::typeText);

	return true;
}
