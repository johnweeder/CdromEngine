#ifndef _ENGINE_RECORDSORT_H_
#define _ENGINE_RECORDSORT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDHEAPSORT_H_
#	include "Engine\RecordHeapSort.h"
#endif	// _ENGINE_RECORDHEAPSORT_H_
#ifndef 	_ENGINE_RECORDFILE_H_
#	include "Engine\RecordFile.h"
#endif	// _ENGINE_RECORDFILE_H_
#ifndef 	_COMMON_FILEMIRROR_H_
#	include "Common\FileMirror.h"
#endif	// _COMMON_FILEMIRROR_H_
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordSort)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Predefined sort type
enum CIuRecordSortNo
{
	sortNone = 0,

	sortAddress,
	sortBusiness,
	sortBusinessFranchise,
	sortPhone, 
	sortStandardByName, 
	sortZip,
	sortZip4,
	sortZip5,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordSort, CIuObjectNamed }}
#define CIuRecordSort_super CIuObjectNamed

class CIuRecordSort : public CIuRecordSort_super
{
//{{Declare
	DECLARE_SERIAL(CIuRecordSort)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordSort();
	virtual ~CIuRecordSort();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetBufferSize() const;
	bool GetDeDup() const;
	CString GetFullOutput() const;
	CString GetInput() const;
	int GetMergeSize() const;
	CString GetOutput() const;
	CIuFieldMap& GetKeyMap() const;
	CIuRecordFile& GetInputFile() const;
	bool ShouldReOrder() const;
	bool StoreKeys() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags);
	void Close();
	void Delete(CIuOutput* pOutput);
	void SetBufferSize(int);
	void SetDeDup(bool);
	void SetInput(LPCTSTR);
	void SetMergeSize(int);
	void SetOutput(LPCTSTR);
	void SetReOrder(bool);
	void SetSpec(int iSpec, LPCTSTR pcszInput = 0, LPCTSTR pcszOutput = 0);
	void SetStoreKeys(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnEditBegin();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionSort(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CIuObject* GetInputFile_() const;
	CIuObject* GetKeyMap_() const;
private:
	bool CreateHeap();
	CIuRecordFilePtr CreateRun(bool fFinal = false);
	bool CreateRuns();
	bool Merge();
	bool Merge(int iMerge, CIuRecordPtrArray& array);
	bool OpenInput();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Data used during sort
	CIuRecordHeapSort m_hs;
	CArray<CIuRecordFilePtr, CIuRecordFile*> m_apOutputFile;
	CIuRecordPtr m_pRecord;
	CIuRecordPtr m_pRecordMapped;
	CIuRecordPtr m_pRecordPrev;
	CIuOutput* m_pOutput;
	CIuFileMirror m_mirror;
	int m_iInput;
	int m_iOutput;
	int m_iDeDuped;
	int m_iSortFlags;
	// Persistent
	CString m_sOutput;
	int m_iBufferSize;
	int m_iMergeSize;
	bool m_fDeDup;
	CString m_sFullOutput; 
	CIuFieldMapPtr m_pKeyMap;
	CIuRecordFilePtr m_pInputFile;
	bool m_fReOrder;
	bool m_fStoreKeys;
	CString m_sInput;
//}}Data

};

//{{Defines
//}}Defines

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuRecordSort::GetInput() const
{
	return m_sInput;
}

inline bool CIuRecordSort::ShouldReOrder() const
{
	return m_fReOrder;
}

inline bool CIuRecordSort::StoreKeys() const
{
	return m_fStoreKeys;
}

#endif // _ENGINE_RECORDSORT_H_
