#include "StdAfx.h"
//{{Include
#include "Record.h"
#include "RecordSpec.h"
#include "FieldMap.h"
#include "Key.h"
#include "Error\Error.h"
#include "RecordDlg.h"
#include "FieldDefConst.h"
#include "CaseConversion.h"
//}}Include

#ifdef _DEBUG
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Local Data
BYTE m_abDwordSize[] = 
	{ 0,  4,  4,  8,  8, 12, 12, 16,  4,  8,  8, 12, 12, 16, 16, 20,  4,  8,  8, 12, 12, 16, 16, 20,  8, 12, 12, 16, 16, 20, 20, 24 };

BYTE m_abExpandCountOffset[] = 
	{ 0,  0,  1,  1,  2,  2,  3,  3,  1,  1,  2,  2,  3,  3,  4,  4,  1,  1,  2,  2,  3,  3,  4,  4,  2,  2,  3,  3,  4,  4,  5,  5 };

BYTE m_abExpandNoOffset[] = 
	{ 0,  0,  0,  0,  2,  2,  2,  2,  1,  1,  1,  1,  3,  3,  3,  3,  1,  1,  1,  1,  3,  3,  3,  3,  2,  2,  2,  2,  4,  4,  4,  4 };

BYTE m_abLatLongOffset[] = 
	{ 0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  2,  2,  2,  2,  2,  2,  2,  2 };

BYTE m_abSourceNoOffset[] = 
	{ 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1 };

#define OFFSETS_SIZE(fields)		(((fields)+1)*sizeof(WORD))
#define m_wDwordOffset				m_awFieldOffset[m_wFields]

/////////////////////////////////////////////////////////////////////////////
// Helpers

static int GetRequiredSize(int iFields, int iData, WORD wFlags, int cbKey)
{
	if (cbKey > 0)
		wFlags |= recordKey;
	ASSERT(iFields >= 0);
	ASSERT(iFields <= recordMaxFields);
	int iSize =
		+ sizeof(CIuRecord)
		+ OFFSETS_SIZE(iFields)
		+ iData
		+ CIuRecord::GetDwordSize(wFlags) 
		+ cbKey;
	return iSize;
}

static int GetRequiredSizeBuffer(const BYTE* pb, int cb)
{
	ASSERT(cb >= sizeof(WORD));
	ASSERT(pb);
	if (cb < 3 * sizeof(WORD) || pb == 0)
		return sizeof(CIuRecord);

	const WORD* pw = reinterpret_cast<const WORD*>(pb);
	if (*pw == recordLoVal || *pw == recordHiVal)
		return sizeof(CIuRecord);

	// The buffer contains: fields, flags, data
	// We will need a complete structure plus the data size and field offset.
	// However, the field counts/flags/key offset are in 'cb' already, so subtract them back out
	int iFields = int(pw[0]);

	int iSize =
		sizeof(CIuRecord)
		+ cb
		+ OFFSETS_SIZE(iFields)
		- 3 * sizeof(WORD); 

	return iSize;
}

static int GetRequiredSizeSpec(CIuRecordSpec& Spec)
{
	int iFields = Spec.m_iRecordFields < 0 ? Spec.m_iFields: Spec.m_iRecordFields;
	int iData = 0;
	for (int iField = 0; iField < iFields; ++iField)
	{
		iData += Spec.m_acb[iField] + 1;
	}
	WORD wFlags = WORD(Spec.m_wFlags|Spec.m_wExtra);
	int cbKey = Spec.m_Key.GetKeySize() + Spec.m_cbKey + Spec.m_cbKeyExtra;
	int iRequiredSize = GetRequiredSize(iFields, iData, wFlags, cbKey);
	return iRequiredSize;
}

/////////////////////////////////////////////////////////////////////////////
// CIuRecord members

void CIuRecord::CaseConvert(int iCaseConvert)
{
	// In-place case conversion
	if (iCaseConvert == caseNoConvert)
		return ;

	for (int iField = 0; iField < int(m_wFields); ++iField)
	{
		int iSize;
		const char* pcsz = GetField(iField, iSize);
		CaseConvertInPlace(LPTSTR(pcsz), iSize, CIuCaseConversionMode(iCaseConvert), 0);
	}
}

void CIuRecord::CaseConvert(int iCaseConvert, CIuRecordDef& RecordDef)
{
	if (iCaseConvert == caseNoConvert)
		return ;

	CIuFieldDefs FieldDefs = RecordDef.GetFieldDefs();
	if (m_wFields == FieldDefs.GetCount())
	{
		for (int iField = 0; iField < int(m_wFields); ++iField)
		{
			int iSize;
			const char* pcsz = GetField(iField, iSize);
			CIuFieldDef& FieldDef = FieldDefs.Get(iField);
			int iFlags = FieldDef.GetFlags();
			CaseConvertInPlace(LPTSTR(pcsz), iSize, CIuCaseConversionMode(iCaseConvert), iFlags);
		}
	}
	else
	{
		// Can end up here for see-also/alternates, etc
		for (int iField = 0; iField < int(m_wFields); ++iField)
		{
			int iSize;
			const char* pcsz = GetField(iField, iSize);
			CaseConvertInPlace(LPTSTR(pcsz), iSize, CIuCaseConversionMode(iCaseConvert), 0);
		}
	}
}

void CIuRecord::Clear(bool fHiVal)
{
	m_wUsedSize = recordOverhead + sizeof(m_wFields);
	ASSERT(m_wUsedSize <= m_wTotalSize);
	if (fHiVal)
		m_wFields = recordHiVal;
	else
		m_wFields = recordLoVal;
	m_wFlags = 0;
	m_wKeyOffset = recordMaxKeyOffset + 1;
}

int CIuRecord::Compare(const CIuRecord& Record, int iFlags) const
{
	// This is a key based compare...

	// Special compare to allow for empty records (low val) and high vals....
	bool fLoVal1 = IsLoVal();
	bool fLoVal2 = Record.IsLoVal();
	bool fHiVal1 = IsHiVal();
	bool fHiVal2 = Record.IsHiVal();
	if (fLoVal1 && fLoVal2)
		return 0;
	else if (fHiVal1 && fHiVal2)
		return 0;
	else if (fHiVal1)
		return 1;
	else if (fHiVal2)
		return -1;
	else if (fLoVal1)
		return -1;
	else if (fLoVal2)
		return 1;

	bool fNoCase = ((iFlags & recordSortCaseSensitive) == 0);

	const BYTE* pbKey1 = GetKeyPtr();
	int iKey1 = GetKeySize();
	const BYTE* pbKey2 = Record.GetKeyPtr();
	int iKey2 = Record.GetKeySize();

	int iCmp = min(iKey1, iKey2);

	int iResult;
	if (fNoCase)
		iResult = memicmp(pbKey1, pbKey2, iCmp);
	else
		iResult = memcmp(pbKey1, pbKey2, iCmp);

	if (iResult < 0)
		return -1;
	else if (iResult > 0)
		return 1;
	else if (iKey1 < iKey2)
		return -1;
	else if (iKey1 > iKey2)
		return 1;

	if ((iFlags & recordSortRecordNo) == 0)
		return 0;

	DWORD dwRecordNo1 = GetRecordNo();
	DWORD dwRecordNo2 = Record.GetRecordNo();
	if (dwRecordNo1 > dwRecordNo2)
		return 1;
	else if (dwRecordNo1 < dwRecordNo2)
		return -1;
	else
	{
		DWORD dwSrcNo1 = GetSourceNo();
		DWORD dwSrcNo2 = Record.GetSourceNo();
		if (dwSrcNo1 > dwSrcNo2)
			return 1;
		else if (dwSrcNo1 < dwSrcNo2)
			return -1;
	}
	return 0;
}

int CIuRecord::Compare(const CIuRecord& Record, const CIuFieldMap& compare, int iFlags) const
{
	ASSERT(compare.IsResolved());
	// NOTE: This compare does not deal with literal fields or expressions.
	//			It is strictly a field-to-field compare.

	// Special compare to allow for empty records (low val) and high vals....
	bool fLoVal1 = IsLoVal();
	bool fLoVal2 = Record.IsLoVal();
	bool fHiVal1 = IsHiVal();
	bool fHiVal2 = Record.IsHiVal();
	if (fLoVal1 && fLoVal2)
		return 0;
	else if (fHiVal1 && fHiVal2)
		return 0;
	else if (fHiVal1)
		return 1;
	else if (fHiVal2)
		return -1;
	else if (fLoVal1)
		return -1;
	else if (fLoVal2)
		return 1;

	int iFields = compare.m_iFields;
	ASSERT(iFields <= GetFields());
	ASSERT(iFields <= Record.GetFields());

	bool fNoCase = ((iFlags & recordSortCaseSensitive) == 0);

	for (int iField = 0; iField < iFields; ++iField)
	{
		int iWhich = compare.m_aFieldNo[iField];
		// Ignore fields which weren't found, are expression or are literals
		if (iWhich < 0)
			continue;
		LPCTSTR pcsz1 = GetField(iWhich);
		LPCTSTR pcsz2 = Record.GetField(iWhich);
		bool fRightJustify = (compare.m_aFieldFlags[iField] & fieldSortNumeric) != 0;
		if (fRightJustify)
		{
			int iLen1 = GetFieldSize(iWhich);
			int iLen2 = Record.GetFieldSize(iWhich);
			if (iLen1 > iLen2)
				return 1;
			else if (iLen1 < iLen2)
				return -1;
		}
		int iResult;
		if (fNoCase)
			iResult = stricmp(pcsz1, pcsz2);
		else
			iResult = strcmp(pcsz1, pcsz2);
		if (iResult != 0)
			return iResult;
	}

	if ((iFlags & recordSortRecordNo) == 0)
		return 0;

	DWORD dwRecordNo1 = GetRecordNo();
	DWORD dwRecordNo2 = Record.GetRecordNo();
	if (dwRecordNo1 > dwRecordNo2)
		return 1;
	else if (dwRecordNo1 < dwRecordNo2)
		return -1;
	else
	{
		DWORD dwSrcNo1 = GetSourceNo();
		DWORD dwSrcNo2 = Record.GetSourceNo();
		if (dwSrcNo1 > dwSrcNo2)
			return 1;
		else if (dwSrcNo1 < dwSrcNo2)
			return -1;
	}
	return 0;
}

int CIuRecord::Compare(const CIuKey& key, bool* pfPartial) const
{
	// Special compare to allow for empty records (low val) and high vals....
	// NOTE: LoVal and Invalid are considered equal for comparison purposes.
	bool fLoVal1 = IsLoVal();
	bool fLoVal2 = key.IsLoVal() || key.IsInvalid();
	bool fHiVal1 = IsHiVal();
	bool fHiVal2 = key.IsHiVal();
	if (fLoVal1 && fLoVal2)
		return 0;
	else if (fHiVal1 && fHiVal2)
		return 0;
	else if (fHiVal1)
		return 1;
	else if (fHiVal2)
		return -1;
	else if (fLoVal1)
		return -1;
	else if (fLoVal2)
		return 1;

	if (pfPartial)
		*pfPartial = false;

	int iCmp = min(GetKeySize(), key.GetKeySize());

	const BYTE* pb1 = GetKeyPtr();
	const BYTE* pb2 = key.GetKeyPtr();

	int iResult = memicmp(pb1, pb2, iCmp);
	if (iResult < 0)
		return -1;
	else if (iResult > 0)
		return 1;
	else if (GetKeySize() < key.GetKeySize())
	{
		return -1;
	}
	else if (GetKeySize() > key.GetKeySize())
	{
		if (key.IsWildCard())
		{
			if (pfPartial)
				*pfPartial = true;
			return 0;
		}
		else
			return 1;
	}
	return 0;
}

void CIuRecord::Construct(WORD wSize)
{
	ASSERT(wSize >= sizeof(CIuRecord));
	ASSERT(sizeof(CIuRecord) == 12);
	m_wTotalSize = wSize;
	m_wUsedSize = recordOverhead + sizeof(m_wFields);
	m_wRef = 0;
	m_wFields = recordLoVal;
	m_wFlags = 0;
	m_wKeyOffset = recordMaxKeyOffset + 1;
}

void CIuRecord::Delete(CIuRecord* pRecord)
{
	ASSERT(pRecord);
	ASSERT(AfxIsValidAddress(pRecord, pRecord->m_wTotalSize, false));
	delete [] reinterpret_cast<BYTE*>(pRecord);
}

void CIuRecord::Dump() const
{
#ifdef _DEBUG
	afxDump << LPCTSTR(DumpAsString());
#endif
}

CString CIuRecord::DumpAsString() const
{
	CString sDump;
	CString s;
	s.Format("RECORD: 0x%08lX\n", this);
	sDump += s;
	s.Format("\t%05d total bytes\n", int(m_wTotalSize));
	sDump += s;
	s.Format("\t%05d used bytes\n", int(m_wUsedSize));
	sDump += s;
	s.Format("\t%05d reference count\n", int(m_wRef));
	sDump += s;
	if (IsLoVal())
	{
		s.Format("\tLOVAL\n");
		sDump += s;
		return s;
	}
	if (IsHiVal())
	{
		s.Format("\tHIVAL\n");
		sDump += s;
		return s;
	}
	s.Format("\t%04X flags\n", int(m_wFlags));
	sDump += s;
	if (HasRecordNo())
	{
		s.Format("\t\tRecord No: %d\n", GetRecordNo());
		sDump += s;
	}
	if (HasSourceNo())
	{
		s.Format("\t\tSource No: %08X\n", GetSourceNo());
		sDump += s;
	}
	if (HasLatLong())
	{
		DWORD dwLat, dwLong;
		GetLatLong(dwLat, dwLong);
		s.Format("\t\tLat/Long: %d / %d\n", dwLat, dwLong);
		sDump += s;
	}
	if (HasExpandNo())
	{
		ASSERT(HasExpandCount());
		DWORD dwExpandNo, dwExpandCount;
		GetExpandNo(dwExpandNo, dwExpandCount);
		s.Format("\t\tExpand No/Count: %d / %d\n", dwExpandNo, dwExpandCount);
		sDump += s;
	}
	else if (HasExpandCount())
	{
		DWORD dwCount = GetExpandCount();
		s.Format("\t\tCount: %d\n", dwCount);
		sDump += s;
	}
	if (IsAlternate())
	{
		s.Format("\t\tAlternate record\n");
		sDump += s;
	}
	if (IsNoPhone())
	{
		s.Format("\t\tNo Phone\n");
		sDump += s;
	}
	if (IsNoMail())
	{
		s.Format("\t\tNo Mail\n");
		sDump += s;
	}
	if (IsTagged())
	{
		s.Format("\t\tTagged\n");
		sDump += s;
	}
	if ((m_wFlags & recordBoughtMask) != 0)
	{
		s.Format("\t\tBought level %d\n", GetBoughtLevel());
		sDump += s;
	}

	s.Format("\t%05d fields\n", int(m_wFields));
	sDump += s;
	s.Format("\t\tOffset Length Value\n");
	sDump += s;
	for (int i = 0; i < int(m_wFields); ++i)
	{
		const char* pcszField = reinterpret_cast<const char*>(this) + m_awFieldOffset[i];
		s.Format("\t\t%05d  %05d [%s]\n",
			int(m_awFieldOffset[i]),
			int(m_awFieldOffset[i+1] - m_awFieldOffset[i]),
			pcszField);
		sDump += s;
	}

	if ((m_wFlags & recordKey) != 0)
	{
		s.Format("\tKey:\n");
		sDump += s;
		int iKeySize = GetKeySize();
		LPCTSTR pcszKey = LPCTSTR(GetKeyPtr());
		s.Format("\t\t%d bytes\n", iKeySize);
		sDump += s;

		CString sKey;
		for (int i = 0; i < iKeySize; ++i)
		{
			if (_istprint(pcszKey[i]))
				sKey += pcszKey[i];
			else
				sKey += _T("^");
		}
		s.Format("\t\t[%s]\n", LPCTSTR(sKey));
		sDump += s;
		if (m_wKeyOffset <= recordMaxKeyOffset)
		{
			s.Format("\t\tKey Offset: %d\n", int(m_wKeyOffset));
			sDump += s;
		}
		else
		{
			WORD wFields = WORD(m_wKeyOffset - recordMaxKeyOffset);
			s.Format("\t\tKey Fields: %d\n", int(wFields));
			sDump += s;
		}
	}
	return sDump;
}

void CIuRecord::Get(CStringArray& as) const
{
	as.RemoveAll();
	int iFields = GetFields();
	for (int iField = 0; iField < iFields; ++iField)
		as.Add(GetField(iField));
}

const char* CIuRecord::GetAltKey() const
{
	if (m_wFields < 1 || !IsAlternate())
		return "";
	return reinterpret_cast<const char*>(this) + m_awFieldOffset[0];
}

const char* CIuRecord::GetAltValue() const
{
	if (m_wFields < 2 || !IsAlternate())
		return "";
	return reinterpret_cast<const char*>(this) + m_awFieldOffset[1];
}

int CIuRecord::GetBoughtLevel() const
{
	return m_wFlags & recordBoughtMask;
}

void CIuRecord::GetBuffer(CIuBuffer& Buffer) const
{
	// Special case...
	if (IsHiVal() || IsLoVal())
	{
		Buffer.SetSize(sizeof(WORD));
		ASSERT(m_wFields == recordLoVal || m_wFields == recordHiVal);
		Buffer.Append((const BYTE*)&m_wFields, sizeof(m_wFields));
		return ;
	}

	// Buffer contains...
	//		Field count (WORD)
	//		Flags (WORD)
	//		Key offset (WORD)
	//		Byte data:
	//			Field data
	//			Dword data
	//			Key
	// Simply start at field 0 and go to end of buffer....
	int iDataSize = m_wUsedSize - m_awFieldOffset[0];

	Buffer.Empty();
	Buffer.Append((const BYTE*)&m_wFields, sizeof(m_wFields));
	Buffer.Append((const BYTE*)&m_wFlags, sizeof(m_wFlags));
	Buffer.Append((const BYTE*)&m_wKeyOffset, sizeof(m_wKeyOffset));
	Buffer.Append((const BYTE*)GetField(0), iDataSize);
}

DWORD CIuRecord::GetExpandCount() const
{
	if (!HasExpandCount())
	{
		return 0;
	}
	int iOffset = m_abExpandCountOffset[m_wFlags >> (16 - recordDwordBitCount)];
	DWORD dwCount = GetDword(iOffset);
	return dwCount;
}

DWORD CIuRecord::GetDword(int iWhich) const
{
	if (IsHiVal() || IsLoVal())
		return 0;
	DWORD dw = GetDwordPtr()[iWhich];
	return dw;
}

DWORD* CIuRecord::GetDwordPtr() const
{
	const BYTE*	pb = reinterpret_cast<const BYTE*>(this) + m_wDwordOffset;
	return reinterpret_cast<DWORD*>(const_cast<BYTE*>(pb));
}

WORD CIuRecord::GetDwordSize(WORD wFlags)
{
	return m_abDwordSize[wFlags >> (16 - recordDwordBitCount)];
}

DWORD CIuRecord::GetExpandNo() const
{
	if (!HasExpandNo())
		return recordExpandNoInvalid;
	int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
	DWORD dwExpandNo = GetDword(iOffset);
	return dwExpandNo;
}

void CIuRecord::GetExpandNo(DWORD& dwExpandNo, DWORD& dwExpandCount) const
{
	if (!HasExpandNo())
	{
		dwExpandNo = recordExpandNoInvalid;
		dwExpandCount = 0;
		return ;
	}
	ASSERT(HasExpandCount());
	int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
	dwExpandNo = GetDword(iOffset);
	dwExpandCount = GetDword(iOffset + 1);
}

const char* CIuRecord::GetField(int iField) const
{
	// Return an empty field for a negative field offset
	// This can happen for a number of reasons. For example, a "see also" record
	// only has two fields where the caller might have been expecting lots of fields.
	// Only the first field of an alternate record is valid!
	if (IsAlternate() && iField != 0)
		return "";
	if (IsHiVal() || IsLoVal())
		return "";
	if (iField < 0 || iField >= m_wFields)
		return "";
	return reinterpret_cast<const char*>(this) + m_awFieldOffset[iField];
}

const char* CIuRecord::GetField(int iField, int& iSize) const
{
	// Return an empty field for a negative field offset
	// This can happen for a number of reasons. For example, a "see also" record
	// only has two fields where the caller might have been expecting lots of fields.
	// Only the first field of an alternate record is valid!
	if ((IsAlternate() && iField != 0) ||
		IsHiVal() || 
		IsLoVal() ||
		iField < 0 || 
		iField >= m_wFields)
	{
		iSize = 0;			
		return "";
	}
	int iOffset = m_awFieldOffset[iField];
	int iOffset1 = m_awFieldOffset[iField+1];
	iSize = iOffset1 - iOffset;
	const char* pcsz = reinterpret_cast<const char*>(this) + iOffset;
	return pcsz;
}

int CIuRecord::GetFieldSize(int iField) const
{
	// Field size does include the trailing null
	// Only the first field of an alternate record is valid!
	if (IsAlternate() && iField != 0)
		return 0;
	if (IsHiVal() || IsLoVal())
		return 0;
	if (iField < 0 || iField >= m_wFields)
		return 0;
	return int(m_awFieldOffset[iField+1] - m_awFieldOffset[iField]);
}

void CIuRecord::GetKey(CIuKey& Key) const
{
	Key.Set(GetKeyPtr(), GetKeySize());
}

const BYTE* CIuRecord::GetKeyPtr() const
{
	// Return the first field if no key specified
	if ((m_wFlags & recordKey) == 0)
		return (const BYTE*)GetField(0);
	// Return the key at the end of the record
	if (m_wKeyOffset < recordMaxKeyOffset)
		return reinterpret_cast<const BYTE*>(this) + m_wKeyOffset;
	// Otherwise, we start at the first field...
	return (const BYTE*)GetField(0);
}

int CIuRecord::GetKeySize() const
{
	// NOTE: Key size includes any trailing null!!!

	// Return the first field if no key specified
	if ((m_wFlags & recordKey) == 0)
		return GetFieldSize(0);
	// Normal key stored at end of record
	if (m_wKeyOffset <= recordMaxKeyOffset)
		return m_wUsedSize - m_wKeyOffset;
	// A key consisting of "n" fields
	WORD wFields = WORD(m_wKeyOffset - recordMaxKeyOffset);
	ASSERT(wFields > 0 && wFields <= m_wFields && !IsHiVal() && !IsLoVal());
	return m_awFieldOffset[wFields] - m_awFieldOffset[0];
}

void CIuRecord::GetLatLong(CIuLatLongCoordinate& Coord) const
{
	DWORD dwLat, dwLong;
	GetLatLong(dwLat, dwLong);
	Coord = CIuLatLongCoordinate(dwLat, dwLong);
}

void CIuRecord::GetLatLong(DWORD& dwLat, DWORD& dwLong) const
{
	if (!HasLatLong())
	{
		dwLat = dwLatLongInvalid;
		dwLong = dwLatLongInvalid;
		return ;
	}
	int iOffset = m_abLatLongOffset[m_wFlags >> (16 - recordDwordBitCount)];
	dwLat = GetDword(iOffset);
	dwLong = GetDword(iOffset + 1);
}

DWORD CIuRecord::GetRecordNo() const
{
	if (!HasRecordNo())
		return recordRecordNoInvalid;
	// If present, record no is always at offset 0
	return GetDword(0);
}

DWORD CIuRecord::GetSourceNo() const
{
	if (!HasSourceNo())
		return recordRecordNoInvalid;
	return GetDword(m_abSourceNoOffset[m_wFlags >> (16 - recordDwordBitCount)]);
}

void CIuRecord::GrowDword(WORD wFlags)
{
	// NOTE: This is a highly inefficient call which we really really
	//			try to avoid. 
	//			You can avoid it by pre-initializing your records so that
	//			any DWORD's which might be needed are already in use
	TRACE("WARNING: Inefficient call to CIuRecord::GrowDword(WORD wFlags)\n"); 

	// NOTE: Flags can be added but not removed!
	wFlags &= 0xF800;
	wFlags |= m_wFlags;

	int iDwordCurrent = GetDwordSize();
	int iDwordNeeded = GetDwordSize(wFlags);
	ASSERT(iDwordNeeded > iDwordCurrent);
	if (iDwordNeeded <= iDwordCurrent)
		return ;

	int iAdditional = iDwordNeeded - iDwordCurrent;
	ASSERT(m_wTotalSize >= m_wUsedSize);
	if ((m_wTotalSize - m_wUsedSize) < iAdditional)
	{
		Dump();
		CString sDebug;
		sDebug.Format(_T("DWORD does not fit.\n%s"), LPCTSTR(DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	// Deal with key field if present and an actual key value
	if ((m_wFlags & recordKey) != 0 && m_wKeyOffset <= recordMaxKeyOffset)
	{
		const BYTE* pbSrc = GetKeyPtr();
		BYTE* pbDst = const_cast<BYTE*>(pbSrc) + iAdditional;

		memmove(pbDst, pbSrc, GetKeySize());
		m_wKeyOffset = WORD(m_wKeyOffset + iAdditional);
	}

	m_wUsedSize = WORD(m_wUsedSize + iAdditional);

	// OK, we now have extra room... but where to the values all go?  The new values
	// we are growing for may go before the existing dwords or even in between them...
	DWORD* pdw = GetDwordPtr();

	DWORD dwRecordNo = recordRecordNoInvalid;
	DWORD dwSourceNo = recordSourceNoInvalid;
	DWORD dwLat = dwLatLongInvalid;
	DWORD dwLong = dwLatLongInvalid;
	DWORD dwExpandNo = recordExpandNoInvalid;
	DWORD dwCount = 0;

	if (HasRecordNo())
		dwRecordNo = pdw[0];
	if (HasSourceNo())
		dwSourceNo = pdw[m_abSourceNoOffset[m_wFlags >> (16 - recordDwordBitCount)]];
	if (HasLatLong())
	{
		int iOffset = m_abLatLongOffset[m_wFlags >> (16 - recordDwordBitCount)];
		dwLat = pdw[iOffset];
		dwLong = pdw[iOffset + 1];
	}
	if (HasExpandNo())
	{
		ASSERT(HasExpandCount());
		int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
		dwExpandNo = pdw[iOffset];
		dwCount = pdw[iOffset + 1];
	}

	// Set new flags
	m_wFlags |= wFlags;

	// Store dwords
	if (HasRecordNo())
		pdw[0] = dwRecordNo;
	if (HasSourceNo())
		pdw[m_abSourceNoOffset[m_wFlags >> (16 - recordDwordBitCount)]] = dwSourceNo;
	if (HasLatLong())
	{
		int iOffset = m_abLatLongOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = dwLat;
		pdw[iOffset + 1] = dwLong;
	}
	if (HasExpandNo())
	{
		int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = dwExpandNo;
		pdw[iOffset + 1] = dwCount;
	}
	else if (HasExpandCount())
	{
		int iOffset = m_abExpandCountOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = dwCount;
	}
}

bool CIuRecord::IsBlank() const
{
	int iFields = GetFields();
	for (int iField = 0; iField < iFields; ++iField)
	{
		const char* pcsz = GetField(iField);
		if (*pcsz)
			return false;
	}
	return true;	
}

CIuRecord* CIuRecord::New(int cb, const CIuRecord* pRecord, WORD wFlags, int cbKey)
{
	ASSERT(cbKey >= 0);

	// This is the primary (actually... only) entry point for creating a record.
	if (cbKey > 0)
		wFlags |= recordKey;

	// Adjust for any new flags
	if (pRecord)
		wFlags |= pRecord->m_wFlags;

	// Get the size required for the flags
	WORD wDwordSize = GetDwordSize(wFlags);

	// Adjust for the size of the source record
	if (pRecord)
	{
		// First, check if dword/key are larger and adjust
		int cbOriginal = pRecord->GetUsedSize();
		WORD wDwordSizeOriginal = GetDwordSize(pRecord->m_wFlags);
		if (wDwordSize > wDwordSizeOriginal)
			cbOriginal += wDwordSize - wDwordSizeOriginal;

		int cbKeyOriginal = 0;
		if ((pRecord->m_wFlags & recordKey) != 0 && pRecord->m_wKeyOffset <= recordMaxKeyOffset)
			cbKeyOriginal = int(pRecord->m_wUsedSize - pRecord->m_wKeyOffset);
		if (cbKeyOriginal > cbKey)
			cbOriginal += cbKeyOriginal - cbKey;
		if (cb < cbOriginal)
			cb = cbOriginal;
	}

	// Add extra space for the key
	cb += cbKey;

	// Check min/max sizes
	if (cb < int(sizeof(CIuRecord) + wDwordSize))
		cb = sizeof(CIuRecord) + wDwordSize;
	if (cb > recordMaxSize)
		cb = recordMaxSize;

	// Do the actual allocations
	BYTE* pb = new BYTE[cb];

	CIuRecord* pNewRecord = reinterpret_cast<CIuRecord*>(pb);
	pNewRecord->Construct(WORD(cb));

	// Copy the source 
	if (pRecord)
		pNewRecord->Set(*pRecord);

	// Return the new record
	return pNewRecord;
}

CIuRecord* CIuRecord::New(const CIuRecord& Record, WORD wFlags, int cbKey)
{
	return New(Record.GetUsedSize(), &Record, wFlags, cbKey);
}

CIuRecord* CIuRecord::New(CIuRecordSpec& Spec)
{
	int cb = GetRequiredSizeSpec(Spec);
	BYTE* pb = new BYTE[cb];
	CIuRecord* pRecord = reinterpret_cast<CIuRecord*>(pb);
	ASSERT(pRecord);
	pRecord->Construct(WORD(cb));
	pRecord->Set(Spec);
	return pRecord;	
}

CIuRecord* CIuRecord::NewBuffer(const BYTE* pb, int cb)
{
	ASSERT(AfxIsValidAddress(pb, cb, false));
	int cbRequired = GetRequiredSizeBuffer(pb, cb);
	CIuRecord* pRecord = New(cbRequired);
	pRecord->SetBuffer(pb, cb);
	return pRecord;
}

void CIuRecord::Set(CIuRecordSpec& Spec)
{
	// This is the low level "set" routine. It is useful for a wide variety of input formats.
	int iFields = Spec.m_iRecordFields < 0 ? Spec.m_iFields: Spec.m_iRecordFields;
	ASSERT(iFields <= recordMaxFields);
	if (iFields <= 0)
	{
		Clear();
		return ;
	}

	ASSERT(iFields > 0);

	// Get offset of first data field element
	BYTE*	pb = reinterpret_cast<BYTE*>(this);

	// Check that it fits
	WORD wOffset = sizeof(*this);
	wOffset = WORD(wOffset + OFFSETS_SIZE(iFields));
	if (wOffset > m_wTotalSize)
	{
		Dump();
		CString sDebug;
		sDebug.Format(_T("Field offsets array does not fit.\n%s"), LPCTSTR(DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	// Store field count and update flags
	// NOTE: Set erases the current key and dwords
	ASSERT(iFields > 0);
	m_wFields = WORD(iFields);
	m_wFlags = 0;

	// Set initial offset so new field/flags can be found
	m_awFieldOffset[0] = wOffset;

	// Process each field
	for (int iField = 0; iField < iFields; ++iField)
	{
		// Get the length of the field

		const BYTE* pbField = Spec.m_apb[iField];
		int cbField = 0;
		if (pbField == 0)
		{
			cbField = 0;
		}
		else
		{
			cbField = Spec.m_acb[iField];
			// NOTE: not necessarily null terminated!
			// ASSERT(pcsz[cb] == '\0');
		}

		// Check that the field fits
		if (wOffset + cbField > m_wTotalSize)
		{
			Dump();
			CString sDebug;
			sDebug.Format(_T("Field %d does not fit.\n%s"), iField, LPCTSTR(DumpAsString()));
			Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
		}

		// Store the offset
		m_awFieldOffset[iField] = wOffset;

		// Copy the data
		if (cbField > 0)
			memcpy(pb + wOffset, pbField, cbField);

		// Add a null terminator
		// Check that the null terminator fits
		if (wOffset + cbField + 1 > m_wTotalSize)
		{
			Dump();
			CString sDebug;
			sDebug.Format(_T("Null terminator for field %d does not fit.\n%s"), iField, LPCTSTR(DumpAsString()));
			Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
		}
		pb[wOffset + cbField] = 0;
		++cbField;

		// Update offset
		wOffset = static_cast<WORD>(wOffset + cbField);
	}

	// The last offset stores the offset of the end of the field data
	m_awFieldOffset[iField] = wOffset;
	// Point key offset to first field
	m_wKeyOffset = recordMaxKeyOffset + 1;
	// And so is the used size
	m_wUsedSize = wOffset;
	// Copy over the flags which have been set
	m_wFlags = Spec.m_wFlags;

	// Now, adjust for the various DWORD values
	//	which are to be appended.
	// NOTE: Flags can be added but not removed!

	int iDword = GetDwordSize(m_wFlags);
	ASSERT(m_wTotalSize >= m_wUsedSize);
	if ((m_wTotalSize - m_wUsedSize) < iDword)
	{
		Dump();
		CString sDebug;
		sDebug.Format(_T("DWORD does not fit.\n%s"), LPCTSTR(DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	m_wUsedSize = WORD(m_wUsedSize + iDword);

	// OK, we now have extra room... but where to the values all go?  The new values
	// we are growing for may go before the existing dwords or even in between them...
	DWORD* pdw = GetDwordPtr();

	// Store dwords
	if (HasRecordNo())
		pdw[0] = Spec.m_dwRecordNo;
	if (HasSourceNo())
		pdw[m_abSourceNoOffset[m_wFlags >> (16 - recordDwordBitCount)]] = Spec.m_dwSourceNo;
	if (HasLatLong())
	{
		int iOffset = m_abLatLongOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = Spec.m_dwLatitude;
		pdw[iOffset + 1] = Spec.m_dwLongitude;
	}
	if (HasExpandNo())
	{
		int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = Spec.m_dwExpandNo;
		pdw[iOffset + 1] = Spec.m_dwExpandCount;
	}
	else if (HasExpandCount())
	{
		int iOffset = m_abExpandCountOffset[m_wFlags >> (16 - recordDwordBitCount)];
		pdw[iOffset] = Spec.m_dwExpandCount;
	}

	// If no key, we are done!
	if ((m_wFlags & recordKey) == 0)
		return ;

	int iKeyFields = Spec.m_iKeyFields;
	if (iKeyFields > 0)
	{
		ASSERT(iKeyFields > 0 && iKeyFields <= int(m_wFields));
		int iActualFields = int(m_wFields);
		iKeyFields = max(1, min(iKeyFields, iActualFields));
		m_wKeyOffset = WORD(recordMaxKeyOffset + iKeyFields);
	}
	else
	{
		const BYTE* pbKey = Spec.m_pbKey;
		int cbKey = Spec.m_cbKey;
		if (pbKey == 0)
		{
			pbKey = Spec.m_Key.GetKeyPtr();
			cbKey = Spec.m_Key.GetKeySize();
		}
		// Make sure new key will fit
		if ((m_wTotalSize - m_wUsedSize) < cbKey)
		{
			Dump();
			CString sDebug;
			sDebug.Format(_T("Key does not fit.\n%s"), LPCTSTR(DumpAsString()));
			Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
		}

		m_wKeyOffset = m_wUsedSize;
		ASSERT(m_wKeyOffset <= recordMaxKeyOffset);
		m_wUsedSize = WORD(m_wUsedSize + cbKey);
		BYTE* pbDst = reinterpret_cast<BYTE*>(this) + m_wKeyOffset;
		memcpy(pbDst, pbKey, cbKey);
		ASSERT(GetKeySize() == cbKey);
	}
}

void CIuRecord::Set(const CIuRecord& Record)
{
	if (this == &Record)
		return ;

	const BYTE* pbSrc = Record.GetData();
	BYTE* pbDst = GetData();
	int cb = Record.GetDataSize();

	ASSERT(m_wTotalSize >= recordOverhead);
	if (cb > int(m_wTotalSize - recordOverhead))
	{
		Dump();
		Record.Dump();
		CString sDebug;
		sDebug.Format(_T("Can not copy record. Source is too large.\n%s\n%s"), 
			LPCTSTR(DumpAsString()), LPCTSTR(Record.DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	memcpy(pbDst, pbSrc, cb);
	m_wUsedSize = WORD(cb + recordOverhead);
}

void CIuRecord::SetAlt(bool fAlt)
{
	if (fAlt)
		m_wFlags |= recordAlternate;
	else
		m_wFlags &= ~recordAlternate;
}

void CIuRecord::SetBoughtLevel(int iBoughtLevel)
{
	ASSERT(boughtMaxLevel <= recordBoughtMask);
	ASSERT(iBoughtLevel >= 0 && iBoughtLevel <= recordBoughtMask);
	WORD wBoughtLevel = static_cast<WORD>(iBoughtLevel);
	wBoughtLevel &= recordBoughtMask;
	m_wFlags &= ~recordBoughtMask;
	m_wFlags |= wBoughtLevel;
}

void CIuRecord::SetBuffer(const BYTE* pb, int cb)
{
	// The buffer contains a bunch of null terminated strings.
	// NOTE: Set erases all the current dword and key valuess
	ASSERT(cb > 0);
	ASSERT(AfxIsValidAddress(pb, cb, false));

	// Handle error conditions
	if (cb < sizeof(WORD))
	{
		TRACE("WARNING: Invalid record binary format.\n");
		Clear(false);
		return ;
	}
	// Get the field count
	const WORD* pw = reinterpret_cast<const WORD*>(pb);

	WORD wFields = pw[0];

	// Handle the special cases
	if (wFields == recordLoVal || cb < 3 * sizeof(WORD))
	{
		Clear(false);
		return ;
	}
	else if (wFields == recordHiVal)
	{
		Clear(true);
		return ;
	}

	WORD wFlags = pw[1];
	WORD wKeyOffset = pw[2];

	// Do a double check on the size
	int iSizeRequired = GetRequiredSizeBuffer(pb, cb);
	if (iSizeRequired > int(m_wTotalSize))
	{
		Dump();
		CString sDebug;
		sDebug.Format(_T("Buffer will not fit. Requires %d bytes.\n%s"), iSizeRequired, LPCTSTR(DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	m_wFields = wFields;
	m_wFlags = wFlags;
	m_wKeyOffset = wKeyOffset;

	// Get data pointer
	BYTE* pbRecord = reinterpret_cast<BYTE*>(this);

	// Get offset to buffer data
	WORD wOffset = static_cast<WORD>(sizeof(CIuRecord) + OFFSETS_SIZE(wFields));

	// Copy the data...
	memcpy(pbRecord + wOffset, pb + 3 * sizeof(WORD), cb - 3 * sizeof(WORD));

	// Update the field offsets
	// We also do some consistency checking on the data
	for (int iField = 0; iField < wFields; ++iField)
	{
		// Store offset of this field
		m_awFieldOffset[iField] = wOffset;

		// Move to end of field
		while (pbRecord[wOffset] != 0)
		{
			++wOffset;
			if (wOffset >= m_wTotalSize)
			{
				Dump();
				CString sDebug;
				sDebug.Format(_T("Field has invalid offset (%08X).\n%s"), 
					DWORD(wOffset), LPCTSTR(DumpAsString()));
				Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
			}
		}

		// Skip over null character
		++wOffset;
		if (wOffset >= m_wTotalSize)
		{
			Dump();
			CString sDebug;
			sDebug.Format(_T("Field null terminator has invalid offset (%08X).\n%s"),
				DWORD(wOffset), LPCTSTR(DumpAsString()));
			Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
		}
	}

	// The last offset stores the offset of the end of the field data
	m_awFieldOffset[iField] = wOffset;
	m_wUsedSize = WORD(iSizeRequired);

	if ((m_wFlags & recordKey) != 0)
	{
		if (m_wKeyOffset <= recordMaxKeyOffset)
		{
			if (m_wKeyOffset >= m_wTotalSize || m_wKeyOffset >= m_wUsedSize || pb[cb - 1] != '\0')
			{
				Dump();
				CString sDebug;
				sDebug.Format(_T("Key offset is invalid (%08X).\n%s"), 
					DWORD(m_wKeyOffset), LPCTSTR(DumpAsString()));
				Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
			}
		}
		else
		{
			int iFields = int(m_wKeyOffset - recordMaxKeyOffset);
			if (iFields <= 0 || iFields > m_wFields)
			{
				Dump();
				CString sDebug;
				sDebug.Format(_T("Key field count (%d) larger than actual field count (%d.\n%s"), 
					iFields, int(m_wFields), LPCTSTR(DumpAsString()));
				Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
			}
		}
	}
	else
	{
		ASSERT(m_wKeyOffset == recordMaxKeyOffset + 1);
		if (m_wKeyOffset != recordMaxKeyOffset + 1)
		{
			Dump();
			CString sDebug;
			sDebug.Format(_T("Key offset is unexpected (%08X).\n%s"), 
				DWORD(m_wKeyOffset), LPCTSTR(DumpAsString()));
			Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
		}
	}
}

void CIuRecord::SetBus()
{
	m_wFlags &= ~recordResidence;
}

void CIuRecord::SetDword(int iWhich, DWORD dw)
{
	if (IsHiVal() || IsLoVal())
		return ;
	GetDwordPtr()[iWhich] = dw;
}

void CIuRecord::SetExpandCount(DWORD dwCount)
{
	if (!HasExpandCount())
		GrowDword(recordExpandCount);

	int iOffset = m_abExpandCountOffset[m_wFlags >> (16 - recordDwordBitCount)];
	SetDword(iOffset, dwCount);
}

void CIuRecord::SetExpandNo(DWORD dwExpandNo, DWORD dwExpandCount) 
{
	if (!HasExpandNo())
		GrowDword(recordExpandNo|recordExpandCount);

	int iOffset = m_abExpandNoOffset[m_wFlags >> (16 - recordDwordBitCount)];
	SetDword(iOffset, dwExpandNo);
	SetDword(iOffset + 1, dwExpandCount);
}

void CIuRecord::SetKey()
{
	// Remove any existing key
	if ((m_wFlags & recordKey) == 0)
		return ;

	if (m_wKeyOffset <= recordMaxKeyOffset && m_wKeyOffset > 0)
	{
		// Actual key, shrink record
		m_wUsedSize = m_wKeyOffset;
	}

	m_wKeyOffset = recordMaxKeyOffset + 1;
	m_wFlags &= ~recordKey;
}

void CIuRecord::SetKey(int iFields)
{
	// If no new key, remove the current key
	SetKey();
	if (iFields <= 0)
		return ;

	ASSERT(iFields > 0 && iFields <= int(m_wFields));
	int iiActualFields = int(m_wFields);
	iFields = max(1, min(iFields, iiActualFields));
	m_wKeyOffset = WORD(recordMaxKeyOffset + iFields);
	m_wFlags |= recordKey;
}

void CIuRecord::SetKey(const char* pbKey, int cbKey)
{
	// If no new key, remove the current key
	SetKey();
	if (pbKey == 0 || cbKey == 0)
		return ;

	// Make sure new key will fit
	if ((m_wTotalSize - m_wUsedSize) < cbKey)
	{
		Dump();
		CString sDebug;
		sDebug.Format(_T("Key does not fit.\n%s"), LPCTSTR(DumpAsString()));
		Error(IU_E_INVALID_RECORD, LPCTSTR(sDebug));
	}

	m_wKeyOffset = m_wUsedSize;
	ASSERT(m_wKeyOffset <= recordMaxKeyOffset);
	m_wUsedSize = WORD(m_wUsedSize + cbKey);
	m_wFlags |= recordKey;
	BYTE* pbDst = reinterpret_cast<BYTE*>(this) + m_wKeyOffset;
	memcpy(pbDst, pbKey, cbKey);
	ASSERT(GetKeySize() == cbKey);
}

void CIuRecord::SetLatLong(DWORD dwLat, DWORD dwLong)
{
	if (!HasLatLong())
		GrowDword(recordLatLong);
	ASSERT(HasLatLong());
	int iOffset = m_abLatLongOffset[m_wFlags >> (16 - recordDwordBitCount)];
	SetDword(iOffset, dwLat);
	SetDword(iOffset + 1, dwLong);
}

void CIuRecord::SetNoMail(bool fNoMail)
{
	if (fNoMail)
		m_wFlags |= recordNoMail;
	else
		m_wFlags &= ~recordNoMail;
}

void CIuRecord::SetNoPhone(bool fNoPhone)
{
	if (fNoPhone)
		m_wFlags |= recordNoPhone;
	else
		m_wFlags &= ~recordNoPhone;
}

void CIuRecord::SetRecordNo(DWORD dwRecordNo)
{
	if (!HasRecordNo())
		GrowDword(recordRecordNo);
	// Record no is always at offset 0
	ASSERT(HasRecordNo());
	SetDword(0, dwRecordNo);
}

void CIuRecord::SetRes()
{
	m_wFlags |= recordResidence;
}

void CIuRecord::SetSourceNo(DWORD dwSrcNo)
{
	if (!HasSourceNo())
		GrowDword(recordSourceNo);
	ASSERT(HasSourceNo());
	SetDword(m_abSourceNoOffset[m_wFlags >> (16 - recordDwordBitCount)], dwSrcNo);
}

void CIuRecord::SetTagged(bool fTagged)
{
	if (fTagged)
		m_wFlags |= recordTagged;
	else
		m_wFlags &= ~recordTagged;
}

void CIuRecord::View(CWnd* pParent) const
{
	CIuRecordDlg Dlg(this, 0, pParent);
	Dlg.DoModal();
}

bool CIuRecord::WillFitBuffer(const BYTE* pb, int cb) const
{
	return m_wTotalSize >= GetRequiredSizeBuffer(pb, cb);
}

bool CIuRecord::WillFitFlags(WORD wFlags) const
{
	wFlags &= 0xF800;
	wFlags |= m_wFlags;
	int iDwordCurrent = GetDwordSize();
	int iDwordNeeded = GetDwordSize(wFlags);
	if (iDwordNeeded <= iDwordCurrent)
		return true;

	int iAdditional = iDwordNeeded - iDwordCurrent;
	ASSERT(m_wTotalSize >= m_wUsedSize);
	if ((m_wTotalSize - m_wUsedSize) < iAdditional)
		return false;

	return true;
}

bool CIuRecord::WillFitKey(int cbKey) const
{
	// If no new key, remove the current key
	if (cbKey <= 0)
		return true;

	// Make sure new key will fit
	int iAdditional = 0;
	if (m_wKeyOffset > recordMaxKeyOffset)
		iAdditional = cbKey;
	else
	{
		iAdditional = cbKey - int(m_wUsedSize - m_wKeyOffset);
		iAdditional = max(0, iAdditional);
	}

	ASSERT(m_wTotalSize >= m_wUsedSize);
	if ((m_wTotalSize - m_wUsedSize) < iAdditional)
		return false;

	return true;
}

bool CIuRecord::WillFitRecord(const CIuRecord& Record) const
{
	return m_wTotalSize >= Record.GetUsedSize();
}

bool CIuRecord::WillFitSpec(CIuRecordSpec& Spec) const
{
	int iRequiredSize = GetRequiredSizeSpec(Spec);
	return m_wTotalSize >= iRequiredSize;
}

#ifdef _DEBUG
#include "Interop\Test.h"

static void RecordTablesArrayOutput(LPCTSTR pcszName, BYTE* pb, int cb)
{
	ASSERT(AfxIsValidString(pcszName));
	TRACE("BYTE m_ab%s[] = \n", pcszName);
	TRACE("\t{");
	for (int i = 0; i < cb; ++i)
	{
		if (i != 0)
			TRACE(", ");
		TRACE("%2d", pb[i]);
	}
	TRACE(" };\n");
	TRACE("\n");
}

IU_TEST_BEGIN(RecordTables, pv)
{
	// To run this test, execute "test RecordTables" in the console.
	// NOTE: You need to select your own name if you copy this code.
	UNUSED_ALWAYS(pv);

	// This test writes the static lookup tables to the debug window

	BYTE ab[1 << recordDwordBitCount];

	for (int i = 0; i < sizeof(ab); ++i)
	{
		WORD wFlags = WORD(i << (16 - recordDwordBitCount));

		int iSize = 0;
		if ((wFlags & recordRecordNo) != 0)
			iSize += sizeof(DWORD);
		if ((wFlags & recordSourceNo) != 0)
			iSize += sizeof(DWORD);
		if ((wFlags & recordLatLong) != 0)
			iSize += 2 * sizeof(DWORD);
		if ((wFlags & recordExpandNo) != 0)
			iSize += sizeof(DWORD);
		if ((wFlags & recordExpandCount) != 0)
			iSize += sizeof(DWORD);

		ab[i] = BYTE(iSize);
	}
	RecordTablesArrayOutput(_T("DwordSize"), ab, sizeof(ab));

	// NOTE: Record no is always the first DWORD.
	// So no table is built for it.
	// However, each of the others has an offset table

	for (i = 0; i < sizeof(ab); ++i)
	{
		WORD wFlags = WORD(i << (16 - recordDwordBitCount));

		int iOffset = 0;
		if ((wFlags & recordRecordNo) != 0)
			iOffset += 1;
		if ((wFlags & recordSourceNo) != 0)
			iOffset += 1;
		if ((wFlags & recordLatLong) != 0)
			iOffset += 2;
		if ((wFlags & recordExpandNo) != 0)
			iOffset += 1;

		ab[i] = BYTE(iOffset);
	}
	RecordTablesArrayOutput(_T("CountOffset"), ab, sizeof(ab));

	for (i = 0; i < sizeof(ab); ++i)
	{
		WORD wFlags = WORD(i << (16 - recordDwordBitCount));

		int iOffset = 0;
		if ((wFlags & recordRecordNo) != 0)
			iOffset += 1;
		if ((wFlags & recordSourceNo) != 0)
			iOffset += 1;
		if ((wFlags & recordLatLong) != 0)
			iOffset += 2;

		ab[i] = BYTE(iOffset);
	}
	RecordTablesArrayOutput(_T("ExpandNoOffset"), ab, sizeof(ab));

	for (i = 0; i < sizeof(ab); ++i)
	{
		WORD wFlags = WORD(i << (16 - recordDwordBitCount));

		int iOffset = 0;
		if ((wFlags & recordRecordNo) != 0)
			iOffset += 1;
		if ((wFlags & recordSourceNo) != 0)
			iOffset += 1;

		ab[i] = BYTE(iOffset);
	}
	RecordTablesArrayOutput(_T("LatLongOffset"), ab, sizeof(ab));

	for (i = 0; i < sizeof(ab); ++i)
	{
		WORD wFlags = WORD(i << (16 - recordDwordBitCount));

		int iOffset = 0;
		if ((wFlags & recordRecordNo) != 0)
			iOffset += 1;

		ab[i] = BYTE(iOffset);
	}
	RecordTablesArrayOutput(_T("SourceNoOffset"), ab, sizeof(ab));

	return 0;
}
IU_TEST_END()
#endif

