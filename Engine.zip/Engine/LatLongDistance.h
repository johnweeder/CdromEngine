#ifndef _ENGINE_LATLONGDISTANCE_H_
#define _ENGINE_LATLONGDISTANCE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuLatLongDistance }}

class IU_CLASS_EXPORT CIuLatLongDistance
{
//{{Declare
public:
// Convert to string as miles/feet/etc (per iFormat)
enum CIuLatLongDistanceUnits
{
	LatLongUnitsMiles,
	LatLongUnitsFeet,
};
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuLatLongDistance();
	CIuLatLongDistance(const CIuLatLongDistance&);
	CIuLatLongDistance(DWORD, CIuLatLongDistanceUnits units = LatLongUnitsMiles);
	CIuLatLongDistance(LPCTSTR pcsz, CIuLatLongDistanceUnits units = LatLongUnitsMiles);
	// Do NOT make this virtual... we don't want to fatten up this class.
	// Do not add any other virtual functions either
	~CIuLatLongDistance();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	// Convert to DWORD (return m_nDistance)
	DWORD AsDWORD() const;
	CString AsString(CIuLatLongDistanceUnits units = LatLongUnitsMiles, bool fUnits = false) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromDWORD(DWORD, CIuLatLongDistanceUnits units = LatLongUnitsMiles);
	void FromString(LPCTSTR pcsz, CIuLatLongDistanceUnits units = LatLongUnitsMiles);
	bool IsValid() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	operator DWORD() const;
	operator CString() const;

	CIuLatLongDistance& operator=(const CIuLatLongDistance&);
	CIuLatLongDistance& operator=(DWORD);
	CIuLatLongDistance& operator=(LPCTSTR);

	CIuLatLongDistance operator-(const CIuLatLongDistance& LatLongDistance) const;
	CIuLatLongDistance operator+(const CIuLatLongDistance& LatLongDistance) const;
	const CIuLatLongDistance& operator+=(const CIuLatLongDistance LatLongDistance);
	const CIuLatLongDistance& operator-=(const CIuLatLongDistance LatLongDistance);

	bool operator==(const CIuLatLongDistance& LatLongDistance) const;
	bool operator<(const CIuLatLongDistance& LatLongDistance) const;
	// implement in terms of above
	bool operator!=(const CIuLatLongDistance& LatLongDistance) const;
	bool operator>(const CIuLatLongDistance& LatLongDistance) const;
	bool operator<=(const CIuLatLongDistance& LatLongDistance) const;
	bool operator>=(const CIuLatLongDistance& LatLongDistance) const;
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Internally, the distance is always in feet
	DWORD	m_dwDistance;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuLatLongDistance::IsValid() const
{
	return m_dwDistance != DWORD(-1);
}

#endif // _ENGINE_LATLONGDISTANCE_H_
