#ifndef _ENGINE_GEOINSTANCE_H_
#define _ENGINE_GEOINSTANCE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
#ifndef 	_ENGINE_LATLONGUNIT_H_
#	include "Engine\LatLongUnit.h"
#endif	// _ENGINE_LATLONGUNIT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoInstance)
class CIuGeoMap;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Latitude/Longitude match levels
const char latlongNone		= '\0';
const char latlongUnknown	= '?';
const char latlongStreet	= '0';
const char latlongZip4		= '4';
const char latlongZip2		= '2';
const char latlongZip		= 'X';

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoInstance, CIuObject }}
#define CIuGeoInstance_super CIuObject

class CIuGeoInstance : public CIuGeoInstance_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoInstance)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoInstance();
	virtual ~CIuGeoInstance();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	void Get(CIuBuffer& output) const;
	CString GetCity() const;
	int GetCountyCode() const;
	void GetCountyCodeAsString(LPTSTR psz, int cb) const;
	CString GetCountyCodeAsString() const;
	CString GetCountyName() const;
	CIuLatLongUnit GetLatitude() const;
	void GetLatitudeAsString(LPTSTR psz, int cb) const;
	CString GetLatitudeAsString() const;
	CIuLatLongUnit GetLongitude() const;
	void GetLongitudeAsString(LPTSTR psz, int cb) const;
	CString GetLongitudeAsString() const;
	int GetMatchLevel() const;
	int GetMedianHomeValue() const;
	void GetMedianHomeValueAsString(LPTSTR psz, int cb) const;
	CString GetMedianHomeValueAsString() const;
	int GetMedianIncome() const;
	void GetMedianIncomeAsString(LPTSTR psz, int cb) const;
	CString GetMedianIncomeAsString() const;
	int GetMsaCode() const;
	void GetMsaCodeAsString(LPTSTR psz, int cb) const;
	CString GetMsaCodeAsString() const;
	CString GetMsaName() const;
	CString GetStateAbbr() const;
	CString GetStateCity() const;
	int GetStateCode() const;
	void GetStateCodeAsString(LPTSTR psz, int cb) const;
	CString GetStateCodeAsString() const;
	CString GetStateName() const;
	CString GetZip() const;
	CString GetZipAddon() const;
	CString GetZipDpbc() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void MakeRecordDef(CIuRecordDef& RecordDef);
	void Set(const CIuRecord& Record, const CIuGeoMap& map);
	void SetCity(LPCTSTR);
	void SetCountyCode(int);
	void SetCountyCodeAsString(LPCTSTR);
	void SetCountyName(LPCTSTR);
	void SetLatitude(CIuLatLongUnit);
	void SetLatitudeAsString(LPCTSTR);
	void SetLongitude(CIuLatLongUnit);
	void SetLongitudeAsString(LPCTSTR);
	void SetMatchLevel(int);
	void SetMedianHomeValue(int);
	void SetMedianIncome(int);
	void SetMsaCode(int);
	void SetMsaCodeAsString(LPCTSTR);
	void SetMsaName(LPCTSTR);
	void SetStateAbbr(LPCTSTR);
	void SetStateCode(int);
	void SetStateName(LPCTSTR);
	void SetZip(LPCTSTR);
	void SetZip4(LPCTSTR pcsz);
	void SetZipAddon(LPCTSTR);
	void SetZipDpbc(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	CIuRecordPtr m_pRecord;
private:
	CString m_sZip;
	CString m_sCity;
	CString m_sStateAbbr;
	int m_iStateCode;
	CString m_sStateName;
	int m_iMsaCode;
	CString m_sMsaName;
	int m_iCountyCode;
	CString m_sCountyName;
	CIuLatLongUnit m_Latitude;
	CIuLatLongUnit m_Longitude;
	int m_iMatchLevel; // 0, 2, 4, X
	int m_iMedianHomeValue;
	int m_iMedianIncome;
	// Variable is simply used as a temp storage
	// so other classes don't have to re-calc state/city
	mutable CString m_sStateCity;
	CString m_sZipAddon;
	CString m_sZipDpbc;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuGeoInstance::GetCity() const
{
	return m_sCity;
}

inline int CIuGeoInstance::GetCountyCode() const
{
	return m_iCountyCode;
}

inline CString CIuGeoInstance::GetCountyName() const
{
	return m_sCountyName;
}

inline CIuLatLongUnit CIuGeoInstance::GetLatitude() const
{
	return m_Latitude;
}

inline CIuLatLongUnit CIuGeoInstance::GetLongitude() const
{
	return m_Longitude;
}

inline int CIuGeoInstance::GetMatchLevel() const
{
	return m_iMatchLevel;
}

inline int CIuGeoInstance::GetMedianHomeValue() const
{
	return m_iMedianHomeValue;
}

inline int CIuGeoInstance::GetMedianIncome() const
{
	return m_iMedianIncome;
}

inline int CIuGeoInstance::GetMsaCode() const
{
	return m_iMsaCode;
}

inline CString CIuGeoInstance::GetMsaName() const
{
	return m_sMsaName;
}

inline CString CIuGeoInstance::GetStateAbbr() const
{
	return m_sStateAbbr;
}

inline int CIuGeoInstance::GetStateCode() const
{
	return m_iStateCode;
}

inline CString CIuGeoInstance::GetStateName() const
{
	return m_sStateName;
}

inline CString CIuGeoInstance::GetZip() const
{
	return m_sZip;
}

inline CString CIuGeoInstance::GetZipAddon() const
{
	return m_sZipAddon;
}

inline CString CIuGeoInstance::GetZipDpbc() const
{
	return m_sZipDpbc;
}

#endif // _ENGINE_GEOINSTANCE_H_
