#ifndef _ENGINE_REPORTDEFSPEC_H_
#define _ENGINE_REPORTDEFSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReportDefSpec, CIuObjectNamed }}
#define CIuReportDefSpec_super CIuObjectNamed

class CIuReportDefSpec : public CIuReportDefSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuReportDefSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReportDefSpec();
	virtual ~CIuReportDefSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CIuReportFieldDefSpec& GetFieldDef(int iReportFieldDef) const;
	int GetFieldDefCount() const;
	static void GetNames(CStringArray& as);
	int GetReportDefNo() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void CreateFieldDef(LPCTSTR pcszFieldDef);
	bool FromIndex(CIuCdromSpec* pCdrom, int iIndex);
	bool FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszName);
	bool FromNo(CIuCdromSpec* pCdrom, int iReportDefNo);
	void RemoveAllFieldDefs();
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetReportDefNo(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuReportFieldDefSpecArray m_apFieldDefs;
	CIuCdromSpec* m_pCdrom;
	int m_iReportDefNo;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuReportDefSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline int CIuReportDefSpec::GetReportDefNo() const
{
	return m_iReportDefNo;
}

inline bool CIuReportDefSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_REPORTDEFSPEC_H_


