#ifndef _ENGINE_METERWARNINGDLG_H_ 
#define _ENGINE_METERWARNINGDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "Resource.h"
#ifndef 	_UI_BITMAP_H_
#	include "Ui\Bitmap.h"
#endif	// _UI_BITMAP_H_
#ifndef 	_UI_DRAWTEXT_H_
#	include "Ui\DrawText.h"
#endif	// _UI_DRAWTEXT_H_
//}}Uses

//{{Predefines
class CIuMeter;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeterWarningDlg, CDialog }}
#define CIuMeterWarningDlg_super CDialog

class CIuMeterWarningDlg : public CIuMeterWarningDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
protected:
	CIuMeterWarningDlg(CWnd* pParent = NULL);   // standard constructor
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuMeter& GetMeter() const;
	bool HasMeter() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	static void DoDialog(CIuMeter& Meter, CWnd* pParent = 0);
	void SetMeter(CIuMeter* pMeter);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMeter* m_pMeter;
	bool m_fNoWarningBitmap;
	CIuBitmap m_WarningBitmp;
	CRect m_rectWarningBitmap;
	CString m_sWarning;
	CRect m_rectWarning;
	CString m_sPhone;
	CRect m_rectPhone;
	CIuDrawText m_Text;
//}}Data

public:
	//{{AFX_DATA(CIuMeterWarningDlg)
	enum { IDD = IDD_ENGINE_METER_WARNING };
	CButton	m_btnOK;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuMeterWarningDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CIuMeterWarningDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuMeter& CIuMeterWarningDlg::GetMeter() const
{
	ASSERT(HasMeter());
	return *m_pMeter;
}

inline bool CIuMeterWarningDlg::HasMeter() const
{
	return m_pMeter != 0;
}

#endif // _ENGINE_METERWARNINGDLG_H_
