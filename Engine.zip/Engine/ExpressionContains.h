#ifndef _ENGINE_EXPRESSIONCONTAINS_H_
#define _ENGINE_EXPRESSIONCONTAINS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
#ifndef 	_ENGINE_COMPARECONTAINS_H_
#	include "Engine\CompareContains.h"
#endif	// _ENGINE_COMPARECONTAINS_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionContains, CIuExpressionElement }} 
#define CIuExpressionContains_super CIuExpressionElement

class CIuExpressionContains : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionContains();
	CIuExpressionContains(const CIuExpressionContains& rExpressionElement);
	virtual ~CIuExpressionContains();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
	virtual void Resolve(CIuResolveSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionContains& operator=(const CIuExpressionContains& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Pattern to match
	mutable CIuCompareContains m_Comparator;
	// Optimization for const patterns
	bool m_fPatternConst;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONCONTAINS_H_
