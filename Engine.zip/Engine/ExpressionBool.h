#ifndef _ENGINE_EXPRESSIONBOOL_H_
#define _ENGINE_EXPRESSIONBOOL_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONELEMENT_H_
#	include "Engine\ExpressionElement.h"
#endif	// _ENGINE_EXPRESSIONELEMENT_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionBool, CIuExpressionElement }} 
#define CIuExpressionBool_super CIuExpressionElement

class CIuExpressionBool : public CIuExpressionElement
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionBool(CIuExpressionType Type = exprBool);
	CIuExpressionBool(const CIuExpressionBool& rExpressionElement);
	virtual ~CIuExpressionBool();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual int GetMaxLength() const;
	virtual LPCTSTR GetTypeName() const;
	virtual bool IsKindOf(CIuExpressionType Type) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	virtual bool EvaluateBool(const CIuRecord*) const;
	virtual int EvaluateInt(const CIuRecord*) const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionBool& operator=(const CIuExpressionBool& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONBOOL_H_
