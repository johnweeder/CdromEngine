#include "StdAfx.h"
//{{Include
#include "ExpressionBool.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionBool::CIuExpressionBool(CIuExpressionType Type) : CIuExpressionElement(Type)
{
	SetFormat(exprFormatBool);
}

CIuExpressionBool::CIuExpressionBool(const CIuExpressionBool& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionBool::~CIuExpressionBool()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionBool::Clone() const
{
	CIuExpressionBool* pElement = new CIuExpressionBool(*this);
	ASSERT(pElement);
	return pElement;
} 

bool CIuExpressionBool::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() >= 2);
	ASSERT(GetType() == exprAnd || GetType() == exprOr);
	for (int iChild = 0; iChild < GetChildCount(); ++iChild)
	{
		bool fResult = EvaluateChildBool(iChild, pRecord);
		if (GetType() == exprAnd && !fResult)
			return false;
		else if (GetType() == exprOr && fResult)
			return true;
	}

	if (GetType() == exprAnd)
		return true;

	ASSERT(GetType() == exprOr);
	return false;
}

int CIuExpressionBool::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionBool::GetMaxLength() const
{
	return BooiMaxLength();
}

LPCTSTR CIuExpressionBool::GetTypeName() const
{
	switch (GetType())
	{
		case exprBool:
			return "#Boolean Operator#";
		case exprAnd:
			return "AND";
		case exprOr:
			return "OR";
	}
	return CIuExpressionBool_super::GetTypeName();
}

bool CIuExpressionBool::IsKindOf(CIuExpressionType Type) const
{
	return Type == exprBool || CIuExpressionBool_super::IsKindOf(Type);
}

CIuExpressionBool& CIuExpressionBool::operator=(const CIuExpressionBool& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionBool_super::operator=(rExpressionElement);
	return *this;
}
