#ifndef _ENGINE_ADDRESSCODEC_H_
#define _ENGINE_ADDRESSCODEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_FIELDMAP_H_
#	include "Engine\FieldMap.h"
#endif	// _ENGINE_FIELDMAP_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddressCodec)
class CIuAddressSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Flags
const int addressRR						= 0x00000001;
const int addressHC						= 0x00000002;
const int addressGD						= 0x00000004;
const int addressPOBOX					= 0x00000008;
const int addressNumericStreet		= 0x00000010; // 1, 2, 3
const int addressOrdinalStreet		= 0x00000020; // 1ST, 2ND, 3RD
const int addressEmpty					= 0x00000040;
const int addressNumericPriNo			= 0x00000100;
const int addressNumericSecNo			= 0x00000200;

enum CIuDirectionals
{
	dirFirst = 0,
	dirN = dirFirst,
	dirS,
	dirE,
	dirW,
	dirNE,
	dirNW,
	dirSE,
	dirSW,
	dirMax,
	dirNone = dirMax,
};


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddressCodec, CIuObject }}
#define CIuAddressCodec_super CIuObject
class IU_CLASS_EXPORT CIuAddressCodec : public CIuAddressCodec_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddressCodec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddressCodec();
	virtual ~CIuAddressCodec();
	CIuAddressCodec(const CIuAddressCodec&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static LPCTSTR GetDir(int iDir);
	int GetFlags() const;
	LPCTSTR GetPostDir() const;
	int GetPostDirNo() const;
	LPCTSTR GetPreDir() const;
	int GetPreDirNo() const;
	CString GetPriNo() const;
	int GetPriNoNo() const;
	CString GetSecNo() const;
	int GetSecNoNo() const;
	CString GetStreet() const;
	CString GetStreetName() const;
	int GetStreetNo() const;
	CString GetSuffix() const;
	CIuFieldMap& GetMap() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
	static int FindDir(LPCTSTR pcszDir);
	bool Process(const CIuRecord& Record);
	bool Process(LPCTSTR pcszPriNo, LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir, LPCTSTR pcszSecNo, LPCTSTR pcszHighRise, LPCTSTR pcszNoSolicitation);
	void Resolve(CIuResolveSpec& Spec);
	void SetSpec(CIuAddressSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuAddressCodec& operator=(const CIuAddressCodec&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetMap_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
public:
	static const TCHAR m_szRR[];
	static const TCHAR m_szHC[];
	static const TCHAR m_szPOBOX[];
	static const TCHAR m_szGD[];
private:
	// Non-Persistent data
		// Mapped fields
		CIuRecordPtr m_pRecord;
		// Parsed fields
		int m_iPreDirNo;
		int m_iPostDirNo;
		CString m_sPriNo;
		int m_iPriNoNo;
		CString m_sStreetName;
		int m_iStreetNo;
		int m_iSecNoNo;
		CString m_sSuffix;
		CString m_sSecNo;
		int m_iFlags;
		// The full street
		mutable CString m_sStreet;
	// Persistent data
		// Field mapping
		CIuFieldMapPtr m_pMap;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAddressCodec::GetFlags() const
{
	return m_iFlags;
}

inline CIuFieldMap& CIuAddressCodec::GetMap() const
{
	return m_pMap.Ref();
}

inline int CIuAddressCodec::GetPostDirNo() const
{
	return m_iPostDirNo;
}

inline int CIuAddressCodec::GetPreDirNo() const
{
	return m_iPreDirNo;
}

inline CString CIuAddressCodec::GetPriNo() const
{
	return m_sPriNo;
}

inline int CIuAddressCodec::GetPriNoNo() const
{
	return m_iPriNoNo;
}

inline CString CIuAddressCodec::GetSecNo() const
{
	return m_sSecNo;
}

inline int CIuAddressCodec::GetSecNoNo() const
{
	return m_iSecNoNo;
}

inline CString CIuAddressCodec::GetStreetName() const
{
	return m_sStreetName;
}

inline int CIuAddressCodec::GetStreetNo() const
{
	return m_iStreetNo;
}

inline CString CIuAddressCodec::GetSuffix() const
{
	return m_sSuffix;
}

#endif // _ENGINE_ADDRESSCODEC_H_
