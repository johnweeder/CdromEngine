#include "StdAfx.h" 
//{{Include 
#include "Export.h"
#include "resource.h"
#include "Queries.h"
#include "Engine.h"
#include "ExportDef.h"
#include "ExportDefs.h"
#include "ExportInstance.h"
#include "Exporter.h"
#include "Data\Output.h"
#include "Interop\Settings.h"
#include "ExportDefaultDlg.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

#pragma __TODO("CIuExport: Load default settings on initialize")

//{{Implement
IU_IMPLEMENT_OBJECT_PTR(CIuExport)
IMPLEMENT_DYNCREATE(CIuExport, CIuExport_super)
const	CIuVersionNumber versionExportMax(2000,1,5,304);
const	CIuVersionNumber versionExportMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORT, CIuExport, CIuExport_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExport, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExport, IDS_ENGINE_PROP_EXPRESSION, GetExpression, SetExpression, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExport, IDS_ENGINE_PROP_EXPORTDEF, GetExportDef, SetExportDef, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExport, IDS_ENGINE_PROP_HANDLE, GetHandle, SetIntNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuExport, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)

	IU_ATTRIBUTE_ACTION(CIuExport, IDS_ENGINE_ACTION_EXPORTDLG, ActionExportDlg, 0)
	IU_ATTRIBUTE_ACTION(CIuExport, IDS_ENGINE_ACTION_EXPORT, ActionExport, 0)

	IU_ATTRIBUTE_PAGE(CIuExport, IDS_ENGINE_PPG_EXPORT, 50, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuExport, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_EXPORT, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExport, IDS_ENGINE_PROP_HANDLE, IDS_ENGINE_PPG_EXPORT, INT_MIN, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuExport, IDS_ENGINE_PROP_EXPRESSION, IDS_ENGINE_PPG_EXPORT, 5, 0)
	IU_ATTRIBUTE_EDITOR_HISTORY(CIuExport, IDS_ENGINE_PROP_EXPORTDEF, IDS_ENGINE_PPG_EXPORT, 0)
	IU_ATTRIBUTE_EDITOR_ALLOWED_VALUES(CIuExport, IDS_ENGINE_PROP_EXPORTDEF, GetExportDefAllowed, 0)
	IU_ATTRIBUTE_EDITOR_OPTIONS(CIuExport, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_EXPORT, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExport, IDS_ENGINE_PROP_MAXRECORDS, GetMaxRecords, SetMaxRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExport, IDS_ENGINE_PROP_MAXRECORDS, IDS_ENGINE_PPG_EXPORT, INT_MIN, INT_MAX, 0)

	IU_ATTRIBUTE_EDITOR_ACTION(CIuExport, IDS_ENGINE_ACTION_EXPORT, IDS_ENGINE_PPG_EXPORT, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuExport, IDS_ENGINE_ACTION_EXPORTDLG, IDS_ENGINE_PPG_EXPORT, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuExport

CIuExport::CIuExport()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);

	m_pEngine = 0;
	CommonConstruct();
}

CIuExport::~CIuExport()
{
	// Remove and destroy query if needed.
	SetQuery(0);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}
												 
/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuExport::ActionExport(const CIuPropertyCollection&, CIuOutput&)
{
	Export();
	return CString("Success");
}

CString CIuExport::ActionExportDlg(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	CString sName = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	if (ExportDlg(sName, Output.GetParentWnd()))
		return CString("Success");
	return CString("Failure");
}

void CIuExport::Clear()
{
	CIuExport_super::Clear();
	CIuExport::CommonConstruct();
}

void CIuExport::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("Export");
	m_sFilename.Empty();
	m_sExpression.Empty();
	m_sExportDef.Empty();
	m_sOptions = "";
	m_fAutoRemove = false;
	m_iMaxRecords = 0;
	if (m_pInstance.IsNull())
		m_pInstance.Create();
	SetVersion(versionExportMax);
	//}}Initialize
}
 
int CIuExport::Export() 
{
	return GetInstance().Export(*this); 
}

bool CIuExport::ExportDlg(LPCTSTR pcszName, CWnd* pParent)
{
	// Return true if dialog was invoked, else return false if no dialog located.
	if (pcszName == 0 || *pcszName == '\0' || _tcsicmp(pcszName, "default") == 0)
		return CIuExportDefaultDlg::ExportDlg(*this, pParent);

	return false;
}

CIuEngine& CIuExport::GetEngine() const
{
	return *m_pEngine;
}

void CIuExport::GetExportDefAllowed(CStringArray& as) const
{
	if (!HasEngine())
		return ;
	GetEngine().GetExportDefs().GetCollectionNames(as);
}

CString CIuExport::GetFilename() const
{
	return m_sFilename;
}

int CIuExport::GetHandle() const
{
	return reinterpret_cast<int>(this);
}

CIuOutput& CIuExport::GetOutput() const
{
	ASSERT(HasEngine());
	if (m_pOutput.IsNull())
	{
		m_pOutput = GetEngine().CreateOutput();
		m_pOutput->SetHandle(GetHandle());
	}
	return m_pOutput.Ref();
}

void CIuExport::GetSettingName(CString& sName) const
{
	CString sSetting = _T("Export\\");
	if (sName.IsEmpty())
		sName = GetName();
	if (sName.IsEmpty())
		sName = _T("Default");
	sSetting += sName;
	sName = sSetting;
}

CIuVersionNumber CIuExport::GetVersionMax() const
{
	return versionExportMax;
}

CIuVersionNumber CIuExport::GetVersionMaxStatic()
{
	return versionExportMax;
}

CIuVersionNumber CIuExport::GetVersionMin() const
{
	return versionExportMin;
}

CIuVersionNumber CIuExport::GetVersionMinStatic()
{
	return versionExportMin;
}

void CIuExport::Load()
{
	OnLoad();
}

void CIuExport::OnLoad(LPCTSTR pcszName, CIuOutput* pOutput)
{
	if (!HasEngine())
	{
		CIuExport_super::OnLoad(pcszName, pOutput);
		return ;
	}

	CString sLoad;
	if (pcszName)
		sLoad = pcszName;

	GetSettingName(sLoad);
	if (!IuSettingsExists(sLoad))
	{
		if (pOutput)
			pOutput->OutputF("Setting not found '%s'", LPCTSTR(sLoad));
		return ;
	}

	// Preserve the current name and id across the load operation
	CString sName = GetName();
	CIuID id = GetID();

	CString sObject = IuSettingsGet(sLoad);
	SerializeFromTextMemoryEx(sObject, this);

	SetName(sName);
	SetID(id);

	if (pOutput)
		pOutput->OutputF("Loaded from '%s'", LPCTSTR(sLoad));
}

void CIuExport::OnSave(LPCTSTR pcszName, CIuOutput* pOutput)
{
	if (!HasEngine())
	{
		CIuExport_super::OnSave(pcszName, pOutput);
		return ;
	}

	CString sName;
	if (pcszName)
		sName = pcszName;

	GetSettingName(sName);
	CString sObject;
	SerializeToTextMemoryEx(sObject, *this);
	IuSettingsSet(sName, sObject);

	if (pOutput)
		pOutput->OutputF("Saved to '%s'", LPCTSTR(sName));
}

void CIuExport::Save()
{
	OnSave();
}

void CIuExport::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
	Load();
}

void CIuExport::SetExportDef(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExportDef = pcsz;
}

void CIuExport::SetExpression(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExpression = pcsz;
}

void CIuExport::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuExport::SetMaxRecords(int iMaxRecords)
{
	m_iMaxRecords = iMaxRecords;
}

void CIuExport::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuExport::SetQuery(CIuQuery* pQuery, bool fAutoRemove)
{
	if (m_pQuery.NotNull())
	{
		if (m_fAutoRemove)
		{
			CString sID = m_pQuery->GetID().AsString();
			GetEngine().GetQueries().Remove(COleVariant(sID));
		}
		m_pQuery.Release();
	}
	// Keep a pointer to the object.
	// Be very careful that this does not create a circular reference.
	if (pQuery)
	{
		m_pQuery = pQuery;
		m_fAutoRemove = fAutoRemove;
	}
	else
	{
		m_pQuery.Release();
		m_fAutoRemove = false;
	}
}

