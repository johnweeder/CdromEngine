#include "StdAfx.h"
//{{Include
#include "FieldMapSpec.h"
#include "FieldMapSpecDft.h"
#include "FieldMap.h"
#include "resource.h"
#include "FieldDefSpec.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuFieldMapSpec, CIuFieldMapSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldMapSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_MAPSPEC, CIuFieldMapSpec, CIuFieldMapSpec_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuFieldMapSpec, IDS_ENGINE_PPG_MAPSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuFieldMapSpec, IDS_ENGINE_PROP_FIELDS, GetFields, SetFields, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuFieldMapSpec, IDS_ENGINE_PROP_FIELDS, IDS_ENGINE_PPG_MAPSPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuFieldMapSpec, IDS_ENGINE_PROP_KEYS, GetKeys, SetKeys, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuFieldMapSpec, IDS_ENGINE_PROP_KEYS, IDS_ENGINE_PPG_MAPSPEC, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldMapSpec::CIuFieldMapSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuFieldMapSpec::~CIuFieldMapSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

int CIuFieldMapSpec::AddField(LPCTSTR pcsz, int iBefore) 
{
	ASSERT(AfxIsValidString(pcsz));

	// Add the Field to the array
	// Set a blank to start, and then set the actual Field
	int iCount = GetFieldCount();
	int iIndex;
	if (iBefore < 0 || iBefore >= iCount)
		iIndex = m_asFields.Add("");
	else
	{
		m_asFields.InsertAt(iBefore, "");
		iIndex = iBefore;
	}
	SetField(iIndex, pcsz);
	return iIndex;
}

int CIuFieldMapSpec::AddKey(LPCTSTR pcsz, int iBefore) 
{
	ASSERT(AfxIsValidString(pcsz));

	// Add the key to the array
	// Set a blank to start, and then set the actual Key
	int iCount = GetKeyCount();
	int iIndex;
	if (iBefore < 0 || iBefore >= iCount)
		iIndex = m_asKeys.Add("");
	else
	{
		m_asKeys.InsertAt(iBefore, "");
		iIndex = iBefore;
	}
	SetKey(iIndex, pcsz);
	return iIndex;
}

void CIuFieldMapSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("Name");
	m_asFields.RemoveAll();
	m_asKeys.RemoveAll();
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuFieldMapSpec::Copy(const CIuObject& object)
{
	CIuFieldMapSpec_super::Copy(object);

	const CIuFieldMapSpec* pFieldMapSpec = dynamic_cast<const CIuFieldMapSpec*>(&object);
	if (pFieldMapSpec == 0 || pFieldMapSpec == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuFieldMapSpec)));
	
	m_asFields.Copy(pFieldMapSpec->m_asFields);
	m_asKeys.Copy(pFieldMapSpec->m_asKeys);
}

bool CIuFieldMapSpec::FromIndex(int iIndex)
{
	if (iIndex < 0 || iIndex >= GetCount())
		return false;

	Clear();

	const CIuFieldMapSpecDft* pFieldMapSpec = CIuFieldMapSpecDft::Get(iIndex);

	SetName(pFieldMapSpec->m_pcszFieldMap);
	SetID(CIuID::Create());

	RemoveAllFields();
	for (int i = 0 ; pFieldMapSpec->m_apcszFields[i]; ++i)
		AddField(pFieldMapSpec->m_apcszFields[i]);

	++i;

	RemoveAllKeys();
	for (; pFieldMapSpec->m_apcszFields[i]; ++i)
		AddKey(pFieldMapSpec->m_apcszFields[i]);

	return true;
}

bool CIuFieldMapSpec::FromName(LPCTSTR pcszName)
{
	return FromIndex(CIuFieldMapSpecDft::Find(pcszName));
}

bool CIuFieldMapSpec::FromNo(int iFieldMap)
{
	return FromIndex(CIuFieldMapSpecDft::Find(iFieldMap));
}

int CIuFieldMapSpec::GetCount()
{
	return CIuFieldMapSpecDft::GetCount();
}

void CIuFieldMapSpec::GetFields(CStringArray& as) const
{
	as.Copy(m_asFields);
}

void CIuFieldMapSpec::GetKeys(CStringArray& as) const
{
	as.Copy(m_asKeys);
}

void CIuFieldMapSpec::GetNames(CStringArray& as)
{
	as.RemoveAll();
	for (int i = 0; i < GetCount(); ++i)
		as.Add(CIuFieldMapSpecDft::Get(i)->m_pcszFieldMap);
}

CIuFieldMapSpec& CIuFieldMapSpec::operator=(const CIuFieldMapSpec& rFieldMapSpec)
{
	Copy(rFieldMapSpec);
	return *this;
}
CIuFieldMapSpec::CIuFieldMapSpec(const CIuFieldMapSpec& rFieldMapSpec)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rFieldMapSpec;
}

void CIuFieldMapSpec::RemoveAllFields()
{
	m_asFields.RemoveAll();
}

void CIuFieldMapSpec::RemoveAllKeys()
{
	m_asKeys.RemoveAll();
}

void CIuFieldMapSpec::RemoveField(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetFieldCount());
	m_asFields.RemoveAt(iWhich);
}

void CIuFieldMapSpec::RemoveKey(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	m_asKeys.RemoveAt(iWhich);
}

void CIuFieldMapSpec::SetField(int iWhich, LPCTSTR pcszExpr)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcszExpr));

	// The Field can be of two basic forms:
	// The first, is your basic field specifier:
	//		name(parms):expr
	// The second is a reference to a default field specifier.
	//		=name(parms)
	// The second format takes a default field specification and
	// modifies it using the parms.
	// parms and expr are optional.

	// First, check for an equal sign
	CString sExpr = pcszExpr;
	if (!sExpr.IsEmpty() && sExpr[0] == '=')
	{
		// OK, this is a reference
		sExpr = sExpr.Mid(1);

		// Resolve it against the field spec defaults....
		CIuFieldDefSpec spec;
		if (spec.FromExpression(sExpr))
			sExpr = spec.GetSpecification();
	}

	m_asFields.SetAtGrow(iWhich, sExpr);
}

void CIuFieldMapSpec::SetFields(const CStringArray& as)
{
	m_asFields.RemoveAll();
	for (int i = 0; i < as.GetSize(); ++i)
		AddField(as[i]);
}

void CIuFieldMapSpec::SetKey(int iWhich, LPCTSTR pcszExpr)
{
	ASSERT(iWhich >= 0);
	ASSERT(AfxIsValidString(pcszExpr));

	// The key can be of two basic forms:
	// The first, is your basic field specifier:
	//		name(parms):expr
	// The second is a reference to a default field specifier.
	//		=name(parms)
	// The second format takes a default field specification and
	// modifies it using the parms.
	// parms and expr are optional.

	// First, check for an equal sign
	CString sExpr = pcszExpr;
	if (!sExpr.IsEmpty() && sExpr[0] == '=')
	{
		// OK, this is a reference
		sExpr = sExpr.Mid(1);

		// Resolve it against the field spec defaults....
		CIuFieldDefSpec spec;
		if (spec.FromExpression(sExpr))
			sExpr = spec.GetSpecification();
	}

	m_asKeys.SetAtGrow(iWhich, sExpr);
}

void CIuFieldMapSpec::SetKeys(const CStringArray& as)
{
	m_asKeys.RemoveAll();
	for (int i = 0; i < as.GetSize(); ++i)
		AddKey(as[i]);
}

