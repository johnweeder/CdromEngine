#ifndef _ENGINE_REPORT_H_
#define _ENGINE_REPORT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReport)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReport, CIuObject }}
#define CIuReport_super CIuObject

class IU_CLASS_EXPORT CIuReport : public CIuReport_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuReport)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReport();           
	virtual ~CIuReport();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_REPORT_H_