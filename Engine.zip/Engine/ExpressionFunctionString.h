#ifndef _ENGINE_EXPRESSIONFUNCTIONSTRING_H_
#define _ENGINE_EXPRESSIONFUNCTIONSTRING_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPRESSIONFUNCTION_H_
#	include "Engine\ExpressionFunction.h"
#endif	// _ENGINE_EXPRESSIONFUNCTION_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExpressionFunctionString, CIuExpressionFunction }}
#define CIuExpressionFunctionString_super CIuExpressionFunction

class CIuExpressionFunctionString : public CIuExpressionFunction
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExpressionFunctionString(CIuExpressionType Type = exprFunction);
	CIuExpressionFunctionString(const CIuExpressionFunctionString& rExpressionElement);
	virtual ~CIuExpressionFunctionString();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static const CIuExpressionFunctionDef* GetFunctionDefs();
	virtual bool IsConst() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual CIuExpressionElement* Clone() const;
	static CIuExpressionFunction* Create();
	virtual CIuExpressionElement* Optimize();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExpressionFunctionString& operator=(const CIuExpressionFunctionString& rExpressionElement);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	LPCTSTR NewlineDelimited(const CIuRecord* pRecord) const;
	int NewlineDelimitedMaxLength() const;
	LPCTSTR TabDelimited(const CIuRecord* pRecord) const;
	int TabDelimitedMaxLength() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_EXPRESSIONFUNCTIONSTRING_H_
