#include "StdAfx.h"
//{{Include
#include "AltRaw.h"
#include "Alt.h"
#include "AltSpec.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "Interop\Conversions.h"
#include "Common\BigBuffer.h"
#include "Error\Error.h"
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltRaw, CIuAltRaw_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltRaw)
const	CIuVersionNumber versionAltRawMax(2000,1,5,304);
const	CIuVersionNumber versionAltRawMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTRAW, CIuAltRaw, CIuAltRaw_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltRaw, IDS_ENGINE_PPG_ALTRAW, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAltRaw, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAltRaw, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ALTRAW, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAltRaw, IDS_ENGINE_PROP_HASHSIZE, GetHashSize, SetHashSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAltRaw, IDS_ENGINE_PROP_HASHSIZE, IDS_ENGINE_PPG_ALTRAW, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAltRaw, IDS_ENGINE_PROP_COUNT, GetCount, SetCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAltRaw, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_ALTRAW, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_ACTION(CIuAltRaw, IDS_ENGINE_ACTION_READ, ActionRead, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAltRaw, IDS_ENGINE_ACTION_READ, IDS_ENGINE_PPG_ALTRAW, editorAutoUpdate)
	IU_ATTRIBUTE_ACTION(CIuAltRaw, IDS_ENGINE_ACTION_WRITE, ActionWrite, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAltRaw, IDS_ENGINE_ACTION_WRITE, IDS_ENGINE_PPG_ALTRAW, editorAutoUpdate)

	IU_ATTRIBUTE_PAGE(CIuAltRaw, IDS_ENGINE_PPG_ALTRAW2, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuAltRaw, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuAltRaw, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_ALTRAW, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl sort_elements_by_key(const void *elem1, const void *elem2)
{
	const CIuAltRawElement** ppElement1 = (const CIuAltRawElement**)elem1;
	const CIuAltRawElement** ppElement2 = (const CIuAltRawElement**)elem2;
	return (*ppElement1)->GetKey().CompareNoCase((*ppElement2)->GetKey());
}

CIuAltRaw::CIuAltRaw() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltRaw::~CIuAltRaw()
{
	Empty();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuAltRaw::ActionRead(const CIuPropertyCollection&, CIuOutput&)
{
	Read();
	return CString();
}

CString CIuAltRaw::ActionWrite(const CIuPropertyCollection&, CIuOutput&)
{
	Write();
	return CString();
}

void CIuAltRaw::AllocateMap(int iHashSize)
{
	// First free any existing map
	Empty();

	// Then, allocate a new map
	ASSERT(iHashSize > 0);
	m_ElementMap.SetSize(iHashSize);
	int iSize = m_ElementMap.GetSize();
	for (int i = 0; i < iSize; ++i)
		m_ElementMap.SetAt(i, 0);
}

void CIuAltRaw::Append(CIuAltInstance& instance)
{
	if (m_ElementMap.GetSize() == 0)
		AllocateMap(GetHashSize());

	CString sKey = instance.GetKey();

	UINT uiHash = HashBucket(sKey);

	CIuAltRawElement* pElement = m_ElementMap.GetAt(uiHash);
	if (pElement)
	{
		int iResult = sKey.CompareNoCase(pElement->GetKey());
		if (iResult < 0)
		{
			// This element belongs first in the bucket... make it so
			pElement = new CIuAltRawElement(instance);
			ASSERT(pElement);
			++m_iCount;
			pElement->SetNext(m_ElementMap.GetAt(uiHash));

			m_ElementMap.SetAt(uiHash, pElement);
			return ;
		}

		// Inserted into this bucket in sorted order
		for (;;)
		{
			// Matches this element in the bucket
			if (iResult == 0)
			{
				pElement->Append(instance);
				return ;
			}
			// There is no next element
			if (pElement->GetNext() == 0)
			{
				// Add new element to end of bucket
				pElement->SetNext(new CIuAltRawElement(instance));
				++m_iCount;
				return ;
			}

			// Compare to next element in chain
			iResult = sKey.CompareNoCase(pElement->GetNext()->GetKey());

			// Should be insert before next element?
			if (iResult < 0)
			{
				CIuAltRawElement* pNew = new CIuAltRawElement(instance);
				pNew->SetNext(pElement->GetNext());
				pElement->SetNext(pNew);
				++m_iCount;
				return ;
			}
			pElement = pElement->GetNext();
		}
	}
	else 
	{
		// First element in this bucket
		pElement = new CIuAltRawElement(instance);
		ASSERT(pElement);
		m_ElementMap.SetAt(uiHash, pElement);
		++m_iCount;
	}
}

void CIuAltRaw::Clear()
{
	CIuAltRaw_super::Clear();
	CIuAltRaw::CommonConstruct();
	Empty();
}

void CIuAltRaw::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("AltRaw");
	m_sFilename = "AltRaw";
	m_iCount = 0;
	m_iHashSize = 64 * 1024;
	SetVersion(versionAltRawMax);
	//}}Initialize
}

void CIuAltRaw::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
	// Empty this object as a way of cleaning up un-needed memory
	Empty();
}

void CIuAltRaw::Empty()
{
	int iSize = m_ElementMap.GetSize();
	for (int i = 0; i < iSize; ++i)
		delete m_ElementMap[i];
	m_ElementMap.RemoveAll();
	m_ElementArray.RemoveAll();
	m_iCount = 0;
}

CIuAltRawElement* CIuAltRaw::Get(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < m_ElementArray.GetSize());
	ASSERT(m_ElementArray.GetAt(iWhich));
	return m_ElementArray.GetAt(iWhich);
}

CIuFilename CIuAltRaw::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

CString CIuAltRaw::GetGridElement(int iRow, int iCol) const
{
	// Make sure row is valid
	ASSERT(GetCount() == m_ElementArray.GetSize());
	if (iRow < 0 || iRow >= m_ElementArray.GetSize())
		return CString();

	// Get the element in this row
	CIuAltRawElement* pElement = m_ElementArray.GetAt(iRow);
	if (pElement == 0)
		return CString();

	// Display the key in column 0
	if (iCol == 0)
	{
		CString sCount;
		return pElement->GetKey();
	}

	ASSERT(iCol == 1);

	CStringArray as;
	pElement->GetValues(as);
	CString s;
	StringArrayAsString(s, as);
	return s;
}

bool CIuAltRaw::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			SortByKey();
			static TCHAR szName[] = _T("CIuAltRawGrid");
			rq.SetName(szName);
			rq.Load();
			rq.SetSize(CSize(2, GetCount()));
			rq.SetColumn(0, "Key", 100, gridWidthOptional);
			rq.SetColumn(1, "Values", 100, gridWidthOptional);
			return true;
		}
		case gridRqTerminate:
			rq.Save();
			return true;
		case gridRqDblClickRow:
		case gridRqDblClickCell:
		{
			if (rq.GetRow() >= 0 && rq.GetRow() < GetCount())
			{
				// Make sure row is valid
				ASSERT(GetCount() == m_ElementArray.GetSize());
				if (rq.GetRow() < 0 || rq.GetRow() >= m_ElementArray.GetSize())
					return false;

				// Get the element in this row
				CIuAltRawElement* pElement = m_ElementArray.GetAt(rq.GetRow());
				if (pElement == 0)
					return false;

				pElement->Edit();
				return true;
			}
			return false;
		}
		case gridRqGet:
		{
			CString s = CIuAltRaw::GetGridElement(rq.GetRow(), rq.GetColumn());
			rq.SetValue(s);
			return true;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

CIuVersionNumber CIuAltRaw::GetVersionMax() const
{
	return versionAltRawMax;
}

CIuVersionNumber CIuAltRaw::GetVersionMaxStatic()
{
	return versionAltRawMax;
}

CIuVersionNumber CIuAltRaw::GetVersionMin() const
{
	return versionAltRawMin;
}

CIuVersionNumber CIuAltRaw::GetVersionMinStatic()
{
	return versionAltRawMin;
}

int CIuAltRaw::HashBucket(LPCTSTR key) const
{
	UINT uiHash = 0;
	while (*key)
		uiHash = (uiHash<<5) + uiHash + *key++;

	int iHashBucket = int(uiHash % m_ElementMap.GetSize());
	return iHashBucket;
}

void CIuAltRaw::Read()
{
	CIuFilename filename = GetFullFilename();
	if (!filename.Exists())
	{
		Clear();
		Error(IU_E_ALT_FILE_NOT_FOUND, filename);
		return ;
	}

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Open(GetFullFilename(), 16 * 1024, CIuFile::openReadOnly);

	pFile->GetData(this);

	CIuFileVirtualPtr pVFile = pFile->Use();

	CIuBigBuffer buffer;
	buffer.SetSize((int)pVFile->GetLength());

	pVFile->Seek(0);
	pVFile->Read(buffer.GetPtr(), buffer.GetSize());

	SerializeFromMemory(buffer, this);
}

void CIuAltRaw::Serialize(CArchive& ar)
{
	// We use MFC serialization for performance reasons...
	// NOTE: We are only saving the AltRaw information via MFC serialization
	const DWORD dwCurrentVersion = 0x00000001;
	if (ar.IsStoring())
	{
		ar << dwCurrentVersion;

		DWORD dwHashSize = m_ElementMap.GetSize();
		ar << dwHashSize;

		DWORD dwCount = m_iCount;
		ar << dwCount;

		for (int iHash = 0; iHash < m_ElementMap.GetSize(); ++iHash)
		{
			CIuAltRawElement* pElement = m_ElementMap.GetAt(iHash);
			while (pElement)
			{
				ASSERT(dwCount != 0);
				--dwCount;
				ASSERT(HashBucket(pElement->GetKey()) == iHash);
				pElement->Serialize(ar);
				pElement = pElement->GetNext();

			}
		}
		ASSERT(dwCount == 0);
	}
	else
	{
		DWORD dwVersion;
		ar >> dwVersion;
		ASSERT(dwVersion == dwCurrentVersion);

		Empty();

		DWORD dwHashSize;
		ar >> dwHashSize;
		ASSERT(dwHashSize > 0);
		AllocateMap(int(dwHashSize));

		DWORD dwCount;
		ar >> dwCount;

		CIuAltRawElement* pPrevElement = 0;
		UINT uiPrevHash = 0;

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			CIuAltRawElement* pElement = new CIuAltRawElement;
			ASSERT(pElement);
			pElement->Serialize(ar);

			UINT uiHash = HashBucket(pElement->GetKey());

			if (m_ElementMap.GetAt(uiHash) == 0)
			{
				++m_iCount;
				m_ElementMap.SetAt(uiHash, pElement);
				pPrevElement = pElement;
				uiPrevHash = uiHash;
			}
			else if (pPrevElement != 0 && uiPrevHash == uiHash)
			{
				++m_iCount;
				pPrevElement->SetNext(pElement);
				ASSERT(pPrevElement->GetKey().CompareNoCase(pElement->GetKey()) <= 0);
				pPrevElement = pElement;
			}
			else
			{
				// This should not happen.... elements should insert into correct order
				ASSERT(false);
			}
		}
		ASSERT(dwCount == DWORD(m_iCount));
	}
	CIuAltRaw_super::Serialize(ar);
}

void CIuAltRaw::SetCount(int iCount)
{
	m_iCount = iCount;
}

void CIuAltRaw::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAltRaw::SetHashSize(int iHashSize)
{
	m_iHashSize = iHashSize;
}

void CIuAltRaw::SetSpec(int iAltNo)
{
	CIuAltSpec Spec;
	Spec.FromNo(0, iAltNo);

	SetName(Spec.GetName());
	SetID(Spec.GetID());
	SetFilename(Spec.GetFilename());
}

void CIuAltRaw::Sort()
{
	m_ElementArray.SetSize(GetCount());
	int iArray = 0;
	int iHashSize = m_ElementMap.GetSize();
	for (int iHash = 0; iHash < iHashSize; ++iHash)
	{
		CIuAltRawElement* pElement = m_ElementMap.GetAt(iHash);
		while (pElement)
		{
			ASSERT(HashBucket(pElement->GetKey()) == iHash);
			m_ElementArray.SetAt(iArray, pElement);
			pElement = pElement->GetNext();
			++iArray;
			ASSERT(iArray <= GetCount());
		}
	}
	ASSERT(iArray <= GetCount());
}

void CIuAltRaw::SortByKey()
{
	Sort();
	if (m_ElementArray.GetSize() > 0)
		qsort(m_ElementArray.GetData(), m_ElementArray.GetSize(), sizeof(CIuAltRawElement*), sort_elements_by_key);
}

void CIuAltRaw::Write() const
{
	CIuBigBuffer buffer;
	SerializeToMemory(buffer, *this, 1024 * 1024);

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Create(GetFullFilename(), 16 * 1024, CIuFile::openCreate);

	CIuFileVirtualPtr pVFile = pFile->Use();
	pFile->SetData(*this);

	pVFile->Seek(0);
	pVFile->Write(buffer.GetPtr(), buffer.GetSize());
}


