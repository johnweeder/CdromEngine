#include "StdAfx.h"
//{{Include
#include "MeterHack.h"
#include "Meter.h"
#include "Ids.h"
#include "Error\Error.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

const long ERROR_READING_METER = -2;
const long ERROR_INV_METER = -3;

static HKEY OldMeterFind(CString& sQueryKey)
{
	// sQueryKey is the product meter GUID
	// Returns an open registry key, caller
	// is responsible for closing the key
	HKEY hKey;
	// Open key              
	CString sKey = _T("CLSID") + CString('\\') + sQueryKey;
	if (RegOpenKey(HKEY_CLASSES_ROOT, sKey, &hKey) != ERROR_SUCCESS)
		hKey = 0;
	return hKey;
}

static LONG OldMeterGetCount(HKEY hKey)
{
	LONG lCount = 0;

	if (hKey)
	{
		DWORD dwCharsRead = 32;	
		LPTSTR lpBuffer = new TCHAR[dwCharsRead] ;
		*lpBuffer = 0 ;                              
		DWORD dwType ;
		LONG bResult =  RegQueryValueEx(hKey, NULL, NULL, &dwType, (LPBYTE)lpBuffer, &dwCharsRead);
	    
		if (bResult != ERROR_SUCCESS)
		{
			delete [] lpBuffer ;
			return ERROR_READING_METER ;      
		}
	
		LPTSTR lptstrBar = NULL; 
		lCount = _tcstol(lpBuffer, &lptstrBar, 10);  // strtol
		delete [] lpBuffer ;
		lCount = ~lCount ;
	}
	
	if (lCount < 0)
		return ERROR_INV_METER;

	return lCount;
}

static void OldMeterSetCount(HKEY hKey, long lCount)
{
	if (hKey)
	{
		CString sOut ;
		sOut.Format("%ld|%ld", ~lCount, ~lCount) ;
		RegSetValueEx(hKey, NULL, 0, REG_SZ, (const BYTE *)((LPCTSTR) sOut), sOut.GetLength()+1);
	}
}

static void OldMeter88mdUpdate(CIuMeter& Meter)
{
	HKEY hKey = 0;

	// Check for previous meters
	CString sMeter00R1 =  _T("{CDB05AE1-33B0-11d3-8065-00104B2CE3F9}") ; // 2000 1st
	hKey = OldMeterFind(sMeter00R1);

	if (hKey == 0)
	{
		CString sMeter99R2 =  _T("{0C08EF72-E1F3-11d2-9367-00104B885529}") ; // 99 2nd
		hKey = OldMeterFind(sMeter99R2);
	}

	if (hKey == 0)
	{
		CString sMeter98R1 =  _T("{8408E0B1-E6A7-11d1-9EC4-00104B2C2F5D}") ; // 99 1st		
		hKey = OldMeterFind(sMeter98R1);
	}

	if (hKey == 0)
		return;

	LONG nOldCount = OldMeterGetCount(hKey);
	if (nOldCount >= 0)
	{
		Meter.SetCount(nOldCount);

		OldMeterSetCount(hKey, 0);
	}

	RegCloseKey(hKey);
}

static void RegistrationHack(CIuMeter& Meter, CIuGuid guid)
{
	const DWORD dwIdentifier		= 0x53FD38A0;
	const DWORD dwCurrentVersion	= 1;

	// Attribute id's. NOTE: Default value is always assumed to be zero!
	const DWORD dwRegistered		= 0x000000001;
	const DWORD dwRemainingRuns	= 0x000000002;

	IU_TRY_ERROR
	{
		IU_TRY_ERROR
		{
			CIuRegistry registryCheck(CIuRegistry::KeySecurityMachine);
			if (!registryCheck.ValueExists(guid.AsString(guidCLSID)))
				return ;

			CDWordArray dwArray;
			CIuRegistry registryKey(CIuRegistry::KeySecurityMachine);
			if (!registryKey.GetValue(guid.AsString(guidCLSID), dwArray))
				Error(IU_E_REGISTRATION_IO);
			
			int iSize = dwArray.GetSize();
			if (iSize < 3 || (iSize % 2) != 1)
				Error(IU_E_REGISTRATION_IO);

			if (dwArray[0] != dwIdentifier)
				Error(IU_E_REGISTRATION_IO);

			DWORD dwVersion = dwArray[1];
			if (dwVersion != dwCurrentVersion)
				Error(IU_E_REGISTRATION_IO);

			DWORD dwActualCRC = crc32(reinterpret_cast<const BYTE*>(dwArray.GetData()), (dwArray.GetSize() - 1) * sizeof(DWORD));
			if (dwArray[iSize - 1] != dwActualCRC)
				Error(IU_E_REGISTRATION_IO);

			for (int i = 2; i < iSize - 1; i += 2)
			{
				DWORD dwID = dwArray[i];
				DWORD dwValue = dwArray[i+1];

				switch (dwID)
				{
					case dwRegistered:
						Meter.SetRegistered(bool(dwValue));
						break;
					case dwRemainingRuns:
						Meter.SetRemainingRuns(bool(dwValue));
						break;
				}
			}

			registryCheck.DeleteValue(guid.AsString(guidCLSID));
		}
		IU_CATCH_ERROR(e)
		{
			e->Delete();
		}
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
	}
}

static void RegistrationHack(CIuMeter& Meter)
{
	// Move registration data from separate key to meter
	if (Meter.GetID() == idMeter_Pf_2000)
	{
		GUID guid = { 0x2d10a72f, 0xea23, 0x48e7, { 0xbb, 0x22, 0x40, 0xd8, 0x8e, 0x78, 0x45, 0xaa } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Bml_2000)
	{
		GUID guid = { 0x531825f1, 0xeb3d, 0x4d55, { 0x9d, 0x26, 0x80, 0xd9, 0xdb, 0x9a, 0xce, 0x8 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Pu_2000)
	{
		GUID guid = { 0xbf3a0823, 0x934c, 0x40e3, { 0x8f, 0xb3, 0xe5, 0xbf, 0x6d, 0xfb, 0xbc, 0xdd } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Slu_2000)
	{
		GUID guid = { 0x9a7a14a0, 0x2db1, 0x4e8a, { 0x9e, 0x11, 0x7c, 0x49, 0x2, 0xb4, 0xe5, 0xe6 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Sample)
	{
		GUID guid = { 0x70fb2968, 0x38fb, 0x4865, { 0xb0, 0xfe, 0x70, 0x75, 0x77, 0x2a, 0xe2, 0x1a } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Ac_V1)
	{
		GUID guid = { 0xa26e3ec4, 0x9418, 0x4e42, { 0xbb, 0x8d, 0xd2, 0x92, 0xa, 0xc7, 0x4, 0xa2 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Pbm_V1)
	{
		GUID guid = { 0x3e3e46f, 0x7586, 0x4320, { 0x8f, 0xb5, 0x5e, 0x5d, 0xf1, 0x11, 0x82, 0x23 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Ci_V1)
	{
		GUID guid = { 0xd1b5497, 0xf8c9, 0x4eb0, { 0x96, 0x5c, 0x8e, 0x47, 0x2, 0x11, 0x14, 0xb8 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Ypu_2001)
	{
		GUID guid = { 0xac7f053e, 0x99c5, 0x4ec9, { 0x90, 0x13, 0x7a, 0x47, 0x23, 0xe0, 0x48, 0xfd } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_Rp_2001)
	{
		GUID guid = { 0x8e808255, 0x268a, 0x4dbb, { 0xa2, 0x76, 0x59, 0xa9, 0xa8, 0x76, 0x9a, 0xb5 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
	else if (Meter.GetID() == idMeter_88md_2001)
	{
		GUID guid = { 0xd893771c, 0x2184, 0x4509, { 0x9e, 0xb9, 0x18, 0xab, 0x57, 0xf6, 0xa5, 0xd0 } };
		RegistrationHack(Meter, CIuGuid(guid));
	}
}

/////////////////////////////////////////////////////////////////////////////
// This function is called each time a meter is initialized.
//	
// This is called to allow any special hacks to allow the meter
// to change based on the rev or on any special access which was granted.
// Feel free to corrupt the nice neat code with your own ugly hacks
//	
// The meter is passed as a parameter.
// You can check the meter name to determine if this is a meter that you
// are interested in. 
// You can then manipulate the meter directly.
// For example Meter.SetCount(Meter.GetCount() + X);
//	
// This function also exists so that the attributes of old (legacy) meters can
// be propogated to the new 32-bit metering code.
//	
IU_API_EXPORT void MeterHack(CIuMeter& Meter, bool fNew)
{
	CString sName = Meter.GetName();
	if (Meter.GetID() == idMeter_88md_2001 && fNew)
	{
		// If a new 88MD meter, try to propogate from old 16-bit meter
		OldMeter88mdUpdate(Meter);
	}
	// Rev 0 customers of 2000 RBOC do not have a speed bump
	// This can be deleted when the 2000 RBOC subscriptions are obsolete
	if (
		Meter.GetID() == idMeter_RbocGreatLakes_2000 ||
		Meter.GetID() == idMeter_RbocNeAtlantic1_2000 ||
		Meter.GetID() == idMeter_RbocNeAtlantic2_2000 ||
		Meter.GetID() == idMeter_RbocPacific_2000 ||
		Meter.GetID() == idMeter_RbocSouthWest_2000 ||
		Meter.GetID() == idMeter_RbocMidWest_2000 ||
		Meter.GetID() == idMeter_RbocTest_2000 ||
		Meter.GetID() == idMeter_RbocSeAtlantic1_2000 ||
		Meter.GetID() == idMeter_RbocSeAtlantic2_2000)
	{
		if (Meter.GetRev() == 0)
		{
			Meter.SetMaxOutput(-1);
		}
	}

	// Hack to fix bad meters...
	if (Meter.GetName().CompareNoCase(_T("Bml2000")) == 0 ||
		Meter.GetName().CompareNoCase(_T("Pf2000")) == 0 ||
		Meter.GetName().CompareNoCase(_T("PfUsa2000")) == 0 ||
		Meter.GetName().CompareNoCase(_T("Slu2000")) == 0)
	{
		Meter.SetMaxOutput(-1);
	}

	// Move registration data to meter
	RegistrationHack(Meter);

	// If changed, write changes
	Meter.Flush();
}
