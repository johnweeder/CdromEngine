#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "MeterUpdate.h"
#include "Meter.h"
#include "MeterUpdateDlg.h"
#include "resource.h"
#include "Data\Output.h"
#include "Common\Miscellaneous.h"
#include "Common\RoutingFrame.h"
#include "..\Version.h"
//}}Include

// Include this file just so we are sure it compiles
#include "MeterUpdate.inl"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuMeterUpdate, CIuMeterUpdate_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuMeterUpdate)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_METERUPDATE, CIuMeterUpdate, CIuMeterUpdate_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuMeterUpdate, IDS_ENGINE_PROP_COUNT, GetCount, SetIntNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_QUERYCODE, GetQueryCode, SetStringNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_RESPONSECODE, GetResponseCode, SetResponseCode, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_KEY, GetKey, SetStringNotSupported, 0)

	IU_ATTRIBUTE_ACTION(CIuMeterUpdate, IDS_ENGINE_ACTION_UPDATE, ActionUpdate, 0)
	IU_ATTRIBUTE_ACTION(CIuMeterUpdate, IDS_ENGINE_ACTION_PROMPTDLG, ActionPromptDlg, 0)

	IU_ATTRIBUTE_PAGE(CIuMeterUpdate, IDS_ENGINE_PPG_METERUPDATE, 50, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuMeterUpdate, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_METERUPDATE, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_KEY, IDS_ENGINE_PPG_METERUPDATE, 1, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_QUERYCODE, IDS_ENGINE_PPG_METERUPDATE, 1, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_STRING(CIuMeterUpdate, IDS_ENGINE_PROP_RESPONSECODE, IDS_ENGINE_PPG_METERUPDATE, 1, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuMeterUpdate, IDS_ENGINE_ACTION_UPDATE, IDS_ENGINE_PPG_METERUPDATE, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuMeterUpdate, IDS_ENGINE_ACTION_PROMPTDLG, IDS_ENGINE_PPG_METERUPDATE, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuMeterUpdate::CIuMeterUpdate()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	//{{Initialize
	m_iCount = 0;
	m_sQueryCode.Empty();
	m_sResponseCode.Empty();
	m_iMaxAttempts = 10;
	m_fUpdatedFlag = false;
	m_pMeter = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

CIuMeterUpdate::~CIuMeterUpdate()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuMeterUpdate::ActionPromptDlg(const CIuPropertyCollection&, CIuOutput&)
{
	PromptDlg();
	return CString("Success");
}

CString CIuMeterUpdate::ActionUpdate(const CIuPropertyCollection&, CIuOutput&)
{
	if (!Update())
		return CString("Failed");
	return CString("Success");
}

CString CIuMeterUpdate::GetKey() const
{
	return GetMeter().GetKey();
}

CIuMeter& CIuMeterUpdate::GetMeter() const
{
	return *m_pMeter;
}

CString CIuMeterUpdate::GetQueryCode() const
{
	return m_sQueryCode;
}

CString CIuMeterUpdate::GetResponseCode() const
{
	return m_sResponseCode;
}

bool CIuMeterUpdate::IsCorrupt()
{
	return GetMeter().IsCorrupt();
}

bool CIuMeterUpdate::IsValid()
{
	if (m_iMaxAttempts <= 0)
		return false;

	// Get the key for this meter
	CString sKey = GetKey();
	m_Session.SetKey(sKey);

	bool fValid = m_Session.Verify(GetResponseCode(), GetQueryCode());
	if (!fValid)
	{
		--m_iMaxAttempts;		
	}
	return fValid;
}

bool CIuMeterUpdate::PromptDlg(CWnd* pParent)
{
	CIuMeterUpdateDlg dlg(pParent);
	dlg.SetMeterUpdatePtr(this);
	return dlg.DoModal() == IDOK;
}

void CIuMeterUpdate::SetCount(int iCount)
{
	m_iCount = max(0, iCount);
	m_iCount = min(m_iCount, meterMagicMeterUpdateMax);

	DWORD dwCount = m_iCount;
	if (IsCorrupt())
		dwCount = meterMagicMeterCorrupt;
	else
	{
		// Add current meter value into the mix
		DWORD dwCurrent = GetMeter().GetCount();
		if (dwCurrent > meterMagicMeterCurrentMax)
			dwCurrent = meterMagicMeterCurrentMax;
		dwCount = (dwCount & 0x0000FFFF) | ((dwCurrent & 0x0000FFFF) << 16);
	}

	CString sKey = GetKey();
	m_Session.SetKey(sKey);
	m_sQueryCode = m_Session.GetQuery(dwCount, true);
}

void CIuMeterUpdate::SetMeter(CIuMeter* pMeter)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pMeter=pMeter;
}

void CIuMeterUpdate::SetResponseCode(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sResponseCode = pcsz;
}

bool CIuMeterUpdate::Update() 
{
	if (m_fUpdatedFlag)
		return true;

	bool bVal = false;
	if (IsValid())
	{
		if (IsCorrupt())
		{
			GetMeter().Reset();
			bVal = true;
		}
		else
		{
			GetMeter().Decrement(-GetCount());
			bVal = true;
			m_fUpdatedFlag = true;
		}
	}
	return bVal;
}
