#include "stdafx.h"
//{{Include
#include "Engine.h"
#include "Listeners.h"
#include "Error\Error.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuListeners, CIuListeners_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuListeners)
//}}Implement

CIuListeners::CIuListeners()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuListeners::~CIuListeners()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuListeners::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	if (m_pBroadcast.IsNull())
		m_pBroadcast.Create();
	SetVersion(IU_VERSION);
	//}}Initialize
}

bool CIuListeners::Fire(CIuEvent EventID, int iHandle)
{
	CIuProgressEvent Event;
	Event.SetEvent(EventID);
	Event.SetHandle(iHandle);
	return Fire(Event);
}

bool CIuListeners::Fire(CIuEvent EventID, int iHandle, LPCTSTR pcszMessage, LPCTSTR pcszOutput)
{
	CIuProgressEvent Event;
	Event.SetEvent(EventID);
	Event.SetHandle(iHandle);
	if (pcszMessage)
		Event.SetMessage(pcszMessage);
	if (pcszOutput)
		Event.SetOutput(pcszOutput);
	return Fire(Event);
}

bool CIuListeners::Fire(CIuEvent EventID, int iHandle, LPCTSTR pcszMessage, LPCTSTR pcszOutput, int iPosition, int iRange, COleDateTime dtStart, void* pv)
{
	CIuProgressEvent Event;
	Event.SetEvent(EventID);
	Event.SetHandle(iHandle);
	if (pcszMessage)
		Event.SetMessage(pcszMessage);
	if (pcszOutput)
		Event.SetOutput(pcszOutput);
	Event.SetPosition(iPosition);
	Event.SetRange(iRange);
	Event.SetStartTime(dtStart);
	Event.SetData(pv);
	return Fire(Event);
}

bool CIuListeners::Fire(const CIuProgressEvent& Event) 
{
	return GetBroadcast().Fire(Event);
}

CIuEngine& CIuListeners::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

void CIuListeners::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back 
	// to the engine.
	m_pEngine = &Engine;
}

void CIuListeners::Subscribe(CWnd* pWnd, UINT msg)
{
	GetBroadcast().Subscribe(pWnd, msg);
}

void CIuListeners::UnSubscribe(CWnd* pWnd)
{
	GetBroadcast().UnSubscribe(pWnd);
}

