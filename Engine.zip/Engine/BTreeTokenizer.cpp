#include "StdAfx.h"
//{{Include
#include "BTreeTokenizer.h"
#include "BTreeTokenizers.h"
#include "BTreeTokenizerSpec.h"
#include "BTreeCodec.h"
#include "BTree.h"
#include "BTrees.h"
#include "Cdrom.h"
#include "CdromSpec.h"
#include "Tokens.h"
#include "TokenMap.h"
#include "Token.h"
#include "TokenSpec.h"
#include "resource.h"
#include "Error\Error.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBTreeTokenizer, CIuBTreeTokenizer_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBTreeTokenizer)
const	CIuVersionNumber versionBTreeTokenizerMax(2000,1,5,304);
const	CIuVersionNumber versionBTreeTokenizerMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BTREETOKENIZER, CIuBTreeTokenizer, CIuBTreeTokenizer_super)
//{{AttributeMap
	// attribute for obsolete name

	IU_ATTRIBUTE_PAGE(CIuBTreeTokenizer, IDS_ENGINE_PPG_BTREETOKENIZER, 50, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeTokenizer, IDS_ENGINE_PROP_TOKENMONIKER, GetTokenMoniker, SetTokenMoniker, 0)
	IU_ATTRIBUTE_PROPERTY_MONIKER(CIuBTreeTokenizer, IDS_ENGINE_PROP_TOKENFILENAME, GetTokenMoniker, SetTokenMoniker, propertyObsolete)
	IU_ATTRIBUTE_EDITOR_MONIKER(CIuBTreeTokenizer, IDS_ENGINE_PROP_TOKENMONIKER, IDS_ENGINE_PPG_BTREETOKENIZER, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeTokenizer, IDS_ENGINE_PROP_OPTIONAL, IsOptional, SetOptional, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeTokenizer, IDS_ENGINE_PROP_OPTIONAL, IDS_ENGINE_PPG_BTREETOKENIZER, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuBTreeTokenizer, IDS_ENGINE_PROP_EXCEPTIONAL, IsExceptional, SetExceptional, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuBTreeTokenizer, IDS_ENGINE_PROP_EXCEPTIONAL, IDS_ENGINE_PPG_BTREETOKENIZER, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuBTreeTokenizer, IDS_ENGINE_PROP_MAP, GetMap_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuBTreeTokenizer, IDS_ENGINE_PROP_MAP, IDS_ENGINE_PPG_BTREETOKENIZER, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBTreeTokenizer::CIuBTreeTokenizer() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBTreeTokenizer::~CIuBTreeTokenizer()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBTreeTokenizer::Close(bool fForce)
{
	if (m_iOpen == 0)
		return ;
	if (m_iOpen > 1 && !fForce)
	{
		--m_iOpen;
		return ;
	}
	m_iOpen = 0;
	if (m_pToken.NotNull())
		m_pToken->Close();
	m_pToken.Release();
}

void CIuBTreeTokenizer::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("BTreeTokenizer");
	m_iOpen = 0;
	if (m_pMap.IsNull())
	{
		m_pMap.Create();
	}
	if (m_pInstance.IsNull())
	{
		m_pInstance.Create();
	}
	m_fOptional = false;
	m_pObjectRepository = 0;
	m_fExceptional = false;
	m_pObjectRepository = 0;
	m_monikerTokenMoniker.Clear();
	SetVersion(versionBTreeTokenizerMax);
	//}}Initialize
}

void CIuBTreeTokenizer::Decode(int iTokenNo, CIuStringBuffer& output) const
{
	ASSERT(IsOpen());
	m_pInstance->SetTokenNo(iTokenNo);
	// NOTE: Token file will return a blank record if token # == -1
	if (!GetToken().Decode(*m_pInstance) && !IsOptional())
	{
		CString sToken;
		sToken.Format("Token #%d", iTokenNo);
		Error(IU_E_TOKEN_NOT_FOUND, sToken);
	}
	output.Append(m_pInstance->GetBuffer());
}

int CIuBTreeTokenizer::Encode(const CIuRecord& Record) const
{
	ASSERT(IsOpen());

	m_pInstance->Set(Record, GetMap());
	if (!GetToken().Encode(*m_pInstance))
	{
		if (!IsOptional() && !IsExceptional())
		{
			CStringArray as;
			m_pInstance->GetKeys(as);
			CString s;
			StringArrayAsString(s, as);
			Error(IU_E_TOKEN_NOT_FOUND, s);
		}
		// Token not found...
		return -1;
	}
	return m_pInstance->GetTokenNo();
}

int CIuBTreeTokenizer::GetBitsRequired() const
{
	if (IsExceptional())
	{
		// Allow one extra token value for the exceptional token case
		return BitsRequired(GetToken().GetTokenCount() + 1);
	}
	else
		return GetToken().GetBitsRequired();
}

CIuObject* CIuBTreeTokenizer::GetInstance_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInstance.Ptr()));
}

CIuObject* CIuBTreeTokenizer::GetMap_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pMap.Ptr()));
}

CIuBTreeTokenizers& CIuBTreeTokenizer::GetTokenizers() const
{
	CIuBTreeTokenizers* pParent = dynamic_cast<CIuBTreeTokenizers*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuVersionNumber CIuBTreeTokenizer::GetVersionMax() const
{
	return versionBTreeTokenizerMax;
}

CIuVersionNumber CIuBTreeTokenizer::GetVersionMaxStatic()
{
	return versionBTreeTokenizerMax;
}

CIuVersionNumber CIuBTreeTokenizer::GetVersionMin() const
{
	return versionBTreeTokenizerMin;
}

CIuVersionNumber CIuBTreeTokenizer::GetVersionMinStatic()
{
	return versionBTreeTokenizerMin;
}

bool CIuBTreeTokenizer::IsValid() const
{
	if (!HasObjectRepository())
		return false;
	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_TOKEN);
	return GetObjectRepository().Find(GetTokenMoniker(), sType) >= 0;
}

void CIuBTreeTokenizer::MakeRecordDef(CIuRecordDef& RecordDef)
{
	GetMap().MakeRecordDef(RecordDef);
}

void CIuBTreeTokenizer::Open()
{
	if (IsOpen())
		return ;

	++m_iOpen;

	CString sType = IuClassFactoryGetType(IDS_ENGINE_OBJECT_TOKEN);
	int iToken = GetObjectRepository().Find(GetTokenMoniker(), sType);
	if (iToken < 0)
		Error(IU_E_TOKEN_FILE_NOT_FOUND, LPCTSTR(GetTokenMoniker().GetName()));

	CIuObjectPtr pObject = GetObjectRepository().UnPack(iToken).Ptr();
	if (pObject.IsNull())
		Error(IU_E_TOKEN_FILE_NOT_FOUND, LPCTSTR(GetTokenMoniker().GetName()));

	CIuTokenPtr pToken = dynamic_cast<CIuToken*>(pObject.Ptr());
	ASSERT(pToken.NotNull());
	SetToken(pToken);

	if (m_pObjectRepository)
		GetToken().SetObjectRepository(m_pObjectRepository);
	GetToken().Open();

	if (GetToken().GetKeyCount() != GetMap().GetKey().GetFieldCount())
	{
		TRACE("WARNING: Key count in token file did not match tokenizer.\n");
		GetMap().GetKey().RemoveAllFields();
		for (int iKey = 0; iKey < GetToken().GetKeyCount(); ++iKey)
		{
			GetMap().GetKey().AddField(GetToken().GetRecordDef().GetFieldDefs().Get(iKey).GetName());
		}
	}

	if (GetToken().GetValueCount() != GetMap().GetValue().GetFieldCount())
	{
		TRACE("WARNING: Value count in token file did not match tokenizer.\n");
		GetMap().GetValue().RemoveAllFields();
		for (int iValue = 0; iValue < GetToken().GetValueCount(); ++iValue)
		{
			GetMap().GetValue().AddField(GetToken().GetRecordDef().GetFieldDefs().Get(GetToken().GetKeyCount() + iValue).GetName());
		}
	}
}

void CIuBTreeTokenizer::Resolve(CIuResolveSpec& Spec)
{
	GetMap().Resolve(Spec);
}

void CIuBTreeTokenizer::SetExceptional(bool f)
{
	m_fExceptional = f;
}

void CIuBTreeTokenizer::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuBTreeTokenizer::SetOptional(bool f)
{
	m_fOptional = f;
}

void CIuBTreeTokenizer::SetSpec(CIuBTreeTokenizerSpec& Spec)
{
	SetMoniker(GetMoniker());

	GetMap().SetSpec(Spec.GetCdrom(), Spec.GetTokenNo());
	SetExceptional(Spec.IsExceptional());
	SetOptional(Spec.IsOptional());

	CIuCdromSpec& Cdrom = Spec.GetCdrom();

	int iToken = Cdrom.FindToken(Spec.GetFilename());
	ASSERT(iToken >= 0);
	SetTokenMoniker(Cdrom.GetToken(iToken).GetMoniker());
}

void CIuBTreeTokenizer::SetToken(CIuToken* pToken)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	ASSERT(pToken!=0);
	m_pToken = pToken;
}

void CIuBTreeTokenizer::SetTokenMoniker(const CIuMoniker& moniker)
{
	m_monikerTokenMoniker = moniker;
}
