#include "stdafx.h"
#include "ReportDefaultDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuReportDefaultDlg, CIuReportDefaultDlg_super)
	//{{AFX_MSG_MAP(CIuReportDefaultDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuReportDefaultDlg::CIuReportDefaultDlg(CWnd* pParent /*=NULL*/) : CIuReportDefaultDlg_super(CIuReportDefaultDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuReportDefaultDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CIuReportDefaultDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuReportDefaultDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuReportDefaultDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuReportDefaultDlg::ReportDlg(CIuReport& Report, CWnd* pParent)
{
	CIuReportDefaultDlg dlg(pParent);
	dlg.m_pReport = &Report;
	return (dlg.DoModal() == IDOK);
}

