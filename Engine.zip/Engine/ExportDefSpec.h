#ifndef _ENGINE_EXPORTDEFSPEC_H_
#define _ENGINE_EXPORTDEFSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef  _ENGINE_EXPORTDEF_H_
#  include "Engine\ExportDef.h"
#endif
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportDefSpec, CIuObjectNamed }}
#define CIuExportDefSpec_super CIuObjectNamed

class CIuExportDefSpec : public CIuExportDefSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportDefSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportDefSpec();
	virtual ~CIuExportDefSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetDescription() const;
	int GetExportDefNo() const;
	CString GetExporter() const;
	CString GetExtension() const;
	CIuExportFieldDefSpec& GetFieldDef(int iExportFieldDef) const;
	int GetFieldDefCount() const;
	static void GetNames(CStringArray& as);
	CString GetOptions() const;
	int GetRecordLength() const;
	CString GetTitle() const;
	int GetType() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool FromIndex(CIuCdromSpec* pCdrom, int iSpec);
	bool FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszName);
	bool FromNo(CIuCdromSpec* pCdrom, int iExportDefNo);
	void RemoveAllFieldDefs();
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetDescription(LPCTSTR);
	void SetExportDefNo(int);
	void SetExporter(LPCTSTR);
	void SetExtension(LPCTSTR);
	void SetType(int);
	void SetOptions(LPCTSTR);
	void SetRecordLength(int);
	void SetTitle(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void CreateFieldDef(LPCTSTR pcszFieldDef);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sTitle;
	CString m_sDescription;
	CString m_sExtension;
	CString m_sOptions;
	CString m_sExporter;
	int m_iExportDefType;
	int m_iRecordLength;
	CIuExportFieldDefSpecArray m_apFieldDefs;
	CIuCdromSpec* m_pCdrom;
	int m_iExportDefNo;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}
inline CIuCdromSpec& CIuExportDefSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuExportDefSpec::GetDescription() const
{
	return m_sDescription;
}

inline int CIuExportDefSpec::GetExportDefNo() const
{
	return m_iExportDefNo;
}

inline CString CIuExportDefSpec::GetExporter() const
{
	return m_sExporter;
}

inline CString CIuExportDefSpec::GetExtension() const
{
	return m_sExtension;
}

inline CString CIuExportDefSpec::GetOptions() const
{
	return m_sOptions;
}

inline int CIuExportDefSpec::GetRecordLength() const
{
	return m_iRecordLength;
}

inline CString CIuExportDefSpec::GetTitle() const
{
	return m_sTitle;
}

inline int CIuExportDefSpec::GetType() const
{
	return m_iExportDefType;
}

#endif // _ENGINE_EXPORTDEFSPEC_H_

