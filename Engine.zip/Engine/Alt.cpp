#include "StdAfx.h"
//{{Include
#include "Alt.h"
#include "Alts.h"
#include "AltInstance.h"
#include "AltRaw.h"
#include "Miscellaneous.h"
#include "AltRawElement.h"
#include "Data\DataFilename.h"
#include "Data\PackRepository.h"
#include "Data\PrefixFile.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Common\BigNybbleBuffer.h"
#include "Common\NybbleString.h"
#include "Common\NybbleInt.h"
#include "Data\Output.h"
#include "Error\Error.h"
#include "Common\StaticBuffer.h"
#include "..\Version.h"
#include "FieldDefConst.h"
#include "Cdrom.h"
#include "CdromSpecConst.h"
#include "AltSpec.h"
#include "CdromSpec.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAlt, CIuAlt_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAlt)
const	CIuVersionNumber versionAlt(1999,0,8,600);
const	CIuVersionNumber versionAltMax(2000,1,5,304);
const	CIuVersionNumber versionAltMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALT, CIuAlt, CIuAlt_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuAlt, IDS_ENGINE_PPG_ALT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAlt, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuAlt, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ALT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuAlt, IDS_ENGINE_PROP_NUMERICKEY, IsNumericKey, SetNumericKey, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuAlt, IDS_ENGINE_PROP_NUMERICKEY, IDS_ENGINE_PPG_ALT, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuAlt, IDS_ENGINE_PROP_NOSTORE, IsNoStore, SetNoStore, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuAlt, IDS_ENGINE_PROP_NOSTORE, IDS_ENGINE_PPG_ALT, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAlt, IDS_ENGINE_PROP_ALTCOUNT, GetAltCount, SetAltCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAlt, IDS_ENGINE_PROP_ALTCOUNT, IDS_ENGINE_PPG_ALT, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAlt, IDS_ENGINE_PROP_ALTSIZE, GetAltSize, SetAltSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAlt, IDS_ENGINE_PROP_ALTSIZE, IDS_ENGINE_PPG_ALT, 0, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAlt, IDS_ENGINE_PROP_EXPANDEDKEYSIZE, GetExpandedKeySize, SetExpandedKeySize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAlt, IDS_ENGINE_PROP_EXPANDEDKEYSIZE, IDS_ENGINE_PPG_ALT, INT_MIN, INT_MAX, editorReadOnly)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAlt, IDS_ENGINE_PROP_DATABASE, GetDatabase, SetDatabase, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuAlt, IDS_ENGINE_PROP_DATABASE, IDS_ENGINE_PPG_ALT, 1, 0)

	IU_ATTRIBUTE_PAGE(CIuAlt, IDS_ENGINE_PPG_ALT2, 50, 0)
	IU_ATTRIBUTE_PROPERTY_GRID(CIuAlt, IDS_ENGINE_PROP_GRID, GetGridInfo, propertyNoSerialize)
	IU_ATTRIBUTE_EDITOR_GRID(CIuAlt, IDS_ENGINE_PROP_GRID, IDS_ENGINE_PPG_ALT2, 10, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()


CIuAlt::CIuAlt() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAlt::CIuAlt(const CIuAlt& rAlt)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rAlt;
}

CIuAlt::~CIuAlt()
{
	Close(true);
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuAlt::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (Flags.Test(cdromsBuildCompressAlt))
		if (!BuildCompress(Output))
			return false;
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	// Some alt objects are only used to build see-also records in indexes...
	if (Flags.Test(cdromsBuildPackDatabaseObjects) && !IsNoStore())
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	if (Flags.Test(cdromsBuildPackDatabaseFiles) && !IsNoStore())
		GetObjectRepository().PackFile(*this, Cdrom.GetPack(), &Output, GetFilename());
	return true;
}

bool CIuAlt::BuildCompress(CIuOutput& Output)
{
	// Save current progress status
	CIuOutputStateInstance Progress(Output);

	// Output description, set range, etc
	Output.OutputF("Compressing alternates '%s'\n", LPCTSTR(GetName()));
	Output.SetPosition(0);
	Output.SetRange(0);
	if (!Output.Fire())
		return false;

	// Be sure that this file is closed
	Close(true);

	// Load the raw Alt file and sort it by key
	Output.SetMessageF("Reading raw alternates '%s'\n", LPCTSTR(GetName()));
	Output.Fire();
	CIuAltRaw raw;
	raw.SetFilename(GetFilename());
	raw.Read();

	// Sort
	Output.SetMessageF("Sorting raw alternates '%s'\n", LPCTSTR(GetName()));
	Output.Fire();
	raw.SortByKey();

	// Process each of the Alts
	CIuBigNybbleBuffer nb;
	nb.SetSize(3 * 1024 * 1024);
	nb.Empty();

	CIuNybbleString ns;

	m_iExpandedKeySize = 0;

	int iAlts = raw.GetCount();

	Output.SetMessageF("Compressing raw alternate record file '%s'\n", LPCTSTR(GetName()));
	Output.SetRange(iAlts);
	Output.Fire();

	CIuNybbleBuffer nbCurrent;
	CIuNybbleBuffer nbPrevious;
	int iAltSize = 0;
	for (int iAlt = 0; iAlt < iAlts; ++iAlt)
	{
		if ((iAlt % ((iAlts + 99) / 100)) == 0)
		{
			Output.SetPosition(iAlt);
			if (!Output.Fire())
				return false;
		}

		CIuAltRawElement* pAlt = raw.Get(iAlt);
		ASSERT(pAlt);

		nbCurrent.Empty();

		if (pAlt->GetKey().IsEmpty())
			Error(IU_E_KEY_INVALID, _T("Alternate record key is empty."));

		m_iExpandedKeySize += pAlt->GetKey().GetLength() + 1;

		ns.Set(LPCTSTR(pAlt->GetKey()), pAlt->GetKey().GetLength() + 1, IsNumericKey() ? NS_NUMERIC: NS_ALPHA);
		nbCurrent += ns;

		int iValues = pAlt->GetValueCount();

		// Output number of alternate values
		ASSERT(iValues > 0);
		CIuNybbleInt::AppendUIntCompressed(iValues - 1, nbCurrent);

		// Output the alternates
		for (int iValue = 0; iValue < iValues; ++iValue)
		{
			ns.Set(LPCTSTR(pAlt->GetValue(iValue)), pAlt->GetValue(iValue).GetLength() + 1, NS_ALPHA);
			nbCurrent += ns;
		}

		// Get number of Nybbles being output
		int iNybbles = nbCurrent.GetNybbles();
		ASSERT(iNybbles != 0);

		// Remember the expanded size
		iAltSize += iNybbles;

		// NOTE: The last byte is always a zero, but we don't need to store it.
		ASSERT(nbCurrent.GetNybbles() > 0);
		ASSERT(nbCurrent.Get(nbCurrent.GetNybbles() - 1) == 0);
		nbCurrent.SetNybbles(nbCurrent.GetNybbles() - 1);

		--iNybbles;

		// Get prefix nybbles if not the first record.
		int iPrefix = 0;
		if (iAlt > 0)
		{
			iPrefix = nbPrevious.GetPrefix(nbCurrent);
			ASSERT(iPrefix <= iNybbles);

			// Adjust record nybbles to skip prefix
			iNybbles -= iPrefix;
		}

		// Output the size of this record
		CIuNybbleInt::AppendUIntCompressed(iNybbles, nb);

		// Output the size of the prefix if this is not the first record in the block
		if (iAlt > 0)
			CIuNybbleInt::AppendUIntCompressed(iPrefix, nb);

		// Append record skipping over prefix
		nb.Append(nbCurrent, -1, iPrefix);

		// Save current record for next pass
		nbPrevious = nbCurrent;
	}

	SetAltCount(iAlts);
	SetAltSize(iAltSize);

	Output.SetMessageF("Writing");
	Output.Fire();
	Write(nb);

	SanityCheck(Output, raw);

	Output.OutputF("%ld alternate in %s\n", GetAltCount(), LPCTSTR(GetName()));
	Output.OutputF("\t%ld nybbles compressed size\n", GetAltSize());
	Output.OutputF("\t%ld bytes total expanded key size\n", GetExpandedKeySize());

	// Display elapsed time
	Progress.Pop(true);

	// Return abort status
	return Output.Fire();
}

void CIuAlt::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iAltCount = 0;
	m_iOpen = 0;
	m_iAltSize = 0;
	m_sFilename = "Alt";
	m_fNumericKey = false;
	m_fNoStore = false;
	SetVersion(versionAlt);
	m_iExpandedKeySize = 0;
	m_pObjectRepository = 0;
	m_fKeysExpanded = false;
	m_sDatabase = "Database";
	SetVersion(versionAltMax);
	//}}Initialize
}

void CIuAlt::Close(bool fForce)
{
	if (m_iOpen == 0)
		return ;
	if (m_iOpen > 1 && !fForce)
	{
		--m_iOpen;
		return ;
	}

	m_iOpen = 0;
	Empty();
}

void CIuAlt::Copy(const CIuObject& object)
{
	CIuAlt_super::Copy(object);

	const CIuAlt* pAlt = dynamic_cast<const CIuAlt*>(&object);
	if (pAlt == 0 || pAlt == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuAlt)));

	m_iAltCount = pAlt->m_iAltCount;
	m_iAltSize = pAlt->m_iAltSize;
	m_sFilename = pAlt->m_sFilename;
	m_fNumericKey = pAlt->m_fNumericKey;
	m_fNoStore = pAlt->m_fNoStore;
	m_iExpandedKeySize = pAlt->m_iExpandedKeySize;
}

void CIuAlt::Delete(CIuOutput* pOutput)
{
	CdromDelete(GetFullFilename(), pOutput);
	Empty();
}

void CIuAlt::Empty()
{
	ASSERT(!IsOpen());
	m_Buffer.Destroy();
	m_Elements.RemoveAll();
	m_Frequency.RemoveAll();
	m_BufferKeys.Destroy();
	m_ElementKeys.RemoveAll();
	m_fKeysExpanded = false;
}

bool CIuAlt::Exists() const
{
	CIuFilename filename = GetFullFilename();
	return filename.Exists();
}

void CIuAlt::ExpandKeys()
{
	m_ElementKeys.SetSize(GetAltCount() + 1);
	m_BufferKeys.PreAllocate(GetExpandedKeySize() + 1);
	m_BufferKeys.Empty();

	for (int iAlt = 0; iAlt < GetAltCount(); ++iAlt)
	{
		m_ElementKeys.SetAt(iAlt, m_BufferKeys.GetSize());

		int iOffset = m_Elements[iAlt];
		iOffset += CIuNybbleString::Get(m_BufferKeys, -1, true, IsNumericKey() ? NS_NUMERIC: NS_ALPHA, m_Buffer, iOffset);
	}

	// Add extra on to end so that "Size=element[n+1]-element[n]" always works
	m_ElementKeys.SetAt(iAlt, m_BufferKeys.GetSize());

	m_fKeysExpanded = true;
}

int CIuAlt::Find(LPCTSTR pcsz) const
{
	if (!m_fKeysExpanded)
		const_cast<CIuAlt*>(this)->ExpandKeys();

	ASSERT(m_fKeysExpanded);
	ASSERT(IsOpen());

	CIuStaticBuffer512 Buffer;
	int iLength = _tcslen(pcsz);
	if (iLength > 0 && pcsz[iLength-1] != ',')
	{
		// You must append a comma so that we match the alternate key.
		// Alternate always have the comma appended to insure correct sort order
		Buffer.Append((const BYTE*)pcsz, iLength);
		Buffer.Append((BYTE)',');
		Buffer.Append((BYTE)'\0');
		pcsz = Buffer;
	}

	int iHi = GetAltCount() - 1;
	if (iHi < 0)
		return -1;
	int iLo = 0;
	while (iLo <= iHi)
	{
		// NOTE: In order for this loop to exit, we must insure 
		// that if Lo + 1 == Hi, then we will test the Lo value.
		int iTest = iLo + (iHi - iLo) / 2;
		ASSERT(iTest >= iLo && iTest <= iHi);

		const BYTE* pbAlt = m_BufferKeys.GetPtr(m_ElementKeys[iTest]);

		int iResult = _tcsicmp(pcsz, LPCTSTR(pbAlt));
		if (iResult == 0)
			return iTest;
		else if (iResult < 0)
			iHi = iTest - 1;			
		else //  if (iResult > 0)
			iLo = iTest + 1;			
	}
	return -1;
}

void CIuAlt::Get(int iAlt, CIuAltInstance& instance) const
{
	ASSERT(iAlt >= 0 && iAlt < GetAltCount());

	int iOffset = m_Elements[iAlt];

	instance.Clear();


	CIuStaticBuffer4096 Buffer;
	iOffset += CIuNybbleString::Get(Buffer, -1, false, IsNumericKey() ? NS_NUMERIC: NS_ALPHA, m_Buffer, iOffset);
	instance.SetKey(LPCTSTR(Buffer.GetPtr()));

	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, m_Buffer, iOffset);
	int iValues = uiVal + 1;

	for (int iValue = 0; iValue < iValues; ++iValue)
	{
		iOffset += CIuNybbleString::Get(Buffer, -1, false, NS_ALPHA, m_Buffer, iOffset);
		instance.AddValue(LPCTSTR(Buffer.GetPtr()));
	}

	ASSERT(iOffset == m_Elements[iAlt + 1]);
}

CString CIuAlt::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CString CIuAlt::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

bool CIuAlt::GetGridInfo(int iRq, CIuGridRq& rq)
{
	switch (iRq)
	{
		case gridRqInitialize:
		{
			static TCHAR szName[] = _T("CIuAltGrid");
			rq.SetName(szName);
			rq.Load();
			if (!IsOpen() && Exists())
			{
				Open();
				rq.SetOpen4Edit();
			}
			if (IsOpen())
			{
				rq.SetSize(CSize(2, GetAltCount()));
				rq.SetColumn(0, "Key", 100, gridWidthOptional);
				rq.SetColumn(1, "Values", 100, gridWidthOptional);
			}
			return true;
		}
		case gridRqTerminate:
			if (rq.IsOpen4Edit())
				Close();
			rq.Save();
			return true;
		case gridRqDblClickRow:
		case gridRqDblClickCell:
			if (rq.GetRow() >= 0 && rq.GetRow() < GetAltCount())
			{
				CIuAltInstance instance;
				Get(rq.GetRow(), instance);
				instance.Edit();
				return true;
			}
			return false;
		case gridRqGet:
		{
			if (rq.GetRow() < 0 || rq.GetRow() >= GetAltCount())
				return false;

			CIuAltInstance instance;
			Get(rq.GetRow(), instance);

			if (rq.GetColumn() == 0)
			{
				rq.SetValue(instance.GetKey());
			}
			else
			{
				CStringArray as;
				instance.GetValues(as);
				CString s;
				StringArrayAsString(s, as);
				rq.SetValue(instance.GetKey());
			}
			return true;
		}
		default:
			ASSERT(false);
			return false;
	}
	return false;
}

CIuAlts& CIuAlt::GetAlts() const
{
	CIuAlts* pParent = dynamic_cast<CIuAlts*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuVersionNumber CIuAlt::GetVersionMax() const
{
	return versionAltMax;
}

CIuVersionNumber CIuAlt::GetVersionMaxStatic()
{
	return versionAltMax;
}

CIuVersionNumber CIuAlt::GetVersionMin() const
{
	return versionAltMin;
}

CIuVersionNumber CIuAlt::GetVersionMinStatic()
{
	return versionAltMin;
}

bool CIuAlt::HasAlts() const
{
	return HasCollection();
}


void CIuAlt::Open()
{
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}

	Close(true);

	m_iOpen = 1;

	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	// Open the file and read in the Alts as one large block
	CIuPrefixFilePtr pFile;
	CIuFileVirtualPtr pVFile;
	CRC32 crc;
	GetObjectRepository().Use(*this, pFile, pVFile, GetFilename(), 0, &crc);

	// Read...
	CIuBigNybbleBuffer nb;
	if (pVFile->GetLength() > 0)
	{
		nb.SetSize(int(pVFile->GetLength()));
		nb.SetNybbles(int(pVFile->GetLength()) * 2);
		pVFile->Read(nb.GetData(), nb.GetBytes());

		CRC32 crcActual = crc32(nb.GetData(), nb.GetBytes());
		if (crc != 0 && crc != crcActual)
			Error(IU_E_OBJECT_INVALID_OR_CORRUPT, GetName());
	}

	// Clear current data
	m_Elements.SetSize(GetAltCount() + 1);
	m_Buffer.SetSize((GetAltSize() + 1) / 2);
	m_Buffer.SetNybbles(0);

	// Expand from delta compresssed to simply nybble compressed by record
	// This is done to speed decompression at the expense of memory
	CIuNybbleBuffer nbRecord;

	int iOffset = 0;
	for (int iAlt = 0; iAlt < GetAltCount(); ++iAlt)
	{
		// Remember position of this record
		m_Elements.SetAt(iAlt, m_Buffer.GetNybbles());

		// Get size of this record
		unsigned int uiVal;
		iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, nb, iOffset);
		int iNybbles = uiVal;

		// Get prefix
		if (iAlt > 0)
		{
			iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, nb, iOffset);
			int iPrefix = uiVal;
			nbRecord.SetNybbles(iPrefix);
		}

		// Append suffix
		int iExtract = nbRecord.Append(nb, iNybbles, iOffset);
		ASSERT(iExtract == iNybbles);
		iOffset += iExtract;

		// Add the null terminator back on
		nbRecord.Append(BYTE(0));

		// Append the record
		m_Buffer += nbRecord;
	}

	// Add this in so that we can easily determine the record length
	// by "element[i+1] - element[i]".
	m_Elements.SetAt(iAlt, m_Buffer.GetNybbles());

	// Double check to make sure the read worked correctly
	ASSERT(iOffset == nb.GetNybbles() || iOffset + 1 == nb.GetNybbles());
	ASSERT(m_Buffer.GetNybbles() == GetAltSize());
	ASSERT(m_Elements.GetSize() == GetAltCount()+1);
}

CIuAlt& CIuAlt::operator=(const CIuAlt& rAlt)
{
	Copy(rAlt);
	return *this;
}

void CIuAlt::SanityCheck(CIuOutput& Output, CIuAltRaw& raw)
{
	Output.OutputF("Validating alternate record file '%s'\n", LPCTSTR(GetName()));
	Output.Fire();

	// Save current progress status
	CIuOutputStateInstance Progress(Output);

	Output.SetMessageF("Opening compressed alternate record image '%s'\n", LPCTSTR(GetName()));
	Output.Fire();

	CIuAlt file;
	file = *this;
	ASSERT(HasObjectRepository());
	file.SetObjectRepository(&GetObjectRepository());
	file.Open();

	if (file.GetAltCount() != GetAltCount())
		Error(IU_E_ALT_INVALID, _T("Stored count does not match memory image."));
	if (file.GetAltCount() != raw.GetCount())
		Error(IU_E_ALT_INVALID, _T("Stored count does not match raw records."));
	if (file.GetVersion() != GetVersion())
		Error(IU_E_ALT_INVALID, _T("Versions do not match."));
	if (file.GetExpandedKeySize() != GetExpandedKeySize())
		Error(IU_E_ALT_INVALID, _T("Expanded key size incorrect."));
	if (file.GetAltSize() != GetAltSize())
		Error(IU_E_ALT_INVALID, _T("Expanded data size incorrect."));
	if (file.IsNumericKey() != IsNumericKey())
		Error(IU_E_ALT_INVALID, _T("Key type does not match."));

	CIuAltInstance Instance;

	int iAlts = file.GetAltCount();

	Output.SetMessageF("Validating records in alternate record image '%s'\n", LPCTSTR(GetName()));
	Output.SetRange(iAlts);
	Output.SetPosition(0);
	Output.Fire();

	CString sPreviousKey;

	for (int iAlt = 0; iAlt < iAlts; ++iAlt)
	{
		if ((iAlt % ((iAlts + 99) / 100)) == 0)
		{
			Output.SetPosition(iAlt);
			if (!Output.Fire())
				return ;
		}

		file.Get(iAlt, Instance);

		CIuAltRawElement* pAlt = raw.Get(iAlt);
		ASSERT(pAlt);
		if (iAlt > 0)
		{
			CIuAltRawElement* pAltPrev = raw.Get(iAlt - 1);
			int iResult = pAltPrev->GetKey().CompareNoCase(pAlt->GetKey());
			if (iResult >= 0)
			{
				CString sDebug;
				sDebug.Format(_T("Raw alternate records out of order @ %ld\n[%s]\n[%s]"),
					iAlt, LPCTSTR(pAltPrev->GetKey()), LPCTSTR(pAlt->GetKey()));
				Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
			}
		}

		int iResult = pAlt->GetKey().CompareNoCase(Instance.GetKey());
		if (iResult != 0)
		{
			CString sDebug;
			sDebug.Format(_T("Alternate key did not match compressed image @ %ld\n[%s]\n[%s]"),
				iAlt, LPCTSTR(pAlt->GetKey()), LPCTSTR(Instance.GetKey()));
			Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
		}

		int iValues = pAlt->GetValueCount();
		for (int iValue = 0; iValue < iValues; ++iValue)
		{
			int iResult = pAlt->GetValue(iValue).CompareNoCase(Instance.GetValue(iValue));
			if (iResult != 0)
			{
				CString sDebug;
				sDebug.Format(_T("Alternate values did not match compressed image @ %ld\n[%s]\n[%s]"),
					iAlt, LPCTSTR(pAlt->GetValue(iValue)), LPCTSTR(Instance.GetValue(iValue)));
				Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
			}
		}

		int iFound = file.Find(pAlt->GetKey());
		if (iFound != iAlt)
		{
			CString sDebug;
			sDebug.Format(_T("Could not find record in alternates @ %ld\n[%s]"),
				iAlt, LPCTSTR(pAlt->GetKey()));
			Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
		}

		iResult = sPreviousKey.CompareNoCase(pAlt->GetKey());
		if (iResult == 0 && iAlt > 0)
		{
			CString sDebug;
			sDebug.Format(_T("Duplicate keys @ %ld\n[%s]\n[%s]"),
				iAlt, LPCTSTR(sPreviousKey), LPCTSTR(pAlt->GetKey()));
			Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
		}
		if (iResult > 0)
		{
			CString sDebug;
			sDebug.Format(_T("Keys out of sort order @ %ld\n[%s]\n[%s]"),
				iAlt, LPCTSTR(sPreviousKey), LPCTSTR(pAlt->GetKey()));
			Error(IU_E_ALT_INVALID, LPCTSTR(sDebug));
		}

		sPreviousKey = pAlt->GetKey();
	}
}

void CIuAlt::SetAltCount(int iAltCount)
{
	m_iAltCount = iAltCount;
}

void CIuAlt::SetAltSize(int iAltSize)
{
	m_iAltSize = iAltSize;
}

void CIuAlt::SetDatabase(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDatabase = pcsz;
}

void CIuAlt::SetExpandedKeySize(int iExpandedKeySize)
{
	m_iExpandedKeySize = iExpandedKeySize;
}

void CIuAlt::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAlt::SetNoStore(bool f)
{
	m_fNoStore = f;
}

void CIuAlt::SetNumericKey(bool f)
{
	m_fNumericKey = f;
}

void CIuAlt::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuAlt::SetSpec(CIuAltSpec& Alt)
{
	SetDatabase(Alt.GetCdrom().GetName());
	SetMoniker(Alt.GetMoniker());

	SetFilename(Alt.GetFilename());
	SetNoStore(Alt.IsNoStore());
	SetNumericKey(Alt.IsNumericKey());
}

void CIuAlt::Write(CIuNybbleBuffer& nb)
{
	// Write the data to an external file
	CIuPrefixFile file;
	ASSERT(HasObjectRepository());
	file.Create(GetObjectRepository().GetFullFilename(*this, GetFilename()), 16 * 1024, CIuFile::openCreate);
	file.SetData(*this);

	CIuFileVirtualPtr pVFile = file.Use();
	pVFile->Seek(0);
	if (nb.GetBytes() > 0)
		pVFile->Write(nb.GetData(), nb.GetBytes());

	// For close so that  debug checks can proceed
	pVFile.Release();
	file.Close();
}

