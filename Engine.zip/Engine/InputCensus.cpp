#include "StdAfx.h"
//{{Include
#include "InputCensus.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputCensus, CIuInputCensus_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputCensus)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTCENSUS, CIuInputCensus, CIuInputCensus_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputCensus, IDS_ENGINE_PPG_INPUTCENSUS, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputCensus::CIuInputCensus() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputCensus::~CIuInputCensus()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputCensus::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input Census"));
	SetInputFilename("Census");
	SetOutputFilename("Census");
	SetFormat(inputCensus);
	//}}Initialize
}

bool CIuInputCensus::OnProcess()
{
	SetField(inputFieldZIP,					GetInput(0));
	SetField(inputFieldMedianIncome,		GetInput(1));
	SetField(inputFieldMedianHomeValue,	GetInput(2));
	return Output();
}
