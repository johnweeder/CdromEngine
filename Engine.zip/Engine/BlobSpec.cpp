#include "StdAfx.h"
//{{Include
#include "BlobSpec.h"
#include "BlobSpecDft.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuBlobSpec, CIuBlobSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBlobSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BLOBSPEC, CIuBlobSpec, CIuBlobSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBlobSpec, IDS_ENGINE_PPG_BLOBSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuBlobSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuBlobSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_BLOBSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuBlobSpec, IDS_ENGINE_PROP_BLOBNO, GetBlobNo, SetBlobNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuBlobSpec, IDS_ENGINE_PROP_BLOBNO, IDS_ENGINE_PPG_BLOBSPEC, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBlobSpec::CIuBlobSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBlobSpec::~CIuBlobSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuBlobSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_sFilename = "Filename";
	m_iBlobNo = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuBlobSpec::FromIndex(CIuCdromSpec* pCdrom, int iBlobSpec)
{
	ASSERT(iBlobSpec >= 0);

	const CIuBlobSpecDft* pBlobSpec = CIuBlobSpecDft::Get(iBlobSpec);
	ASSERT(pBlobSpec);

	FromSpec(pCdrom, pBlobSpec);
}

void CIuBlobSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszBlob)
{
	FromIndex(pCdrom, CIuBlobSpecDft::Find(pcszBlob));
}

void CIuBlobSpec::FromNo(CIuCdromSpec* pCdrom, int iBlobNo)
{
	FromIndex(pCdrom, CIuBlobSpecDft::Find(iBlobNo));
}

void CIuBlobSpec::FromSpec(CIuCdromSpec* pCdrom, const CIuBlobSpecDft* pBlobSpec)
{
	SetCdrom(pCdrom);

	// Blobs have unique id's so they are updateable
	SetName(pBlobSpec->m_pcszBlob);
	ASSERT(pBlobSpec->m_pid);
	SetID(*pBlobSpec->m_pid);

	SetBlobNo(pBlobSpec->m_iBlob);
	SetFilename(pBlobSpec->m_pcszFilename);
}

int CIuBlobSpec::GetCount()
{
	return CIuBlobSpecDft::GetCount();
}

void CIuBlobSpec::SetBlobNo(int iBlobNo)
{
	m_iBlobNo = iBlobNo;
}

void CIuBlobSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuBlobSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}
