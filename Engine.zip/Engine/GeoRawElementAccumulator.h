#ifndef _ENGINE_GEORAWELEMENTACCUMULATOR_H_
#define _ENGINE_GEORAWELEMENTACCUMULATOR_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawElementAccumulator)
class CIuGeoRaw;
class CIuNybbleBuffer;
class CIuGeoRawElementMap;
struct CIuGeoRawElementAccumulatorTuple;
typedef CArray<CIuGeoRawElementAccumulatorTuple*, CIuGeoRawElementAccumulatorTuple*> CIuGeoRawElementAccumulatorTupleArray;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawElementAccumulator, CIuObject }}
#define CIuGeoRawElementAccumulator_super CIuObject

class CIuGeoRawElementAccumulator : public CIuGeoRawElementAccumulator_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawElementAccumulator)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawElementAccumulator();
	virtual ~CIuGeoRawElementAccumulator();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAccumulated() const;
	int GetCount(int iWhich) const;
	CString GetName(int iWhich) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Add(__int64 l, int iPad = 0);
	void Add(LPCTSTR pcszName, int iActuaiCount = -1);
	void Clear();
	int CompressPreferred(CIuGeoRaw&, CIuNybbleBuffer& buffer, int iMax, bool fNumeric = false);
	void CompressPreferred(CIuGeoRaw& geo, CIuNybbleBuffer& buffer, CIuGeoRawElementMap& map);
	void CompressPreferred(CIuGeoRaw& geo, CIuNybbleBuffer& buffer, LPCTSTR pcszDefault = 0);
	void SortByCountDecreasing();
	void SortByName();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	bool GetGridInfo(int iRq, CIuGridRq& rq);
private:
	void CommonConstruct();
	const CIuGeoRawElementAccumulatorTuple* Find(int iWhich) const;
	void SortPost(CIuGeoRawElementAccumulatorTupleArray& array);
	int SortPre(CIuGeoRawElementAccumulatorTupleArray& array);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// This class really goes about things the hard way. Because of the HUGE number of instances of this class
	// which are created, we really need to limit the amount of memory which is used. We also trade of the 
	// performance of a nice map (hash table) based lookup for a simple scan.
	// This works ok because the number of elements is usually limited.
	CIuBuffer m_Buffer;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_GEORAWELEMENTACCUMULATOR_H_
