#include "StdAfx.h"
//{{Include
#include "RecordIterator.h"
#include "Data\Output.h"
#include "CdromSpec.h"
#include "resource.h"
#include "Error\Error.h"
#ifndef 	_ENGINE_RECORDFILE_H_
#	include "Engine\RecordFile.h"
#endif	// _ENGINE_RECORDFILE_H_
#include "CdromSpecConst.h"
#include "..\Version.h"
#include "OpenSpec.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRecordIterator, CIuRecordIterator_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordIterator)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDITERATOR, CIuRecordIterator, CIuRecordIterator_super)
//{{AttributeMap

	IU_ATTRIBUTE_PAGE(CIuRecordIterator, IDS_ENGINE_PPG_RECORDITERATOR, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordIterator, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRecordIterator, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_RECORDITERATOR, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordIterator, IDS_ENGINE_PROP_MAXRECORDS, GetMaxRecords, SetMaxRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordIterator, IDS_ENGINE_PROP_MAXRECORDS, IDS_ENGINE_PPG_RECORDITERATOR, -1, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuRecordIterator, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuRecordIterator, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_RECORDITERATOR, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordIterator, IDS_ENGINE_PROP_INPUT, GetInput_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuRecordIterator, IDS_ENGINE_PROP_INPUT, IDS_ENGINE_PPG_RECORDITERATOR, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuRecordIterator::CIuRecordIterator() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRecordIterator::~CIuRecordIterator()
{
	Close();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuRecordIterator::Build(CIuOutput& Output, CIuFlags Flags)
{
	// Output description, set range, etc
	if (!Output.Fire())
		return false;

	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);

	if (!Flags.Test(cdromsBuildProcess))
		return true;

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	if (!Open(Output))
		return false;

	// Process the input
	IU_TRY_ERROR
	{
		bool fResult = Process(Output, Flags);

		Close();

		if (!fResult)
			return false;
	}
	IU_CATCH_ERROR(e)
	{
		GetInput().Close();
		OnClose(Output);
		throw e;	
	}

	// Display elapsed time
	instance.Pop(true);

	return true;
}

void CIuRecordIterator::Close(CIuOutput& Output)
{
	if (!GetInput().IsOpen())
		return ;
	Output.SetMessageF("Closing");
	Output.Fire();
	GetInput().Close();
	OnClose(Output);
}

void CIuRecordIterator::Close()
{
	if (!GetInput().IsOpen())
		return ;
	CIuOutputPtr pOutput;
	pOutput.Create();
	Close(*pOutput);
}

void CIuRecordIterator::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iMaxRecords = -1;
	m_sOptions = "";
	m_sFilename = "";
	if (m_pInput.IsNull())
	{
		m_pInput.Create();
	}
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuRecordIterator::Delete(CIuOutput*)
{
	// Do not delete the input... only our outputs
}

CIuObject* CIuRecordIterator::GetInput_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pInput.Ptr()));
}

void CIuRecordIterator::OnClose(CIuOutput&)
{
}

bool CIuRecordIterator::OnOpen(CIuOpenSpec&)
{
	return true;
}

bool CIuRecordIterator::OnProcess(const CIuRecord&, CIuOutput&)
{
	return true;
}

bool CIuRecordIterator::MoveFirst(CIuOutput& Output)
{
	ASSERT(GetInput().IsOpen());

	// NOTE: A common side effect of the open command is to set the
	// message line that should be used for the remainder of the processing.
	m_iProcessRecord = 0;
	m_iProcessRecords = GetInput().GetRecords();
	m_iProcessMaxRecords = GetMaxRecords() < 0 ? 0x7FFFFFFF: GetMaxRecords();

	m_iProcessNoise = (min(m_iProcessRecords, m_iProcessRecords) + 99) / 100;
	m_iProcessNoise = min(m_iProcessNoise, 100000);
	if (m_iProcessNoise == 0)
		m_iProcessNoise = 10000;

	// Get a record count and start
	Output.SetPosition(0);
	Output.SetRange(min(m_iProcessRecords, m_iProcessRecords));
	return Output.Fire();
}

bool CIuRecordIterator::MoveNext(CIuOutput& Output, CIuRecordPtr& pRecord)
{
	if (m_iProcessRecord >= min(m_iProcessRecords, m_iProcessRecords))
		return false;

	if ((m_iProcessRecord % m_iProcessNoise) == 0)
	{
		Output.SetPosition(m_iProcessRecord);
		if (!Output.Fire(IU_EVENT_OPERATION_PROGRESS))
			return false;
	}

	if (!GetInput().Get(m_iProcessRecord, pRecord))
		return false;
	ASSERT(pRecord.NotNull());
	++m_iProcessRecord;
	return true;
}

bool CIuRecordIterator::Open(CIuOutput& Output)
{
	Close();

	// Display a title
	Output.OutputF("Processing %s\n", LPCTSTR(GetName()));
	Output.Fire();

	// Open the target
	Output.SetMessageF("Opening '%s'", LPCTSTR(GetInput().GetFullFilename()));
	Output.Fire();

	CIuOpenSpec OpenSpec;
	OpenSpec.m_pOutput = &Output;
	CIuOptions Options = GetOptions();
	OpenSpec.m_pOptions = &Options;
	GetInput().Open(OpenSpec);

	Output.SetMessageF("Opening");
	Output.Fire();
	if (!OnOpen(OpenSpec))
		return false;

	return MoveFirst(Output);
}

bool CIuRecordIterator::Process(CIuOutput& Output, CIuFlags)
{
	if (!MoveFirst(Output))
		return false;
	ASSERT(m_iProcessRecord == 0);

	// Create a record pointer
	CIuRecordPtr pRecord;
	while (MoveNext(Output, pRecord))
	{
		if (!OnProcess(*pRecord, Output))
			return false;
	}

	Output.OutputF("Processed %ld records\n", m_iProcessRecord);
	return true;
}

void CIuRecordIterator::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
	GetInput().SetFilename(pcsz);
}

void CIuRecordIterator::SetMaxRecords(int iMaxRecords)
{
	m_iMaxRecords = iMaxRecords;
}

void CIuRecordIterator::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuRecordIterator::SetSpec(CIuCdromSpec& Spec)
{
	SetName(Spec.GetName());
	GetInput().SetFilename(Spec.GetFilename());
}
