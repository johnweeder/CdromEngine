#include "stdafx.h"
//{{Include
#include "FieldList.h"
#include "RecordDef.h"
#include "EngineApp.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuFieldList, CIuFieldList_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuFieldList)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_FIELDLIST, CIuFieldList, CIuFieldList_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuFieldList, IDS_ENGINE_PPG_FIELDLIST, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldList, IDS_ENGINE_PROP_TERMINATOR, GetTerminator, SetTerminator, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldList, IDS_ENGINE_PROP_TERMINATOR, IDS_ENGINE_PPG_FIELDLIST, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldList, IDS_ENGINE_PROP_SEPARATOR, GetSeparator, SetSeparator, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldList, IDS_ENGINE_PROP_SEPARATOR, IDS_ENGINE_PPG_FIELDLIST, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldList, IDS_ENGINE_PROP_BEGIN, GetBegin, SetBegin, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldList, IDS_ENGINE_PROP_BEGIN, IDS_ENGINE_PPG_FIELDLIST, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuFieldList, IDS_ENGINE_PROP_END, GetEnd, SetEnd, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuFieldList, IDS_ENGINE_PROP_END, IDS_ENGINE_PPG_FIELDLIST, 1, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuFieldList::CIuFieldList()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuFieldList::CIuFieldList(const CIuFieldList& rFieldList)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rFieldList;
}

CIuFieldList::~CIuFieldList()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuFieldList::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sTerminator = "";
	m_sSeparator = "\t";
	m_sBegin = "";
	m_sEnd = "";
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuFieldList::Copy(const CIuObject& object)
{
	CIuFieldList_super::Copy(object);

	const CIuFieldList* pFieldList = dynamic_cast<const CIuFieldList*>(&object);
	if (pFieldList == 0 || pFieldList == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuFieldList)));
	
	m_sTerminator = pFieldList->m_sTerminator;
	m_sSeparator = pFieldList->m_sSeparator;
	m_sBegin = pFieldList->m_sBegin;
	m_sEnd = pFieldList->m_sEnd;
}

LPCTSTR CIuFieldList::Evaluate(CIuRecord* pRecord)
{
	ASSERT(IsResolved());

	if (pRecord == 0)
		return m_sTerminator;

	CIuFieldMap::Map(m_Spec, *pRecord);
	ASSERT(m_Spec.GetFields() == m_iFields);

	int iBegin = m_sBegin.GetLength();
	LPCTSTR pcszBegin = m_sBegin;
	int iEnd = m_sEnd.GetLength();
	LPCTSTR pcszEnd = m_sEnd;
	int iSeparator = m_sSeparator.GetLength();
	LPCTSTR pcszSeparator = m_sSeparator;

	m_Buffer.Empty();
	for (int iField = 0; iField < m_iFields; ++iField)
	{
		if (iBegin > 0)
			m_Buffer.Append((const BYTE*)pcszBegin, iBegin);
		int iFieldSize = m_Spec.GetFieldSize(iField);
		if (iFieldSize >= 1)
		{
			const BYTE* pbField = m_Spec.GetField(iField);
			ASSERT(pbField);
			m_Buffer.Append(pbField, iFieldSize);
		}
		if (iEnd > 0)
			m_Buffer.Append((const BYTE*)pcszEnd, iEnd);
		if (iField >= m_iFields - 1)
		{
			int iTerminator = m_sTerminator.GetLength();
			if (iTerminator > 0)
			{
				LPCTSTR pcszTerminator = m_sTerminator;
				m_Buffer.Append((const BYTE*)pcszTerminator, iTerminator);
			}
		}
		else
		{
			if (iSeparator > 0)
				m_Buffer.Append((const BYTE*)pcszSeparator, iSeparator);
		}
	}
	m_Buffer.Append((BYTE)'\0');
	return LPCTSTR(m_Buffer.GetPtr());
}

CIuFieldList& CIuFieldList::operator=(const CIuFieldList& rFieldList)
{
	Copy(rFieldList);
	return *this;
}

void CIuFieldList::SetBegin(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sBegin = pcsz;
}

void CIuFieldList::SetEnd(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sEnd = pcsz;
}

void CIuFieldList::SetSeparator(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sSeparator = pcsz;
}

void CIuFieldList::SetTerminator(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTerminator = pcsz;
}

