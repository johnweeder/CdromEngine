#ifndef _ENGINE_ADDRESSSCAN_H_ 
#define _ENGINE_ADDRESSSCAN_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_RECORDITERATOR_H_
#	include "Engine\RecordIterator.h"
#endif	// _ENGINE_RECORDITERATOR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAddressScan)
IU_DEFINE_OBJECT_PTR(CIuAddressRaw)
IU_DEFINE_OBJECT_PTR(CIuAddressCodec)
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
class CIuAddressSpec;
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAddressScan, CIuRecordIterator }}
#define CIuAddressScan_super CIuRecordIterator

class CIuAddressScan : public CIuAddressScan_super
{
//{{Declare
	DECLARE_SERIAL(CIuAddressScan)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAddressScan();
	virtual ~CIuAddressScan();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAddressCodec& GetCodec() const;
	CIuAddressRaw& GetRaw() const;
	bool ShouldAppend() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Delete(CIuOutput* pOutput = 0);
	void SetAppend(bool);
	void SetSpec(CIuAddressSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose(CIuOutput&);
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnProcess(const CIuRecord& Record, CIuOutput&);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetCodec_() const;
	CIuObject* GetRaw_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Raw address information 
	CIuAddressRawPtr m_pRaw;
	// Processor
	CIuAddressCodecPtr m_pCodec;
	// Should we append?
	bool m_fAppend;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAddressCodec& CIuAddressScan::GetCodec() const
{
	return m_pCodec.Ref();
}

inline CIuAddressRaw& CIuAddressScan::GetRaw() const
{
	return m_pRaw.Ref();
}

inline bool CIuAddressScan::ShouldAppend() const
{
	return m_fAppend;
}

#endif // _ENGINE_ADDRESSSCAN_H_
