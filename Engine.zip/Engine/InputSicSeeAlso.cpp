#include "StdAfx.h"
//{{Include
#include "InputSicSeeAlso.h"
#include "resource.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputSicSeeAlso, CIuInputSicSeeAlso_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputSicSeeAlso)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTSICSEEALSO, CIuInputSicSeeAlso, CIuInputSicSeeAlso_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputSicSeeAlso, IDS_ENGINE_PPG_INPUTSICSEEALSO, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputSicSeeAlso::CIuInputSicSeeAlso() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputSicSeeAlso::~CIuInputSicSeeAlso()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputSicSeeAlso::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input SicSeeAlso"));
	SetInputFilename("SicSeeAlso");
	SetOutputFilename("SicSeeAlso");
	SetFormat(inputSicSeeAlso);
	m_asSeeAlso.SetNoCase(true);
	m_asSeeAlso.SetDedup(true);
	//}}Initialize
}

bool CIuInputSicSeeAlso::OnProcess()
{
	int iFields = GetInputs();
	if (iFields < 2)
		return true;
	LPCTSTR pcszSicCode = GetInput(0);
	ASSERT(_tcslen(pcszSicCode) == 6);
	m_asSeeAlso.RemoveAll();
	for (int iField = 1; iField < iFields; ++iField)
	{
		LPCTSTR pcszSeeAlso = GetInput(iField);
		if (*pcszSeeAlso == '\0')
			continue;
		ASSERT(_tcslen(pcszSeeAlso) == 6);
		m_asSeeAlso.Add(pcszSeeAlso);
	}

	StringArrayAsString(m_sSeeAlso, m_asSeeAlso, '\n');

	SetField(inputFieldSicCode, pcszSicCode);
	SetField(inputFieldSeeAlso, m_sSeeAlso);
	return Output();
}
