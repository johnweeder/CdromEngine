#include "StdAfx.h"
//{{Include
#include "Address.h"
#include "AddressRaw.h"
#include "AddressCodec.h"
#include "AddressSpec.h"
#include "Element.h"
#include "resource.h"
#include "Cdrom.h"
#include "CdromSpec.h"
#include "Miscellaneous.h"
#include "Common\BigBuffer.h"
#include "Data\DataFilename.h"
#include "Error\Error.h"
#include "Data\PrefixFile.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAddress, CIuAddress_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAddress)
const	CIuVersionNumber versionAddressMax(2000,1,6,1500);
const	CIuVersionNumber versionAddressMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ADDRESS, CIuAddress, CIuAddress_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAddress, IDS_ENGINE_PPG_ADDRESS, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAddress, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuAddress, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ADDRESS, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAddress, IDS_ENGINE_PROP_STREETNAMECOUNT, GetStreetNameCount, SetStreetNameCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAddress, IDS_ENGINE_PROP_STREETNAMECOUNT, IDS_ENGINE_PPG_ADDRESS, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAddress, IDS_ENGINE_PROP_SUFFIXCOUNT, GetSuffixCount, SetSuffixCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAddress, IDS_ENGINE_PROP_SUFFIXCOUNT, IDS_ENGINE_PPG_ADDRESS, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAddress, IDS_ENGINE_PROP_ADDRESSSIZE, GetAddressSize, SetAddressSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAddress, IDS_ENGINE_PROP_ADDRESSSIZE, IDS_ENGINE_PPG_ADDRESS, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static int __cdecl FindString(const void *elem1, const void *elem2)
{
	LPCTSTR pElement1 = (LPCTSTR)elem1;
	LPCTSTR pElement2 = **(LPCTSTR**)elem2;
	return _tcsicmp(pElement1, pElement2);
}

static int __cdecl SortString(const void *elem1, const void *elem2)
{
	LPCTSTR pElement1 = **(LPCTSTR**)elem1;
	LPCTSTR pElement2 = **(LPCTSTR**)elem2;
	return _tcsicmp(pElement1, pElement2);
}

CIuAddress::CIuAddress() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAddress::CIuAddress(const CIuAddress& rAddress)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rAddress;
}

CIuAddress::~CIuAddress()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuAddress::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (Flags.Test(cdromsBuildCompressAddress))
		if (!BuildCompress(Cdrom, Output))
			return false;
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackDatabaseObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	if (Flags.Test(cdromsBuildPackDatabaseFiles))
		GetObjectRepository().PackFile(*this, Cdrom.GetPack(), &Output, GetFilename());
	return true;
}

bool CIuAddress::BuildCompress(CIuCdrom&, CIuOutput& Output)
{
	// Output description, set range, etc
	Output.OutputF("Compressing address file '%s'\n", LPCTSTR(GetFilename()));
	Output.Fire();

	// Save current progress status
	CIuOutputStateInstance instance(Output);

	Output.SetPosition(0);
	Output.SetRange(0);
	if (!Output.Fire())
		return false;

	// Be sure that this file is closed
	Close(true);

	// Load the raw token file and sort it by key
	Output.SetMessageF("Reading & Sorting");
	CIuAddressRaw Raw;
	Raw.SetFilename(GetFilename());
	Raw.Read();
	Raw.SetName(GetName());

	Output.SetMessageF("Compressing");

	CIuBigBuffer Buffer;
	Buffer.PreAllocate(256 * 1024);
	Buffer.SetGrowBy(32 * 1024);

	// See CIuBTreeCodec::CompressAddress() for explanation of this 
	// strange number of street names and suffixes which are retained
	// Do a simple compression of the suffixes
	int iSuffixes = 7 + 256;
	Raw.GetSuffixes().SortByCountDecreasing();
	if (Raw.GetSuffixes().GetSortedCount() > iSuffixes)
		Error(IU_E_ADDRESS_INVALID, _T("Number of suffixes exceeds 256+7"));
	if (!Raw.GetSuffixes().Compress(Buffer, iSuffixes, Output))
		return false;
	SetSuffixCount(iSuffixes);
									  
	if (!CompressStreetNames(Raw, Buffer, Output))
		return false;

	SetAddressSize(Buffer.GetSize());

	Output.SetMessageF("Writing");

	// Write the data to an external file
	CIuPrefixFile file;
	ASSERT(m_pObjectRepository);
	file.Create(GetObjectRepository().GetFullFilename(*this, GetFilename()), 16 * 1024, CIuFile::openCreate);
	file.SetData(*this);

	CIuFileVirtualPtr pVFile = file.Use();
	pVFile->Seek(0);
	if (Buffer.GetSize() > 0)
		pVFile->Write(Buffer.GetPtr(), Buffer.GetSize());

	// For close so that  debug checks can proceed
	pVFile.Release();
	file.Close();

	// Run a sanity check on the compressed data
	SanityCheck(Output, Raw);

	// Display elapsed time
	instance.Pop(true);

	// Return abort status
	return Output.Fire();
}

void CIuAddress::Close(bool fForce)
{
	if (m_iOpen == 0)
		return ;
	if (m_iOpen > 1 && !fForce)
	{
		--m_iOpen;
		return ;
	}
	m_iOpen = 0;
	Empty();
}

void CIuAddress::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_iOpen = 0;
	m_sFilename = "Address";
	m_pObjectRepository = 0;
	SetVersion(versionAddressMax);
	m_iStreetNameCount = 0;
	m_iSuffixCount = 0;
	m_iAddressSize = 0;
	//}}Initialize
}

bool CIuAddress::CompressStreetNames(CIuAddressRaw& Raw, CIuBuffer& Buffer, CIuOutput& Output)
{
	CIuAddressStreetNames& StreetNames = Raw.GetStreetNames();
	CIuElementCollection& Suffixes = Raw.GetSuffixes();
	// Sort the names
	StreetNames.Sort();

	// See CIuBTreeCodec::CompressAddress() for explanation of this 
	// strange number of street names and suffixes which are retained
	int iStreetNames = 65536 + 4096 + 16 - 5;
	if (iStreetNames > StreetNames.GetSortedCount())
		iStreetNames = StreetNames.GetSortedCount();

	// Press names into a buffer in decreasing count order
	// The strings are pack with two leading bytes indicating the preferred
	//	suffix and pre/post dir, followed by a null terminated street name.
	//	string

	int iStart = Buffer.GetSize();
	for (int i = 0; i < iStreetNames; ++i)
	{
		CIuAddressStreetName* pStreet = StreetNames.GetSorted(i);
		ASSERT(pStreet);

		//Output.OutputF(_T("%s|%s|%s|%s|%d\n"),
		//		pStreet->m_pcszStreetName,
		//		pStreet->m_pcszSuffix,
		//		pStreet->m_pcszPreDir,
		//		pStreet->m_pcszPostDir,
		//		pStreet->m_iCount);

		int iPreDir = CIuAddressCodec::FindDir(pStreet->m_pcszPreDir);
		ASSERT(iPreDir >= 0 && iPreDir < 16);
		int iPostDir = CIuAddressCodec::FindDir(pStreet->m_pcszPostDir);
		ASSERT(iPostDir >= 0 && iPostDir < 16);

		BYTE bDir = BYTE(BYTE((iPreDir & 0x0F) << 4) | BYTE(iPostDir & 0x0F));
		Buffer.Append(&bDir, sizeof(bDir));

		// NOTE: Suffix 0xFF implies no default suffix
		int iSuffix = Suffixes.FindSorted(pStreet->m_pcszSuffix);
		BYTE bSuffix;
		if (iSuffix < 0 || iSuffix > 0xFE)
			bSuffix = 0xFF;
		else
			bSuffix = BYTE(iSuffix);
		Buffer.Append(&bSuffix, sizeof(bSuffix));

		LPCTSTR pcszStreetName = pStreet->m_pcszStreetName;
		Buffer.Append((const BYTE*)pcszStreetName, _tcslen(pcszStreetName) + 1);
	}

	SetStreetNameCount(iStreetNames);

	// Output description, set range, etc
	int iEnd = Buffer.GetSize();
	Output.OutputF("Compressed %d elements in %d bytes\n", iStreetNames, iEnd - iStart);
	return Output.Fire();
}

void CIuAddress::Copy(const CIuObject& object)
{
	CIuAddress_super::Copy(object);

	const CIuAddress* pAddress = dynamic_cast<const CIuAddress*>(&object);
	if (pAddress == 0 || pAddress == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuAddress)));
	
	m_sFilename = pAddress->m_sFilename;
	m_iAddressSize = pAddress->m_iAddressSize;
	m_iStreetNameCount = pAddress->m_iStreetNameCount;
	m_iSuffixCount = pAddress->m_iSuffixCount;
}

int CIuAddress::DeCompressStreetNames(const BYTE* pb, int cb, CArray<LPCTSTR, LPCTSTR>& aStrings, int iStrings)
{
	const BYTE* pbStart = pb;

	ASSERT(iStrings >= 0);
	ASSERT(iStrings >= 0);
	aStrings.SetSize(iStrings);

	for (int i = 0; i < iStrings && cb > 0; ++i)
	{
		if (cb < 3)
			Error(IU_E_ELEMENT_INVALID, _T("Expected additional elements decompressing street name information"));

		pb += 2;
		cb -= 2;

		aStrings.SetAt(i, LPCTSTR(pb));

		for (;*pb != 0 && cb > 0; ++pb, --cb)
			/* null */ ;
		if (*pb == 0 && cb > 0)
		{
			++pb;
			--cb;
		}
	}

	if (i != iStrings)
		Error(IU_E_ELEMENT_INVALID, _T("Expected additional elements decompressing street name information"));

	// Returns number of bytes consumed
	return pb - pbStart;
}

void CIuAddress::Delete(CIuOutput* pOutput)
{
	ASSERT(!IsOpen());
	CdromDelete(GetFullFilename(), pOutput);
	// Empty this object as a way of cleaning up un-needed memory
	Empty();
}

void CIuAddress::Empty()
{
	ASSERT(!IsOpen());
	m_Buffer.Destroy();
	m_aStreetNames.SetSize(0);
	m_aStreetNamesSorted.SetSize(0);
	m_aSuffixes.SetSize(0);
	m_aSuffixesSorted.SetSize(0);
}

int CIuAddress::FindStreetName(LPCTSTR pcszStreetName, int iSuffix) const
{
	if (m_aStreetNames.GetSize() <= 0)
		return -1;
	if (m_aStreetNames.GetSize() != m_aStreetNamesSorted.GetSize())
	{
		m_aStreetNamesSorted.SetSize(m_aStreetNames.GetSize());
		for (int iStreetName = 0; iStreetName < m_aStreetNames.GetSize(); ++iStreetName)
		{
			LPCTSTR* ppcszStreetName = &m_aStreetNames.ElementAt(iStreetName);
			m_aStreetNamesSorted.SetAt(iStreetName, ppcszStreetName);
		}
		qsort(m_aStreetNamesSorted.GetData(), m_aStreetNamesSorted.GetSize(), sizeof(LPCTSTR*), SortString);
	}

	ASSERT(AfxIsValidString(pcszStreetName));
	LPCTSTR** pppcszStreetName = (LPCTSTR**)bsearch(pcszStreetName, m_aStreetNamesSorted.GetData(), m_aStreetNamesSorted.GetSize(), sizeof(LPCTSTR*), FindString);
	if (pppcszStreetName == 0)
		return -1;

	LPCTSTR** pppcszStreetNamesSorted0 = &m_aStreetNamesSorted.ElementAt(0);
	int iSortedIndex = pppcszStreetName - pppcszStreetNamesSorted0;
	ASSERT(iSortedIndex >= 0 && iSortedIndex < m_aStreetNamesSorted.GetSize());
	ASSERT(_tcsicmp(pcszStreetName, *m_aStreetNamesSorted[iSortedIndex]) == 0);

	// At this point, we have matched the street. But we would also like to match the suffix
	// if possible.
	// Move back to first matching street
	for (; iSortedIndex > 0; --iSortedIndex)
	{
		if (_tcsicmp(pcszStreetName, *m_aStreetNamesSorted[iSortedIndex - 1]) != 0)
			break;
	}
	for (int iScan = iSortedIndex; iScan < m_aStreetNamesSorted.GetSize(); ++iScan)
	{
		LPCTSTR pcszStreetNameSorted = *m_aStreetNamesSorted[iScan];
		if (_tcsicmp(pcszStreetName, pcszStreetNameSorted) != 0)
			break;
		pcszStreetNameSorted -= 1;
		int iThisSuffix = int(*pcszStreetNameSorted);
		if (iThisSuffix == 0xFF)
			iThisSuffix = -1;
		if (iThisSuffix == iSuffix)
		{
			iSortedIndex = iScan;
			pppcszStreetName = &m_aStreetNamesSorted.ElementAt(iSortedIndex);
			ASSERT(iSortedIndex >= 0 && iSortedIndex < m_aStreetNamesSorted.GetSize());
			ASSERT(_tcsicmp(pcszStreetName, *m_aStreetNamesSorted[iSortedIndex]) == 0);
			break;			
		}
	}

	// Compute index via the original unsorted array
	LPCTSTR* ppcszStreetName0 = &m_aStreetNames.ElementAt(0);
	int iIndex = (*pppcszStreetName) - ppcszStreetName0;
	ASSERT(iIndex >= 0 && iIndex < m_aStreetNames.GetSize());
	ASSERT(_tcsicmp(pcszStreetName, m_aStreetNames[iIndex]) == 0);

	return iIndex;
}

int CIuAddress::FindSuffix(LPCTSTR pcszSuffix) const
{
	if (m_aSuffixes.GetSize() <= 0)
		return -1;
	if (m_aSuffixes.GetSize() != m_aSuffixesSorted.GetSize())
	{
		m_aSuffixesSorted.SetSize(m_aSuffixes.GetSize());
		for (int iSuffix = 0; iSuffix < m_aSuffixes.GetSize(); ++iSuffix)
		{
			LPCTSTR* ppcszSuffix = &m_aSuffixes.ElementAt(iSuffix);
			m_aSuffixesSorted.SetAt(iSuffix, ppcszSuffix);
		}
		qsort(m_aSuffixesSorted.GetData(), m_aSuffixesSorted.GetSize(), sizeof(LPCTSTR*), SortString);
	}

	ASSERT(AfxIsValidString(pcszSuffix));
	LPCTSTR** pppcszSuffix = (LPCTSTR**)bsearch(pcszSuffix, m_aSuffixesSorted.GetData(), m_aSuffixesSorted.GetSize(), sizeof(LPCTSTR*), FindString);
	if (pppcszSuffix == 0)
		return -1;

	// Compute index via the original unsorted array
	LPCTSTR* ppcszSuffix0 = &m_aSuffixes.ElementAt(0);
	int iIndex = (*pppcszSuffix) - ppcszSuffix0;
	ASSERT(iIndex >= 0 && iIndex < m_aSuffixes.GetSize());
	ASSERT(_tcsicmp(pcszSuffix, m_aSuffixes[iIndex]) == 0);
	return iIndex;
}

CString CIuAddress::GetFilename() const
{
	return m_sFilename.IsEmpty() ? GetName(): m_sFilename;
}

CString CIuAddress::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

int CIuAddress::GetStreetNamePostDir(int iStreetName) const
{
	const BYTE* pb = (const BYTE*)m_aStreetNames[iStreetName];
	pb -= 2;
	return int((*pb) & 0x0F);
}

int CIuAddress::GetStreetNamePreDir(int iStreetName) const
{
	const BYTE* pb = (const BYTE*)m_aStreetNames[iStreetName];
	pb -= 2;
	return int((*pb) >> 4);
}

int CIuAddress::GetStreetNameSuffix(int iStreetName) const
{
	const BYTE* pb = (const BYTE*)m_aStreetNames[iStreetName];
	pb -= 1;
	int iSuffix = int(*pb);
	if (iSuffix == 0xFF)
		return -1;
	else
		return iSuffix;
}

CIuVersionNumber CIuAddress::GetVersionMax() const
{
	return versionAddressMax;
}

CIuVersionNumber CIuAddress::GetVersionMaxStatic()
{
	return versionAddressMax;
}

CIuVersionNumber CIuAddress::GetVersionMin() const
{
	return versionAddressMin;
}

CIuVersionNumber CIuAddress::GetVersionMinStatic()
{
	return versionAddressMin;
}

void CIuAddress::Open()
{
	if (m_iOpen > 0)
	{
		++m_iOpen;
		return ;
	}

	Close(true);

#ifdef _DEBUG
	time_t timeStart = time(0);
#endif

	m_iOpen = 1;

	if (!HasObjectRepository())
		Error(IU_E_NO_REPOSITORY);

	// Open the file and read in the tokens as one large block
	CIuPrefixFilePtr pFile;
	CIuFileVirtualPtr pVFile;
	CRC32 crc;
	GetObjectRepository().Use(*this, pFile, pVFile, GetFilename(), 0, &crc);

	// Read...
	if (pVFile->GetLength() != GetAddressSize())
		Error(IU_E_ADDRESS_INVALID, _T("Invalid size for address information."));
	m_Buffer.SetGrowBy(4 * 1024);
	m_Buffer.SetSize(GetAddressSize());

	pVFile->Read(m_Buffer.GetPtr(), m_Buffer.GetSize());

	CRC32 crcActual = crc32(m_Buffer.GetPtr(), m_Buffer.GetSize());
	if (crc != 0 && crc != crcActual)
		Error(IU_E_ADDRESS_INVALID, _T("Invalid CRC code for address information"));

	// The format is
	//	Suffixes
	//		Count (CIuInt32)
	//		n zero terminated strings (sorted by decreasing count)
	//	Street Names
	//		Count (CIuInt32)
	//		n zero terminated strings (sorted by decreasing count) with two leading bytes
	const BYTE* pb = m_Buffer.GetPtr();
	int cb = m_Buffer.GetSize();

	int iSuffixCount = GetSuffixCount();
	int cbSuffixes = CIuElementCollection::DeCompress(pb, cb, m_aSuffixes, iSuffixCount);
	ASSERT(cbSuffixes > 0);
	cb -= cbSuffixes;
	pb += cbSuffixes;

	int iStreetNameCount = GetStreetNameCount();
	int cbStreetNames = DeCompressStreetNames(pb, cb, m_aStreetNames, iStreetNameCount);
	ASSERT(cbStreetNames > 0);
	pb += cbStreetNames;
	cb -= cbStreetNames;

	if (cb != 0)
		Error(IU_E_ADDRESS_INVALID, _T("Unexpected data decompressing address information."));

#ifdef _DEBUG
	time_t timeNow = time(0);
	int iElapsed = timeNow - timeStart;
	TRACE("OPEN: Address '%s' expanded %d street names and %d suffixes from %d bytes in %d seconds.\n",
		LPCTSTR(GetName()), GetStreetNameCount(), GetSuffixCount(), GetAddressSize(), iElapsed);
#endif
}

CIuAddress& CIuAddress::operator=(const CIuAddress& rAddress)
{
	Copy(rAddress);
	return *this;
}

void CIuAddress::SanityCheck(CIuOutput& Output, CIuAddressRaw& Raw)
{
	// franchise codes must be in ascending order....
	Output.OutputF("Validating address file '%s'\n", LPCTSTR(GetName()));
	Output.Fire();

	// Save current progress status
	CIuOutputStateInstance Progress(Output);

	Output.SetMessageF("Opening file %s\n", LPCTSTR(GetName()));
	Output.Fire();

	CIuAddress File;
	File = *this;
	File.SetObjectRepository(m_pObjectRepository);
	File.Open();

	if (File.GetAddressSize() != GetAddressSize())
		Error(IU_E_ADDRESS_INVALID, _T("Compressed data sizes do not match."));
	if (File.GetStreetNameCount() != GetStreetNameCount())
		Error(IU_E_ADDRESS_INVALID, _T("Street name counts do not match."));
	if (File.GetSuffixCount() != GetSuffixCount())
		Error(IU_E_ADDRESS_INVALID, _T("Suffix counts do not match."));
	if (File.GetVersion() != GetVersion())
		Error(IU_E_ADDRESS_INVALID, _T("Versions do not match."));

	int iSuffixes = File.GetSuffixCount();
	Output.SetRange(iSuffixes);
	Output.SetPosition(0);
	Output.Fire();
	for (int iSuffix = 0; iSuffix < iSuffixes; ++iSuffix)
	{
		if ((iSuffix % ((iSuffixes + 99) / 100)) == 0)
		{
			Output.SetPosition(iSuffix);
			if (!Output.Fire())
				return ;
		}

		LPCTSTR pcszSuffix1 = File.GetSuffix(iSuffix);

		CIuElement* pElement = Raw.GetSuffixes().GetSorted(iSuffix);
		if (pElement == 0)
		{
			CString sDebug;
			sDebug.Format(_T("Invalid raw address element @ %ld."), iSuffix);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}

		LPCTSTR pcszSuffix3 = pElement->GetName();
		if (_tcscmp(pcszSuffix1, pcszSuffix3) != 0)
		{
			CString sDebug;
			sDebug.Format(_T("Address does not match raw address @ %ld.\n%s\n%s"), iSuffix, pcszSuffix1, pcszSuffix3);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}

		int iFind = File.FindSuffix(pcszSuffix1);
		if (iFind < 0)
		{
			CString sDebug;
			sDebug.Format(_T("Suffix not found @ %ld.\n%s"), iSuffix, pcszSuffix1);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}
		if (iFind != iSuffix)
		{
			CString sDebug;
			sDebug.Format(_T("Found suffix does not match @ %ld.\n%s"), iSuffix, pcszSuffix1);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}
	}

	// Save current progress status
	int iStreetNames = File.GetStreetNameCount();
	Output.SetRange(iStreetNames);
	Output.SetPosition(0);
	Output.Fire();
	for (int iStreetName = 0; iStreetName < iStreetNames; ++iStreetName)
	{
		if ((iStreetName % ((iStreetNames + 99) / 100)) == 0)
		{
			Output.SetPosition(iStreetName);
			if (!Output.Fire())
				return ;
		}

		LPCTSTR pcszStreetName1 = File.GetStreetName(iStreetName);

		CIuAddressStreetName* pElement = Raw.GetStreetNames().GetSorted(iStreetName);
		if (pElement == 0)
		{
			CString sDebug;
			sDebug.Format(_T("Invalid raw address element @ %ld."), iStreetName);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}

		LPCTSTR pcszStreetName3 = pElement->m_pcszStreetName;
		if (_tcscmp(pcszStreetName1, pcszStreetName3) != 0)
		{
			CString sDebug;
			sDebug.Format(_T("Address does not match raw address @ %ld.\n%s\n%s"), iStreetName, pcszStreetName1, pcszStreetName3);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}

		int iSuffix = File.GetStreetNameSuffix(iStreetName);
		int iFind = File.FindStreetName(pcszStreetName1, iSuffix);
		if (iFind < 0)
		{
			CString sDebug;
			sDebug.Format(_T("Street name not found @ %ld.\n%s"), iStreetName, pcszStreetName1);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}
		if (iFind != iStreetName)
		{
			CString sDebug;
			sDebug.Format(_T("Found street name does not match @ %ld.\n%s"), iStreetName, pcszStreetName1);
			Error(IU_E_ADDRESS_INVALID, LPCTSTR(sDebug));
		}
	}
}

void CIuAddress::SetAddressSize(int iAddressSize)
{
	m_iAddressSize = iAddressSize;
}

void CIuAddress::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAddress::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuAddress::SetSpec(CIuAddressSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());
	SetFilename(Spec.GetCdrom().GetFilename());
}

void CIuAddress::SetStreetNameCount(int iStreetNameCount)
{
	m_iStreetNameCount = iStreetNameCount;
}

void CIuAddress::SetSuffixCount(int iSuffixCount)
{
	m_iSuffixCount = iSuffixCount;
}
