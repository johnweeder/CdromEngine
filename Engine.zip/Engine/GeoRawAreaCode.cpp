#include "StdAfx.h"
//{{Include
#include "GeoRawAreaCode.h"
#include "resource.h"
#include "GeoRawInstance.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawAreaCode, CIuGeoRawAreaCode_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawAreaCode)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWAREACODE, CIuGeoRawAreaCode, CIuGeoRawAreaCode_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_STRING(CIuGeoRawAreaCode, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuGeoRawAreaCode, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_GEORAWELEMENT, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawAreaCode, IDS_ENGINE_PROP_STATE, GetState_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawAreaCode, IDS_ENGINE_PROP_STATE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuGeoRawAreaCode, IDS_ENGINE_PROP_ZIPS, GetZips_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuGeoRawAreaCode, IDS_ENGINE_PROP_ZIPS, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawAreaCode::CIuGeoRawAreaCode() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
}

CIuGeoRawAreaCode::~CIuGeoRawAreaCode()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawAreaCode::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance& Instance, CIuOutput&)
{
	GetState().Add(Instance.GetStateAbbr());
	GetZips().Add(Instance.GetZip());
	CIuGeoRawAreaCode_super::Another();
}

CIuObject* CIuGeoRawAreaCode::GetState_() const
{
	return &m_State;
}

CIuObject* CIuGeoRawAreaCode::GetZips_() const
{
	return &m_Zips;
}

void CIuGeoRawAreaCode::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_sTitle;
	}
	else
	{
		ar >> m_sTitle;
	}
	GetState().Serialize(ar);
	GetZips().Serialize(ar);
	CIuGeoRawAreaCode_super::Serialize(ar);
}

void CIuGeoRawAreaCode::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}
