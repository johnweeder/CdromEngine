#include "stdafx.h"
//{{Include
#include "RecordDef.h"
#include "Select.h"
#include "RecordDefSpec.h"
#include "FieldDefs.h"
#include "FieldDef.h"
#include "Record.h"
#include "Data\Archive.h"
#include "resource.h"
#include "Data\resource.h"
#include "Common\Buffer.h"
#include "Data\DataFilename.h"
#include "RecordFile.h"
#include "FieldName.h"
#include "Data\Output.h"
#include "Error\Error.h"
#include "Common\String.h"
#include "Expression.h"
#include "FieldMap.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Implement
IMPLEMENT_SERIAL(CIuRecordDef, CIuRecordDef_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuRecordDef)
const	CIuVersionNumber versionRecordDefMax(2000,1,5,304);
const	CIuVersionNumber versionRecordDefMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RECORDDEF, CIuRecordDef, CIuRecordDef_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_INT(CIuRecordDef, IDS_ENGINE_PROP_RECORDLENGTH, GetRecordLength, SetRecordLength, 0)

	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordDef, IDS_ENGINE_PROP_FIELDDEFS, GetFieldDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuRecordDef, IDS_ENGINE_PROP_KEYDEF, GetKeyDef_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_ADJUST, ActionAdjust, 0)
	IU_ATTRIBUTE_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_LOADFROMRECORDDEF, ActionLoadFromRecordDef, 0)
	IU_ATTRIBUTE_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_LOADFROMRECORDFILE, ActionLoadFromRecordFile, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuRecordDef, IDS_ENGINE_PROP_FIELDDEFS, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuRecordDef, IDS_ENGINE_PROP_KEYDEF, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuRecordDef, IDS_ENGINE_PPG_RECORDDEF, 50, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuRecordDef, IDS_ENGINE_PROP_RECORDLENGTH, IDS_ENGINE_PPG_RECORDDEF, 1, INT_MAX, 0)

	IU_ATTRIBUTE_EDITOR_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_ADJUST, IDS_ENGINE_PPG_RECORDDEF, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_LOADFROMRECORDDEF, IDS_ENGINE_PPG_RECORDDEF, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuRecordDef, IDS_ENGINE_ACTION_LOADFROMRECORDFILE, IDS_ENGINE_PPG_RECORDDEF, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIuRecordDef

CIuRecordDef::CIuRecordDef()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRecordDef::CIuRecordDef(const CIuRecordDef& rRecordDef)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rRecordDef;
}

CIuRecordDef::~CIuRecordDef()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuRecordDef::ActionAdjust(const CIuPropertyCollection&, CIuOutput&)
{
	Adjust();
	return CString("Success");
}

CString CIuRecordDef::ActionLoadFromRecordDef(const CIuPropertyCollection& Collection, CIuOutput&)
{
	CString sFilename = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	LoadFromRecordDef(sFilename);
	return CString("Success");
}

CString CIuRecordDef::ActionLoadFromRecordFile(const CIuPropertyCollection& Collection, CIuOutput&)
{
	CString sFilename = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	LoadFromRecordFile(sFilename);
	return CString("Success");
}

int CIuRecordDef::AddFieldDef(LPCTSTR pcszDef)
{
	return GetFieldDefs().AddFieldDef(pcszDef);
}

int CIuRecordDef::AddFieldDef(CIuFieldDefSpec& spec)
{
	return GetFieldDefs().AddFieldDef(spec);
}

void CIuRecordDef::AddFieldDefs(CStringArray& as)
{
	for (int i = 0; i < as.GetSize(); ++i)
		AddFieldDef(as[i]);
}

void CIuRecordDef::AddFieldDefs(CIuFieldMap& Map)
{
	CStringArray asFields;
	Map.GetFields(asFields);
	AddFieldDefs(asFields);
	CStringArray asKeys;
	Map.GetKeys(asKeys);
	AddFieldDefs(asKeys);
}

void CIuRecordDef::Adjust()
{
	OnAdjust();
}

void CIuRecordDef::Append(const CIuRecordDef& RecordDef, const CIuRecordDef* pRecordDefMaster)
{
	// All of the fields in recordDef are appended to this.
	// NOTE: pRecordDefMaster is considered the "master" field definition set. If a field is found in "recordDef"
	//	and also in pRecordDefMaster, then the field def from the master set will be utilized.
	int iFields = RecordDef.GetFieldDefs().GetCount();
	for (int iField = 0; iField < iFields; ++iField)
		AppendFieldDef(RecordDef.GetFieldDefs().Get(iField), pRecordDefMaster);
}

void CIuRecordDef::AppendFieldDef(const CIuFieldDef& FieldDefSrc, const CIuRecordDef* pRecordDefMaster)
{
	// NOTE: pRecordDefMaster is considered the "master" field definition set. If a field is found in "recordDef"
	//	and also in pRecordDefMaster, then the field def from the master set will be utilized.
	// This function is used to create the output record definition.
	// Copy field def if found. Otherwise, create a new one
	CString sName = FieldDefSrc.GetName();
	ASSERT(!sName.IsEmpty());

	// Field can not already exist
	if (GetFieldDefs().Exists(sName))
		Error(IU_E_DUPLICATE_FIELD, LPCTSTR(sName));

	// Add a field
	int iDst = GetFieldDefs().Add();

	// Check if the field existed previously, if so, copy it
	// Otherwise, copy the def which was passed in
	int iSrc = -1;
	if (pRecordDefMaster)
		iSrc = pRecordDefMaster->GetFieldDefs().Find(sName);
	if (iSrc >= 0)
		GetFieldDefs().Get(iDst).Copy(pRecordDefMaster->GetFieldDefs().Get(iSrc));
	else
		GetFieldDefs().Get(iDst).Copy(FieldDefSrc);
}

void CIuRecordDef::Clear()
{
	CIuRecordDef_super::Clear();
	CIuRecordDef::CommonConstruct();
	GetFieldDefs().RemoveAll();
	GetKeyDef().Clear();
}

void CIuRecordDef::CommonConstruct()
{
	//{{Initialize
	if (m_pFieldDefs.IsNull())
	{
		m_pFieldDefs.Create();
	}
	if (m_pKeyDef.IsNull())
	{
		m_pKeyDef.Create();
	}
	m_iRecordLength = 1;
	SetName(_T("RecordDef"));
	SetVersion(versionRecordDefMax);
	//}}Initialize
}

void CIuRecordDef::Copy(const CIuObject& object)
{
	CIuRecordDef_super::Copy(object);

	const CIuRecordDef* pRecordDef = dynamic_cast<const CIuRecordDef*>(&object);
	if (pRecordDef == 0 || pRecordDef == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuRecordDef)));
	
	GetKeyDef() = pRecordDef->GetKeyDef();
	GetFieldDefs() = pRecordDef->GetFieldDefs();
	SetRecordLength(pRecordDef->GetRecordLength());
}

void CIuRecordDef::CreateDefaultKeyDef() 
{
	GetKeyDef().Clear();
	// Create a normal, single key'd def
	if (GetFieldDefs().GetCount() >= 1)
		GetKeyDef().AddWidth(-1);
}

CIuObject* CIuRecordDef::GetFieldDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pFieldDefs.Ptr()));
}

void CIuRecordDef::GetFields(CStringArray& as) const
{
	GetFieldDefs().GetCollectionNames(as);
}

void CIuRecordDef::GetFields(LPCTSTR pcsz, CStringArray& as)
{
	IU_TRY_ERROR
	{
		CIuRecordDef recordDef;
		ASSERT(AfxIsValidString(pcsz));
		recordDef.LoadFromRecordDef(pcsz);
		recordDef.GetFields(as);
	}
	IU_CATCH_ERROR(e)
	{
		e->Delete();
		as.RemoveAll();
	}
}

CIuObject* CIuRecordDef::GetKeyDef_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pKeyDef.Ptr()));
}

int CIuRecordDef::GetMaxLength() const
{
	int iLength = 0;
	int iFields = GetFieldDefs().GetCount();
	for (int iField = 0; iField < iFields; ++iField)
		iLength += GetFieldDefs().Get(iField).GetLength();
	return iLength;
}

CIuVersionNumber CIuRecordDef::GetVersionMax() const
{
	return versionRecordDefMax;
}

CIuVersionNumber CIuRecordDef::GetVersionMaxStatic()
{
	return versionRecordDefMax;
}

CIuVersionNumber CIuRecordDef::GetVersionMin() const
{
	return versionRecordDefMin;
}

CIuVersionNumber CIuRecordDef::GetVersionMinStatic()
{
	return versionRecordDefMin;
}

void CIuRecordDef::LoadFromRecordDef(LPCTSTR pcsz)
{
	CIuFilename filename;
	if (pcsz)
		filename = pcsz;
	CIuRecordDef recordDef;
	if (filename.IsEmpty())
	{
		CString sFilter = IuDataFilenameFilter(extDataObject, &recordDef);
		CString sExt = IuDataFilenameExt(extDataObject, &recordDef);
		if (!filename.Query(0, 0, sExt, sFilter, 0))
			return ;
	}
	else
		filename = IuDataFilenameSearch(filename, extDataObject, this);
	SerializeFromFileEx(filename, this);
}

void CIuRecordDef::LoadFromRecordFile(LPCTSTR pcsz)
{
	CIuFilename filename;
	if (pcsz)
		filename = pcsz;
	if (filename.IsEmpty())
	{
		CIuRecordFile rawRecordFile;
		CString sFilter = IuDataFilenameFilter(extDataPrefix, &rawRecordFile);
		CString sExt = IuDataFilenameExt(extDataPrefix, &rawRecordFile);
		if (!filename.Query(0, 0, sExt, sFilter, 0))
			return ;
	}
	else
		filename = IuDataFilenameSearch(filename, extDataPrefix, this);

	// Do this the hard way... we don't actually want to read any data
	CIuPrefixFile file;
	file.Open(filename);
	file.GetData(this);
}

void CIuRecordDef::OnAdjust()
{
	// This is a virtual function used by special record def types to "validate" a record
	// definition. For example, a fixed length record might adjust the fields so that they
	// don't overlap.
	GetFieldDefs().Adjust();

	// Verify record length. Increase the record length if necessary to accomodate
	// all the fields.
	int iLength = 1;
	int iFields = GetFieldDefs().GetCount();
	for (int iField = 0; iField < iFields; ++iField)
	{
		int iFieldLength = GetFieldDefs().Get(iField).GetLength();
		int iFieldOffset = GetFieldDefs().Get(iField).GetOffset();
		iLength = max(iLength, iFieldOffset + iFieldLength);
	}
	if (iLength > GetRecordLength())
		SetRecordLength(iLength);
}

CIuRecordDef& CIuRecordDef::operator=(const CIuRecordDef& rRecordDef)
{
	Copy(rRecordDef);
	return *this;
}

void CIuRecordDef::SetSpec(LPCTSTR apcszOutput[])
{
	// Poor man's way of creating a record def from an array of
	// strings with a null terminator.
	//	static LPCTSTR apcszOutput[] =
	//	{
	//		"=Name(30)",
	//		0
	//	};
	// Set up a record definitions
	Clear();
	int iRecordLength = 0;
	for (int iField = 0; apcszOutput[iField]; ++iField)
	{
		LPCTSTR pcsz = apcszOutput[iField];
		AddFieldDef(pcsz);

		CIuFieldDef& Field = GetFieldDefs().Get(iField);
		if (Field.GetOffset() == 0 && iField != 0)
			Field.SetOffset(iRecordLength);
		iRecordLength = max(iRecordLength, Field.GetOffset() + Field.GetLength());
	}

	SetRecordLength(iRecordLength);

	Adjust();

	GetKeyDef().Clear();

	// Create a normal, single key'd def
	if (GetFieldDefs().GetCount() >= 1)
		GetKeyDef().AddWidth(-1);
}

void CIuRecordDef::SetSpec(int iSpec)
{
	CIuRecordDefSpec RecordDefSpec;
	if (!RecordDefSpec.FromNo(iSpec))
	{
		ASSERT(false);
		return ;
	}
	SetSpec(RecordDefSpec);
}

void CIuRecordDef::SetSpec(CIuRecordDefSpec& RecordDefSpec)
{
	// This function is over-loaded to support supplying various "default" object definitions.
	// For example, record defs may support various well known internal formats.
	if (RecordDefSpec.GetLength() > 0)
		SetRecordLength(RecordDefSpec.GetLength());

	GetFieldDefs().SetSpec(RecordDefSpec);

	int iRecordLength = 0;
	for (int iField = 0; iField < GetFieldDefs().GetCount(); ++iField)
	{
		CIuFieldDef& Field = GetFieldDefs().Get(iField);

		iRecordLength = max(iRecordLength, Field.GetOffset() + Field.GetLength());
	}

	if (RecordDefSpec.GetLength() < 0)
		SetRecordLength(iRecordLength);

	Adjust();

	GetKeyDef().Clear();

	// Create a normal, single key'd def
	if (GetFieldDefs().GetCount() >= 1)
		GetKeyDef().AddWidth(-1);
}

void CIuRecordDef::SetRecordLength(int iLength)
{
	m_iRecordLength = max(1, iLength);
}


