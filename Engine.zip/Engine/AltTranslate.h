#ifndef _ENGINE_ALTTRANSLATE_H_
#define _ENGINE_ALTTRANSLATE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltTranslate)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltTranslate, CIuObjectNamed }}
#define CIuAltTranslate_super CIuObjectNamed

class CIuAltTranslate : public CIuAltTranslate_super
{
/////////////////////////////////////////////////////////////////////////////
// When alternate records are added to the compressed records, the mapping of
// record no's to expanded records is thrown off. This class is used to 
// translate back to the correct record no.

//{{Declare
	DECLARE_SERIAL(CIuAltTranslate)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltTranslate();
	virtual ~CIuAltTranslate();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	CString GetFilename() const;
	CIuFilename GetFullFilename() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Append(DWORD dwRecordNo);
	virtual void Clear();
	void Delete(CIuOutput* pOutput);
	void Empty();
	void Read();
	void SetFilename(LPCTSTR);
	void Translate(CDWordArray& adw);
	DWORD Translate(DWORD dwRecordNo) const;
	void Write() const;
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionRead(const CIuPropertyCollection& collection, CIuOutput&);
	CString ActionWrite(const CIuPropertyCollection& collection, CIuOutput&);
	void Serialize(CArchive& ar);
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// This array contains a sorted list of positions at which 
	// "see also" records were inserted. Basically, you must offset
	// the input record no by the position in the array in order to get the
	// record no in the compressed file.
	// This information is serialized to the external prefix file.
	CDWordArray m_adwInsertNo;
	// This is other information
	CString m_sFilename;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuAltTranslate::GetFilename() const
{
	return m_sFilename;
}

#endif // _ENGINE_ALTTRANSLATE_H_
