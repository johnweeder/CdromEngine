#include "StdAfx.h"
//{{Include
#include "ExpressionLiteral.h"
#include "Interop\Conversions.h"
#include "Common\String.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionLiteral::CIuExpressionLiteral(LPCTSTR pcsz) : CIuExpressionElement(exprStringLiteral)
{
	SetFormat(exprFormatString);
	m_iLiteral = 0;
	if (pcsz)
		SetLiteral(pcsz);
}

CIuExpressionLiteral::CIuExpressionLiteral(const CIuExpressionLiteral& rExpressionElement)
{
	*this = rExpressionElement;
}

CIuExpressionLiteral::~CIuExpressionLiteral()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionLiteral::Clone() const
{
	CIuExpressionLiteral* pElement = new CIuExpressionLiteral(*this);
	ASSERT(pElement);
	return pElement;
} 

LPCTSTR CIuExpressionLiteral::Evaluate(const CIuRecord*) const
{
	ASSERT(GetChildCount() == 0);
	ASSERT(GetType() == exprStringLiteral);
	return m_sBuffer;
}

bool CIuExpressionLiteral::EvaluateBool(const CIuRecord*) const
{
	ASSERT(GetChildCount() == 0);
	ASSERT(GetType() == exprStringLiteral);
	return m_iLiteral != 0;
}

int CIuExpressionLiteral::EvaluateInt(const CIuRecord*) const
{
	ASSERT(GetChildCount() == 0);
	ASSERT(GetType() == exprStringLiteral);
	return m_iLiteral;
}

int CIuExpressionLiteral::GetMaxLength() const
{
	return m_sBuffer.GetLength();
}

LPCTSTR CIuExpressionLiteral::GetTypeName() const
{
	switch (GetType())
	{
		case exprStringLiteral:
			return "#String Literal#";
	}
	return CIuExpressionLiteral_super::GetTypeName();
}

bool CIuExpressionLiteral::IsConst() const
{
	return true;
}

bool CIuExpressionLiteral::IsKindOf(CIuExpressionType Type) const
{
	// This type is always a valid expression
	return CIuExpressionLiteral_super::IsKindOf(Type);
}

CIuExpressionLiteral& CIuExpressionLiteral::operator=(const CIuExpressionLiteral& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CIuExpressionLiteral_super::operator=(rExpressionElement);
	m_iLiteral = rExpressionElement.m_iLiteral;
	return *this;
}

void CIuExpressionLiteral::SetLiteral(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sBuffer = pcsz;
	m_iLiteral = StringAsInt(pcsz);
	if (IsNumeric(m_sBuffer))
		SetFormat(exprFormatInt);
	else
		SetFormat(exprFormatString);
}

void CIuExpressionLiteral::SetLiteral(int iLiteral)
{
	m_iLiteral = iLiteral;
	IntAsString(m_sBuffer, m_iLiteral);
	SetFormat(exprFormatInt);
}
