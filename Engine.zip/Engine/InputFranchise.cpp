#include "StdAfx.h"
//{{Include
#include "InputFranchise.h"
#include "Error\Error.h"
#include "Data\DataFilename.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputFranchise, CIuInputFranchise_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputFranchise)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTFRANCHISE, CIuInputFranchise, CIuInputFranchise_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputFranchise, IDS_ENGINE_PPG_INPUTFRANCHISE, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputFranchise::CIuInputFranchise() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputFranchise::~CIuInputFranchise()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputFranchise::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input Franchise"));
	SetInputFilename("PFran.");
	SetOutputFilename("Franchise");
	SetFormat(inputFranchise);
	//}}Initialize
}

void CIuInputFranchise::Delete(CIuOutput* pOutput)
{
	CIuInputFranchise_super::Delete(pOutput);
	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	CdromDelete(FilenameOutput, pOutput);
}

void CIuInputFranchise::OnClose()
{
	m_FileInput.Close();
	m_FileOutput.Close();
	CIuInputFranchise_super::OnClose();
}

bool CIuInputFranchise::OnMoveNext()
{
	if (!m_FileInput.ReadString(m_sInput))
		return false;

	if (m_sInput.GetLength() < 6)
		return true;

	m_sSicCode = m_sInput.Mid(0, 6);
	m_sSicCode.TrimRight();
	m_sSicCode.MakeUpper();
	if (m_sSicCode.GetLength() != 6)
	{
		TRACE("WARNING: Invalid franchise SIC code '%s'\n", LPCTSTR(m_sSicCode));
		return true;
	}

	m_sFranchiseCode = m_sInput.Mid(51, 1);
	m_sFranchiseCode.TrimRight();
	if (m_sFranchiseCode.IsEmpty())
		return true;

	m_sFranchiseName = m_sInput.Mid(52, 40);
	m_sFranchiseName.TrimRight();
	m_sFranchiseName.MakeUpper();
	if (m_sFranchiseName.IsEmpty())
		return true;

	ClearFields();
	SetField(inputFieldSicCode, m_sSicCode);
	SetField(inputFieldFranchiseCode, m_sFranchiseCode);
	SetField(inputFieldFranchiseName, m_sFranchiseName);

	return Output();
}

bool CIuInputFranchise::OnOutput()
{
	// Just to be nice, we dump a text file version of the output
	m_sOutput = _T("\"");
	m_sOutput += GetField(inputFieldSicCode);
	m_sOutput += _T("\",\"");
	m_sOutput += GetField(inputFieldFranchiseCode);
	m_sOutput += _T("\",\"");
	m_sOutput += GetField(inputFieldFranchiseName);
	m_sOutput += _T("\"\n");

	m_FileOutput.WriteString(m_sOutput);

	return CIuInputFranchise_super::OnOutput();
}

bool CIuInputFranchise::OnOpen(CIuOpenSpec& OpenSpec)
{
	if (!CIuInputFranchise_super::OnOpen(OpenSpec))
		return false;

	CIuFilename FilenameInput = GetFullInputFilename();
	if (!FilenameInput.Exists())
	{
		GetOutput().OutputF(_T("*** WARNING: Franchise master file, %s, not found\n"), LPCTSTR(FilenameInput));
		return false;
	}
	m_FileInput.Open(FilenameInput, CFile::modeRead|CFile::shareDenyNone|CFile::typeText);

	CIuFilename FilenameOutput = IuDataFilenameSearch(GetOutputFilename(), ".txt");
	m_FileOutput.Open(FilenameOutput, CFile::modeCreate|CFile::modeReadWrite|CFile::shareExclusive|CFile::typeText);

	return true;
}
