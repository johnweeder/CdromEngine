#include "StdAfx.h"
//{{Include
#include "GeoZip.h"
#include "GeoRawZip.h"
#include "Zip.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "LatLongDistance.h"
#include "Error\Error.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoZip, CIuGeoZip_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoZip)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOZIP, CIuGeoZip, CIuGeoZip_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoZip::CIuGeoZip() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoZip::~CIuGeoZip()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}


void CIuGeoZip::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoZIP"));
	//}}Initialize
}

LPCTSTR CIuGeoZip::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoZip::GetIndexStatic()
{
	return _T("ZIP");
}

void CIuGeoZip::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefZip);
}

int CIuGeoZip::GetSourceType() const
{
	return sourceGeoCollectionZip;
}

void CIuGeoZip::GetZipList(int iZip, CIuGeoList& GeoList) const
{
	GeoList.Add(iZip, iZip);
}

int CIuGeoZip::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawZip& Zip = *dynamic_cast<CIuGeoRawZip*>(&Element);
	ASSERT(&Zip);

	int iExpandedSize = sizeof(CIuZip);
	ASSERT(iExpandedSize == 60);

	CString sName = Zip.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLatitude()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLatitudeMin()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLatitudeMax()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLongitude()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLongitudeMin()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetLongitudeMax()), Buffer);

	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetMedianHomeValue()), Buffer);
	CIuNybbleInt::AppendUIntCompressed(DWORD(Zip.GetMedianIncome()), Buffer);

	Zip.GetMsa().CompressPreferred(Geo, Buffer, Geo.GetMsaMap());
	Zip.GetAreaCode().CompressPreferred(Geo, Buffer, Geo.GetAreaCodeMap());
	Zip.GetCounty().CompressPreferred(Geo, Buffer, Geo.GetCountyMap());
	Zip.GetCity().CompressPreferred(Geo, Buffer, Geo.GetCityMap());
	Zip.GetState().CompressPreferred(Geo, Buffer, Geo.GetStateMap());

	// See notes in BTreeCodec.cpp for why we store 6 prefixes...
	int iPrefixes = Zip.GetPrefix().CompressPreferred(Geo, Buffer, 6, true);
	iExpandedSize += (iPrefixes + 1) * sizeof(WORD);

	return iExpandedSize;
}

int CIuGeoZip::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuZip* pZip = (CIuZip*)AddElement(sizeof(CIuZip));

	// Decompress the various strings
	CIuStaticBuffer256 BufferZip;
	iOffset += CIuNybbleString::Get(BufferZip, -1, true, NS_ALPHA, Buffer, iOffset);

	unsigned int uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_Latitude = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_LatitudeMin = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_LatitudeMax = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_Longitude = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_LongitudeMin = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_LongitudeMax = uiVal;

	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iMedianHomeValue = uiVal;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iMedianIncome = uiVal;

	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iMsaNo = int(uiVal) - 1;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iAreaCodeNo = int(uiVal) - 1;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iCountyNo = int(uiVal) - 1;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iCityNo = int(uiVal) - 1;
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	pZip->m_iStateNo = int(uiVal) - 1;

	// Decompress the prefix list
	// Note that this will invalidate the pElement pointer
	iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
	WORD wPrefixes = WORD(uiVal);
	AddElementData((const BYTE*)&wPrefixes, sizeof(wPrefixes));

	for (WORD w = 0; w < wPrefixes; ++w)
	{
		iOffset += CIuNybbleInt::GetUIntCompressed(uiVal, Buffer, iOffset);
		WORD wPrefix = WORD(uiVal);
		AddElementData((const BYTE*)&wPrefix, sizeof(wPrefix));
	}

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferZip.GetPtr()));
	AddElementStringTerm();

	return iOffset;
}

bool CIuGeoZip::Request(CString& sResult, const CStringArray& as)
{
	CString sRequest = as[0];
	if (sRequest.CompareNoCase("FromLatLong") == 0)
	{
		if (as.GetSize() < 3)
			Error(IU_E_REQUEST_FAILED, _T("Latitude and longitude expected in FromLatLong request."));

		CIuLatLongCoordinate Coord(as[1], as[2]);

		if (!Coord.IsValid())
			return  CString();

		sResult = "";
		CIuLatLongDistance MinDistance ;

		int iZips = GetCount();
		for (int iZip = 0; iZip < iZips; ++iZip)
		{
			const CIuZip& Zip = Get(iZip);
			CIuLatLongCoordinate Centroid = Zip.GetCentroid();

			if (!Centroid.IsValid())
				continue;

			CIuLatLongDistance ThisDistance = Centroid - Coord;

			if (sResult.IsEmpty() || ThisDistance < MinDistance)
			{
				sResult = Zip.GetName();
				MinDistance = ThisDistance;
			}
		}
		return !sResult.IsEmpty();
	}

	return CIuGeoZip_super::Request(sResult, as);
}

bool CIuGeoZip::Within(CString& sKeys, const CIuLatLongCoordinate& Coord1, const CIuLatLongCoordinate& Coord2) 
{
	sKeys = "";

	ASSERT(Coord1 <= Coord2);
	ASSERT(Coord2 >= Coord1);

	bool fSequence = false;
	CString sLastInSequence;

	int iZips = GetCount();
	for (int iZip = 0; iZip < iZips; ++iZip)
	{
		const CIuZip& Zip = Get(iZip);
		CIuLatLongCoordinate CoordMin = Zip.GetCoordMin();
		CIuLatLongCoordinate CoordMax = Zip.GetCoordMax();
		ASSERT(CoordMin <= CoordMax);
		ASSERT(CoordMax >= CoordMin);

		if (!((Coord1 >= CoordMin && Coord1 <= CoordMax) ||(Coord2 >= CoordMin && Coord2 <= CoordMax)))
		{
			if (fSequence && !sLastInSequence.IsEmpty())
			{
				sKeys += _T("-");
				sKeys += sLastInSequence;
			}

			sLastInSequence = _T("");
			fSequence = false;
			continue;
		}

		TRACE("MATCH %s: %s <%s>-<%s> %s\n", Zip.GetName(), CoordMin.AsString(), Coord1.AsString(), Coord2.AsString(), CoordMax.AsString());
		TRACE("MATCH %s %s\n", Zip.GetLatitude().AsString(), Zip.GetLongitude().AsString());

		if (fSequence)
		{
			sLastInSequence = Zip.GetName();
			continue;
		}

		if (!sKeys.IsEmpty())
			sKeys += _T(",");

		sKeys += Zip.GetName();
		fSequence = true;
	}

	if (fSequence && !sLastInSequence.IsEmpty())
	{
		sKeys += _T("-");
		sKeys += sLastInSequence;
	}

	return !sKeys.IsEmpty();	
}

