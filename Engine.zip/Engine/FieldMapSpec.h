#ifndef _ENGINE_FIELDMAPSPEC_H_
#define _ENGINE_FIELDMAPSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuFieldMapSpec)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuFieldMapSpec, CIuObjectNamed }}
#define CIuFieldMapSpec_super CIuObjectNamed

class CIuFieldMapSpec : public CIuFieldMapSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuFieldMapSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuFieldMapSpec();
	virtual ~CIuFieldMapSpec();
	CIuFieldMapSpec(const CIuFieldMapSpec&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddField(LPCTSTR, int iBefore = -1);
	int AddKey(LPCTSTR, int iBefore = -1);
	static int GetCount();
	CString GetField(int) const;
	int GetFieldCount() const;
	void GetFields(CStringArray& as) const;
	CString GetKey(int) const;
	int GetKeyCount() const;
	void GetKeys(CStringArray& as) const;
	static void GetNames(CStringArray& as);
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
	bool FromIndex(int iIndex);
	bool FromName(LPCTSTR pcszName);
	bool FromNo(int iSpec);
	void RemoveAllFields();
	void RemoveAllKeys();
	void RemoveField(int);
	void RemoveKey(int);
	void SetField(int, LPCTSTR);
	void SetFields(const CStringArray&);
	void SetKey(int, LPCTSTR);
	void SetKeys(const CStringArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuFieldMapSpec& operator=(const CIuFieldMapSpec&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CStringArray m_asFields;
	CStringArray m_asKeys;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CString CIuFieldMapSpec::GetField(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetFieldCount());
	return m_asFields[iWhich];
}

inline int CIuFieldMapSpec::GetFieldCount() const
{
	return m_asFields.GetSize();
}

inline CString CIuFieldMapSpec::GetKey(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetKeyCount());
	return m_asKeys[iWhich];
}

inline int CIuFieldMapSpec::GetKeyCount() const
{
	return m_asKeys.GetSize();
}

#endif // _ENGINE_FIELDMAPSPEC_H_
