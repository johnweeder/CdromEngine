#ifndef _ENGINE_FIELDDEFSPECDFT_H_
#define _ENGINE_FIELDDEFSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// CIuFieldDefSpecDft

struct CIuFieldDefSpecDft
{
public:
	static int Find(LPCTSTR pcszFieldDef);
	static int Find(int iFieldDef);
	static const CIuFieldDefSpecDft* Get(int iWhich);
	static int GetCount();
	static CString Resolve(CIuFieldDefSpecDft& FieldDefSpecDft);

public:
	// The name of this default value
	// For example, we may have two different "City" fields...
	// The spec name would be different, but the field name might be the same
	LPCTSTR m_pcszFieldDef;
	// Field def specifier
	int m_iFieldDef;

	// The "actual" name of the field for the FieldDef
	// Several defaults may be for fields with an actual name of "ZIP"
	//		for instance. However, each default must have a unique ID.
	// If the name starts with an equal sign, the actual name and 
	//		all null parameters are pulled from the record whose ID matches
	//		the name.
	// For example, there may be several ways to generate a name (first/last, company, etc), 
	//		but the the definition of a name field is always the same.
	// If null, the id is used
	LPCTSTR m_pcszName;
	// If null, the name is used
	LPCTSTR m_pcszShortName;
	// If null, the short name is used
	LPCTSTR m_pcszLongName;
	// A descrption of the field
	LPCTSTR m_pcszDescription;
	// The expression used to create field (if any). 
	LPCTSTR m_pcszExpression;
	//	Various miscellaneous options. This can include flags, bought level, offset, etc.
	// Basically, anything which might be used by a field def, export field def or report
	//		def can be stuffed in here.
	LPCTSTR m_pcszOptions;
	// The default length (this is often over-ridden)
	int m_iLength;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_FIELDDEFSPECDFT_H_
