#include "StdAfx.h"
//{{Include
#include "GeoRawElement.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoRawElement, CIuGeoRawElement_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoRawElement)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEORAWELEMENT, CIuGeoRawElement, CIuGeoRawElement_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuGeoRawElement, IDS_ENGINE_PPG_GEORAWELEMENT, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuGeoRawElement, IDS_ENGINE_PROP_COUNT, GetCount, SetCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuGeoRawElement, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_GEORAWELEMENT, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoRawElement::CIuGeoRawElement() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	//{{Initialize
	m_iCount = 0;
	//}}Initialize
}

CIuGeoRawElement::~CIuGeoRawElement()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoRawElement::Another(const CIuGeoRawElementCollection&, const CIuGeoRawInstance&, CIuOutput&)
{
	ASSERT(false);
	// Derived class must do a Another()
}

void CIuGeoRawElement::Another()
{
	++m_iCount;
}

void CIuGeoRawElement::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_sName;
		ar << m_iCount;
	}
	else
	{
		ar >> m_sName;
		ar >> m_iCount;
	}
}

void CIuGeoRawElement::SetCount(int iCount)
{
	m_iCount = iCount;
}

void CIuGeoRawElement::SetName(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sName = pcsz;
}
