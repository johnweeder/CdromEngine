#include "stdafx.h"
#include "ExportDefaultDlg.h"
#include "Export.h"
#include "Engine.h"
#include "ExportDefs.h"
#include "ExportDefaultAdvancedDlg.h"
#include "Common\Options.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
 

//{{Implement
BEGIN_MESSAGE_MAP(CIuExportDefaultDlg, CIuExportDefaultDlg_super)
	//{{AFX_MSG_MAP(CIuExportDefaultDlg)
	ON_BN_CLICKED(IDC_ENGINE_ADVANCED, OnAdvanced)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuExportDefaultDlg::CIuExportDefaultDlg(CWnd* pParent /*=NULL*/) : CIuExportDefaultDlg_super(CIuExportDefaultDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuExportDefaultDlg)
	m_bAppend = false;
	m_bHeader = false;
	m_nSelected = -1;
	//}}AFX_DATA_INIT
}

void CIuExportDefaultDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuExportDefaultDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuExportDefaultDlg)
	DDX_Control(pDX, IDC_ENGINE_FORMAT, m_Format);
	DDX_Check(pDX, IDC_ENGINE_APPEND, m_bAppend);
	DDX_Check(pDX, IDC_ENGINE_HEADER, m_bHeader);
	DDX_Radio(pDX, IDC_ENGINE_ALL, m_nSelected);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuExportDefaultDlg::ExportDlg(CIuExport& export, CWnd* pParent)
{
	CIuExportDefaultDlg dlg(pParent);
	dlg.m_pExport = &export;
	return (dlg.DoModal() == IDOK);
}

bool CIuExportDefaultDlg::GetAppendFlag()
{
	return m_bAppend;
}

CString CIuExportDefaultDlg::GetExportDef() const
{
	return m_sFormat;
}

CString CIuExportDefaultDlg::GetFileName() const
{
	return m_sFileName;
}

bool CIuExportDefaultDlg::GetHeaderFlag()
{
	return m_bHeader;
}

int CIuExportDefaultDlg::GetSelected()
{
	return m_nSelected;
}

void CIuExportDefaultDlg::InitializeDlgMembers()
{
	ASSERT(m_pExport.NotNull());

	CIuExport &export = GetExport();

	m_EditFilename.Initialize(IDC_ENGINE_FILENAME, this);

	SetFileName(export.GetFilename());
	m_EditFilename.SetWindowText(GetFileName());

	CIuOptions options = export.GetOptions();

	SetAppendFlag(options.FindValueAsBool(IDS_ENGINE_PROP_APPEND, false));
	SetHeaderFlag(options.FindValueAsBool(IDS_ENGINE_PROP_HEADER, false));
	SetSelected(options.FindValueAsInt(IDS_ENGINE_PROP_SELECTED, -1));
	SetExportDef(export.GetExportDef());

	// Initialize Combo Box
	CIuExportDefs &exportDefs = export.GetEngine().GetExportDefs();
	int iCount = exportDefs.GetCount();

	for (int i=0; i<iCount; i++)
	{
		int iIndex = m_Format.AddString(exportDefs.Get(i).GetName());
		m_Format.SetItemData(iIndex, i);
	}

	m_Format.InsertString(iCount, "Create New Format");
	m_Format.SetItemData(iCount, iCount);

	if (GetExportDef().IsEmpty() || m_Format.FindString(-1, GetExportDef()) == CB_ERR)
		m_Format.SetCurSel(0);
	else
		m_Format.SetCurSel(m_Format.FindString(-1, GetExportDef()));

	UpdateData(false);
}

void CIuExportDefaultDlg::OnAdvanced() 
{
	CIuExportDefaultAdvancedDlg dlg(this);

	dlg.SetUniversalArray(m_asUniversal);		//First, provide the initial
	dlg.SetDefaultArray(m_asDefault);			//values for the Advanced
	dlg.SetSelectedArray(m_asSelected);			//Dialog
	
	dlg.SetBought(GetBought());
	dlg.SetOrderByArray(GetOrderByArray());
	dlg.SetDistinctArray(GetDistinctArray());

	if (IDOK == dlg.DoModal())
	{
		SetOrderByArray(dlg.GetOrderByArray());	//and, now retrieve them
		SetDistinctArray(dlg.GetDistinctArray());
		SetBought(dlg.GetBought());
	}
}

BOOL CIuExportDefaultDlg::OnInitDialog() 
{
	CIuExportDefaultDlg_super::OnInitDialog();
	InitializeDlgMembers();
	
	return true;  
}

void CIuExportDefaultDlg::OnOK() 
{
	UpdateData(true);

	CString sFilename;
	m_EditFilename.GetWindowText(sFilename);
	if (sFilename.IsEmpty())
	{
		AfxMessageBox("Please select a file name for export");
		return;
	}
	else
		SetFileName(sFilename);
	
	CString sTemp;
	m_Format.GetLBText(m_Format.GetCurSel(), sTemp);
	SetExportDef(sTemp);

	//Save Settings
	CIuOptions options;
	options.Add(IDS_ENGINE_PROP_APPEND, GetAppendFlag());
	options.Add(IDS_ENGINE_PROP_HEADER, GetHeaderFlag());
	options.Add(IDS_ENGINE_PROP_SELECTED, GetSelected());

	CIuExport &export = GetExport();
	export.SetOptions(options.Get());
	export.SetFilename(GetFileName());
	export.SetExportDef(GetExportDef());
	export.Save();

	CIuExportDefaultDlg_super::OnOK();
}

void CIuExportDefaultDlg::SetAppendFlag(bool bVal)
{
	m_bAppend = bVal;
}

void CIuExportDefaultDlg::SetExportDef(const CString sExportDef)
{
	ASSERT(AfxIsValidString(sExportDef));
	m_sFormat = sExportDef;
}

void CIuExportDefaultDlg::SetFileName(const CString sFileName)
{
	ASSERT(AfxIsValidString(sFileName));
	m_sFileName = sFileName;
	m_EditFilename.SetInitialFileName(sFileName);
}

void CIuExportDefaultDlg::SetHeaderFlag(bool bVal)
{
	m_bHeader = bVal;
}

void CIuExportDefaultDlg::SetSelected(int index)
{
	m_nSelected = index;
}

void CIuExportDefaultDlg::SetDefaultArray(const CStringArray &asDefault)
{
	if (m_asDefault.GetSize() > 0)
		m_asDefault.RemoveAll();

	m_asDefault.Copy(asDefault);
}

void CIuExportDefaultDlg::SetSelectedArray(const CStringArray &asSelected)
{
	if (m_asSelected.GetSize() > 0)
		m_asSelected.RemoveAll();

	m_asSelected.Copy(asSelected);
}

void CIuExportDefaultDlg::SetUniversalArray(const CStringArray &asUniversal)
{
	if (m_asUniversal.GetSize() > 0)
		m_asUniversal.RemoveAll();

	m_asUniversal.Copy(asUniversal);
}

CString CIuExportDefaultDlg::GetBought() const
{
	return m_sBought;
}

void CIuExportDefaultDlg::SetBought(const CString sBought)
{
	ASSERT(AfxIsValidString(sBought));
	m_sBought = sBought;
}

const CStringArray& CIuExportDefaultDlg::GetOrderByArray() const
{
	return m_asOrderBy;
}

void CIuExportDefaultDlg::SetOrderByArray(const CStringArray &asOrderBy)
{
	if (m_asOrderBy.GetSize() > 0)
		m_asOrderBy.RemoveAll();

	m_asOrderBy.Copy(asOrderBy);
}

const CStringArray& CIuExportDefaultDlg::GetDistinctArray() const
{
	return m_asDistinct;
}

void CIuExportDefaultDlg::SetDistinctArray(const CStringArray &asDistinct)
{
	if (m_asDistinct.GetSize() > 0)
		m_asDistinct.RemoveAll();

	m_asDistinct.Copy(asDistinct);
}
