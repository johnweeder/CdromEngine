#ifndef _ENGINE_RELEASENOTESPECDFT_H_
#define _ENGINE_RELEASENOTESPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Descriptions for the various ReleaseNoteernate record files
struct CIuReleaseNoteSpecDft
{
public:
	static int Find(LPCTSTR pcszReleaseNote);
	static int Find(int iReleaseNote);
	static const CIuReleaseNoteSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszReleaseNote;
	int m_iReleaseNote;
	LPCTSTR m_pcszReleaseCurrent;
	LPCTSTR m_pcszReleaseMin;
	LPCTSTR m_pcszNotes;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_RELEASENOTESPECDFT_H_
