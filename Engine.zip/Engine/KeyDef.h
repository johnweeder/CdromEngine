#ifndef _ENGINE_KEYDEF_H_
#define _ENGINE_KEYDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuKeyDef)
IU_DEFINE_OBJECT_PTR(CIuFieldMap)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuKeyDef, CIuObject }}
#define CIuKeyDef_super CIuObject

class CIuKeyDef : public CIuKeyDef_super
{
//{{Declare
	DECLARE_SERIAL(CIuKeyDef)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuKeyDef();
	CIuKeyDef(const CIuKeyDef&);
	virtual ~CIuKeyDef();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetCount() const;
	void GetWidths(CIntArray& al) const;
	bool IsSimple() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void AddWidth(int iWidth = -1);
	virtual void Clear();
	bool Compare(const CIuKeyDef& KeyDef);
	virtual void Copy(const CIuObject& object);
	void CreateFromMap(const CIuFieldMap& keyMap);
	void CreateFromMapFields(const CIuFieldMap& keyMap);
	void SetWidths(const CIntArray&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuKeyDef& operator=(const CIuKeyDef&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void CreateFromMap_(const CIuFieldMap& keyMap, int iFirst, int iCount);
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuKey;
	// Width of each key element (needed to right justify)
	// A width of -1 implies that a field is left justified.
	// A width greater than zero causes the field to be left padded with spaces 
	// up to the specified width.
	CIntArray m_aiWidths;
	// A "simple" keydef is one where all the width are -1.
	// In other words, all fields are left justified
	bool m_fSimple;
	static const TCHAR m_szSpaces[];
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuKeyDef::GetCount() const
{
	return m_aiWidths.GetSize();
}

inline bool CIuKeyDef::IsSimple() const
{
	return m_fSimple;
}

#endif // _ENGINE_KEYDEF_H_
