#include "StdAfx.h"
//{{Include
#include "RegExCompare.h"
#include "RegEx.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
// Tokens used by the comparator
const BYTE regExTokenCharMin		= 0x20;	// The minimum char value accepted
const BYTE regExTokenCharMax		= 0x7E;	// The maximum char value accepted
const BYTE regExTokenHiVal			= 0xFF;	// A token represent a hival (greater than any character)
														// An empty string represents loval 

const BYTE regExTokenKeySeparator= 0x00;	// Separator for key values. Must be zero

														// These are all terminators
const BYTE regExTokenRange			= 0x01;	// ~
const BYTE regExTokenEndSubExpr	= 0x02;	// End of a sub expression
const BYTE regExTokenEndExpr		= 0x03;	// End of parsed expression
														// This marks the final byte in a regEx

														// These are leading indicators for a sub expression
const BYTE regExTokenNot			= 0x04;	// -
const BYTE regExTokenPhonetic		= 0x05;	// %

														// These are wildcarding operators
const BYTE regExTokenAnyOne		= 0x07;	// ?
const BYTE regExTokenZeroOrMore	= 0x08;	//	*, except at the end of a string
const BYTE regExTokenRemainder	= 0x09;	// This was a star which appeared at the end of a sub-expression
														// We use a different token for performance reasons.

// NOTES:
//	The entire tokenized expression will always end with a regExTokenEndExpr.
// Each term and/or hi/lo range will always end with a regExTokenEndSubExpr.
 
//}}Implement

CIuRegExCompare::CIuRegExCompare() 
{
	Clear();
}

CIuRegExCompare::CIuRegExCompare(const CIuRegEx& RegEx)
{
	Create(RegEx);
}

CIuRegExCompare::CIuRegExCompare(const CIuRegEx& RegEx, int iTerm)
{
	Create(RegEx, iTerm);
}

CIuRegExCompare::~CIuRegExCompare()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRegExCompare::Append(BYTE b)
{
	// Avoid putting regExZeroOrMore/regExRemainder together.
	// '**' sequences are redundant.
	int iSize = m_Tokens.GetSize();
	if (iSize == 0)
	{
		m_Tokens.Append(&b, sizeof(b));
		return ;	
	}

	// Get the last byte
	BYTE bLast = m_Tokens[iSize - 1];
	if (bLast == regExTokenZeroOrMore || bLast == regExTokenRemainder)
	{
		if (b == regExTokenEndSubExpr)
		{
			// Optimization
			// Convert '{*}{null}' to '{remainder}{null}'
			m_Tokens[iSize - 1] = regExTokenRemainder;
		}
		else if (b == regExTokenRemainder)
		{
			m_Tokens[iSize - 1] = regExTokenRemainder;
			return ;
		}
		else if (b == regExTokenZeroOrMore)
		{
			// Convert '{*}{*}' to '{*}'
			return ;
		}
	}

	// Just append it...
	m_Tokens.Append(&b, sizeof(b));
}

void CIuRegExCompare::Append(LPCTSTR pcsz, int iFlags)
{
	bool fEmpty = (*pcsz == '\0');
	// A "within" is implements by doing a "*A*" pattern regEx.
	// Obviously, this can be very poorly performing.
	// "Within" on an empty expression is not allowed
	if ((iFlags & (regExHasTermWithin|regExHasGlobalWithin)) != 0 && !fEmpty)
		Append(regExTokenZeroOrMore);

	// Build the tokens for the sub-expression
	// The expression is assumed to be "well-formed"
	for (; *pcsz; ++pcsz)
	{
		if (*pcsz == '*')
			Append(regExTokenZeroOrMore);
		else if (*pcsz == '?')
			Append(regExTokenAnyOne);
		else if (*pcsz == '\\')
		{
			++pcsz;
			ASSERT(*pcsz);
			if (*pcsz == 't')
				Append(regExTokenKeySeparator);
			else
				Append(BYTE(*pcsz));
		}
		else
			Append(BYTE(*pcsz));
	}

	// Complete the "within" and/or wildcard all logic 
	// Except on an empty expression.
	if ((iFlags & (regExHasTermWithin|regExHasGlobalWithin|regExHasGlobalWildcard)) != 0 && !fEmpty)
		Append(regExTokenZeroOrMore);

	// Terminate with a null.
	Append(regExTokenEndSubExpr);
}

void CIuRegExCompare::Append(const CIuRegEx& RegEx, int iTerm)
{
	ASSERT(iTerm >= 0 && iTerm < RegEx.GetTerms());

	CString sLo, sHi;
	int iFlags = RegEx.GetTerm(iTerm, sLo, sHi);

	if ((iFlags & (regExHasTermNot|regExHasGlobalNot)) != 0)
		Append(regExTokenNot);

	if ((iFlags & (regExHasTermPhonetic|regExHasGlobalPhonetic)) != 0)
		Append(regExTokenPhonetic);

	Append(sLo, iFlags);

	if ((iFlags & regExHasTermRange) != 0)
	{
		Append(regExTokenRange);
		if (sHi.IsEmpty())
			Append(regExTokenHiVal);
		else
			Append(sHi, iFlags);
	}
}

void CIuRegExCompare::Clear()
{
	// Clear current tokens
	m_Tokens.Destroy();
	m_Tokens.PreAllocate(256);
	ASSERT(regExExact == regExYes);
	// This is a sanity check to make sure hival is greater than loval
	ASSERT(regExTokenHiVal > 0);
}

int CIuRegExCompare::Compare(LPCTSTR pcsz) const
{
	// Strings are assumed to be null terminated.
	// Strings with embedded nulls (index keys) must
	// have had those null converts to a index separator 
	//	(currently a '\t').
	ASSERT(AfxIsValidString(pcsz));
	const BYTE* pbValue = (const BYTE*)pcsz;
	const BYTE* pbPattern = m_Tokens;

	bool fNotAll = true;
	for (int iTerm = 0; *pbPattern != regExTokenEndExpr; ++iTerm)
	{
		bool fNot = false;
		if (*pbPattern == regExTokenNot)
		{
			fNot = true;
			++pbPattern;
		}
		else
		{
			fNotAll = false;
		}
		// Phonetic regExing
		if (*pbPattern == regExTokenPhonetic)
		{
			++pbPattern;
#pragma __TODO("CIuRegExCompare::Compare(): regExTokenPhonetic")
			bool fResult = false;
			if (!fNot && fResult)
				return regExYes;
			else if (fNot && fResult)
				return regExNo;

			// Skip over present term
			while (*pbPattern != regExTokenEndSubExpr)
				++pbPattern;
			++pbPattern;
		}
		// RegEx string comparator
		else
		{
			int iResult1 = CompareTerm(pbValue, pbPattern);

			// Skip over present term
			while (*pbPattern != regExTokenEndSubExpr)
				++pbPattern;
			++pbPattern;

			if (iResult1 == regExLT)
			{
				// If <, skip over range if present
				if (*pbPattern == regExTokenRange)
				{
					++pbPattern;
					while (*pbPattern != regExTokenEndSubExpr)
						++pbPattern;
					++pbPattern;
				}

				// Special case: 1 term, not negated and less <
				if (iTerm == 0 && !fNot && *pbPattern == regExTokenEndExpr)
					return regExLT;
			}
			else
			{
				ASSERT(iResult1 == regExExact || iResult1 == regExPartial || iResult1 == regExGT);
				if (*pbPattern == regExTokenRange)
				{
					++pbPattern;
					int iResult2 = CompareTerm(pbValue, pbPattern);

					// Skip over the term
					while (*pbPattern != regExTokenEndSubExpr)
						++pbPattern;
					++pbPattern;

					if (iResult2 == regExExact || iResult2 == regExPartial || iResult2 == regExLT)
					{
						if (fNot)
							return regExNo;
						else
							return regExYes;
					}
					ASSERT(iResult2 == regExGT);

					// Special case: 1 term, not negated and greater than
					if (iTerm == 0 && !fNot && *pbPattern == regExTokenEndExpr)
						return regExGT;
				}
				else if (iResult1 == regExExact || iResult1 == regExPartial)
				{
					if (fNot)
						return regExNo;
					else
						return regExYes;
				}
				else if (iResult1 == regExGT)
				{
					// Special case: 1 term, not negated and greater than
					if (iTerm == 0 && !fNot && *pbPattern == regExTokenEndExpr)
						return regExGT;
				}
			}
		}
	}
	return fNotAll ? regExYes: regExNo;
}

int CIuRegExCompare::CompareTerm(const BYTE* pbValue, const BYTE* pbPattern) const
{
	// Compare a term in an expression. A term always ends with a
	// regExTokenEndSubExpr token. If is not necessary for the pattern to 
	// match the regExTokenEndSubExpr token
	for (;;)
	{
		if (*pbPattern == regExTokenEndSubExpr)
		{
			// Matched exactly to end of string
			if (*pbValue == 0)
				return regExExact;
			// Pattern at an end, stuff remains in the value string
			else 
				return regExGT;
		}
		// Match remainder of string as a wildcard
		else if (*pbPattern == regExTokenRemainder)
		{
			if (*pbValue == 0)
				return regExExact;
			else 
				return regExPartial;
		}
		// Match exactly one character (it must exist)
		else if (*pbPattern == regExTokenAnyOne)
		{
			if (*pbValue == 0)
				return regExLT;
			++pbValue;
			++pbPattern;
		}
		else if (*pbPattern == regExTokenZeroOrMore)
		{
			// Keep going through the string character by character seeing if we can find a regExToken.
			// NOTE: Search for things like 'A*B*C*D' can get real ugly performance-wise
			++pbPattern;

			if (*pbPattern >= regExTokenCharMin && *pbPattern <= regExTokenCharMax)
			{
				// This is a small optimization for the common case where the next character following the '*' is a 
				// literal. We do an inline search for the next regExing literal. 
				// NOTE: This is a greedy heuristic.
				while (*pbValue)
				{
					while (*pbValue && *pbPattern != (BYTE)_totupper(*pbValue))
						++pbValue;
					int iResult = CompareTerm(pbValue, pbPattern);
					if (iResult == regExExact || iResult == regExPartial)
						return iResult;
				}
			}
			else
			{
				// This is the full blown match... potentially very slow!
				for (; *pbValue; ++pbValue)
				{
					int iResult = CompareTerm(pbValue, pbPattern);
					if (iResult == regExExact || iResult == regExPartial)
						return iResult;
				}
			}

			// Always return -1 (value < pattern) even though the result is undefined.
			return regExLT;
		}

		ASSERT((*pbPattern >= regExTokenCharMin && *pbPattern <= regExTokenCharMax) || *pbPattern == regExTokenKeySeparator);

		// Value ended but there is still stuff in the pattern
		if (*pbValue == 0)
			return regExLT;
		// Check index separator
		else if (*pbPattern == regExTokenKeySeparator)
		{
			if (*pbValue == regExTokenKeySeparator)
			{
				++pbValue;
				++pbPattern;
				continue;
			}
			return regExGT;
		}
		// Otherwise, just compare the literal characters
		else
		{
			BYTE bValue = (BYTE)_totupper(*pbValue);
			if (bValue < *pbPattern)
				return regExLT;
			else if (bValue > *pbPattern)
				return regExGT;
			++pbValue;
			++pbPattern;
		}
	}
}

void CIuRegExCompare::Create(const CIuRegEx& RegEx)
{
	Clear();
	int iTerms = RegEx.GetTerms();
	for (int iTerm = 0; iTerm < iTerms; ++iTerm)
		Append(RegEx, iTerm);
	Append(regExTokenEndExpr);
}

void CIuRegExCompare::Create(const CIuRegEx& RegEx, int iTerm)
{
	Clear();
	Append(RegEx, iTerm);
	Append(regExTokenEndExpr);
}

void CIuRegExCompare::Dump() const
{
#ifdef _DEBUG
	int iSize = m_Tokens.GetSize();

	TRACE("TOKENS %03d: [", iSize);

	for (int i = 0; i < iSize; ++i)
	{
		BYTE bVal = m_Tokens[i];
		switch (bVal)
		{
			case regExTokenEndSubExpr:
				TRACE("{endsub}");
				break;
			case regExTokenEndExpr:
				TRACE("{end}");
				break;
			case regExTokenNot:
				TRACE("{not}");
				break;
			case regExTokenPhonetic:
				TRACE("{phonetic}");
				break;
			case regExTokenRange:
				TRACE("{range}");
				break;
			case regExTokenAnyOne:
				TRACE("{one}");
				break;
			case regExTokenZeroOrMore:
				TRACE("{zero/more}");
				break;
			case regExTokenRemainder:
				TRACE("{remainder}");
				break;
			case regExTokenHiVal:
				TRACE("{hival}");
				break;
			case regExTokenKeySeparator:
				TRACE("{keysep}");
				break;
			default:
				if (bVal >= regExTokenCharMin && bVal <= regExTokenCharMax)
					TRACE("%c", bVal);
				else
				{
					TRACE("{#INVALID %02X#}", bVal);
					ASSERT(false);					
				}
				break;
		}
	}
	TRACE("]\n");
#endif
}

#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(RegExCompare, pv)
{
	UNUSED_ALWAYS(pv);

	struct CIuRegExCompareTest
	{
		LPCTSTR m_pcszValue;
		LPCTSTR m_pcszPattern;
		int m_iResult;
		int m_iFlags;
	};

	static CIuRegExCompareTest aTest[] =
	{
		{
			"",		
			"",		
			regExYes,
			regExFull,
		},{
			"Omaha",
			"!MAH",		
			regExYes,
			regExFull,
		},{
			"lindsay",		
			"{!}MAH,NDSAY",		
			regExYes,
			regExFull,
		},{
			"lindsay",		
			"{*}LIND",		
			regExYes,
			regExFull,
		},{
			"lindsay",		
			"{*}-LIND",		
			regExNo,
			regExFull,
		},{
			"402",		
			"{*}-407,-870",		
			regExYes,
			regExFull,
		},{
			"402",		
			"{*}-407,-870,3",
			regExNo,
			regExFull,
		},{
			"402",		
			"{*}-407,-870,4",
			regExYes,
			regExFull,
		},{
			"402",		
			"{*}-402,-870,4",
			regExNo,
			regExFull,
		},{
			"407",		
			"{*}-407,-870",		
			regExNo,
			regExFull,
		},{
			0 
		}
	};

	for (int i = 0; aTest[i].m_pcszPattern; ++i)
	{
		LPCTSTR pcszPattern = aTest[i].m_pcszPattern;
		CIuRegEx RegEx(pcszPattern, aTest[i].m_iFlags);
		CIuRegExCompare RegExCompare(RegEx);

		LPCTSTR pcszValue = aTest[i].m_pcszValue;
		int iResult = RegExCompare.Compare(pcszValue);
		int iExpectedResult = aTest[i].m_iResult;

		if (iResult != iExpectedResult)
		{
			TRACE("'%s' LIKE '%s'\n", pcszValue, pcszPattern);
			TRACE("\tRegEx: [%s]\n", LPCTSTR(RegEx.GetExpression()));
			TRACE("\tExpected: %d, Received: %d\n", iExpectedResult, iResult);
			TRACE("\tTokens: ");
			RegExCompare.Dump();
			ASSERT(false);
		}
	}
	return 0;	
}
IU_TEST_END()
#endif
