#ifndef _ENGINE_GEORAWELEMENTMAP_H_
#define _ENGINE_GEORAWELEMENTMAP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_MAPSI_H_
#	include "Common\MapSI.h"
#endif	// _COMMON_MAPSI_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawElementMap)
class CIuGeoRawElementCollection;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawElementMap, CIuObject }}
// A class used during compression to provide an efficient mapping between
// a named collection items and it's offset in the collection.
#define CIuGeoRawElementMap_super CIuObject

class CIuGeoRawElementMap : public CIuGeoRawElementMap_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawElementMap)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawElementMap();
	virtual ~CIuGeoRawElementMap();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool Lookup(LPCTSTR pcszName, __int32& iIndex) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Create(CIuGeoRawElementCollection& collection);
	void Empty();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuMapStringToInt32 m_Map;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuGeoRawElementMap::Lookup(LPCTSTR pcszName, __int32& iIndex) const
{
	return m_Map.Lookup(pcszName, iIndex);
}

#endif // _ENGINE_GEORAWELEMENTMAP_H_
