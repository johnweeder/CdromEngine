#ifndef _ENGINE_RECORDDLG_H_
#define _ENGINE_RECORDDLG_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#include "resource.h"
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_RECORD_H_
#	include "Engine\Record.h"
#endif	// _ENGINE_RECORD_H_
//}}Uses

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordDlg, CDialog }}
#define CIuRecordDlg_super CDialog

class CIuRecordDlg : public CIuRecordDlg_super
{
//{{Declare
	DECLARE_MESSAGE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordDlg(const CIuRecord* pRecord, const CIuRecordDef* pRecordDef = 0, CWnd* pParent = 0);   
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	const CIuRecord* m_pRecord;
	const CIuRecordDef* m_pRecordDef;
//}}Data

public:
	//{{AFX_DATA(CIuRecordDlg)
	enum { IDD = IDD_ENGINE_RECORD };
	CListCtrl	m_Grid;
	CString	m_sSize;
	CString	m_sRefCount;
	CString	m_sFields;
	CString	m_sFlags;
	CString	m_sAlt;
	CString	m_sBoughtLevel;
	CString	m_sCount;
	CString	m_sExpandNo;
	CString	m_sKey;
	CString	m_sRecordNo;
	CString	m_sSourceNo;
	CString	m_sKeyInfo;
	CString	m_sLatLong;
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIuRecordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIuRecordDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_RECORDDLG_H_
