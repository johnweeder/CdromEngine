#include "StdAfx.h"
//{{Include
#include "DemographicsBusiness.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

static LPCTSTR apcszAdSize[] =
{
	"Z" "\0" "Not Available",
	"A" "\0" "Regular Listing",
	"B" "\0" "Bold Listing",
	"C" "\0" "In-Column Space Ad",
	"D" "\0" "Display Ad",
	0
};
const int iAdSizeCodes = (sizeof(apcszAdSize) / sizeof(apcszAdSize[0])) - 1;

static LPCTSTR apcszEmployeeSize[] =
{
	"Z" "\0" "Not Available",
	"A" "\0" "1 to 4 Employees",
	"B" "\0" "5 to 9 Employees",
	"C" "\0" "10 to 19 Employees",
	"D" "\0" "20 to 49 Employees",
	"E" "\0" "50 to 99 Employees",
	"F" "\0" "100 to 249 Employees",
	"G" "\0" "250 to 499 Employees",
	"H" "\0" "500 to 999 Employees",
	"I" "\0" "1,000 to 4,999 Employees",
	"J" "\0" "5,000 to 9,999 Employees",
	"K" "\0" "Over 10,000 Employees",
	0
};

const int iEmployeeSizeCodes = (sizeof(apcszEmployeeSize) / sizeof(apcszEmployeeSize[0])) - 1;

static LPCTSTR apcszSalesVolume[] =
{
	"Z" "\0" "Not Available",
	"A" "\0" "Less than $500,000",
	"B" "\0" "$500,000 to $1 million",
	"C" "\0" "$1 to 2.5 million",
	"D" "\0" "$2.5 to 5 million",
	"E" "\0" "$5 to 10 million",
	"F" "\0" "$10 to 20 million",
	"G" "\0" "$20 to 50 million",
	"H" "\0" "$50 to 100 million",
	"I" "\0" "$100 to 500 million",
	"J" "\0" "$500 million to $1 billion",
	"K" "\0" "Over $1 billion",
	0
};
const int iSalesVolumeCodes = (sizeof(apcszSalesVolume) / sizeof(apcszSalesVolume[0])) - 1;

IU_API_EXPORT LPCTSTR AdSizeCode(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iAdSizeCodes);
	return apcszAdSize[iSize];
}

IU_API_EXPORT int AdSizeFromCode(TCHAR ch)
{
	if (ch >= 'A' && ch <= 'D')
		return ch - 'A' + 1;
	else if (ch >= 'a' && ch <= 'd')
		return ch - 'a' + 1;
	else if (ch == 'Z' || ch == 'z')
		return 0;
	else if (ch == '\0')
		return 0;
	TRACE("WARNING: Unknown ad size code '%c' (%d)\n", (_istprint(ch) ? ch: '?'), ch);
	return 0;
}

IU_API_EXPORT int AdSizeCount()
{
	return iAdSizeCodes;
}

IU_API_EXPORT LPCTSTR AdSizeName(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iAdSizeCodes);
	return apcszAdSize[iSize] + 2;
}

IU_API_EXPORT int AdSizeNameMaxLength()
{
	int iMaxLength = 0;
	for (int i = 0; apcszAdSize[i]; ++i)
		iMaxLength = max(iMaxLength, int(_tcslen(AdSizeName(i))));
	return iMaxLength;
}

IU_API_EXPORT LPCTSTR EmployeeSizeCode(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iEmployeeSizeCodes);
	return apcszEmployeeSize[iSize];
}

IU_API_EXPORT int EmployeeSizeCount()
{
	return iEmployeeSizeCodes;
}

IU_API_EXPORT int EmployeeSizeFromCode(TCHAR ch)
{
	if (ch >= 'A' && ch <= 'K')
		return ch - 'A' + 1;
	else if (ch >= 'a' && ch <= 'k')
		return ch - 'a' + 1;
	else if (ch == 'Z' || ch == 'z')
		return 0;
	else if (ch == '\0')
		return 0;
	TRACE("WARNING: Unknown employee size code '%c' (%d)\n", (_istprint(ch) ? ch: '?'), ch);
	return 0;
}

IU_API_EXPORT LPCTSTR EmployeeSizeName(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iEmployeeSizeCodes);
	return apcszEmployeeSize[iSize] + 2;
}

IU_API_EXPORT int EmployeeSizeNameMaxLength()
{
	int iMaxLength = 0;
	for (int i = 0; apcszEmployeeSize[i]; ++i)
		iMaxLength = max(iMaxLength, int(_tcslen(EmployeeSizeName(i))));
	return iMaxLength;
}
IU_API_EXPORT LPCTSTR SalesVolumeCode(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iSalesVolumeCodes);
	return apcszSalesVolume[iSize];
}

IU_API_EXPORT int SalesVolumeCount()
{
	return iSalesVolumeCodes;
}

IU_API_EXPORT int SalesVolumeFromCode(TCHAR ch)
{
	if (ch >= 'A' && ch <= 'K')
		return ch - 'A' + 1;
	else if (ch >= 'a' && ch <= 'k')
		return ch - 'a' + 1;
	else if (ch == 'Z' || ch == 'z')
		return 0;
	else if (ch == '\0')
		return 0;
	TRACE("WARNING: Unknown sales volume code '%c' (%d)\n", (_istprint(ch) ? ch: '?'), ch);
	return 0;
}

IU_API_EXPORT LPCTSTR SalesVolumeName(int iSize)
{
	ASSERT(iSize >= 0 && iSize < iSalesVolumeCodes);
	return apcszSalesVolume[iSize] + 2;
}

IU_API_EXPORT int SalesVolumeNameMaxLength()
{
	int iMaxLength = 0;
	for (int i = 0; apcszSalesVolume[i]; ++i)
		iMaxLength = max(iMaxLength, int(_tcslen(SalesVolumeName(i))));
	return iMaxLength;
}
