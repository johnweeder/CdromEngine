#include "StdAfx.h"
//{{Include
#include "CdromSpecDft.h"
#include "CdromSpecConst.h"
#include "IDs.h"
#include "resource.h"
#include "Strip.h"
#include "RecordDef.h"
#include "Meter.h"
#include "RecordSort.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Lists of meters
// List must end with meterNone
static int aiMeterPf[] = { meterPf_2000, meterNone };
static int aiMeterPu[] = { meterPu_2000, meterNone };

/////////////////////////////////////////////////////////////////////////////
// Release specifications

static const CIuCdromSpecDft aDft[] =
{
	{
	//////////////////////////////////////////////////////////////////////////
	// 104 Million Businesses & Households  Test
		_T("104m_Test_2001"),
		&id104m_Test_2001,
		_T("104 Million Businesses & Households - 2001 Test!"),
		cdromProduct104mTest_2001,
		szRelease_Test,
		_T("14Test"),
		0, 1,
		meter104m_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// 104 Million Businesses & Households  2001 R1
		_T("104mUsa_2001R1"),
		&id104m_Usa_2001R1,
		_T("104 Million Businesses & Households USA1 - 2001 1st Edition"),
		cdromProduct104mUsa_2001,
		szRelease_2001R1,
		_T("14Us01R1"),
		0, 1,
		meter104m_2001,
		0,
	},{
		_T("104mWestern_2001R1"),
		&id104m_Western_2001R1,
		_T("104 Million Businesses & Households Western - 2001 1st Edition"),
		cdromProduct104mWestern_2001,
		szRelease_2001R1,
		_T("14We01R1"),
		0, 5,
		meter104m_2001,
		0,
	},{
		_T("104mNorthEast_2001R1"),
		&id104m_NorthEast_2001R1,
		_T("104 Million Businesses & Households Northeast - 2001 1st Edition"),
		cdromProduct104mNorthEast_2001,
		szRelease_2001R1,
		_T("14Ne01R1"),
		1, 5,
		meter104m_2001,
		0,
	},{
		_T("104mSouthEast_2001R1"),
		&id104m_SouthEast_2001R1,
		_T("104 Million Businesses & Households Southeast - 2001 1st Edition"),
		cdromProduct104mSouthEast_2001,
		szRelease_2001R1,
		_T("14Se01R1"),
		2, 5,
		meter104m_2001,
		0,
	},{
		_T("104mCentral_2001R1"),
		&id104m_Central_2001R1,
		_T("104 Million Businesses & Households Central - 2001 1st Edition"),
		cdromProduct104mCentral_2001,
		szRelease_2001R1,
		_T("14Ce01R1"),
		3, 5,
		meter104m_2001,
		0,
	},{
		_T("104mGreatLakes_2001R1"),
		&id104m_GreatLakes_2001R1,
		_T("104 Million Businesses & Households GreatLakes - 2001 1st Edition"),
		cdromProduct104mGreatLakes_2001,
		szRelease_2001R1,
		_T("14Gl01R1"),
		4, 5,
		meter104m_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// 88 Million Households Deluxe Test
		_T("88md_Test_2001"),
		&id88md_Test_2001,
		_T("88 Million Households Deluxe - 2001 Test!"),
		cdromProduct88mdTest_2001,
		szRelease_Test,
		_T("88Test"),
		0, 1,
		meter88md_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// 88 Million Households Deluxe 2001 R1
		_T("88mdUsa_2001R1"),
		&id88md_Usa_2001R1,
		_T("88 Million Households Deluxe USA1 - 2001 1st Edition"),
		cdromProduct88mdUsa_2001,
		szRelease_2001R1,
		_T("88Us01R1"),
		0, 1,
		meter88md_2001,
		0,
	},{
		_T("88mdWestern_2001R1"),
		&id88md_Western_2001R1,
		_T("88 Million Households Deluxe Western - 2001 1st Edition"),
		cdromProduct88mdWestern_2001,
		szRelease_2001R1,
		_T("88We01R1"),
		0, 5,
		meter88md_2001,
		0,
	},{
		_T("88mdNorthEast_2001R1"),
		&id88md_NorthEast_2001R1,
		_T("88 Million Households Deluxe Northeast - 2001 1st Edition"),
		cdromProduct88mdNorthEast_2001,
		szRelease_2001R1,
		_T("88Ne01R1"),
		1, 5,
		meter88md_2001,
		0,
	},{
		_T("88mdCentral_2001R1"),
		&id88md_Central_2001R1,
		_T("88 Million Households Deluxe Central - 2001 1st Edition"),
		cdromProduct88mdCentral_2001,
		szRelease_2001R1,
		_T("88Ce01R1"),
		2, 5,
		meter88md_2001,
		0,
	},{
		_T("88mdSouthEast_2001R1"),
		&id88md_SouthEast_2001R1,
		_T("88 Million Households Deluxe Southeast - 2001 1st Edition"),
		cdromProduct88mdSouthEast_2001,
		szRelease_2001R1,
		_T("88Se01R1"),
		3, 5,
		meter88md_2001,
		0,
	},{
		_T("88mdMidWest_2001R1"),
		&id88md_MidWest_2001R1,
		_T("88 Million Households Deluxe Midwest - 2001 1st Edition"),
		cdromProduct88mdMidWest_2001,
		szRelease_2001R1,
		_T("88Mw01R1"),
		4, 5,
		meter88md_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Address Corrector Test
		_T("Ac_Test_V1"),
		&idAc_Test_V1,
		_T("Address Corrector - V1 Test!"),
		cdromProductAcTest_V1,
		szRelease_Test,
		_T("AcTest"),
		0, 1,
		meterAc_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Address Corrector UI -- Database to provide default registration info
	// to the UI
		_T("AcUi_V1"),
		&idAc_Ui_V1,
		_T("Address Corrector - V1 UI!"),
		cdromProductAcUi_V1,
		szRelease_V1,
		_T("AcUi00V1"),
		0, 1,
		meterAc_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Address Corrector V1
		_T("AcUsa_V1"),
		&idAc_Usa_V1,
		_T("Address Corrector USA1 - Version 1"),
		cdromProductAcUsa_V1,
		szRelease_V1,
		_T("AcUs00V1"),
		0, 1,
		meterAc_V1,
		0,
	},{
		_T("AcWestern_V1"),
		&idAc_Western_V1,
		_T("Address Corrector Western - Version 1"),
		cdromProductAcWestern_V1,
		szRelease_V1,
		_T("AcWe00V1"),
		0, 6,
		meterAc_V1,
		0,
	},{
		_T("AcNorthEast_V1"),
		&idAc_NorthEast_V1,
		_T("Address Corrector Northeast - Version 1"),
		cdromProductAcNorthEast_V1,
		szRelease_V1,
		_T("AcNe00V1"),
		1, 6,
		meterAc_V1,
		0,
	},{
		_T("AcCentral_V1"),
		&idAc_Central_V1,
		_T("Address Corrector Central - Version 1"),
		cdromProductAcCentral_V1,
		szRelease_V1,
		_T("AcCe00V1"),
		2, 6,
		meterAc_V1,
		0,
	},{
		_T("AcMidAtlantic_V1"),
		&idAc_MidAtlantic_V1,
		_T("Address Corrector Mid-Atlantic - Version 1+Version 1"),
		cdromProductAcMidAtlantic_V1,
		szRelease_V1,
		_T("AcMa00V1"),
		3, 6,
		meterAc_V1,
		0,
	},{
		_T("AcSouthEast_V1"),
		&idAc_SouthEast_V1,
		_T("Address Corrector Southeast - Version 1"),
		cdromProductAcSouthEast_V1,
		szRelease_V1,
		_T("AcSe00V1"),
		4, 6,
		meterAc_V1,
		0,
	},{
		_T("AcMidWest_V1"),
		&idAc_MidWest_V1,
		_T("Address Corrector Midwest - Version 1"),
		cdromProductAcMidWest_V1,
		szRelease_V1,
		_T("AcMw00V1"),
		5, 6,
		meterAc_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Business Mailing Lists Test
		_T("Bml1_Test_2000"),
		&idBml_Test1_2000,
		_T("Business Mailing Lists, Disc 1 - 2000 Test!"),
		cdromProductBml1Test_2000,
		szRelease_Test,
		_T("Bml1Test"),
		0, 2,
		meterBml_2000,
		0,
	},{
		_T("Bml2_Test_2000"),
		&idBml_Test2_2000,
		_T("Business Mailing Lists, Disc 2 - 2000 Test!"),
		cdromProductBml2Test_2000,
		szRelease_Test,
		_T("Bml2Test"),
		1, 2,
		meterBml_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Business Mailing Lists 2000 R1
		_T("Bml1_2000R1"),
		&idBml_Usa1_2000R1,
		_T("Business Mailing Lists, Disc 1 - 2000 1st Edition"),
		cdromProductBml1Usa_2000,
		szRelease_2000R1,
		_T("BmD100R1"),
		0, 2,
		meterBml_2000,
		0,
	},{
		_T("Bml2_2000R1"),
		&idBml_Usa2_2000R1,
		_T("Business Mailing Lists, Disc 2 - 2000 1st Edition"),
		cdromProductBml2Usa_2000,
		szRelease_2000R1,
		_T("BmD200R1"),
		1, 2,
		meterBml_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Business Mailing Lists 2000 R2
		_T("Bml1_2000R2"),
		&idBml_Usa1_2000R2,
		_T("Business Mailing Lists, Disc 1 - 2000 2nd Edition"),
		cdromProductBml1Usa_2000,
		szRelease_2000R2,
		_T("BmD100R2"),
		0, 2,
		meterBml_2000,
		0,
	},{
		_T("Bml2_2000R2"),
		&idBml_Usa2_2000R2,
		_T("Business Mailing Lists, Disc 2 - 2000 2nd Edition"),
		cdromProductBml2Usa_2000,
		szRelease_2000R2,
		_T("BmD200R2"),
		1, 2,
		meterBml_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// CallerID Test
		_T("Ci_Test_V1"),
		&idCi_Test_V1,
		_T("CallerID - V1 Test!"),
		cdromProductCiTest_V1,
		szRelease_Test,
		_T("CiTest"),
		0, 1,
		meterCi_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// CallerID UI -- Database to provide default registration info
	// to the UI
		_T("CiUi_V1"),
		&idCi_Ui_V1,
		_T("CallerID - V1 UI!"),
		cdromProductCiUi_V1,
		szRelease_V1,
		_T("CiUi00V1"),
		0, 1,
		meterCi_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// CallerID Regional V1
		_T("CiWest_V1"),
		&idCi_West_V1,
		_T("CallerID West - Version 1"),
		cdromProductCiWest_V1,
		szRelease_V1,
		_T("CiWe00V1"),
		0, 1,
		meterCi_V1,
		0,
	},{
		_T("CiMidWest_V1"),
		&idCi_MidWest_V1,
		_T("CallerID MidWest - Version 1"),
		cdromProductCiMidWest_V1,
		szRelease_V1,
		_T("CiMw00V1"),
		0, 1,
		meterCi_V1,
		0,
	},{
		_T("CiEast_V1"),
		&idCi_East_V1,
		_T("CallerID East - Version 1"),
		cdromProductCiEast_V1,
		szRelease_V1,
		_T("CiEa00V1"),
		0, 1,
		meterCi_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// CallerID USA V1
		_T("CiUsa_V1"),
		&idCi_Usa_V1,
		_T("CallerID USA1 - Version 1"),
		cdromProductCiUsa_V1,
		szRelease_V1,
		_T("CiUs00V1"),
		0, 1,
		meterCi_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Console
		_T("Console"),
		&idConsole,
		_T("infoUSA Console"),
		cdromProductConsole,
		szRelease_Internal,
		_T("Console"),
		0, 1,
		meterAll,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Meter Admin
		_T("MeterAdmin"),
		&idMeterAdmin,
		_T("infoUSA Meter Administrator"),
		cdromProductMeterAdmin,
		szRelease_Internal,
		_T("MeterAdmin"),
		0, 1,
		meterAll,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Net Admin
		_T("NetAdmin"),
		&idNetAdmin,
		_T("infoUSA Network Administrator"),
		cdromProductNetAdmin,
		szRelease_Internal,
		_T("NetAdmin"),
		0, 1,
		meterAll,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Open Access Method Test
		_T("Oam_Test_V1"),
		&idOam_Test_V1,
		_T("Open Access Method - V1 Test!"),
		cdromProductOamTest_V1,
		szRelease_Test,
		_T("OamTest"),
		0, 1,
		meterOam_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Open Access Method USA V1
		_T("Oam_USAV1"),
		&idOam_Usa_V1,
		_T("Open Access Method USA - Version 1"),
		cdromProductOamUsa_V1,
		szRelease_V1,
		_T("Oam00V1"),
		0, 1,
		meterOam_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Power Business Test
		_T("Pb_Test_2001"),
		&idPb_Test_2001,
		_T("Power Business - 2001 Test!"),
		cdromProductPbTest_2001,
		szRelease_Test,
		_T("PbTest"),
		0, 1,
		meterPb_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Power Business
		_T("Pb_2001R1"),
		&idPb_Usa_2001R1,
		_T("Power Business - 2001 1st Edition"),
		cdromProductPbUsa_2001,
		szRelease_2001R1,
		_T("PbUs01R1"),
		0, 1,
		meterPb_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Personalized Business Mailings Test
		_T("Pbm_Test_V1"),
		&idPbm_Test_V1,
		_T("Personalized Business Mailings - V1 Test!"),
		cdromProductPbmTest_V1,
		szRelease_Test,
		_T("PbmTest"),
		0, 1,
		meterPbm_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Personalized Business Mailings V1
		_T("Pbm_V1"),
		&idPbm_Usa_V1,
		_T("Personalized Business Mailings - Version 1"),
		cdromProductPbmUsa_V1,
		szRelease_V1,
		_T("Pbm00V1"),
		0, 1,
		meterPbm_V1,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder Commercial Test
		_T("Pf_Test_2001"),
		&idPf_Test_2001,
		_T("PowerFinder - 2001 Test!"),
		cdromProductPfTest_2001,
		szRelease_Test,
		_T("PfTest"),
		0, 1,
		meterPf_2001,
		aiMeterPf,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder Commercial 2001 R1
		_T("PfEast_2001R1"),
		&idPf_East_2001R1,
		_T("PowerFinder East - 2001 1st Edition"),
		cdromProductPfEast_2001,
		szRelease_2001R1,
		_T("PfEa01R1"),
		0, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfMidAtlantic_2001R1"),
		&idPf_MidAtlantic_2001R1,
		_T("PowerFinder MidAtlantic - 2001 1st Edition"),
		cdromProductPfMidAtlantic_2001,
		szRelease_2001R1,
		_T("PfMa01R1"),
		1, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfMidWest_2001R1"),
		&idPf_MidWest_2001R1,
		_T("PowerFinder MidWest - 2001 1st Edition"),
		cdromProductPfMidWest_2001,
		szRelease_2001R1,
		_T("PfMw01R1"),
		2, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfMountain_2001R1"),
		&idPf_Mountain_2001R1,
		_T("PowerFinder Mountain - 2001 1st Edition"),
		cdromProductPfMountain_2001,
		szRelease_2001R1,
		_T("PfMt01R1"),
		3, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfNorthCentral_2001R1"),
		&idPf_NorthCentral_2001R1,
		_T("PowerFinder NorthCentral - 2001 1st Edition"),
		cdromProductPfNorthCentral_2001,
		szRelease_2001R1,
		_T("PfNc01R1"),
		4, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfPacific_2001R1"),
		&idPf_Pacific_2001R1,
		_T("PowerFinder Pacific - 2001 1st Edition"),
		cdromProductPfPacific_2001,
		szRelease_2001R1,
		_T("PfPa01R1"),
		5, 7,
		meterPf_2001,
		aiMeterPf,
	},{
		_T("PfSouthern_2001R1"),
		&idPf_Southern_2001R1,
		_T("PowerFinder Southern - 2001 1st Edition"),
		cdromProductPfSouthern_2001,
		szRelease_2001R1,
		_T("PfSo01R1"),
		6, 7,
		meterPf_2001,
		aiMeterPf,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder Government Test
		_T("Pg_Test_2000"),
		&idPg_Test_2000,
		_T("PowerFinder Government - 2000 Test!"),
		cdromProductPgTest_2000,
		szRelease_Test,
		_T("PgTest"),
		0, 1,
		meterPg_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder Government 2000 R2
		_T("PgCentral_2000R2"),
		&idPg_Central_2000R2,
		_T("PowerFinder Government Central - 2000 2nd Edition"),
		cdromProductPgCentral_2000,
		szRelease_2000R2,
		_T("PgCe00R2"),
		0, 6,
		meterPg_2000,
		0,
	},{
		_T("PgMidAtlantic_2000R2"),
		&idPg_MidAtlantic_2000R2,
		_T("PowerFinder Government Mid-Atlantic - 2000 2nd Edition"),
		cdromProductPgMidAtlantic_2000,
		szRelease_2000R2,
		_T("PgMa00R2"),
		1, 6,
		meterPg_2000,
		0,
	},{
		_T("PgMidWest_2000R2"),
		&idPg_MidWest_2000R2,
		_T("PowerFinder Government Midwest - 2000 2nd Edition"),
		cdromProductPgMidWest_2000,
		szRelease_2000R2,
		_T("PgMw00R2"),
		2, 6,
		meterPg_2000,
		0,
	},{
		_T("PgNorthEast_2000R2"),
		&idPg_NorthEast_2000R2,
		_T("PowerFinder Government Northeast - 2000 2nd Edition"),
		cdromProductPgNorthEast_2000,
		szRelease_2000R2,
		_T("PgNe00R2"),
		3, 6,
		meterPg_2000,
		0,
	},{
		_T("PgSouthEast_2000R2"),
		&idPg_SouthEast_2000R2,
		_T("PowerFinder Government Southeast - 2000 2nd Edition"),
		cdromProductPgSouthEast_2000,
		szRelease_2000R2,
		_T("PgSe00R2"),
		4, 6,
		meterPg_2000,
		0,
	},{
		_T("PgWestern_2000R2"),
		&idPg_Western_2000R2,
		_T("PowerFinder Government Western - 2000 2nd Edition"),
		cdromProductPgWestern_2000,
		szRelease_2000R2,
		_T("PgWe00R2"),
		5, 6,
		meterPg_2000,
		0,
	},{
		_T("PgUsa_2000R2"),
		&idPg_Usa_2000R2,
		_T("PowerFinder Government USA1 - 2000 2nd Edition"),
		cdromProductPgUsa_2000,
		szRelease_2000R2,
		_T("PgUs00R2"),
		0, 1,
		meterPg_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder USA1 Test
		_T("Pu_Test_2001"),
		&idPu_Test_2001,
		_T("PowerFinder USA1 - 2001 Test!"),
		cdromProductPuTest_2001,
		szRelease_Test,
		_T("PuTest"),
		0, 1,
		meterPu_2001,
		aiMeterPu,
	},{
	//////////////////////////////////////////////////////////////////////////
	// PowerFinder USA1 
		_T("Pu_2001R1"),
		&idPu_Usa_2001R1,
		_T("PowerFinder USA1 - 2001 1st Edition"),
		cdromProductPuUsa_2001,
		szRelease_2001R1,
		_T("PuUs01R1"),
		0, 1,
		meterPu_2001,
		aiMeterPu,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Power Check
		_T("PowerCheck"),
		&idPowerCheck,
		_T("infoUSA Power Check"),
		cdromProductPowerCheck,
		szRelease_Internal,
		_T("PowerCheck"),
		0, 1,
		meterAll,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// RBOC Test
		_T("Rboc_Test_2000"),
		&idRboc_Test_2000,
		_T("infoUSA (RBOC) - 2000 Test!"),
		cdromProductRbocTest_2000,
		szRelease_Test,
		_T("RbTest"),
		0, 1,
		meterRbocTest_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// RBOC 2000 R8
		_T("Rboc_GreatLakes_2000R8"),
		&idRboc_GreatLakes_2000R8,
		_T("infoUSA Great Lakes Region - August 2000"),
		cdromProductRbocGreatLakes_2000,
		szRelease_Aug2000,
		_T("RbGl00R8"),
		0, 8,
		meterRbocGreatLakes_2000,
		0,
	},{
		_T("Rboc_SeAtlantic1_2000R8"),
		&idRboc_SeAtlantic1_2000R8,
		_T("infoUSA SE Atlantic Region 1 - August 2000"),
		cdromProductRbocSeAtlantic1_2000,
		szRelease_Aug2000,
		_T("RbS100R8"),
		1, 8,
		meterRbocSeAtlantic1_2000,
		0,
	},{
		_T("Rboc_SeAtlantic2_2000R8"),
		&idRboc_SeAtlantic2_2000R8,
		_T("infoUSA SE Atlantic Region 2 - August 2000"),
		cdromProductRbocSeAtlantic2_2000,
		szRelease_Aug2000,
		_T("RbS200R8"),
		2, 8,
		meterRbocSeAtlantic2_2000,
		0,
	},{
		_T("Rboc_NeAtlantic1_2000R8"),
		&idRboc_NeAtlantic1_2000R8,
		_T("infoUSA NE Atlantic Region 1 - August 2000"),
		cdromProductRbocNeAtlantic1_2000,
		szRelease_Aug2000,
		_T("RbN100R8"),
		3, 8,
		meterRbocNeAtlantic1_2000,
		0,
	},{
		_T("Rboc_NeAtlantic2_2000R8"),
		&idRboc_NeAtlantic2_2000R8,
		_T("infoUSA NE Atlantic Region 2 - August 2000"),
		cdromProductRbocNeAtlantic2_2000,
		szRelease_Aug2000,
		_T("RbN200R8"),
		4, 8,
		meterRbocNeAtlantic2_2000,
		0,
	},{
		_T("Rboc_Pacific_2000R8"),
		&idRboc_Pacific_2000R8,
		_T("infoUSA Pacific Region - August 2000"),
		cdromProductRbocPacific_2000,
		szRelease_Aug2000,
		_T("RbPa00R8"),
		5, 8,
		meterRbocPacific_2000,
		0,
	},{
		_T("Rboc_SouthWest_2000R8"),
		&idRboc_SouthWest_2000R8,
		_T("infoUSA Southwest Region - August 2000"),
		cdromProductRbocSouthWest_2000,
		szRelease_Aug2000,
		_T("RbSw00R8"),
		6, 8,
		meterRbocSouthWest_2000,
		0,
	},{
		_T("Rboc_MidWest_2000R8"),
		&idRboc_MidWest_2000R8,
		_T("infoUSA Midwest Region - August 2000"),
		cdromProductRbocMidWest_2000,
		szRelease_Aug2000,
		_T("RbMw00R8"),
		7, 8,
		meterRbocMidWest_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// RBOC 2000 R9
		_T("Rboc_GreatLakes_2000R9"),
		&idRboc_GreatLakes_2000R9,
		_T("infoUSA Great Lakes Region - September 2000"),
		cdromProductRbocGreatLakes_2000,
		szRelease_Sep2000,
		_T("RbGl00R9"),
		0, 8,
		meterRbocGreatLakes_2000,
		0,
	},{
		_T("Rboc_SeAtlantic1_2000R9"),
		&idRboc_SeAtlantic1_2000R9,
		_T("infoUSA SE Atlantic Region 1 - September 2000"),
		cdromProductRbocSeAtlantic1_2000,
		szRelease_Sep2000,
		_T("RbS100R9"),
		1, 8,
		meterRbocSeAtlantic1_2000,
		0,
	},{
		_T("Rboc_SeAtlantic2_2000R9"),
		&idRboc_SeAtlantic2_2000R9,
		_T("infoUSA SE Atlantic Region 2 - September 2000"),
		cdromProductRbocSeAtlantic2_2000,
		szRelease_Sep2000,
		_T("RbS200R9"),
		2, 8,
		meterRbocSeAtlantic2_2000,
		0,
	},{
		_T("Rboc_NeAtlantic1_2000R9"),
		&idRboc_NeAtlantic1_2000R9,
		_T("infoUSA NE Atlantic Region 1 - September 2000"),
		cdromProductRbocNeAtlantic1_2000,
		szRelease_Sep2000,
		_T("RbN100R9"),
		3, 8,
		meterRbocNeAtlantic1_2000,
		0,
	},{
		_T("Rboc_NeAtlantic2_2000R9"),
		&idRboc_NeAtlantic2_2000R9,
		_T("infoUSA NE Atlantic Region 2 - September 2000"),
		cdromProductRbocNeAtlantic2_2000,
		szRelease_Sep2000,
		_T("RbN200R9"),
		4, 8,
		meterRbocNeAtlantic2_2000,
		0,
	},{
		_T("Rboc_Pacific_2000R9"),
		&idRboc_Pacific_2000R9,
		_T("infoUSA Pacific Region - September 2000"),
		cdromProductRbocPacific_2000,
		szRelease_Sep2000,
		_T("RbPa00R9"),
		5, 8,
		meterRbocPacific_2000,
		0,
	},{
		_T("Rboc_SouthWest_2000R9"),
		&idRboc_SouthWest_2000R9,
		_T("infoUSA Southwest Region - September 2000"),
		cdromProductRbocSouthWest_2000,
		szRelease_Sep2000,
		_T("RbSw00R9"),
		6, 8,
		meterRbocSouthWest_2000,
		0,
	},{
		_T("Rboc_MidWest_2000R9"),
		&idRboc_MidWest_2000R9,
		_T("infoUSA Midwest Region - September 2000"),
		cdromProductRbocMidWest_2000,
		szRelease_Sep2000,
		_T("RbMw00R9"),
		7, 8,
		meterRbocMidWest_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Release Notes
		_T("ReleaseNotes"),
		0, // _NO_ ID: Each release note file is unique....
		_T("ReleaseNotes"),
		cdromProductReleaseNotes,
		szRelease_2000R1,
		_T("ReleaseNotes"),
		0, 1,
		meterNone,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// ResumePlus Test
		_T("Rp_Test_2001"),
		&idRp_Test_2001,
		_T("ResumePlus - 2001 Test!"),
		cdromProductRpTest_2001,
		szRelease_Test,
		_T("RpTest"),
		0, 1,
		meterRp_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// ResumePlus 2001 R1
		_T("Rp_2001R1"),
		&idRp_Usa_2001R1,
		_T("ResumePlus - 2001 1st Edition"),
		cdromProductRpUsa_2001,
		szRelease_2001R1,
		_T("Rp01R1"),
		0, 1,
		meterRp_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Sales Leads USA Test
		_T("Slu_Test_2000"),
		&idSlu_Test_2000,
		_T("Sales Leads USA - Test!"),
		cdromProductSluTest_2000,
		szRelease_Test,
		_T("SlTest"),
		0, 1,
		meterSlu_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Sales Leads USA 2000 R1
		_T("Slu_2000R1"),
		&idSlu_Usa_2000R1,
		_T("Sales Leads USA - 2000 1st Edition"),
		cdromProductSluUsa_2000,
		szRelease_2000R1,
		_T("Slu00R1"),
		0, 1,
		meterSlu_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Sales Leads USA 2000 R2
		_T("Slu_2000R2"),
		&idSlu_Usa_2000R2,
		_T("Sales Leads USA - 2000 2nd Edition"),
		cdromProductSluUsa_2000,
		szRelease_2000R2,
		_T("Slu00R2"),
		0, 1,
		meterSlu_2000,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Sample
		_T("Sample"),
		&idSample,
		_T("Sample!"),
		cdromProductSample,
		szRelease_Sample,
		_T("Sample"),
		0, 1,
		meterSample,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Yellow Pages USA Test
		_T("Ypu_Test_2001"),
		&idYpu_Test_2001,
		_T("Yellow Pages USA - 2001 Test!"),
		cdromProductYpuTest_2001,
		szRelease_Test,
		_T("YpuTest"),
		0, 1,
		meterYpu_2001,
		0,
	},{
	//////////////////////////////////////////////////////////////////////////
	// Yellow Pages USA 2001 R1
		_T("Ypu_2001R1"),
		&idYpu_Usa_2001R1,
		_T("Yellow Pages USA - 2001 1st Edition"),
		cdromProductYpuUsa_2001,
		szRelease_2001R1,
		_T("Ypu01R1"),
		0, 1,
		meterYpu_2001,
		0,
	}
};


/////////////////////////////////////////////////////////////////////////////
// CIuCdromSpecDft

int CIuCdromSpecDft::Find(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszCdrom, pcszName) != 0)
			continue;
		return i;
	}
	return -1;
}

int CIuCdromSpecDft::Find(int iProductNo, LPCTSTR pcszRelease)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		const CIuCdromSpecDft* pSpec = Get(i);
		ASSERT(pSpec);

		if (iProductNo != cdromProductNone && pSpec->m_iProductNo != iProductNo)
			continue;

		if (pcszRelease && _tcsicmp(pSpec->m_pcszRelease, pcszRelease) != 0)
			continue;

		return i;
	}
	return -1;
}

const CIuCdromSpecDft* CIuCdromSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aDft + iWhich;
}

int CIuCdromSpecDft::GetCount()
{
	return sizeof(aDft) / sizeof(aDft[0]);
}

