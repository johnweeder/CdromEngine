#include "stdafx.h"
//{{Include
#include "engine.h"
#include "Meters.h"
#include "CdromSpec.h"
#include "MeterSpec.h"
#include "resource.h"
#include "Meter.h"
#include "Error\Error.h"
#include "Common\Variant.h"
#include "Data\Output.h"
#include "MeterAdministratorDlg.h"
#include "Common\SysInfo.h"
#include "Engine.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuMeters, CIuMeters_super)
IU_IMPLEMENT_OBJECT_PTR(CIuMeters)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_METERS, CIuMeters, CIuMeters_super)
//{{AttributeMap
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuMeters, IDS_ENGINE_PPG_METERS, 10, editorEdit)
	IU_ATTRIBUTE_PAGE(CIuMeters, IDS_ENGINE_PPG_METERS, 50, 0)
	IU_ATTRIBUTE_ACTION(CIuMeters, IDS_ENGINE_ACTION_ADMINISTRATORDLG, ActionAdministratorDlg, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuMeters, IDS_ENGINE_ACTION_ADMINISTRATORDLG, IDS_ENGINE_PPG_METERS, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuMeters::CIuMeters()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);

	m_pEngine = 0;
	CommonConstruct();
}

CIuMeters::~CIuMeters()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuMeters::ActionAdministratorDlg(const CIuPropertyCollection&, CIuOutput& Output)
{
	if (!AdministratorDlg(Output.GetParentWnd()))
		return CString("Cancelled");
	return CString("Success");
}

bool CIuMeters::AdministratorDlg(CWnd* pParent, CIuID idMeter, LPCTSTR pcszQueryCode, CString* pResponseCode)
{
	return CIuMeterAdministratorDlg::DoDialog(*this, pParent, idMeter, pcszQueryCode, pResponseCode);
}

bool CIuMeters::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int i = 0; i < GetCount(); ++i)
		if (!Get(i).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuMeters::Clear()
{
	CIuMeters_super::Clear();
	CIuMeters::CommonConstruct();
}

void CIuMeters::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuMeters::Create(CIuMeterSpec& MeterSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuMeter& Meter = Get(iIndex);
	Meter.SetSpec(MeterSpec);
}

CIuEngine& CIuMeters::GetEngine() const
{
	ASSERT(m_pEngine);
	return *m_pEngine;
}

int CIuMeters::GetUserRights() const
{
	return GetEngine().GetUserRights();
}

void CIuMeters::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuMeterPtr pMeter = dynamic_cast<CIuMeter*>(pCollectable.Ptr());
	if (GetEngine().QueryObject(collectionMeters, Descriptor, *pMeter))
	{
		pMeter->SetObjectRepository(&GetEngine().GetObjectRepository());
		pMeter->SetMode(meterModeCdrom);
		// Do not open until first actual use of meter
	}
}

CIuCollectablePtr CIuMeters::OnNew(CWnd*) const
{
	CIuMeterPtr pMeter;
	pMeter.Create();
	return CIuObjectPtr(pMeter);
}

void CIuMeters::Refresh()
{
	for (int iMeter = 0; iMeter < GetCount(); ++iMeter)
		Get(iMeter).Refresh();
}

void CIuMeters::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuMeters::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iMeter = 0; iMeter < Spec.GetMeterCount(); ++iMeter)
		Create(Spec.GetMeter(iMeter));
}
