#include "StdAfx.h"
//{{Include
#include "CdromStrips.h"
#include "resource.h"
#include "CdromStrip.h"
#include "CdromSpec.h"
#include "CdromStripSpec.h"
#include "Strip.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromStrips, CIuCdromStrips_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromStrips)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMSTRIPS, CIuCdromStrips, CIuCdromStrips_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuCdromStrips, IDS_ENGINE_PPG_CDROMSTRIPS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuCdromStrips, IDS_ENGINE_PPG_CDROMSTRIPS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdromStrips::CIuCdromStrips() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromStrips::~CIuCdromStrips()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCdromStrips::Build(CIuOutput& Output, CIuFlags Flags)
{
	for (int iStrip = 0; iStrip < GetCount(); ++iStrip)
		if (!Get(iStrip).Build(Output, Flags))
			return false;
	return true;
}

void CIuCdromStrips::CreateStrip(CIuCdromStripSpec& CdromStripSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuCdromStrip& CdromStrip = Get(iIndex);
	CdromStrip.SetSpec(CdromStripSpec);
}

void CIuCdromStrips::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuCdromStrips::Delete(CIuOutput* pOutput)
{
	for (int iStrip = 0; iStrip < GetCount(); ++iStrip)
		Get(iStrip).Delete(pOutput);
}

CIuCollectablePtr CIuCdromStrips::OnNew(CWnd*) const
{
	CIuCdromStripPtr pCdromStrip;
	pCdromStrip.Create();
	return pCdromStrip;
}

void CIuCdromStrips::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iStrip = 0; iStrip < Spec.GetStripCount(); ++iStrip)
	{
		// Get the Strip specifier
		CIuCdromStripSpec& CdromStripSpec = Spec.GetStrip(iStrip);

		// If we don't need to strip anything, just ignore it
		if (CdromStripSpec.GetStripNo() == stripNone)
			continue;

		CreateStrip(CdromStripSpec);
	}
}

