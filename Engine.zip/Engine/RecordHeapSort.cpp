#include "StdAfx.h"
//{{Include
#include "RecordHeapSort.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

CIuRecordHeapSort::CIuRecordHeapSort()
{
	m_iSortFlags = recordSortRecordNo;
}

CIuRecordHeapSort::~CIuRecordHeapSort()
{
	if (m_pArray)
	{
		CIuRecord** ppRecords = reinterpret_cast<CIuRecord**>(m_pArray);
		for (int i = 0; i < m_iNumElements; ++i)
		{
			CIuRecord::Delete(ppRecords[i]);
		}
		OnDestruct(m_pArray);
	}
	m_pArray = 0;
}

bool CIuRecordHeapSort::Insert(const CIuRecord& Record)
{
	CIuRecord* pRecord = CIuRecord::New(Record);
	// We don't want a peek to accidently free this via the reference count.
	pRecord->AddRef();
	return CIuRecordHeapSort_super::Insert(reinterpret_cast<const BYTE*>(&pRecord));
}

int CIuRecordHeapSort::OnCompare(const BYTE* pb1, const BYTE* pb2) const
{
	const CIuRecord** ppRecord1 = (const CIuRecord**)(pb1);
	const CIuRecord** ppRecord2 = (const CIuRecord**)(pb2);

	return (*ppRecord1)->Compare(**ppRecord2, m_iSortFlags);
}

BYTE* CIuRecordHeapSort::OnConstruct()
{
	int iSize = m_iMaxElements * m_iElementSize;
	BYTE* pb = (BYTE*)(VirtualAlloc(NULL, iSize, MEM_COMMIT, PAGE_READWRITE));
	memset(pb, 0, iSize);
	return pb;
}

void CIuRecordHeapSort::OnCopy(BYTE* pbDst, const BYTE* pbSrc)
{
	CIuRecord** ppRecordSrc = (CIuRecord**)(pbSrc);
	ASSERT(ppRecordSrc);
	CIuRecord** ppRecordDst = (CIuRecord**)(pbDst);
	ASSERT(ppRecordDst);
	*ppRecordDst = *ppRecordSrc;
}

void CIuRecordHeapSort::OnDestruct(BYTE* pArray)
{
	if (pArray)
		VirtualFree(pArray, 0, MEM_RELEASE);
}

void CIuRecordHeapSort::OnExchange(BYTE* pb1, BYTE* pb2)
{
	CIuRecord** ppRecord1 = (CIuRecord**)(pb1);
	CIuRecord** ppRecord2 = (CIuRecord**)(pb2);
	CIuRecord* pRecordTemp = *ppRecord1;
	*ppRecord1 = *ppRecord2;
	*ppRecord2 = pRecordTemp;
}

CIuRecord* CIuRecordHeapSort::Peek()
{
	CIuRecord* pRecord;
	CIuRecordHeapSort_super::Peek(reinterpret_cast<BYTE*>(&pRecord));
	return pRecord;
}

CIuRecordPtr CIuRecordHeapSort::Remove()
{
	CIuRecord* pRecord;
	CIuRecordHeapSort_super::Remove(reinterpret_cast<BYTE*>(&pRecord));
	// Release the extra reference we added at insert
	pRecord->Release();
	CIuRecordPtr pRecordPtr;
	pRecordPtr.Attach(pRecord, true);
	return pRecordPtr;
}

void CIuRecordHeapSort::SetSize(int iMaxElements)
{
	CIuRecordHeapSort_super::SetSize(iMaxElements, sizeof(CIuRecord*));
}

void CIuRecordHeapSort::SetSortFlags(int iFlags)
{
	m_iSortFlags = iFlags;
}

void CIuRecordHeapSort::Store(CIuRecord& Record)
{
	CIuRecord* pRecord = CIuRecord::New(Record);
	// We don't want a peek to accidently free this via the reference count.
	pRecord->AddRef();
	CIuRecordHeapSort_super::Store(reinterpret_cast<BYTE*>(&pRecord));
}
