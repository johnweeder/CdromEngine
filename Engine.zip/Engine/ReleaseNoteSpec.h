#ifndef _ENGINE_RELEASENOTESPEC_H_
#define _ENGINE_RELEASENOTESPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_INTEROP_VERSIONNUMBER_H_
#	include "Interop\VersionNumber.h"
#endif	// _INTEROP_VERSIONNUMBER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuReleaseNoteSpec)
struct CIuReleaseNoteSpecDft;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuReleaseNoteSpec, CIuObjectNamed }}
#define CIuReleaseNoteSpec_super CIuObjectNamed
class CIuReleaseNoteSpec : public CIuReleaseNoteSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuReleaseNoteSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuReleaseNoteSpec();
	virtual ~CIuReleaseNoteSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetNotes() const;
	CIuVersionNumber GetReleaseCurrent() const;
	CIuVersionNumber GetReleaseMin() const;
	int GetReleaseNoteNo() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iReleaseNoteSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszReleaseNote);
	void FromNo(CIuCdromSpec* pCdrom, int iReleaseNoteNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuReleaseNoteSpecDft* pReleaseNoteSpec);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetNotes(LPCTSTR);
	void SetReleaseCurrent(CIuVersionNumber);
	void SetReleaseMin(CIuVersionNumber);
	void SetReleaseNoteNo(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	int m_iReleaseNoteNo;
	CIuVersionNumber m_verReleaseCurrent;
	CIuVersionNumber m_verReleaseMin;
	CString m_sNotes;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuReleaseNoteSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuReleaseNoteSpec::GetNotes() const
{
	return m_sNotes;
}

inline CIuVersionNumber CIuReleaseNoteSpec::GetReleaseCurrent() const
{
	return m_verReleaseCurrent;
}

inline CIuVersionNumber CIuReleaseNoteSpec::GetReleaseMin() const
{
	return m_verReleaseMin;
}

inline int CIuReleaseNoteSpec::GetReleaseNoteNo() const
{
	return m_iReleaseNoteNo;
}

inline bool CIuReleaseNoteSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_RELEASENOTESPEC_H_
