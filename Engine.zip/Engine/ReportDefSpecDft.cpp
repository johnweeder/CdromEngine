#include "StdAfx.h"
//{{Include
#include "ReportDefSpecDft.h"
#include "ReportDef.h"
#include "IDs.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ReportDef specifications

static const CIuReportDefSpecDft reportDefXXXDft =
{
	_T("ReportDefXXX"), reportDefXXX,
	&idReportDefXXX,
	{
		0
	}
};

static const CIuReportDefSpecDft* apReportDef[] =
{
	&reportDefXXXDft,
};

/////////////////////////////////////////////////////////////////////////////
// CIuReportDefSpecDft

int CIuReportDefSpecDft::Find(LPCTSTR pcszReportDef)
{
	ASSERT(AfxIsValidString(pcszReportDef));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszReportDef, pcszReportDef) == 0)
			return i;
	}
	return -1;
}

int CIuReportDefSpecDft::Find(int iReportDef)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iReportDef == iReportDef)
			return i;
	}
	return -1;
}

const CIuReportDefSpecDft* CIuReportDefSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return apReportDef[iWhich];
}

int CIuReportDefSpecDft::GetCount()
{
	return sizeof(apReportDef) / sizeof(apReportDef[0]);
}

