#include "StdAfx.h"
//{{Include
#include "InputAlt.h"
#include "resource.h"
#include "Interop\Conversions.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_SERIAL(CIuInputAlt, CIuInputAlt_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuInputAlt)
IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_INPUTALT, CIuInputAlt, CIuInputAlt_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuInputAlt, IDS_ENGINE_PPG_INPUTALT, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuInputAlt::CIuInputAlt() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuInputAlt::~CIuInputAlt()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuInputAlt::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("Input Alt"));
	SetFormat(inputAlt);
	m_asSeeAlso.SetNoCase(true);
	m_asSeeAlso.SetDedup(true);
	//}}Initialize
}

bool CIuInputAlt::OnProcess()
{
	int iFields = GetInputs();
	if (iFields < 2)
		return true;
	LPCTSTR pcszAlt = GetInput(0);
	m_asSeeAlso.RemoveAll();
	for (int iField = 1; iField < iFields; ++iField)
	{
		LPCTSTR pcszSeeAlso = GetInput(iField);
		if (*pcszSeeAlso == '\0')
			continue;
		m_asSeeAlso.Add(pcszSeeAlso);
	}

	StringArrayAsString(m_sSeeAlso, m_asSeeAlso, '\n');

	SetField(inputFieldAlt, pcszAlt);
	SetField(inputFieldSeeAlso, m_sSeeAlso);
	return Output();
}
