#ifndef _ENGINE_RECORDDEF_H_
#define _ENGINE_RECORDDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_FIELDDEFS_H_
#	include "Engine\FieldDefs.h"
#endif	// _ENGINE_FIELDDEFS_H_
#ifndef 	_ENGINE_KEYDEF_H_
#	include "Engine\KeyDef.h"
#endif	// _ENGINE_KEYDEF_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordDef)
class CIuRecordDefSpec;
//}}Predefines

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Predefined record spec type

enum CIuRecordDefSpecNo
{
	recordDefNone = 0,

	recordDefAddress,
	recordDefAreaCodeUpdate,
	recordDefBusiness,
	recordDefCensus,
	recordDefCountyUpdate,
	recordDefExchangeUpdate,
	recordDefFranchise,
	recordDefGeoAreaCode,
	recordDefGeoCity,
	recordDefGeoCounty,
	recordDefGeoExchange,
	recordDefGeoMsa,
	recordDefGeoState,
	recordDefGeoZip,
	recordDefMsaUpdate,
	recordDefPhone,
	recordDefSic,
	recordDefSicDescription,
	recordDefSicSeeAlso,
	recordDefZip,
	recordDefZip4,
	recordDefZip5,
	recordDefZipCentroid,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordDef, CIuObjectNamed }}

#define CIuRecordDef_super CIuObjectNamed

class IU_CLASS_EXPORT CIuRecordDef : public CIuRecordDef_super
{
//{{Declare
	IU_DECLARE_ATTRIBUTE_MAP()
	DECLARE_SERIAL(CIuRecordDef)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordDef();           
	virtual ~CIuRecordDef();
	CIuRecordDef(const CIuRecordDef&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuFieldDefs& GetFieldDefs() const;
	void GetFields(CStringArray& as) const;
	static void GetFields(LPCTSTR pcsz, CStringArray& as);
	int GetMaxLength() const;
	int GetRecordLength() const;
	CIuKeyDef& GetKeyDef() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	int AddFieldDef(LPCTSTR pcszDef);
	int AddFieldDef(CIuFieldDefSpec& spec);
	void AddFieldDefs(CStringArray& as);
	void AddFieldDefs(CIuFieldMap& Map);
	void Adjust();
	void Append(const CIuRecordDef& RecordDef, const CIuRecordDef* pRecordDefMaster = 0);
	virtual void Clear();
	virtual void Copy(const CIuObject& object);
	void CreateDefaultKeyDef();
	virtual void LoadFromRecordDef(LPCTSTR pcsz = 0);
	virtual void LoadFromRecordFile(LPCTSTR pcsz = 0);
	void SetSpec(LPCTSTR apcszOutput[]);
	void SetSpec(int iSpec);
	void SetSpec(CIuRecordDefSpec& RecordDefSpec);
	void SetRecordLength(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnAdjust();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuRecordDef& operator=(const CIuRecordDef&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionAdjust(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionLoadFromRecordDef(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CString ActionLoadFromRecordFile(const CIuPropertyCollection& Collection, CIuOutput& Output);
	CIuObject* GetFieldDefs_() const;
	CIuObject* GetKeyDef_() const;
private:
	void AppendFieldDef(const CIuFieldDef& FieldDefSrc, const CIuRecordDef* pRecordDefMaster = 0);
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	CIuFieldDefsPtr m_pFieldDefs;
private:
	int m_iRecordLength;
	CIuKeyDefPtr m_pKeyDef;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuFieldDefs& CIuRecordDef::GetFieldDefs() const
{
	return m_pFieldDefs.Ref();
}

inline CIuKeyDef& CIuRecordDef::GetKeyDef() const
{
	return m_pKeyDef.Ref();
}

inline int CIuRecordDef::GetRecordLength() const
{
	return m_iRecordLength;
}

#endif // _ENGINE_RECORDDEF_H_
