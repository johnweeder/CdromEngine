#ifndef _ENGINE_RECORDFILE_H_
#define _ENGINE_RECORDFILE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_PREFIXFILE_H_
#	include "Data\PrefixFile.h"
#endif	// _DATA_PREFIXFILE_H_
#ifndef 	_COMMON_BIGBUFFER_H_
#	include "Common\BigBuffer.h"
#endif	// _COMMON_BIGBUFFER_H_
#ifndef 	_INTEROP_INTEGER_H_
#	include "Interop\Integer.h"
#endif	// _INTEROP_INTEGER_H_
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_RECORDPTR_H_
#	include "Engine\RecordPtr.h"
#endif	// _ENGINE_RECORDPTR_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRecordFile)
struct CIuRecord;
class CIuRecordPtr;
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

const int rawRecordFileBlockSize = 32 * 1024;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRecordFile, CIuObjectNamed }}
#define CIuRecordFile_super CIuObjectNamed

class CIuRecordFile : public CIuRecordFile_super
{
//{{Declare
	DECLARE_SERIAL(CIuRecordFile)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRecordFile();
	virtual ~CIuRecordFile();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	bool Exists() const;
	bool Get(int, CIuRecordPtr&) const;
	int GetBlocks() const;
	int GetBlockSize() const;
	static void GetFields(LPCTSTR pcsz, CStringArray& as);
	CString GetFilename() const;
	CString GetFullFilename() const;
	int GetMaxRecordNo() const;
	int GetNextRecord() const;
	int GetRecords() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool IsEof() const;
	bool IsOpen() const;
	bool IsTemporary() const;
	CIuRecordDef& GetRecordDef() const;
	bool ShouldAppend() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Append(const CIuRecord&);
	void ClearTemporary();
	void Close();
	void Create(CIuOpenSpec&);
	void Delete(CIuOutput* pOutput = 0);
	void DeleteTemporary(CIuOutput* pOutput = 0);
	void LoadFromRecordFile(LPCTSTR pcsz = 0);
	void MoveFirst();
	bool MoveNext(CIuRecordPtr& pRecord);
	void Open(CIuOpenSpec&);
	void SetAppend(bool);
	void SetBlocks(int);
	void SetBlockSize(int);
	void SetFilename(LPCTSTR);
	void SetMaxRecordNo(int);
	void SetRecords(int);
	void SetSpec(int iRecordDefSpec, LPCTSTR pcszFilename);
	void SetTemporary(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	int FindBlock(int iRecord);
	bool IsRecordInBlock(int iRecord, int iBlock) const;
	void ReadBlock(int iBlock);
	void ReadBlockStarts();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetRecordDef_() const;
	bool GetGridInfo(int iRq, CIuGridRq& rq);
protected:
	void OpenAppend();
	void OpenReadOnly();
private:
	void AppendBlock();
	void ValidateBlock() const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Non-persistent
	// Files & buffers
		CIuPrefixFile m_file;
		CIuFileVirtualPtr m_pVFile;
	// Caching for blocks during read/write
		// Current block
		CIuBigBuffer m_block;
		// The RecordNo of first record in each block
		CIntArray m_aiFirstRecordInBlock;
		// Current blocks
		int m_iBlock;
		// Current record and pointer to data for record
		int m_iRecord;
		PBYTE m_pbRecord;
		// A buffer used to build the raw data for writing
		CIuBuffer m_AppendBuffer;
		// Open flag. > 0 is open.
		int m_iOpen;
		// Are we in "temporary" mode... used for discardable sources...
		bool m_fTemporary;
		// Append flag
		bool m_fAppend;
		// Next record to read
		// Used by the MoveFirst/MoveNext
		int m_iNextRecord;
	// Persistent
		// Number of records in file
		int m_iRecords;
		// Maximum record number seen in creating this file. Primarily used to get the
		// number of bits required to create pointers back to the original records
		int m_iMaxRecordNo;
		// Number of blocks
		int m_iBlocks;
		// Size of each block
		int m_iBlockSize;
		// Actual filename
		CString m_sFilename;
		// Record definition
		CIuRecordDefPtr m_pRecordDef;
	// Used internally as part of grid support
	CIuRecordPtr m_pGridRecord;
	int m_iGridRecord;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuRecordFile::GetBlocks() const
{
	return m_iBlocks;
}

inline int CIuRecordFile::GetBlockSize() const
{
	return ((max(m_iBlockSize, rawRecordFileBlockSize) / 512) * 512);
}

inline int CIuRecordFile::GetMaxRecordNo() const
{
	return m_iMaxRecordNo;
}

inline int CIuRecordFile::GetNextRecord() const
{
	return m_iNextRecord;
}

inline CIuRecordDef& CIuRecordFile::GetRecordDef() const
{
	return m_pRecordDef.Ref();
}

inline int CIuRecordFile::GetRecords() const
{
	return m_iRecords;
}

inline bool CIuRecordFile::IsTemporary() const
{
	return m_fTemporary;
}

inline bool CIuRecordFile::ShouldAppend() const
{
	return m_fAppend;
}

#endif // _ENGINE_RECORDFILE_H_
