#ifndef _ENGINE_BLOBS_H_
#define _ENGINE_BLOBS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_BLOB_H_
#	include "Engine\Blob.h"
#endif	// _ENGINE_BLOB_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuBlobs)
class CIuCdromSpec;
class CIuCdrom;
class CIuEngine;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1


/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuBlobs, CIuCollection }}
#define CIuBlobs_super CIuCollection

class IU_CLASS_EXPORT CIuBlobs : public CIuBlobs_super
{
//{{Declare
	DECLARE_SERIAL(CIuBlobs)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuBlobs();
	virtual ~CIuBlobs();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuBlob& Get(const CIuMoniker& moniker) const;
	CIuBlob& Get(LPCTSTR s) const;
	CIuBlob& Get(int iIndex) const;
	CIuBlob& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	bool HasEngine() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	void Create(CIuBlobSpec& BlobSpec);
	void SetEngine(CIuEngine& Engine);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int iIndex, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuBlob& CIuBlobs::Get(const CIuMoniker& moniker) const
{
	return *dynamic_cast<CIuBlob*>(&CIuCollection::Get(moniker));
}

inline CIuBlob& CIuBlobs::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuBlob*>(&CIuCollection::Get(s));
}

inline CIuBlob& CIuBlobs::Get(int iIndex) const
{
	return *dynamic_cast<CIuBlob*>(&CIuCollection::Get(iIndex));
}

inline CIuBlob& CIuBlobs::Get(CIuID id) const
{
	return *dynamic_cast<CIuBlob*>(&CIuCollection::Get(id));
}

inline CIuEngine& CIuBlobs::GetEngine() const
{
	ASSERT(HasEngine());
	return *m_pEngine;
}

inline bool CIuBlobs::HasEngine() const
{
	return m_pEngine != 0;
}

#endif // _ENGINE_BLOBS_H_
