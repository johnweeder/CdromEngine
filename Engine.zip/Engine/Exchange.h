#ifndef _ENGINE_EXCHANGE_H_
#define _ENGINE_EXCHANGE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOELEMENT_H_
#	include "Engine\GeoElement.h"
#endif	// _ENGINE_GEOELEMENT_H_
//}}Uses

//{{Predefines
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExchange, CIuGeoElement }}
#define CIuExchange_super CIuGeoElement
#pragma pack(1)
class CIuExchange : public CIuExchange_super
{
//{{Declare
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetExchange() const;
	LPCTSTR GetExchangeAsString() const;
	LPCTSTR GetExchangeName() const;
	void GetZipList(CIuGeoList&) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	friend class CIuGeoExchange;
	// Fixed Data:
		int m_iExchange;
	// Variable Data:
		// List of associated ZIP's	
	// Strings:
		//	0) Exchange as a string
		//	1) Name of exchange
//}}Data

};
#pragma pack()

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuExchange::GetExchange() const
{
	return m_iExchange;
}

inline LPCTSTR CIuExchange::GetExchangeAsString() const
{
	return GetName();
}

inline LPCTSTR CIuExchange::GetExchangeName() const
{
	return GetString(1);
}

#endif // _ENGINE_EXCHANGE_H_
