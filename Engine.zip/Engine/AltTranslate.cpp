#include "StdAfx.h"
//{{Include
#include "AltTranslate.h"
#include "resource.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "Data\DataFilename.h"
#include "Data\PrefixFile.h"
#include "Common\BigBuffer.h"
#include "Error\Error.h"
#include "Miscellaneous.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuAltTranslate, CIuAltTranslate_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuAltTranslate)
const	CIuVersionNumber versionAltTranslateMax(2000,1,5,304);
const	CIuVersionNumber versionAltTranslateMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ALTTRANSLATE, CIuAltTranslate, CIuAltTranslate_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuAltTranslate, IDS_ENGINE_PPG_ALTTRANSLATE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuAltTranslate, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_FILENAME(CIuAltTranslate, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_ALTTRANSLATE, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuAltTranslate, IDS_ENGINE_PROP_COUNT, GetCount, SetIntNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuAltTranslate, IDS_ENGINE_PROP_COUNT, IDS_ENGINE_PPG_ALTTRANSLATE, 0, INT_MAX, 0)
	IU_ATTRIBUTE_ACTION(CIuAltTranslate, IDS_ENGINE_ACTION_READ, ActionRead, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAltTranslate, IDS_ENGINE_ACTION_READ, IDS_ENGINE_PPG_ALTTRANSLATE, editorAutoUpdate)
	IU_ATTRIBUTE_ACTION(CIuAltTranslate, IDS_ENGINE_ACTION_WRITE, ActionWrite, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuAltTranslate, IDS_ENGINE_ACTION_WRITE, IDS_ENGINE_PPG_ALTTRANSLATE, editorAutoUpdate)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuAltTranslate::CIuAltTranslate() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuAltTranslate::~CIuAltTranslate()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuAltTranslate::ActionRead(const CIuPropertyCollection&, CIuOutput&)
{
	Read();
	return CString("Success");
}

CString CIuAltTranslate::ActionWrite(const CIuPropertyCollection&, CIuOutput&)
{
	Write();
	return CString("Success");
}

void CIuAltTranslate::Append(DWORD dwRecordNo)
{
	if (m_adwInsertNo.GetSize() > 0 && m_adwInsertNo[m_adwInsertNo.GetSize() - 1] > dwRecordNo)
		Error(IU_E_TRANSLATE_OUT_OF_ORDER);
	m_adwInsertNo.SetSize(m_adwInsertNo.GetSize() + 1, 1024);
	m_adwInsertNo.SetAt(m_adwInsertNo.GetSize() - 1, dwRecordNo);
}

void CIuAltTranslate::Clear()
{
	CIuAltTranslate_super::Clear();
	CIuAltTranslate::CommonConstruct();
}

void CIuAltTranslate::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("AltTranslate");
	m_sFilename = "AltTranslate";
	m_adwInsertNo.SetSize(0);
	SetVersion(versionAltTranslateMax);
	//}}Initialize
}

void CIuAltTranslate::Delete(CIuOutput* pOutput)
{
	if (GetFilename().IsEmpty())
		return ;
	CdromDelete(GetFullFilename(), pOutput);
	Empty();
}

void CIuAltTranslate::Empty()
{
	m_adwInsertNo.SetSize(0);
}

int CIuAltTranslate::GetCount() const
{
	return m_adwInsertNo.GetSize();
}

CIuFilename CIuAltTranslate::GetFullFilename() const
{
	CString sName = GetFilename();
	CIuFilename filename = IuDataFilenameSearch(sName, extDataPrefix, this);
	return filename;
}

CIuVersionNumber CIuAltTranslate::GetVersionMax() const
{
	return versionAltTranslateMax;
}

CIuVersionNumber CIuAltTranslate::GetVersionMaxStatic()
{
	return versionAltTranslateMax;
}

CIuVersionNumber CIuAltTranslate::GetVersionMin() const
{
	return versionAltTranslateMin;
}

CIuVersionNumber CIuAltTranslate::GetVersionMinStatic()
{
	return versionAltTranslateMin;
}

void CIuAltTranslate::Read()
{
	CIuFilename filename = GetFullFilename();
	if (!filename.Exists())
	{
		Clear();
		Error(IU_E_ALT_TRANSLATE_FILE_NOT_FOUND, filename);
		return ;
	}

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Open(GetFullFilename(), 16 * 1024, CIuFile::openReadOnly);

	pFile->GetData(this);

	CIuFileVirtualPtr pVFile = pFile->Use();

	CIuBigBuffer buffer;
	buffer.SetSize((int)pVFile->GetLength());

	pVFile->Seek(0);
	pVFile->Read(buffer.GetPtr(), buffer.GetSize());

	SerializeFromMemory(buffer, this);
}

void CIuAltTranslate::Serialize(CArchive& ar)
{
	// We use MFC serialization for performance reasons...
	// NOTE: We are only saving the AltRaw information via MFC serialization
	const DWORD dwCurrentVersion = 0x00000001;
	if (ar.IsStoring())
	{
		ar << dwCurrentVersion;

		DWORD dwCount = GetCount();
		ar << dwCount;

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			DWORD dwTranslate = DWORD(m_adwInsertNo[dw]);
			ar << dwTranslate;
		}
	}
	else
	{
		DWORD dwVersion;
		ar >> dwVersion;
		ASSERT(dwVersion == dwCurrentVersion);

		Clear();

		DWORD dwCount;
		ar >> dwCount;
		m_adwInsertNo.SetSize(dwCount);

		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			DWORD dwTranslate;
			ar >> dwTranslate;
			m_adwInsertNo.SetAt(dw, dwTranslate);
		}
	}
	CIuAltTranslate_super::Serialize(ar);
}

void CIuAltTranslate::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuAltTranslate::Translate(CDWordArray& adw)
{
	int iPointers = adw.GetSize();
	for (int iPointer = 0; iPointer < iPointers; ++iPointer)
	{
		DWORD dwThis = adw[iPointer];
		DWORD dwNew = Translate(dwThis);
		adw.SetAt(iPointer, dwNew);
	}
}

DWORD CIuAltTranslate::Translate(DWORD dwRecordNo) const
{
	int iHi = GetCount() - 1;
	if (iHi <= 0)
		return dwRecordNo;

	if (dwRecordNo < m_adwInsertNo[0])
		return dwRecordNo;
	if (dwRecordNo >= m_adwInsertNo[m_adwInsertNo.GetSize() - 1])
		return dwRecordNo + m_adwInsertNo.GetSize();

	int iLo = 1;
	while (iLo < iHi)
	{
		// NOTE: In order for this loop to exit, we must insure 
		// that if Lo + 1 == Hi, then we will test the Lo value.
		// There can also be several records with the same insert no (several
		// see also's in a row. We need to select the final one.
		int iTest = iLo + (iHi - iLo) / 2;
		ASSERT(iTest >= iLo && iTest <= iHi);

		DWORD dwInsertedAt = m_adwInsertNo[iTest];

		if (dwInsertedAt <= dwRecordNo)
			iLo = iTest + 1;
		else
			iHi = iTest;
	}

	ASSERT(iLo < m_adwInsertNo.GetSize());
	ASSERT(dwRecordNo >= m_adwInsertNo[iLo - 1]);
	ASSERT(dwRecordNo < m_adwInsertNo[iLo]);
	DWORD dwTranslate = dwRecordNo + iLo;

#ifdef _DEBUG
	{
		int iHi = GetCount() - 1;
		int iLo = 0;
		while (iLo <= iHi)
		{
			// NOTE: In order for this loop to exit, we must insure 
			// that if Lo + 1 == Hi, then we will test the Lo + 1 value.
			int iTest = iLo + (iHi - iLo + 1) / 2;
			ASSERT(iTest >= iLo && iTest <= iHi);

			DWORD dwInsertedAt = m_adwInsertNo[iTest] + iTest;
			if (dwTranslate == dwInsertedAt)
			{
				// We should never translate to a see also record!				
				ASSERT(false);
			}
			else if (dwTranslate < dwInsertedAt)
				iHi = iTest - 1;			
			else if (dwTranslate > dwInsertedAt)
				iLo = iTest + 1;
		}
	}
#endif
	return dwTranslate;
}

void CIuAltTranslate::Write() const
{
	CIuBigBuffer buffer;
	SerializeToMemory(buffer, *this, 1024 * 1024);

	CIuPrefixFilePtr pFile;
	pFile.Create();
	pFile->Create(GetFullFilename(), 16 * 1024, CIuFile::openCreate);

	CIuFileVirtualPtr pVFile = pFile->Use();
	pFile->SetData(*this);

	pVFile->Seek(0);
	pVFile->Write(buffer.GetPtr(), buffer.GetSize());
}
