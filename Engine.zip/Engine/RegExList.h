#ifndef _ENGINE_REGEXLIST_H_
#define _ENGINE_REGEXLIST_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_REGEX_H_
#	include "Engine\RegEx.h"
#endif	// _ENGINE_REGEX_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRegEx)
IU_DEFINE_OBJECT_PTR(CIuRegExList)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegExList, CIuObjectNamed }}
// This class manages a list of name/expression pairs. It is used primarily
//		by the query expression parser.
// A list takes the form of a number of comma separated tuples. The list
//		may be empty.
//	Example:
//		[name1]='expression1',[name2],'expression3'
//	
//	Each tuple may be in one of the following forms.
//			name='expression'
//			name
//			'expression'
//			name=
//			='expression'
// It is normal for the name to be bracketed with square brackets.
//	An expression is normally delimited with single or double quotes.
//	If a expression contains special characters (basically anything but 
//		alpha/num),	then the expression must be quoted.
//	As you can see, there must be a way to distinguish between a name and
//		a expression which stand alone. We require that a expression be quoted.
// You can also force the distinction with an equal sign.
//	On output, names are always brackets and expressions are single quoted.
//	When parsing, unrecognized data is ignored.
#define CIuRegExList_super CIuObjectNamed
class IU_CLASS_EXPORT CIuRegExList : public CIuRegExList_super
{
//{{Declare
	DECLARE_SERIAL(CIuRegExList)
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegExList();
	virtual ~CIuRegExList();
	CIuRegExList(const CIuRegExList&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int Find(LPCTSTR pcszName) const;
	CString Get() const;
	CIuRegEx& Get(int iWhich) const;
	int GetCount() const;
	void GetNames(CStringArray& as) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Add(LPCTSTR pcszName, LPCTSTR pcszExpression = 0, int iFlags = regExSimple);
	void Clear();
	virtual void Copy(const CIuObject& object);
	void Remove(int iWhich);
	void Set(LPCTSTR pcszExpression, int iFlags = regExSimple);
	void SetNames(const CStringArray& as);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuRegExList& operator=(const CIuRegExList&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CArray<CIuRegExPtr, CIuRegEx*> m_Tuples;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuRegExList::GetCount() const
{
	return m_Tuples.GetSize();
}

#endif // _ENGINE_REGEXLIST_H_
