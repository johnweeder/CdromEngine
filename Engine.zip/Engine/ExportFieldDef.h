#ifndef _ENGINE_EXPORTFIELDDEF_H_
#define _ENGINE_EXPORTFIELDDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportFieldDef)
class CIuFieldDefSpec;
class CIuExportFieldDefSpec;
//}}Predefines

#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportFieldDef, CIuCollectable }}
#define CIuExportFieldDef_super CIuCollectable

class IU_CLASS_EXPORT CIuExportFieldDef : public CIuExportFieldDef_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportFieldDef)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportFieldDef();           
	virtual ~CIuExportFieldDef();
	CIuExportFieldDef(const CIuExportFieldDef&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CString GetExpression() const;
	void GetExpressionAllowed(CStringArray& as) const;
	int GetLength() const;
	CString GetLongName() const;
	int GetOffset() const;
	CString GetOptions() const;
	CString GetShortName() const;
	virtual CString GetSpecification() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Copy(const CIuObject& object);
	void SetExpression(LPCTSTR pcsz);
	void SetLength(int iLength);
	void SetLongName(LPCTSTR pcsz);
	void SetOffset(int iOffset);
	void SetOptions(LPCTSTR pcsz);
	void SetShortName(LPCTSTR pcsz);
	void SetSpec(LPCTSTR pcszDef);
	void SetSpec(CIuExportFieldDefSpec& spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExportFieldDef& operator=(const CIuExportFieldDef&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CString m_sExpression;
	CString m_sOptions;
	int m_iLength;
	int m_iOffset;
	CString m_sLongName;
	CString m_sShortName;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CString CIuExportFieldDef::GetExpression() const
{
	return m_sExpression;
}

inline int CIuExportFieldDef::GetLength() const
{
	return m_iLength;
}

inline CString CIuExportFieldDef::GetLongName() const
{
	return m_sLongName;
}

inline int CIuExportFieldDef::GetOffset() const
{
	return m_iOffset;
}

inline CString CIuExportFieldDef::GetOptions() const
{
	return m_sOptions;
}

inline CString CIuExportFieldDef::GetShortName() const
{
	return m_sShortName;
}

#endif // _ENGINE_EXPORTFIELDDEF_H_
