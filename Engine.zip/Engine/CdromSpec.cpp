#include "StdAfx.h"
//{{Include
#include "CdromSpec.h"
#include "CdromProductSpecDft.h"
#include "CdromFormatSpecDft.h"
#include "UserInterfaceSpec.h"
#include "ReleaseNoteSpec.h"
#include "RegistrationSpec.h"
#include "SplashSpec.h"
#include "CdromStripSpec.h"
#include "TokenSpec.h"
#include "AltSpec.h"
#include "BlobSpec.h"
#include "MeterSpec.h"
#include "GeoSpec.h"
#include "AddressSpec.h"
#include "SicSpec.h"
#include "CdromSpecDft.h"
#include "CdromSelectDlg.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "Common\String.h"
#include "Meter.h"
#include "Sic.h"
#include "Address.h"
#include "Geo.h"
#include "Token.h"
#include "UserInterface.h"
#include "Registration.h"
#include "ReleaseNote.h"
#include "Splash.h"
#include "CdromStrip.h"
#include "Blob.h"
#include "Alt.h"
#include "BTree.h"
#include "BTreeSpec.h"
#include "ExportDef.h"
#include "ExportDefSpec.h"
#include "ReportDef.h"
#include "ReportDefSpec.h"
#include "StatesRaw.h"
#include "Common\SortedStringArray.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromSpec, CIuCdromSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMSPEC, CIuCdromSpec, CIuCdromSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_ADDRESS, GetAddress_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_ADDRESS, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_SIC, GetSic_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_SIC, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_GEO, GetGeo_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_GEO, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_USERINTERFACE, GetUserInterface_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_USERINTERFACE, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_SPLASH, GetSplash_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_SPLASH, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_REGISTRATION, GetRegistration_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuCdromSpec, IDS_ENGINE_PROP_REGISTRATION, editorUsePropName)

	IU_ATTRIBUTE_PAGE(CIuCdromSpec, IDS_ENGINE_PPG_CDROMSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_NAME, GetName, SetName, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_NAME, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_FORMAT, GetFormat, SetFormat, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_FORMAT, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_PRODUCT, GetProduct, SetProduct, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_PRODUCT, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_RELEASE, GetRelease, SetRelease, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_RELEASE, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_APPLICATION, GetApplication, SetApplication, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_APPLICATION, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_TITLE, GetTitle, SetTitle, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_TITLE, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_DESCRIPTION, GetDescription, SetDescription, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_DESCRIPTION, IDS_ENGINE_PPG_CDROMSPEC, 5, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromSpec, IDS_ENGINE_PROP_OPTIONS, GetOptions, SetOptions, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromSpec, IDS_ENGINE_PROP_OPTIONS, IDS_ENGINE_PPG_CDROMSPEC, 1, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCdromSpec, IDS_ENGINE_PROP_SPLITSIZE, GetSplitSize, SetSplitSize, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCdromSpec, IDS_ENGINE_PROP_SPLITSIZE, IDS_ENGINE_PPG_CDROMSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_HASDATABASE, HasDatabase, SetHasDatabase, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_HASDATABASE, IDS_ENGINE_PPG_CDROMSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCdromSpec, IDS_ENGINE_PROP_GROUPNO, GetGroupNo, SetGroupNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCdromSpec, IDS_ENGINE_PROP_GROUPNO, IDS_ENGINE_PPG_CDROMSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCdromSpec, IDS_ENGINE_PROP_GROUPCOUNT, GetGroupCount, SetGroupCount, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCdromSpec, IDS_ENGINE_PROP_GROUPCOUNT, IDS_ENGINE_PPG_CDROMSPEC, INT_MIN, INT_MAX, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_NOSPOUSE, NoSpouse, SetNoSpouse, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_NOSPOUSE, IDS_ENGINE_PPG_CDROMSPEC, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_NONOSOLICIT, NoNoSolicit, SetNoNoSolicit, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuCdromSpec, IDS_ENGINE_PROP_NONOSOLICIT, IDS_ENGINE_PPG_CDROMSPEC, 0)

	IU_ATTRIBUTE_PAGE(CIuCdromSpec, IDS_ENGINE_PPG_CDROMSPEC_STATES, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING_ARRAY(CIuCdromSpec, IDS_ENGINE_PROP_STATES, GetStates, SetStates, 0)
	IU_ATTRIBUTE_EDITOR_STRING_ARRAY(CIuCdromSpec, IDS_ENGINE_PROP_STATES, IDS_ENGINE_PPG_CDROMSPEC_STATES, 10, editorAdd|editorDelete|editorMove|editorEdit)
	IU_ATTRIBUTE_PROPERTY_INT(CIuCdromSpec, IDS_ENGINE_PROP_MAXRECORDS, GetMaxRecords, SetMaxRecords, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuCdromSpec, IDS_ENGINE_PROP_MAXRECORDS, IDS_ENGINE_PPG_CDROMSPEC_STATES, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdromSpec::CIuCdromSpec()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromSpec::CIuCdromSpec(LPCTSTR pcszName, int iMaxRecords)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	VERIFY(FromName(pcszName) >= 0);
	SetMaxRecords(iMaxRecords);
}

CIuCdromSpec::CIuCdromSpec(int iIndex, int iMaxRecords)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	FromIndex(iIndex);
	SetMaxRecords(iMaxRecords);
}

CIuCdromSpec::~CIuCdromSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuCdromSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sProduct = "";
	m_sRelease = "";
	m_sApplication = "";
	m_sFilename = "";
	m_sTitle = "";
	m_sDescription = "";
	m_asStates.RemoveAll();
	m_sOptions = "";
	m_sFormat = "";
	m_iMaxRecords = -1;
	m_iFormatNo = 0;
	m_iSplitSize = 0;
	m_iProductNo = 0;
	m_fHasDatabase = false;
	SetVersion(IU_VERSION);
	m_iGroupCount = 1;
	m_iGroupNo = 0;
	m_fNoSpouse = false;
	m_fNoNoSolicit = false;
	//}}Initialize
}

int CIuCdromSpec::FindAlt(LPCTSTR pcszAlt)
{
	ASSERT(AfxIsValidString(pcszAlt));
	for (int iAlt = 0; iAlt < GetAltCount(); ++iAlt)
	{
		if (GetAlt(iAlt).GetName().CompareNoCase(pcszAlt) == 0)
			return iAlt;
	}
	return -1;
}

int CIuCdromSpec::FindBTree(LPCTSTR pcszBTree)
{
	ASSERT(AfxIsValidString(pcszBTree));
	for (int iBTree = 0; iBTree < GetBTreeCount(); ++iBTree)
	{
		if (GetBTree(iBTree).GetName().CompareNoCase(pcszBTree) == 0)
			return iBTree;
	}
	return -1;
}

int CIuCdromSpec::FindProductRelease(LPCTSTR pcszProduct, LPCTSTR pcszRelease)
{
	int iProduct = CIuCdromProductSpecDft::Find(pcszProduct);
	ASSERT(iProduct >= 0);
	const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
	ASSERT(pProduct);
	return FindProductRelease(pProduct->m_iProduct, pcszRelease);
}

int CIuCdromSpec::FindProductRelease(int iProductNo, LPCTSTR pcszRelease)
{
	ASSERT(AfxIsValidString(pcszRelease));
	int iWhich = CIuCdromSpecDft::Find(iProductNo, pcszRelease);
	if (iWhich < 0)
		return iWhich;
	const CIuCdromSpecDft* pSpec = CIuCdromSpecDft::Get(iWhich);
	if (pSpec == 0)
		return -1;
	return iWhich;
}

int CIuCdromSpec::FindToken(LPCTSTR pcszToken)
{
	ASSERT(AfxIsValidString(pcszToken));
	for (int iToken = 0; iToken < GetTokenCount(); ++iToken)
	{
		if (GetToken(iToken).GetName().CompareNoCase(pcszToken) == 0)
			return iToken;
	}
	return -1;
}

void CIuCdromSpec::FromIndex(int iWhich)
{
	FromSpec(CIuCdromSpecDft::Get(iWhich));
}

int CIuCdromSpec::FromName(LPCTSTR pcszName)
{
	ASSERT(AfxIsValidString(pcszName));
	int iWhich = CIuCdromSpecDft::Find(pcszName);
	if (iWhich < 0)
		return iWhich;
	const CIuCdromSpecDft* pSpec = CIuCdromSpecDft::Get(iWhich);
	if (pSpec == 0)
		return -1;
	FromSpec(pSpec);
	return iWhich;
}

int CIuCdromSpec::FromProductRelease(LPCTSTR pcszProduct, LPCTSTR pcszRelease)
{
	int iSpec = FindProductRelease(pcszProduct, pcszRelease);
	if (iSpec < 0)
		return -1;
	FromIndex(iSpec);
	return iSpec;
}

int CIuCdromSpec::FromProductRelease(int iProductNo, LPCTSTR pcszRelease)
{
	int iSpec = FindProductRelease(iProductNo, pcszRelease);
	if (iSpec < 0)
		return -1;
	FromIndex(iSpec);
	return iSpec;
}

void CIuCdromSpec::FromSpec(const CIuCdromSpecDft* pSpec)
{
	ASSERT(pSpec);

	int iProduct = CIuCdromProductSpecDft::Find(pSpec->m_iProductNo);
	ASSERT(iProduct >= 0);
	const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
	ASSERT(pProduct);

	int iFormat = CIuCdromFormatSpecDft::Find(pProduct->m_iFormatNo);
	ASSERT(iFormat >= 0);
	const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iFormat);
	ASSERT(pFormat);

	// Use the release as the full product name
	SetName(pSpec->m_pcszCdrom);
	if (pSpec->m_pidCdrom)
		SetID(*pSpec->m_pidCdrom);
	else
		SetID(CIuID::Create());
	SetProduct(pProduct->m_pcszProduct);
	SetProductNo(pSpec->m_iProductNo);
	SetRelease(pSpec->m_pcszRelease);
	SetTitle(pSpec->m_pcszTitle);
	SetFilename(pSpec->m_pcszFilename);
	SetFormat(pFormat->m_pcszFormat);
	SetFormatNo(pFormat->m_iFormat);
	SetGroupNo(pSpec->m_iGroupNo);
	SetGroupCount(pSpec->m_iGroupCount);
	CString sOptions = pFormat->m_pcszOptions;
	if (!_tcsisempty(pProduct->m_pcszOptions))
	{
		if (!sOptions.IsEmpty())
			sOptions += _T(",");
		sOptions += pProduct->m_pcszOptions;
	}
	SetOptions(sOptions);

	CIuOptions Options = GetOptions();

	SetNoSpouse(Options.Find(_T("nospouse")) >= 0);
	SetNoNoSolicit(Options.Find(_T("nonosolict")) >= 0);

	SetHasDatabase(pFormat->m_fHasDatabase);
	SetSplitSize(pProduct->m_iSplitSize);

	m_Attributes.RemoveAll();
	for (int iAttribute = 0; pProduct->m_apcszAttributes[iAttribute]; ++iAttribute)
	{
		LPCTSTR pcszName = pProduct->m_apcszAttributes[iAttribute];
		LPCTSTR pcszValue = _tcschr(pcszName, '\0') + 1;
		m_Attributes.SetAt(pcszName, pcszValue);
	}

	ASSERT(AfxIsValidString(pProduct->m_pcszStates));
	CStringArray asStatesNotSorted;
	StringAsStringArray(pProduct->m_pcszStates, asStatesNotSorted);
	CIuSortedStringArray asStates;
	asStates.SetDedup();
	asStates.SetNoCase();
	asStates.Add(asStatesNotSorted);
	SetStates(asStates);

	if (pProduct->m_pcszDescription != szDescriptionGenerate)
		SetDescription(pProduct->m_pcszDescription);
	else
	{
		CString sDescription;
		if (IncludeBusiness() && IncludeResidential())
			sDescription = _T("This database includes businesses and residences in:\n");
		else if (IncludeBusiness())
			sDescription = _T("This database includes businesses in:\n");
		else if (IncludeResidential())
			sDescription = _T("This database includes residences in:\n");
		else 
			sDescription = _T("This database includes records in:\n");

		int iStates = asStates.GetSize();
		for (int iState = 0; iState < iStates; ++iState)
		{
			if (iState)			
				sDescription += _T(", ");
			sDescription += asStates[iState];
		}
		sDescription += _T("\n");
		sDescription += GetRelease();
		SetDescription(sDescription);
	}

	SetApplication(pFormat->m_pcszApplication);

	// NOTE: The order of creation is important
	m_pUserInterface.Release();
	if (pFormat->m_iUserInterfaceNo != uiNone)
	{
		m_pUserInterface.Create();
		m_pUserInterface->FromNo(this, pFormat->m_iUserInterfaceNo);
	}
	m_pRegistration.Release();
	if (pProduct->m_iRegistrationNo != registrationNone)
	{
		m_pRegistration.Create();
		m_pRegistration->FromNo(this, pProduct->m_iRegistrationNo);
	}
	m_pSplash.Release();
	if (pProduct->m_iSplashNo != splashNone)
	{
		m_pSplash.Create();
		m_pSplash->FromNo(this, pProduct->m_iSplashNo);
	}

	// Add ExportDefs
	RemoveAllExportDefs();
	const int* pExportDefs = pProduct->m_piExportDefs;
	ASSERT(pExportDefs);
	for (; *pExportDefs != exportDefNone; ++pExportDefs)
	{	
		CIuExportDefSpecPtr pExportDef;
		pExportDef.Create();
		pExportDef->FromNo(this, *pExportDefs);
		m_apExportDefs.Add(pExportDef);
	}

	// Add Meters
	RemoveAllMeters();
	if (pSpec->m_iMeterNo == meterAll)
	{
		for (int iMeter = meterFirst; iMeter < meterLast; ++iMeter)
		{	
			CIuMeterSpecPtr pMeter;
			pMeter.Create();
			pMeter->FromNo(this, iMeter);
			m_apMeters.Add(pMeter);
		}
	}
	else if (pSpec->m_iMeterNo != meterNone)
	{
		CIuMeterSpecPtr pMeter;
		pMeter.Create();
		pMeter->FromNo(this, pSpec->m_iMeterNo);
		m_apMeters.Add(pMeter);
		if (pSpec->m_piOtherMeterNo)
		{
			for (int* piOtherMeterNo = pSpec->m_piOtherMeterNo; *piOtherMeterNo != meterNone; ++piOtherMeterNo)
			{
				CIuMeterSpecPtr pMeter;
				pMeter.Create();
				pMeter->FromNo(this, *piOtherMeterNo);
				m_apMeters.Add(pMeter);
			}
		}
	}

	// Add ReleaseNotes
	RemoveAllReleaseNotes();
	if (pProduct->m_iReleaseNoteNo == releaseNoteAll)
	{
		for (int iReleaseNote = releaseNoteFirst; iReleaseNote < releaseNoteLast; ++iReleaseNote)
		{	
			CIuReleaseNoteSpecPtr pReleaseNote;
			pReleaseNote.Create();
			pReleaseNote->FromNo(this, iReleaseNote);
			m_apReleaseNotes.Add(pReleaseNote);
		}
	}
	else if (pProduct->m_iReleaseNoteNo != releaseNoteNone)
	{
		CIuReleaseNoteSpecPtr pReleaseNote;
		pReleaseNote.Create();
		pReleaseNote->FromNo(this, pProduct->m_iReleaseNoteNo);
		m_apReleaseNotes.Add(pReleaseNote);
	}

	// Add ReportDefs
	RemoveAllReportDefs();
	const int* pReportDefs = pProduct->m_piReportDefs;
	for (; *pReportDefs != reportDefNone; ++pReportDefs)
	{	
		CIuReportDefSpecPtr pReportDef;
		pReportDef.Create();
		pReportDef->FromNo(this, *pReportDefs);
		m_apReportDefs.Add(pReportDef);
	}

	// Add blobs
	RemoveAllBlobs();
	const int* pBlobs = pProduct->m_piBlobs;
	for (; *pBlobs != blobNone; ++pBlobs)
	{	
		CIuBlobSpecPtr pBlob;
		pBlob.Create();
		pBlob->FromNo(this, *pBlobs);
		m_apBlobs.Add(pBlob);
	}

	// Add alts
	RemoveAllAlts();
	const int* piAlts = pFormat->m_piAlts;
	for (; *piAlts != altNone; ++piAlts)
	{	
		CIuAltSpecPtr pAlt;
		pAlt.Create();
		pAlt->FromNo(this, *piAlts);
		m_apAlts.Add(pAlt);
	}

	m_pGeo.Release();
	if (pFormat->m_iGeoNo != geoNone)
	{
		m_pGeo.Create();
		m_pGeo->FromNo(this, pFormat->m_iGeoNo);
	}

	m_pSic.Release();
	if (pFormat->m_iSicNo != sicNone)
	{
		m_pSic.Create();
		m_pSic->FromNo(this, pFormat->m_iSicNo);
	}

	m_pAddress.Release();
	if (pFormat->m_iAddressNo != addressNone)
	{
		m_pAddress.Create();
		m_pAddress->FromNo(this, pFormat->m_iAddressNo);
	}
	// Add strips
	RemoveAllStrips();
	const int* piStrips = pFormat->m_piStrips;
	for (; *piStrips != cdromStripNone; ++piStrips)
	{	
		CIuCdromStripSpecPtr pStrip;
		pStrip.Create();
		pStrip->FromNo(this, *piStrips);
		m_apStrips.Add(pStrip);
	}

	// Add Tokens
	RemoveAllTokens();
	const int* pTokens = pFormat->m_piTokens;
	for (; *pTokens != tokenNone; ++pTokens)
	{	
		CIuTokenSpecPtr pToken;
		pToken.Create();
		pToken->FromNo(this, *pTokens);
		m_apTokens.Add(pToken);
	}

	// Add BTrees
	RemoveAllBTrees();
	const int* pBTrees = pFormat->m_piBTrees;
	for (; *pBTrees != btreeNone; ++pBTrees)
	{	
		CIuBTreeSpecPtr pBTree;
		pBTree.Create();
		pBTree->FromNo(this, *pBTrees);
		m_apBTrees.Add(pBTree);
	}
}

CIuObject* CIuCdromSpec::GetAddress_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pAddress.Ptr()));
}

CIuAltSpec& CIuCdromSpec::GetAlt(int iAlt) const
{
	ASSERT(iAlt >= 0 && iAlt < GetAltCount());
	return *m_apAlts[iAlt];
}

int CIuCdromSpec::GetAltCount() const
{
	return m_apAlts.GetSize();	
}

void CIuCdromSpec::GetApplications(CStringArray& as)
{
	// Build a list of applications
	CIuSortedStringArray asApplications;
	asApplications.SetNoCase();
	asApplications.SetDedup();

	for (int iSpec = 0; iSpec < CIuCdromFormatSpecDft::GetCount(); ++iSpec)
	{
		const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iSpec);
		asApplications.Add(pFormat->m_pcszApplication);
	}
	as.Copy(asApplications);
}

POSITION CIuCdromSpec::GetAttributeFirst() const
{
	return m_Attributes.GetStartPosition();
}

void CIuCdromSpec::GetAttributeNext(POSITION& pos, CString& sName, CString& sValue) const
{
	m_Attributes.GetNextAssoc(pos, sName, sValue);
}

CIuBlobSpec& CIuCdromSpec::GetBlob(int iBlob) const
{
	ASSERT(iBlob >= 0 && iBlob < GetBlobCount());
	return *m_apBlobs[iBlob];
}

int CIuCdromSpec::GetBlobCount() const
{
	return m_apBlobs.GetSize();	
}

CIuBTreeSpec& CIuCdromSpec::GetBTree(int iBTree) const
{
	ASSERT(iBTree >= 0 && iBTree < GetBTreeCount());
	return *m_apBTrees[iBTree];
}

int CIuCdromSpec::GetBTreeCount() const
{
	return m_apBTrees.GetSize();	
}

int CIuCdromSpec::GetCount()
{
	return CIuCdromSpecDft::GetCount();
}

CIuExportDefSpec& CIuCdromSpec::GetExportDef(int iExportDef) const
{
	ASSERT(iExportDef >= 0 && iExportDef < GetExportDefCount());
	return *m_apExportDefs[iExportDef];
}

int CIuCdromSpec::GetExportDefCount() const
{
	return m_apExportDefs.GetSize();	
}

CIuObject* CIuCdromSpec::GetGeo_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pGeo.Ptr()));
}

CIuMeterSpec& CIuCdromSpec::GetMeter(int iMeter) const
{
	ASSERT(iMeter >= 0 && iMeter < GetMeterCount());
	return *m_apMeters[iMeter];
}

int CIuCdromSpec::GetMeterCount() const
{
	return m_apMeters.GetSize();	
}

void CIuCdromSpec::GetProductGroups(LPCTSTR pcszApplication, LPCTSTR pcszRelease, CStringArray& as)
{
	// Build a list of Releases
	CIuSortedStringArray asProductGroups;
	asProductGroups.SetNoCase();
	asProductGroups.SetDedup();

	for (int iSpec = 0; iSpec < CIuCdromSpecDft::GetCount(); ++iSpec)
	{
		const CIuCdromSpecDft* pSpec = CIuCdromSpecDft::Get(iSpec);

		int iProduct = CIuCdromProductSpecDft::Find(pSpec->m_iProductNo);
		ASSERT(iProduct >= 0);
		const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
		ASSERT(pProduct);

		int iFormat = CIuCdromFormatSpecDft::Find(pProduct->m_iFormatNo);
		ASSERT(iFormat >= 0);
		const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iFormat);
		ASSERT(pFormat);

		if (_tcsicmp(pFormat->m_pcszApplication, pcszApplication) != 0)
			continue;
		if (_tcsicmp(pSpec->m_pcszRelease, pcszRelease) != 0)
			continue;

		asProductGroups.Add(pProduct->m_pcszProductGroup);
	}
	as.Copy(asProductGroups);
}

void CIuCdromSpec::GetProducts(LPCTSTR pcszApplication, LPCTSTR pcszRelease, LPCTSTR pcszProductGroup, CStringArray& as)
{
	// Build a list of Releases
	CIuSortedStringArray asProducts;
	asProducts.SetNoCase();
	asProducts.SetDedup();

	for (int iSpec = 0; iSpec < CIuCdromSpecDft::GetCount(); ++iSpec)
	{
		const CIuCdromSpecDft* pSpec = CIuCdromSpecDft::Get(iSpec);

		int iProduct = CIuCdromProductSpecDft::Find(pSpec->m_iProductNo);
		ASSERT(iProduct >= 0);
		const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
		ASSERT(pProduct);

		int iFormat = CIuCdromFormatSpecDft::Find(pProduct->m_iFormatNo);
		ASSERT(iFormat >= 0);
		const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iFormat);
		ASSERT(pFormat);

		if (_tcsicmp(pFormat->m_pcszApplication, pcszApplication) != 0)
			continue;
		if (_tcsicmp(pSpec->m_pcszRelease, pcszRelease) != 0)
			continue;
		if (_tcsicmp(pProduct->m_pcszProductGroup, pcszProductGroup) != 0)
			continue;

		asProducts.Add(pProduct->m_pcszProduct);
	}
	as.Copy(asProducts);
}

CIuObject* CIuCdromSpec::GetRegistration_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRegistration.Ptr()));
}

CIuReleaseNoteSpec& CIuCdromSpec::GetReleaseNote(int iReleaseNote) const
{
	ASSERT(iReleaseNote >= 0 && iReleaseNote < GetReleaseNoteCount());
	return *m_apReleaseNotes[iReleaseNote];
}

int CIuCdromSpec::GetReleaseNoteCount() const
{
	return m_apReleaseNotes.GetSize();	
}

void CIuCdromSpec::GetReleases(LPCTSTR pcszApplication, CStringArray& as)
{
	// Build a list of Releases
	CIuSortedStringArray asReleases;
	asReleases.SetNoCase();
	asReleases.SetDedup();

	for (int iSpec = 0; iSpec < CIuCdromSpecDft::GetCount(); ++iSpec)
	{
		const CIuCdromSpecDft* pSpec = CIuCdromSpecDft::Get(iSpec);

		int iProduct = CIuCdromProductSpecDft::Find(pSpec->m_iProductNo);
		ASSERT(iProduct >= 0);
		const CIuCdromProductSpecDft* pProduct = CIuCdromProductSpecDft::Get(iProduct);
		ASSERT(pProduct);

		int iFormat = CIuCdromFormatSpecDft::Find(pProduct->m_iFormatNo);
		ASSERT(iFormat >= 0);
		const CIuCdromFormatSpecDft* pFormat = CIuCdromFormatSpecDft::Get(iFormat);
		ASSERT(pFormat);

		if (_tcsicmp(pFormat->m_pcszApplication, pcszApplication) != 0)
			continue;

		asReleases.Add(pSpec->m_pcszRelease);
	}
	as.Copy(asReleases);
}

CIuReportDefSpec& CIuCdromSpec::GetReportDef(int iReportDef) const
{
	ASSERT(iReportDef >= 0 && iReportDef < GetReportDefCount());
	return *m_apReportDefs[iReportDef];
}

int CIuCdromSpec::GetReportDefCount() const
{
	return m_apReportDefs.GetSize();	
}

CIuObject* CIuCdromSpec::GetSic_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSic.Ptr()));
}

CIuObject* CIuCdromSpec::GetSplash_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSplash.Ptr()));
}

void CIuCdromSpec::GetStates(CStringArray& as) const
{
	as.Copy(m_asStates);
}

CIuCdromStripSpec& CIuCdromSpec::GetStrip(int iStrip) const
{
	ASSERT(iStrip >= 0 && iStrip < GetStripCount());
	return *m_apStrips[iStrip];
}

int CIuCdromSpec::GetStripCount() const
{
	return m_apStrips.GetSize();	
}

CIuTokenSpec& CIuCdromSpec::GetToken(int iToken) const
{
	ASSERT(iToken >= 0 && iToken < GetTokenCount());
	return *m_apTokens[iToken];
}

int CIuCdromSpec::GetTokenCount() const
{
	return m_apTokens.GetSize();	
}

CIuObject* CIuCdromSpec::GetUserInterface_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pUserInterface.Ptr()));
}

bool CIuCdromSpec::IncludeBusiness() const
{
	CIuOptions Options = GetOptions();
	return Options.Find(_T("business")) >= 0;
}	

bool CIuCdromSpec::IncludeResidential() const
{
	CIuOptions Options = GetOptions();
	return Options.Find(_T("residential")) >= 0;
}

bool CIuCdromSpec::IncludeSample() const
{
	CIuOptions Options = GetOptions();
	return Options.Find(_T("sample")) >= 0;
}

void CIuCdromSpec::RemoveAllAlts() 
{
	m_apAlts.RemoveAll();
}

void CIuCdromSpec::RemoveAllBlobs() 
{
	m_apBlobs.RemoveAll();
}

void CIuCdromSpec::RemoveAllBTrees() 
{
	m_apBTrees.RemoveAll();
}

void CIuCdromSpec::RemoveAllExportDefs() 
{
	m_apExportDefs.RemoveAll();
}

void CIuCdromSpec::RemoveAllMeters() 
{
	m_apMeters.RemoveAll();
}

void CIuCdromSpec::RemoveAllReleaseNotes() 
{
	m_apReleaseNotes.RemoveAll();
}

void CIuCdromSpec::RemoveAllReportDefs() 
{
	m_apReportDefs.RemoveAll();
}

void CIuCdromSpec::RemoveAllStrips() 
{
	m_apStrips.RemoveAll();
}

void CIuCdromSpec::RemoveAllTokens() 
{
	m_apTokens.RemoveAll();
}

bool CIuCdromSpec::SelectDlg(CWnd* pParent)
{
	CIuCdromSelectDlg dlg(pParent);
	dlg.SetMaxRecords(GetMaxRecords());
	dlg.SetSpec(GetName());
	if (dlg.DoModal() != IDOK)
		return false;
	int iSpec = dlg.GetSpec();
	if (iSpec < 0)
		return false;
	SetMaxRecords(dlg.GetMaxRecords());
	FromIndex(iSpec);
	return true;
}

void CIuCdromSpec::SetApplication(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sApplication = pcsz;
}

void CIuCdromSpec::SetDescription(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDescription = pcsz;
}

void CIuCdromSpec::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCdromSpec::SetFormat(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFormat = pcsz;
}

void CIuCdromSpec::SetFormatNo(int iFormatNo)
{
	m_iFormatNo = iFormatNo;
}

void CIuCdromSpec::SetGroupCount(int iGroupCount)
{
	m_iGroupCount = iGroupCount;
}

void CIuCdromSpec::SetGroupNo(int iGroupNo)
{
	m_iGroupNo = iGroupNo;
}

void CIuCdromSpec::SetHasDatabase(bool f)
{
	m_fHasDatabase = f;
}

void CIuCdromSpec::SetMaxRecords(int iMaxRecords)
{
	ASSERT(iMaxRecords != 0);
	m_iMaxRecords = iMaxRecords;
}

void CIuCdromSpec::SetNoNoSolicit(bool f)
{
	m_fNoNoSolicit = f;
}

void CIuCdromSpec::SetNoSpouse(bool f)
{
	m_fNoSpouse = f;
}

void CIuCdromSpec::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuCdromSpec::SetProduct(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sProduct = pcsz;
}

void CIuCdromSpec::SetProductNo(int iProductNo)
{
	m_iProductNo = iProductNo;
}

void CIuCdromSpec::SetRelease(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sRelease = pcsz;
}

void CIuCdromSpec::SetSplitSize(int iSplitSize)
{
	m_iSplitSize = iSplitSize;
}

void CIuCdromSpec::SetStates(const CStringArray& as)
{
#ifdef _DEBUG
	for (int iState = 0; iState < as.GetSize(); ++iState)
	{
		ASSERT(CIuStatesRaw::FindAbbr(as[iState]) != 0);
	}
#endif
	m_asStates.Copy(as);
}

void CIuCdromSpec::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}

