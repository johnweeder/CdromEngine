 #include "stdafx.h"
//{{Include
#include "Engine.h"
#include "resource.h"
#include "Data\resource.h"
#include "Data\SearchWhereDlg.h"
#include "Data\ObjectDatabase.h"
#include "Database.h"
#include "DatabaseList.h"
#include "Databases.h"
#include "Listeners.h"
#include "ReleaseNotes.h"
#include "Registrations.h"
#include "Queries.h"
#include "SimpleQuery.h"
#include "Version.h" 
#include "Builds.h"
#include "Meters.h"
#include "BTree.h"
#include "Token.h"
#include "IDs.h"
#include "Error\Error.h"
#include "Ui\ProgressDlg.h"
#include "Common\String.h"
#include "Common\Crc32.h"
#include "ExportDefs.h"
#include "ExportDef.h"
#include "Common\Path.h"
#include "Common\FilenameList.h"
#include "Export.h"
#include "Data\Output.h"
#include "Gps.h"
#include "Tapi.h"
#include "Exporters.h"
#include "ReportDefs.h"
#include "Reporters.h"
#include "UserInterfaces.h"
#include "Splashes.h"
#include "Blobs.h"
#include "Common\Options.h"
#include "Common\SysInfo.h"
#include "SourceProvider.h"
#include "Data\DataFilename.h"
#include "Data\XmlConnectDlg.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE												   
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuEngine, CIuEngine_super, 0)
IU_IMPLEMENT_OBJECT_PTR(CIuEngine)
//}}Implement


IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_ENGINE, CIuEngine, CIuEngine_super)
//{{AttributeMap
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_DATABASES, GetDatabases_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_GPS, GetGps_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_TAPI, GetTapi_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_EXPORTERS, GetExporters_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_BUILDS, GetBuilds_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_EXPORTDEFS, GetExportDefs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_METERS, GetMeters_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_QUERIES, GetQueries_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_USERINTERFACES, GetUserInterfaces_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_SPLASHES, GetSplashes_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_BLOBS, GetBlobs_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_RELEASENOTES, GetReleaseNotes_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_REGISTRATIONS, GetRegistrations_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_REPORTERS, GetReporters_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuEngine, IDS_ENGINE_PROP_REPORTDEFS, GetReportDefs_, SetObjectNotSupported, 0)

	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_DATABASES, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_GPS, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_EXPORTERS, editorReadOnly)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_BUILDS, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_EXPORTDEFS, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_TAPI, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_QUERIES, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_USERINTERFACES, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_SPLASHES, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_BLOBS, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_RELEASENOTES, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_REGISTRATIONS, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_REPORTERS, editorUsePropName)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_REPORTDEFS, editorUsePropName)

	IU_ATTRIBUTE_ACTION(CIuEngine, IDS_ENGINE_ACTION_REFRESH, ActionRefresh, 0)
	IU_ATTRIBUTE_ACTION(CIuEngine, IDS_ENGINE_ACTION_CREATEEXPORT, ActionCreateExport, 0)
	IU_ATTRIBUTE_ACTION(CIuEngine, IDS_ENGINE_ACTION_CREATESELECT, ActionCreateSelect, 0)
	IU_ATTRIBUTE_ACTION(CIuEngine, IDS_ENGINE_ACTION_CREATEDATABASELIST, ActionCreateDatabaseList, 0)

	IU_ATTRIBUTE_PAGE(CIuEngine, IDS_ENGINE_PPG_ENGINE, 50, 0)
	IU_ATTRIBUTE_ACTION(CIuEngine, IDS_ENGINE_ACTION_SEARCHWHERE, ActionSearchWhere, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuEngine, IDS_ENGINE_ACTION_SEARCHWHERE, IDS_ENGINE_PPG_ENGINE, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuEngine, IDS_ENGINE_ACTION_REFRESH, IDS_ENGINE_PPG_ENGINE, editorAutoUpdate)
	IU_ATTRIBUTE_EDITOR_OBJECT(CIuEngine, IDS_ENGINE_PROP_METERS, 0)
	IU_ATTRIBUTE_PROPERTY_BOOL(CIuEngine, IDS_ENGINE_PROP_DEBUG, IsDebug, SetDebug, 0)
	IU_ATTRIBUTE_EDITOR_BOOL(CIuEngine, IDS_ENGINE_PROP_DEBUG, IDS_ENGINE_PPG_ENGINE, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

static LPCTSTR apcszIpSubNets[] = 
{
	_T("176.16."),
	_T("10.205."),
	_T("10.35."),
	_T("10.8."),
	0
};

static TCHAR szDomain[] = _T("NEBRASKA");

struct CIuEngineRights
{
	LPCTSTR m_pcszName;
	int m_iRights;
};

const int iRightsDevelopers	= engineRightsAll;
const int iRightsTesters		= engineRightsInternal|engineRightsSuper|engineRightsMultiUserLicense|engineRightsMeterAdmin|engineRightsDateRange|engineRightsTest;
const int iRightsTechSupport	= engineRightsInternal|engineRightsMultiUserLicense|engineRightsDateRange|engineRightsTest|engineRightsMeterAdmin;
const int iRightsManager		= engineRightsInternal|engineRightsMultiUserLicense|engineRightsDateRange|engineRightsMeterAdmin;

static CIuEngineRights aRights[] =
{
	// Developers
	{ _T("JohnW"),			iRightsDevelopers },
	{ _T("CDBuild"),		iRightsDevelopers },	
	{ _T("TomMas"),		iRightsDevelopers },
	{ _T("JimKu"),			iRightsDevelopers },
	{ _T("JerryL"),		iRightsDevelopers },
	{ _T("MichaelG"),		iRightsDevelopers },
	{ _T("KenK"),			iRightsDevelopers },
	{ _T("ToddT"),			iRightsDevelopers },
	{ _T("CurtS"),			iRightsDevelopers },
	{ _T("JaredT"),		iRightsDevelopers },
	{ _T("JerryL"),		iRightsDevelopers },

	// Testers
	{ _T("JohnM"),			iRightsTesters },
	{ _T("BarbaraH"),		iRightsTesters },
	{ _T("RodneyR"),		iRightsTesters },
	{ _T("MikeW"),			iRightsTesters },
	{ _T("DougC"),			iRightsTesters },
	{ _T("ThomasB"),		iRightsTesters },

	// Tech support
	{ _T("BradF"),			iRightsTechSupport },
	{ _T("RobertB"),		iRightsTechSupport },
	{ _T("JamesD"),		iRightsTechSupport },
	{ _T("KirtT"),			iRightsTechSupport },
	{ _T("NathanV"),		iRightsTechSupport },

	// Managers
	{ _T("IshanA"),		iRightsManager|engineRightsSuper|engineRightsMultiUserLicense },
	{ _T("RobMa"),			iRightsManager },
	{ _T("StevenK"),		iRightsManager },
	{ _T("MarkV"),			iRightsManager },
	{ _T("MarkMu"),		iRightsManager },
	{ _T("DJD"),			iRightsManager },
	{ _T("PhyllisD"),		iRightsManager },
	{ _T("SimonD"),		iRightsManager },
	{ _T("JeanH"),			iRightsManager },
	{ _T("Theressm"),		iRightsManager },
	{ _T("DanielB"),		iRightsManager },

	{ 0 , 0}
};

static int iObjectDatabaseInit;

CIuEngine::CIuEngine()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	m_fConnected = false;
	CommonConstruct();
	if (iObjectDatabaseInit == 0)
	{
		VERIFY(CIuObjectDatabase::Initialize());
	}
	++iObjectDatabaseInit;
}

CIuEngine::~CIuEngine()
{
	// Remove queries first... (in case they are still running)
	GetQueries().RemoveAll();
	DisConnect();
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
	ASSERT(iObjectDatabaseInit > 0);
	--iObjectDatabaseInit;
	if (iObjectDatabaseInit == 0)
		CIuObjectDatabase::Terminate();
}

#pragma __TODO("CIuEngine::Check connection before all calls")

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuEngine::ActionCreateDatabaseList(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	CString sName = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	if (sName.IsEmpty())
		Error(IU_E_MEMBER_NAME_EXPECTED);

	CIuDatabaseListPtr pDatabaseList = CreateDatabaseList();
	pDatabaseList->SetName(sName);
	Output.GetDictionary().AddObject(pDatabaseList);

	CString sResult;
	sResult.Format("Created Source List  as '%s'\n", LPCTSTR(sName));
	return sResult;
}

CString CIuEngine::ActionCreateExport(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	CString sName = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	if (sName.IsEmpty())
		Error(IU_E_MEMBER_NAME_EXPECTED);

	CIuExportPtr pExport = CreateExport();
	pExport->SetName(sName);
	Output.GetDictionary().AddObject(pExport);

	CString sResult;
	sResult.Format("Created export  as '%s'\n", LPCTSTR(sName));
	return sResult;
}

CString CIuEngine::ActionCreateSelect(const CIuPropertyCollection& Collection, CIuOutput& Output)
{
	CString sName = Collection.GetStringOrDefault(S(IDS_ENGINE_PROP_NAME));
	if (sName.IsEmpty())
		Error(IU_E_MEMBER_NAME_EXPECTED);

	CIuSelectPtr pSelect = CreateSelect();
	pSelect->SetName(sName);
	Output.GetDictionary().AddObject(pSelect);

	CString sResult;
	sResult.Format("Created select  as '%s'\n", LPCTSTR(sName));
	return sResult;
}

CString CIuEngine::ActionRefresh(const CIuPropertyCollection&, CIuOutput&)
{
	Refresh();
	CString sResult;
	sResult.Format("Engine refreshed.");
	return sResult;
}

CString CIuEngine::ActionSearchWhere(const CIuPropertyCollection&, CIuOutput& Output)
{
	SearchWhereDlg(Output.GetParentWnd());
	return CString();
}

void CIuEngine::CheckConnected() const
{
	if (!m_fConnected)
		const_cast<CIuEngine*>(this)->Connect(0);
	if (!m_fConnected)
		Error(IU_E_NO_CONNECTION);
}

bool CIuEngine::CheckVersion(LPCTSTR pcszName, CIuVersionNumber version, bool fShowDlg, CWnd* pParent)
{
	// Check an application named 'pcszName' for the specified version number.
	CheckConnected();
	return GetReleaseNotes().CheckVersion(pcszName, version, fShowDlg, pParent);
}

void CIuEngine::CloseUnused()
{
	GetPackRepository().CloseUnused();
}

void CIuEngine::CommonConstruct()
{
	//{{Initialize
	if (!m_pPackRepository)
	{
		m_pPackRepository.Create();
	}
	if (m_pObjectRepository.IsNull())
	{
		m_pObjectRepository.Create();
	}
	if (m_pSourceProvider.IsNull())
	{
		m_pSourceProvider.Create();
		m_pSourceProvider->SetEngine(*this);
	}
	if (!m_pListeners)
	{
		m_pListeners.Create();
		m_pListeners->SetEngine(*this);
	}
	if (!m_pBuilds)
	{
		m_pBuilds.Create();
		m_pBuilds->SetEngine(*this);
	}
	if (!m_pDatabases)
	{
		m_pDatabases.Create();
		m_pDatabases->SetEngine(*this);
	}
	if (!m_pExportDefs)
	{
		m_pExportDefs.Create();
		m_pExportDefs->SetEngine(*this);
	}
	if (!m_pExporters)
	{
		m_pExporters.Create();
		m_pExporters->SetEngine(*this);
	}
	if (m_pGps.IsNull())
	{
		m_pGps.Create();
		m_pGps->SetEngine(*this);
	}
	if (m_pTapi.IsNull())
	{
		m_pTapi.Create();
		m_pTapi->SetEngine(*this);
	}
	if (m_pMeters.IsNull())
	{
		m_pMeters.Create();
		m_pMeters->SetEngine(*this);
	}
	if (m_pQueries.IsNull())
	{
		m_pQueries.Create();
		m_pQueries->SetEngine(*this);
	}
	if (m_pReleaseNotes.IsNull())
	{
		m_pReleaseNotes.Create();
		m_pReleaseNotes->SetEngine(*this);
	}
	if (m_pRegistrations.IsNull())
	{
		m_pRegistrations.Create();
		m_pRegistrations->SetEngine(*this);
	}
	SetName("Engine");
	if (m_pUserInterfaces.IsNull())
	{
		m_pUserInterfaces.Create();
		m_pUserInterfaces->SetEngine(*this);
	}
	if (m_pSplashes.IsNull())
	{
		m_pSplashes.Create();
		m_pSplashes->SetEngine(*this);
	}
	if (m_pBlobs.IsNull())
	{
		m_pBlobs.Create();
		m_pBlobs->SetEngine(*this);
	}
	if (m_pReporters.IsNull())
	{
		m_pReporters.Create();
		m_pReporters->SetEngine(*this);
	}
	if (m_pReportDefs.IsNull())
	{
		m_pReportDefs.Create();
		m_pReportDefs->SetEngine(*this);
	}
	SetVersion(IU_ENGINE_VERSION);
	m_fDebug = false;
	//}}Initialize
}

bool CIuEngine::Connect(LPCTSTR ConnectString) 
{
	if (m_fConnected)
		DisConnect();
	if (ConnectString == 0)
		ConnectString = _T("");
	ASSERT(AfxIsValidString(ConnectString));

	CIuOptions options(ConnectString);
	int iCount = options.GetCount();
	for (int i = 0; i < iCount; ++i)
	{
		if (!options.HasName(i))
			continue;

		CString sKeyword = options.GetName(i);
		if (sKeyword.CompareNoCase(S(IDS_ENGINE_ADMIN)) == 0)
		{
			// The password for admin mode is currently infoUSA (case sensitive).
			// That password generates the following CRC code
			const CRC32 crcAdmin = 0xCF8B4EA7;
			CRC32 crc = crc32(options.GetValue(i));
			if (crc != crcAdmin)
				Error(IU_E_INV_PASSWORD, LPCTSTR(options.GetValue(i)));
#pragma __TODO("Allow granting certain rights via connect string...")
		}
		else if (sKeyword.CompareNoCase(S(IDS_ENGINE_DEBUG)) == 0)
		{
			// Sets debug mode... this mode slows down performance but performs additional check
			// on data.
			SetDebug(true);
		}
		else if (sKeyword.CompareNoCase(S(IDS_ENGINE_CONNECT)) == 0)
		{
			// This is currently not implemented
			TRACE("WARNING: Connection to '%s' not supported.\n", LPCTSTR(options.GetValue(i)));
		}
	}

	m_fConnected = true;

	IU_TRY_ERROR
	{
		Refresh();
		GetListeners().Fire(IU_EVENT_ENGINE_CONNECT, -1, "infoUSA Engine connected");
	}
	IU_CATCH_ERROR(e)
	{
		// If an error occurs, report it but continue as if connection
		// had succeeded.
		e->ReportError();
		e->Delete();
		return false;
	}
	return true;
}

bool CIuEngine::ConnectDlg(int ForceDialog, CWnd* pWnd)
{
	CString sConnectString;
	for (;;)
	{
		if (!CIuXmlConnectDlg::ConnectDlg(_T("Engine"), sConnectString, ForceDialog, pWnd))
			return false;

		IU_TRY_ERROR
		{
			Connect(sConnectString);
			break;
		}
		IU_CATCH_ERROR(e)
		{
			e->ReportError();
			e->Delete();
			ForceDialog = true;
		}
	}
	return true;
}

CIuDatabaseListPtr CIuEngine::CreateDatabaseList() const
{
	CIuDatabaseListPtr pDatabaseList;
	pDatabaseList.Create();
	pDatabaseList->SetEngine(*const_cast<CIuEngine*>(this));
	return pDatabaseList;
}

CIuExportPtr CIuEngine::CreateExport() const
{
	CIuExportPtr pExport;
	pExport.Create();
	pExport->SetEngine(*const_cast<CIuEngine*>(this));
	return pExport;
}

CIuOutputPtr CIuEngine::CreateOutput() const
{
	CIuOutputPtr pOutput;
	pOutput.Create();
	pOutput->DefaultObjects();
	pOutput->GetDictionary().AddObject(const_cast<CIuEngine*>(this));
	pOutput->SetOwner(const_cast<CIuEngine*>(this));
	pOutput->SetBroadcast(&GetListeners().GetBroadcast());
	return pOutput;
}

CIuProgressDlg* CIuEngine::CreateProgressDlg(CWnd* pParent, LPCTSTR pcszTitle, int iHandle) const
{
	CIuProgressDlg* pProgress = CIuProgressDlg::Create(pParent, pcszTitle, &GetListeners().GetBroadcast(), true);
	if (pProgress == 0)
		return pProgress;
	pProgress->SetHandle(iHandle);
	return pProgress;
}

CIuQueryPtr CIuEngine::CreateQuery() const
{
	int iIndex = GetQueries().Add();
	ASSERT(iIndex >= 0);
	CIuQueryPtr pQuery = &GetQueries().Get(iIndex);
	return pQuery;
}

CIuSelectPtr CIuEngine::CreateSelect() const
{
	CIuSelectPtr pSelect;
	pSelect.Create();
	pSelect->SetEngine(*const_cast<CIuEngine*>(this));
	return pSelect;
}

CIuSimpleQueryPtr CIuEngine::CreateSimpleQuery() const
{
	CIuSimpleQueryPtr pSimpleQuery;
	pSimpleQuery.Create();
	pSimpleQuery->SetEngine(*const_cast<CIuEngine*>(this));
	return pSimpleQuery;
}

void CIuEngine::DisConnect() 
{
	GetTapi().Flush();
	GetGps().DisConnect();

	m_fConnected = false;
#pragma __TODO("CIuEngine::DisConnect() - Delete all queries and other info")
}

CIuObject* CIuEngine::GetBlobs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pBlobs.Ptr()));
}

CIuProgressBroadcast& CIuEngine::GetBroadcast() const
{
	return GetListeners().GetBroadcast();
}

CIuBuilds& CIuEngine::GetBuilds() const
{
	CheckConnected();
	if ((GetUserRights() & engineRightsBuild) == 0)
		Error(IU_E_NOT_AUTHORIZED);
	return m_pBuilds.Ref();
}

CIuObject* CIuEngine::GetBuilds_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pBuilds.Ptr()));
}

bool CIuEngine::GetConnected() 
{
	return m_fConnected;
}

CIuDatabases& CIuEngine::GetDatabases() const
{
	CheckConnected();
	return m_pDatabases.Ref();
}

CIuObject* CIuEngine::GetDatabases_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pDatabases.Ptr()));
}

CIuExportDefs& CIuEngine::GetExportDefs() const
{
	return m_pExportDefs.Ref();
}

CIuObject* CIuEngine::GetExportDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pExportDefs.Ptr()));
}

CIuExporters& CIuEngine::GetExporters() const
{
	return m_pExporters.Ref();
}

CIuObject* CIuEngine::GetExporters_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pExporters.Ptr()));
}

CIuGps& CIuEngine::GetGps() const
{
	CheckConnected();
	return m_pGps.Ref();
}

CIuObject* CIuEngine::GetGps_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pGps.Ptr()));
}

CIuListeners& CIuEngine::GetListeners() const
{
	CheckConnected();
	return m_pListeners.Ref();
}

CIuObject* CIuEngine::GetMeters_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pMeters.Ptr()));
}

CIuPackRepository& CIuEngine::GetPackRepository() const
{
	return m_pPackRepository.Ref();
}

CIuObject* CIuEngine::GetQueries_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pQueries.Ptr()));
}

CIuObject* CIuEngine::GetRegistrations_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRegistrations.Ptr()));
}

CIuObject* CIuEngine::GetReleaseNotes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pReleaseNotes.Ptr()));
}

CIuObject* CIuEngine::GetReportDefs_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pReportDefs.Ptr()));
}

CIuObject* CIuEngine::GetReporters_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pReporters.Ptr()));
}

CIuObject* CIuEngine::GetSourceProvider_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSourceProvider.Ptr()));
}

CIuObject* CIuEngine::GetSplashes_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSplashes.Ptr()));
}

CIuTapi& CIuEngine::GetTapi() const
{
	return m_pTapi.Ref();
}

CIuObject* CIuEngine::GetTapi_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pTapi.Ptr()));
}

int CIuEngine::GetUserRights() const
{
	// Only allow extra rights on internal network!
	if (!IsValidIp())
		return engineRightsNone;

	CString sUser, sDomain;
	CIuSysInfo si;
	int iRights = engineRightsInternal|engineRightsMultiUserLicense;
	if (!si.GetUserAndDomainName(sUser, sDomain))
	{
		iRights = engineRightsInternal;
	}
	else if (!sDomain.IsEmpty() && sDomain.CompareNoCase(szDomain) != 0)
	{
		return engineRightsNone;
	}
	else
	{
		for (int iUser = 0; aRights[iUser].m_pcszName; ++iUser)
		{
			if (sUser.CompareNoCase(aRights[iUser].m_pcszName) == 0)
			{
				iRights = aRights[iUser].m_iRights;
				break;
			}
		}
	}

#ifdef _DEBUG
	// Allow meter admin in debug mode
	iRights |= engineRightsMeterAdmin;
#endif

	return iRights;
}
		

CIuObject* CIuEngine::GetUserInterfaces_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pUserInterfaces.Ptr()));
}

bool CIuEngine::IsValidIp() const
{
	// Only allow extra rights on internal network!
	CIuSysInfo si;
	CStringArray IPArray;
	if (!si.GetIPAddresses(IPArray))
		return false;
	for (int j = 0; j < IPArray.GetSize(); j++)
	{
		CString sIP = IPArray[j];
		for (int k = 0; apcszIpSubNets[k]; ++k)
		{
			if (sIP.Find(apcszIpSubNets[k]) == 0)
				return true;
		}
	}
	return false;
}

bool CIuEngine::QueryCollection(int iCollection, CIuObjectRepository& Repository)
{
	UINT uiType = 0;
	CString sOldType;
	CIuVersionNumber verMin = IU_VERSION;
	CIuVersionNumber verMax = IU_VERSION;

	switch (iCollection)
	{
		case collectionExporters:
		{
			// The engine is asking for all exporters provided. Inform
			// engine exporters are available by adding expoter ids to 
			// the id array.
			const CIuVersionNumber versionCurrent = CIuExporter::GetVersionMaxStatic();
			Repository.Add(CIuMoniker(CIuExporter::GetExporterName(idExporterCsv), idExporterCsv), IuClassFactoryGetType(IDS_ENGINE_OBJECT_EXPORTER), versionCurrent,0,0,0);
			Repository.Add(CIuMoniker(CIuExporter::GetExporterName(idExporterTab), idExporterTab), IuClassFactoryGetType(IDS_ENGINE_OBJECT_EXPORTER), versionCurrent,0,0,0);
			Repository.Add(CIuMoniker(CIuExporter::GetExporterName(idExporterFix), idExporterFix), IuClassFactoryGetType(IDS_ENGINE_OBJECT_EXPORTER), versionCurrent,0,0,0);
			Repository.Add(CIuMoniker(CIuExporter::GetExporterName(idExporterDbf), idExporterDbf), IuClassFactoryGetType(IDS_ENGINE_OBJECT_EXPORTER), versionCurrent,0,0,0);
			Repository.Add(CIuMoniker(CIuExporter::GetExporterName(idExporterTxt), idExporterTxt), IuClassFactoryGetType(IDS_ENGINE_OBJECT_EXPORTER), versionCurrent,0,0,0);
			break;
		}
		case collectionDatabases:
			uiType = IDS_ENGINE_OBJECT_DATABASE;
			sOldType = "DbDatabase";
			verMin = CIuDatabase::GetVersionMinStatic();
			verMax = CIuDatabase::GetVersionMaxStatic();
			break;
		case collectionExportDefs:
			uiType = IDS_ENGINE_OBJECT_EXPORTDEF;
			sOldType = "DbExportDef";
			verMin = CIuExportDef::GetVersionMinStatic();
			verMax = CIuExportDef::GetVersionMaxStatic();
			break;
		case collectionMeters:
			uiType = IDS_ENGINE_OBJECT_METER;
			sOldType = "DbMeter";
			verMin = CIuMeter::GetVersionMinStatic();
			verMax = CIuMeter::GetVersionMaxStatic();
			break;
		case collectionSourceDescriptors:
			uiType = IDS_ENGINE_OBJECT_SOURCEDESCRIPTOR;
			verMin = CIuSourceDescriptor::GetVersionMinStatic();
			verMax = CIuSourceDescriptor::GetVersionMaxStatic();
			break;
		case collectionReleaseNotes:
			uiType = IDS_ENGINE_OBJECT_RELEASENOTE;
			sOldType = "DbReleaseNote";
			verMin = CIuReleaseNote::GetVersionMinStatic();
			verMax = CIuReleaseNote::GetVersionMaxStatic();
			break;
		case collectionRegistrations:
			uiType = IDS_ENGINE_OBJECT_REGISTRATION;
			verMin = CIuRegistration::GetVersionMinStatic();
			verMax = CIuRegistration::GetVersionMaxStatic();
			break;
		case collectionReportDefs:
			uiType = IDS_ENGINE_OBJECT_REPORTDEF;
			sOldType = "DbReportDef";
			verMin = CIuReportDef::GetVersionMinStatic();
			verMax = CIuReportDef::GetVersionMaxStatic();
			break;
		case collectionUserInterfaces:
			uiType = IDS_ENGINE_OBJECT_USERINTERFACE;
			sOldType = "DbUserInterface";
			verMin = CIuUserInterface::GetVersionMinStatic();
			verMax = CIuUserInterface::GetVersionMaxStatic();
			break;
		case collectionSplashes:
			uiType = IDS_ENGINE_OBJECT_SPLASH;
			verMin = CIuSplash::GetVersionMinStatic();
			verMax = CIuSplash::GetVersionMaxStatic();
			break;
		case collectionBlobs:
			uiType = IDS_ENGINE_OBJECT_BLOB;
			verMin = CIuBlob::GetVersionMinStatic();
			verMax = CIuBlob::GetVersionMaxStatic();
			break;
		case collectionBTrees:
			uiType = IDS_ENGINE_OBJECT_BTREE;
			verMin = CIuBTree::GetVersionMinStatic();
			verMax = CIuBTree::GetVersionMaxStatic();
			break;
		case collectionTokens:
			uiType = IDS_ENGINE_OBJECT_TOKEN;
			sOldType = "TokenFile";
			verMin = CIuToken::GetVersionMinStatic();
			verMax = CIuToken::GetVersionMaxStatic();
			break;
		case collectionSics:
			uiType = IDS_ENGINE_OBJECT_SIC;
			sOldType = "SicFile";
			verMin = CIuSic::GetVersionMinStatic();
			verMax = CIuSic::GetVersionMaxStatic();
			break;
		case collectionGeos:
			uiType = IDS_ENGINE_OBJECT_GEO;
			verMin = CIuGeo::GetVersionMinStatic();
			verMax = CIuGeo::GetVersionMaxStatic();
			break;
		default:
			return false;
	}

	if (uiType != 0)
	{
		CString sType = IuClassFactoryGetType(uiType);
		GetObjectRepository().Create(Repository, sType, verMin, verMax);

		if (!sOldType.IsEmpty())
		{
			CIuObjectRepository RepositoryOld;
			GetObjectRepository().Create(RepositoryOld, sOldType, verMin, verMax);
			Repository.Append(RepositoryOld);
		}
	}
	return true;
}

bool CIuEngine::QueryObject(int iCollection, const CIuObjectDescriptor& Descriptor, CIuObject& Object, CString* pActualFilename)
{
	if (pActualFilename)
		pActualFilename->Empty();

	// Some collections are handled internal
	switch (iCollection)
	{
		case collectionExporters:
		{
			CIuExporterPtr pExporter = dynamic_cast<CIuExporter*>(&Object);
			ASSERT(pExporter.NotNull());
			if (pExporter->SetSpec(Descriptor.GetID()))
				return true;
			break;
		}
	}

	// For the rest, we just try to unpack an object from the repository
	int iIndex = GetObjectRepository().Find(Descriptor);
	if (iIndex < 0)
		return false;

	CIuObjectPtr pObject = GetObjectRepository().UnPack(iIndex, true, 0, pActualFilename);
	if (pObject.IsNull())
		return false;
	Object.Copy(*pObject);
	return true;
}

void CIuEngine::Refresh()
{
#ifdef _DEBUG
	time_t timeStart = time(0);
#endif

	CheckConnected();

	// Update repositories
	RefreshPackRepository();

	GetObjectRepository().SetPackRepository(&GetPackRepository());

	// Mark for later sweep
	GetObjectRepository().SetMarked(true);

	// Update each of the providers
	// Find all of the repositories
	CString sType = IuClassFactoryGetType(IDS_DATA_OBJECT_OBJECTREPOSITORY);
	CString sRepositoryName;
	sRepositoryName.Format("/%s/", LPCTSTR(sType));

	CIuIDArray ids;
	GetObjectRepository().GetPackRepository().Find(sRepositoryName, ids);

	int iCount = ids.GetSize();
	for (int i = 0; i < iCount; ++i)
	{
		CIuID id = ids[i];

		CIuObjectRepositoryPtr pObjectRepository; 
		pObjectRepository.Create();
		ASSERT(pObjectRepository.NotNull());

		CString sFilename;

		sRepositoryName.Format("/%s/%s", LPCTSTR(sType), LPCTSTR(id.AsString()));
		GetObjectRepository().GetPackRepository().UnPack(sRepositoryName, pObjectRepository, &sFilename);

		if (pObjectRepository->GetVersion() < CIuObjectRepository::GetVersionMinStatic())
		{
			TRACE("NOTE: CD-ROM repository '%s' is an obsolete release (%s).\n", 
				LPCTSTR(pObjectRepository->GetName()),
				LPCTSTR(pObjectRepository->GetVersion().ToString()));
			continue;
		}

		pObjectRepository->SetFilename(sFilename);
		GetObjectRepository().Append(*pObjectRepository);
	}

	// Remove all objects which are still marked
	GetObjectRepository().Sweep(true);

	// Clear out the ids array being passed in
	// Order is important

	// Meters before databases so database can connect to meter
	RefreshCollection(collectionMeters, GetMeters());
	RefreshCollection(collectionDatabases, GetDatabases());
	RefreshCollection(collectionExportDefs, GetExportDefs());
	RefreshCollection(collectionExporters, GetExporters());
	RefreshCollection(collectionReleaseNotes, GetReleaseNotes());
	RefreshCollection(collectionRegistrations, GetRegistrations());
	RefreshCollection(collectionReportDefs, GetReportDefs());
	RefreshCollection(collectionReporters, GetReporters());
	RefreshCollection(collectionUserInterfaces, GetUserInterfaces());
	RefreshCollection(collectionSplashes, GetSplashes());
	RefreshCollection(collectionBlobs, GetBlobs());

	// If we support remote queries, we made need to consider updating
	// the query collection here
#pragma __TODO("GetQueries().Refresh()")

	GetTapi().Refresh();

	// Meter object needs to check again for network meter files
	GetMeters().Refresh();

	GetSourceProvider().SetRefresh();

	// Close any unused pack files
	CloseUnused();

#ifdef _DEBUG
	time_t timeEnd = time(0);
	TRACE("NOTE: Engine refresh completed in %d seconds\n", timeEnd - timeStart);
#endif
}

bool CIuEngine::RefreshCollection(int iCollection, CIuCollection& Collection)
{
	CIuObjectRepository Repository;
	if (!QueryCollection(iCollection, Repository))
		return false;
	Collection.Refresh(Repository);
	return true;
}

void CIuEngine::RefreshPackRepository()
{
	CStringArray asLocations;
	IuSearchGetMaster(asLocations);
	GetPackRepository().Refresh(asLocations);
}

bool CIuEngine::SearchWhereDlg(CWnd* pParent)
{
	if (!CIuSearchWhereDlg::Edit(pParent))
		return false;
	Refresh();
	return true;
}

void CIuEngine::SetDebug(bool f)
{
	m_fDebug = f;
}

void CIuEngine::ShowUserRightsException() const
{
	CString sMessage = _T("You are not authorized for this operation.\n");

	CIuSysInfo si;
	if (!IsValidIp())
	{
		sMessage += _T("ADDRESS:\n");
		CStringArray IPArray;
		if (si.GetIPAddresses(IPArray))
		{
			for (int j = 0; j < IPArray.GetSize(); j++)
			{
				CString sIP = IPArray[j];
				sMessage += _T("\t");
				sMessage += sIP;
				sMessage += _T("\n");
			}
		}
		else
			sMessage += _T("\tNo Address\n");
	}

	CString sUser, sDomain;
	if (!si.GetUserAndDomainName(sUser, sDomain))
		sMessage += _T("No user name or domain.\n");
	else if (!sDomain.IsEmpty() && sDomain.CompareNoCase(szDomain) != 0)
	{
		sMessage += _T("DOMAIN: ");
		sMessage += sDomain;
		sMessage += _T("\n");
	}

	if (!sUser.IsEmpty())
	{
		bool fFound = false;
		for (int iUser = 0; aRights[iUser].m_pcszName; ++iUser)
		{
			if (sUser.CompareNoCase(aRights[iUser].m_pcszName) == 0)
			{
				fFound = true;
				break;
			}
		}
		if (!fFound)
		{
			sMessage += _T("USER: ");
			sMessage += sUser;
			sMessage += _T("\n");
		}
	}
	else
		sMessage += _T("USER: <unknown>");

	AfxMessageBox(sMessage);
}
