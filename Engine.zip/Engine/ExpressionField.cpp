#include "StdAfx.h"
//{{Include
#include "ExpressionField.h"
#include "Record.h"
#include "RecordDef.h"
#include "resource.h"
#include "Interop\Conversions.h"
#include "LatLongUnit.h"
#include "CaseConversion.h"
#include "Key.h"
#include "FieldDefConst.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionField::CIuExpressionField(LPCTSTR pcsz) : CIuExpressionElement(exprFieldLiteral)
{
	SetFormat(exprFormatString);
	CommonConstruct();
	if (pcsz)
		SetField(pcsz);
}

CIuExpressionField::CIuExpressionField(const CIuExpressionField& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionField::~CIuExpressionField()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionField::Clone() const
{
	CIuExpressionField* pElement = new CIuExpressionField(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionField::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_sField = "";
	m_iMaxLength = 0;
	m_iBoughtLevel = 0;
	m_iFieldFlags = 0;
	//}}Initialize
}

LPCTSTR CIuExpressionField::Evaluate(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 0);

	if (GetFormat() != exprFormatString)
		return CIuExpressionField_super::Evaluate(pRecord);

	ASSERT(GetChildCount() == 0);
	if (pRecord == 0)
		return m_sBuffer;

	// If no field was resolved, an empty string will be returned
	if (GetType() >= 0)
	{
		if (m_iBoughtLevel > 0 && pRecord->GetBoughtLevel() < m_iBoughtLevel)
			return _T("");

		LPCTSTR pcszField = pRecord->GetField(int(GetType()));
		if (GetCaseConvert() == caseNoConvert)
			return pcszField;

		m_sBuffer = pcszField;
		LPTSTR psz = m_sBuffer.GetBuffer(0);
		CaseConvertInPlace(psz, m_sBuffer.GetLength(), CIuCaseConversionMode(GetCaseConvert()), m_iFieldFlags);
		m_sBuffer.ReleaseBuffer();
		return m_sBuffer;
	}
	else if (GetType() == exprOption)
	{
		// Don't do anything
		// m_sBuffer contains the proper value for the option
	}
	else if (GetType() == exprKey)
	{
		// Key the key, note that it can contain embedded nulls. Convert them to linefeeds.
		LPCTSTR pcszKey = (LPCTSTR)pRecord->GetKeyPtr();
		ASSERT(pcszKey);
		int iKey = pRecord->GetKeySize();
		ASSERT(iKey > 0);

		LPTSTR pszKey = m_sBuffer.GetBuffer(iKey);
		memcpy(pszKey, pcszKey, iKey);

		for (int i = 0; i < iKey - 1; ++i)
		{
			if (pszKey[i] == '\0')
				pszKey[i] = keySeparatorChar;
		}

		m_sBuffer.ReleaseBuffer();
	}
	else if (GetType() == exprFieldLiteral)
	{
		// m_sBuffer = "literal";
	}
	else
	{
		switch (GetType())
		{
			case exprAlt:
				return pRecord->GetAltKey();
			case exprSeeAlso:
				return pRecord->GetAltValue();
			case exprLatitude:
			{
				DWORD dwLat, dwLong;
				pRecord->GetLatLong(dwLat, dwLong);
				CIuLatLongUnit latitude(dwLat);
				m_sBuffer = latitude.AsString();
				break;
			}
			case exprLongitude:
			{
				DWORD dwLat, dwLong;
				pRecord->GetLatLong(dwLat, dwLong);
				CIuLatLongUnit longitude(dwLong);
				m_sBuffer = longitude.AsString();
				break;
			}
			case exprBusResFlag:
			{
				if (pRecord->IsBusiness())
					m_sBuffer = _T("B");
				else
					m_sBuffer = _T("R");
				break;
			}
			default:
				ASSERT(false);
				return _T("");
		}
	}
	return m_sBuffer;
}

bool CIuExpressionField::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 0);

	if (GetFormat() == exprFormatInt)
		return EvaluateInt(pRecord) != 0;
	if (GetFormat() != exprFormatBool)
		return CIuExpressionField_super::EvaluateBool(pRecord);

	ASSERT(GetChildCount() == 0);
	if (pRecord == 0)
		return false;

	ASSERT(GetType() != exprOption);
	ASSERT(GetType() < 0);
	ASSERT(GetType() != exprKey);
	ASSERT(GetType() != exprFieldLiteral);

	switch (GetType())
	{
		case exprTagged:
			return pRecord->IsTagged();
		case exprNoMail:
			return pRecord->IsNoMail();
		case exprNoPhone:
			return pRecord->IsNoPhone();
		case exprBusiness:
			return pRecord->IsBusiness();
		case exprResidence:
			return pRecord->IsResidence();
	}

	ASSERT(false);
	return false;
}

int CIuExpressionField::EvaluateInt(const CIuRecord* pRecord) const
{
	ASSERT(GetChildCount() == 0);
	if (GetFormat() == exprFormatBool)
		return int(EvaluateBool(pRecord));
	if (GetFormat() != exprFormatInt)
		return CIuExpressionField_super::EvaluateInt(pRecord);

	if (pRecord == 0)
		return 0;

	ASSERT(GetType() != exprOption);
	ASSERT(GetType() < 0);
	ASSERT(GetType() != exprKey);
	ASSERT(GetType() != exprFieldLiteral);

	switch (GetType())
	{
		case exprRecordNo:
			return pRecord->GetRecordNo();
		case exprSourceNo:
			return pRecord->GetSourceNo();
		case exprExpandNo:
			return pRecord->GetExpandNo();
		case exprCount:
			return pRecord->GetExpandCount();
		case exprBought:
			return pRecord->GetBoughtLevel();
	}

	ASSERT(false);
	return 0;
}

int CIuExpressionField::GetBoughtLevel() const
{
	return m_iBoughtLevel;
}

int CIuExpressionField::GetMaxLength() const
{
	return m_iMaxLength;
}

LPCTSTR CIuExpressionField::GetTypeName() const
{
	if (GetType() >= 0)
	{
		// This is a resolved field
		return m_sField;
	}
	switch (GetType())
	{
		case exprFieldLiteral:
			return "#Field Literal#";
		case exprOption:
			return "#Option#";
		case exprKey:
			return "#Key#";
		case exprAlt:
			return "#Alt#";
		case exprSeeAlso:
			return "#SeeAlso#";
		case exprRecordNo:
			return "#RecordNo#";
		case exprSourceNo:
			return "#SourceNo#";
		case exprExpandNo:
			return "#ExpandNo#";
		case exprCount:
			return "#Count#";
		case exprLatitude:
			return "#Latitude#";
		case exprLongitude:
			return "#Longitude#";
		case exprTagged:
			return "#Tagged#";
		case exprBought:
			return "#Bought#";
		case exprNoMail:
			return "#NoMail#";
		case exprNoPhone:
			return "#NoPhone#";
		case exprBusiness:
			return "#Business#";
		case exprResidence:
			return "#Residence#";
		case exprBusResFlag:
			return "#BusResFlag#";
	}
	return CIuExpressionField_super::GetTypeName();
}

bool CIuExpressionField::IsConst() const
{
	// Only the unresolved field is constant
	// This type of expression is never const
	ASSERT(GetType() >= 0|| GetType() == exprOption || GetType() == exprFieldLiteral || (GetType() >= exprFieldFirst && GetType() < exprFieldLast));
	return GetType() < 0 && (GetType() < exprFieldFirst && GetType() >= exprFieldLast);
}

bool CIuExpressionField::IsKindOf(CIuExpressionType Type) const
{
	return CIuExpressionField_super::IsKindOf(Type);
}

CIuExpressionField& CIuExpressionField::operator=(const CIuExpressionField& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionField_super::operator=(rExpressionElement);
	m_sField = rExpressionElement.m_sField;
	m_iMaxLength = rExpressionElement.m_iMaxLength;
	m_iBoughtLevel = rExpressionElement.m_iBoughtLevel;
	m_iFieldFlags = rExpressionElement.m_iFieldFlags;
	return *this;
}

void CIuExpressionField::Resolve(CIuResolveSpec& Spec)
{
	CIuExpressionField_super::Resolve(Spec);
	ASSERT(Spec.m_pRecordDefSrc);

	m_iFieldFlags = 0;
	m_sBuffer = "";
	SetFormat(exprFormatString);

	// Can only be resolved once without re-parsing...
	ASSERT(GetType() == exprFieldLiteral);
	ASSERT(GetChildCount() == 0);
	CIuFieldDefs& fields = Spec.m_pRecordDefSrc->GetFieldDefs();

	int iField = fields.Find(m_sField);
	if (iField >= 0)
	{
		SetType(CIuExpressionType(iField));
		m_iMaxLength = fields.Get(iField).GetLength();
		m_iBoughtLevel = fields.Get(iField).GetBoughtLevel();
		m_iFieldFlags = fields.Get(iField).GetFlags();
		return ;
	}

	m_iMaxLength = fieldDftLength;
	m_iBoughtLevel = 0;
	m_iFieldFlags = 0;
	if (m_sField.CompareNoCase(szFieldKey) == 0)
	{
		SetType(exprKey);
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldAlt) == 0)
	{
		SetType(exprAlt);
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldSeeAlso) == 0)
	{
		SetType(exprSeeAlso);
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldRecordNo) == 0)
	{
		SetFormat(exprFormatInt);
		SetType(exprRecordNo);
		m_iMaxLength = 11;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldSourceNo) == 0)
	{
		SetFormat(exprFormatInt);
		SetType(exprSourceNo);
		m_iMaxLength = 11;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldExpandNo) == 0)
	{
		SetFormat(exprFormatInt);
		SetType(exprExpandNo);
		m_iMaxLength = 11;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldCount) == 0)
	{
		SetFormat(exprFormatInt);
		SetType(exprCount);
		m_iMaxLength = 10;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldLatitude) == 0)
	{
		SetFormat(exprFormatString);
		SetType(exprLatitude);
		m_iMaxLength = 11;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldLongitude) == 0)
	{
		SetFormat(exprFormatString);
		SetType(exprLongitude);
		m_iMaxLength = 11;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldTagged) == 0)
	{
		SetFormat(exprFormatBool);
		SetType(exprTagged);
		m_iMaxLength = 1;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldBought) == 0)
	{
		SetFormat(exprFormatInt);
		SetType(exprBought);
		m_iMaxLength = 3;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldNoMail) == 0)
	{
		SetFormat(exprFormatBool);
		SetType(exprNoMail);
		m_iMaxLength = 1;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldNoPhone) == 0)
	{
		SetFormat(exprFormatBool);
		SetType(exprNoPhone);
		m_iMaxLength = 1;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldBusiness) == 0)
	{
		SetFormat(exprFormatBool);
		SetType(exprBusiness);
		m_iMaxLength = 1;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldResidence) == 0)
	{
		SetFormat(exprFormatBool);
		SetType(exprResidence);
		m_iMaxLength = 1;
		return ;
	}
	else if (m_sField.CompareNoCase(szFieldBusResFlag) == 0)
	{
		SetFormat(exprFormatString);
		SetType(exprBusResFlag);
		m_iMaxLength = 1;
		return ;
	}

	if (Spec.m_pOptions)
	{
		int iOption = Spec.m_pOptions->Find(m_sField);
		if (iOption >= 0)
		{
			if (Spec.m_pOptions->HasValue(iOption))
			{
				m_sBuffer = Spec.m_pOptions->GetValue(iOption);
				m_iMaxLength = m_sBuffer.GetLength();
				m_iBoughtLevel = 0;
			}
			else
			{
				m_sBuffer = "1";
				m_iMaxLength = 1;
			}
			m_iBoughtLevel = 0;
			SetType(exprOption);
			return ;
		}

	}

	// Field not found, it becomes an empty field
	m_iMaxLength = 0;
	m_iBoughtLevel = 0;
}

void CIuExpressionField::SetField(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sField = pcsz;
}

