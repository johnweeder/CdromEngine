#include "StdAfx.h"
//{{Include
#include "ExportDefSpec.h"
#include "ExportDefSpecDft.h"
#include "ExportFieldDefSpec.h"
#include "FieldDefSpec.h"
#include "resource.h"
#include "ExportDef.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuExportDefSpec, CIuExportDefSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuExportDefSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_EXPORTDEFSPEC, CIuExportDefSpec, CIuExportDefSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuExportDefSpec, IDS_ENGINE_PPG_EXPORTDEFSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuExportDefSpec, IDS_ENGINE_PROP_EXPORTDEFNO, GetExportDefNo, SetExportDefNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuExportDefSpec, IDS_ENGINE_PROP_EXPORTDEFNO, IDS_ENGINE_PPG_EXPORTDEFSPEC, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuExportDefSpec::CIuExportDefSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuExportDefSpec::~CIuExportDefSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuExportDefSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName("ExportDefSpec");
	m_sTitle = "";
	m_sDescription = "";
	m_sExtension = "";
	m_sOptions = "";
	m_sExporter = "";
	m_iExportDefType = exportDefTypeFixed;
	m_iRecordLength = 0;
	m_pCdrom = 0;
	m_iExportDefNo = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuExportDefSpec::CreateFieldDef(LPCTSTR pcszFieldDef)
{
	ASSERT(AfxIsValidString(pcszFieldDef));
	CIuExportFieldDefSpecPtr pFieldDefSpec;
	pFieldDefSpec.Create();
	pFieldDefSpec->Set(pcszFieldDef);
	m_apFieldDefs.Add(pFieldDefSpec);
}

bool CIuExportDefSpec::FromIndex(CIuCdromSpec* pCdrom, int iSpec)
{
	if (iSpec < 0 || iSpec >= GetCount())
		return false;

	const CIuExportDefSpecDft* pExportDef = CIuExportDefSpecDft::Get(iSpec);

	Clear();

	SetCdrom(pCdrom);

	SetName(pExportDef->m_pcszExportDef);
	SetID(*pExportDef->m_pid);

	SetExportDefNo(pExportDef->m_iExportDef);
	SetTitle(pExportDef->m_pcszTitle);
	SetDescription(pExportDef->m_pcszDescription);
	SetExtension(pExportDef->m_pcszExtension);
	SetOptions(pExportDef->m_pcszOptions);
	SetExporter(pExportDef->m_pcszExporter);
	SetType(pExportDef->m_iExportDefType);
	SetRecordLength(pExportDef->m_iRecordLength);

	RemoveAllFieldDefs();
	for (int i = 0 ; pExportDef->m_apcszFields[i]; ++i)
		CreateFieldDef(pExportDef->m_apcszFields[i]);

	return true;
}

bool CIuExportDefSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszName)
{
	return FromIndex(pCdrom, CIuExportDefSpecDft::Find(pcszName));
}

bool CIuExportDefSpec::FromNo(CIuCdromSpec* pCdrom, int iExportDefNo)
{
	return FromIndex(pCdrom, CIuExportDefSpecDft::Find(iExportDefNo));
}

int CIuExportDefSpec::GetCount()
{
	return CIuExportDefSpecDft::GetCount();
}

CIuExportFieldDefSpec& CIuExportDefSpec::GetFieldDef(int iExportFieldDef) const
{
	ASSERT(iExportFieldDef >= 0 && iExportFieldDef < GetFieldDefCount());
	return *m_apFieldDefs[iExportFieldDef];
}

int CIuExportDefSpec::GetFieldDefCount() const
{
	return m_apFieldDefs.GetSize();	
}

inline bool CIuExportDefSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

void CIuExportDefSpec::GetNames(CStringArray& as)
{
	as.RemoveAll();
	for (int i = 0; i < GetCount(); ++i)
		as.Add(CIuExportDefSpecDft::Get(i)->m_pcszExportDef);
}

void CIuExportDefSpec::RemoveAllFieldDefs()
{
	m_apFieldDefs.RemoveAll();
}

void CIuExportDefSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}

void CIuExportDefSpec::SetDescription(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sDescription = pcsz;
}

void CIuExportDefSpec::SetExportDefNo(int iExportDefNo)
{
	m_iExportDefNo = iExportDefNo;
}

void CIuExportDefSpec::SetExporter(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExporter = pcsz;
}

void CIuExportDefSpec::SetExtension(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sExtension = pcsz;
}

void CIuExportDefSpec::SetOptions(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sOptions = pcsz;
}

void CIuExportDefSpec::SetRecordLength(int iRecordLength)
{
	ASSERT(iRecordLength >= 0);
	m_iRecordLength = iRecordLength;
}

void CIuExportDefSpec::SetTitle(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sTitle = pcsz;
}

void CIuExportDefSpec::SetType(int iExportDefType)
{
	ASSERT(
		iExportDefType == exportDefTypeFixed
	|| iExportDefType == exportDefTypeCustom
	|| iExportDefType == exportDefTypeAll
	|| iExportDefType == exportDefTypeDefault
	|| iExportDefType == exportDefTypeUser
	);
	m_iExportDefType = iExportDefType;
}


