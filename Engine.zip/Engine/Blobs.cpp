#include "StdAfx.h"
//{{Include
#include "Blobs.h"
#include "Blob.h"
#include "Database.h"
#include "resource.h"
#include "CdromSpec.h"
#include "Engine.h"
#include "..\Version.h"
//}}Include


#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif
//{{Implement
IMPLEMENT_SERIAL(CIuBlobs, CIuBlobs_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuBlobs)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_BLOBS, CIuBlobs, CIuBlobs_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuBlobs, IDS_ENGINE_PPG_BLOBS, 50, 0)
	IU_ATTRIBUTE_EDITOR_COLLECTION(CIuBlobs, IDS_ENGINE_PPG_BLOBS, 10, editorAdd|editorDelete|editorMove|editorEdit)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuBlobs::CIuBlobs() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuBlobs::~CIuBlobs()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuBlobs::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	for (int iFile = 0; iFile < GetCount(); ++iFile)
		if (!Get(iFile).Build(Cdrom, Output, Flags))
			return false;
	return Output.Fire();
}

void CIuBlobs::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pEngine = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuBlobs::Create(CIuBlobSpec& BlobSpec)
{
	int iIndex = Add();
	ASSERT(iIndex >= 0);
	CIuBlob& Blob = Get(iIndex);
	Blob.SetSpec(BlobSpec);
}

void CIuBlobs::OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const
{
	CIuBlobPtr pBlob = dynamic_cast<CIuBlob*>(pCollectable.Ptr());
	ASSERT(pBlob.NotNull());
	ASSERT_KINDOF(CIuBlob, pBlob.Ptr());

	if (GetEngine().QueryObject(collectionBlobs, Descriptor, *pBlob))
		pBlob->SetObjectRepository(&GetEngine().GetObjectRepository());
}

CIuCollectablePtr CIuBlobs::OnNew(CWnd*) const
{
	CIuBlobPtr pBlob;
	pBlob.Create();
	return CIuObjectPtr(pBlob);
}

void CIuBlobs::SetEngine(CIuEngine& Engine)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	m_pEngine = &Engine;
}

void CIuBlobs::SetSpec(CIuCdromSpec& Spec)
{
	RemoveAll();
	for (int iBlob = 0; iBlob <  Spec.GetBlobCount(); ++iBlob)
		Create(Spec.GetBlob(iBlob));  	
}

