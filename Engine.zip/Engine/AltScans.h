#ifndef _ENGINE_ALTSCANS_H_
#define _ENGINE_ALTSCANS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_ALTSCAN_H_
#	include "Engine\AltScan.h"
#endif	// _ENGINE_ALTSCAN_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltScans)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltScans, CIuCollection }}
#define CIuAltScans_super CIuCollection

class CIuAltScans : public CIuAltScans_super
{
//{{Declare
	DECLARE_SERIAL(CIuAltScans)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltScans();
	virtual ~CIuAltScans();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuAltScan& Get(const CIuMoniker& moniker) const;
	CIuAltScan& Get(LPCTSTR s) const;
	CIuAltScan& Get(int iIndex) const;
	CIuAltScan& Get(CIuID id) const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags = 0);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void Initialize();
	virtual CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
	void Create(int iAlt);
//}}Implementation

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuAltScan& CIuAltScans::Get(const CIuMoniker& moniker) const
{
	ASSERT(dynamic_cast<CIuAltScan*>(&CIuCollection::Get(moniker)));
	return *reinterpret_cast<CIuAltScan*>(&CIuCollection::Get(moniker));
}

inline CIuAltScan& CIuAltScans::Get(LPCTSTR s) const
{
	ASSERT(dynamic_cast<CIuAltScan*>(&CIuCollection::Get(s)));
	return *reinterpret_cast<CIuAltScan*>(&CIuCollection::Get(s));
}

inline CIuAltScan& CIuAltScans::Get(int iIndex) const
{
	ASSERT(dynamic_cast<CIuAltScan*>(&CIuCollection::Get(iIndex)));
	return *reinterpret_cast<CIuAltScan*>(&CIuCollection::Get(iIndex));
}

inline CIuAltScan& CIuAltScans::Get(CIuID id) const
{
	ASSERT(dynamic_cast<CIuAltScan*>(&CIuCollection::Get(id)));
	return *reinterpret_cast<CIuAltScan*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_ALTSCANS_H_
