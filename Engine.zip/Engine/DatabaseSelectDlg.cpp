#include "stdafx.h"
#include "DatabaseSelectDlg.h"
#include "DatabaseList.h"
#include "Interop\Conversions.h"
#include "Meters.h"
#include "MeterSpecialAccessDlg.h"
#include "Engine.h"
#include "Listeners.h"
#include "Ui\ProgressDlg.h"
#include "Error\Error.h"
#include "Data\SearchWhereDlg.h"
#include "..\Version.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuDatabaseSelectDlg, CIuDatabaseSelectDlg_super)
	//{{AFX_MSG_MAP(CIuDatabaseSelectDlg)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_ENGINE_GRID, OnColumnclickGrid)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_ENGINE_GRID, OnItemchangedGrid)
	ON_NOTIFY(NM_DBLCLK, IDC_ENGINE_GRID, OnDblclkGrid)
	ON_BN_CLICKED(IDC_ENGINE_REFRESH, OnRefresh)
	ON_BN_CLICKED(IDC_ENGINE_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_ENGINE_ALL, OnAll)
	ON_WM_SYSCOMMAND()
	ON_BN_CLICKED(IDC_ENGINE_VALIDATE, OnValidate)
	ON_BN_CLICKED(IDC_ENGINE_STATES, OnStates)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

#define IDM_METER_ADMIN			0x0110
#define IDM_SPECIAL_ACCESS		0x0120

//}}Implement

CIuDatabaseSelectDlg::CIuDatabaseSelectDlg(CWnd* pParent /*=NULL*/)	: CIuDatabaseSelectDlg_super(CIuDatabaseSelectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuDatabaseSelectDlg)
	m_sDescription = _T("");
	m_fAll = false;
	//}}AFX_DATA_INIT
	m_iFlags = 0;
	m_pDatabases = 0;
	m_pQueries = 0;
	m_fMultiSelect = false;
	m_pParent = pParent;
}

void CIuDatabaseSelectDlg::CreateColumns()
{
	m_Grid.DeleteAllItems();
	while (m_Grid.DeleteColumn(0))
		/* NULL */ ;

	LV_COLUMN lvc;
	memset(&lvc, 0, sizeof(lvc));
	lvc.mask = LVCF_TEXT | LVCF_SUBITEM | LVCF_WIDTH | LVCF_FMT;
	lvc.fmt = LVCFMT_LEFT;

	CRect rect;
	m_Grid.GetWindowRect(&rect);

	lvc.iSubItem = 0;
	lvc.pszText = _T("Name");
	lvc.cx = rect.Width() - 4;
	VERIFY(m_Grid.InsertColumn(lvc.iSubItem, &lvc) >= 0);

	if ((m_iFlags & selectShowDescription) != 0)
	{
		++lvc.iSubItem;
		lvc.pszText = _T("Description");
		lvc.cx = 200;
		VERIFY(m_Grid.InsertColumn(lvc.iSubItem, &lvc) >= 0);
	}

	if ((m_iFlags & selectShowID) != 0)
	{
		++lvc.iSubItem;
		lvc.pszText = _T("ID");
		lvc.cx = 100;
		VERIFY(m_Grid.InsertColumn(lvc.iSubItem, &lvc) >= 0);
	}
}

void CIuDatabaseSelectDlg::CreateRows()
{
	m_Grid.DeleteAllItems();
	if (m_pDatabases)
		CreateRows(m_pDatabases);
	if (m_pQueries)
		CreateRows(m_pQueries);
}

void CIuDatabaseSelectDlg::CreateRows(CIuCollection* pCollection)
{
	int iRows = pCollection->GetCount();

	m_Grid.SetItemCount(m_Grid.GetItemCount() + iRows);

	CStringArray asApplications;
	StringAsStringArray(m_sApplication, asApplications, ';');

	for (int i = 0; i < iRows; ++i)
	{
		CIuCollectable& Collectable = pCollection->Get(i);
		bool fKeeper = true;
		if (!m_sApplication.IsEmpty())
		{
			bool fDatabase = Collectable.IsKindOf(RUNTIME_CLASS(CIuDatabase));
			if (fDatabase)
			{
				CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(&Collectable);
				ASSERT(pDatabase);
				CString sApplication = pDatabase->GetApplication();
				fKeeper = false;
				for (int iApplication = 0; iApplication < asApplications.GetSize(); ++iApplication)
				{
					CString sThisApplication = asApplications[iApplication];
					if (sThisApplication.CompareNoCase(sApplication) == 0)
					{
						fKeeper = true;
						break;						
					}
				}
			}
		}
		if (!fKeeper)
			continue;							 

		int iIndex = m_Grid.InsertItem(m_Grid.GetItemCount(), Collectable.GetTitle());

		m_Grid.SetItemData(iIndex, DWORD(Collectable.GetID()));

		int iSelected = m_aidDefaults.GetSize();
		if (iSelected == 0 && !m_fMultiSelect && m_Grid.GetItemCount() == 1)
		{
			m_Grid.SetItemState(iIndex, LVIS_SELECTED, LVIS_SELECTED);
			OnChange(Collectable.GetID());
		}
		else
		{
			for (int iSelect = 0; iSelect < iSelected; ++iSelect)
			{
				if (m_aidDefaults[iSelect] == Collectable.GetID())
				{
					m_Grid.SetItemState(iIndex, LVIS_SELECTED, LVIS_SELECTED);
					break;
				}
			}
		}

		int iColumn = 1;

		if ((m_iFlags & selectShowDescription) != 0)
			m_Grid.SetItemText(iIndex, iColumn++, Collectable.GetDescription());
		if ((m_iFlags & selectShowID) != 0)
			m_Grid.SetItemText(iIndex, iColumn++, Collectable.GetID().AsString());
	}
}

void CIuDatabaseSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuDatabaseSelectDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuDatabaseSelectDlg)
	DDX_Control(pDX, IDC_ENGINE_STATES, m_btnStates);
	DDX_Control(pDX, IDC_ENGINE_VALIDATE, m_btnValidate);
	DDX_Control(pDX, IDC_ENGINE_ALL, m_btnAll);
	DDX_Control(pDX, IDC_ENGINE_GRID, m_Grid);
	DDX_Text(pDX, IDC_ENGINE_DESCRIPTION, m_sDescription);
	DDX_Check(pDX, IDC_ENGINE_ALL, m_fAll);
	//}}AFX_DATA_MAP
}

CIuCollectable* CIuDatabaseSelectDlg::GetCollectable(CIuID ID)
{
	if (m_pDatabases)
	{
		int iIndex = m_pDatabases->Find(ID);
		if (iIndex >= 0)
			return &m_pDatabases->Get(iIndex);
	}
	if (m_pQueries)
	{
		int iIndex = m_pQueries->Find(ID);
		if (iIndex >= 0)
			return &m_pQueries->Get(iIndex);
	}
	return 0;
}

void CIuDatabaseSelectDlg::OnAll()
{
	UpdateData();
	m_Grid.EnableWindow(!m_fAll);
}

void CIuDatabaseSelectDlg::OnCancel()
{
	m_aidDefaults.RemoveAll();
	CIuDatabaseSelectDlg_super::OnCancel();
}

void CIuDatabaseSelectDlg::OnChange(CIuID ID)
{
	m_btnValidate.ShowWindow(SW_HIDE);
	m_btnStates.ShowWindow(SW_HIDE);
	if (!ID.IsInvalid())
	{
		CIuCollectable* pCollectable = GetCollectable(ID);
		if (pCollectable)
		{
			m_sDescription = pCollectable->GetDescription();
			if (pCollectable->IsKindOf(RUNTIME_CLASS(CIuDatabase)))
			{
				CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(pCollectable);
				ASSERT(pDatabase);

				CIuFilename Filename = pDatabase->GetFilename();
				if (Filename.Exists())
					m_btnValidate.ShowWindow(SW_SHOW);

				CStringArray asStates;
				pDatabase->GetStates(asStates);
				if (asStates.GetSize() > 0)
					m_btnStates.ShowWindow(SW_SHOW);
			}
		}
		else
			m_sDescription.Empty();
	}
	else
		m_sDescription.Empty();
	UpdateData(false);
}

void CIuDatabaseSelectDlg::OnColumnclickGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_Sort.Sort(pNMListView->iSubItem);
	*pResult = 0;
}

void CIuDatabaseSelectDlg::OnDblclkGrid(NMHDR* pNMHDR, LRESULT* pResult)
{
	*pResult = 0;
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	if (pNMListView->iItem < 0)
		return ;
	OnOK();
}

BOOL CIuDatabaseSelectDlg::OnInitDialog() 
{
	CIuDatabaseSelectDlg_super::OnInitDialog();


	// IDM_METER_ADMIN must be in the system command range.
	ASSERT((IDM_METER_ADMIN & 0xFFF0) == IDM_METER_ADMIN);
	ASSERT(IDM_METER_ADMIN < 0xF000);
	ASSERT((IDM_SPECIAL_ACCESS & 0xFFF0) == IDM_SPECIAL_ACCESS);
	ASSERT(IDM_SPECIAL_ACCESS < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(false);
	if (pSysMenu != NULL)
	{
		CIuEngine* pEngine;
		if (m_pDatabases)
			pEngine = &m_pDatabases->GetEngine();
		else
			pEngine = &m_pQueries->GetEngine();
		ASSERT(pEngine);
		int iRights = pEngine->GetUserRights();
		if ((iRights & engineRightsMeterAdmin) != 0)
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_SPECIAL_ACCESS, _T("Special Access..."));
			pSysMenu->AppendMenu(MF_STRING, IDM_METER_ADMIN, _T("Administrator..."));
		}
	}

	m_LayoutManager.Attach(this);
	m_LayoutManager.AddChild(IDC_ENGINE_GRID);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_GRID,			OX_LMS_TOP,		OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_GRID,			OX_LMS_LEFT,	OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_GRID,			OX_LMS_RIGHT,  OX_LMT_OPPOSITE, -iWindowMargin, IDOK);
	m_LayoutManager.SetConstraint(IDC_ENGINE_GRID,			OX_LMS_BOTTOM, OX_LMT_OPPOSITE, -iWindowMargin, IDC_ENGINE_DESCRIPTION);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_DESCRIPTION,	OX_LMS_LEFT,	OX_LMT_SAME, iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_DESCRIPTION,	OX_LMS_RIGHT,  OX_LMT_OPPOSITE, -iWindowMargin, IDOK);
	m_LayoutManager.SetConstraint(IDC_ENGINE_DESCRIPTION,	OX_LMS_BOTTOM, OX_LMT_SAME, -iWindowMargin, 0);
	
	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDOK,							OX_LMS_TOP,		OX_LMT_SAME, iWindowMargin, 0);
	
	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDCANCEL,					OX_LMS_TOP,		OX_LMT_OPPOSITE, iWindowMargin, IDOK);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_REFRESH,		OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_REFRESH,		OX_LMS_TOP,		OX_LMT_OPPOSITE, 2 * iWindowMargin, IDCANCEL);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_SEARCH,		OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_SEARCH,		OX_LMS_TOP,		OX_LMT_OPPOSITE, iWindowMargin, IDC_ENGINE_REFRESH);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,		OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_STATES,		OX_LMS_TOP,		OX_LMT_OPPOSITE, 2 * iWindowMargin, IDC_ENGINE_SEARCH);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_VALIDATE,		OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_VALIDATE,		OX_LMS_TOP,		OX_LMT_OPPOSITE, 2 * iWindowMargin, IDC_ENGINE_STATES);
	
	m_LayoutManager.SetConstraint(IDC_ENGINE_ALL,			OX_LMS_RIGHT,	OX_LMT_SAME, -iWindowMargin, 0);
	m_LayoutManager.SetConstraint(IDC_ENGINE_ALL,			OX_LMS_BOTTOM,	OX_LMT_SAME, iWindowMargin, IDC_ENGINE_GRID);
	
	// Set the minimum size of the window
	m_LayoutManager.SetMinMax(IDC_ENGINE_GRID, CSize(200,50));
	m_LayoutManager.SetMinMax(CSize(400, 300));
	
	// Draw the layout with the new constraints
	// This is necessary when constraints are implemented and the window must be refreshed
	m_LayoutManager.RedrawLayout(); 

	m_Grid.SetExtendedStyle(m_Grid.GetExtendedStyle()|LVS_EX_INFOTIP|LVS_EX_FULLROWSELECT);

	DWORD dwStyle = m_Grid.GetStyle();
	if (m_fMultiSelect)
		::SetWindowLong(m_Grid.m_hWnd, GWL_STYLE, dwStyle&(~LVS_SINGLESEL));
	else
	{
		m_btnAll.ShowWindow(SW_HIDE);
		::SetWindowLong(m_Grid.m_hWnd, GWL_STYLE, dwStyle|LVS_SINGLESEL);
	}

	CreateColumns();
	CreateRows();

	m_Sort.Initialize(m_Grid);
	if (m_Grid.GetItemCount())
		m_Grid.SetSelectionMark(0);

	CenterWindow();

	OnAll();

	int iCount = m_Grid.GetItemCount();
	if (iCount == 1)
	{
		if ((m_iFlags & selectAutoDefault) != 0)
		{
			OnOK();
		}
	}

	m_pParent = this;

	return true;  
}

void CIuDatabaseSelectDlg::OnItemchangedGrid(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if ((pNMListView->uNewState & LVIS_FOCUSED) != 0)
	{
		CIuID ID = UINT32(m_Grid.GetItemData(pNMListView->iItem));
		OnChange(ID);
	}
	*pResult = 0;
}

void CIuDatabaseSelectDlg::OnOK() 
{
	m_aidDefaults.RemoveAll();
	POSITION pos = m_Grid.GetFirstSelectedItemPosition();
	if (pos == 0)
	{
		// Must select at least one for database in single select mode
		if (!m_fMultiSelect)
			return ;
	}
	while (pos)
	{
		int iIndex = m_Grid.GetNextSelectedItem(pos);
		CIuID ID = UINT32(m_Grid.GetItemData(iIndex));

		CIuCollectable* pCollectable = GetCollectable(ID);
		if (pCollectable)
		{
			if (pCollectable->IsKindOf(RUNTIME_CLASS(CIuDatabase)))
			{
				CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(pCollectable);
				ASSERT(pDatabase);
				if (!pDatabase->CheckAccessCode(m_pParent))
					return;
				if (!pDatabase->CheckCdOnly(m_pParent))
					return;
				if (!pDatabase->CheckExpired(m_pParent))
					return;
				if (!pDatabase->CheckWarning(m_pParent))
					return ;
				if (!pDatabase->CheckVersion(IU_VERSION, true, m_pParent))
					return ;
				if (!pDatabase->CheckAcknowledge(m_pParent))
					return ;
			}
			m_aidDefaults.Add(pCollectable->GetID());
		}
	}
	CIuDatabaseSelectDlg_super::OnOK();
}

BOOL CIuDatabaseSelectDlg::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		bool bS = GetKeyState('S') & 0x80;
		bool bCtrl = GetKeyState(VK_CONTROL) & 0x80;
		bool bAlt = GetKeyState(VK_MENU) & 0x80;

		if (bS && bCtrl && bAlt)
		{
			OnSpecialAccess();
			return TRUE;
		}
	}

	return CIuDatabaseSelectDlg_super::PreTranslateMessage(pMsg);
}

void CIuDatabaseSelectDlg::OnRefresh() 
{
	CIuEngine* pEngine;
	if (m_pDatabases)
		pEngine = &m_pDatabases->GetEngine();
	else
		pEngine = &m_pQueries->GetEngine();
	ASSERT(pEngine);
	CWaitCursor cursor;
	pEngine->Refresh();
	CreateRows();
	OnChange(idInvalid);
}

void CIuDatabaseSelectDlg::OnSearch() 
{
	CIuEngine* pEngine;
	if (m_pDatabases)
		pEngine = &m_pDatabases->GetEngine();
	else
		pEngine = &m_pQueries->GetEngine();
	ASSERT(pEngine);
	if (CIuSearchWhereDlg::Edit(this))
		OnRefresh();
}

void CIuDatabaseSelectDlg::OnSpecialAccess()
{
	POSITION pos = m_Grid.GetFirstSelectedItemPosition();
	if (pos == 0)
		return ;

	int iIndex = m_Grid.GetNextSelectedItem(pos);
	CIuID ID = UINT32(m_Grid.GetItemData(iIndex));
	CIuCollectable* pCollectable = GetCollectable(ID);
	if (pCollectable == 0)
		return ;
	if (!pCollectable->IsKindOf(RUNTIME_CLASS(CIuDatabase)))
		return ;
	CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(pCollectable);
	if (!pDatabase->HasMeter())
		return ;

	CIuMeterPtr pMeter = &pDatabase->GetMeter();

	CIuMeterSpecialAccessDlg::DoDialog(*pMeter, this);
}

void CIuDatabaseSelectDlg::OnStates() 
{
	POSITION pos = m_Grid.GetFirstSelectedItemPosition();
	if (pos == 0)
		return ;

	int iIndex = m_Grid.GetNextSelectedItem(pos);
	CIuID ID = UINT32(m_Grid.GetItemData(iIndex));

	CIuCollectable* pCollectable = GetCollectable(ID);
	if (pCollectable == 0)
		return ;

	if (!pCollectable->IsKindOf(RUNTIME_CLASS(CIuDatabase)))
		return ;

	CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(pCollectable);
	ASSERT(pDatabase);

	pDatabase->ShowStates(this);
}

void CIuDatabaseSelectDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	if ((nID & 0xFFF0) == IDM_METER_ADMIN)
	{
		m_pDatabases->GetEngine().GetMeters().AdministratorDlg(this);
	}
	else if ((nID & 0xFFF0) == IDM_SPECIAL_ACCESS)
	{
		OnSpecialAccess();
	}
	else
		CIuDatabaseSelectDlg_super::OnSysCommand(nID, lParam);
}

void CIuDatabaseSelectDlg::OnValidate() 
{
	POSITION pos = m_Grid.GetFirstSelectedItemPosition();
	if (pos == 0)
		return ;

	int iIndex = m_Grid.GetNextSelectedItem(pos);
	CIuID ID = UINT32(m_Grid.GetItemData(iIndex));

	CIuCollectable* pCollectable = GetCollectable(ID);
	if (pCollectable == 0)
		return ;

	if (!pCollectable->IsKindOf(RUNTIME_CLASS(CIuDatabase)))
		return ;

	CIuDatabase* pDatabase = dynamic_cast<CIuDatabase*>(pCollectable);
	ASSERT(pDatabase);

	CIuFilename Filename = pDatabase->GetFilename();
	if (!Filename.Exists())
		return ;

	CString sMessage = Filename + 
		CString(" will be be checked for potential data errors. "
		"This operation can take several minutes to an hour or more. " 
		"If errors are found, carefully clean your disk and try again. "
		"Do you want to continue?");
		
	if (AfxMessageBox(sMessage, MB_YESNO|MB_APPLMODAL|MB_DEFBUTTON2) != IDYES)
		return ;

	int iHandle = CIuID::Create();

	CIuEngine& Engine = m_pDatabases->GetEngine();

	CIuProgressDlg* pProgress = CIuProgressDlg::Create(this, _T("Validating..."), &Engine.GetBroadcast(), true);
	pProgress->SetHandle(iHandle);

	CIuOutputPtr pOutput = Engine.CreateOutput();
	pOutput->SetPump(true);
	pOutput->SetHandle(iHandle);


	IU_TRY_ERROR
	{
		CIuPackRepository& PackRepository = Engine.GetPackRepository();

		int iIndex = PackRepository.FindFilename(Filename);
		if (iIndex >= 0)
		{
			CIuPackPtr pPack = PackRepository.GetPack(iIndex);
			ASSERT(pPack.NotNull());
			if (pPack.NotNull())
				pPack->Verify(0, pOutput);
		}
		else
		{
			CIuPack Pack;
			Pack.Open(Filename, true, true);
			Pack.Verify(0, pOutput);
		}
	}
	IU_CATCH_ERROR(e)
	{
		// If tokenizing fails, just keep processing. But, output the message

		e->ReportError();
		e->Delete();
	}
	pProgress->Close();
}

bool CIuDatabaseSelectDlg::SelectDlg(CIuID& id, CIuDatabases* pDatabases, CIuQueries* pQueries, int iFlags, LPCTSTR pcszApplication, CWnd* pParent)
{
	CIuDatabaseSelectDlg dlg(pParent);
	dlg.m_iFlags = iFlags;
	if (pcszApplication)
	{
		ASSERT(AfxIsValidString(pcszApplication));
		dlg.m_sApplication = pcszApplication;
	}
	ASSERT(pDatabases || pQueries);
	dlg.m_pDatabases = pDatabases;
	dlg.m_pQueries = pQueries;
	if (!id.IsInvalid())
		dlg.m_aidDefaults.Add(id);
	dlg.m_fMultiSelect = false;
	if (dlg.DoModal() != IDOK)
		return false;
	if (dlg.m_aidDefaults.GetSize() < 1)
		return false;
	id = dlg.m_aidDefaults[0];
	return true;
}

bool CIuDatabaseSelectDlg::SelectDlg(CIuDatabaseList& DatabaseList, int iFlags, LPCTSTR pcszApplication, CWnd* pParent)
{
	CIuDatabaseSelectDlg dlg(pParent);
	dlg.m_iFlags = iFlags;
	if (pcszApplication)
	{
		ASSERT(AfxIsValidString(pcszApplication));
		dlg.m_sApplication = pcszApplication;
	}
	dlg.m_pDatabases = &DatabaseList.GetEngine().GetDatabases();
	if (DatabaseList.ShowQueries())
		dlg.m_pQueries = &DatabaseList.GetEngine().GetQueries();
	int iDatabases = DatabaseList.GetDatabaseCount();
	for (int iDatabase = 0; iDatabase < iDatabases; ++iDatabase)
		dlg.m_aidDefaults.Add(DatabaseList.GetDatabaseID(iDatabase));
	dlg.m_fAll = DatabaseList.SearchAll();
	dlg.m_fMultiSelect = true;
	if (dlg.DoModal() != IDOK)
		return false;

	DatabaseList.RemoveAllDatabases();
	if (dlg.m_fAll)
	{
		DatabaseList.SetSearchAll(true);
		iDatabases = DatabaseList.GetEngine().GetDatabases().GetCount();
		for (iDatabase = 0; iDatabase < iDatabases; ++iDatabase)
		{
			DatabaseList.AddDatabase(DatabaseList.GetEngine().GetDatabases().Get(iDatabase).GetMoniker(), -1);
		}
	}
	else
	{
		DatabaseList.SetSearchAll(false);
		iDatabases = dlg.m_aidDefaults.GetSize();
		for (iDatabase = 0; iDatabase < iDatabases; ++iDatabase)
		{
			CIuMoniker moniker;

			int iIndex = DatabaseList.GetEngine().GetDatabases().Find(dlg.m_aidDefaults[iDatabase]);
			if (iIndex >= 0)
			{
				DatabaseList.AddDatabase(DatabaseList.GetEngine().GetDatabases().Get(iIndex).GetMoniker(), -1);
				continue;
			}

			if (DatabaseList.ShowQueries())
			{
				int iIndex = DatabaseList.GetEngine().GetQueries().Find(dlg.m_aidDefaults[iDatabase]);
				if (iIndex >= 0)
				{
					DatabaseList.AddDatabase(DatabaseList.GetEngine().GetQueries().Get(iIndex).GetMoniker(), -1);
					continue;
				}
			}
			TRACE("ERROR: Database %s not found\n", LPCTSTR(dlg.m_aidDefaults[iDatabase].AsString()));
			ASSERT(false);
		}
	}
	return true;
}


