#ifndef _ENGINE_REGISTRATIONSPEC_H_
#define _ENGINE_REGISTRATIONSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuRegistrationSpec)
struct CIuRegistrationSpecDft;
class CIuCdromSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuRegistrationSpec, CIuObjectNamed }}
#define CIuRegistrationSpec_super CIuObjectNamed
class CIuRegistrationSpec : public CIuRegistrationSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuRegistrationSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuRegistrationSpec();
	virtual ~CIuRegistrationSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetFaxPhone() const;
	CString GetMailAddress() const;
	int GetMaxRuns() const;
	virtual CIuID GetMeter() const;
	CString GetModemPhone() const;
	CString GetModemPhoneAreaCode() const;
	CString GetModemPhoneCountryCode() const;
	CString GetProductID() const;
	CString GetProductName() const;
	int GetRegistrationNo() const;
	CString GetURL() const;
	void GetValidResponses(CStringArray& as) const;
	CString GetVoicePhone() const;
	bool HasCdrom() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iRegistrationSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszRegistration);
	void FromNo(CIuCdromSpec* pCdrom, int iRegistrationNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuRegistrationSpecDft* pRegistrationSpec);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetFaxPhone(LPCTSTR);
	void SetMailAddress(LPCTSTR);
	void SetMaxRuns(int iMaxRuns);
	void SetMeter(const CIuID& idMeter);
	void SetModemPhone(LPCTSTR);
	void SetModemPhoneAreaCode(LPCTSTR);
	void SetModemPhoneCountryCode(LPCTSTR);
	void SetProductID(LPCTSTR);
	void SetProductName(LPCTSTR);
	void SetRegistrationNo(int);
	void SetURL(LPCTSTR);
	void SetValidResponses(const CStringArray&);
	void SetVoicePhone(LPCTSTR);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuCdromSpec* m_pCdrom;
	int m_iRegistrationNo;
	// Product name and id
	CString m_sProductName;
	CString m_sProductID;
	// Maximum runs allowed (-1 == registration not required)
	int m_iMaxRuns;
	// Locations for registration information
	CString m_sFaxPhone;
	CString m_sMailAddress;
	CString m_sURL;
	// Phone info
	CString m_sVoicePhone;
	CString m_sModemPhoneCountryCode;
	CString m_sModemPhoneAreaCode;
	CString m_sModemPhone;
	// A list of valid responses
	CStringArray m_asValidResponses;
	// The meter which stores the persistent registration information
	CIuID m_idMeter;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuCdromSpec& CIuRegistrationSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuRegistrationSpec::GetFaxPhone() const
{
	return m_sFaxPhone;
}

inline CString CIuRegistrationSpec::GetMailAddress() const
{
	return m_sMailAddress;
}

inline int CIuRegistrationSpec::GetMaxRuns() const
{
	return m_iMaxRuns;
}

inline CIuID CIuRegistrationSpec::GetMeter() const
{
	return m_idMeter;
}

inline CString CIuRegistrationSpec::GetModemPhone() const
{
	return m_sModemPhone;
}

inline CString CIuRegistrationSpec::GetModemPhoneAreaCode() const
{
	return m_sModemPhoneAreaCode;
}

inline CString CIuRegistrationSpec::GetModemPhoneCountryCode() const
{
	return m_sModemPhoneCountryCode;
}

inline CString CIuRegistrationSpec::GetProductID() const
{
	return m_sProductID;
}

inline CString CIuRegistrationSpec::GetProductName() const
{
	return m_sProductName;
}

inline int CIuRegistrationSpec::GetRegistrationNo() const
{
	return m_iRegistrationNo;
}

inline CString CIuRegistrationSpec::GetURL() const
{
	return m_sURL;
}

inline CString CIuRegistrationSpec::GetVoicePhone() const
{
	return m_sVoicePhone;
}

inline bool CIuRegistrationSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

#endif // _ENGINE_REGISTRATIONSPEC_H_
