#ifndef _ENGINE_EXPORTDEF_H_ 
#define _ENGINE_EXPORTDEF_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_EXPORTFIELDDEFS_H_
#	include "Engine\ExportFieldDefs.h"
#endif	// _ENGINE_EXPORTFIELDDEFS_H_
#ifndef 	_ENGINE_CDROMSPECCONST_H_
#	include "Engine\CdromSpecConst.h"
#endif	// _ENGINE_CDROMSPECCONST_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExportDef)
class CIuExportDefs;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

#ifndef IU_ENGINE
#  include "Globals\MfcImport1.h"
#else
#  include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// Export def types
enum CIuExportDefType
{
	// Format is fixed and never changed
	exportDefTypeFixed = 0,
 	// A format which has been modified by the user
	exportDefTypeCustom,
	// Format contains all fields for the specified record set
	exportDefTypeAll,
	// A format which is user customizable but which hasn't been touched
	// by the user yet.
	exportDefTypeDefault,
	// A new format created by the user from scratch
	exportDefTypeUser,
};

/////////////////////////////////////////////////////////////////////////////
// Export Defs
enum CIuExportDefNo
{
	exportDefNone = 0,

	exportDefSingleLine,
	exportDefAct,
	exportDefWordproMailMerge,
	exportDefAutomapStreets,
	exportDefDbaseIiIii,
	exportDefDesktopManager,
	exportDefGoldmine,
	exportDefLotusOrganizer21,
	exportDefMaximizer,
	exportDefMaplinx,
	exportDefMicrosoftWordMailMerge,
	exportDefMicrosoftOutlook,
	exportDefMymaillist,
	exportDefWordPerfectMailMerge,
	exportDefExcel,
	exportDefLotus123,
	exportDefWinfaxPro70,
	exportDefMailingLabel,
	exportDefMailingLabelWPhone,
	exportDefTabDelimited,
	exportDefCommaDelimitedWHeaders,
	exportDefCommaDelimited,
	exportDefCommaDelWLatLongDist,
	exportDefStreets2000Interoperability,
	exportDefPowerStreets,
	exportDefBusinessMapping,
	exportDefPalmPilot1,
	exportDefELetter,
};

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExportDef, CIuCollectable }}
#define CIuExportDef_super CIuCollectable

class IU_CLASS_EXPORT CIuExportDef : public CIuExportDef_super
{
//{{Declare
	DECLARE_SERIAL(CIuExportDef)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExportDef();           
	virtual ~CIuExportDef();
	CIuExportDef(const CIuExportDef&);
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuExportDefs& GetExportDefs() const;
	CString GetExporter() const;
	void GetExporterAllowed(CStringArray& as) const;
	CIuExportFieldDefs& GetFieldDefs() const;
	CString GetExtension() const;
	CIuObjectRepository& GetObjectRepository() const;
	CString GetOptions() const;
	int GetRecordLength() const;
	int GetType() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasExportDefs() const;
	bool HasObjectRepository() const;
	bool IsCustom() const;
	bool IsRefreshable() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	virtual void Copy(const CIuObject& object);
	virtual int CreateFieldDef(LPCTSTR pcszDef);
	virtual int CreateFieldDef(CIuExportFieldDefSpec& spec);
	static CIuVersionNumber GetVersionMin();
	void SetCustom(bool);
	void SetExporter(LPCTSTR pcsz);
	void SetExtension(LPCTSTR pcsz);
	void SetObjectRepository(CIuObjectRepository* pObjectRepository);
	void SetOptions(LPCTSTR pcsz);
	void SetRecordLength(int iRecordLength);
	void SetSpec(CIuExportDefSpec& Spec);
	void SetType(int enm);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	CIuExportDef& operator=(const CIuExportDef&);
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetFieldDefs_() const;
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
protected:
	CIuExportFieldDefsPtr m_pFieldDefs;
private:
	int m_enumType;
	CString m_sExtension;
	CString m_sExporter;
	CString m_sOptions;
	int m_iRecordLength;
	bool m_fCustom;
	CIuObjectRepository* m_pObjectRepository;
//}}Data
};

#ifndef IU_ENGINE
#  include "Globals\MfcImport2.h"
#else
#  include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CIuObjectRepository& CIuExportDef::GetObjectRepository() const
{
	ASSERT(HasObjectRepository());
	return *m_pObjectRepository;
}

inline CString CIuExportDef::GetOptions() const
{
	return m_sOptions;
}

inline int CIuExportDef::GetRecordLength() const
{
	return m_iRecordLength;
}

inline bool CIuExportDef::HasExportDefs() const
{
	return HasCollection();
}

inline bool CIuExportDef::HasObjectRepository() const
{
	return m_pObjectRepository != 0;
}

inline bool CIuExportDef::IsCustom() const
{
	return m_fCustom;
}

#endif 
