#include "StdAfx.h"
//{{Include
#include "BTreeIndexRawSeparator.h"
#include "BTreeIndexSeparator.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

int CIuBTreeIndexRawSeparator::Compare(const CIuKey& key) const
{
	const BYTE* pb1 = GetSeparatorPtr();
	const BYTE* pb2 = key.GetKeyPtr();
	int iCmp = min(GetSeparatorSize(), key.GetKeySize());
	int iResult = memicmp(pb1, pb2, iCmp);
	if (iResult != 0)
		return iResult;
	if (GetSeparatorSize() > key.GetKeySize())
		return 1;
	else if (GetSeparatorSize() < key.GetKeySize())
		return -1;
	return 0;
}

void CIuBTreeIndexRawSeparator::Get(CIuBTreeIndexSeparator& key) const
{
	key.Clear();
	key.Set(GetSeparatorPtr(), GetSeparatorSize());
	key.SetContinuation(IsContinuation());
	key.SetPointerNo(GetPointerNo());
	key.SetRecordNo(GetRecordNo());
}

int CIuBTreeIndexRawSeparator::GetPointerNo() const
{
	return m_dwPointerNo;
}

int CIuBTreeIndexRawSeparator::GetRecordNo() const
{
	DWORD dwRecordNo = m_dwRecordNo;
	return static_cast<int>(dwRecordNo & 0x3FFFFFFF);
}

bool CIuBTreeIndexRawSeparator::IsContinuation() const
{
	DWORD dwRecordNo = m_dwRecordNo;
	return (dwRecordNo & 0x40000000) != 0;
}

bool CIuBTreeIndexRawSeparator::IsEob() const
{
	DWORD dwRecordNo = m_dwRecordNo;
	return (dwRecordNo & 0x80000000) != 0;
}

void CIuBTreeIndexRawSeparator::SetContinuation(bool fContinuation)
{
	DWORD dwRecordNo = m_dwRecordNo;
	dwRecordNo &= ~(0x40000000);
	dwRecordNo |= fContinuation ? 0x40000000: 0x00000000;
	m_dwRecordNo = dwRecordNo;
}

void CIuBTreeIndexRawSeparator::SetEob(bool fEob)
{
	DWORD dwRecordNo = m_dwRecordNo;
	dwRecordNo &= ~(0x80000000);
	dwRecordNo |= fEob ? 0x80000000: 0x00000000;
	m_dwRecordNo = dwRecordNo;
}

void CIuBTreeIndexRawSeparator::SetPointerNo(DWORD dwPointerNo)
{
	m_dwPointerNo = dwPointerNo;
}

void CIuBTreeIndexRawSeparator::SetRecordNo(DWORD dwNewRecordNo)
{
	ASSERT(dwNewRecordNo <= 0x3FFFFFFF);
	DWORD dwRecordNo = m_dwRecordNo;
	dwRecordNo &= ~(0x3FFFFFFF);
	dwRecordNo |= (dwNewRecordNo & 0x3FFFFFFF);
	m_dwRecordNo = dwRecordNo;
}
