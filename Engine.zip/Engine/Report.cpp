#include "StdAfx.h" 
#include "Report.h"

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuReport, CIuReport_super)
IU_IMPLEMENT_OBJECT_PTR(CIuReport)
const	CIuVersionNumber versionReportMax(2000,1,5,304);
const	CIuVersionNumber versionReportMin(1999,0,1,100);
//}}Implement

CIuReport::CIuReport()
{
	CommonConstruct();
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReport::~CIuReport()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuReport::Clear()
{
	CIuReport_super::Clear();
	CIuReport::CommonConstruct();
}

void CIuReport::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(versionReportMax);
	//}}Initialize
}


CIuVersionNumber CIuReport::GetVersionMax() const
{
	return versionReportMax;
}

CIuVersionNumber CIuReport::GetVersionMaxStatic()
{
	return versionReportMax;
}

CIuVersionNumber CIuReport::GetVersionMin() const
{
	return versionReportMin;
}

CIuVersionNumber CIuReport::GetVersionMinStatic()
{
	return versionReportMin;
}
