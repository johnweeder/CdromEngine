#ifndef _ENGINE_GEORAWINSTANCE_H_
#define _ENGINE_GEORAWINSTANCE_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEOINSTANCE_H_
#	include "Engine\GeoInstance.h"
#endif	// _ENGINE_GEOINSTANCE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawInstance)
class CIuGeoRawMap;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawInstance, CIuGeoInstance }}
#define CIuGeoRawInstance_super CIuGeoInstance

class CIuGeoRawInstance : public CIuGeoRawInstance_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawInstance)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawInstance();
	virtual ~CIuGeoRawInstance();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int AddPhone(__int64, int iBefore = -1);
	__int64 GetAreaCode(int iWhich) const;
	__int64 GetExchange(int iWhich) const;
	__int64 GetPhone(int) const;
	int GetPhoneCount() const;
	void GetPhones(CIntArray64& al) const;
	__int64 GetPrefix(int iWhich) const;
	CIuLatLongCoordinate& GetZipCentroid() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void RemoveAllPhones();
	void RemovePhone(int);
	void Set(const CIuRecord& Record, const CIuGeoRawMap& map);
	void SetPhone(int, __int64);
	void SetPhones(const CIntArray64&);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// List of phone numbers extracted from this record
	CIntArray64 m_aiPhones;
	CIuLatLongCoordinate m_ZipCentroid;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline __int64 CIuGeoRawInstance::GetAreaCode(int iWhich) const
{
	return GetPhone(iWhich) / 10000000;
}

inline __int64 CIuGeoRawInstance::GetExchange(int iWhich) const
{
	return GetPhone(iWhich) / 10000;
}

inline __int64 CIuGeoRawInstance::GetPhone(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetPhoneCount());
	return m_aiPhones[iWhich];
}

inline int CIuGeoRawInstance::GetPhoneCount() const
{
	return m_aiPhones.GetSize();
}

inline __int64 CIuGeoRawInstance::GetPrefix(int iWhich) const
{
	return (GetPhone(iWhich) / 10000) % 1000;
}

inline CIuLatLongCoordinate& CIuGeoRawInstance::GetZipCentroid() const
{
	return *const_cast<CIuLatLongCoordinate*>(&m_ZipCentroid);
}

#endif // _ENGINE_GEORAWINSTANCE_H_
