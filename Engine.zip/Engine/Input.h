#ifndef _ENGINE_INPUT_H_
#define _ENGINE_INPUT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_COMMON_BUFFER_H_
#	include "Common\Buffer.h"
#endif	// _COMMON_BUFFER_H_
#ifndef 	_ENGINE_RECORDSPEC_H_
#	include "Engine\RecordSpec.h"
#endif	// _ENGINE_RECORDSPEC_H_
#ifndef 	_ENGINE_RECORDDEF_H_
#	include "Engine\RecordDef.h"
#endif	// _ENGINE_RECORDDEF_H_
#ifndef 	_ENGINE_ADDRESSCODEC_H_
#	include "Engine\AddressCodec.h"
#endif	// _ENGINE_ADDRESSCODEC_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuInput)
class CIuCdromSpec;
class CIuOpenSpec;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

#if _MSC_VER > 1000
#	pragma once
#endif

/////////////////////////////////////////////////////////////////////////////
// Input Field Specifiers
// *** Auto-Generated ***
enum CIuInputField
{
 inputFieldNone = -1,
 inputFieldFirst = 0,
  inputFieldAcPhone= inputFieldFirst,
  inputFieldAdSizeCode,
  inputFieldAreaCode,
  inputFieldAreaCodeName,
  inputFieldAlt,
  inputFieldBusResFlag,
  inputFieldCity,
  inputFieldContact,
  inputFieldCountyCode,
  inputFieldCountyName,
  inputFieldEmployeeSizeCode,
  inputFieldExchange,
  inputFieldExchangeName,
  inputFieldFaxAcPhone,
  inputFieldFirstYear,
  inputFieldFranchiseCode,
  inputFieldFranchiseName,
  inputFieldGender,
  inputFieldLatitude,
  inputFieldLongitude,
  inputFieldMatchLevel,
  inputFieldMedianHomeValue,
  inputFieldMedianIncome,
  inputFieldMsaCode,
  inputFieldMsaName,
  inputFieldName,
  inputFieldNoSolicitation,
  inputFieldPostDir,
  inputFieldPreDir,
  inputFieldPriNo,
  inputFieldPubDate,
  inputFieldSalesVolumeCode,
  inputFieldSeeAlso,
  inputFieldSicCode,
  inputFieldSicName,
  inputFieldSicPreferred,
  inputFieldSecNo,
  inputFieldStateCode,
  inputFieldStreet,
  inputFieldStreetName,
  inputFieldSuffix,
  inputFieldTollFreeAcPhone,
  inputFieldToken,
  inputFieldZIP,
 inputFieldMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Input Formats
// *** Auto-Generated ***
enum CIuInputFormat
{
 inputNone = -1,
 inputFirst = 0,
  inputAreaCode= inputFirst,
  inputAlt,
  inputCensus,
  inputCounty,
  inputExchange,
  inputFranchise,
  inputMsa,
  inputSic,
  inputSicSeeAlso,
  inputStandard,
  inputToken,
  inputZipCentroid,
 inputMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// AreaCode Input Format
// *** Auto-Generated ***
enum CIuInputFormatAreaCode
{
 inputAreaCodeFirst = 0,
  inputAreaCodeAreaCode= inputAreaCodeFirst,
  inputAreaCodeAreaCodeName,
 inputAreaCodeMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Alt Input Format
// *** Auto-Generated ***
enum CIuInputFormatAlt
{
 inputAltFirst = 0,
  inputAltAlt= inputAltFirst,
  inputAltSeeAlso,
 inputAltMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Census Input Format
// *** Auto-Generated ***
enum CIuInputFormatCensus
{
 inputCensusFirst = 0,
  inputCensusZIP= inputCensusFirst,
  inputCensusMedianIncome,
  inputCensusMedianHomeValue,
 inputCensusMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// County Input Format
// *** Auto-Generated ***
enum CIuInputFormatCounty
{
 inputCountyFirst = 0,
  inputCountyCountyCode= inputCountyFirst,
  inputCountyCountyName,
 inputCountyMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Exchange Input Format
// *** Auto-Generated ***
enum CIuInputFormatExchange
{
 inputExchangeFirst = 0,
  inputExchangeExchange= inputExchangeFirst,
  inputExchangeExchangeName,
 inputExchangeMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Franchise Input Format
// *** Auto-Generated ***
enum CIuInputFormatFranchise
{
 inputFranchiseFirst = 0,
  inputFranchiseSicCode= inputFranchiseFirst,
  inputFranchiseFranchiseCode,
  inputFranchiseFranchiseName,
 inputFranchiseMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Msa Input Format
// *** Auto-Generated ***
enum CIuInputFormatMsa
{
 inputMsaFirst = 0,
  inputMsaMsaCode= inputMsaFirst,
  inputMsaMsaName,
 inputMsaMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Sic Input Format
// *** Auto-Generated ***
enum CIuInputFormatSic
{
 inputSicFirst = 0,
  inputSicSicCode= inputSicFirst,
  inputSicSicName,
  inputSicSicPreferred,
 inputSicMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// SicSeeAlso Input Format
// *** Auto-Generated ***
enum CIuInputFormatSicSeeAlso
{
 inputSicSeeAlsoFirst = 0,
  inputSicSeeAlsoSicCode= inputSicSeeAlsoFirst,
  inputSicSeeAlsoSeeAlso,
 inputSicSeeAlsoMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Standard Input Format
// *** Auto-Generated ***
enum CIuInputFormatStandard
{
 inputStandardFirst = 0,
  inputStandardName= inputStandardFirst,
  inputStandardCity,
  inputStandardStateCode,
  inputStandardZIP,
  inputStandardAcPhone,
  inputStandardPriNo,
  inputStandardPreDir,
  inputStandardStreetName,
  inputStandardSuffix,
  inputStandardPostDir,
  inputStandardSecNo,
  inputStandardAdSizeCode,
  inputStandardBusResFlag,
  inputStandardContact,
  inputStandardCountyCode,
  inputStandardEmployeeSizeCode,
  inputStandardFaxAcPhone,
  inputStandardFirstYear,
  inputStandardFranchiseCode,
  inputStandardGender,
  inputStandardLatitude,
  inputStandardLongitude,
  inputStandardMatchLevel,
  inputStandardMsaCode,
  inputStandardNoSolicitation,
  inputStandardPubDate,
  inputStandardSalesVolumeCode,
  inputStandardSicCode,
  inputStandardStreet,
  inputStandardTollFreeAcPhone,
 inputStandardMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// Token Input Format
// *** Auto-Generated ***
enum CIuInputFormatToken
{
 inputTokenFirst = 0,
  inputTokenToken= inputTokenFirst,
  inputTokenSeeAlso,
 inputTokenMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
// ZipCentroid Input Format
// *** Auto-Generated ***
enum CIuInputFormatZipCentroid
{
 inputZipCentroidFirst = 0,
  inputZipCentroidZIP= inputZipCentroidFirst,
  inputZipCentroidLatitude,
  inputZipCentroidLongitude,
 inputZipCentroidMax,
};
// *** Auto-Generated ***

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuInput, CIuCollectable }}
#define CIuInput_super CIuCollectable

class CIuInput : public CIuInput_super
{
//{{Declare
	DECLARE_SERIAL(CIuInput)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuInput();
	virtual ~CIuInput();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	LPCTSTR GetField(int iField) const;
	int GetFormat() const;
	virtual CIuFilename GetFullInputFilename() const;
	virtual CIuFilename GetFullOutputFilename() const;
	CString GetInputFilename() const;
	int GetMaxRecords() const;
	CString GetOptions() const;
	CIuOutput& GetOutput() const;
	CString GetOutputFilename() const;
	virtual int GetRecords() const;
	void GetRecord(CIuRecordPtr& pRecord) const;
	CIuRecordDefPtr GetRecordDef() const;
	static CIuRecordDefPtr GetRecordDef(int iInputFormat);
	void GetRecordSpec(CIuRecordSpec& RecordSpec) const;
	bool HasOutput() const;
	bool ShouldAppend() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual bool Build(CIuOutput& Output, CIuFlags Flags = 0);
	virtual void Delete(CIuOutput* pOutput = 0);
	virtual void SetAppend(bool);
	void SetFilename(LPCTSTR pcsz);
	virtual void SetFormat(int iFormat);
	virtual void SetInputFilename(LPCTSTR);
	virtual void SetMaxRecords(int);
	virtual void SetOptions(LPCTSTR);
	virtual void SetOutput(CIuOutput* pOutput);
	virtual void SetOutputFilename(LPCTSTR);
	virtual void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnClose();
	virtual int OnGetRange();
	virtual bool OnMoveFirst();
	virtual bool OnMoveNext();
	virtual bool OnOpen(CIuOpenSpec& OpenSpec);
	virtual bool OnOutput();
	virtual bool OnProcess();
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
protected:
	void ClearFields();
	bool Input(CIuFlags Flags);
	bool Output();
	bool Process();
	void SetField(int iField, LPCTSTR pcsz);

protected:
	// Helper functions
	void MakeAddress(LPCTSTR pcszPriNo, LPCTSTR pcszPreDir, LPCTSTR pcszStreetName, LPCTSTR pcszSuffix, LPCTSTR pcszPostDir, LPCTSTR pcszSecNo, LPCTSTR pcszHighRise, LPCTSTR pcszNoSolicitation);
	void MakeName(int iField, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMI, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle);
	void MakeNameInitials(int iField, LPCTSTR pcszLast, LPCTSTR pcszFirst, LPCTSTR pcszMI, LPCTSTR pcszGen, LPCTSTR pcszProSuffix, LPCTSTR pcszTitle);
	void MakePhone(int iField, LPCTSTR pcszAreaCode, LPCTSTR pcszPhone);
	void MakeState(LPCTSTR pcszState);
	void MakeZip(LPCTSTR pcszZip5, LPCTSTR pcszAddon, LPCTSTR pcszDPBC);

private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// The raw record input process generally works as follows:
	//		An input source is read. 
	//		The input is massaged into a "buffered" record in a known recordef.
	//		A mapping is applied from the buffered record to the output record.
	//		The resulting record is output

	// Generic info
		// An "options" string containing arbitrary options
		CString m_sOptions;
		// The input format
		int m_iFormat;
		// An output object
		CIuOutput* m_pOutput;
		// Input filename
		CString m_sInputFilename;
		// Output filename
		CString m_sOutputFilename;
		// Do we append or replace the output
		bool m_fAppend;
		// The maximum number of records output
		int m_iMaxRecords;
		// Number of records output thus far
		int m_iRecords;
	// These structures define the record which was input
		// This is the buffer which contains the actual field data. 		
		//	The "pointers" below access this data as an offset from the
		//	start of the buffer
		CIuBuffer m_FieldBuffer;
		// These are pointers to, and lengths of, the input
		//	fields. For ease of processing, fields are null terminated
		//	but the length does not include the null.
		int m_aiFieldOffset[inputFieldMax];
		int m_aiFieldLength[inputFieldMax]; 
		// A record spec used to create a record. Used as a "temp" object.
		mutable CIuRecordSpec m_RecordSpec;
		// A temporary buffer
		CString m_sTemp;
		// Address encoder
		CIuAddressCodec m_Codec;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuInput::GetFormat() const
{
	return m_iFormat;
}

inline CString CIuInput::GetInputFilename() const
{
	return m_sInputFilename;
}

inline int CIuInput::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline CString CIuInput::GetOptions() const
{
	return m_sOptions;
}

inline CIuOutput& CIuInput::GetOutput() const
{
	ASSERT(HasOutput());
	return *m_pOutput;
}

inline CString CIuInput::GetOutputFilename() const
{
	return m_sOutputFilename;
}

inline bool CIuInput::HasOutput() const
{
	return m_pOutput != 0;
}

inline bool CIuInput::ShouldAppend() const
{
	return m_fAppend;
}

#endif // _ENGINE_INPUT_H_
