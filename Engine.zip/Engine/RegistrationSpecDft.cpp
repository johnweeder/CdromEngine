#include "StdAfx.h"
//{{Include
#include "RegistrationSpecDft.h"
#include "Registration.h"
#include "CdromSpecConst.h"
#include "Ids.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Registrationernate specifications

const TCHAR szWebRegistration[] = _T("http://kickapoo.infousa.com/regist1");
const TCHAR szMailAddress[] = _T("infoUSA\r\n5711 S 86TH CIR\r\nOmaha NE 68127");
const TCHAR szFaxAcPhone[] = _T("");
const TCHAR szVoiceAcPhone[] = _T("800-211-1966");
const TCHAR szModemCountryCode[] = _T("1");
const TCHAR szModemAreaCode[] = _T("800");
const TCHAR szModemPhone[] = _T("2169197");

static const CIuRegistrationSpecDft aRegistration[] =
{
	{
		szFormat104m_2001, registration104m_2001,
		_T("104 Million Businesses & Households 2001"),
		_T("125"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("21C01"),
		&idMeter_104m_2001,
	},{
		szFormat88md_2001, registration88md_2001,
		_T("88 Million Households Deluxe 2001"),
		_T("124"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("88M30"),
		&idMeter_88md_2001,
	},{
		szFormatAc_V1, registrationAc_V1,
		_T("Address Corrector"),
		_T("666"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("ADC30"),
		&idMeter_Ac_V1,
	},{
		szFormatBml_2000, registrationBml_2000,
		_T("Business Mailing Lists"),
		_T("323"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("RCD30"),
		&idMeter_Bml_2000,
	},{
		szFormatCi_V1, registrationCi_V1,
		_T("CallerID"),
		_T("667"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("CID30"),
		&idMeter_Ci_V1,
	},{
		szFormatPb_2001, registrationPb_2001,
		_T("Power Business 2001"),
		_T("123"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("PFC56"),
		&idMeter_Pb_2001,
	},{
		szFormatPbm_V1, registrationPbm_V1,
		_T("Personalized Business Mailings"),
		_T("861"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("PBM30"),
		&idMeter_Pbm_V1,
	},{
		szFormatPf_2001, registrationPf_2001,
		_T("PowerFinder Commercial"),
		_T("123"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("PFC56"),
		&idMeter_Pf_2001,
	},{
		szFormatPu_2001, registrationPu_2001,
		_T("PowerFinder USA1 2001"),
		_T("223"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("PFC56"),
		&idMeter_Pu_2001,
	},{
		szFormatRp_2001, registrationRp_2001,
		_T("ResumePlus"),
		_T("863"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("21C01"),
		&idMeter_Rp_2001,
	},{
		szFormatSample, registrationSample,
		_T("Sample"),
		_T("999"),
		-1,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("SMP30"),
		&idMeter_Sample,
	},{
		szFormatSlu_2000, registrationSlu_2000,
		_T("SalesLeadsUSA"),
		_T("861"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("SLU30"),
		&idMeter_Slu_2000,
	},{
		szFormatYpu_2001, registrationYpu_2001,
		_T("YellowPagesUSA 2001"),
		_T("862"),
		9,
		szFaxAcPhone,
		szMailAddress,
		szWebRegistration,
		szVoiceAcPhone,
		szModemCountryCode,
		szModemAreaCode,
		szModemPhone,
		_T("21C01"),
		&idMeter_Ypu_2001,
	}
};

/////////////////////////////////////////////////////////////////////////////
// CIuRegistrationSpecDft

int CIuRegistrationSpecDft::Find(LPCTSTR pcszRegistration)
{
	ASSERT(AfxIsValidString(pcszRegistration));
	for (int i = 0; i < GetCount(); ++i)
	{
		if (_tcsicmp(Get(i)->m_pcszRegistration, pcszRegistration) == 0)
			return i;
	}
	return -1;
}

int CIuRegistrationSpecDft::Find(int iRegistration)
{
	for (int i = 0; i < GetCount(); ++i)
	{
		if (Get(i)->m_iRegistration == iRegistration)
			return i;
	}
	return -1;
}

const CIuRegistrationSpecDft* CIuRegistrationSpecDft::Get(int iWhich)
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return aRegistration + iWhich;
}

int CIuRegistrationSpecDft::GetCount()
{
	return sizeof(aRegistration) / sizeof(aRegistration[0]);
}


