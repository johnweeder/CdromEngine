#ifndef _ENGINE_METERS_H_ 
#define _ENGINE_METERS_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_METER_H_
#	include "Engine\Meter.h"
#endif	// _ENGINE_METER_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuMeters)
class CIuEngine;
class CIuCdromSpec;
class CIuCdrom;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuMeters, CCmdTarget }}
#define CIuMeters_super CIuCollection

class IU_CLASS_EXPORT CIuMeters : public CIuMeters_super
{
//{{Declare
	DECLARE_DYNCREATE(CIuMeters)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuMeters();           
	virtual ~CIuMeters();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuMeter& Get(LPCTSTR s) const;
	CIuMeter& Get(int iIndex) const;
	CIuMeter& Get(CIuID id) const;
	CIuEngine& GetEngine() const;
	int GetUserRights() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool AdministratorDlg(CWnd* pParent = 0, CIuID idMeter = CIuID(), LPCTSTR pcszQueryCode = 0, CString* pResponseCode = 0);
	bool Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags);
	virtual void Clear();
	void Refresh();
	void SetEngine(CIuEngine& Engine);
	void SetSpec(CIuCdromSpec& Spec);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	virtual void OnConnect(int, CIuCollectablePtr pCollectable, CIuObjectDescriptor& Descriptor) const;
	CIuCollectablePtr OnNew(CWnd*) const;
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CString ActionAdministratorDlg(const CIuPropertyCollection& Collection, CIuOutput& Output);
private:
	void CommonConstruct();
	void Create(CIuMeterSpec& MeterSpec);
//}}Implementation

	/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuEngine* m_pEngine;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuMeter& CIuMeters::Get(LPCTSTR s) const
{
	return *dynamic_cast<CIuMeter*>(&CIuCollection::Get(s));
}

inline CIuMeter& CIuMeters::Get(int iIndex) const
{
	return *dynamic_cast<CIuMeter*>(&CIuCollection::Get(iIndex));
}

inline CIuMeter& CIuMeters::Get(CIuID id) const
{
	return *dynamic_cast<CIuMeter*>(&CIuCollection::Get(id));
}

#endif // _ENGINE_METERS_H_
