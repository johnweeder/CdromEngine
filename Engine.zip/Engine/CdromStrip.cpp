#include "StdAfx.h"
//{{Include
#include "CdromStrip.h"
#include "CdromSpec.h"
#include "CdromStripSpec.h"
#include "Strip.h"
#include "RecordSort.h"
#include "resource.h"
#include "resource.h"
#include "Miscellaneous.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromStrip, CIuCdromStrip_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromStrip)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMSTRIP, CIuCdromStrip, CIuCdromStrip_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuCdromStrip, IDS_ENGINE_PPG_CDROMSTRIP, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuCdromStrip, IDS_ENGINE_PROP_FILENAME, GetFilename, SetFilename, 0)
	IU_ATTRIBUTE_EDITOR_STRING(CIuCdromStrip, IDS_ENGINE_PROP_FILENAME, IDS_ENGINE_PPG_CDROMSTRIP, 1, 0)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromStrip, IDS_ENGINE_PROP_STRIP, GetStrip_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromStrip, IDS_ENGINE_PROP_STRIP, IDS_ENGINE_PPG_CDROMSTRIP, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromStrip, IDS_ENGINE_PROP_SORT, GetSort_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromStrip, IDS_ENGINE_PROP_SORT, IDS_ENGINE_PPG_CDROMSTRIP, editorUsePropName)
	IU_ATTRIBUTE_PROPERTY_OBJECT(CIuCdromStrip, IDS_ENGINE_PROP_RECORDS, GetRecords_, SetObjectNotSupported, 0)
	IU_ATTRIBUTE_EDITOR_OBJECT_DLG(CIuCdromStrip, IDS_ENGINE_PROP_RECORDS, IDS_ENGINE_PPG_CDROMSTRIP, editorUsePropName)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdromStrip::CIuCdromStrip() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromStrip::~CIuCdromStrip()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCdromStrip::Build(CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
		Delete(&Output);
	if (Flags.Test(cdromsBuildInputIndexes))
	{
		if (!GetStrip().Build(Output, cdromsBuildInputIndexes|cdromsBuildProcess))
			return false;
		if (!GetSort().Build(Output, cdromsBuildInputIndexes|cdromsBuildProcess))
			return false;
	}
	return true;
}

void CIuCdromStrip::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	if (m_pStrip.IsNull())
	{
		m_pStrip.Create();
	}
	if (m_pSort.IsNull())
	{
		m_pSort.Create();
	}
	if (m_pRecords.IsNull())
	{
		m_pRecords.Create();
	}
	m_sFilename = "";
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuCdromStrip::Delete(CIuOutput* pOutput)
{
	GetRecords().Delete(pOutput);
	GetStrip().Delete(pOutput);
	GetSort().Delete(pOutput);
}

CIuObject* CIuCdromStrip::GetRecords_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pRecords.Ptr()));
}

CIuObject* CIuCdromStrip::GetSort_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pSort.Ptr()));
}

CIuObject* CIuCdromStrip::GetStrip_() const
{
	return const_cast<CIuObject*>(reinterpret_cast<const CIuObject*>(m_pStrip.Ptr()));
}

void CIuCdromStrip::SetFilename(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sFilename = pcsz;
}

void CIuCdromStrip::SetSpec(CIuCdromStripSpec& CdromStripSpec)
{
	// Use filename for the name (for example: business1 and business6 both are named business)
	SetName(CdromStripSpec.GetFilename());
	SetID(CdromStripSpec.GetID());

	SetFilename(CdromStripSpec.GetFilename());

	GetStrip().SetSpec(CdromStripSpec.GetStripNo(), CdromStripSpec.GetCdrom().GetFilename(), GetFilename());
	GetSort().SetSpec(CdromStripSpec.GetSortNo(), GetFilename());
	GetRecords().SetFilename(GetFilename());
}

