#ifndef _ENGINE_CDROMOTHER_H_
#define _ENGINE_CDROMOTHER_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_INPUTSIC_H_
#	include "Engine\InputSic.h"
#endif	// _ENGINE_INPUTSIC_H_
#ifndef 	_ENGINE_INPUTCOUNTY_H_
#	include "Engine\InputCounty.h"
#endif	// _ENGINE_INPUTCOUNTY_H_
#ifndef 	_ENGINE_INPUTFRANCHISE_H_
#	include "Engine\InputFranchise.h"
#endif	// _ENGINE_INPUTFRANCHISE_H_
#ifndef 	_ENGINE_INPUTMSA_H_
#	include "Engine\InputMsa.h"
#endif	// _ENGINE_INPUTMSA_H_
#ifndef 	_ENGINE_INPUTAREACODE_H_
#	include "Engine\InputAreaCode.h"
#endif	// _ENGINE_INPUTAREACODE_H_
#ifndef 	_ENGINE_INPUTEXCHANGE_H_
#	include "Engine\InputExchange.h"
#endif	// _ENGINE_INPUTEXCHANGE_H_
#ifndef 	_ENGINE_INPUTCENSUS_H_
#	include "Engine\InputCensus.h"
#endif	// _ENGINE_INPUTCENSUS_H_
#ifndef 	_ENGINE_INPUTSICSEEALSO_H_
#	include "Engine\InputSicSeeAlso.h"
#endif	// _ENGINE_INPUTSICSEEALSO_H_
#ifndef 	_ENGINE_INPUTZIPCENTROID_H_
#	include "Engine\InputZipCentroid.h"
#endif	// _ENGINE_INPUTZIPCENTROID_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuCdromOther)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuCdromOther, CIuObjectNamed }}
#define CIuCdromOther_super CIuObjectNamed
class IU_CLASS_EXPORT CIuCdromOther : public CIuCdromOther_super
{
//{{Declare
	DECLARE_SERIAL(CIuCdromOther)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuCdromOther();
	virtual ~CIuCdromOther();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	bool Build(CIuOutput& Output, CIuFlags Flags);
	void Delete(CIuOutput* pOutput);
	void Empty();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	CIuInputSic m_Sic;
	CIuInputFranchise m_Franchise;
	CIuInputMsa m_Msa;
	CIuInputCounty m_County;
	CIuInputAreaCode m_AreaCode;
	CIuInputExchange m_Exchange;
	CIuInputCensus m_Census;
	CIuInputZipCentroid m_ZipCentroid;
	CIuInputSicSeeAlso m_SicSeeAlso;
//}}Data
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

#endif // _ENGINE_CDROMOTHER_H_
