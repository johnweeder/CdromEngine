#include "StdAfx.h"
//{{Include
#include "GeoCounty.h"
#include "GeoRawCounty.h"
#include "County.h"
#include "GeoRaw.h"
#include "GeoList.h"
#include "RecordDef.h"
#include "SourceDescriptor.h"
#include "resource.h"
#include "FieldDefConst.h"
#include "Interop\Conversions.h"
#include "StatesRaw.h"
#include "RegExCompare.h"
#include "Common\StaticBuffer.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuGeoCounty, CIuGeoCounty_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuGeoCounty)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_GEOCOUNTY, CIuGeoCounty, CIuGeoCounty_super)
//{{AttributeMap
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuGeoCounty::CIuGeoCounty() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuGeoCounty::~CIuGeoCounty()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuGeoCounty::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetName(_T("GeoCounty"));
	//}}Initialize
}

void CIuGeoCounty::FindScan(CIuGeoList& GeoList, const CIuRegExCompare& RegExCompare) const
{
	int iElements = GetCount();
	for (int iElement = 0; iElement < iElements; ++iElement)
	{
		const CIuCounty& County = Get(iElement);
		LPCTSTR pcsz = County.GetCountyName();
		int iResult = RegExCompare.Compare(pcsz);
		if (!REGEX_EQ(iResult))
			continue;
		GeoList.Add(iElement, iElement);
	}
}

void CIuGeoCounty::GetGeoListFilter(const CIuRegEx& RegEx, CStringArray& asFilter) const
{
	CString sFilter;
	sFilter += RegEx.CreateLikeClause(_T("CountyCode"));
	sFilter += _T(" OR ");
	sFilter += RegEx.CreateLikeClause(_T("CountyName"));
	asFilter.Add(sFilter);
}

LPCTSTR CIuGeoCounty::GetIndex() const
{
	return GetIndexStatic();
}

LPCTSTR CIuGeoCounty::GetIndexStatic()
{
	return _T("County");
}

void CIuGeoCounty::GetRecordDef(CIuRecordDef& RecordDef) const
{
	RecordDef.SetSpec(recordDefGeoCounty);
}

int CIuGeoCounty::GetSourceType() const
{
	return sourceGeoCollectionCounty;
}

void CIuGeoCounty::GetZipList(int iElement, CIuGeoList& GeoList) const
{
	Get(iElement).GetZipList(GeoList);
}

int CIuGeoCounty::OnCompressElement(CIuNybbleBuffer& Buffer, CIuGeoRaw& Geo, CIuGeoRawElement& Element, CIuGeoRawElementCollection&, CIuOutput&)
{
	CIuGeoRawCounty& County = *dynamic_cast<CIuGeoRawCounty*>(&Element);
	ASSERT(&County);

	int iExpandedSize = sizeof(CIuCounty);
	ASSERT(iExpandedSize == 12);

	CString sName = County.GetName();
	CheckField(sName);
	CIuNybbleString::Append(sName, -1, NS_ALPHA, Buffer);
	iExpandedSize += sName.GetLength() + 1;

	CString sTitle = County.GetTitle();
	CheckField(sTitle);
	CIuNybbleString::Append(sTitle, -1, NS_ALPHA, Buffer);
	iExpandedSize += sTitle.GetLength() + 1;

	iExpandedSize += CIuGeoList::Compress(County.GetZips(), Geo.GetZipMap(), Buffer);

	return iExpandedSize + 3 /* State Abbr */;
}

int CIuGeoCounty::OnDeCompressElement(CIuNybbleBuffer& Buffer, int iOffset)
{
	// Append a new element
	CIuCounty* pCounty = (CIuCounty*)AddElement(sizeof(CIuCounty));

	// Decompress the various strings
	CIuStaticBuffer256 BufferCounty;
	iOffset += CIuNybbleString::Get(BufferCounty, -1, true, NS_ALPHA, Buffer, iOffset);
	int iCountyCode = StringAsInt(LPCTSTR(BufferCounty.GetPtr()));
	pCounty->m_iCountyCode = iCountyCode;
	ASSERT(BufferCounty.GetSize() == 5 + 1);

	CIuStaticBuffer256 BufferCountyName;
	iOffset += CIuNybbleString::Get(BufferCountyName, -1, true, NS_ALPHA, Buffer, iOffset);

	// Handle the variable length data. 
	// Note that this will invalidate the pElement pointer
	iOffset = CIuGeoList::DeCompress(*this, Buffer, iOffset);

	// Append the strings
	// Note that this will invalidate the pElement pointer
	AddElementName(LPCTSTR(BufferCounty.GetPtr()));
	AddElementString(LPCTSTR(BufferCountyName.GetPtr()));
	AddElementString(CIuStatesRaw::Code2Abbr(iCountyCode / 1000));
	AddElementStringTerm();

	return iOffset;
}
