#include "StdAfx.h"
//{{Include
#include "CdromOther.h"
#include "CdromSpecConst.h"
#include "Cdrom.h"
#include "resource.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuCdromOther, CIuCdromOther_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuCdromOther)
const	CIuVersionNumber versionCdromOtherMax(2000,1,5,304);
const	CIuVersionNumber versionCdromOtherMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_CDROMOTHER, CIuCdromOther, CIuCdromOther_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuCdromOther, IDS_ENGINE_PPG_CDROMOTHER, 50, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuCdromOther::CIuCdromOther() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuCdromOther::~CIuCdromOther()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

bool CIuCdromOther::Build(CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildDeleteStart|cdromsBuildDeleteEnd))
	{
		Delete(&Output);
		m_Sic.Delete(&Output);
		m_Franchise.Delete(&Output);
		m_Msa.Delete(&Output);
		m_County.Delete(&Output);
		m_AreaCode.Delete(&Output);
		m_Exchange.Delete(&Output);
		m_Census.Delete(&Output);
		m_SicSeeAlso.Delete(&Output);
		m_ZipCentroid.Delete(&Output);
	}
	if (!Flags.Test(cdromsBuildOther))
		return true;
	if (!m_Sic.Build(Output, Flags))
		return false;
	if (!m_Franchise.Build(Output, Flags))
		return false;
	if (!m_Msa.Build(Output, Flags))
		return false;
	if (!m_County.Build(Output, Flags))
		return false;
	if (!m_AreaCode.Build(Output, Flags))
		return false;
	if (!m_Exchange.Build(Output, Flags))
		return false;
	if (!m_Census.Build(Output, Flags))
		return false;
	if (!m_SicSeeAlso.Build(Output, Flags))
		return false;
	if (!m_ZipCentroid.Build(Output, Flags))
		return false;
	return true;
}

void CIuCdromOther::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(versionCdromOtherMax);
	//}}Initialize
}

void CIuCdromOther::Delete(CIuOutput*)
{
	Empty();
}

void CIuCdromOther::Empty()
{
}

CIuVersionNumber CIuCdromOther::GetVersionMax() const
{
	return versionCdromOtherMax;
}

CIuVersionNumber CIuCdromOther::GetVersionMaxStatic()
{
	return versionCdromOtherMax;
}

CIuVersionNumber CIuCdromOther::GetVersionMin() const
{
	return versionCdromOtherMin;
}

CIuVersionNumber CIuCdromOther::GetVersionMinStatic()
{
	return versionCdromOtherMin;
}

