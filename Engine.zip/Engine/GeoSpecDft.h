#ifndef _ENGINE_GEOSPECDFT_H_
#define _ENGINE_GEOSPECDFT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
// Descriptions for the various Geoernate record files
struct CIuGeoSpecDft
{
public:
	static int Find(LPCTSTR pcszGeo);
	static int Find(int iGeo);
	static const CIuGeoSpecDft* Get(int iWhich);
	static int GetCount();

public:
	// The cdrom form name and number
	LPCTSTR m_pcszGeo;
	int m_iGeo;
	// Geo filename (this is the "raw" filename)
	LPCTSTR m_pcszFilename;
	// The fields to be used
	LPCTSTR m_pcszZip;
	LPCTSTR m_pcszCity;
	LPCTSTR m_pcszState;
	LPCTSTR m_pcszMsaCode;
	LPCTSTR m_pcszCountyCode;
	LPCTSTR m_pcszLatitude;
	LPCTSTR m_pcszLongitude;
	LPCTSTR m_pcszMatchLevel;
	LPCTSTR m_pcszPhones;
};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

#endif // _ENGINE_GEOSPECDFT_H_
