#include "StdAfx.h"
//{{Include
#include "ReportDefSpec.h"
#include "ReportDefSpecDft.h"
#include "ReportFieldDefSpec.h"
#include "FieldDefSpec.h"
#include "resource.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuReportDefSpec, CIuReportDefSpec_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuReportDefSpec)
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_REPORTDEFSPEC, CIuReportDefSpec, CIuReportDefSpec_super)
//{{AttributeMap
	IU_ATTRIBUTE_PAGE(CIuReportDefSpec, IDS_ENGINE_PPG_REPORTDEFSPEC, 50, 0)
	IU_ATTRIBUTE_PROPERTY_INT(CIuReportDefSpec, IDS_ENGINE_PROP_REPORTDEFNO, GetReportDefNo, SetReportDefNo, 0)
	IU_ATTRIBUTE_EDITOR_INT(CIuReportDefSpec, IDS_ENGINE_PROP_REPORTDEFNO, IDS_ENGINE_PPG_REPORTDEFSPEC, INT_MIN, INT_MAX, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuReportDefSpec::CIuReportDefSpec() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReportDefSpec::~CIuReportDefSpec()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuReportDefSpec::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_pCdrom = 0;
	m_iReportDefNo = 0;
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuReportDefSpec::CreateFieldDef(LPCTSTR pcszFieldDef)
{
	ASSERT(AfxIsValidString(pcszFieldDef));
	CIuReportFieldDefSpecPtr pFieldDefSpec;
	pFieldDefSpec.Create();
	pFieldDefSpec->Set(pcszFieldDef);
	m_apFieldDefs.Add(pFieldDefSpec);
}

bool CIuReportDefSpec::FromIndex(CIuCdromSpec* pCdrom, int iReportDef)
{
	if (iReportDef < 0 || iReportDef >= GetCount())
		return false;

	Clear();

	const CIuReportDefSpecDft* pReportDef = CIuReportDefSpecDft::Get(iReportDef);

	SetCdrom(pCdrom);
	SetName(pReportDef->m_pcszReportDef);
	SetID(*pReportDef->m_pid);

	SetReportDefNo(pReportDef->m_iReportDef);

	RemoveAllFieldDefs();
	for (int i = 0 ; pReportDef->m_apcszFields[i]; ++i)
		CreateFieldDef(pReportDef->m_apcszFields[i]);

	return true;
}

bool CIuReportDefSpec::FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszName)
{
	return FromIndex(pCdrom, CIuReportDefSpecDft::Find(pcszName));
}

bool CIuReportDefSpec::FromNo(CIuCdromSpec* pCdrom, int iReportDefNo)
{
	return FromIndex(pCdrom, CIuReportDefSpecDft::Find(iReportDefNo));
}

int CIuReportDefSpec::GetCount()
{
	return CIuReportDefSpecDft::GetCount();
}

void CIuReportDefSpec::GetNames(CStringArray& as)
{
	as.RemoveAll();
	for (int i = 0; i < GetCount(); ++i)
		as.Add(CIuReportDefSpecDft::Get(i)->m_pcszReportDef);
}

CIuReportFieldDefSpec& CIuReportDefSpec::GetFieldDef(int iReportFieldDef) const
{
	ASSERT(iReportFieldDef >= 0 && iReportFieldDef < GetFieldDefCount());
	return *m_apFieldDefs[iReportFieldDef];
}

int CIuReportDefSpec::GetFieldDefCount() const
{
	return m_apFieldDefs.GetSize();	
}

void CIuReportDefSpec::RemoveAllFieldDefs()
{
	m_apFieldDefs.RemoveAll();
}

void CIuReportDefSpec::SetCdrom(CIuCdromSpec* pCdrom)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pCdrom != 0);
	m_pCdrom = pCdrom;
}


void CIuReportDefSpec::SetReportDefNo(int iReportDefNo)
{
	m_iReportDefNo = iReportDefNo;
}
