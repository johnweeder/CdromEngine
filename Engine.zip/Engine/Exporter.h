#ifndef _ENGINE_EXPORTER_H_
#define _ENGINE_EXPORTER_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_DATA_ARCHIVE_H_
#	include "Data\Archive.h"
#endif	// _DATA_ARCHIVE_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuExporter)
IU_DEFINE_OBJECT_PTR(CIuXChgFile)
IU_DEFINE_OBJECT_PTR(CIuExporterInstance)
class CIuExporters;
class CIuEngine;
class CIuExporterInstance;
class CIuOpenSpec;
//}}Predefines


#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuExporter, CIuCollectable }}
#define CIuExporter_super CIuCollectable

class IU_CLASS_EXPORT CIuExporter : public CIuExporter_super
{
//{{Declare
	DECLARE_SERIAL(CIuExporter)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuExporter();           
	virtual ~CIuExporter();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	static LPCTSTR GetExporterName(const CIuID& id);
	CIuExporters& GetExporters() const;
	CString GetExtension() const;
	int GetFieldNameLength() const;
	bool GetFieldNamesUnique() const;
	int GetMaxFields() const;
	int GetMaxRecords() const;
	CIuExporterInstance& GetInstance() const;
	virtual CIuVersionNumber GetVersionMax() const;
	static CIuVersionNumber GetVersionMaxStatic();
	virtual CIuVersionNumber GetVersionMin() const;
	static CIuVersionNumber GetVersionMinStatic();
	bool HasInstance() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	virtual void Clear();
	CIuXChgFilePtr CreateXChgFile(CIuOpenSpec&) const;
	void SetExtension(LPCTSTR pcsz);
	void SetFieldNameLength(int iFieldNameLength);
	void SetFieldNamesUnique(bool f);
	void SetMaxFields(int iMaxFields);
	void SetMaxRecords(int iMaxRecords);
	bool SetSpec(CIuID id);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	int m_iFieldNameLength;
	bool m_fFieldNamesUnique;
	CString m_sExtension;
	int m_iMaxRecords;
	int m_iMaxFields;
	CIuExporterInstancePtr m_pInstance;
//}}Data
};

#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif

//{{Inline}}

inline CString CIuExporter::GetExtension() const
{
	return m_sExtension;
}

inline int CIuExporter::GetFieldNameLength() const
{
	return m_iFieldNameLength;
}

inline bool CIuExporter::GetFieldNamesUnique() const
{
	return m_fFieldNamesUnique;
}

inline CIuExporterInstance& CIuExporter::GetInstance() const
{
	return m_pInstance.Ref();
}

inline int CIuExporter::GetMaxFields() const
{
	return m_iMaxFields;
}

inline int CIuExporter::GetMaxRecords() const
{
	return m_iMaxRecords;
}

inline bool CIuExporter::HasInstance() const
{
	return m_pInstance.NotNull();
}

#endif // _ENGINE_EXPORTER_H_
