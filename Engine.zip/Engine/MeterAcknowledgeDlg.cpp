#include "stdafx.h"
#include "engine.h"
#include "MeterAcknowledgeDlg.h"
#include "Meter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
BEGIN_MESSAGE_MAP(CIuMeterAcknowledgeDlg, CIuMeterAcknowledgeDlg_super)
	//{{AFX_MSG_MAP(CIuMeterAcknowledgeDlg)
	ON_EN_CHANGE(IDC_ENGINE_PROFILE_YES_EDIT, OnChangeYesEdit)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//}}Implement

CIuMeterAcknowledgeDlg::CIuMeterAcknowledgeDlg(CWnd* pParent /*=NULL*/) : CIuMeterAcknowledgeDlg_super(CIuMeterAcknowledgeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIuMeterAcknowledgeDlg)
	m_sPhone = _T("");
	//}}AFX_DATA_INIT
}

void CIuMeterAcknowledgeDlg::DoDataExchange(CDataExchange* pDX)
{
	CIuMeterAcknowledgeDlg_super::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIuMeterAcknowledgeDlg)
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_ENGINE_PROFILE_YES_EDIT, m_editYes);
	DDX_Control(pDX, IDC_ENGINE_PROFILE_RECEIPT, m_stReceipt);
	DDX_Text(pDX, IDC_ENGINE_PROFILE_PHONE, m_sPhone);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CIuMeterAcknowledgeDlg message handlers

bool CIuMeterAcknowledgeDlg::DoDialog(CIuMeter& Meter, CWnd* pParent)
{
	CIuMeterAcknowledgeDlg Dlg(pParent);
	Dlg.m_pMeter = &Meter;
	return Dlg.DoModal() == IDOK;
}

void CIuMeterAcknowledgeDlg::OnCancel() 
{
	CIuMeterAcknowledgeDlg_super::OnCancel();
} 

void CIuMeterAcknowledgeDlg::OnChangeYesEdit() 
{
	CString sText;
	m_editYes.GetWindowText(sText);

	if (sText.CompareNoCase(_T("YES")) == 0)
	{
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnOK.ShowWindow(SW_SHOW);
	}
	else
	{
		m_btnOK.ShowWindow(SW_HIDE);
		m_btnCancel.ShowWindow(SW_SHOW);
	}
}

BOOL CIuMeterAcknowledgeDlg::OnInitDialog() 
{
	CIuMeterAcknowledgeDlg_super::OnInitDialog();
	
	m_btnOK.ShowWindow(SW_HIDE);

	if (!m_pMeter)
		return FALSE;

	VERIFY(m_AttentionBitmap.LoadBitmap(IDB_ENGINE_ATTENTION));

	CString sSpeedBump = _T("");
	if (m_pMeter->HasSpeedBump())
	{
		sSpeedBump.Format(IDS_ENGINE_PROFILE_SPEEDBUMP, m_pMeter->GetMaxOutput());
	}

	CString sReceipt;
	if (m_pMeter->IsMetered())
	{
		// Always display the current count... there is some relatively complex logic
		// defining how many record profiles a user actually get.
		sReceipt.Format(IDS_ENGINE_PROFILE_RECEIPT, m_pMeter->GetCount(), sSpeedBump);
	}
	else
	{
		sReceipt.Format(IDS_ENGINE_PROFILE_RECEIPT_NO_METER, sSpeedBump);
	}

	m_stReceipt
		.SetBorder(borderSingle|borderSunken)
		.SetFontSize(9)
		.SetFontBold()
		.SetFontName("Arial")
		.SetTransparent()
		.SetText(sReceipt);

	m_sPhone = m_pMeter->GetPhone();

	UpdateData(FALSE);

	return TRUE;  
}

void CIuMeterAcknowledgeDlg::OnOK() 
{
	CString sText;
	m_editYes.GetWindowText(sText);
	if (sText.CompareNoCase(_T("YES")) != 0)
		return ;

	CIuMeterAcknowledgeDlg_super::OnOK();
}

void CIuMeterAcknowledgeDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rect;
	GetDlgItem(IDC_ATTENTION)->GetWindowRect(&rect);
	ScreenToClient(&rect);
	m_AttentionBitmap.Draw(dc, rect, bitmapTransparent|bitmapCentered);
}
