#ifndef _ENGINE_ALTSPEC_H_
#define _ENGINE_ALTSPEC_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuAltSpec)
class CIuCdromSpec;
struct CIuAltSpecDft;
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuAltSpec, CIuObjectNamed }}
#define CIuAltSpec_super CIuObjectNamed

class CIuAltSpec : public CIuAltSpec_super
{
//{{Declare
	DECLARE_SERIAL(CIuAltSpec)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuAltSpec();
	virtual ~CIuAltSpec();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	int GetAltNo() const;
	CIuCdromSpec& GetCdrom() const;
	static int GetCount();
	CString GetFilename() const;
	bool HasCdrom() const;
	bool IsNoStore() const;
	bool IsNumericKey() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void FromIndex(CIuCdromSpec* pCdrom, int iAltSpec);
	void FromName(CIuCdromSpec* pCdrom, LPCTSTR pcszAlt);
	void FromNo(CIuCdromSpec* pCdrom, int iAltNo);
	void FromSpec(CIuCdromSpec* pCdrom, const CIuAltSpecDft* pAltSpec);
	void SetAltNo(int iAltNo);
	void SetCdrom(CIuCdromSpec* pCdrom);
	void SetFilename(LPCTSTR);
	void SetNoStore(bool);
	void SetNumericKey(bool);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
private:
	void CommonConstruct();
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	bool m_fNoStore;
	bool m_fNumericKey;
	CIuCdromSpec* m_pCdrom;
	CString m_sFilename;
	int m_iAltNo;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline int CIuAltSpec::GetAltNo() const
{
	return m_iAltNo;
}

inline CIuCdromSpec& CIuAltSpec::GetCdrom() const
{
	ASSERT(HasCdrom());
	return *m_pCdrom;
}

inline CString CIuAltSpec::GetFilename() const
{
	return m_sFilename;
}

inline bool CIuAltSpec::HasCdrom() const
{
	return m_pCdrom != 0;
}

inline bool CIuAltSpec::IsNoStore() const
{
	return m_fNoStore;
}

inline bool CIuAltSpec::IsNumericKey() const
{
	return m_fNumericKey;
}

#endif // _ENGINE_ALTSPEC_H_
