#include "StdAfx.h"
//{{Include
#include "ReleaseNote.h"
#include "ReleaseNoteSpec.h"
#include "ReleaseNotes.h"
#include "Engine.h"
#include "Error\Error.h"
#include "resource.h"
#include "..\Version.h"
#include "Data\Output.h"
#include "Data\resource.h"
#include "VersionDlg.h"
#include "CdromSpecConst.h"
#include "Cdrom.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_DYNCREATE(CIuReleaseNote, CIuReleaseNote_super)
IU_IMPLEMENT_OBJECT_PTR(CIuReleaseNote)
const	CIuVersionNumber versionReleaseNoteMax(2000,1,5,304);
const	CIuVersionNumber versionReleaseNoteMin(1999,0,1,100);
//}}Implement

IU_BEGIN_ATTRIBUTE_MAP(IDS_ENGINE_OBJECT_RELEASENOTE, CIuReleaseNote, CIuReleaseNote_super)
//{{AttributeMap
	IU_ATTRIBUTE_ACTION(CIuReleaseNote, IDS_ENGINE_ACTION_CHECKVERSION, ActionCheckVersion, 0)
	IU_ATTRIBUTE_PAGE(CIuReleaseNote, IDS_ENGINE_PPG_RELEASENOTE, 50, 0)
	IU_ATTRIBUTE_PROPERTY_STRING(CIuReleaseNote, IDS_ENGINE_PROP_NOTES, GetNotes, SetNotes, 0)
	IU_ATTRIBUTE_EDITOR_RTF(CIuReleaseNote, IDS_ENGINE_PROP_NOTES, IDS_ENGINE_PPG_RELEASENOTE, 0)
	IU_ATTRIBUTE_EDITOR_ACTION(CIuReleaseNote, IDS_ENGINE_ACTION_CHECKVERSION, IDS_ENGINE_PPG_RELEASENOTE, editorAutoUpdate)
	IU_ATTRIBUTE_PROPERTY_VERSION(CIuReleaseNote, IDS_ENGINE_PROP_RELEASEMIN, GetReleaseMin, SetReleaseMin, 0)
	IU_ATTRIBUTE_EDITOR_VERSION(CIuReleaseNote, IDS_ENGINE_PROP_RELEASEMIN, IDS_ENGINE_PPG_RELEASENOTE, 0)
	IU_ATTRIBUTE_PROPERTY_VERSION(CIuReleaseNote, IDS_ENGINE_PROP_RELEASECURRENT, GetReleaseCurrent, SetReleaseCurrent, 0)
	IU_ATTRIBUTE_EDITOR_VERSION(CIuReleaseNote, IDS_ENGINE_PROP_RELEASECURRENT, IDS_ENGINE_PPG_RELEASENOTE, 0)
//}}AttributeMap
IU_END_ATTRIBUTE_MAP()

CIuReleaseNote::CIuReleaseNote()
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuReleaseNote::CIuReleaseNote(const CIuReleaseNote& rReleaseNote)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rReleaseNote;
}

CIuReleaseNote::~CIuReleaseNote()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CString CIuReleaseNote::ActionCheckVersion(const CIuPropertyCollection&, CIuOutput& Output)
{
	CheckVersion(IU_VERSION, true, Output.GetParentWnd());
	return CString("Success");
}

bool CIuReleaseNote::Build(CIuCdrom& Cdrom, CIuOutput& Output, CIuFlags Flags)
{
	if (Flags.Test(cdromsBuildSetRepository))
		SetObjectRepository(&Cdrom.GetObjectRepository());
	if (Flags.Test(cdromsBuildUpdateRepository))
		GetObjectRepository().Add(*this);
	if (Flags.Test(cdromsBuildPackAuxiliaryObjects))
		GetObjectRepository().Pack(*this, Cdrom.GetPack(), &Output);
	return true;
}

bool CIuReleaseNote::CheckVersion(CIuVersionNumber version, bool fShowDlg, CWnd* pParent)
{
	CIuVersionNumber versionCurrent = GetReleaseCurrent();
	if (version >= versionCurrent)
		return true;

	if (fShowDlg)
	{
		CIuVersionDlg::DoDialog(version, this, pParent);
	}
	return version >= GetReleaseMin();
}

void CIuReleaseNote::Clear()
{
	CIuReleaseNote_super::Clear();
	CIuReleaseNote::CommonConstruct();
}

void CIuReleaseNote::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(versionReleaseNoteMax);
	m_sNotes = "";
	m_pObjectRepository = 0;
	m_verReleaseMin = IU_VERSION_MIN;
	m_verReleaseCurrent = IU_VERSION;
	//}}Initialize
}

void CIuReleaseNote::Copy(const CIuObject& object)
{
	CIuReleaseNote_super::Copy(object);

	const CIuReleaseNote* pReleaseNote = dynamic_cast<const CIuReleaseNote*>(&object);
	if (pReleaseNote == 0 || pReleaseNote == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuReleaseNote)));
	
	SetID(pReleaseNote->GetID());
	SetNotes(pReleaseNote->GetNotes());
	SetName(pReleaseNote->GetName());
	SetReleaseCurrent(pReleaseNote->GetReleaseCurrent());
	SetReleaseMin(pReleaseNote->GetReleaseMin());
}

CIuReleaseNotes& CIuReleaseNote::GetReleaseNotes() const
{
	CIuReleaseNotes* pParent = dynamic_cast<CIuReleaseNotes*>(const_cast<CIuCollection*>(&GetCollection()));
	ASSERT(pParent);
	return *pParent;
}

CIuVersionNumber CIuReleaseNote::GetVersionMax() const
{
	return versionReleaseNoteMax;
}

CIuVersionNumber CIuReleaseNote::GetVersionMaxStatic()
{
	return versionReleaseNoteMax;
}

CIuVersionNumber CIuReleaseNote::GetVersionMin() const
{
	return versionReleaseNoteMin;
}

CIuVersionNumber CIuReleaseNote::GetVersionMinStatic()
{
	return versionReleaseNoteMin;
}

CIuReleaseNote& CIuReleaseNote::operator=(const CIuReleaseNote& rReleaseNote)
{
	Copy(rReleaseNote);
	return *this;
}

void CIuReleaseNote::SetNotes(LPCTSTR pcsz)
{
	ASSERT(AfxIsValidString(pcsz));
	m_sNotes = pcsz;
}

void CIuReleaseNote::SetObjectRepository(CIuObjectRepository* pObjectRepository)
{
	// Note, do not add a reference. 
	// We simply want to keep a weak reference back to the object.
	ASSERT(pObjectRepository != 0);
	m_pObjectRepository = pObjectRepository;
}

void CIuReleaseNote::SetReleaseCurrent(CIuVersionNumber ver)
{
	m_verReleaseCurrent = ver;
}

void CIuReleaseNote::SetReleaseMin(CIuVersionNumber ver)
{
	m_verReleaseMin = ver;
}

void CIuReleaseNote::SetSpec(CIuReleaseNoteSpec& Spec)
{
	SetMoniker(Spec.GetMoniker());
	SetNotes(Spec.GetNotes());
	SetReleaseCurrent(Spec.GetReleaseCurrent());
	SetReleaseMin(Spec.GetReleaseMin());
}


