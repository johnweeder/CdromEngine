#ifndef _ENGINE_LATLONGUNIT_H_
#define _ENGINE_LATLONGUNIT_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

const DWORD dwLatLongInvalid = 0xFFFFFFFF;

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuLatLongUnit}}

class IU_CLASS_EXPORT CIuLatLongUnit
{

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuLatLongUnit();
	CIuLatLongUnit(const CIuLatLongUnit&);
	CIuLatLongUnit(DWORD);
	CIuLatLongUnit(LPCTSTR);
	// Do NOT make this virtual... we don't want to fatten up this class.
	// Do not add any other virtual functions either
	// ~CIuLatLongUnit();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	DWORD AsDWORD() const;
	CString AsString(bool fDms = false) const;
	int AsString(LPTSTR psz, int cb, bool fDms = false) const;
	bool IsValid() const;
	bool IsZero() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Clear();
	bool Constrain(const CIuLatLongUnit& Centroid);
	void FromDWORD(DWORD);
	void FromString(LPCTSTR);
	void NonNegative();
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Operators
public:
	operator DWORD() const;
	operator CString() const;
	CIuLatLongUnit& operator=(const CIuLatLongUnit&);
	CIuLatLongUnit& operator=(LPCTSTR);
	CIuLatLongUnit& operator=(DWORD);
	
	CIuLatLongUnit operator+(LPCTSTR) const;
	CIuLatLongUnit operator+(DWORD) const;
	CIuLatLongUnit operator-(LPCTSTR) const;
	CIuLatLongUnit operator-(DWORD) const;
	
	CIuLatLongUnit& operator+=(LPCTSTR);
	CIuLatLongUnit& operator+=(DWORD);

	CIuLatLongUnit& operator-=(LPCTSTR);
	CIuLatLongUnit& operator-=(DWORD);

	bool operator==(const CIuLatLongUnit& ) const;
	bool operator!=(const CIuLatLongUnit& LatLongUnit) const;

	bool operator<(const CIuLatLongUnit&) const;
	bool operator<=(const CIuLatLongUnit&) const;

	bool operator>(const CIuLatLongUnit& LatLongUnit) const;
	bool operator>=(const CIuLatLongUnit& LatLongUnit) const;
//}}Operators

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
protected:
	friend IU_API_EXPORT CArchive& operator>>(CArchive& ar, CIuLatLongUnit& unit);
	friend IU_API_EXPORT CArchive& operator<<(CArchive& ar, const CIuLatLongUnit& unit);

private:
	int AsStringInternal(LPTSTR psz, bool fDms) const;
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Always store lat/int as DWORD
	DWORD	m_dwLatLong;
//}}Data
};

IU_API_EXPORT CArchive& operator>>(CArchive& ar, CIuLatLongUnit& unit);
IU_API_EXPORT CArchive& operator<<(CArchive& ar, const CIuLatLongUnit& unit);

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline bool CIuLatLongUnit::operator==(const CIuLatLongUnit& LatLongUnit ) const
{
	return m_dwLatLong == LatLongUnit.m_dwLatLong;
}

inline bool CIuLatLongUnit::operator!=(const CIuLatLongUnit& LatLongUnit) const
{
	return m_dwLatLong != LatLongUnit.m_dwLatLong;
}

inline CIuLatLongUnit::operator DWORD() const
{
	return m_dwLatLong;
}

inline CIuLatLongUnit& CIuLatLongUnit::operator=(const CIuLatLongUnit& latlong)
{
	m_dwLatLong = latlong.m_dwLatLong;
	return *this;
}

inline CIuLatLongUnit& CIuLatLongUnit::operator=(DWORD dw)
{
	m_dwLatLong = dw;
	return *this;
}

#endif // _ENGINE_LATLONGUNIT_H_
