#ifndef _ENGINE_GEORAWZIP_H_
#define _ENGINE_GEORAWZIP_H_
#if _MSC_VER > 1000
#	pragma once
#endif

//{{Uses
#ifndef 	_ENGINE_GEORAWELEMENT_H_
#	include "Engine\GeoRawElement.h"
#endif	// _ENGINE_GEORAWELEMENT_H_
#ifndef 	_ENGINE_LATLONGUNIT_H_
#	include "Engine\LatLongUnit.h"
#endif	// _ENGINE_LATLONGUNIT_H_
//}}Uses

//{{Predefines
IU_DEFINE_OBJECT_PTR(CIuGeoRawZip)
//}}Predefines

//{{Export1
#ifndef IU_ENGINE
#	include "Globals\MfcImport1.h"
#else
#	include "Globals\MfcExport1.h"
#endif
//}}Export1

/////////////////////////////////////////////////////////////////////////////
//{{Class: CIuGeoRawZip, CIuGeoRawElement }}
#define CIuGeoRawZip_super CIuGeoRawElement

class CIuGeoRawZip : public CIuGeoRawZip_super
{
//{{Declare
	DECLARE_SERIAL(CIuGeoRawZip)
	IU_DECLARE_ATTRIBUTE_MAP()
//}}Declare

/////////////////////////////////////////////////////////////////////////////
//{{Constructor/Destuctor
public:
	CIuGeoRawZip();
	virtual ~CIuGeoRawZip();
//}}Constructor/Destuctor

/////////////////////////////////////////////////////////////////////////////
//{{Attributes
public:
	CIuGeoRawElementAccumulator& GetCounty() const;
	CIuGeoRawElementAccumulator& GetAreaCode() const;
	CIuGeoRawElementAccumulator& GetCity() const;
	CIuLatLongUnit GetLatitude() const;
	CString GetLatitudeAsString() const;
	CString GetLatitudeAverageAsString() const;
	CIuLatLongUnit GetLatitudeCentroid0() const;
	CIuLatLongUnit GetLatitudeCentroid1() const;
	CIuLatLongUnit GetLatitudeCentroid2() const;
	CString GetLatitudeCentroid0AsString() const;
	CString GetLatitudeCentroid1AsString() const;
	CString GetLatitudeCentroid2AsString() const;
	CIuLatLongUnit GetLatitudeMax() const;
	CString GetLatitudeMaxAsString() const;
	CIuLatLongUnit GetLatitudeMin() const;
	CString GetLatitudeMinAsString() const;
	CIuLatLongUnit GetLongitude() const;
	CString GetLongitudeAsString() const;
	CString GetLongitudeAverageAsString() const;
	CIuLatLongUnit GetLongitudeCentroid0() const;
	CIuLatLongUnit GetLongitudeCentroid1() const;
	CIuLatLongUnit GetLongitudeCentroid2() const;
	CString GetLongitudeCentroid0AsString() const;
	CString GetLongitudeCentroid1AsString() const;
	CString GetLongitudeCentroid2AsString() const;
	CIuLatLongUnit GetLongitudeMax() const;
	CString GetLongitudeMaxAsString() const;
	CIuLatLongUnit GetLongitudeMin() const;
	CString GetLongitudeMinAsString() const;
	int GetMedianHomeValue() const;
	int GetMedianIncome() const;
	CIuGeoRawElementAccumulator& GetState() const;
	CIuGeoRawElementAccumulator& GetMsa() const;
	CIuGeoRawElementAccumulator& GetPrefix() const;
//}}Attributes

/////////////////////////////////////////////////////////////////////////////
//{{Operations
public:
	void Another(const CIuGeoRawElementCollection& collection, const CIuGeoRawInstance& instance, CIuOutput& Output);
	bool CheckLatLongConstraint(CIuOutput& Output);
	void SetMedianHomeValue(int);
	void SetMedianIncome(int);
//}}Operations

/////////////////////////////////////////////////////////////////////////////
//{{Overrides
public:
	void Serialize(CArchive& ar);
//}}Overrides

/////////////////////////////////////////////////////////////////////////////
//{{Implementation
public:
	CIuObject* GetAreaCode_() const;
	CIuObject* GetCity_() const;
	CIuObject* GetCounty_() const;
	CIuObject* GetMsa_() const;
	CIuObject* GetPrefix_() const;
	CIuObject* GetState_() const;
private:
//}}Implementation

/////////////////////////////////////////////////////////////////////////////
//{{Data
private:
	// Various information about the ZIP code
	mutable CIuGeoRawElementAccumulator m_City;
	mutable CIuGeoRawElementAccumulator m_State;
	mutable CIuGeoRawElementAccumulator m_Msa;
	mutable CIuGeoRawElementAccumulator m_AreaCode;
	mutable CIuGeoRawElementAccumulator m_County;

	// A list of phone prefixes found in this zip
	mutable CIuGeoRawElementAccumulator m_Prefix;

	// These are some demographics for the ZIP code
	int m_iMedianIncome;
	int m_iMedianHomeValue;

	// The min/max lat/int. This does not include records thrown out for being way
	// out of range.
	CIuLatLongUnit m_LatitudeMax;
	CIuLatLongUnit m_LatitudeMin;
	CIuLatLongUnit m_LongitudeMin;
	CIuLatLongUnit m_LongitudeMax;

	// This accumulate lat/longs. We use this to create a centroid if 
	// an actual centroid is not located.
	__int64 m_iLatitudeAccumulator;
	__int64 m_iLongitudeAccumulator;
	__int64 m_iLatLongs;

	// This is the actual centroid as reported from the centroid file.
	// These may be blank if the ZIP is not found in the centroid file.
	CIuLatLongUnit m_LatitudeCentroid0;
	CIuLatLongUnit m_LongitudeCentroid0;

	// We carry two centroids because the business and residential data are 
	// encoded from different sources.
	// We prefer which-ever centroid is "used" the most.
	__int64 m_LatLongCentroid1Count;
	__int64 m_LatLongCentroid2Count;
	CIuLatLongUnit m_LatitudeCentroid1;
	CIuLatLongUnit m_LatitudeCentroid2;
	CIuLatLongUnit m_LongitudeCentroid1;
	CIuLatLongUnit m_LongitudeCentroid2;

	// These are flags for one-time only error messages.
	bool m_fNoCentroidMessage;
	bool m_fTooManyCentroidsMessage;
	bool m_fCentroidMisMatchMessage;
//}}Data

};

//{{Export2
#ifndef IU_ENGINE
#	include "Globals\MfcImport2.h"
#else
#	include "Globals\MfcExport2.h"
#endif
//}}Export2

//{{Inline}}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetAreaCode() const
{
	return m_AreaCode;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetCity() const
{
	return m_City;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetCounty() const
{
	return m_County;
}

inline int CIuGeoRawZip::GetMedianHomeValue() const
{
	return m_iMedianHomeValue;
}

inline int CIuGeoRawZip::GetMedianIncome() const
{
	return m_iMedianIncome;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetMsa() const
{
	return m_Msa;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetPrefix() const
{
	return m_Prefix;
}

inline CIuGeoRawElementAccumulator& CIuGeoRawZip::GetState() const
{
	return m_State;
}

#endif // _ENGINE_GEORAWZIP_H_
