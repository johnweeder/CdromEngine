#include "StdAfx.h"
//{{Include
#include "ExpressionWord.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
//}}Implement

CIuExpressionWord::CIuExpressionWord() : CIuExpressionElement(exprContainsWord)
{
	CommonConstruct();
	SetFormat(exprFormatBool);
}

CIuExpressionWord::CIuExpressionWord(const CIuExpressionWord& rExpressionElement)
{
	CommonConstruct();
	*this = rExpressionElement;
}

CIuExpressionWord::~CIuExpressionWord()
{
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

CIuExpressionElement* CIuExpressionWord::Clone() const
{
	CIuExpressionWord* pElement = new CIuExpressionWord(*this);
	ASSERT(pElement);
	return pElement;
} 

void CIuExpressionWord::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	m_fPatternConst = false;
	//}}Initialize
}

bool CIuExpressionWord::EvaluateBool(const CIuRecord* pRecord) const
{
	ASSERT(GetType() == exprContainsWord);
	ASSERT(GetChildCount() == 2);
	if (!m_fPatternConst)
		m_Comparator.SetExpression(EvaluateChild(1, pRecord));

	bool fContains = m_Comparator.Compare(EvaluateChild(0, pRecord));
	return fContains;
}

int CIuExpressionWord::EvaluateInt(const CIuRecord* pRecord) const
{
	return int(EvaluateBool(pRecord));
}

int CIuExpressionWord::GetMaxLength() const
{
	// Always returns boolean "0" or "1"
	return BooiMaxLength();
}

LPCTSTR CIuExpressionWord::GetTypeName() const
{
	switch (GetType())
	{
		case exprContainsWord:
			return "CONTAINSWORD";
	}
	return CIuExpressionWord_super::GetTypeName();
}

CIuExpressionWord& CIuExpressionWord::operator=(const CIuExpressionWord& rExpressionElement)
{
	if (this == &rExpressionElement)
		return *this;
	CommonConstruct();
	CIuExpressionWord_super::operator=(rExpressionElement);
	m_Comparator = rExpressionElement.m_Comparator;
	m_fPatternConst = rExpressionElement.m_fPatternConst;
	return *this;
}

void CIuExpressionWord::Resolve(CIuResolveSpec& Spec)
{
	CIuExpressionWord_super::Resolve(Spec);
	ASSERT(GetType() == exprContainsWord);
	ASSERT(GetChildCount() == 2);

	m_fPatternConst = GetChild(1).IsConst();
	if (m_fPatternConst)
		m_Comparator.SetExpression(EvaluateChild(1, 0));
}
