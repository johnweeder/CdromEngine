#include "StdAfx.h"
//{{Include
#include "RegExList.h"
#include "RegEx.h"
#include "Common\String.h"
#include "..\Version.h"
//}}Include

#ifdef _DEBUG
#	define new DEBUG_NEW
#	undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

//{{Implement
IMPLEMENT_SERIAL(CIuRegExList, CIuRegExList_super,0)
IU_IMPLEMENT_OBJECT_PTR(CIuRegExList)
//}}Implement

CIuRegExList::CIuRegExList() 
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
}

CIuRegExList::CIuRegExList(const CIuRegExList& rRegExList)
{
	IuDataAddObject(GetRuntimeClass()->m_lpszClassName);
	CommonConstruct();
	*this = rRegExList;
}

CIuRegExList::~CIuRegExList()
{
	IuDataReleaseObject(GetRuntimeClass()->m_lpszClassName);
}

/////////////////////////////////////////////////////////////////////////////
//{{Members}}

void CIuRegExList::Add(LPCTSTR pcszName, LPCTSTR pcszExpression, int iFlags)
{
	CIuRegExPtr pRegEx;
	pRegEx.Create();
	if (pcszName)
		pRegEx->SetName(pcszName);
	if (pcszExpression)
		pRegEx->SetExpression(pcszExpression, iFlags);
	m_Tuples.Add(pRegEx);
}

void CIuRegExList::Clear() 
{
	m_Tuples.RemoveAll();
}

void CIuRegExList::CommonConstruct()
{
	// DO _NOT_ RECURSE OR MAKE VIRTUAL. Doing so would cause redundant execution and would break serialization.
	//{{Initialize
	SetVersion(IU_VERSION);
	//}}Initialize
}

void CIuRegExList::Copy(const CIuObject& object)
{
	CIuRegExList_super::Copy(object);

	const CIuRegExList* pRegExList = dynamic_cast<const CIuRegExList*>(&object);
	if (pRegExList == 0 || pRegExList == this)
		return ;
	ASSERT(object.IsKindOf(RUNTIME_CLASS(CIuRegExList)));
	m_Tuples.RemoveAll();
	for (int i = 0; i < pRegExList->m_Tuples.GetSize(); ++i)
	{
		CIuRegExPtr pRegEx;
		pRegEx.Create();
		*pRegEx = *(pRegExList->m_Tuples[i]);
		m_Tuples.Add(pRegEx);
	}
}

int CIuRegExList::Find(LPCTSTR pcszName) const
{
	ASSERT(AfxIsValidString(pcszName));
	for (int i = 0; i < GetCount(); ++i)
	{
		CIuRegEx& RegEx = Get(i);
		CString sName = RegEx.GetName();
		if (sName.CompareNoCase(pcszName) == 0)
			return i;
	}
	return -1;
}

CString CIuRegExList::Get() const
{
	CString s;
	for (int i = 0; i < GetCount(); ++i)
	{
		if (i != 0)
			s += ',';

		CIuRegEx& RegEx = Get(i);
		CString sName = RegEx.GetName();
		if (!sName.IsEmpty())
		{
			s += _T("[");
			s += sName;
			s += _T("]");
		}
		CString sExpression = RegEx.GetExpression();
		if (!sExpression.IsEmpty())
		{
			if (!sName.IsEmpty())
				s += _T("=");
			s += _T("\'");
			s += sExpression;
			s += _T("\'");
		}
	}
	return s;
}

CIuRegEx& CIuRegExList::Get(int iWhich) const
{
	ASSERT(iWhich >= 0 && iWhich < GetCount());
	return *m_Tuples[iWhich];
}

void CIuRegExList::GetNames(CStringArray& as) const
{
	as.RemoveAll();
	for (int i = 0; i < GetCount(); ++i)
		as.Add(Get(i).GetName());
}

CIuRegExList& CIuRegExList::operator=(const CIuRegExList& rRegExList)
{
	Copy(rRegExList);
	return *this;
}

void CIuRegExList::Remove(int iWhich) 
{
	m_Tuples.RemoveAt(iWhich);
}

void CIuRegExList::Set(LPCTSTR pcsz, int iFlags)
{
	Clear();

	if (pcsz == 0)
		return ;
	ASSERT(AfxIsValidString(pcsz));

	while (pcsz && *pcsz)
	{
		// Skip white space
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == '\0')
			break;

		// Extract the name
		CString sName;
		if (*pcsz != '=')
		{
			if (*pcsz == '[')
			{
				++pcsz;

				for (; *pcsz && *pcsz != ']'; ++pcsz)
					sName += *pcsz;

				if (*pcsz == ']')
					++pcsz;
			}
			else if (*pcsz != '\'' && *pcsz != '\"')
			{
				for (; *pcsz && *pcsz != '=' &&  *pcsz != ','; ++pcsz)
					sName += *pcsz;
			}
		}

		// Handle the equal sign
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == '=')
			++pcsz;
		pcsz = _tcsskipws(pcsz);

		// Extract the expression
		CString sExpression;
		if (*pcsz == '\'' || *pcsz == '\"')
		{
			TCHAR chQuote = *pcsz;
			++pcsz;

			for (; *pcsz  && *pcsz != chQuote; )
			{
				if (*pcsz == '\\')
				{
					sExpression += *pcsz;
					++pcsz;
					if (*pcsz)
					{
						sExpression += *pcsz;
						++pcsz;						
					}
					else
						sExpression += '\\';
				}
				else
				{
					sExpression += *pcsz;
					++pcsz;
				}
			}

			if (*pcsz == chQuote)
				++pcsz;
		}
		else
		{
			// Hard core case... take everything up to the next comma
			for (; *pcsz && *pcsz != ','; ++pcsz)
				sExpression += *pcsz;

			// Trim whitespace
			sExpression.TrimLeft();
			sExpression.TrimRight();
		}

		// Add an expression
		if (!sName.IsEmpty() || !sExpression.IsEmpty())
			Add(sName, sExpression, iFlags);

		// Move to next...
		pcsz = _tcsskipws(pcsz);
		if (*pcsz == ',')
			++pcsz;
	}
}

void CIuRegExList::SetNames(const CStringArray& as) 
{
	Clear();
	for (int i = 0; i < as.GetSize(); ++i)
		Add(as[i]);
}


#ifdef _DEBUG
#include "Interop\Test.h"

IU_TEST_BEGIN(RegExList, pv)
{
	UNUSED_ALWAYS(pv);

	CIuRegExList RegExList;
	LPCTSTR pcszInput = "[name1] = 'expression1',[name2] , 'expression3',name4,=expression5,name6= ,name7.name7";
	RegExList.Set(pcszInput, regExAll);
	ASSERT(RegExList.GetCount() == 7);
	CString sOutput = RegExList.Get();
	LPCTSTR pcszOutput = "[name1]='expression1',[name2],'expression3',[name4],'expression5',[name6],[name7.name7]";
	ASSERT(sOutput.Compare(pcszOutput) == 0);
	
	ASSERT(RegExList.Get(0).GetName().Compare(_T("name1")) == 0);
	ASSERT(RegExList.Get(1).GetName().Compare(_T("name2")) == 0);
	ASSERT(RegExList.Get(2).GetName().Compare(_T("")) == 0);
	ASSERT(RegExList.Get(3).GetName().Compare(_T("name4")) == 0);
	ASSERT(RegExList.Get(4).GetName().Compare(_T("")) == 0);
	ASSERT(RegExList.Get(5).GetName().Compare(_T("name6")) == 0);
	ASSERT(RegExList.Get(6).GetName().Compare(_T("name7.name7")) == 0);

	ASSERT(RegExList.Get(0).GetExpression().Compare(_T("expression1")) == 0);
	ASSERT(RegExList.Get(1).GetExpression().Compare(_T("")) == 0);
	ASSERT(RegExList.Get(2).GetExpression().Compare(_T("expression3")) == 0);
	ASSERT(RegExList.Get(3).GetExpression().Compare(_T("")) == 0);
	ASSERT(RegExList.Get(4).GetExpression().Compare(_T("expression5")) == 0);
	ASSERT(RegExList.Get(5).GetExpression().Compare(_T("")) == 0);
	ASSERT(RegExList.Get(6).GetExpression().Compare(_T("")) == 0);

	return 0;	
}
IU_TEST_END()
#endif
